// ============================================================================
// OSITO-TITAN-85: 49.2g Sub-50g Heavy-Lift STEM Logistics & Bridge Crane Drone
// Airframe: 85mm PETG-CF Spine + TPU 95A Tandem-Bumper Ducts
// Motors: 1102 18000KV (4-bolt 9mm circle) | Props: 45mm 4-Blade Heavy-Lift
// Payload Mechanism: 2.8g Electro-Permanent Magnetic (EPM) Belly Cargo Winch
// ============================================================================

$fn = 72;

wheelbase_mm = 85.0;
duct_inner_r = 23.2;       // 45mm 4-blade prop + 0.7mm tip clearance
duct_wall_t = 1.35;
duct_height = 10.5;
spine_t = 2.2;             // Carbon-Fiber PETG structural X-truss
epm_winch_r = 7.5;         // Center-of-gravity Electro-Permanent Magnet housing

module heavy_lift_duct(cx, cy) {
    translate([cx, cy, 0]) {
        difference() {
            cylinder(r = duct_inner_r + duct_wall_t, h = duct_height, center = true);
            cylinder(r = duct_inner_r, h = duct_height + 1.0, center = true);
        }
        // 4 heavy-duty stator struts for 1102 high-torque motors
        for (a = [45, 135, 225, 315]) {
            rotate([0, 0, a])
                translate([0, -0.9, -duct_height/2])
                    cube([duct_inner_r, 1.8, 2.4]);
        }
        translate([0, 0, -duct_height/2 + 1.2])
            difference() {
                cylinder(r = 6.8, h = 2.4, center = true);
                cylinder(r = 2.0, h = 4.0, center = true);
            }
    }
}

module petg_cf_structural_spine() {
    for (a = [45, -45]) {
        rotate([0, 0, a])
            translate([0, 0, -duct_height/2 + spine_t/2])
                cube([wheelbase_mm, 5.5, spine_t], center = true);
    }
}

module epm_magnetic_cargo_winch_bay() {
    // Centered directly on Z-axis below CG to prevent pitch/roll moment coupling
    translate([0, 0, -duct_height/2 - 3.0]) {
        difference() {
            cylinder(r = epm_winch_r, h = 6.0, center = true);
            cylinder(r = epm_winch_r - 1.5, h = 4.5, center = true);
        }
        // Self-centering conical docking guide for steel-capped foam bridge trusses
        translate([0, 0, -3.5])
            difference() {
                cylinder(r1 = epm_winch_r + 3.0, r2 = epm_winch_r, h = 3.0, center = true);
                cylinder(r1 = epm_winch_r + 1.5, r2 = epm_winch_r - 1.2, h = 3.5, center = true);
            }
    }
}

module titan85_complete_frame() {
    offset_xy = (wheelbase_mm / 2.0) / sqrt(2.0);
    union() {
        heavy_lift_duct( offset_xy,  offset_xy);
        heavy_lift_duct(-offset_xy,  offset_xy);
        heavy_lift_duct(-offset_xy, -offset_xy);
        heavy_lift_duct( offset_xy, -offset_xy);
        petg_cf_structural_spine();
        epm_magnetic_cargo_winch_bay();
    }
}

titan85_complete_frame();
