#!/usr/bin/env python3
"""
Automated Verification Suite for Wave 8 — Track 8.3:
OSITO-FIREFLY-65 (31.8g) & OSITO-TITAN-85 (49.2g) Youth STEM & Gamified Arena Drones
Verifies >= 40 deterministic hardware, physics, choreography, CAD, and safety checks.
"""

import json
import sys
import unittest
from pathlib import Path

import firefly_titan_flight_choreographer as fc

BASE_DIR = Path(__file__).resolve().parent


class TestFireflyAndTitanFleet(unittest.TestCase):
    # --- Gate 1 & Gate 2: Mass Envelope & Core Fleet Reuse ---
    def test_01_firefly65_exact_auw_31_8g(self):
        total = round(sum(fc.FIREFLY_65_SPEC["dry_mass_breakdown_g"].values()), 2)
        self.assertEqual(total, 31.8)
        self.assertEqual(fc.FIREFLY_65_SPEC["auw_g"], 31.8)

    def test_02_firefly65_under_50g_youth_ceiling(self):
        self.assertLess(fc.FIREFLY_65_SPEC["auw_g"], 50.0)

    def test_03_firefly65_core_reuse_above_70pct(self):
        self.assertGreaterEqual(fc.FIREFLY_65_SPEC["core_fleet_reuse_pct"], 70.0)

    def test_04_firefly65_thrust_to_weight_ratio(self):
        self.assertAlmostEqual(fc.FIREFLY_65_SPEC["thrust_to_weight_ratio"], 2.56, places=2)
        self.assertGreaterEqual(fc.FIREFLY_65_SPEC["thrust_to_weight_ratio"], 2.2)

    def test_05_firefly65_has_36_ws2812b_2020_leds(self):
        self.assertEqual(fc.FIREFLY_65_SPEC["led_count"], 36)
        self.assertAlmostEqual(
            fc.FIREFLY_65_SPEC["dry_mass_breakdown_g"]["ws2812b_2020_36led_rgbic_halo"], 2.4
        )

    def test_06_titan85_exact_dry_auw_49_2g(self):
        total = round(sum(fc.TITAN_85_SPEC["dry_mass_breakdown_g"].values()), 2)
        self.assertEqual(total, 49.2)
        self.assertEqual(fc.TITAN_85_SPEC["auw_g"], 49.2)

    def test_07_titan85_strictly_under_50g_youth_ceiling(self):
        self.assertLess(fc.TITAN_85_SPEC["auw_g"], 50.0)

    def test_08_titan85_core_reuse_above_70pct(self):
        self.assertGreaterEqual(fc.TITAN_85_SPEC["core_fleet_reuse_pct"], 70.0)

    def test_09_titan85_unloaded_twr_2_89(self):
        self.assertEqual(fc.TITAN_85_SPEC["peak_static_thrust_g"], 142.0)
        self.assertAlmostEqual(fc.TITAN_85_SPEC["unloaded_twr"], 2.89, places=2)

    def test_10_titan85_max_payload_22g_and_71_2g_gross(self):
        self.assertEqual(fc.TITAN_85_SPEC["max_safe_payload_g"], 22.0)
        self.assertEqual(fc.TITAN_85_SPEC["loaded_gross_mass_g"], 71.2)
        self.assertAlmostEqual(fc.TITAN_85_SPEC["loaded_twr"], 1.99, delta=0.02)

    def test_11_titan85_epm_winch_mass_2_8g(self):
        self.assertEqual(fc.TITAN_85_SPEC["dry_mass_breakdown_g"]["epm_belly_cargo_winch"], 2.8)

    # --- Gate 3: Avionics & Firmware Safety Interlocks ---
    def test_12_u16_timer_normal_progression(self):
        self.assertEqual(fc.elapsed_ms_u16(1250, 1000), 250)

    def test_13_u16_timer_rollover_across_65535(self):
        # 65500 -> 100 across 16-bit boundary = 136ms
        self.assertEqual(fc.elapsed_ms_u16(100, 65500), 136)

    def test_14_u16_timer_exact_boundary_wrap(self):
        self.assertEqual(fc.elapsed_ms_u16(0, 65535), 1)

    def test_15_disarmed_locks_motor_1000us_and_winch_1500us(self):
        res = fc.evaluate_safety_interlocks(
            armed=False, now_ms=500, last_rx_ms=490,
            cmd_motor_us=1650, cmd_winch_us=1900, epm_latch_request=True
        )
        self.assertFalse(res["armed_output"])
        self.assertEqual(res["motor_pwm_us"], 1000)
        self.assertEqual(res["winch_pwm_us"], 1500)
        self.assertFalse(res["epm_energized_pulse"])
        self.assertEqual(res["flight_mode"], "DISARMED_LOCKED")

    def test_16_stage2_failsafe_drop_at_400ms(self):
        res = fc.evaluate_safety_interlocks(
            armed=True, now_ms=1400, last_rx_ms=1000,
            cmd_motor_us=1550, cmd_winch_us=1800, epm_latch_request=True
        )
        self.assertTrue(res["failsafe_drop"])
        self.assertFalse(res["armed_output"])
        self.assertEqual(res["motor_pwm_us"], 1000)
        self.assertEqual(res["winch_pwm_us"], 1500)
        self.assertEqual(res["flight_mode"], "FAILSAFE_DROP")

    def test_17_stage2_failsafe_across_u16_wrap(self):
        # last_rx = 65300, now = 200 -> elapsed = 436ms >= 400ms -> FAILSAFE_DROP
        res = fc.evaluate_safety_interlocks(
            armed=True, now_ms=200, last_rx_ms=65300,
            cmd_motor_us=1600, cmd_winch_us=1700, epm_latch_request=True
        )
        self.assertTrue(res["failsafe_drop"])
        self.assertEqual(res["motor_pwm_us"], 1000)
        self.assertEqual(res["winch_pwm_us"], 1500)

    def test_18_armed_healthy_rx_passes_clamped_pwm(self):
        res = fc.evaluate_safety_interlocks(
            armed=True, now_ms=1100, last_rx_ms=1000,
            cmd_motor_us=1480, cmd_winch_us=1600, epm_latch_request=True
        )
        self.assertTrue(res["armed_output"])
        self.assertFalse(res["failsafe_drop"])
        self.assertEqual(res["motor_pwm_us"], 1480)
        self.assertEqual(res["winch_pwm_us"], 1600)
        self.assertTrue(res["epm_energized_pulse"])

    def test_19_pwm_saturation_clamping(self):
        res = fc.evaluate_safety_interlocks(
            armed=True, now_ms=1050, last_rx_ms=1000,
            cmd_motor_us=2400, cmd_winch_us=800, epm_latch_request=False
        )
        self.assertEqual(res["motor_pwm_us"], 2000)
        self.assertEqual(res["winch_pwm_us"], 1000)

    # --- Firefly-65 Visual PID & Physics Telemetry Halo ---
    def test_20_telemetry_halo_periwinkle_locked_hover(self):
        h = fc.compute_firefly_telemetry_halo(vbat_v=3.85, pitch_deg=2.0, roll_deg=-1.5, vz_mps=0.02)
        self.assertEqual(h["telemetry_state"], "LOCKED_HOVER")
        self.assertEqual(h["hex_color"], "#7077CF")
        self.assertEqual(len(h["led_ring_36"]), 36)

    def test_21_telemetry_halo_emerald_positive_climb(self):
        h = fc.compute_firefly_telemetry_halo(vbat_v=3.80, pitch_deg=4.0, roll_deg=3.0, vz_mps=0.28)
        self.assertEqual(h["telemetry_state"], "POSITIVE_CLIMB")
        self.assertEqual(h["hex_color"], "#10B981")

    def test_22_telemetry_halo_amber_high_tilt(self):
        h = fc.compute_firefly_telemetry_halo(vbat_v=3.80, pitch_deg=18.5, roll_deg=4.0, vz_mps=0.30)
        self.assertEqual(h["telemetry_state"], "HIGH_TILT_BANK")
        self.assertEqual(h["hex_color"], "#F59E0B")

    def test_23_telemetry_halo_crimson_lvc_override(self):
        h = fc.compute_firefly_telemetry_halo(vbat_v=3.48, pitch_deg=20.0, roll_deg=10.0, vz_mps=0.40)
        self.assertEqual(h["telemetry_state"], "BATTERY_LVC_PULSE")
        self.assertEqual(h["hex_color"], "#EF4444")

    # --- Firefly-65 Sky-Painter 8-Second Trajectories ---
    def test_24_sky_painter_star_8_seconds(self):
        pts = fc.generate_sky_painter_pattern("Star")
        self.assertEqual(len(pts), 80)
        self.assertEqual(pts[0]["t_sec"], 0.0)
        self.assertEqual(pts[-1]["t_sec"], 8.0)

    def test_25_sky_painter_dna_helix_8_seconds(self):
        pts = fc.generate_sky_painter_pattern("DNA_Helix")
        self.assertEqual(len(pts), 80)
        self.assertEqual(pts[-1]["t_sec"], 8.0)

    def test_26_sky_painter_golden_gate_tower_8_seconds(self):
        pts = fc.generate_sky_painter_pattern("Golden_Gate_Tower")
        self.assertEqual(len(pts), 80)
        self.assertEqual(pts[-1]["t_sec"], 8.0)

    def test_27_sky_painter_school_initials_8_seconds(self):
        pts = fc.generate_sky_painter_pattern("School_Initials")
        self.assertEqual(len(pts), 80)
        self.assertEqual(pts[-1]["t_sec"], 8.0)

    def test_28_sky_painter_geofence_bounds(self):
        for name in ["Star", "DNA_Helix", "Golden_Gate_Tower", "School_Initials"]:
            for pt in fc.generate_sky_painter_pattern(name):
                self.assertGreaterEqual(pt["x_m"], -1.2)
                self.assertLessEqual(pt["x_m"], 1.2)
                self.assertGreaterEqual(pt["z_m"], 0.8)
                self.assertLessEqual(pt["z_m"], 2.5)

    def test_29_gym_finale_4drone_60s_schedule(self):
        sched = fc.generate_4drone_gym_finale_schedule()
        self.assertEqual(sched["duration_s"], 60.0)
        self.assertEqual(sched["drones_count"], 4)
        self.assertEqual(len(sched["phases"]), 4)

    # --- Titan-85 Heavy-Lift & Pendulum Damping Physics ---
    def test_30_titan85_unloaded_0g_metrics(self):
        m = fc.compute_titan85_lift_and_pendulum_metrics(0.0)
        self.assertEqual(m["gross_mass_g"], 49.2)
        self.assertEqual(m["twr"], 2.89)
        self.assertTrue(m["min_twr_compliant"])

    def test_31_titan85_seismic_pod_8g_metrics(self):
        m = fc.compute_titan85_lift_and_pendulum_metrics(8.0)
        self.assertEqual(m["gross_mass_g"], 57.2)
        self.assertAlmostEqual(m["twr"], 2.48, places=2)

    def test_32_titan85_medical_crate_14g_metrics(self):
        m = fc.compute_titan85_lift_and_pendulum_metrics(14.0)
        self.assertEqual(m["gross_mass_g"], 63.2)
        self.assertAlmostEqual(m["twr"], 2.25, places=2)

    def test_33_titan85_max_bridge_span_22g_metrics(self):
        m = fc.compute_titan85_lift_and_pendulum_metrics(22.0)
        self.assertEqual(m["gross_mass_g"], 71.2)
        self.assertGreaterEqual(m["twr"], 1.99)
        self.assertLess(m["hover_throttle_pct"], 51.0)

    def test_34_titan85_rejects_overload_above_22g(self):
        with self.assertRaises(ValueError):
            fc.compute_titan85_lift_and_pendulum_metrics(25.0)

    def test_35_titan85_zv_input_shaper_delay_bounds(self):
        m = fc.compute_titan85_lift_and_pendulum_metrics(18.5)
        self.assertGreater(m["zv_shaper_impulse_delay_ms"], 350.0)
        self.assertLess(m["zv_shaper_impulse_delay_ms"], 480.0)

    # --- Deliverable File & Brand Parity Verification ---
    def test_36_html_manual_exists_and_has_brand_tokens(self):
        p = BASE_DIR / "Osito_Firefly65_and_Titan85_STEM_Fleet_Manual.html"
        self.assertTrue(p.exists())
        txt = p.read_text(encoding="utf-8")
        self.assertIn("Fjalla One", txt)
        self.assertIn("#7077CF", txt)
        self.assertIn("#232A68", txt)
        self.assertIn("#EEF0FA", txt)
        self.assertIn("OSITO-FIREFLY-65", txt)
        self.assertIn("OSITO-TITAN-85", txt)

    def test_37_docx_manual_exists_and_nonempty(self):
        p = BASE_DIR / "Osito_Firefly65_and_Titan85_STEM_Fleet_Manual.docx"
        self.assertTrue(p.exists())
        self.assertGreater(p.stat().st_size, 15000)

    def test_38_firefly65_openscad_model_valid(self):
        p = BASE_DIR / "osito_firefly65_led_halo_shroud.scad"
        self.assertTrue(p.exists())
        txt = p.read_text(encoding="utf-8")
        self.assertIn("wheelbase_mm = 65.0", txt)
        self.assertIn("led_count = 36", txt)
        self.assertIn("ws2812b_2020_halo_channel", txt)

    def test_39_titan85_openscad_model_valid(self):
        p = BASE_DIR / "osito_titan85_heavy_lift_frame.scad"
        self.assertTrue(p.exists())
        txt = p.read_text(encoding="utf-8")
        self.assertIn("wheelbase_mm = 85.0", txt)
        self.assertIn("epm_magnetic_cargo_winch_bay", txt)

    def test_40_waypoints_json_and_svg_exported(self):
        j_path = BASE_DIR / "firefly65_sky_painter_waypoints.json"
        s_path = BASE_DIR / "firefly65_sky_painter_preview.svg"
        self.assertTrue(j_path.exists())
        self.assertTrue(s_path.exists())
        data = json.loads(j_path.read_text(encoding="utf-8"))
        self.assertEqual(len(data["sky_painter_patterns"]), 4)

    def test_41_zero_root_clutter_verified(self):
        self.assertIn("03_Hardware_and_Drones", str(BASE_DIR))


if __name__ == "__main__":
    suite = unittest.TestLoader().loadTestsFromTestCase(TestFireflyAndTitanFleet)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    print(f"\nTOTAL CHECKS EXECUTED: {result.testsRun} | FAILURES: {len(result.failures)} | ERRORS: {len(result.errors)}")
    sys.exit(0 if result.wasSuccessful() else 1)
