#!/usr/bin/env python3
"""
OSITO-FIREFLY-65 & OSITO-TITAN-85 Flight Choreographer, Telemetry Halo & Heavy-Lift Physics Engine
==================================================================================================
- Generates 8.0-second 2D/3D Long-Exposure Sky-Painter Waypoint Trajectories (SVG + JSON)
  for Star, DNA Helix, Golden Gate Tower, and School Initials ("OSITO").
- Computes real-time 36-LED WS2812B-2020 Visual PID & Physics Telemetry Halo colors.
- Models OSITO-TITAN-85 (49.2g dry, 142.0g thrust) heavy-lift payload dynamics,
  CG pendulum input-shaping filter, and Electro-Permanent Magnet (EPM) winch safety interlocks.
- Enforces Gate 3 Avionics Safety:
  * 16-bit unsigned millisecond rollover protection: `(now_ms - last_ms) & 0xFFFF`
  * Disarmed motor (1000us) & magnetic winch (1500us neutral / DE-ENERGIZED) interlock
  * Stage-2 Failsafe DROP <= 0.4s (400ms)
"""

import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

BASE_DIR = Path(__file__).resolve().parent

# ============================================================================
# 1. MASS & PROPULSION SPECIFICATIONS (GATE 1 & GATE 2 COMPLIANCE)
# ============================================================================

FIREFLY_65_SPEC = {
    "model": "OSITO-FIREFLY-65",
    "wheelbase_mm": 65.0,
    "core_fleet_reuse_pct": 82.5,
    "dry_mass_breakdown_g": {
        "matrix_1s_g473_fc_elrs_vtx": 3.6,
        "motors_0802_19500kv_x4": 7.6,
        "props_31mm_3blade_x4": 1.0,
        "translucent_tpu95a_diffuser_frame": 5.3,
        "mtf01_optical_flow_lidar": 1.5,
        "ws2812b_2020_36led_rgbic_halo": 2.4,
        "battery_1s_300mah_bt20_lihv": 8.2,
        "canopy_fasteners_lead_wires": 2.2,
    },
    "auw_g": 31.8,
    "youth_ceiling_g": 50.0,
    "peak_static_thrust_g": 81.4,
    "thrust_to_weight_ratio": round(81.4 / 31.8, 2),  # 2.56:1
    "led_count": 36,
    "sky_painter_duration_s": 8.0,
}

TITAN_85_SPEC = {
    "model": "OSITO-TITAN-85",
    "wheelbase_mm": 85.0,
    "core_fleet_reuse_pct": 78.0,
    "dry_mass_breakdown_g": {
        "osito_f411_12a_aio_fc": 4.8,
        "motors_1102_18000kv_x4": 14.8,
        "props_45mm_4blade_heavylift_x4": 2.4,
        "petg_cf_spine_tpu95a_ducts": 10.6,
        "mtf01_optical_flow_lidar": 1.5,
        "epm_belly_cargo_winch": 2.8,
        "battery_1s_450mah_bt20_lihv": 12.3,
    },
    "auw_g": 49.2,
    "youth_ceiling_g": 50.0,
    "peak_static_thrust_g": 142.0,
    "max_safe_payload_g": 22.0,
    "loaded_gross_mass_g": 71.2,
    "unloaded_twr": round(142.0 / 49.2, 2),  # 2.89:1
    "loaded_twr": round(142.0 / 71.2, 2),    # 2.00:1
    "tether_length_m": 0.22,
}

# ============================================================================
# 2. AVIONICS & FIRMWARE SAFETY ENGINE (GATE 3 COMPLIANCE)
# ============================================================================

STAGE2_FAILSAFE_MAX_MS = 400      # <= 0.4s Stage-2 DROP
DISARMED_MOTOR_PWM_US = 1000      # Strictly locked at 1000us when disarmed
DISARMED_WINCH_PWM_US = 1500      # Neutral 1500us pulse (no EPM switching when disarmed)
LVC_WARNING_VOLTS = 3.55          # Crimson pulse warning threshold


def elapsed_ms_u16(now_ms: int, last_ms: int) -> int:
    """
    Unsigned 16-bit millisecond rollover-safe elapsed time calculation.
    Matches C firmware `(uint16_t)(now_ms - last_ms)` across 65535 -> 0 wrap.
    """
    return (int(now_ms) - int(last_ms)) & 0xFFFF


def evaluate_safety_interlocks(
    armed: bool,
    now_ms: int,
    last_rx_ms: int,
    cmd_motor_us: int,
    cmd_winch_us: int,
    epm_latch_request: bool,
) -> Dict[str, object]:
    """
    Evaluates flight & winch safety interlocks for both FIREFLY-65 and TITAN-85.
    """
    rx_age_ms = elapsed_ms_u16(now_ms, last_rx_ms)
    failsafe_drop = rx_age_ms >= STAGE2_FAILSAFE_MAX_MS

    if (not armed) or failsafe_drop:
        return {
            "armed_output": False,
            "failsafe_drop": failsafe_drop,
            "rx_age_ms": rx_age_ms,
            "motor_pwm_us": DISARMED_MOTOR_PWM_US,
            "winch_pwm_us": DISARMED_WINCH_PWM_US,
            "epm_energized_pulse": False,
            "flight_mode": "FAILSAFE_DROP" if failsafe_drop else "DISARMED_LOCKED",
        }

    safe_motor_us = max(1000, min(2000, int(cmd_motor_us)))
    safe_winch_us = max(1000, min(2000, int(cmd_winch_us)))
    return {
        "armed_output": True,
        "failsafe_drop": False,
        "rx_age_ms": rx_age_ms,
        "motor_pwm_us": safe_motor_us,
        "winch_pwm_us": safe_winch_us,
        "epm_energized_pulse": bool(epm_latch_request),
        "flight_mode": "ACTIVE_STEM_ARENA",
    }


# ============================================================================
# 3. FIREFLY-65 VISUAL PID & PHYSICS TELEMETRY HALO ENGINE
# ============================================================================

TELEMETRY_PALETTE = {
    "LOCKED_HOVER": {"hex": "#7077CF", "rgb": (112, 119, 207), "label": "Periwinkle Indigo (Optical-Flow Hover Locked)"},
    "POSITIVE_CLIMB": {"hex": "#10B981", "rgb": (16, 185, 129), "label": "Emerald Green (Positive Climb Vz > +0.15 m/s)"},
    "HIGH_TILT_BANK": {"hex": "#F59E0B", "rgb": (245, 158, 11), "label": "Amber Gold (Pitch/Roll Angle > 15.0 deg)"},
    "BATTERY_LVC_PULSE": {"hex": "#EF4444", "rgb": (239, 68, 68), "label": "Crimson Pulse (Battery LVC < 3.55V Warning)"},
}


def compute_firefly_telemetry_halo(
    vbat_v: float,
    pitch_deg: float,
    roll_deg: float,
    vz_mps: float,
    pos_err_cm: float = 1.5,
) -> Dict[str, object]:
    """
    Maps real-time flight physics state to the 36-LED WS2812B-2020 halo ring.
    Priority order:
      1. Battery LVC (< 3.55V) -> Crimson Pulse (#EF4444)
      2. High Bank Angle (|pitch| > 15 deg or |roll| > 15 deg) -> Amber (#F59E0B)
      3. Positive Climb (vz > +0.15 m/s) -> Emerald (#10B981)
      4. Locked Hover -> Periwinkle Indigo (#7077CF)
    """
    tilt_deg = max(abs(pitch_deg), abs(roll_deg))
    if vbat_v < LVC_WARNING_VOLTS:
        mode = "BATTERY_LVC_PULSE"
    elif tilt_deg > 15.0:
        mode = "HIGH_TILT_BANK"
    elif vz_mps > 0.15:
        mode = "POSITIVE_CLIMB"
    else:
        mode = "LOCKED_HOVER"

    color_info = TELEMETRY_PALETTE[mode]
    return {
        "telemetry_state": mode,
        "hex_color": color_info["hex"],
        "rgb": color_info["rgb"],
        "description": color_info["label"],
        "led_ring_36": [color_info["hex"]] * 36,
        "max_tilt_deg": round(tilt_deg, 2),
        "pos_err_cm": round(pos_err_cm, 2),
    }


# ============================================================================
# 4. FIREFLY-65 8-SECOND LONG-EXPOSURE SKY-PAINTER CHOREOGRAPHER
# ============================================================================

def generate_sky_painter_pattern(pattern_name: str, num_points: int = 80) -> List[Dict[str, object]]:
    """
    Generates an 8.0-second 2D (X, Z) indoor trajectory in meters (width 2.0m, height 1.2m–2.4m)
    with synchronized RGBIC LED color gradients for tablet long-exposure light-painting.
    Supported patterns: 'Star', 'DNA_Helix', 'Golden_Gate_Tower', 'School_Initials'
    """
    waypoints = []
    duration_s = 8.0

    for i in range(num_points):
        u = i / float(num_points - 1)
        t_sec = round(u * duration_s, 3)

        if pattern_name == "Star":
            # 5-point geometric star order: 0 -> 2 -> 4 -> 1 -> 3 -> 0
            star_Order = [0, 2, 4, 1, 3, 0]
            seg = min(4, int(u * 5))
            local_u = (u * 5) - seg
            a1 = math.radians(90 + star_Order[seg] * 72)
            a2 = math.radians(90 + star_Order[seg + 1] * 72)
            r = 0.75
            x = (1 - local_u) * (r * math.cos(a1)) + local_u * (r * math.cos(a2))
            z = 1.65 + (1 - local_u) * (r * math.sin(a1)) + local_u * (r * math.sin(a2))
            color = "#7077CF" if seg % 2 == 0 else "#F59E0B"

        elif pattern_name == "DNA_Helix":
            # Double-helix sinusoidal trace across X=[-0.85, +0.85]
            x = -0.85 + 1.70 * u
            phase = u * 2.0 * math.pi * 2.0
            branch = 1 if (i % 2 == 0) else -1
            z = 1.65 + 0.45 * math.sin(phase) * branch
            color = "#7077CF" if branch == 1 else "#10B981"

        elif pattern_name == "Golden_Gate_Tower":
            # Iconic suspension tower silhouette + parabolic main cable
            if u < 0.35:
                # Left tower leg up & right tower leg down
                x = -0.45 if u < 0.175 else 0.45
                z = 1.10 + (u / 0.175) * 1.10 if u < 0.175 else 2.20 - ((u - 0.175) / 0.175) * 1.10
                color = "#EF4444"
            else:
                # Parabolic suspension catenary cable from left to right
                cu = (u - 0.35) / 0.65
                x = -0.90 + 1.80 * cu
                z = 1.35 + 0.80 * ((x / 0.90) ** 2)
                color = "#F59E0B"

        elif pattern_name == "School_Initials":
            # Traces "O-D" (Osito Drone STEM Academy emblem)
            if u < 0.5:
                ang = (u / 0.5) * 2.0 * math.pi
                x = -0.45 + 0.35 * math.cos(ang)
                z = 1.65 + 0.45 * math.sin(ang)
                color = "#7077CF"
            else:
                ang = -math.pi / 2 + ((u - 0.5) / 0.5) * math.pi
                x = 0.25 + 0.38 * math.cos(ang)
                z = 1.65 + 0.45 * math.sin(ang)
                color = "#10B981"
        else:
            raise ValueError(f"Unsupported pattern: {pattern_name}")

        waypoints.append({
            "step": i,
            "t_sec": t_sec,
            "x_m": round(x, 3),
            "y_m": 0.0,
            "z_m": round(z, 3),
            "led_hex": color,
        })

    return waypoints


def generate_4drone_gym_finale_schedule() -> Dict[str, object]:
    """
    Generates the 60-second 4-Drone Indoor Gymnasium Light-Show Finale formation schedule.
    """
    return {
        "show_title": "Osito Firefly-65 4-Drone Indoor Gymnasium Light-Show Finale",
        "duration_s": 60.0,
        "drones_count": 4,
        "safety_geofence_m": {"width_x": 4.0, "depth_y": 3.0, "ceiling_z": 2.8},
        "phases": [
            {"phase": 1, "t_start_s": 0.0, "t_end_s": 15.0, "formation": "Diamond Ascending Lift", "halo_theme": "#7077CF"},
            {"phase": 2, "t_start_s": 15.0, "t_end_s": 35.0, "formation": "Counter-Rotating Double DNA Vortex", "halo_theme": "#10B981"},
            {"phase": 3, "t_start_s": 35.0, "t_end_s": 50.0, "formation": "Golden Gate Span Wave Sync", "halo_theme": "#F59E0B"},
            {"phase": 4, "t_start_s": 50.0, "t_end_s": 60.0, "formation": "Synchronized Periwinkle Bow & Precision Autoland", "halo_theme": "#7077CF"},
        ],
    }


# ============================================================================
# 5. TITAN-85 HEAVY-LIFT LOGISTICS & PENDULUM DAMPING PHYSICS ENGINE
# ============================================================================

def compute_titan85_lift_and_pendulum_metrics(payload_mass_g: float) -> Dict[str, float]:
    """
    Computes loaded gross weight, thrust-to-weight ratio (TWR), hover throttle %,
    center-of-gravity vertical shift, and Zero-Vibration (ZV) input-shaper parameters
    to suppress cargo swing on the 0.22m magnetic winch line.
    """
    if payload_mass_g < 0.0 or payload_mass_g > TITAN_85_SPEC["max_safe_payload_g"]:
        raise ValueError(f"Payload {payload_mass_g}g exceeds TITAN-85 safe envelope (0..22.0g).")

    dry_mass_g = TITAN_85_SPEC["auw_g"]          # 49.2g
    max_thrust_g = TITAN_85_SPEC["peak_static_thrust_g"]  # 142.0g
    total_mass_g = round(dry_mass_g + payload_mass_g, 2)
    twr = round(max_thrust_g / total_mass_g, 2)
    hover_throttle_pct = round((total_mass_g / max_thrust_g) * 100.0, 1)

    # Natural pendulum period & ZV input-shaper impulse timing for L = 0.22m tether
    g = 9.80665
    tether_m = TITAN_85_SPEC["tether_length_m"]
    omega_n = math.sqrt((g / tether_m) * (total_mass_g / dry_mass_g))
    period_s = (2.0 * math.pi) / omega_n
    zv_impulse_delay_ms = round((period_s / 2.0) * 1000.0, 1)

    # CG shift along Z axis when docked directly to belly EPM (z_winch = -28mm)
    cg_z_shift_mm = round((-28.0 * payload_mass_g) / total_mass_g, 2)

    return {
        "dry_mass_g": dry_mass_g,
        "payload_mass_g": round(payload_mass_g, 2),
        "gross_mass_g": total_mass_g,
        "peak_thrust_g": max_thrust_g,
        "twr": twr,
        "hover_throttle_pct": hover_throttle_pct,
        "cg_z_shift_mm": cg_z_shift_mm,
        "pendulum_natural_freq_hz": round(omega_n / (2.0 * math.pi), 2),
        "zv_shaper_impulse_delay_ms": zv_impulse_delay_ms,
        "min_twr_compliant": twr >= 2.00,
    }


def export_sky_painter_artifacts() -> Tuple[Path, Path]:
    """
    Exports `firefly65_sky_painter_waypoints.json` and `firefly65_sky_painter_preview.svg`
    into the deliverable folder.
    """
    patterns = {
        name: generate_sky_painter_pattern(name)
        for name in ["Star", "DNA_Helix", "Golden_Gate_Tower", "School_Initials"]
    }
    payload = {
        "firefly65_spec": FIREFLY_65_SPEC,
        "titan85_spec": TITAN_85_SPEC,
        "sky_painter_patterns": patterns,
        "gym_finale_schedule": generate_4drone_gym_finale_schedule(),
    }
    json_path = BASE_DIR / "firefly65_sky_painter_waypoints.json"
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # Render SVG preview of the 4 patterns side by side
    svg_lines = [
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 260" width="100%" height="260">',
        '<rect width="960" height="260" rx="12" fill="#161616"/>',
    ]
    titles = ["Star (8.0s)", "DNA Helix (8.0s)", "Golden Gate Tower (8.0s)", "School Initials (8.0s)"]
    keys = ["Star", "DNA_Helix", "Golden_Gate_Tower", "School_Initials"]
    for idx, (key, title) in enumerate(zip(keys, titles)):
        ox = 120 + idx * 240
        oy = 215
        pts = patterns[key]
        poly_pts = []
        for p in pts:
            px = ox + p["x_m"] * 95.0
            py = oy - (p["z_m"] - 1.0) * 115.0
            poly_pts.append(f"{px:.1f},{py:.1f}")
        stroke_col = pts[0]["led_hex"]
        svg_lines.append(
            f'<polyline fill="none" stroke="{stroke_col}" stroke-width="3.5" stroke-linecap="round" points="{" ".join(poly_pts)}"/>'
        )
        svg_lines.append(
            f'<text x="{ox}" y="242" fill="#EEF0FA" font-family="Roboto, sans-serif" font-size="13" font-weight="bold" text-anchor="middle">{title}</text>'
        )
    svg_lines.append("</svg>")
    svg_path = BASE_DIR / "firefly65_sky_painter_preview.svg"
    svg_path.write_text("\n".join(svg_lines), encoding="utf-8")
    return json_path, svg_path


if __name__ == "__main__":
    j_path, s_path = export_sky_painter_artifacts()
    print(f"Exported waypoints JSON: {j_path.name}")
    print(f"Exported preview SVG:   {s_path.name}")
