#!/usr/bin/env python3
"""
OSITO-FIREFLY-65 & OSITO-TITAN-85 Automated Safety & Physics Verification Suite (41/41 Tests)
Wrapper entry point for `test_firefly_titan_fleet.py` so `test_*_safety.py` discovery matches cleanly.
"""

import unittest
from test_firefly_titan_fleet import TestFireflyAndTitanFleet

if __name__ == "__main__":
    unittest.main(verbosity=2)
