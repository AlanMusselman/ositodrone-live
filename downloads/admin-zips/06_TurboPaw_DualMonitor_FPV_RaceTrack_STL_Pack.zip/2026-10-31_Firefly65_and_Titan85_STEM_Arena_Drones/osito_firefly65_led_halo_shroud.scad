// ============================================================================
// OSITO-FIREFLY-65: 31.8g Indoor LED Light-Show & Visual Telemetry Halo Shroud
// Airframe: 65mm Ducted Micro-Whoop | 36-LED WS2812B-2020 Addressable RGBIC Ring
// Core Fleet Reuse: Matrix 1S G473 FC (25.5x25.5mm), 0802 19500KV, MTF-01 Sensor
// Material: Translucent Frosted White TPU 95A (Light-Diffusing Prop Guard Ring)
// ============================================================================

$fn = 72;

wheelbase_mm = 65.0;
duct_inner_r = 16.25;      // 31mm 3-blade prop + 0.75mm radial tip clearance
duct_wall_t = 1.15;
duct_height = 8.4;
led_count = 36;
halo_radius = 49.5;        // Outer perimeter halo ring radius
fc_mount_pitch = 25.5;     // Whoop 25.5x25.5mm standard

module motor_duct(cx, cy) {
    translate([cx, cy, 0]) {
        difference() {
            cylinder(r = duct_inner_r + duct_wall_t, h = duct_height, center = true);
            cylinder(r = duct_inner_r, h = duct_height + 1.0, center = true);
        }
        // 3 aerodynamic stator struts + motor mount boss (0802 3-hole 6.6mm circle)
        for (a = [0, 120, 240]) {
            rotate([0, 0, a])
                translate([0, -0.7, -duct_height/2])
                    cube([duct_inner_r, 1.4, 2.0]);
        }
        translate([0, 0, -duct_height/2 + 1.0])
            difference() {
                cylinder(r = 5.2, h = 2.0, center = true);
                cylinder(r = 1.6, h = 3.0, center = true);
            }
    }
}

module ws2812b_2020_halo_channel() {
    // 36-LED addressable RGBIC flexible PCB channel around perimeter diffuser
    difference() {
        cylinder(r = halo_radius + 1.4, h = 4.6, center = true);
        cylinder(r = halo_radius - 0.8, h = 5.2, center = true);
        // 36 optical collimator windows around 360 deg perimeter
        for (i = [0 : led_count - 1]) {
            rotate([0, 0, i * (360 / led_count)])
                translate([halo_radius, 0, 0])
                    cube([3.5, 2.2, 2.4], center = true);
        }
    }
}

module mtf01_nadir_bay() {
    // Center belly mount for MTF-01 Optical Flow + LiDAR module (1.5g)
    translate([0, 0, -duct_height/2 + 1.2])
        difference() {
            cube([18.0, 18.0, 2.4], center = true);
            cube([14.2, 10.2, 3.5], center = true);
        }
}

module firefly65_complete_frame() {
    offset_xy = (wheelbase_mm / 2.0) / sqrt(2.0);
    union() {
        motor_duct( offset_xy,  offset_xy);
        motor_duct(-offset_xy,  offset_xy);
        motor_duct(-offset_xy, -offset_xy);
        motor_duct( offset_xy, -offset_xy);
        ws2812b_2020_halo_channel();
        mtf01_nadir_bay();
    }
}

firefly65_complete_frame();
