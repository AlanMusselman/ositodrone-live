# OSITO TURBOPAW-64 ("Grand Prix Arcade") — Dual Large-Monitor FPV Racing Car & Track System

**Built around the In-House Osito Flight/Drive Controller (`OSITO-FC29-F411-12A-HB REV 1.1` / `ESP32-S3`) & `1S 550mAh BT2.0` Battery Ecosystem**

![OSITO TURBOPAW-64 OpenSCAD Preview](./cad/TURBOPAW64_OpenSCAD_Preview.png)

## Quick Navigation
- **[Interactive Dual-Monitor FPV Racing Simulator & 3D CAD Viewer (`TURBOPAW_Dual_Monitor_FPV_Race_Simulator.html`)](./TURBOPAW_Dual_Monitor_FPV_Race_Simulator.html)** — Open in any browser to see **both large $32\text{"}\text{–}55\text{"}$ Racer Monitors running live side-by-side**, plus the full 3D modular race track and driver stations below. Drive **Racer 1 (Red)** with `WASD` + `Left Shift` and **Racer 2 (Blue)** with `Arrow Keys` + `Space`, trigger the **5-Light Formula 1 Start Gantry**, or switch to **Exploded CAD Inspector Mode**.
- **[Engineering Blueprint, RF Isolation Plan & Commercial PRD (`TURBOPAW_FPV_RaceSystem_Blueprint_and_PRD.md`)](./TURBOPAW_FPV_RaceSystem_Blueprint_and_PRD.md)** — Full orthographic schematics, why "Hood + Fender" camera geometry makes big-screen FPV driving intuitive, $259\text{ MHz}$ (`R1 5658 MHz RHCP` vs. `R8 5917 MHz LHCP`) zero-interference video architecture, and `OSITO-FC29-F411-12A-HB` wiring.
- **[Bill of Materials, Sourcing & Unit Economics (`TURBOPAW_BOM_and_Sourcing.md` / `.csv`)](./TURBOPAW_BOM_and_Sourcing.md)** — `$63.35` per-car in-house build cost and `$915.99` turnkey 2-player Dual-Monitor Arena Kit (`$619.99` if using existing TVs/monitors).
- **[Parametric OpenSCAD CAD & 11 Compiled STL Files (`cad/`)](./cad/)** — Master OpenSCAD source [`cad/TURBOPAW64_Parametric_Master.scad`](./cad/TURBOPAW64_Parametric_Master.scad), batch compiler [`cad/generate_turbopaw64_stls.ps1`](./cad/generate_turbopaw64_stls.ps1), and all 10 individual printable parts + full assembly `.stl`.
- **[Onboard Torque-Vectoring & IR Lap Timing Firmware (`firmware/`)](./firmware/)** — [`firmware/turbopaw_esp32_race_controller.ino`](./firmware/turbopaw_esp32_race_controller.ino) and [`firmware/TURBOPAW64_Betaflight_OsitoFC_Rover_CLI.txt`](./firmware/TURBOPAW64_Betaflight_OsitoFC_Rover_CLI.txt).
