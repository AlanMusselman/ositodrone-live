# OSITO TURBOPAW-64 — Bill of Materials, Sourcing & Commercial Unit Economics

## 1. Per-Car Hardware Cost Breakdown (`$62.05` In-House Build Cost)

Each **`TURBOPAW-64`** FPV Race Car costs only **`$62.05`** to build in-house on your Bambu Lab P1S and shares the exact same **`1S 550mAh BT2.0` batteries** and **`OSITO-FC29-F411-12A-HB`** electronics ecosystem as the `KODIAK-75` and `GRIZZLY-85`:

| Code | Component | Spec / Role | Qty / Car | Unit Cost | Extended |
| :--- | :--- | :--- | :---: | :---: | :---: |
| `CAR-01` | `OSITO-FC29-F411-12A-HB REV 1.1` (or ESP32-S3 + Dual H-Bridge + ELRS) | 1S Bidirectional H-Bridge + $5.0\text{V}/2.0\text{A}$ Buck-Boost BEC + 2.4GHz ELRS RX | 1 | $\$14.80$ | $\$14.80$ |
| `CAR-02` | `N20` Micro Metal Gearmotors (`1200 RPM` at $5.0\text{V}$) | Left & Right independent rear drive + electronic torque vectoring | 2 | $\$2.90$ | $\$5.80$ |
| `CAR-03` | `GH-S37D` $2.0\text{g}$ Sub-Micro Digital Servo | Front Ackermann steering actuator ($333\text{ Hz}$) | 1 | $\$4.20$ | $\$4.20$ |
| `CAR-04` | `MR63ZZ` Precision Ball Bearings ($3 \times 6 \times 2.5\text{ mm}$) | Rear axle & front kingpin bearings | 6 | $\$0.25$ | $\$1.50$ |
| `CAR-05` | $38\text{ kHz}$ $940\text{ nm}$ IR Lap Transponder Emitter LED | Pulses unique Car ID (`0xA1` / `0xB2`) downward into finish line | 1 | $\$0.45$ | $\$0.45$ |
| `FPV-01` | `RunCam Nano 4` / `Caddx Ant` $150^\circ$ Wide-Angle FPV Camera | Mounted at `Y=+8.5mm, Z=+20.5mm` for Hood + Fender monitor view | 1 | $\$16.90$ | $\$16.90$ |
| `FPV-02` | `25mW–200mW` $5.8\text{ GHz}$ OpenVTX Nano Video Transmitter | Locked to `R1 (5658 MHz)` for Car 1 and `R8 (5917 MHz)` for Car 2 | 1 | $\$12.50$ | $\$12.50$ |
| `FPV-03` | $5.8\text{ GHz}$ Circular Polarized Micro Antenna (`RHCP` or `LHCP`) | Cross-polarized between Car 1 and Car 2 for zero video crosstalk | 1 | $\$4.80$ | $\$4.80$ |
| `CAD-01` | 3D-Printed `TURBOPAW-64` Chassis, GT Shell, Rims, TPU Slicks & Bumper | `Parts 1–6` printed in-house (`36.3g` total filament) | 1 set | $\$2.40$ | $\$2.40$ |
| **—** | **TOTAL PER-CAR IN-HOUSE BUILD COST** | **Ready-to-Race FPV Car (excluding swappable 1S battery)** | **1 Car** | — | **`$63.35`** |

---

## 2. Complete Turnkey 2-Player Dual-Monitor Arena Kit BOM (`$915.99` Total)

| Subsystem | Items Included | Cost (USD) | Notes |
| :--- | :--- | :---: | :--- |
| **2x `TURBOPAW-64` FPV Race Cars** | Car 1 (Red `R1 5658MHz RHCP`) + Car 2 (Blue `R8 5917MHz LHCP`) | $\$126.70$ | 100% 3D-printed modular spares in `cad/` |
| **Power & Charging Fleet** | `6x` BetaFPV Lava `1S 550mAh` Packs + `VIFLY WhoopStor V3` Charger | $\$60.89$ | Each pack runs **35–45 mins** in a ground car! |
| **2x Large $43\text{"}$ 120Hz Gaming Monitors + VRX Docks** | `2x` $43\text{"}$ 1080p Low-Latency Screens + `2x` 5.8GHz Diversity VRX + HDMI Scalers + Patch/Omni Antennas + `Part 10` Monitor-Top Clips | $\$404.00$ | Or **$\$108.00$** if using two monitors/TVs you already own! |
| **2x Driver Control Stations** | `2x` Radiomaster MT12 ELRS 2.4GHz Pistol-Grip Radios *(or 2x USB Sim Steering Wheels + ESP32 ELRS Bridge)* | $\$258.00$ | Instant 250Hz response + Overboost button |
| **Modular Grand Prix Track & IR Lap Gantry** | $8\text{ ft} \times 4\text{ ft}$ Roll-Up EVA Track Mat + 32x `Part 7` Barriers + 10x `Part 8` Apex Curbs + `Part 9` Start/Finish Gantry + ESP32-S3 Timer | $\$66.40$ | Sets up on any standard folding table in 10 minutes |
| **COMPLETE TURNKEY 2-PLAYER SYSTEM** | **Everything needed for paid events (including 2 new 43" TVs)** | **`$915.99`** | **Only `$619.99` if using existing TVs/Monitors!** |

---

## 3. Event Payback & ROI Calculator

- **Single Corporate Holiday / Friendsgiving Booking (`2 Hours`):** **`$1,200 – $1,500`** $\rightarrow$ **Pays off 100% of the entire Dual-Monitor FPV Racing System in a single 2-hour event!**
- **Brewery Taproom Pay-Per-Race Night (`$10/racer` = `$20 per 3-minute 5-lap duel`):** At 8–10 races per hour (`$160–$200/hr`), a single Friday evening taproom pop-up generates **`$640–$800`** with zero safety net cage required.
- **Retail / STEM School Kit Price:** Build cost `$63.35/car` $\rightarrow$ Retail **`$179.00/car`** (**`64.6%` gross margin**) or **`$1,995.00`** for a turnkey 2-Car School STEM Robotics Track Lab.
