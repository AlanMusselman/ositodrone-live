// ============================================================================
// OSITO TURBOPAW-64: Dual-Monitor FPV Racing Car & Modular Track System
// 1:64 / 1:43 Tabletop & Portable Fold-Up FPV Race Car + Dual Sim Rig Pod +
// IR Lap Timing Arch & Modular Interlocking Track System
// Built Around OSITO-DRV29-F411-12A-HB (or ESP32-S3 + Dual H-Bridge + 5.8GHz/HDZero VTX)
// ============================================================================
// PART_ID Selector:
//   0 = Full Prototype Assembly (Race Car + Cockpit Sim Rig + Timing Arch)
//   1 = TURBOPAW64_Chassis_Main_Deck.stl (PETG-CF / PA12-CF Race Car Chassis w/ Suspension)
//   2 = TURBOPAW64_Aero_Body_Shell_OsitoGT.stl (PLA+ / PETG Aero GT Shell w/ Bear Ears & Wing)
//   3 = TURBOPAW64_FPV_Cockpit_Turret_Mount.stl (TPU 95A Vibration-Isolated Camera + VTX Pod)
//   4 = TURBOPAW64_Wheel_Rim_18mm_Set4.stl (PETG-CF / PLA+ 6-Spoke Racing Rims, Set of 4)
//   5 = TURBOPAW64_Slick_Tire_TPU_Set4.stl (TPU 85A/95A High-Grip Racing Slicks, Set of 4)
//   6 = TURBOPAW64_360_Spring_Bumper_Ring.stl (TPU 95A Crash-Proof Arcade Perimeter Bumper)
//   7 = TURBOPAW64_Track_Barrier_Interlock_Straight.stl (Modular Snap-Lock Guardrail Barrier)
//   8 = TURBOPAW64_Track_Apex_Curb_90Deg.stl (Modular 90-Deg Rumble Strip & Wall Corner)
//   9 = TURBOPAW64_StartFinish_IR_Timing_Gantry.stl (Start/Finish Arch w/ IR Lap Sensor & LEDs)
//  10 = TURBOPAW64_Monitor_Top_VRX_Dock_Bracket.stl (VESA / Monitor-Top 5.8GHz Receiver & Antenna Mount)
// ============================================================================

PART_ID = 0;
$fn = 64;

// --- Core Race Car Parametric Constants (mm) ---
car_wheelbase = 64.0;      // 64mm wheelbase (Agile 1:43 / Oversized 1:64 Arcade Scale)
car_track_w   = 48.0;      // 48mm outer track width
car_length    = 98.0;      // 98mm overall length with splitter & rear diffuser
car_width     = 52.0;      // 52mm overall width over fenders
wheel_od      = 20.0;      // 20mm outer tire diameter
rim_od        = 15.6;      // 15.6mm wheel rim diameter
wheel_w       = 8.5;       // 8.5mm wide racing slicks

// Osito Drive & Avionics Stack (25.5x25.5mm Whoop/Rover Mount Pattern)
fc_mount_span = 25.5;
fc_hole_r     = fc_mount_span / 2.0;

// --- Helper Modules ---
module wheel_positions() {
    for (sx = [-1, 1]) {
        for (sy = [-1, 1]) {
            translate([sx * (car_track_w/2 - wheel_w/2), sy * (car_wheelbase/2), wheel_od/2])
                rotate([0, sx * 90, 0])
                    children();
        }
    }
}

module fc_mount_holes() {
    for (sx = [-1, 1])
        for (sy = [-1, 1])
            translate([sx * fc_hole_r, sy * fc_hole_r, 0])
                children();
}

// ============================================================================
// PART 1: TURBOPAW-64 Main Chassis Deck (with Flexure Front Suspension & N20/1102 Drive Bay)
// ============================================================================
module part1_chassis_deck() {
    difference() {
        union() {
            // Main flat bottom pan (Z = 3.0 to 5.5mm -> 3mm ground clearance)
            translate([0, 0, 4.25])
                cube([32.0, car_wheelbase + 22.0, 2.5], center = true);

            // Front splitter & lower crash nose
            translate([0, car_wheelbase/2 + 12.0, 4.25])
                cylinder(d = 32.0, h = 2.5, center = true);

            // Rear diffuser ramp
            translate([0, -car_wheelbase/2 - 11.0, 4.75])
                cube([34.0, 10.0, 3.5], center = true);

            // Side battery & electronics stiffening rails
            for (sx = [-1, 1]) {
                translate([sx * 15.0, 0, 7.5])
                    cube([2.4, 46.0, 6.5], center = true);
            }

            // Rear Dual Micro-Gearmotor / Brushless Pod Mounts (Left & Right Independent Rear Drive)
            for (sx = [-1, 1]) {
                translate([sx * 10.5, -car_wheelbase/2, 10.0]) {
                    cube([13.0, 14.0, 12.0], center = true);
                }
            }

            // Front Micro-Servo Ackermann Steering Cradle (2.0g GH-S37D / 4.3g Digital Servo)
            translate([0, car_wheelbase/2 - 2.0, 9.5])
                cube([22.0, 14.0, 9.0], center = true);

            // Front Kingpin Steering Knuckle Bosses
            for (sx = [-1, 1]) {
                translate([sx * (car_track_w/2 - wheel_w - 1.5), car_wheelbase/2, 10.0])
                    cylinder(d = 6.5, h = 10.0, center = true);
            }

            // 4x M2 Standoffs for Osito FC/Drive Board (25.5x25.5mm)
            translate([0, -2.0, 5.5])
                fc_mount_holes()
                    cylinder(d = 4.8, h = 6.5);

            // Magnetic Body Shell Post Mounts (Front & Rear N52 Magnet Towers)
            for (sy = [-car_wheelbase/2 - 6.0, car_wheelbase/2 + 6.0]) {
                for (sx = [-9.0, 9.0]) {
                    translate([sx, sy, 5.5])
                        cylinder(d = 5.4, h = 11.0);
                }
            }
        }

        // Rear axle bearing tunnels (MR63ZZ 3x6x2.5mm bearings)
        translate([0, -car_wheelbase/2, 10.0])
            rotate([0, 90, 0])
                cylinder(d = 6.1, h = car_track_w + 4.0, center = true);

        // Front kingpin M2 pivot holes
        for (sx = [-1, 1]) {
            translate([sx * (car_track_w/2 - wheel_w - 1.5), car_wheelbase/2, 10.0])
                cylinder(d = 2.05, h = 14.0, center = true);
        }

        // Servo pocket cutout
        translate([0, car_wheelbase/2 - 2.0, 10.5])
            cube([16.6, 8.6, 9.0], center = true);

        // Osito FC M2 screw holes
        translate([0, -2.0, 2.0])
            fc_mount_holes()
                cylinder(d = 1.9, h = 12.0);

        // Downward IR Lap Transponder / Optical Sensor Window
        translate([0, 10.0, 4.0])
            cylinder(d = 8.0, h = 6.0, center = true);

        // N52 Magnet pockets on body towers (3x2mm magnets)
        for (sy = [-car_wheelbase/2 - 6.0, car_wheelbase/2 + 6.0]) {
            for (sx = [-9.0, 9.0]) {
                translate([sx, sy, 15.0])
                    cylinder(d = 3.2, h = 2.2);
            }
        }
    }
}

// ============================================================================
// PART 2: Aero GT Body Shell ("Osito GT-R" with Hood View & Rear Swan-Neck Wing)
// ============================================================================
module part2_aero_body_shell() {
    difference() {
        union() {
            // Sculpted Le Mans / GT3 Lower Body Hull
            hull() {
                // Low aerodynamic nose hood
                translate([0, car_wheelbase/2 + 11.0, 10.5])
                    scale([1.0, 0.6, 0.35])
                        sphere(d = 44.0);
                // Wide mid-fender stance
                translate([0, 0, 14.0])
                    cube([car_width - 2.0, car_wheelbase - 8.0, 12.0], center = true);
                // Rear GT deck
                translate([0, -car_wheelbase/2 - 8.0, 13.5])
                    cube([car_width - 6.0, 12.0, 10.0], center = true);
            }

            // Flared Front & Rear Wheel Arch Louvers
            for (sx = [-1, 1]) {
                for (sy = [-1, 1]) {
                    translate([sx * (car_width/2 - 5.0), sy * (car_wheelbase/2), 12.5])
                        scale([0.55, 1.15, 0.9])
                            sphere(d = 24.0);
                }
            }

            // Cockpit Canopy Dome surrounding the FPV Camera
            hull() {
                translate([0, 8.0, 19.0])
                    scale([1.0, 1.3, 0.7])
                        sphere(d = 26.0);
                translate([0, -14.0, 18.0])
                    scale([0.85, 1.0, 0.6])
                        sphere(d = 22.0);
            }

            // Signature Osito Racing Bear Ears on Roof Canopy
            for (sx = [-1, 1]) {
                translate([sx * 9.5, -2.0, 26.5])
                    rotate([12, sx * 18, 0])
                        scale([1.0, 0.55, 1.1])
                            sphere(d = 8.5);
            }

            // Swan-Neck GT3 Rear Wing Uprights & High-Downforce Wing Element
            for (sx = [-11.0, 11.0]) {
                translate([sx, -car_wheelbase/2 - 8.0, 22.0])
                    rotate([18, 0, 0])
                        cube([2.2, 8.0, 14.0], center = true);
            }
            // Main Rear Wing Foil + Endplates
            translate([0, -car_wheelbase/2 - 11.5, 28.5]) {
                rotate([-12, 0, 0])
                    cube([car_width, 11.0, 2.2], center = true);
                for (sx = [-1, 1])
                    translate([sx * (car_width/2 - 1.0), 0, -1.0])
                        cube([2.0, 14.0, 8.5], center = true);
            }
        }

        // Hollow inner shell cavity (2.0mm wall thickness)
        translate([0, 0, -2.2])
            scale([0.91, 0.94, 0.88])
                hull() {
                    translate([0, car_wheelbase/2 + 11.0, 10.5])
                        scale([1.0, 0.6, 0.35])
                            sphere(d = 44.0);
                    translate([0, 0, 14.0])
                        cube([car_width - 2.0, car_wheelbase - 8.0, 12.0], center = true);
                    translate([0, -car_wheelbase/2 - 8.0, 13.5])
                        cube([car_width - 6.0, 12.0, 10.0], center = true);
                }

        // Wheel Well Arch Cutouts (Clears 20mm OD tires + steering sweep)
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * (car_track_w/2 - wheel_w/2), sy * (car_wheelbase/2), 10.0])
                    rotate([0, 90, 0])
                        cylinder(d = wheel_od + 4.5, h = wheel_w + 6.0, center = true);
            }
        }

        // FPV Windshield Cutout for Zero-Obstruction 150-Deg Wide-Angle Camera View
        // Gives the racer on the big monitor a true "Cockpit + Front Hood + Fender" view!
        translate([0, 16.0, 21.5])
            rotate([-8, 0, 0])
                cube([18.0, 22.0, 10.0], center = true);

        // Rear VTX Cooling Louvers
        for (ly = [-18, -22, -26]) {
            translate([0, ly, 23.0])
                cube([14.0, 2.2, 8.0], center = true);
        }

        // Trim flat bottom below Z = 7.5mm
        translate([0, 0, -10.0])
            cube([120, 160, 35.0], center = true);
    }
}

// ============================================================================
// PART 3: Vibration-Isolated FPV Cockpit Camera & VTX Pod (TPU 95A)
// ============================================================================
module part3_fpv_cockpit_mount() {
    difference() {
        union() {
            // Base plate matching 25.5x25.5mm Osito stack
            translate([0, -2.0, 12.8])
                cube([29.5, 29.5, 2.0], center = true);

            // 14x14mm / 10x10mm Nano FPV Camera Gimbal Cage at Y = +8mm, Z = 21mm
            // Positioned so camera sees the front hood & left/right fenders on the big monitor!
            translate([0, 8.0, 19.5]) {
                cube([17.6, 12.0, 14.0], center = true);
            }

            // Rear dipole / whip 5.8GHz antenna protector tube
            translate([0, -15.0, 18.0])
                rotate([-25, 0, 0])
                    cylinder(d = 5.5, h = 16.0);
        }

        // 14.2mm Nano Camera cavity & lens barrel opening
        translate([0, 8.5, 20.5]) {
            cube([14.3, 14.0, 14.3], center = true);
            // M2 side tilt adjustment slots
            rotate([0, 90, 0])
                cylinder(d = 2.1, h = 22.0, center = true);
        }

        // Antenna inner routing hole
        translate([0, -15.0, 17.0])
            rotate([-25, 0, 0])
                cylinder(d = 2.8, h = 20.0);

        // 25.5x25.5mm M2 mounting holes
        translate([0, -2.0, 10.0])
            fc_mount_holes()
                cylinder(d = 2.1, h = 6.0);
    }
}

// ============================================================================
// PART 4: 6-Spoke Racing Wheel Rim (Print Set of 4)
// ============================================================================
module single_wheel_rim() {
    difference() {
        union() {
            // Outer rim barrel with tire bead retention lip
            cylinder(d = rim_od, h = wheel_w, center = true);
            translate([0, 0, wheel_w/2 - 0.8])
                cylinder(d = rim_od + 0.8, h = 1.6, center = true);
            translate([0, 0, -wheel_w/2 + 0.8])
                cylinder(d = rim_od + 0.8, h = 1.6, center = true);

            // Central axle hub
            cylinder(d = 6.5, h = wheel_w, center = true);

            // 6 Racing Spokes
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    cube([rim_od - 1.0, 1.8, 2.5], center = true);
            }
        }
        // Outer deep-dish recess
        translate([0, 0, 1.8])
            cylinder(d = rim_od - 2.4, h = wheel_w, center = true);
        // 3.0mm D-shaft / M2 axle bore
        cylinder(d = 3.0, h = wheel_w + 4.0, center = true);
    }
}

module part4_wheel_rim_set4() {
    for (ix = [-1, 1])
        for (iy = [-1, 1])
            translate([ix * 12.0, iy * 12.0, wheel_w/2])
                single_wheel_rim();
}

// ============================================================================
// PART 5: TPU 85A/95A High-Grip Racing Slick Tires (Print Set of 4)
// ============================================================================
module single_slick_tire() {
    difference() {
        // Rounded racing slick profile with micro-grooves
        union() {
            cylinder(d = wheel_od, h = wheel_w - 1.2, center = true);
            for (sz = [-1, 1])
                translate([0, 0, sz * (wheel_w/2 - 0.6)])
                    cylinder(d1 = (sz < 0 ? wheel_od - 1.2 : wheel_od),
                             d2 = (sz > 0 ? wheel_od - 1.2 : wheel_od),
                             h = 1.2, center = true);
        }
        // Inner bore to slip over Part 4 rim
        cylinder(d = rim_od + 0.15, h = wheel_w + 2.0, center = true);
        // Semi-slick circumferential rain groove
        difference() {
            cylinder(d = wheel_od + 0.5, h = 1.2, center = true);
            cylinder(d = wheel_od - 0.8, h = 2.0, center = true);
        }
    }
}

module part5_slick_tire_set4() {
    for (ix = [-1, 1])
        for (iy = [-1, 1])
            translate([ix * 14.0, iy * 14.0, wheel_od/2])
                single_slick_tire();
}

// ============================================================================
// PART 6: 360-Degree Arcade Bumper Ring (TPU 95A — Enables Rubbing-Is-Racing!)
// ============================================================================
module part6_bumper_ring() {
    difference() {
        union() {
            // Outer oval impact absorber hoop
            hull() {
                for (sy = [-car_wheelbase/2 - 11.0, car_wheelbase/2 + 12.0])
                    translate([0, sy, 6.5])
                        cylinder(d = car_width + 6.0, h = 5.0, center = true);
            }
        }
        // Inner cutout leaving a 3.0mm flexible TPU perimeter ring + flex struts
        hull() {
            for (sy = [-car_wheelbase/2 - 8.0, car_wheelbase/2 + 9.0])
                translate([0, sy, 6.5])
                    cylinder(d = car_width, h = 8.0, center = true);
        }
    }
}

// ============================================================================
// PART 7: Modular Interlocking Track Barrier Straight (180mm Snap-Lock Guardrail)
// ============================================================================
module part7_track_barrier_straight() {
    barrier_len = 160.0;
    difference() {
        union() {
            // Wide stable base foot + angled TecPro-style barrier wall
            translate([0, 0, 1.5])
                cube([24.0, barrier_len, 3.0], center = true);
            translate([0, 0, 14.0])
                cube([10.0, barrier_len, 25.0], center = true);
            // Male puzzle-tail connector at +Y end
            translate([0, barrier_len/2 + 6.0, 12.5]) {
                cylinder(d = 8.5, h = 25.0, center = true);
                translate([0, -3.5, 0])
                    cube([5.0, 7.0, 25.0], center = true);
            }
        }
        // Female puzzle-socket cutout at -Y end
        translate([0, -barrier_len/2 + 6.0, 12.5]) {
            cylinder(d = 9.0, h = 28.0, center = true);
            translate([0, -3.5, 0])
                cube([5.5, 8.0, 28.0], center = true);
        }
        // Weight-saving & LED strip channel along top
        translate([0, 0, 25.0])
            cube([5.2, barrier_len + 20.0, 4.0], center = true);
    }
}

// ============================================================================
// PART 8: Modular 90-Degree Apex Rumble Curb & Corner Wall
// ============================================================================
module part8_track_apex_curb() {
    curb_r = 90.0;
    rotate_extrude(angle = 90, $fn = 72) {
        translate([curb_r, 0, 0])
            polygon(points = [
                [0, 0],
                [38, 0],
                [38, 24],
                [28, 24],
                [28, 6],
                [0, 2.0]  // Angled FIA Red/White Apex Rumble Strip
            ]);
    }
}

// ============================================================================
// PART 9: Start/Finish IR Lap Timing Gantry Arch (Holds IR Emitter + WS2812B LEDs)
// ============================================================================
module part9_timing_gantry_arch() {
    span_w = 220.0; // Wide enough for 2-to-3 lanes side-by-side!
    arch_h = 95.0;
    union() {
        // Left & Right Gantry Towers
        for (sx = [-1, 1]) {
            translate([sx * (span_w/2), 0, 0]) {
                // Tower base foot
                translate([0, 0, 2.0])
                    cube([32.0, 48.0, 4.0], center = true);
                // Vertical truss column
                translate([0, 0, arch_h/2])
                    cube([16.0, 22.0, arch_h], center = true);
            }
        }
        // Overhead Start/Finish Bridge Beam with IR Emitter bays & 5-Light F1 Tree
        difference() {
            translate([0, 0, arch_h + 9.0])
                cube([span_w + 20.0, 24.0, 18.0], center = true);
            // 5x F1 Starting Light Bezel Holes on front face
            for (lx = [-60, -30, 0, 30, 60]) {
                translate([lx, 8.0, arch_h + 9.0])
                    rotate([90, 0, 0])
                        cylinder(d = 10.0, h = 12.0, center = true);
            }
            // Downward 38kHz IR Lap Curtain Emitter Slots
            for (ix = [-70, -35, 0, 35, 70]) {
                translate([ix, 0, arch_h])
                    cylinder(d = 5.4, h = 12.0, center = true);
            }
        }
    }
}

// ============================================================================
// PART 10: Monitor-Top 5.8GHz / HDZero VRX Receiver & Patch Antenna Clip Bracket
// (Clips onto top bezel of each Racer's 27"-55" Large Monitor!)
// ============================================================================
module part10_monitor_vrx_bracket() {
    difference() {
        union() {
            // Monitor bezel saddle clip (fits 12mm-28mm monitor top edge)
            cube([74.0, 42.0, 6.0], center = true);
            // Front bezel lip
            translate([0, 18.0, -8.0])
                cube([74.0, 6.0, 18.0], center = true);
            // Rear counter-support arm
            translate([0, -18.0, -14.0])
                rotate([20, 0, 0])
                    cube([74.0, 6.0, 30.0], center = true);
            // Upper VRX Cradle Box (Holds 5.8GHz HDMI/USB Receiver + Dual SMA Antennas)
            translate([0, 0, 14.0])
                cube([74.0, 38.0, 22.0], center = true);
        }
        // Inner VRX receiver bay pocket
        translate([0, 2.0, 16.0])
            cube([68.0, 34.0, 22.0], center = true);
        // Dual SMA antenna bulkhead holes on top
        for (ax = [-22.0, 22.0])
            translate([ax, -15.0, 16.0])
                rotate([90, 0, 0])
                    cylinder(d = 6.5, h = 12.0, center = true);
    }
}

// ============================================================================
// FULL PROTOTYPE ASSEMBLY SCENE (PART_ID = 0)
// Shows Car 1 (Red) & Car 2 (Blue) Racing Under the IR Timing Gantry!
// ============================================================================
module complete_race_car(body_col = [0.92, 0.18, 0.15]) {
    color([0.22, 0.24, 0.27]) part1_chassis_deck();
    color(body_col)           part2_aero_body_shell();
    color([0.15, 0.80, 0.90]) part3_fpv_cockpit_mount();
    color([0.18, 0.18, 0.20]) part6_bumper_ring();
    wheel_positions() {
        color([0.88, 0.72, 0.18]) single_wheel_rim();
        color([0.12, 0.12, 0.14]) single_slick_tire();
    }
}

if (PART_ID == 0) {
    // Racer 1 (Player 1 Red Osito GT-R)
    translate([-42.0, 10.0, 0])
        complete_race_car([0.92, 0.18, 0.15]);

    // Racer 2 (Player 2 Blue Osito GT-R)
    translate([42.0, -12.0, 0])
        complete_race_car([0.12, 0.48, 0.95]);

    // Start/Finish IR Lap Timing Gantry Arch
    color([0.20, 0.22, 0.26])
        translate([0, 35.0, 0])
            part9_timing_gantry_arch();

    // Left & Right Interlocking Track Guardrails
    color([0.92, 0.35, 0.10])
        translate([-135.0, 0, 0])
            part7_track_barrier_straight();
    color([0.95, 0.95, 0.98])
        translate([135.0, 0, 0])
            part7_track_barrier_straight();
}
else if (PART_ID == 1)  { part1_chassis_deck(); }
else if (PART_ID == 2)  { part2_aero_body_shell(); }
else if (PART_ID == 3)  { part3_fpv_cockpit_mount(); }
else if (PART_ID == 4)  { part4_wheel_rim_set4(); }
else if (PART_ID == 5)  { part5_slick_tire_set4(); }
else if (PART_ID == 6)  { part6_bumper_ring(); }
else if (PART_ID == 7)  { part7_track_barrier_straight(); }
else if (PART_ID == 8)  { part8_track_apex_curb(); }
else if (PART_ID == 9)  { part9_timing_gantry_arch(); }
else if (PART_ID == 10) { part10_monitor_vrx_bracket(); }
