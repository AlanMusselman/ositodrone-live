# REPORT - Track 3: Complete STEM Academy Curriculum Pack v2 (CUB-75, 10 sessions)

Folder: `01_Sales_and_STEM_Academy/2026-10-31_Complete_Academy_Curriculum_Pack_v2/`

## What I audited (read-only, nothing modified)
8Week_Curriculum_and_Pilot_Certificates (builder + 3 docs), AeroCub_K5 (3 docs), 4_Station_Rotation, Academy_2_0, Turnkey_Demo_and_Compliance (builder + 3 docs), Academia_de_Drones Espanol kit, Adaptive_Sensory kit, plus the ELOP/DCYF grant kit, legacy Participant Safety Waiver and Academy One-Pager.
**Gap found:** nothing existed that was a multi-session CUB-75 sequence with per-lesson objectives, standards strands, safety checks, assessment/exit tickets, a student workbook, a coach card, a rule-to-session TRUST/waiver map, or a fill-in grant template. The 8-week manual was FPV-heavy and had no per-lesson assessment.

## What I built (each as .docx with logo in the page header + HTML print view)
| # | Deliverable | DOCX | HTML |
|---|---|---|---|
| 1 | Coach Curriculum Binder (scope and sequence, 10 lesson plans, assessment + answer key, standards matrix, equipment, **Spanish summary page**, [VERIFY] register, source map) | [docx](./01_Osito_CUB75_Coach_Curriculum_Binder_10_Sessions.docx) | [html](./01_Osito_CUB75_Coach_Curriculum_Binder_10_Sessions.html) |
| 2 | Student Workbook (passport, pledge EN/ES, rank tracker, Pre/Post Check, 10 session pages, anatomy, graph page, EN/ES glossary) | [docx](./02_Osito_CUB75_Student_Workbook.docx) | [html](./02_Osito_CUB75_Student_Workbook.html) |
| 3 | Coach Quick-Start Card (2 pages) | [docx](./03_Osito_CUB75_Coach_Quick_Start_Card.docx) | [html](./03_Osito_CUB75_Coach_Quick_Start_Card.html) |
| 4 | Parent Handout, English + Spanish | [docx](./04_Osito_CUB75_Parent_Handout_EN_ES.docx) | [html](./04_Osito_CUB75_Parent_Handout_EN_ES.html) |
| 5 | FAA TRUST + Waiver Cross-Reference Packet (rule-to-session map, pre-cohort gate, roster, incident log) | [docx](./05_Osito_FAA_TRUST_and_Waiver_Crossreference_Packet.docx) | [html](./05_Osito_FAA_TRUST_and_Waiver_Crossreference_Packet.html) |
| 6 | Grant-Pitch One-Pager Template (+ fill-in guide page) | [docx](./06_Osito_Grant_Pitch_OnePager_Template.docx) | [html](./06_Osito_Grant_Pitch_OnePager_Template.html) |

Index: [index.html](./index.html)

Design: 10 sessions x 90 min = 15 instructional hours (matches the ELOP kit TIER-4 "10-Week Expanded Learning Deep-Dive"); 16-20 students; 4-station rotation (10 briefing + 4 x 17 + 12 debrief); CUB-75 39.5 g only (SHARD-75 FPV optional, site-gated); Rank 1-4 system and 100-pt Checkride reused from the 8-week kit so the existing certificates can be reused.

Builder scripts (all in `06_Scripts_and_Automation/`):
- [build_complete_academy_curriculum_pack_v2.py](../../06_Scripts_and_Automation/build_complete_academy_curriculum_pack_v2.py) - document definitions + build
- [academy_curriculum_v2_sessions.py](../../06_Scripts_and_Automation/academy_curriculum_v2_sessions.py) - session data (single source of truth)
- [osito_docpack_framework.py](../../06_Scripts_and_Automation/osito_docpack_framework.py) - reusable DOCX + HTML renderer (brand tokens and XML helpers ported from the 8-Week builder, with OOXML child-order fixes)
- [verify_academy_curriculum_pack_v2.py](../../06_Scripts_and_Automation/verify_academy_curriculum_pack_v2.py) - QA

## What I verified (`python 06_Scripts_and_Automation/verify_academy_curriculum_pack_v2.py` -> 129 PASS, 0 FAIL)
- All 6 DOCX reload in python-docx; logo image in page header; Fjalla One + Roboto present; PAGE/NUMPAGES footer; OOXML property child order valid.
- All 6 HTML parse with balanced tags; embedded logo, brand tokens and fonts present; [VERIFY] counts match DOCX vs HTML.
- Logic: 10 sessions; clock sums to 90; rotation matrix is a Latin square; pre/post key valid; all arithmetic used in lessons recomputed (9.875 g, 11.375 g, 15.8%, 0.178 J, 24.4%, 21.6 s mean / 1.6 s range, $281.25 / $225 / $18.75 / $15.00).
- Chrome headless print check (visual review of PNGs): Quick Card = 2 pages, Grant = 1 page + guide, Parent = 3, Compliance = 4, Workbook = 18, Binder = 34.
- **Not verifiable here:** Word/LibreOffice are not installed, so DOCX page breaks were not visually rendered in Word (HTML print views were). Fonts must be installed on the viewing PC or Word substitutes.

## Inconsistencies found in EXISTING kits (full list: Binder Section 12) - please fix at source
1. Battery: 8-Week says 1S 450 mAh LiHV; Risk Sheet says 1S 300 mAh LiPo.
2. Risk Sheet foam-ball row: 6.5 g at 26 m/s is 2.20 J, not 1.10 J.
3. ELOP kit TIER-4: $18.75/student-hr at 20 students should be $15.00.
4. 8-week lab price: One-Pager $5,600 vs ELOP kit $5,120.
5. Collateral waiver includes an optional soldering elective; compliance docs say students never solder.
6. "Official FAA TRUST certificate" copy vs. the actual FAA test process; "$2M insured", "Live Scan cleared", "+40% gain" have no evidence in the workspace.

## Known gaps / [VERIFY]
Age band (8-14 assumed); exact standards codes (kept generic by design); staffing ratio per site/insurer; pass mark 70/100; FPV approval; failsafe-demo procedure (CTO); configurator software; equipment counts; Spanish copy needs native-speaker review; no outcome data exists yet (grant template uses targets, never claims).

## Single next action
Alan/Miguel to run the 14-item [VERIFY] register (Binder Section 12) - starting with the battery spec, price book and TRUST wording - then pilot Session 1-3 with one cohort and replace targets with real data.
