#!/usr/bin/env python3
"""
controller_sim.py - Complete Python Simulation and Validation Harness
Smart Disc Golf Steerable Driver Subsystem (Milestone M2)

Verifies:
1. 16-Byte BLE 5.3 compact binary frame serialization, deserialization, and CRC-16-CCITT.
2. Smartphone roll tilt transfer function:
   - Bilateral deadband (+/- 3.5 deg) eliminating jitter
   - Cubic exponential blending curve (alpha = 0.45) for fine vernier control
   - Slew rate limiter (400 deg/s or 400%/s) preventing aerodynamic stall
   - Elevon physical deflection and servo PWM pulse width mapping (1000..2000 us)
   - Interface Contract 2 steering polarity compliance
3. 100ms packet-loss failsafe watchdog (soft decay to neutral glide, 300ms hard disarm).
4. BLE 5.3 2Mbps LE PHY update rates (>= 50 Hz, 7.5 - 15.0 ms connection interval).
5. End-to-end latency budget breakdown (<20ms typical, <50ms worst case).
6. ICM-42688-P IMU centripetal acceleration compensation (r <= 0.5 mm, a_c <= 5.03g at 3000 RPM).
7. High-G throw launch detection state machine and spin-axis phase estimation.
"""

import math
import struct
import sys
import time
from typing import Tuple, Dict, Any, List

# ============================================================================
# CRC-16-CCITT Implementation (Matches C ble_service.c)
# ============================================================================

def crc16_ccitt(data: bytes) -> int:
    """
    Calculate standard CRC-16-CCITT (poly 0x1021, init 0xFFFF, no reflection, final XOR 0x0000).
    """
    crc = 0xFFFF
    for byte in data:
        crc ^= (byte << 8) & 0xFFFF
        for _ in range(8):
            if crc & 0x8000:
                crc = ((crc << 1) ^ 0x1021) & 0xFFFF
            else:
                crc = (crc << 1) & 0xFFFF
    return crc


# ============================================================================
# BLE 5.3 Protocol Models (16-Byte Compact Frames)
# ============================================================================

HEADER_MAGIC = 0xAA55
FRAME_LEN = 16

# Command Flags
FLAG_ARM_ACTIVE       = (1 << 0)
FLAG_BIAS_TRIM_EN     = (1 << 1)
FLAG_FAILSAFE_TEST    = (1 << 2)
FLAG_INSTANT_NEUTRAL  = (1 << 3)
FLAG_FLIGHT_PHASE_GLIDE = 0x20


class BleCommandFrame:
    """Represents a 16-byte packed forward command frame from phone to disc."""
    
    def __init__(self,
                 msg_id: int = 0,
                 timestamp_ms: int = 0,
                 roll_angle_cdeg: int = 0,
                 pitch_angle_cdeg: int = 0,
                 steer_demand: int = 0,
                 cmd_flags: int = FLAG_ARM_ACTIVE,
                 profile_id: int = 0,
                 dynamic_gain: int = 100,
                 aux_data: int = 0):
        self.header = HEADER_MAGIC
        self.msg_id = msg_id & 0xFF
        self.timestamp_ms = timestamp_ms & 0xFFFF
        self.roll_angle_cdeg = roll_angle_cdeg
        self.pitch_angle_cdeg = pitch_angle_cdeg
        self.steer_demand = max(-100, min(100, steer_demand))
        self.cmd_flags = cmd_flags & 0xFF
        self.profile_id = profile_id & 0xFF
        self.dynamic_gain = dynamic_gain & 0xFF
        self.aux_data = aux_data & 0xFF
        self.crc16 = 0

    def serialize(self) -> bytes:
        """Packs frame into 16 bytes with big-endian wire format and calculates CRC."""
        # Pack first 14 bytes: >H B H h h b B B B B
        payload_14 = struct.pack(
            ">HBHhhbBBBB",
            self.header,
            self.msg_id,
            self.timestamp_ms,
            self.roll_angle_cdeg,
            self.pitch_angle_cdeg,
            self.steer_demand,
            self.cmd_flags,
            self.profile_id,
            self.dynamic_gain,
            self.aux_data
        )
        self.crc16 = crc16_ccitt(payload_14)
        return payload_14 + struct.pack(">H", self.crc16)

    @classmethod
    def deserialize(cls, raw: bytes) -> 'BleCommandFrame':
        """Unpacks and validates a 16-byte binary command frame."""
        if len(raw) != FRAME_LEN:
            raise ValueError(f"Invalid frame length: expected {FRAME_LEN}, got {len(raw)}")
        
        # Verify CRC
        payload_14 = raw[:14]
        expected_crc = crc16_ccitt(payload_14)
        received_crc = struct.unpack(">H", raw[14:16])[0]
        if expected_crc != received_crc:
            raise ValueError(f"CRC mismatch: expected 0x{expected_crc:04X}, received 0x{received_crc:04X}")
        
        header, msg_id, ts, roll, pitch, steer, flags, prof, gain, aux = struct.unpack(
            ">HBHhhbBBBB", payload_14
        )
        if header != HEADER_MAGIC:
            raise ValueError(f"Invalid header magic: expected 0x{HEADER_MAGIC:04X}, got 0x{header:04X}")
        
        frame = cls(
            msg_id=msg_id,
            timestamp_ms=ts,
            roll_angle_cdeg=roll,
            pitch_angle_cdeg=pitch,
            steer_demand=steer,
            cmd_flags=flags,
            profile_id=prof,
            dynamic_gain=gain,
            aux_data=aux
        )
        frame.crc16 = received_crc
        return frame


class BleTelemetryFrame:
    """Represents a 16-byte packed reverse telemetry frame from disc to phone."""
    
    def __init__(self,
                 battery_voltage_mv: int = 4180,
                 spin_rpm: int = 1800,
                 phase_deg_cdeg: int = 0,
                 actuator_current_ma: int = 250,
                 core_temp_c: int = 25,
                 rssi_dbm: int = -50,
                 flight_time_ms: int = 1200,
                 status_flags: int = 1):
        self.battery_voltage_mv = battery_voltage_mv
        self.spin_rpm = spin_rpm
        self.phase_deg_cdeg = phase_deg_cdeg
        self.actuator_current_ma = actuator_current_ma
        self.core_temp_c = core_temp_c
        self.rssi_dbm = rssi_dbm
        self.flight_time_ms = flight_time_ms
        self.status_flags = status_flags
        self.crc16 = 0

    def serialize(self) -> bytes:
        payload_14 = struct.pack(
            ">HHHHbbHH",
            self.battery_voltage_mv,
            self.spin_rpm,
            self.phase_deg_cdeg,
            self.actuator_current_ma,
            self.core_temp_c,
            self.rssi_dbm,
            self.flight_time_ms,
            self.status_flags
        )
        self.crc16 = crc16_ccitt(payload_14)
        return payload_14 + struct.pack(">H", self.crc16)

    @classmethod
    def deserialize(cls, raw: bytes) -> 'BleTelemetryFrame':
        if len(raw) != FRAME_LEN:
            raise ValueError(f"Invalid telemetry length: expected {FRAME_LEN}, got {len(raw)}")
        payload_14 = raw[:14]
        calc_crc = crc16_ccitt(payload_14)
        rx_crc = struct.unpack(">H", raw[14:16])[0]
        if calc_crc != rx_crc:
            raise ValueError(f"Telemetry CRC error: expected 0x{calc_crc:04X}, got 0x{rx_crc:04X}")
        batt, rpm, phase, curr, temp, rssi, ftime, status = struct.unpack(">HHHHbbHH", payload_14)
        telem = cls(batt, rpm, phase, curr, temp, rssi, ftime, status)
        telem.crc16 = rx_crc
        return telem


# ============================================================================
# Motion Mapping Engine
# ============================================================================

class MotionMappingEngine:
    """
    Translates raw smartphone roll tilt into conditioned steering commands
    with deadband, cubic exponential blending, rate limiting, and failsafe watchdog.
    """
    
    def __init__(self,
                 deadband_deg: float = 3.5,
                 max_tilt_deg: float = 35.0,
                 expo_alpha: float = 0.45,
                 slew_rate_pct_s: float = 400.0,
                 elevon_max_deg: float = 25.0,
                 failsafe_soft_ms: int = 100,
                 failsafe_hard_ms: int = 300,
                 roll_trim_pct: float = 0.0):
        self.deadband_deg = deadband_deg
        self.max_tilt_deg = max_tilt_deg
        self.expo_alpha = expo_alpha
        self.slew_rate_pct_s = slew_rate_pct_s
        self.elevon_max_deg = elevon_max_deg
        self.failsafe_soft_ms = failsafe_soft_ms
        self.failsafe_hard_ms = failsafe_hard_ms
        self.roll_trim_pct = float(roll_trim_pct)
        
        # State
        self.armed = False
        self.state = "UNINITIALIZED"
        self.target_steer_pct = 0.0
        self.current_steer_pct = 0.0
        self.elevon_left_deg = 0.0
        self.elevon_right_deg = 0.0
        self.servo_left_us = 1500
        self.servo_right_us = 1500
        self.last_packet_time_ms = 0
        self.total_packets_rx = 0

    def set_roll_trim(self, trim_pct: float):
        """Sets the differential elevon roll trim percentage."""
        self.roll_trim_pct = float(trim_pct)

    def compute_normalized_tilt(self, roll_deg: float) -> float:
        """Applies bilateral deadband conditioning."""
        abs_roll = abs(roll_deg)
        if abs_roll <= self.deadband_deg:
            return 0.0
        if abs_roll >= self.max_tilt_deg:
            return 1.0 if roll_deg > 0 else -1.0
        span = self.max_tilt_deg - self.deadband_deg
        norm = (abs_roll - self.deadband_deg) / span
        return norm if roll_deg > 0 else -norm

    def compute_expo_blend(self, norm_tilt: float) -> float:
        """Applies cubic exponential blending curve."""
        norm_tilt = max(-1.0, min(1.0, norm_tilt))
        return (1.0 - self.expo_alpha) * norm_tilt + self.expo_alpha * (norm_tilt ** 3)

    def feed_packet(self, roll_deg: float, timestamp_ms: int):
        """Processes a newly arrived valid telemetry/command packet."""
        self.last_packet_time_ms = timestamp_ms
        self.total_packets_rx += 1
        norm = self.compute_normalized_tilt(roll_deg)
        expo = self.compute_expo_blend(norm)
        self.target_steer_pct = expo * 100.0
        if self.state in ("FAILSAFE_SOFT", "FAILSAFE_HARD"):
            self.state = "NOMINAL_FLIGHT"

    def update_step(self, current_time_ms: int, dt_sec: float):
        """1 kHz periodic update step."""
        if not self.armed:
            self.current_steer_pct = 0.0
            self.target_steer_pct = 0.0
            self.elevon_left_deg = 0.0
            self.elevon_right_deg = 0.0
            self.servo_left_us = 1500
            self.servo_right_us = 1500
            return

        elapsed_ms = (current_time_ms - self.last_packet_time_ms) & 0xFFFF
        
        # Failsafe watchdog
        if elapsed_ms > self.failsafe_hard_ms:
            self.state = "FAILSAFE_HARD"
            active_target = 0.0
            self.current_steer_pct = 0.0 # Instant hard disarm / neutral
        elif elapsed_ms > self.failsafe_soft_ms:
            self.state = "FAILSAFE_SOFT"
            active_target = 0.0
            # Slew smoothly back to zero at 500%/s
            decay_rate = 500.0
            max_change = decay_rate * dt_sec
            diff = active_target - self.current_steer_pct
            if abs(diff) <= max_change:
                self.current_steer_pct = active_target
            else:
                self.current_steer_pct += math.copysign(max_change, diff)
        else:
            self.state = "NOMINAL_FLIGHT"
            active_target = self.target_steer_pct
            max_change = self.slew_rate_pct_s * dt_sec
            diff = active_target - self.current_steer_pct
            if abs(diff) <= max_change:
                self.current_steer_pct = active_target
            else:
                self.current_steer_pct += math.copysign(max_change, diff)

        self.current_steer_pct = max(-100.0, min(100.0, self.current_steer_pct))

        # Elevon mixing & servo pulse mapping with differential roll trim (Interface Contract 2)
        # S > 0 -> Roll Right -> Precession Right -> Nose Down Pitch Moment
        elevon_pitch_deg = (self.current_steer_pct / 100.0) * self.elevon_max_deg
        elevon_trim_deg = (self.roll_trim_pct / 100.0) * self.elevon_max_deg
        self.elevon_left_deg = max(-self.elevon_max_deg, min(self.elevon_max_deg, elevon_pitch_deg - elevon_trim_deg))
        self.elevon_right_deg = max(-self.elevon_max_deg, min(self.elevon_max_deg, elevon_pitch_deg + elevon_trim_deg))

        # PWM mixing with clamp [1000, 2000] us
        pwm_pitch = int(self.current_steer_pct * 5.0)
        pwm_trim = int(self.roll_trim_pct * 5.0)
        self.servo_left_us = max(1000, min(2000, 1500 + pwm_pitch - pwm_trim))
        self.servo_right_us = max(1000, min(2000, 1500 + pwm_pitch + pwm_trim))


# ============================================================================
# IMU Dynamics, Centripetal Compensation & Launch Detection
# ============================================================================

class ImuDynamics:
    """Models ICM-42688-P IMU kinematics, centripetal compensation, and launch detection."""
    
    GRAVITY = 9.80665

    @staticmethod
    def calc_centripetal_g(omega_rpm: float, radius_m: float) -> float:
        """Calculates centripetal acceleration in g units: a_c = omega^2 * r / g0."""
        omega_rad_s = abs(omega_rpm) * (2.0 * math.pi / 60.0)
        a_c_m_s2 = (omega_rad_s ** 2) * radius_m
        return a_c_m_s2 / ImuDynamics.GRAVITY

    @staticmethod
    def compensate_centripetal(meas_ax_g: float,
                               meas_ay_g: float,
                               meas_az_g: float,
                               offset_x_m: float,
                               offset_y_m: float,
                               omega_z_rad_s: float) -> Tuple[float, float, float, float]:
        """
        Removes centripetal acceleration vector caused by spinning around Z axis.
        Returns: (true_ax_g, true_ay_g, true_az_g, centripetal_mag_g)
        """
        omega_sq = omega_z_rad_s ** 2
        ac_x_g = (omega_sq * offset_x_m) / ImuDynamics.GRAVITY
        ac_y_g = (omega_sq * offset_y_m) / ImuDynamics.GRAVITY
        
        true_ax = meas_ax_g - ac_x_g
        true_ay = meas_ay_g - ac_y_g
        true_az = meas_az_g
        
        radius_m = math.sqrt(offset_x_m ** 2 + offset_y_m ** 2)
        ac_mag_g = (omega_sq * radius_m) / ImuDynamics.GRAVITY
        return true_ax, true_ay, true_az, ac_mag_g


class LaunchStateMachine:
    """High-G throw launch detection state machine."""
    
    def __init__(self):
        self.phase = "STATIONARY"
        self.arm_timer_ms = 0
        self.flight_timer_ms = 0

    def update(self, total_accel_g: float, spin_rpm: float, dt_ms: int) -> str:
        if self.phase == "STATIONARY":
            if total_accel_g >= 6.0:
                self.arm_timer_ms += dt_ms
                if self.arm_timer_ms >= 30:
                    self.phase = "ARMING"
            else:
                self.arm_timer_ms = 0
        elif self.phase == "ARMING":
            self.arm_timer_ms += dt_ms
            if total_accel_g >= 15.0 and spin_rpm >= 800.0:
                self.phase = "RELEASE"
            elif self.arm_timer_ms > 2000:
                self.phase = "STATIONARY"
                self.arm_timer_ms = 0
        elif self.phase == "RELEASE":
            self.phase = "IN_FLIGHT"
            self.flight_timer_ms = 0
        elif self.phase == "IN_FLIGHT":
            self.flight_timer_ms += dt_ms
            if total_accel_g >= 35.0 or (self.flight_timer_ms >= 300 and spin_rpm < 250.0):
                self.phase = "IMPACT"
        return self.phase


# ============================================================================
# Latency Budget Model
# ============================================================================

def get_latency_budget() -> Dict[str, Dict[str, float]]:
    """Returns typical and worst-case latency budget breakdowns."""
    typical = {
        "imu_fusion_ms": 5.5,
        "os_app_proc_ms": 2.0,
        "ble_airtime_ms": 6.0,
        "disc_rx_ipc_ms": 1.0,
        "actuator_slew_ms": 5.0,
        "total_ms": 19.5
    }
    worst_case = {
        "imu_fusion_ms": 7.0,
        "os_app_proc_ms": 3.0,
        "ble_airtime_ms": 23.0, # 1 link-layer retry @ 15ms CI
        "disc_rx_ipc_ms": 1.5,
        "actuator_slew_ms": 8.0,
        "total_ms": 42.5
    }
    return {"typical": typical, "worst_case": worst_case}


# ============================================================================
# Comprehensive Verification Test Suite
# ============================================================================

class TestRunner:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.tests_run = 0

    def assert_true(self, condition: bool, test_name: str, msg: str = ""):
        self.tests_run += 1
        if condition:
            self.passed += 1
            print(f"  [PASS] {test_name}")
        else:
            self.failed += 1
            print(f"  [FAIL] {test_name} - {msg}")


def run_all_tests() -> bool:
    runner = TestRunner()
    print("=" * 78)
    print("SMART DISC GOLF AVIONICS & LOW-LATENCY BLE SIMULATION HARNESS")
    print("Milestone M2 Verification Suite")
    print("=" * 78)

    # ------------------------------------------------------------------------
    # Test Suite 1: CRC-16-CCITT and Packet Integrity
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 1: CRC-16-CCITT & Binary Packet Serialization ---")
    
    # 1.1 Known vector
    test_data = b"123456789"
    crc_known = crc16_ccitt(test_data)
    # Standard CCITT poly 0x1021 init 0xFFFF on "123456789" gives 0x29B1
    runner.assert_true(crc_known == 0x29B1, "CRC16 known vector '123456789'",
                       f"Expected 0x29B1, got 0x{crc_known:04X}")

    # 1.2 Serialization / Deserialization Round-Trip
    frame_orig = BleCommandFrame(
        msg_id=42,
        timestamp_ms=12345,
        roll_angle_cdeg=1520,   # +15.20 deg roll right
        pitch_angle_cdeg=-340,  # -3.40 deg pitch
        steer_demand=48,        # +48% demand
        cmd_flags=FLAG_ARM_ACTIVE | FLAG_FLIGHT_PHASE_GLIDE,
        profile_id=1,
        dynamic_gain=110,
        aux_data=7
    )
    raw_bytes = frame_orig.serialize()
    runner.assert_true(len(raw_bytes) == 16, "Command frame length == 16 bytes",
                       f"Length: {len(raw_bytes)}")
    runner.assert_true(raw_bytes[0] == 0xAA and raw_bytes[1] == 0x55, "Header magic == 0xAA55")

    frame_rx = BleCommandFrame.deserialize(raw_bytes)
    runner.assert_true(frame_rx.msg_id == 42, "Deserialized msg_id match")
    runner.assert_true(frame_rx.timestamp_ms == 12345, "Deserialized timestamp match")
    runner.assert_true(frame_rx.roll_angle_cdeg == 1520, "Deserialized roll angle match")
    runner.assert_true(frame_rx.pitch_angle_cdeg == -340, "Deserialized pitch angle match")
    runner.assert_true(frame_rx.steer_demand == 48, "Deserialized steer demand match")
    runner.assert_true(frame_rx.cmd_flags == (FLAG_ARM_ACTIVE | FLAG_FLIGHT_PHASE_GLIDE), "Flags match")

    # 1.3 Corrupted Packet Detection
    corrupted_bytes = bytearray(raw_bytes)
    corrupted_bytes[5] ^= 0x01 # Corrupt one bit in roll angle
    crc_failed = False
    try:
        BleCommandFrame.deserialize(bytes(corrupted_bytes))
    except ValueError as e:
        crc_failed = True
    runner.assert_true(crc_failed, "Bitflip corruption detection via CRC-16")

    # 1.4 Reverse Telemetry Frame Serialization
    telem_orig = BleTelemetryFrame(
        battery_voltage_mv=4180,
        spin_rpm=2150,
        phase_deg_cdeg=18450,
        actuator_current_ma=320,
        core_temp_c=27,
        rssi_dbm=-62,
        flight_time_ms=1450,
        status_flags=3
    )
    raw_telem = telem_orig.serialize()
    runner.assert_true(len(raw_telem) == 16, "Telemetry frame length == 16 bytes")
    telem_rx = BleTelemetryFrame.deserialize(raw_telem)
    runner.assert_true(telem_rx.battery_voltage_mv == 4180, "Telemetry battery voltage match")
    runner.assert_true(telem_rx.spin_rpm == 2150, "Telemetry spin RPM match")

    # ------------------------------------------------------------------------
    # Test Suite 2: Smartphone Roll Motion Mapping Transfer Function
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 2: Motion Mapping Transfer Function ---")
    engine = MotionMappingEngine(
        deadband_deg=3.5,
        max_tilt_deg=35.0,
        expo_alpha=0.45,
        slew_rate_pct_s=400.0,
        elevon_max_deg=25.0
    )
    engine.armed = True

    # 2.1 Bilateral Deadband Tests (+/- 3.5 deg)
    runner.assert_true(engine.compute_normalized_tilt(0.0) == 0.0, "Zero roll -> 0.0 norm")
    runner.assert_true(engine.compute_normalized_tilt(2.0) == 0.0, "+2.0 deg (in deadband) -> 0.0")
    runner.assert_true(engine.compute_normalized_tilt(-3.4) == 0.0, "-3.4 deg (in deadband) -> 0.0")
    runner.assert_true(engine.compute_normalized_tilt(3.5) == 0.0, "Exact +3.5 deg boundary -> 0.0")
    runner.assert_true(engine.compute_normalized_tilt(-3.5) == 0.0, "Exact -3.5 deg boundary -> 0.0")
    
    # 2.2 Continuity and Upper Bound
    tilt_just_above = engine.compute_normalized_tilt(3.51)
    runner.assert_true(0.0 < tilt_just_above < 0.01, f"+3.51 deg just above deadband -> {tilt_just_above:.4f}")
    runner.assert_true(engine.compute_normalized_tilt(35.0) == 1.0, "+35.0 deg -> 1.0 norm")
    runner.assert_true(engine.compute_normalized_tilt(-35.0) == -1.0, "-35.0 deg -> -1.0 norm")
    runner.assert_true(engine.compute_normalized_tilt(50.0) == 1.0, "+50.0 deg (clamped) -> 1.0 norm")

    # 2.3 Cubic Exponential Blending Curve (alpha = 0.45)
    # delta = (1 - 0.45)*x + 0.45*x^3 = 0.55*x + 0.45*x^3
    runner.assert_true(abs(engine.compute_expo_blend(0.0)) < 1e-6, "Expo blend @ 0.0 == 0.0")
    runner.assert_true(abs(engine.compute_expo_blend(1.0) - 1.0) < 1e-6, "Expo blend @ 1.0 == 1.0")
    runner.assert_true(abs(engine.compute_expo_blend(-1.0) - (-1.0)) < 1e-6, "Expo blend @ -1.0 == -1.0")

    # Midpoint test: at norm=0.5 -> 0.55*0.5 + 0.45*0.125 = 0.275 + 0.05625 = 0.33125
    expected_mid = 0.33125
    actual_mid = engine.compute_expo_blend(0.5)
    runner.assert_true(abs(actual_mid - expected_mid) < 1e-5,
                       f"Expo blend @ 0.5 == {expected_mid:.5f}",
                       f"Got {actual_mid:.5f}")

    # 2.4 Interface Contract 2 Steering Polarity Check
    # Roll Right (> +3.5 deg) -> Positive Steer Demand -> Nose Down Pitch Moment -> Precess Right
    engine.feed_packet(roll_deg=20.0, timestamp_ms=100)
    runner.assert_true(engine.target_steer_pct > 0.0, "Positive roll -> Positive steer demand (Right)")
    
    engine.feed_packet(roll_deg=-20.0, timestamp_ms=100)
    runner.assert_true(engine.target_steer_pct < 0.0, "Negative roll -> Negative steer demand (Left)")

    # ------------------------------------------------------------------------
    # Test Suite 3: Slew Rate Limiter & Structural Protection
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 3: Slew Rate Limiter (400 deg/s or 400%/s) ---")
    engine.current_steer_pct = 0.0
    engine.feed_packet(roll_deg=35.0, timestamp_ms=1000) # Demands instant +100%
    
    # Run 10 ms step (0.010 s)
    # Maximum allowed change in 10ms = 400 %/s * 0.010 s = 4.0 %
    engine.update_step(current_time_ms=1010, dt_sec=0.010)
    runner.assert_true(abs(engine.current_steer_pct - 4.0) < 1e-3,
                       f"10ms step limited to 4.0% change (got {engine.current_steer_pct:.2f}%)")

    # Run for 250 ms total (25 steps of 10 ms with streaming packets @ 100 Hz): 4.0 * 25 = 100.0%
    for step in range(24):
        t_ms = 1020 + step * 10
        engine.feed_packet(roll_deg=35.0, timestamp_ms=t_ms)
        engine.update_step(current_time_ms=t_ms, dt_sec=0.010)
    
    runner.assert_true(abs(engine.current_steer_pct - 100.0) < 1e-2,
                       f"250ms ramp reaches full 100% smoothly (got {engine.current_steer_pct:.2f}%)")
    runner.assert_true(abs(engine.elevon_left_deg - 25.0) < 1e-2,
                       f"Elevon physical deflection == +25.0 deg (got {engine.elevon_left_deg:.2f} deg)")
    runner.assert_true(engine.servo_left_us == 2000,
                       f"Servo PWM pulse width == 2000 us (got {engine.servo_left_us} us)")

    # ------------------------------------------------------------------------
    # Test Suite 4: 100ms Packet-Loss Watchdog & Failsafe Subsystem
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 4: 100ms Packet-Loss Watchdog & Failsafe ---")
    
    # Establish active flight at +100%
    engine.feed_packet(roll_deg=35.0, timestamp_ms=2000)
    engine.current_steer_pct = 100.0
    engine.update_step(current_time_ms=2050, dt_sec=0.050)
    runner.assert_true(engine.state == "NOMINAL_FLIGHT", "Nominal state within 50ms of packet")
    runner.assert_true(engine.current_steer_pct == 100.0, "Holds steer command during nominal flight")

    # Advance time to 95 ms without packet -> Still nominal
    engine.update_step(current_time_ms=2095, dt_sec=0.045)
    runner.assert_true(engine.state == "NOMINAL_FLIGHT", "State nominal at 95 ms elapsed")

    # Advance time to 120 ms without packet -> Triggers soft decay failsafe
    engine.update_step(current_time_ms=2120, dt_sec=0.025)
    runner.assert_true(engine.state == "FAILSAFE_SOFT", "Soft failsafe active after 120 ms packet loss")
    runner.assert_true(engine.current_steer_pct < 100.0,
                       f"Command decaying toward zero (current: {engine.current_steer_pct:.2f}%)")

    # Continue decaying for 200 ms (total elapsed 320 ms) -> Triggers hard disarm
    engine.update_step(current_time_ms=2320, dt_sec=0.200)
    runner.assert_true(engine.state == "FAILSAFE_HARD", "Hard disarm active after >300 ms packet loss")
    runner.assert_true(engine.current_steer_pct == 0.0, "Steer demand clamped to 0.0% neutral glide")
    runner.assert_true(engine.elevon_left_deg == 0.0, "Elevons returned to neutral 0.0 deg")
    runner.assert_true(engine.servo_left_us == 1500, "Servos returned to neutral 1500 us")

    # Recovery test: receive fresh packet -> State returns to nominal
    engine.feed_packet(roll_deg=-15.0, timestamp_ms=2350)
    engine.update_step(current_time_ms=2350, dt_sec=0.001)
    runner.assert_true(engine.state == "NOMINAL_FLIGHT", "Failsafe automatically clears on fresh packet")

    # ------------------------------------------------------------------------
    # Test Suite 5: BLE 5.3 2Mbps LE PHY Timing & Latency Budget
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 5: BLE 5.3 Timing & Latency Budget ---")
    
    # 5.1 Connection interval update rates
    ci_min_ms = 7.5  # Android high priority
    ci_max_ms = 15.0 # iOS accessory guidance
    rate_at_7_5 = 1000.0 / ci_min_ms
    rate_at_15_0 = 1000.0 / ci_max_ms
    runner.assert_true(rate_at_7_5 >= 100.0, f"7.5ms CI delivers {rate_at_7_5:.1f} Hz (>= 100 Hz)")
    runner.assert_true(rate_at_15_0 >= 50.0, f"15.0ms CI delivers {rate_at_15_0:.1f} Hz (>= 50 Hz)")

    # 5.2 Latency Budget Verification
    budgets = get_latency_budget()
    typ_total = budgets["typical"]["total_ms"]
    wst_total = budgets["worst_case"]["total_ms"]
    
    runner.assert_true(typ_total < 20.0,
                       f"Typical latency {typ_total:.1f} ms strictly < 20.0 ms target",
                       f"Typical latency: {typ_total:.1f} ms")
    runner.assert_true(wst_total < 50.0,
                       f"Worst-case latency {wst_total:.1f} ms strictly < 50.0 ms requirement",
                       f"Worst-case latency: {wst_total:.1f} ms")

    # Verify breakdown components
    runner.assert_true(budgets["typical"]["imu_fusion_ms"] == 5.5, "Typical IMU fusion delay == 5.5 ms")
    runner.assert_true(budgets["typical"]["ble_airtime_ms"] == 6.0, "Typical BLE airtime == 6.0 ms")
    runner.assert_true(budgets["worst_case"]["ble_airtime_ms"] == 23.0, "Worst-case BLE airtime (1 retry) == 23.0 ms")

    # ------------------------------------------------------------------------
    # Test Suite 6: IMU Centripetal Acceleration Compensation
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 6: IMU Centripetal Acceleration Compensation ---")
    
    # Requirement: mounted within r <= 0.5 mm of spin axis
    # a_c = omega^2 * r <= 5.03g at 3000 RPM, well within +/-16g range
    max_rpm = 3000.0
    r_target_m = 0.0005 # 0.5 mm
    ac_3000_rpm = ImuDynamics.calc_centripetal_g(max_rpm, r_target_m)
    
    runner.assert_true(ac_3000_rpm <= 5.033,
                       f"Centripetal accel at 3000 RPM and 0.5mm is {ac_3000_rpm:.3f}g <= 5.033g")
    runner.assert_true(ac_3000_rpm < 16.0,
                       f"Headroom on +/-16g scale: {(16.0 - ac_3000_rpm):.2f}g available for flight forces")

    # Check 1500 RPM nominal
    ac_1500_rpm = ImuDynamics.calc_centripetal_g(1500.0, r_target_m)
    runner.assert_true(ac_1500_rpm <= 1.30, f"Nominal 1500 RPM centripetal accel is {ac_1500_rpm:.3f}g")

    # Vector Compensation Verification
    # Sensor mounted at offset rx = 0.35 mm, ry = 0.35 mm (total radius = 0.495 mm <= 0.5 mm)
    rx_m = 0.00035
    ry_m = 0.00035
    omega_z = 3000.0 * (2.0 * math.pi / 60.0) # 314.159 rad/s
    
    # Simulate accelerometer raw reading: 1.0g true aerodynamic lift along Z,
    # plus centripetal apparent acceleration along X and Y
    ac_x_g = (omega_z ** 2 * rx_m) / ImuDynamics.GRAVITY
    ac_y_g = (omega_z ** 2 * ry_m) / ImuDynamics.GRAVITY
    
    raw_ax = 0.2 + ac_x_g  # 0.2g true inertial lateral + centripetal
    raw_ay = -0.1 + ac_y_g # -0.1g true inertial lateral + centripetal
    raw_az = 1.0           # 1.0g true vertical
    
    comp_ax, comp_ay, comp_az, ac_mag = ImuDynamics.compensate_centripetal(
        raw_ax, raw_ay, raw_az, rx_m, ry_m, omega_z
    )
    
    runner.assert_true(abs(comp_ax - 0.2) < 1e-5, f"Centripetal cancelled on X: {comp_ax:.4f}g == 0.2g")
    runner.assert_true(abs(comp_ay - (-0.1)) < 1e-5, f"Centripetal cancelled on Y: {comp_ay:.4f}g == -0.1g")
    runner.assert_true(abs(comp_az - 1.0) < 1e-5, f"Z axis unaffected: {comp_az:.4f}g == 1.0g")
    runner.assert_true(ac_mag <= 5.033, f"Calculated centripetal magnitude: {ac_mag:.3f}g")

    # ------------------------------------------------------------------------
    # Test Suite 7: High-G Throw Launch Detection & Phase Estimation
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 7: Launch Detection State Machine & Phase ---")
    sm = LaunchStateMachine()
    
    # 1. Stationary rest
    runner.assert_true(sm.update(total_accel_g=1.0, spin_rpm=0.0, dt_ms=10) == "STATIONARY",
                       "Phase is STATIONARY on bench")

    # 2. Arm backswing & pull-through: 8g for 40ms -> transitions to ARMING
    for _ in range(4):
        state = sm.update(total_accel_g=8.0, spin_rpm=200.0, dt_ms=10)
    runner.assert_true(state == "ARMING", "Phase transitions to ARMING during pull-through")

    # 3. Release Snap: acceleration spike to 28g and spin snap to 1800 RPM
    state = sm.update(total_accel_g=28.0, spin_rpm=1800.0, dt_ms=10)
    runner.assert_true(state == "RELEASE", "Phase transitions to RELEASE on high-G snap (>15g, >800 RPM)")

    # 4. In-Flight Glide: enters free flight
    state = sm.update(total_accel_g=1.1, spin_rpm=1750.0, dt_ms=10)
    runner.assert_true(state == "IN_FLIGHT", "Phase transitions to IN_FLIGHT")

    # 5. Simulated flight for 3.0 seconds
    for _ in range(300):
        state = sm.update(total_accel_g=1.05, spin_rpm=1600.0, dt_ms=10)
    runner.assert_true(state == "IN_FLIGHT", "Maintains IN_FLIGHT during sustained glide")

    # 6. Basket Impact: 45g chain strike
    state = sm.update(total_accel_g=45.0, spin_rpm=800.0, dt_ms=10)
    runner.assert_true(state == "IMPACT", "Phase transitions to IMPACT on violent chain strike (>35g)")

    # Phase angle accumulation & zero-crossing sync
    phase_deg = 0.0
    gyro_z_dps = 1800.0 * 6.0 # 1800 RPM = 10,800 deg/s
    dt = 0.001 # 1 ms
    for _ in range(100): # 100 ms of rotation = 1080 deg = 3 full rotations
        phase_deg = (phase_deg + gyro_z_dps * dt) % 360.0
    runner.assert_true(abs(phase_deg - 0.0) < 1e-4, f"Phase wrap after 3 full revolutions: {phase_deg:.1f} deg")

    # ------------------------------------------------------------------------
    # Test Suite 8: Integrated End-to-End Flight Steering Scenario
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 8: Integrated Real-Time Steering Flight Scenario ---")
    
    # Simulate a full 5-second throw flight with real-time steering commands at 66.7 Hz (15ms interval)
    flight_engine = MotionMappingEngine()
    flight_engine.armed = True
    
    sim_time_ms = 0
    dt_ms = 1 # 1kHz internal control loop
    packet_interval_ms = 15 # 66.7 Hz BLE stream
    
    trajectory_log: List[Dict[str, float]] = []

    # Flight profile:
    # 0.0s - 1.0s: Flat flight (roll = 0 deg)
    # 1.0s - 2.5s: Steer Right to avoid tree (roll = +25.0 deg)
    # 2.5s - 3.5s: Steer Left toward basket (roll = -20.0 deg)
    # 3.5s - 4.2s: Packet loss simulation (no packets)
    # 4.2s - 5.0s: Packet restored (roll = +10.0 deg)
    
    for ms in range(5000):
        sim_time_ms = ms
        
        # Periodic BLE packet arrival
        if ms % packet_interval_ms == 0:
            if ms < 1000:
                roll = 1.0 # Within deadband
            elif ms < 2500:
                roll = 25.0 # Roll right
            elif ms < 3500:
                roll = -20.0 # Roll left
            elif ms < 4200:
                # RF packet loss period: no packets fed!
                roll = None
            else:
                roll = 10.0 # Restored right correction
            
            if roll is not None:
                # Simulate BLE packet transmission
                cmd = BleCommandFrame(
                    msg_id=(ms // packet_interval_ms) & 0xFF,
                    timestamp_ms=sim_time_ms,
                    roll_angle_cdeg=int(roll * 100),
                    steer_demand=0
                )
                packet_bytes = cmd.serialize()
                parsed = BleCommandFrame.deserialize(packet_bytes)
                flight_engine.feed_packet(parsed.roll_angle_cdeg / 100.0, sim_time_ms)

        # 1 kHz control update
        flight_engine.update_step(sim_time_ms, dt_sec=0.001)

        if ms in (500, 2000, 3000, 3700, 4500):
            trajectory_log.append({
                "time_s": ms / 1000.0,
                "state": flight_engine.state,
                "steer_pct": flight_engine.current_steer_pct,
                "elevon_deg": flight_engine.elevon_left_deg,
                "servo_us": flight_engine.servo_left_us
            })

    # Assertions on trajectory scenario checkpoints
    # Checkpoint 1 (0.5s): Neutral deadband
    runner.assert_true(trajectory_log[0]["steer_pct"] == 0.0,
                       "Scenario @ 0.5s: Neutral center in deadband")
    # Checkpoint 2 (2.0s): Right steer active (> +50%)
    runner.assert_true(trajectory_log[1]["steer_pct"] > 50.0,
                       f"Scenario @ 2.0s: Right steering active ({trajectory_log[1]['steer_pct']:.1f}%)")
    # Checkpoint 3 (3.0s): Left steer active (< -30% matching cubic expo for -20 deg tilt)
    runner.assert_true(trajectory_log[2]["steer_pct"] < -30.0,
                       f"Scenario @ 3.0s: Left steering active ({trajectory_log[2]['steer_pct']:.1f}%)")
    # Checkpoint 4 (3.7s): Failsafe triggered during 700ms outage
    runner.assert_true(trajectory_log[3]["state"] in ("FAILSAFE_SOFT", "FAILSAFE_HARD"),
                       f"Scenario @ 3.7s: Failsafe triggered ({trajectory_log[3]['state']})")
    runner.assert_true(abs(trajectory_log[3]["steer_pct"]) < 5.0,
                       f"Scenario @ 3.7s: Elevons returned to neutral glide ({trajectory_log[3]['steer_pct']:.2f}%)")
    # Checkpoint 5 (4.5s): Restored control
    runner.assert_true(trajectory_log[4]["state"] == "NOMINAL_FLIGHT",
                       "Scenario @ 4.5s: Nominal control restored after reconnect")

    # ------------------------------------------------------------------------
    # Test Suite 9: Differential Elevon Roll-Trim Verification
    # ------------------------------------------------------------------------
    print("\n--- Test Suite 9: Differential Elevon Roll-Trim ---")

    # 9.0 Initializer verification
    init_trim_engine = MotionMappingEngine(roll_trim_pct=5.0)
    runner.assert_true(init_trim_engine.roll_trim_pct == 5.0,
                       "MotionMappingEngine initializes with custom roll_trim_pct")

    # 9.1 Zero Trim Verification (Symmetric deflection)
    trim_engine = MotionMappingEngine(roll_trim_pct=0.0)
    trim_engine.armed = True
    trim_engine.last_packet_time_ms = 10

    # Neutral pitch with zero trim
    trim_engine.target_steer_pct = 0.0
    trim_engine.current_steer_pct = 0.0
    trim_engine.update_step(current_time_ms=10, dt_sec=0.010)
    runner.assert_true(trim_engine.elevon_left_deg == 0.0 and trim_engine.elevon_right_deg == 0.0,
                       "Zero trim at neutral pitch gives 0.0 deg on both elevons")
    runner.assert_true(trim_engine.servo_left_us == 1500 and trim_engine.servo_right_us == 1500,
                       "Zero trim at neutral pitch centers both servos at 1500 us")

    # Symmetric pitch deflection with zero trim (+40% steer -> +10.0 deg, 1700 us)
    trim_engine.last_packet_time_ms = 20
    trim_engine.target_steer_pct = 40.0
    trim_engine.current_steer_pct = 40.0
    trim_engine.update_step(current_time_ms=20, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_left_deg - 10.0) < 1e-3 and abs(trim_engine.elevon_right_deg - 10.0) < 1e-3,
                       "Zero trim preserves symmetric elevon pitch deflection (+10.0 deg)")
    runner.assert_true(trim_engine.servo_left_us == 1700 and trim_engine.servo_right_us == 1700,
                       "Zero trim preserves symmetric servo PWM (1700 us)")

    # 9.2 Positive Roll Trim Verification (+10% trim -> +2.5 deg trim offset, +50 us)
    trim_engine.set_roll_trim(10.0)
    trim_engine.last_packet_time_ms = 30
    trim_engine.target_steer_pct = 0.0
    trim_engine.current_steer_pct = 0.0
    trim_engine.update_step(current_time_ms=30, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_left_deg - (-2.5)) < 1e-3,
                       f"Positive trim: left elevon deflected -2.5 deg (got {trim_engine.elevon_left_deg:.2f})")
    runner.assert_true(abs(trim_engine.elevon_right_deg - 2.5) < 1e-3,
                       f"Positive trim: right elevon deflected +2.5 deg (got {trim_engine.elevon_right_deg:.2f})")
    runner.assert_true(trim_engine.servo_left_us == 1450,
                       f"Positive trim: left servo PWM == 1450 us (got {trim_engine.servo_left_us})")
    runner.assert_true(trim_engine.servo_right_us == 1550,
                       f"Positive trim: right servo PWM == 1550 us (got {trim_engine.servo_right_us})")

    # 9.3 Negative Roll Trim Verification (-10% trim -> -2.5 deg trim offset, -50 us)
    trim_engine.set_roll_trim(-10.0)
    trim_engine.last_packet_time_ms = 40
    trim_engine.target_steer_pct = 0.0
    trim_engine.current_steer_pct = 0.0
    trim_engine.update_step(current_time_ms=40, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_left_deg - 2.5) < 1e-3,
                       f"Negative trim: left elevon deflected +2.5 deg (got {trim_engine.elevon_left_deg:.2f})")
    runner.assert_true(abs(trim_engine.elevon_right_deg - (-2.5)) < 1e-3,
                       f"Negative trim: right elevon deflected -2.5 deg (got {trim_engine.elevon_right_deg:.2f})")
    runner.assert_true(trim_engine.servo_left_us == 1550,
                       f"Negative trim: left servo PWM == 1550 us (got {trim_engine.servo_left_us})")
    runner.assert_true(trim_engine.servo_right_us == 1450,
                       f"Negative trim: right servo PWM == 1450 us (got {trim_engine.servo_right_us})")

    # 9.4 Combined Pitch + Roll Trim Mixing
    # Steer = +50% (+12.5 deg, +250 us), Trim = -10% (-2.5 deg, -50 us)
    # Left = 12.5 - (-2.5) = +15.0 deg, Right = 12.5 + (-2.5) = +10.0 deg
    # Left PWM = 1500 + 250 - (-50) = 1800 us, Right PWM = 1500 + 250 + (-50) = 1700 us
    trim_engine.set_roll_trim(-10.0)
    trim_engine.last_packet_time_ms = 50
    trim_engine.target_steer_pct = 50.0
    trim_engine.current_steer_pct = 50.0
    trim_engine.update_step(current_time_ms=50, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_left_deg - 15.0) < 1e-3,
                       f"Combined pitch+trim: left elevon == 15.0 deg (got {trim_engine.elevon_left_deg:.2f})")
    runner.assert_true(abs(trim_engine.elevon_right_deg - 10.0) < 1e-3,
                       f"Combined pitch+trim: right elevon == 10.0 deg (got {trim_engine.elevon_right_deg:.2f})")
    runner.assert_true(trim_engine.servo_left_us == 1800,
                       f"Combined pitch+trim: left servo == 1800 us (got {trim_engine.servo_left_us})")
    runner.assert_true(trim_engine.servo_right_us == 1700,
                       f"Combined pitch+trim: right servo == 1700 us (got {trim_engine.servo_right_us})")

    # 9.5 Combined Pitch + Roll Trim Saturation Clamping
    # Positive Saturation Clamping
    # Steer = +90% (+22.5 deg, +450 us), Trim = +20% (+5.0 deg, +100 us)
    # Right unclamped: 22.5 + 5.0 = 27.5 deg (> 25.0 max) -> Clamped to 25.0 deg
    # Right PWM unclamped: 1500 + 450 + 100 = 2050 us (> 2000 max) -> Clamped to 2000 us
    # Left unclamped: 22.5 - 5.0 = 17.5 deg (< 25.0 max) -> 17.5 deg
    # Left PWM unclamped: 1500 + 450 - 100 = 1850 us -> 1850 us
    trim_engine.set_roll_trim(20.0)
    trim_engine.last_packet_time_ms = 60
    trim_engine.target_steer_pct = 90.0
    trim_engine.current_steer_pct = 90.0
    trim_engine.update_step(current_time_ms=60, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_right_deg - 25.0) < 1e-3,
                       f"Positive saturation: right elevon clamped to +25.0 deg (got {trim_engine.elevon_right_deg:.2f})")
    runner.assert_true(trim_engine.servo_right_us == 2000,
                       f"Positive saturation: right servo clamped to 2000 us (got {trim_engine.servo_right_us})")
    runner.assert_true(abs(trim_engine.elevon_left_deg - 17.5) < 1e-3,
                       f"Positive saturation: left elevon at 17.5 deg (got {trim_engine.elevon_left_deg:.2f})")
    runner.assert_true(trim_engine.servo_left_us == 1850,
                       f"Positive saturation: left servo at 1850 us (got {trim_engine.servo_left_us})")

    # Negative Saturation Clamping
    # Steer = -90% (-22.5 deg, -450 us), Trim = +20% (+5.0 deg, +100 us)
    # Left unclamped: -22.5 - 5.0 = -27.5 deg (< -25.0 min) -> Clamped to -25.0 deg
    # Left PWM unclamped: 1500 - 450 - 100 = 950 us (< 1000 min) -> Clamped to 1000 us
    # Right unclamped: -22.5 + 5.0 = -17.5 deg (> -25.0 min) -> -17.5 deg
    # Right PWM unclamped: 1500 - 450 + 100 = 1150 us -> 1150 us
    trim_engine.set_roll_trim(20.0)
    trim_engine.last_packet_time_ms = 70
    trim_engine.target_steer_pct = -90.0
    trim_engine.current_steer_pct = -90.0
    trim_engine.update_step(current_time_ms=70, dt_sec=0.010)
    runner.assert_true(abs(trim_engine.elevon_left_deg - (-25.0)) < 1e-3,
                       f"Negative saturation: left elevon clamped to -25.0 deg (got {trim_engine.elevon_left_deg:.2f})")
    runner.assert_true(trim_engine.servo_left_us == 1000,
                       f"Negative saturation: left servo clamped to 1000 us (got {trim_engine.servo_left_us})")
    runner.assert_true(abs(trim_engine.elevon_right_deg - (-17.5)) < 1e-3,
                       f"Negative saturation: right elevon at -17.5 deg (got {trim_engine.elevon_right_deg:.2f})")
    runner.assert_true(trim_engine.servo_right_us == 1150,
                       f"Negative saturation: right servo at 1150 us (got {trim_engine.servo_right_us})")

    # ------------------------------------------------------------------------
    # Final Summary Report
    # ------------------------------------------------------------------------
    print("\n" + "=" * 78)
    print("VERIFICATION SUITE SUMMARY REPORT")
    print("=" * 78)
    print(f"Total Tests Run: {runner.tests_run}")
    print(f"Passed:          {runner.passed}")
    print(f"Failed:          {runner.failed}")
    print(f"Pass Rate:       {(runner.passed / runner.tests_run * 100.0):.1f}%")
    print("-" * 78)
    print("Performance & Constraint Verification:")
    print(f"  [x] Bilateral Deadband:          +/- 3.5 deg (Confirmed zero response)")
    print(f"  [x] Cubic Expo Blending:        alpha = 0.45 (Confirmed high vernier center)")
    print(f"  [x] Slew Rate Limiter:          400 %/s (Confirmed structural protection)")
    print(f"  [x] Packet Loss Failsafe:       100ms soft decay / 300ms hard disarm (Confirmed)")
    print(f"  [x] 16-Byte BLE Command Frame:  0xAA55 header + CRC-16-CCITT validated")
    print(f"  [x] Update Rates:               50 - 100 Hz (at 7.5 - 15.0 ms connection interval)")
    print(f"  [x] Latency Budget:             {typ_total:.1f}ms typ (<20ms) / {wst_total:.1f}ms worst (<50ms)")
    print(f"  [x] IMU Centripetal Limit:      {ac_3000_rpm:.2f}g at 3000 RPM (<= 5.03g on +/-16g scale)")
    print(f"  [x] Launch State Machine:       Stationary -> Arming -> Release -> Flight -> Impact")
    print(f"  [x] Elevon Roll Trim Mixing:    +/- 25 deg saturation clamp / [1000, 2000] us PWM")
    print("=" * 78)

    if runner.failed == 0:
        print("\nALL VERIFICATION TESTS PASSED SUCCESSFULLY! (Milestone M2 Fully Compliant)")
        return True
    else:
        print(f"\nVERIFICATION FAILED: {runner.failed} test(s) failed.")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
