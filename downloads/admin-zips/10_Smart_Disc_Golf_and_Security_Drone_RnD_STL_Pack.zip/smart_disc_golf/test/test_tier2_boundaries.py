"""Smart Disc Golf Steerable Driver System - Tier 2: Boundary & Corner Cases Test Suite.

Validates boundary conditions, physical extremities, environmental extremes,
and corner cases as specified in PROJECT.md and the E2E verification matrix:
1. Zero spin launch (0 RPM - complete loss of gyroscopic stiffness)
2. Overspeed spin limit (3500 RPM - extreme angular momentum)
3. Gale-force headwind/airspeed (35 m/s - maximum dynamic pressure)
4. Near-stall low launch velocity (12 m/s - minimum aerodynamic authority)
5. Extreme smartphone roll tilt (+/-90 deg - complete lateral orientation)
6. Packet loss dropout bursts (50ms, 100ms, 250ms dropout evaluation)
7. Battery voltage near UVLO cutoff boundary (2.81V vs 2.79V)
8. Docking cradle lateral misalignments (0mm to 15mm offset sweep)
9. Catastrophic 150G deceleration impact shock
"""

import math
import struct
import unittest

from smart_disc_golf.test.disc_physics import (
    RHO_AIR,
    GRAVITY,
    DISC_MASS,
    DISC_RADIUS,
    DISC_IZZ,
    DISC_IXX,
    MODULE_MASS,
    BearingKinematics,
    VentralKeelAero,
    MicroElevonsAero,
    LinearServoModel,
    TrajectorySim6DOF,
    BLECommandPacket,
    MotionMappingEngine,
    FailsafeController,
    LiHVBatterySubsystem,
    QiWirelessChargingSystem,
    MechanicalMassBalance,
    InjectionMoldingTransition,
)


class TestTier2Boundaries(unittest.TestCase):
    """Tier 2: Boundary and Corner Case Verification."""

    # ------------------------------------------------------------------------
    # 1. Zero Spin (0 RPM) Launch Dynamics
    # ------------------------------------------------------------------------
    def test_b01_zero_spin_lack_of_gyroscopic_rigidity(self):
        """Verify at 0 RPM, angular momentum L=0, precluding gyroscopic roll precession."""
        spin_rpm = 0.0
        omega_z = spin_rpm * (2.0 * math.pi / 60.0)
        angular_momentum = DISC_IZZ * omega_z
        self.assertEqual(angular_momentum, 0.0)
        # At zero spin, gyroscopic precession equation has zero denominator;
        # any pitching moment causes direct pitching acceleration without roll banking
        res = TrajectorySim6DOF.simulate_flight(spin_rpm=0.0, steer_command="RIGHT", duration=1.0)
        # Without roll banking, lateral deflection should be near zero
        self.assertAlmostEqual(res["final_y"], 0.0, delta=0.5)

    def test_b02_zero_spin_bearing_friction(self):
        """Verify bearing friction at 0 RPM is at minimal static/boundary level."""
        torque = BearingKinematics.friction_torque(0.0)
        self.assertLessEqual(torque, 0.00020)
        self.assertGreater(torque, 0.0)

    # ------------------------------------------------------------------------
    # 2. Maximum Spin (3500 RPM) Overspeed
    # ------------------------------------------------------------------------
    def test_b03_overspeed_angular_momentum_and_reduced_precession_rate(self):
        """Verify at 3500 RPM overspeed, high angular momentum reduces precession rate for same torque."""
        rpm_nominal = 2000.0
        rpm_overspeed = 3500.0
        l_nominal = DISC_IZZ * (rpm_nominal * 2.0 * math.pi / 60.0)
        l_overspeed = DISC_IZZ * (rpm_overspeed * 2.0 * math.pi / 60.0)

        self.assertGreater(l_overspeed, l_nominal)
        self.assertAlmostEqual(l_overspeed / l_nominal, 1.75, places=2)

        # Same pitch torque produces proportionally lower precession rate
        tau_y = -0.035
        p_nominal = - tau_y / l_nominal
        p_overspeed = - tau_y / l_overspeed
        self.assertLess(p_overspeed, p_nominal)
        self.assertAlmostEqual(p_nominal / p_overspeed, 1.75, places=2)

    def test_b04_overspeed_centripetal_acceleration_at_imu(self):
        """Verify at 3500 RPM overspeed with r=0.5mm, centripetal acceleration remains under 7.0g."""
        omega = 3500.0 * (2.0 * math.pi / 60.0)
        a_centripetal = (omega ** 2) * 0.0005
        a_g = a_centripetal / GRAVITY
        self.assertLess(a_g, 7.0)
        # Must be well below the 20,000g IMU limit
        self.assertLess(a_g, 20000.0 * 0.001)

    def test_b05_overspeed_unbalance_force_at_3500_rpm(self):
        """Verify dynamic unbalance force at 3500 RPM with Delta_r=0.05mm is <= 0.235 N."""
        f_unbal = MechanicalMassBalance.dynamic_unbalance_force(
            mass_kg=0.035, rpm=3500.0, eccentricity_m=0.00005
        )
        self.assertLessEqual(f_unbal, 0.240)
        self.assertAlmostEqual(f_unbal, 0.235, delta=0.01)

    # ------------------------------------------------------------------------
    # 3. High Wind / Gale (35 m/s) Airspeed
    # ------------------------------------------------------------------------
    def test_b06_gale_wind_dynamic_pressure_and_control_authority(self):
        """Verify at 35 m/s gale airspeed, dynamic pressure reaches ~750 Pa and elevon moment increases."""
        airspeed = 35.0
        q = 0.5 * RHO_AIR * (airspeed ** 2)
        self.assertAlmostEqual(q, 750.31, places=1)

        m_nominal = MicroElevonsAero.pitching_moment(25.0, 18.0)
        m_gale = MicroElevonsAero.pitching_moment(35.0, 18.0)
        # Moment scales as (35/25)^2 = 1.96
        self.assertAlmostEqual(m_gale / m_nominal, 1.96, places=2)

    def test_b07_gale_wind_keel_restoring_torque(self):
        """Verify keel alignment moment at 35 m/s scales up to >0.060 N*m/rad."""
        gradient_gale = VentralKeelAero.restoring_torque_gradient(airspeed=35.0)
        self.assertGreater(gradient_gale, 0.060)

    # ------------------------------------------------------------------------
    # 4. Near-Stall Launch (12 m/s Low Velocity)
    # ------------------------------------------------------------------------
    def test_b08_near_stall_low_velocity_authority(self):
        """Verify at 12 m/s, dynamic pressure drops to ~88 Pa, reducing control torque proportionally."""
        airspeed = 12.0
        q = 0.5 * RHO_AIR * (airspeed ** 2)
        self.assertAlmostEqual(q, 88.2, places=1)
        m_stall = abs(MicroElevonsAero.pitching_moment(12.0, 18.0))
        self.assertLess(m_stall, 0.015)
        self.assertGreater(m_stall, 0.005)

    def test_b09_near_stall_keel_lock_in_time(self):
        """Verify at 12 m/s, alignment time remains bounded (<130 ms)."""
        t_lock = VentralKeelAero.lock_in_time_ms(airspeed=12.0)
        self.assertLess(t_lock, 130.0)
        self.assertGreater(t_lock, 80.0)

    # ------------------------------------------------------------------------
    # 5. Extreme Phone Roll Tilts (+/-90 deg)
    # ------------------------------------------------------------------------
    def test_b10_extreme_roll_tilt_saturation(self):
        """Verify phone held completely sideways (+/-90 deg) cleanly saturates to exactly +/-100 demand."""
        mapper = MotionMappingEngine()
        for angle in [+90.0, +89.9, +75.0, -90.0, -89.9, -75.0]:
            demand = mapper.map_roll_to_demand(angle)
            if angle > 0:
                self.assertAlmostEqual(demand, +100.0)
            else:
                self.assertAlmostEqual(demand, -100.0)

    def test_b11_extreme_roll_tilt_packet_encoding(self):
        """Verify packet struct encodes +/-90 deg without overflow or sign distortion."""
        pkt_pos = BLECommandPacket(sequence_id=10, timestamp_ms=1000, roll_angle_deg=+90.0, pitch_angle_deg=0.0, steer_demand=100)
        pkt_neg = BLECommandPacket(sequence_id=11, timestamp_ms=1020, roll_angle_deg=-90.0, pitch_angle_deg=0.0, steer_demand=-100)

        dec_pos = BLECommandPacket.unpack(pkt_pos.pack())
        dec_neg = BLECommandPacket.unpack(pkt_neg.pack())

        self.assertIsNotNone(dec_pos)
        self.assertIsNotNone(dec_neg)
        self.assertAlmostEqual(dec_pos.roll_angle_deg, +90.0)
        self.assertAlmostEqual(dec_neg.roll_angle_deg, -90.0)
        self.assertEqual(dec_pos.steer_demand, 100)
        self.assertEqual(dec_neg.steer_demand, -100)

    # ------------------------------------------------------------------------
    # 6. Packet Loss Bursts (50ms, 100ms, 250ms)
    # ------------------------------------------------------------------------
    def test_b12_packet_loss_burst_50ms(self):
        """Verify 50ms packet burst loss does NOT trigger failsafe disarm."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=0.0, has_valid_packet=True)
        # Drop packets for 50 ms
        for t_ms in [10.0, 20.0, 30.0, 40.0, 50.0]:
            status = failsafe.update(current_time_ms=t_ms, has_valid_packet=False)
            self.assertFalse(failsafe.is_failsafe_active)

    def test_b13_packet_loss_boundary_100ms(self):
        """Verify exactly 100ms boundary: disarms at 100.1ms."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=0.0, has_valid_packet=True)
        failsafe.update(current_time_ms=99.9, has_valid_packet=False)
        self.assertFalse(failsafe.is_failsafe_active)
        failsafe.update(current_time_ms=100.1, has_valid_packet=False)
        self.assertTrue(failsafe.is_failsafe_active)

    def test_b14_packet_loss_prolonged_dropout_250ms(self):
        """Verify prolonged 250ms dropout locks elevons at neutral (0 demand) throughout."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=0.0, has_valid_packet=True)
        failsafe.update(current_time_ms=150.0, has_valid_packet=False)
        self.assertTrue(failsafe.is_failsafe_active)
        demand = failsafe.update(current_time_ms=250.0, has_valid_packet=False)
        self.assertEqual(demand, 0.0)
        self.assertTrue(failsafe.is_failsafe_active)

    def test_b14b_packet_loss_16bit_timer_rollover(self):
        """Verify 16-bit millisecond counter rollover (65535 -> 0) triggers failsafe at >100ms elapsed."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=65500.0, has_valid_packet=True)
        # 50ms elapsed across rollover (65500 -> 14): should NOT trigger failsafe
        failsafe.update(current_time_ms=14.0, has_valid_packet=False)
        self.assertFalse(failsafe.is_failsafe_active)
        # 120ms elapsed across rollover (65500 -> 84): MUST trigger failsafe
        demand = failsafe.update(current_time_ms=84.0, has_valid_packet=False)
        self.assertTrue(failsafe.is_failsafe_active)
        self.assertEqual(demand, 0.0)

    # ------------------------------------------------------------------------
    # 7. Battery Voltage Near UVLO Boundary (2.81V vs 2.79V)
    # ------------------------------------------------------------------------
    def test_b15_battery_voltage_marginal_above_uvlo(self):
        """Verify at 2.81V (marginal above 2.80V), UVLO is NOT tripped."""
        self.assertFalse(LiHVBatterySubsystem.is_uvlo_triggered(2.81))

    def test_b16_battery_voltage_marginal_below_uvlo(self):
        """Verify at 2.79V (marginal below 2.80V), UVLO IS tripped."""
        self.assertTrue(LiHVBatterySubsystem.is_uvlo_triggered(2.79))

    # ------------------------------------------------------------------------
    # 8. Docking Coil Lateral Offsets (0mm to 15mm Sweep)
    # ------------------------------------------------------------------------
    def test_b17_docking_alignment_sweep(self):
        """Verify magnetic snap force and coupling across 0mm to 15mm offsets."""
        # 0mm: perfect alignment
        f_0 = QiWirelessChargingSystem.magnetic_snap_force(0.0)
        self.assertAlmostEqual(f_0, 3.2, places=1)

        # 1.5mm: edge of self-centering chamfer
        f_1_5 = QiWirelessChargingSystem.magnetic_snap_force(1.5)
        self.assertGreater(f_1_5, 1.0)

        # 5.0mm: air gap limit
        f_5 = QiWirelessChargingSystem.magnetic_snap_force(5.0)
        self.assertGreater(f_5, 0.25)

        # 15.0mm: far away, snap force effectively zero
        f_15 = QiWirelessChargingSystem.magnetic_snap_force(15.0)
        self.assertLess(f_15, 0.10)

    # ------------------------------------------------------------------------
    # 9. 150G Catastrophic Impact Shock
    # ------------------------------------------------------------------------
    def test_b18_catastrophic_150g_impact_shear(self):
        """Verify structural survivability under 150G catastrophic impact shock."""
        sf_150g = MechanicalMassBalance.impact_shear_safety_factor(g_shock=150.0)
        # Must maintain safety factor > 100 even under 150G
        self.assertGreater(sf_150g, 100.0)
        self.assertAlmostEqual(sf_150g, 227.0 * (100.0 / 150.0), delta=5.0)


if __name__ == "__main__":
    unittest.main()
