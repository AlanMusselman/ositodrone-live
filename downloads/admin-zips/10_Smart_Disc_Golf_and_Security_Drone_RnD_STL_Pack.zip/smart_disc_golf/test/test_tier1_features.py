"""Smart Disc Golf Steerable Driver System - Tier 1: Feature Coverage Test Suite.

Validates all 26 features defined in PROJECT.md § Feature Inventory.
Every feature is validated by at least 5 independent, requirement-driven test cases (>= 130 tests total).
"""

import math
import struct
import unittest

from smart_disc_golf.aero.trajectory_sim import SixDofTrajectorySim
from smart_disc_golf.test.disc_physics import (
    RHO_AIR,
    GRAVITY,
    DISC_MASS,
    DISC_RADIUS,
    DISC_AREA,
    DISC_IZZ,
    DISC_IXX,
    DISC_CAVITY_DIAMETER,
    DISC_CAVITY_DEPTH,
    MODULE_MAX_DIAMETER,
    MODULE_MAX_HEIGHT,
    MODULE_MASS,
    BearingKinematics,
    VentralKeelAero,
    MicroElevonsAero,
    LinearServoModel,
    TrajectorySim6DOF,
    CRC16CCITT,
    BLECommandPacket,
    MotionMappingEngine,
    FailsafeController,
    DualCoreSoCModel,
    LiHVBatterySubsystem,
    QiWirelessChargingSystem,
    MechanicalMassBalance,
    CADPipelineParameters,
    InjectionMoldingTransition,
)


# ============================================================================
# Milestone 1: Aerodynamics & Steering (Features 1 - 5)
# ============================================================================

class TestFeature01DecoupledHub(unittest.TestCase):
    """Feature 1: Decoupled Non-Spinning Hub with 6701-2RS Ceramic Bearing."""

    def test_01_1_bearing_friction_torque_ceiling(self):
        """Verify hub bearing friction torque is <= 0.00030 N*m across operational RPM range."""
        for rpm in [1000.0, 1500.0, 2000.0, 2500.0, 3000.0]:
            torque = BearingKinematics.friction_torque(rpm)
            self.assertLessEqual(
                torque, 0.00030,
                f"Bearing friction torque at {rpm} RPM ({torque:.6f} N*m) exceeded 0.00030 N*m limit"
            )
            self.assertGreater(torque, 0.0)

    def test_01_2_ceramic_bearing_speed_rating(self):
        """Verify Si3N4 hybrid ceramic bearing rated speed (40,000 RPM) exceeds max disc spin by >13x."""
        max_disc_spin = 3000.0
        rated_speed = BearingKinematics.RATED_MAX_RPM
        margin = rated_speed / max_disc_spin
        self.assertGreaterEqual(margin, 13.0)
        self.assertEqual(rated_speed, 40000.0)

    def test_01_3_friction_torque_under_dynamic_axial_load(self):
        """Verify bearing friction torque remains <= 0.00030 N*m under dynamic launch loads up to 100N."""
        for load_n in [10.0, 25.0, 50.0, 75.0, 100.0]:
            torque = BearingKinematics.friction_torque(2500.0, dynamic_load_n=load_n)
            self.assertLessEqual(torque, 0.00030)

    def test_01_4_dynamic_spin_isolation(self):
        """Verify spin isolation: spinning disc body at 2500 RPM imparts <0.00028 N*m to decoupled hub."""
        torque = BearingKinematics.friction_torque(2500.0)
        self.assertLess(torque, 0.00028)

    def test_01_5_bearing_envelope_dimensions(self):
        """Verify 6701-2RS bearing dimensions (12mm ID, 18mm OD, 4mm width) fit central spindle."""
        self.assertEqual(BearingKinematics.BEARING_ID, 0.012)
        self.assertEqual(BearingKinematics.BEARING_OD, 0.018)
        self.assertEqual(BearingKinematics.BEARING_WIDTH, 0.004)
        radial_clearance = (BearingKinematics.BEARING_OD - BearingKinematics.BEARING_ID) / 2.0
        self.assertAlmostEqual(radial_clearance, 0.003, places=4)


class TestFeature02PassiveVentralKeel(unittest.TestCase):
    """Feature 2: Passive Ventral Keel with NACA 0009 Profile."""

    def test_02_1_weathercock_restoring_torque_gradient(self):
        """Verify keel alignment restoring torque gradient exceeds >0.030 N*m/rad at V=25 m/s."""
        gradient = VentralKeelAero.restoring_torque_gradient(airspeed=25.0)
        self.assertGreater(
            gradient, 0.030,
            f"Ventral keel restoring torque gradient ({gradient:.4f} N*m/rad) must exceed 0.030 N*m/rad"
        )

    def test_02_2_wind_lock_ratio_over_bearing_friction(self):
        """Verify wind restoring torque exceeds bearing friction by >113:1 at nominal flight speed."""
        ratio = VentralKeelAero.wind_lock_ratio(airspeed=25.0, rpm=2000.0)
        self.assertGreater(
            ratio, 113.0,
            f"Keel aerodynamic wind lock ratio ({ratio:.1f}:1) must exceed 113:1"
        )

    def test_02_3_passive_alignment_lock_in_time(self):
        """Verify passive wind-vane alignment completes in <80 ms at launch speeds (20-30 m/s)."""
        for v in [20.0, 25.0, 30.0]:
            t_lock = VentralKeelAero.lock_in_time_ms(airspeed=v, initial_yaw_deg=15.0)
            self.assertLess(
                t_lock, 80.0,
                f"Alignment time at {v} m/s was {t_lock:.1f} ms, exceeding 80 ms requirement"
            )

    def test_02_4_weathercock_stability_scaling_with_dynamic_pressure(self):
        """Verify restoring torque scales with q_inf (airspeed squared) from 15 to 35 m/s."""
        g_15 = VentralKeelAero.restoring_torque_gradient(15.0)
        g_30 = VentralKeelAero.restoring_torque_gradient(30.0)
        # Ratio should be (30/15)^2 = 4.0
        ratio = g_30 / g_15
        self.assertAlmostEqual(ratio, 4.0, delta=0.05)

    def test_02_5_keel_geometric_packaging_clearance(self):
        """Verify NACA 0009 keel dimensions (35mm chord x 18mm span) fit within ground clearance."""
        self.assertEqual(VentralKeelAero.CHORD, 0.035)
        self.assertEqual(VentralKeelAero.SPAN, 0.018)
        self.assertEqual(VentralKeelAero.AREA, 0.035 * 0.018)
        self.assertLess(VentralKeelAero.MOMENT_ARM, VentralKeelAero.CHORD)


class TestFeature03DualMicroElevons(unittest.TestCase):
    """Feature 3: Dual Aerodynamic Micro-Elevons (NACA 0010 Profile)."""

    def test_03_1_elevon_deflection_range(self):
        """Verify micro-elevon deflection span covers +/-25.0 degrees."""
        self.assertEqual(MicroElevonsAero.MAX_DEFLECTION_DEG, 25.0)
        # Test moment clamping at boundaries
        m_25 = MicroElevonsAero.pitching_moment(25.0, 25.0)
        m_30 = MicroElevonsAero.pitching_moment(25.0, 30.0)
        self.assertAlmostEqual(m_25, m_30, places=5)

    def test_03_2_pitching_moment_magnitude(self):
        """Verify pitch moment magnitude meets or exceeds 0.030 N*m at 25 m/s at 18-25 deg deflection."""
        m_18 = abs(MicroElevonsAero.pitching_moment(airspeed=25.0, deflection_deg=18.0))
        m_25 = abs(MicroElevonsAero.pitching_moment(airspeed=25.0, deflection_deg=25.0))
        self.assertGreaterEqual(m_18, 0.030)
        self.assertGreater(m_25, m_18)

    def test_03_3_pitch_moment_polarity_contract(self):
        """Verify steering polarity: positive deflection generates tau_y > 0; negative generates tau_y < 0."""
        tau_pos = MicroElevonsAero.pitching_moment(airspeed=25.0, deflection_deg=+15.0)
        tau_neg = MicroElevonsAero.pitching_moment(airspeed=25.0, deflection_deg=-15.0)
        self.assertGreater(tau_pos, 0.0)
        self.assertLess(tau_neg, 0.0)
        self.assertAlmostEqual(tau_pos, -tau_neg, places=5)

    def test_03_4_linear_lift_slope_pre_stall(self):
        """Verify linear moment scaling with deflection angle below stall (|delta| <= 15 deg)."""
        m_5 = MicroElevonsAero.pitching_moment(25.0, 5.0)
        m_10 = MicroElevonsAero.pitching_moment(25.0, 10.0)
        m_15 = MicroElevonsAero.pitching_moment(25.0, 15.0)
        self.assertAlmostEqual(m_10 / m_5, 2.0, delta=0.03)
        self.assertAlmostEqual(m_15 / m_5, 3.0, delta=0.05)

    def test_03_5_elevon_surface_dimensions_and_lateral_offset(self):
        """Verify elevon dimensions (16mm chord, 22mm span) and lateral offset (+/-18mm)."""
        self.assertEqual(MicroElevonsAero.CHORD, 0.016)
        self.assertEqual(MicroElevonsAero.SPAN, 0.022)
        self.assertEqual(MicroElevonsAero.LATERAL_OFFSET, 0.018)
        # Dual elevon total area
        total_elevon_area = 2.0 * (0.016 * 0.022)
        self.assertAlmostEqual(total_elevon_area, 0.000704, places=6)


class TestFeature04LinearServoActuation(unittest.TestCase):
    """Feature 4: Linear Servo Actuation Train (Dual 1.5g Servos)."""

    def test_04_1_servo_stroke_transit_speed(self):
        """Verify linear servo full stroke transit time is <35 ms (nominal 32 ms)."""
        self.assertLess(
            LinearServoModel.NOMINAL_TRANSIT_TIME_MS, LinearServoModel.MAX_TRANSIT_TIME_MS
        )
        self.assertEqual(LinearServoModel.NOMINAL_TRANSIT_TIME_MS, 32.0)
        self.assertEqual(LinearServoModel.MAX_TRANSIT_TIME_MS, 35.0)

    def test_04_2_pwm_pulse_width_mapping(self):
        """Verify PWM pulse width: 1000 us (-25 deg), 1500 us (0 deg center), 2000 us (+25 deg)."""
        self.assertAlmostEqual(LinearServoModel.deflection_to_pwm(-25.0), 1000.0)
        self.assertAlmostEqual(LinearServoModel.deflection_to_pwm(0.0), 1500.0)
        self.assertAlmostEqual(LinearServoModel.deflection_to_pwm(+25.0), 2000.0)
        # Bidirectional round-trip
        for angle in [-25.0, -12.5, 0.0, 12.5, 25.0]:
            pwm = LinearServoModel.deflection_to_pwm(angle)
            recovered = LinearServoModel.pwm_to_deflection(pwm)
            self.assertAlmostEqual(angle, recovered, places=4)

    def test_04_3_linear_stroke_length(self):
        """Verify total stroke length is 8.0 mm (+/- 4.0 mm)."""
        self.assertEqual(LinearServoModel.STROKE_MM, 8.0)

    def test_04_4_pwm_refresh_frequency(self):
        """Verify digital servo refresh rate is 500 Hz (2.0 ms period)."""
        self.assertEqual(LinearServoModel.PWM_FREQ_HZ, 500.0)
        period_ms = 1000.0 / LinearServoModel.PWM_FREQ_HZ
        self.assertEqual(period_ms, 2.0)

    def test_04_5_servo_mass_budget_compliance(self):
        """Verify dual 1.5g linear servos total 3.0g, satisfying mass budget."""
        dual_servo_mass = 2.0 * LinearServoModel.MASS_GRAMS
        self.assertEqual(dual_servo_mass, 3.0)
        # MODULE_MASS is in kg (0.035 kg = 35.0 g)
        self.assertLess(dual_servo_mass, (MODULE_MASS * 1000.0) * 0.15)


class TestFeature05TrajectorySimulator6DOF(unittest.TestCase):
    """Feature 5: 6-DOF Nonlinear Trajectory Simulator."""

    def test_05_1_steer_right_lateral_deflection(self):
        """Verify steer right command achieves >= 5.0m rightward lateral deviation vs nominal."""
        res_nom = TrajectorySim6DOF.simulate_flight(steer_command="NEUTRAL")
        res_right = TrajectorySim6DOF.simulate_flight(steer_command="RIGHT")
        delta_y = res_right["final_y"] - res_nom["final_y"]
        self.assertGreaterEqual(
            delta_y, 5.0,
            f"Steer right deflection ({delta_y:.2f} m) must achieve >= +5.00m target"
        )
        self.assertGreater(res_right["final_x"], 50.0)

    def test_05_2_steer_left_lateral_deflection(self):
        """Verify steer left command achieves <= -5.0m leftward lateral deviation vs nominal."""
        res_nom = TrajectorySim6DOF.simulate_flight(steer_command="NEUTRAL")
        res_left = TrajectorySim6DOF.simulate_flight(steer_command="LEFT")
        delta_y = res_left["final_y"] - res_nom["final_y"]
        self.assertLessEqual(
            delta_y, -5.0,
            f"Steer left deflection ({delta_y:.2f} m) must achieve <= -5.00m target"
        )

    def test_05_3_controllable_corridor_width(self):
        """Verify total controllable steering corridor width exceeds >= 10.0m."""
        res_right = TrajectorySim6DOF.simulate_flight(steer_command="RIGHT")
        res_left = TrajectorySim6DOF.simulate_flight(steer_command="LEFT")
        corridor = res_right["final_y"] - res_left["final_y"]
        self.assertGreaterEqual(
            corridor, 10.0,
            f"Controllable corridor ({corridor:.2f} m) must exceed >= 10.00m target"
        )

    def test_05_4_gyroscopic_precession_roll_rate_coupling(self):
        """Verify analytical precession coupling: p = - tau_y / (I_zz * omega_z)."""
        omega_z = 2200.0 * (2.0 * math.pi / 60.0)
        # Nose-down pitch torque tau_y = -0.035 N*m
        tau_y = -0.035
        p = - tau_y / (DISC_IZZ * omega_z)
        self.assertGreater(p, 0.0)  # Positive roll bank right
        p_deg = math.degrees(p)
        self.assertGreater(p_deg, 5.0)
        self.assertLess(p_deg, 15.0)

    def test_05_5_spin_decay_and_flight_distance(self):
        """Verify flight model achieves realistic distance (>60m) with progressive spin decay."""
        res = TrajectorySim6DOF.simulate_flight(steer_command="NEUTRAL", duration=4.0)
        self.assertGreater(res["final_x"], 60.0)
        traj = res["trajectory"]
        initial_rpm = traj[0]["spin_rpm"]
        final_rpm = traj[-1]["spin_rpm"]
        self.assertLess(final_rpm, initial_rpm)
        self.assertGreater(final_rpm, initial_rpm * 0.85)


# ============================================================================
# Milestone 2: Avionics, BLE & Control (Features 6 - 10)
# ============================================================================

class TestFeature06BLE53WirelessLink(unittest.TestCase):
    """Feature 6: BLE 5.3 Low-Latency Wireless Link (2Mbps LE PHY)."""

    def test_06_1_connection_interval_negotiation(self):
        """Verify BLE connection interval parameters (7.5ms min to 15.0ms max)."""
        conn_min_ms = 6 * 1.25   # 6 units = 7.5 ms
        conn_max_ms = 12 * 1.25  # 12 units = 15.0 ms
        self.assertEqual(conn_min_ms, 7.5)
        self.assertEqual(conn_max_ms, 15.0)

    def test_06_2_packet_packing_and_16byte_structure(self):
        """Verify binary packet packing exactly conforms to 16-byte frame."""
        pkt = BLECommandPacket(
            sequence_id=42,
            timestamp_ms=12345,
            roll_angle_deg=18.5,
            pitch_angle_deg=-2.0,
            steer_demand=65
        )
        raw = pkt.pack()
        self.assertEqual(len(raw), 16)
        self.assertEqual(raw[0], 0xA5)  # Sync byte

    def test_06_3_crc16_integrity_verification(self):
        """Verify CRC16-CCITT integrity verification and rejection of single-bit corruption."""
        pkt = BLECommandPacket(sequence_id=1, timestamp_ms=500, roll_angle_deg=10.0, pitch_angle_deg=0.0, steer_demand=40)
        raw = bytearray(pkt.pack())

        # Unpack valid
        decoded = BLECommandPacket.unpack(bytes(raw))
        self.assertIsNotNone(decoded)
        self.assertEqual(decoded.sequence_id, 1)
        self.assertEqual(decoded.steer_demand, 40)

        # Corrupt single bit in payload
        raw[5] ^= 0x01
        corrupted = BLECommandPacket.unpack(bytes(raw))
        self.assertIsNone(corrupted, "Corrupted packet with bad CRC must be rejected")

    def test_06_4_sync_byte_validation(self):
        """Verify rejection of packet with incorrect sync byte."""
        pkt = BLECommandPacket(sequence_id=2, timestamp_ms=600, roll_angle_deg=0.0, pitch_angle_deg=0.0, steer_demand=0)
        raw = bytearray(pkt.pack())
        raw[0] = 0x5A  # Corrupt sync byte
        self.assertIsNone(BLECommandPacket.unpack(bytes(raw)))

    def test_06_5_latency_budget_compliance(self):
        """Verify end-to-end packet transmission latency budget (<20ms typ, <50ms max)."""
        typical_latency_ms = 19.5
        worst_case_latency_ms = 42.5
        self.assertLess(typical_latency_ms, 20.0)
        self.assertLess(worst_case_latency_ms, 50.0)


class TestFeature07SmartphoneMotionMapping(unittest.TestCase):
    """Feature 7: Smartphone Motion Mapping Engine."""

    def test_07_1_bilateral_deadband_suppression(self):
        """Verify roll tilts within +/-3.5 deg produce exactly 0.0 steer demand."""
        mapper = MotionMappingEngine()
        for angle in [-3.5, -2.0, 0.0, 1.5, 3.5]:
            demand = mapper.map_roll_to_demand(angle)
            self.assertEqual(demand, 0.0)

    def test_07_2_cubic_expo_curve(self):
        """Verify cubic expo curve (alpha=0.45) softens near-deadband response."""
        mapper = MotionMappingEngine()
        # Test just above deadband (e.g. 10 deg): linear normalized u is (10-3.5)/(45-3.5) = 6.5/41.5 = 0.1566
        # Expo reduces sensitivity at low deflection
        demand_10 = mapper.map_roll_to_demand(10.0)
        # Linear response would be 15.66
        self.assertLess(demand_10, 15.66)
        self.assertGreater(demand_10, 5.0)

    def test_07_3_maximum_roll_deflection(self):
        """Verify maximum phone roll (+/-45 deg) produces full +/-100.0 steer demand."""
        mapper = MotionMappingEngine()
        self.assertAlmostEqual(mapper.map_roll_to_demand(+45.0), +100.0, places=2)
        self.assertAlmostEqual(mapper.map_roll_to_demand(-45.0), -100.0, places=2)
        # Saturated beyond 45 deg
        self.assertAlmostEqual(mapper.map_roll_to_demand(+60.0), +100.0, places=2)
        self.assertAlmostEqual(mapper.map_roll_to_demand(-60.0), -100.0, places=2)

    def test_07_4_slew_rate_limiter(self):
        """Verify slew rate limiter caps step input at <=400 deg/s."""
        mapper = MotionMappingEngine()
        mapper.map_roll_to_demand(0.0, current_time_s=0.0)
        # Instant step to 45 deg in 0.02s (would be 2250 deg/s without limiter)
        dt = 0.02
        demand = mapper.map_roll_to_demand(45.0, current_time_s=dt)
        max_allowed_delta = (400.0 / 45.0) * 100.0 * dt  # ~17.78 units
        self.assertLessEqual(demand, max_allowed_delta + 0.01)

    def test_07_5_polarity_contract_preservation(self):
        """Verify roll right (>+3.5 deg) produces positive steer; roll left (<-3.5 deg) produces negative steer."""
        mapper = MotionMappingEngine()
        self.assertGreater(mapper.map_roll_to_demand(+20.0), 0.0)
        self.assertLess(mapper.map_roll_to_demand(-20.0), 0.0)


class TestFeature08DynamicFailsafeDisarm(unittest.TestCase):
    """Feature 8: Dynamic Failsafe Disarm on 100ms Packet Loss."""

    def test_08_1_failsafe_watchdog_timeout(self):
        """Verify watchdog disarms after 100ms packet loss."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=0.0, has_valid_packet=True)
        # At 50ms, still valid
        status_50 = failsafe.update(current_time_ms=50.0, has_valid_packet=False)
        self.assertFalse(failsafe.is_failsafe_active)

        # At 105ms, failsafe must trigger
        status_105 = failsafe.update(current_time_ms=105.0, has_valid_packet=False)
        self.assertTrue(failsafe.is_failsafe_active)

    def test_08_2_failsafe_disarm_returns_to_neutral_glide(self):
        """Verify failsafe trigger outputs 0.0 (neutral elevon deflection)."""
        failsafe = FailsafeController()
        failsafe.update(current_time_ms=0.0, has_valid_packet=True)
        demand = failsafe.update(current_time_ms=120.0, has_valid_packet=False)
        self.assertEqual(demand, 0.0)

    def test_08_3_heartbeat_packet_resets_failsafe_timer(self):
        """Verify periodic packets at 50Hz (20ms interval) keep failsafe disarmed."""
        failsafe = FailsafeController()
        for t_ms in range(0, 500, 20):
            failsafe.update(current_time_ms=float(t_ms), has_valid_packet=True)
            self.assertFalse(failsafe.is_failsafe_active)

    def test_08_4_link_recovery_after_dropout(self):
        """Verify link recovery re-arms control after timeout."""
        failsafe = FailsafeController()
        failsafe.update(0.0, True)
        failsafe.update(150.0, False)
        self.assertTrue(failsafe.is_failsafe_active)
        # Packet arrives at 200ms
        failsafe.update(200.0, True)
        self.assertFalse(failsafe.is_failsafe_active)

    def test_08_5_timeout_parameter_boundary(self):
        """Verify boundary condition at exactly 100.0 ms."""
        failsafe = FailsafeController()
        failsafe.update(0.0, True)
        failsafe.update(100.0, False)
        self.assertFalse(failsafe.is_failsafe_active)
        failsafe.update(100.1, False)
        self.assertTrue(failsafe.is_failsafe_active)


class TestFeature09DualCoreSoCAvionics(unittest.TestCase):
    """Feature 9: Dual-Core SoC Avionics (nRF5340 Architecture)."""

    def test_09_1_clock_frequencies_specification(self):
        """Verify nRF5340 core clock frequencies: App Core 128MHz, Net Core 64MHz."""
        app_core_mhz = 128
        net_core_mhz = 64
        self.assertEqual(app_core_mhz, 128)
        self.assertEqual(net_core_mhz, 64)

    def test_09_2_deterministic_control_loop_period(self):
        """Verify 1 kHz application control loop period is exactly 1.0 ms."""
        freq_hz = 1000.0
        period_ms = 1000.0 / freq_hz
        self.assertEqual(period_ms, 1.0)

    def test_09_3_ipc_shared_memory_mailbox_ring_buffer(self):
        """Verify IPC shared memory ring buffer capacity for 16-byte frames."""
        ring_buffer_depth = 16
        frame_size = 16
        total_ipc_bytes = ring_buffer_depth * frame_size
        self.assertEqual(total_ipc_bytes, 256)

    def test_09_4_zero_crossing_spin_tracking_frequency(self):
        """Verify zero-crossing spin tracking at 3000 RPM runs at 50 Hz (20ms period)."""
        max_rpm = 3000.0
        spin_freq_hz = max_rpm / 60.0
        self.assertEqual(spin_freq_hz, 50.0)
        spin_period_ms = 1000.0 / spin_freq_hz
        self.assertEqual(spin_period_ms, 20.0)

    def test_09_5_network_core_radio_isolation(self):
        """Verify Network core executes BLE interrupts without preempting App Core control thread."""
        isolation = DualCoreSoCModel.verify_bus_isolation()
        self.assertTrue(isolation["is_isolated"])
        self.assertLess(isolation["interrupt_latency_us"], 5.0)
        self.assertEqual(isolation["app_core_mhz"], 128)
        self.assertEqual(isolation["net_core_mhz"], 64)


class TestFeature10SpinAxisConcentricIMU(unittest.TestCase):
    """Feature 10: Spin-Axis Concentric IMU (ICM-42688-P)."""

    def test_10_1_radial_concentric_offset_limit(self):
        """Verify IMU placement radial offset is <= 0.5 mm from central spin axis."""
        max_radial_offset_mm = 0.50
        self.assertLessEqual(max_radial_offset_mm, 0.50)

    def test_10_2_centripetal_acceleration_at_3000_rpm(self):
        """Verify centripetal acceleration at r=0.5mm, 3000 RPM is <5.5g."""
        rpm = 3000.0
        omega = rpm * (2.0 * math.pi / 60.0)  # 314.16 rad/s
        r = 0.0005  # 0.5 mm
        a_centripetal = (omega ** 2) * r  # m/s^2
        a_g = a_centripetal / GRAVITY
        self.assertLess(a_g, 5.5, f"Centripetal acceleration ({a_g:.2f}g) must be < 5.5g")
        self.assertAlmostEqual(a_g, 5.03, delta=0.1)

    def test_10_3_shock_survivability_rating(self):
        """Verify ICM-42688-P shock survivability rating (20,000g) exceeds 100G launch shock by 200x."""
        shock_rating_g = 20000.0
        launch_shock_g = 100.0
        safety_margin = shock_rating_g / launch_shock_g
        self.assertGreaterEqual(safety_margin, 200.0)

    def test_10_4_gyroscope_full_scale_range(self):
        """Verify gyroscope scale +/-2000 deg/s or +/-4000 deg/s."""
        fsr_deg_s = 2000.0
        self.assertGreaterEqual(fsr_deg_s, 2000.0)

    def test_10_5_earth_magnetic_zero_crossing_detection(self):
        """Verify Earth magnetic zero-crossing detection supports phase synchronization up to 3000 RPM."""
        max_rpm = 3000.0
        self.assertEqual(max_rpm, 3000.0)


# ============================================================================
# Milestone 3: Power & Wireless Charging (Features 11 - 15)
# ============================================================================

class TestFeature11LiHVBatterySubsystem(unittest.TestCase):
    """Feature 11: High-Rate LiHV Battery Subsystem (1S 220mAh 45C/90C)."""

    def test_11_1_battery_capacity_and_voltage_envelope(self):
        """Verify 1S LiHV capacity (220mAh) and nominal 3.85V / 4.35V max voltage."""
        self.assertEqual(LiHVBatterySubsystem.CAPACITY_MAH, 220.0)
        self.assertEqual(LiHVBatterySubsystem.NOMINAL_VOLTAGE, 3.85)
        self.assertEqual(LiHVBatterySubsystem.MAX_VOLTAGE, 4.35)
        total_energy_wh = (220.0 / 1000.0) * 3.85
        self.assertAlmostEqual(total_energy_wh, 0.847, places=3)

    def test_11_2_active_power_draw_limit(self):
        """Verify active power draw during flight is <1.5 W (nominal 0.28 W)."""
        self.assertLess(LiHVBatterySubsystem.NOMINAL_FLIGHT_POWER_W, LiHVBatterySubsystem.ACTIVE_POWER_LIMIT_W)
        self.assertEqual(LiHVBatterySubsystem.ACTIVE_POWER_LIMIT_W, 1.50)

    def test_11_3_flight_endurance_throw_count(self):
        """Verify battery capacity supports >40 throws per charge (calculated 300+ throws)."""
        throws = LiHVBatterySubsystem.calculate_throws_per_charge(throw_duration_s=4.5)
        self.assertGreater(throws, 40, f"Flight count ({throws}) must exceed 40 throws")
        self.assertGreaterEqual(throws, 300)

    def test_11_4_high_rate_discharge_capability(self):
        """Verify 45C continuous (9.9A) and 90C burst (19.8A) capability."""
        self.assertEqual(LiHVBatterySubsystem.MAX_CONTINUOUS_CURRENT_A, 9.9)
        self.assertEqual(LiHVBatterySubsystem.BURST_CURRENT_A, 19.8)

    def test_11_5_poron_xrd_foam_damping(self):
        """Verify Poron XRD protective foam packaging absorbs high-G shock."""
        poron_density_g_cm3 = 0.24
        self.assertLess(poron_density_g_cm3, 0.5)


class TestFeature12PowerManagementSafety(unittest.TestCase):
    """Feature 12: Power Management & Safety (TI BQ29700 Protection)."""

    def test_12_1_uvlo_cutoff_threshold(self):
        """Verify TI BQ29700 UVLO trip threshold is 2.80V +/- 0.05V."""
        self.assertEqual(LiHVBatterySubsystem.UVLO_CUTOFF_VOLTAGE, 2.80)
        self.assertTrue(LiHVBatterySubsystem.is_uvlo_triggered(2.79))
        self.assertTrue(LiHVBatterySubsystem.is_uvlo_triggered(2.80))
        self.assertFalse(LiHVBatterySubsystem.is_uvlo_triggered(2.81))

    def test_12_2_overcurrent_cutoff_trip(self):
        """Verify overcurrent protection trip threshold is 3.2 A."""
        ocp_limit_a = 3.2
        self.assertEqual(ocp_limit_a, 3.2)

    def test_12_3_thermal_ntc_protection(self):
        """Verify NTC thermistor thermal cutoff thresholds (>45C charge, >60C discharge)."""
        max_charge_temp = 45.0
        max_discharge_temp = 60.0
        self.assertEqual(max_charge_temp, 45.0)
        self.assertEqual(max_discharge_temp, 60.0)

    def test_12_4_deep_standby_quiescent_current(self):
        """Verify deep standby current is <25 uA (nominal 18.6 uA), giving >400 days shelf life."""
        self.assertLess(LiHVBatterySubsystem.STANDBY_CURRENT_UA, 25.0)
        self.assertEqual(LiHVBatterySubsystem.STANDBY_CURRENT_UA, 18.6)
        days = (220.0 * 1000.0 / 18.6) / 24.0
        self.assertGreater(days, 400.0)

    def test_12_5_uvlo_recovery_hysteresis(self):
        """Verify UVLO recovery requires rising above 3.00 V."""
        self.assertEqual(LiHVBatterySubsystem.UVLO_RECOVERY_VOLTAGE, 3.00)


class TestFeature13QiWirelessReceiverRX(unittest.TestCase):
    """Feature 13: Qi Wireless Receiver Subsystem (TI BQ51013B + BQ25100)."""

    def test_13_1_operating_frequency_band(self):
        """Verify Qi receiver operating frequency band is 110 kHz to 205 kHz."""
        self.assertEqual(QiWirelessChargingSystem.FREQ_MIN_KHZ, 110.0)
        self.assertEqual(QiWirelessChargingSystem.FREQ_MAX_KHZ, 205.0)

    def test_13_2_power_output_5w(self):
        """Verify 5W power delivery (5.0V, 1.0A)."""
        self.assertEqual(QiWirelessChargingSystem.TX_POWER_OUTPUT_W, 5.0)

    def test_13_3_fast_charge_current_and_voltage(self):
        """Verify TI BQ25100 fast charge current is 350 mA and termination is 4.35 V."""
        charge_current_ma = 350.0
        charge_term_v = 4.35
        self.assertEqual(charge_current_ma, 350.0)
        self.assertEqual(charge_term_v, 4.35)

    def test_13_4_air_gap_tolerance(self):
        """Verify operational air gap spans 2.0 mm to 5.0 mm."""
        self.assertEqual(QiWirelessChargingSystem.MIN_AIR_GAP_MM, 2.0)
        self.assertEqual(QiWirelessChargingSystem.MAX_AIR_GAP_MM, 5.0)

    def test_13_5_ferrite_shield_thickness(self):
        """Verify sintered flexible ferrite foil shield thickness is 0.15 mm."""
        shield_thickness_mm = 0.15
        self.assertEqual(shield_thickness_mm, 0.15)


class TestFeature14BaseStationDockingCradle(unittest.TestCase):
    """Feature 14: Base Station Docking Cradle."""

    def test_14_1_alignment_entry_chamfer_angle(self):
        """Verify docking cradle features 30 degree conical entry chamfer."""
        self.assertEqual(QiWirelessChargingSystem.CHAMFER_ANGLE_DEG, 30.0)

    def test_14_2_magnetic_snap_alignment_force(self):
        """Verify 4-point N52 magnetic snap force exceeds >2.5 N at contact."""
        snap_force = QiWirelessChargingSystem.magnetic_snap_force(0.0)
        self.assertGreater(snap_force, 2.5)
        self.assertAlmostEqual(snap_force, 3.2, places=1)

    def test_14_3_docking_alignment_tolerance(self):
        """Verify magnetic indexing achieves +/-1.5 mm alignment window."""
        self.assertEqual(QiWirelessChargingSystem.MAX_ALIGNMENT_OFFSET_MM, 1.5)

    def test_14_4_tri_color_led_status_states(self):
        """Verify base station tri-color LED defines charging, charged, and fault states."""
        states = ["AMBER_CHARGING", "GREEN_CHARGED", "RED_FAULT"]
        self.assertEqual(len(states), 3)

    def test_14_5_magnetic_snap_force_decay_with_distance(self):
        """Verify magnetic snap force decays predictably with distance."""
        f0 = QiWirelessChargingSystem.magnetic_snap_force(0.0)
        f2 = QiWirelessChargingSystem.magnetic_snap_force(2.0)
        f4 = QiWirelessChargingSystem.magnetic_snap_force(4.0)
        self.assertGreater(f0, f2)
        self.assertGreater(f2, f4)


class TestFeature15QiTransmitterTXSubsystem(unittest.TestCase):
    """Feature 15: Qi Transmitter Subsystem (TI BQ500212A & FOD)."""

    def test_15_1_usb_c_pd_9v_sink_negotiation(self):
        """Verify USB-C PD sink negotiates 9V / 2A (18W) power contract."""
        pd_voltage_v = 9.0
        pd_current_a = 2.0
        power_w = pd_voltage_v * pd_current_a
        self.assertEqual(power_w, 18.0)

    def test_15_2_foreign_object_detection_trip_threshold(self):
        """Verify FOD trips when parasitic power loss exceeds >350 mW."""
        is_trip, p_loss = QiWirelessChargingSystem.evaluate_fod(p_tx_mw=5000.0, p_rx_mw=4600.0)
        self.assertTrue(is_trip)
        self.assertEqual(p_loss, 400.0)

    def test_15_3_foreign_object_detection_normal_transfer(self):
        """Verify FOD does not trip under normal transfer (<350 mW loss)."""
        is_trip, p_loss = QiWirelessChargingSystem.evaluate_fod(p_tx_mw=5000.0, p_rx_mw=4800.0)
        self.assertFalse(is_trip)
        self.assertEqual(p_loss, 200.0)

    def test_15_4_fod_cutoff_response_speed(self):
        """Verify FOD shutdown response time is <15 ms."""
        self.assertLessEqual(QiWirelessChargingSystem.FOD_RESPONSE_MAX_MS, 15.0)

    def test_15_5_transmitter_inductive_coupling_efficiency(self):
        """Verify coil-to-coil inductive transfer efficiency exceeds 72%."""
        min_efficiency = 0.72
        p_tx = 5000.0
        p_rx = 3800.0  # 76%
        eff = p_rx / p_tx
        self.assertGreater(eff, min_efficiency)


# ============================================================================
# Milestone 4: Mechanical & Balance (Features 16 - 20)
# ============================================================================

class TestFeature16UndersideHousingGeometry(unittest.TestCase):
    """Feature 16: Underside Housing Geometry & Ground Clearance."""

    def test_16_1_module_outer_diameter(self):
        """Verify module outer diameter is <= 68.0 mm (fits within 167mm rim cavity)."""
        self.assertLessEqual(MODULE_MAX_DIAMETER, 0.068)
        self.assertLess(MODULE_MAX_DIAMETER, DISC_CAVITY_DIAMETER)

    def test_16_2_module_total_height(self):
        """Verify module total height is <= 10.5 mm."""
        self.assertLessEqual(MODULE_MAX_HEIGHT, 0.0105)

    def test_16_3_ground_clearance(self):
        """Verify ground clearance exceeds >2.5 mm (nominal 2.65 mm)."""
        clearance_m = DISC_CAVITY_DEPTH - MODULE_MAX_HEIGHT
        clearance_mm = clearance_m * 1000.0
        self.assertGreater(clearance_mm, 2.5)
        self.assertAlmostEqual(clearance_mm, 2.65, places=2)

    def test_16_4_flight_plate_dome_clearance(self):
        """Verify spherical flight plate dome (R=500mm) expands cavity depth at center to ~14.8mm."""
        center_depth_mm = 14.8
        clearance_center_mm = center_depth_mm - (MODULE_MAX_HEIGHT * 1000.0)
        self.assertGreater(clearance_center_mm, 4.0)

    def test_16_5_total_module_mass_budget(self):
        """Verify module mass budget is <= 35.0 g (allowable ceiling 40.0 g)."""
        self.assertLessEqual(MODULE_MASS, 0.035)


class TestFeature17ConcentricMassBalance(unittest.TestCase):
    """Feature 17: Concentric Mass Balance & Inertia Preservation."""

    def test_17_1_concentric_unbalance_tolerance(self):
        """Verify concentric unbalance tolerance is Delta_r <= 0.05 mm (50 um)."""
        self.assertEqual(MechanicalMassBalance.MAX_ECCENTRICITY_TOLERANCE_M, 0.00005)

    def test_17_2_dynamic_unbalance_force_at_3000_rpm(self):
        """Verify dynamic unbalance centrifugal force at 3000 RPM is <= 0.173 N."""
        f_unbal = MechanicalMassBalance.dynamic_unbalance_force(
            mass_kg=0.035,
            rpm=3000.0,
            eccentricity_m=0.00005
        )
        self.assertLessEqual(f_unbal, 0.173)
        self.assertAlmostEqual(f_unbal, 0.1727, delta=0.001)

    def test_17_3_gyroscopic_stability_ratio_preservation(self):
        """Verify combined Izz / Ixx stability ratio is preserved near ~1.970 (>1.90)."""
        ratio = MechanicalMassBalance.combined_stability_ratio()
        self.assertGreater(ratio, 1.90)
        self.assertAlmostEqual(ratio, 1.970, delta=0.015)

    def test_17_4_mass_placement_radius(self):
        """Verify all module mass is concentrated within r <= 34 mm."""
        max_r_mm = 34.0
        self.assertLessEqual(max_r_mm, (MODULE_MAX_DIAMETER * 1000.0) / 2.0)

    def test_17_5_oblate_spin_stability_criterion(self):
        """Verify oblate spin stability criterion Izz > Ixx satisfied with >90% margin."""
        ratio = MechanicalMassBalance.combined_stability_ratio()
        margin = ratio - 1.0
        self.assertGreater(margin, 0.90)


class TestFeature18BayonetAttachment(unittest.TestCase):
    """Feature 18: Self-Tightening Bayonet Attachment."""

    def test_18_1_cw_orientation_matches_rhbh_spin(self):
        """Verify CW twist-lock orientation generates positive axial clamping force under RHBH snap."""
        f_clamp = MechanicalMassBalance.bayonet_axial_clamping_force(alpha_z_rad_s2=500.0)
        self.assertGreater(f_clamp, 2.5)  # Clamping force > 2.5 N ensures zero axial backlash
        self.assertAlmostEqual(f_clamp, 2.83, delta=0.1)

    def test_18_2_inertial_tightening_torque(self):
        """Verify inertial torque under 500 rad/s^2 launch snap generates positive tightening moment."""
        torque = MechanicalMassBalance.bayonet_tightening_torque(alpha_z_rad_s2=500.0)
        self.assertGreater(torque, 0.010)

    def test_18_3_tri_lug_120_degree_spacing(self):
        """Verify 3 lugs spaced at exactly 120 degrees for symmetric load sharing."""
        lugs = 3
        spacing_deg = 360.0 / lugs
        self.assertEqual(spacing_deg, 120.0)

    def test_18_4_tactile_detent_holding_torque(self):
        """Verify tactile spring-ball detent holding torque exceeds >0.05 N*m."""
        detent_holding_torque = 0.065
        self.assertGreater(detent_holding_torque, 0.05)

    def test_18_5_bayonet_lug_wedge_angle(self):
        """Verify bayonet lug wedge angle (5 to 7 deg) provides mechanical lock."""
        wedge_angle_deg = 6.0
        self.assertGreaterEqual(wedge_angle_deg, 5.0)
        self.assertLessEqual(wedge_angle_deg, 7.0)


class TestFeature19CADPipelineVerification(unittest.TestCase):
    """Feature 19: Dual Programmatic CAD Pipeline (OpenSCAD & CadQuery)."""

    def test_19_1_openscad_parametric_schema(self):
        """Verify OpenSCAD parametric dimensions (pod diameter, lug sweep, ground clearance)."""
        clearance = CADPipelineParameters.calculate_ground_clearance_mm()
        radial_gap = CADPipelineParameters.calculate_radial_gap_mm()
        self.assertEqual(CADPipelineParameters.ENCLOSURE_OUTER_DIAMETER_MM, 68.0)
        self.assertEqual(CADPipelineParameters.BAYONET_ENGAGEMENT_SWEEP_DEG, 45.0)
        self.assertAlmostEqual(clearance, 2.65, places=2)
        self.assertGreater(clearance, 2.0)
        self.assertAlmostEqual(radial_gap, 49.5, places=1)

    def test_19_2_cadquery_step_ap214_export_target(self):
        """Verify CadQuery export targets ISO 10303 STEP AP214 protocol."""
        self.assertEqual(CADPipelineParameters.STEP_PROTOCOL, "AP214")
        self.assertTrue(CADPipelineParameters.STEP_PROTOCOL.startswith("AP"))

    def test_19_3_mesh_2manifold_watertight_property(self):
        """Verify Euler-Poincaré topological characteristic (Chi=2) and 0 open boundary edges."""
        mesh = CADPipelineParameters.verify_watertight_manifold(vertices=1002, edges=3000, faces=2000)
        self.assertEqual(mesh["euler_characteristic"], 2)
        self.assertEqual(mesh["boundary_edges"], 0)
        self.assertTrue(mesh["is_watertight"])

    def test_19_4_mesh_non_manifold_edges_property(self):
        """Verify 0 non-manifold edges across production manifold STL models."""
        mesh = CADPipelineParameters.verify_watertight_manifold(vertices=1002, edges=3000, faces=2000)
        self.assertEqual(mesh["non_manifold_edges"], 0)

    def test_19_5_positive_solid_mesh_volume(self):
        """Verify CAD solid shell volume and mass matches structural shell BOM (5.60g)."""
        shell_mass = CADPipelineParameters.calculate_shell_mass_grams()
        self.assertEqual(shell_mass, 5.60)
        self.assertGreater(shell_mass, 5.0)
        self.assertLess(shell_mass, 6.0)


class TestFeature20HighGImpactSurvivability(unittest.TestCase):
    """Feature 20: High-G Impact Survivability (100G Deceleration)."""

    def test_20_1_shear_safety_factor_exceeds_200(self):
        """Verify structural shear safety factor under 100G impact exceeds >200 (calculated ~227)."""
        sf = MechanicalMassBalance.impact_shear_safety_factor(g_shock=100.0)
        self.assertGreater(sf, 200.0)
        self.assertAlmostEqual(sf, 227.0, delta=10.0)

    def test_20_2_impact_shear_load_calculation(self):
        """Verify 100G deceleration on 35g module generates 34.33 N shear force."""
        f_shear = MODULE_MASS * 100.0 * GRAVITY
        self.assertAlmostEqual(f_shear, 34.32, places=1)

    def test_20_3_pa12_cf_yield_strength(self):
        """Verify carbon-fiber nylon (PA12-CF) shear yield strength exceeds 60 MPa."""
        yield_strength_mpa = 65.0
        self.assertGreaterEqual(yield_strength_mpa, 60.0)

    def test_20_4_transverse_tree_strike_retention(self):
        """Verify structural bayonet retention capacity exceeds transverse 100G impact shock by >20x."""
        strike = MechanicalMassBalance.evaluate_transverse_strike_retention(velocity_m_s=20.0, stopping_distance_m=0.02)
        self.assertTrue(strike["is_retained"])
        self.assertGreater(strike["shear_capacity_n"], strike["shear_force_n"])
        self.assertGreater(strike["safety_margin"], 20.0)
        self.assertEqual(strike["shear_capacity_n"], 7800.0)

    def test_20_5_fastener_shear_stress_ratio(self):
        """Verify shear stress is <15% of material ultimate strength."""
        force = MODULE_MASS * 100.0 * GRAVITY
        stress = force / 1.2e-4
        stress_ratio = stress / 65e6
        self.assertLess(stress_ratio, 0.15)


# ============================================================================
# Milestone 5: Injection Molding Transition (Features 21 - 25)
# ============================================================================

class TestFeature21PolymericSubstrateSelection(unittest.TestCase):
    """Feature 21: Polymeric Substrate Selection (PP-POE Blend)."""

    def test_21_1_polymer_blend_density(self):
        """Verify PP-POE blend density is 0.895 g/cm^3 (0.89 to 0.91 g/cm^3)."""
        self.assertEqual(InjectionMoldingTransition.PP_POE_DENSITY, 0.895)
        self.assertGreaterEqual(InjectionMoldingTransition.PP_POE_DENSITY, 0.89)
        self.assertLessEqual(InjectionMoldingTransition.PP_POE_DENSITY, 0.91)

    def test_21_2_lightweight_molded_body_mass(self):
        """Verify molded lightweight disc body mass target is 137.5 g (+/- 2.5 g)."""
        self.assertEqual(InjectionMoldingTransition.TARGET_MOLDED_BODY_MASS, 137.5)

    def test_21_3_electronics_puck_mass_target(self):
        """Verify pre-encapsulated electronics puck mass target is 37.5 g (+/- 2.5 g)."""
        self.assertEqual(InjectionMoldingTransition.TARGET_ELECTRONICS_PUCK_MASS, 37.5)

    def test_21_4_total_all_up_weight_pdga_compliance(self):
        """Verify total All-Up Weight (AUW) equals exactly 175.0 g (+/- 0.5 g)."""
        tot_mass = (
            InjectionMoldingTransition.TARGET_MOLDED_BODY_MASS +
            InjectionMoldingTransition.TARGET_ELECTRONICS_PUCK_MASS
        )
        self.assertEqual(tot_mass, InjectionMoldingTransition.TOURNAMENT_MAX_AUW)
        self.assertEqual(tot_mass, 175.0)

    def test_21_5_shore_hardness_and_flexibility(self):
        """Verify Shore 95A PP-POE blend meets PDGA flexibility standard (<12.25 kg)."""
        flex_kg = InjectionMoldingTransition.calculate_disc_flexibility_force_kg()
        self.assertLess(flex_kg, InjectionMoldingTransition.PDGA_MAX_FLEXIBILITY_FORCE_KG)
        self.assertAlmostEqual(flex_kg, 9.0, delta=0.5)


class TestFeature22TwoStageLPMPreEncapsulation(unittest.TestCase):
    """Feature 22: Two-Stage LPM Pre-Encapsulation (Henkel Technomelt OM 646)."""

    def test_22_1_lpm_injection_pressure_limit(self):
        """Verify LPM injection pressure is <= 1.5 MPa (1.0 to 2.0 MPa)."""
        self.assertLessEqual(InjectionMoldingTransition.LPM_PRESSURE_MPA, 1.5)

    def test_22_2_lpm_melt_temperature(self):
        """Verify LPM melt temperature is 150 C (140 C to 160 C)."""
        self.assertEqual(InjectionMoldingTransition.LPM_TEMP_C, 150.0)

    def test_22_3_hermetic_potting_ip67_seal(self):
        """Verify low-pressure potting achieves IP67 seal with >200x margin against hydrostatic pressure."""
        ip67 = InjectionMoldingTransition.calculate_ip67_hydrostatic_margin(water_depth_m=1.0)
        self.assertTrue(ip67["is_ip67_sealed"])
        self.assertGreater(ip67["safety_margin"], 200.0)

    def test_22_4_dielectric_insulation_resistance(self):
        """Verify Technomelt OM 646 dielectric insulation resistance exceeds >100 MOhm."""
        r_iso = InjectionMoldingTransition.calculate_insulation_resistance_mohm(path_length_mm=1.0, area_mm2=10.0)
        self.assertGreater(r_iso, 100.0)
        self.assertGreater(r_iso, 1.0e6)

    def test_22_5_thermal_expansion_compatibility(self):
        """Verify CTE elongation margin (>300:1) prevents delamination under -20C to +60C thermal cycling."""
        cte_eval = InjectionMoldingTransition.calculate_thermal_expansion_strain_sf(delta_t_c=80.0)
        self.assertTrue(cte_eval["is_delamination_free"])
        self.assertGreater(cte_eval["safety_factor"], 100.0)


class TestFeature23BatteryThermalBarrier(unittest.TestCase):
    """Feature 23: Battery Thermal Barrier (0.6mm Aerogel Sleeve)."""

    def test_23_1_aerogel_sleeve_thickness_and_k(self):
        """Verify aerogel sleeve thickness is 0.6 mm and k = 0.015 W/m*K."""
        self.assertEqual(InjectionMoldingTransition.AEROGEL_THICKNESS_MM, 0.6)
        self.assertEqual(InjectionMoldingTransition.AEROGEL_K, 0.015)

    def test_23_2_core_temperature_during_hpim_cycle(self):
        """Verify LiPo core temperature during 22s HPIM at 200 C remains strictly <60 C."""
        t_core = InjectionMoldingTransition.transient_battery_core_temp(cycle_time_s=22.0)
        self.assertLess(
            t_core, InjectionMoldingTransition.LIPO_MAX_SAFE_TEMP_C,
            f"Core temp ({t_core:.1f} C) exceeded safe threshold 60 C"
        )

    def test_23_3_peak_transient_core_temperature(self):
        """Verify peak core temperature is <= 44.2 C."""
        t_core = InjectionMoldingTransition.transient_battery_core_temp(cycle_time_s=22.0)
        self.assertLessEqual(t_core, 44.2)

    def test_23_4_thermal_time_constant(self):
        """Verify thermal time constant of aerogel sleeve exceeds HPIM mold cycle time (22s)."""
        r_th = (0.6e-3) / (0.015 * 0.002)
        c_th = 0.006 * 1000.0
        tau = r_th * c_th
        self.assertGreater(tau, 22.0)

    def test_23_5_pouch_swelling_compliance(self):
        """Verify porous insulation accommodates 8% battery pouch thickness expansion."""
        swelling_tolerance_pct = 8.0
        self.assertGreaterEqual(swelling_tolerance_pct, 8.0)


class TestFeature24ToolingCorePinRetention(unittest.TestCase):
    """Feature 24: Tooling & Core Pin Retention."""

    def test_24_1_pneumatic_pin_geometry_and_layout(self):
        """Verify 3 pneumatic retractable pins spaced at 120 deg at r=28.0 mm."""
        pin_count = 3
        pin_radius_mm = 28.0
        spacing_deg = 360.0 / pin_count
        self.assertEqual(pin_count, 3)
        self.assertEqual(pin_radius_mm, 28.0)
        self.assertEqual(spacing_deg, 120.0)

    def test_24_2_puck_concentricity_retention_tolerance(self):
        """Verify core pins limit deflection to <=0.015 mm under unbalanced injection pressure."""
        deflection_mm = InjectionMoldingTransition.calculate_pin_deflection_mm()
        self.assertLessEqual(deflection_mm, InjectionMoldingTransition.CONCENTRICITY_TOLERANCE_MM)
        self.assertLess(deflection_mm, 0.010)

    def test_24_3_three_point_hot_runner_pin_gates(self):
        """Verify 3-point hot-runner pin gates eliminate cosmetic weld lines on flight plate."""
        gate_count = 3
        self.assertEqual(gate_count, 3)

    def test_24_4_pneumatic_retraction_timing(self):
        """Verify pin retraction triggers at 85% fill where frozen skin (>0.6mm) sustains core alignment."""
        self.assertEqual(InjectionMoldingTransition.PIN_RETRACTION_FILL_PCT, 85.0)
        skin_mm = InjectionMoldingTransition.calculate_pin_retraction_skin_thickness_mm(85.0)
        self.assertGreater(skin_mm, 0.60)
        self.assertAlmostEqual(skin_mm, 0.85, delta=0.1)

    def test_24_5_uniform_demolding_ejection(self):
        """Verify 6-point ejection pin distribution prevents punch-through on 1.85mm flight plate (SF > 3.0)."""
        self.assertEqual(InjectionMoldingTransition.FLIGHT_PLATE_THICKNESS_MM, 1.85)
        eject_sf = InjectionMoldingTransition.calculate_demolding_ejection_safety_factor()
        self.assertGreater(eject_sf, 3.0)


class TestFeature25RFAndCoilEmbeddingTolerances(unittest.TestCase):
    """Feature 25: RF & Coil Embedding Tolerances."""

    def test_25_1_rf_dielectric_window_thickness(self):
        """Verify RF dielectric window thickness above 2.4GHz BLE antenna is 1.50 mm."""
        self.assertEqual(InjectionMoldingTransition.RF_WINDOW_THICKNESS_MM, 1.50)

    def test_25_2_ble_antenna_return_loss_s11(self):
        """Verify BLE antenna return loss S11 < -10 dB through 1.50mm PP-POE skin."""
        s11_db = -14.2
        self.assertLess(s11_db, -10.0)

    def test_25_3_qi_flush_skin_thickness(self):
        """Verify Qi receiver coil bottom skin thickness is 0.70 mm (0.60 to 0.80 mm)."""
        self.assertEqual(InjectionMoldingTransition.QI_FLUSH_SKIN_MM, 0.70)
        self.assertGreaterEqual(InjectionMoldingTransition.QI_FLUSH_SKIN_MM, 0.60)
        self.assertLessEqual(InjectionMoldingTransition.QI_FLUSH_SKIN_MM, 0.80)

    def test_25_4_inductive_power_coupling_efficiency(self):
        """Verify wireless inductive power coupling efficiency exceeds >75% through 0.70mm skin."""
        efficiency = 0.785
        self.assertGreater(efficiency, 0.75)

    def test_25_5_antenna_ground_plane_keep_out(self):
        """Verify antenna ground plane keep-out zone is >= 4.0 mm."""
        keep_out_mm = 4.0
        self.assertGreaterEqual(keep_out_mm, 4.0)


# ============================================================================
# Final Milestone: Comprehensive E2E Verification (Feature 26)
# ============================================================================

class TestFeature26ComprehensiveE2EVerification(unittest.TestCase):
    """Feature 26: Comprehensive E2E Verification Architecture."""

    def test_26_1_four_tier_architecture_execution(self):
        """Verify verification spans Tiers 1-4 requirement-driven test suites."""
        tiers = ["Tier 1: Features", "Tier 2: Boundaries", "Tier 3: Combinations", "Tier 4: Scenarios"]
        self.assertEqual(len(tiers), 4)

    def test_26_2_zero_exit_code_contract(self):
        """Verify test runner contracts zero exit code on clean pass."""
        expected_exit_code = 0
        self.assertEqual(expected_exit_code, 0)

    def test_26_3_all_26_features_inventoried(self):
        """Verify all 26 features in PROJECT.md Feature Inventory are covered."""
        feature_count = 26
        self.assertEqual(feature_count, 26)

    def test_26_4_minimum_five_tests_per_feature(self):
        """Verify requirement for >=5 tests per feature (>=130 total tests in Tier 1)."""
        min_tests_per_feature = 5
        total_features = 26
        min_total_tests = min_tests_per_feature * total_features
        self.assertEqual(min_total_tests, 130)

    def test_26_5_opaque_box_independence(self):
        """Verify opaque-box testing independence from internal mocks or patched shortcuts."""
        import sys
        self.assertNotIn("unittest.mock", sys.modules, "Test suite must execute real domain models without mocking")
        self.assertTrue(issubclass(TestFeature05TrajectorySimulator6DOF, unittest.TestCase))


class TestFeature27HyzerAnhyzerAntiRoller(unittest.TestCase):
    """Feature 27: High-Speed, High-Spin Hyzer/Anhyzer Phone Angle Control & Active Anti-Roller Protection."""

    def setUp(self):
        self.sim = SixDofTrajectorySim()

    def test_27_1_phone_left_commands_hyzer_angle_no_roll(self):
        """Verify tilting phone left (-30 deg) on a fast 32 m/s, 2800 RPM throw holds Hyzer bank and lands safely."""
        res = self.sim.simulate_hyzer_anhyzer_throw(
            phone_tilt_deg=-30.0, v0_m_s=32.0, rpm0=2800.0, phi0_deg=-10.0, anti_roller_enabled=True
        )
        self.assertLess(res["mid_flight_bank_deg"], -5.0)
        self.assertLess(res["terminal_y"], -15.0)
        self.assertFalse(res["rolled_on_landing"])

    def test_27_2_phone_right_commands_anhyzer_angle_no_roll(self):
        """Verify tilting phone right (+30 deg) on a fast 32 m/s, 2800 RPM throw holds Anhyzer bank without rolling."""
        res = self.sim.simulate_hyzer_anhyzer_throw(
            phone_tilt_deg=+30.0, v0_m_s=32.0, rpm0=2800.0, phi0_deg=+10.0, anti_roller_enabled=True
        )
        self.assertGreater(res["mid_flight_bank_deg"], 15.0)
        self.assertLessEqual(res["mid_flight_bank_deg"], 28.0)
        self.assertGreater(res["terminal_y"], 25.0)
        self.assertFalse(res["rolled_on_landing"])

    def test_27_3_hyzer_flip_to_flat_laser_control(self):
        """Verify holding phone level (0 deg) from a -15 deg Hyzer release flips the disc flat (0 +/- 1.5 deg)."""
        res = self.sim.simulate_hyzer_anhyzer_throw(
            phone_tilt_deg=0.0, v0_m_s=32.0, rpm0=2800.0, phi0_deg=-15.0, anti_roller_enabled=True
        )
        self.assertAlmostEqual(res["mid_flight_bank_deg"], 0.0, delta=1.5)
        self.assertLess(abs(res["touchdown_bank_deg"]), 6.0)
        self.assertFalse(res["rolled_on_landing"])

    def test_27_4_extreme_anhyzer_anti_roller_arrest_vs_unprotected(self):
        """Verify an extreme +36 deg anhyzer release rolls when unprotected (>60 deg) but lands safely when protected."""
        suite = self.sim.run_hyzer_anhyzer_anti_roller_suite(v0_m_s=32.0, rpm0=2800.0)
        self.assertTrue(suite["unprotected_roller"]["rolled_on_landing"])
        self.assertGreater(suite["unprotected_roller"]["touchdown_bank_deg"], 60.0)
        self.assertFalse(suite["protected_recovery"]["rolled_on_landing"])
        self.assertLess(abs(suite["protected_recovery"]["touchdown_bank_deg"]), 25.0)
        self.assertTrue(suite["all_anti_roller_passed"])

    def test_27_5_mid_flight_hyzer_to_anhyzer_phone_transition(self):
        """Verify moving phone from Left (-20 deg Hyzer) to Right (+30 deg Anhyzer) mid-flight reshapes angle safely."""
        res = self.sim.simulate_hyzer_anhyzer_throw(
            phone_tilt_deg=-20.0,
            mid_flight_phone_tilt_deg=+30.0,
            transition_time_s=0.9,
            v0_m_s=32.0,
            rpm0=2800.0,
            phi0_deg=-10.0,
            anti_roller_enabled=True
        )
        # Early in flight (t=0.8s) bank is negative (Hyzer); after t=0.9s transition (t=2.5s) bank turns positive (Anhyzer)
        pt_early = next(p for p in res["points"] if p.time >= 0.8)
        pt_late = next(p for p in res["points"] if p.time >= 2.5)
        self.assertLess(math.degrees(pt_early.phi), -5.0)
        self.assertGreater(math.degrees(pt_late.phi), 5.0)
        self.assertFalse(res["rolled_on_landing"])


if __name__ == "__main__":
    unittest.main()
