"""
Empirical Adversarial Stress Test Harness: Aerodynamics, Elevon Steering, and Flight Dynamics.
Challenger 1 - Milestone 1 Verification.
"""

import math
import os
import sys
from typing import List, Dict, Any, Tuple

# Ensure project root is in sys.path
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_DIR = os.path.dirname(BASE_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from smart_disc_golf.aero.trajectory_sim import SixDofTrajectorySim, DiscParameters, AeroCoefficients, ElevonParameters


def run_airspeed_spin_sweep() -> List[Dict[str, Any]]:
    sim = SixDofTrajectorySim()
    airspeeds = [10.0, 15.0, 20.0, 25.0, 30.0]
    spin_rpms = [0.0, 500.0, 1000.0, 2000.0, 2500.0, 3000.0]
    results = []

    for v in airspeeds:
        for rpm in spin_rpms:
            # Test nominal, right (+18 deg), left (-18 deg), full right (+25 deg), full left (-25 deg)
            for mode, defl in [("nominal", 0.0), ("right_18", 18.0), ("left_18", -18.0), ("right_25", 25.0), ("left_25", -25.0)]:
                throw_type = "nominal" if mode == "nominal" else ("right" if "right" in mode else "left")
                try:
                    res = sim.simulate_throw(
                        throw_type=throw_type,
                        v0_m_s=v,
                        theta0_deg=2.5,
                        rpm0=rpm,
                        elevon_deflection_deg=abs(defl),
                        steer_start_s=0.8,
                        steer_end_s=2.0
                    )
                    
                    # Check for stall, tumbling, divergence
                    max_alpha = max(abs(p.alpha) for p in res.points) if res.points else 0.0
                    max_phi = max(abs(p.phi) for p in res.points) if res.points else 0.0
                    has_nan = any(math.isnan(p.x) or math.isnan(p.y) or math.isnan(p.z) for p in res.points)
                    is_tumbled = max_phi > math.radians(85.0) or max_alpha > math.radians(45.0)
                    is_stalled = max_alpha > math.radians(20.0)

                    results.append({
                        "v": v,
                        "rpm": rpm,
                        "mode": mode,
                        "flight_time": res.flight_time_s,
                        "x": res.terminal_x,
                        "y": res.terminal_y,
                        "max_alt": res.max_altitude_m,
                        "max_alpha_deg": math.degrees(max_alpha),
                        "max_phi_deg": math.degrees(max_phi),
                        "has_nan": has_nan,
                        "is_tumbled": is_tumbled,
                        "is_stalled": is_stalled,
                        "num_points": len(res.points)
                    })
                except Exception as e:
                    results.append({
                        "v": v,
                        "rpm": rpm,
                        "mode": mode,
                        "error": str(e)
                    })
    return results


def run_launch_angle_sweep() -> List[Dict[str, Any]]:
    sim = SixDofTrajectorySim()
    launch_angles = [-5.0, 0.0, 2.5, 5.0, 10.0]
    results = []

    for th in launch_angles:
        for mode in ["nominal", "right", "left"]:
            try:
                res = sim.simulate_throw(
                    throw_type=mode,
                    v0_m_s=26.0,
                    theta0_deg=th,
                    rpm0=2200.0,
                    elevon_deflection_deg=18.0
                )
                max_alpha = max(abs(p.alpha) for p in res.points) if res.points else 0.0
                max_phi = max(abs(p.phi) for p in res.points) if res.points else 0.0
                has_nan = any(math.isnan(p.x) or math.isnan(p.y) or math.isnan(p.z) for p in res.points)
                is_stalled = max_alpha > math.radians(20.0)

                results.append({
                    "theta0": th,
                    "mode": mode,
                    "flight_time": res.flight_time_s,
                    "x": res.terminal_x,
                    "y": res.terminal_y,
                    "max_alt": res.max_altitude_m,
                    "max_alpha_deg": math.degrees(max_alpha),
                    "max_phi_deg": math.degrees(max_phi),
                    "has_nan": has_nan,
                    "is_stalled": is_stalled
                })
            except Exception as e:
                results.append({
                    "theta0": th,
                    "mode": mode,
                    "error": str(e)
                })
    return results


def run_continuous_deflection_sweep() -> List[Dict[str, Any]]:
    """Test full left (-25 deg) and full right (+25 deg) continuous elevon deflection throughout flight."""
    sim = SixDofTrajectorySim()
    results = []

    for defl in [-25.0, -18.0, 0.0, 18.0, 25.0]:
        mode = "nominal" if defl == 0.0 else ("right" if defl > 0 else "left")
        res = sim.simulate_throw(
            throw_type=mode,
            v0_m_s=25.0,
            theta0_deg=2.5,
            rpm0=2200.0,
            elevon_deflection_deg=abs(defl),
            steer_start_s=0.0,  # continuous from start
            steer_end_s=8.0    # to end
        )
        max_alpha = max(abs(p.alpha) for p in res.points) if res.points else 0.0
        max_phi = max(abs(p.phi) for p in res.points) if res.points else 0.0
        has_nan = any(math.isnan(p.x) or math.isnan(p.y) or math.isnan(p.z) for p in res.points)
        is_tumbled = max_phi > math.radians(85.0)
        is_stalled = max_alpha > math.radians(20.0)

        results.append({
            "defl_deg": defl,
            "flight_time": res.flight_time_s,
            "x": res.terminal_x,
            "y": res.terminal_y,
            "max_alt": res.max_altitude_m,
            "max_alpha_deg": math.degrees(max_alpha),
            "max_phi_deg": math.degrees(max_phi),
            "has_nan": has_nan,
            "is_tumbled": is_tumbled,
            "is_stalled": is_stalled
        })
    return results


def run_bearing_keel_stress_test() -> List[Dict[str, Any]]:
    """
    Stress test bearing friction vs keel wind-lock restoring moment across worst-case corners.
    Includes cold-weather bearing grease viscosity factor (2.0x, 3.0x).
    """
    # Bearing baseline: tau_coulomb = 0.150 mN*m, c_v = 4.20e-7 N*m*s/rad
    # Fin baseline: NACA 0009, S_fin = 3.0e-4 m^2, x_fin = 0.055 m, C_N_beta = 5.0265 rad^-1
    rho = 1.225
    s_fin = 3.0e-4
    x_fin = 0.055
    cn_beta = 5.0265
    tau_coulomb_base = 0.150e-3
    cv_base = 4.20e-7

    speeds = [10.0, 12.0, 15.0, 20.0, 25.0, 30.0]
    rpms = [1000.0, 2000.0, 2500.0, 3000.0, 3500.0]
    viscosity_mults = [1.0, 2.0, 3.0]  # 1.0 nominal, 2.0 cool (0 C), 3.0 sub-zero (-15 C)

    results = []
    for mult in viscosity_mults:
        for v in speeds:
            q_inf = 0.5 * rho * (v ** 2)
            k_align = q_inf * s_fin * x_fin * cn_beta  # N*m/rad
            for rpm in rpms:
                w_z = rpm * (2.0 * math.pi / 60.0)
                tau_f = (tau_coulomb_base + cv_base * w_z) * mult
                ratio = k_align / tau_f
                beta_eq_rad = tau_f / k_align
                beta_eq_deg = math.degrees(beta_eq_rad)
                pass_ratio = ratio > 10.0
                pass_offset = beta_eq_deg <= 1.5

                results.append({
                    "visc_mult": mult,
                    "v": v,
                    "rpm": rpm,
                    "k_align_mNm": k_align * 1000.0,
                    "tau_f_mNm": tau_f * 1000.0,
                    "wind_lock_ratio": ratio,
                    "beta_eq_deg": beta_eq_deg,
                    "pass_ratio": pass_ratio,
                    "pass_offset": pass_offset
                })
    return results


if __name__ == "__main__":
    print("=" * 80)
    print("1. AIRSPEED & SPIN RATE BOUNDARY SWEEP (10-30 m/s, 0-3000 RPM)")
    print("=" * 80)
    sweep1 = run_airspeed_spin_sweep()
    print(f"Total simulations run: {len(sweep1)}")
    
    # Filter and analyze lateral steering corridor across speeds at 2000 RPM
    print("\n--- Steering Authority vs Airspeed at 2000 RPM ---")
    print(f"{'V (m/s)':<8} | {'Nom Y (m)':<10} | {'R_18 Y (m)':<10} | {'L_18 Y (m)':<10} | {'Delta R (m)':<11} | {'Delta L (m)':<11} | {'Corridor (m)':<12}")
    for v in [10.0, 15.0, 20.0, 25.0, 30.0]:
        n = next(r for r in sweep1 if r["v"] == v and r["rpm"] == 2000.0 and r["mode"] == "nominal")
        r18 = next(r for r in sweep1 if r["v"] == v and r["rpm"] == 2000.0 and r["mode"] == "right_18")
        l18 = next(r for r in sweep1 if r["v"] == v and r["rpm"] == 2000.0 and r["mode"] == "left_18")
        dR = r18["y"] - n["y"]
        dL = l18["y"] - n["y"]
        corr = r18["y"] - l18["y"]
        print(f"{v:<8.1f} | {n['y']:<10.2f} | {r18['y']:<10.2f} | {l18['y']:<10.2f} | {dR:<+11.2f} | {dL:<+11.2f} | {corr:<12.2f}")

    # Check for failures, stalls, tumbling
    stalls = [r for r in sweep1 if r.get("is_stalled", False)]
    tumbles = [r for r in sweep1 if r.get("is_tumbled", False)]
    nans = [r for r in sweep1 if r.get("has_nan", False)]
    errors = [r for r in sweep1 if "error" in r]
    print(f"\nBoundary anomalies: Stalls={len(stalls)}, Tumbles={len(tumbles)}, NaNs={len(nans)}, Errors={len(errors)}")
    if stalls:
        print("Sample stalled cases:")
        for s in stalls[:5]:
            print(f"  V={s['v']} m/s, RPM={s['rpm']}, Mode={s['mode']}, Max Alpha={s['max_alpha_deg']:.1f} deg, Flight Time={s['flight_time']:.2f} s")

    print("\n" + "=" * 80)
    print("2. LAUNCH ANGLE SWEEP (-5 to +10 deg, V=26 m/s, 2200 RPM)")
    print("=" * 80)
    sweep2 = run_launch_angle_sweep()
    print(f"{'Theta0 (deg)':<12} | {'Nom Y (m)':<10} | {'Right Y (m)':<11} | {'Left Y (m)':<11} | {'Delta R':<10} | {'Delta L':<10} | {'Flight Time (s)':<15}")
    for th in [-5.0, 0.0, 2.5, 5.0, 10.0]:
        n = next(r for r in sweep2 if r["theta0"] == th and r["mode"] == "nominal")
        r_ = next(r for r in sweep2 if r["theta0"] == th and r["mode"] == "right")
        l_ = next(r for r in sweep2 if r["theta0"] == th and r["mode"] == "left")
        dR = r_["y"] - n["y"]
        dL = l_["y"] - n["y"]
        print(f"{th:<+12.1f} | {n['y']:<10.2f} | {r_['y']:<11.2f} | {l_['y']:<11.2f} | {dR:<+10.2f} | {dL:<+10.2f} | {n['flight_time']:<15.2f}")

    print("\n" + "=" * 80)
    print("3. CONTINUOUS ELEVON DEFLECTION SWEEP (+/- 25 deg)")
    print("=" * 80)
    sweep3 = run_continuous_deflection_sweep()
    print(f"{'Deflection':<12} | {'Flight Time':<12} | {'X Landing':<12} | {'Y Landing':<12} | {'Max Alpha':<12} | {'Max Phi':<12} | {'Status':<10}")
    for r in sweep3:
        status = "STALL" if r["is_stalled"] else ("TUMBLE" if r["is_tumbled"] else "OK")
        print(f"{r['defl_deg']:<+12.1f} | {r['flight_time']:<12.2f} | {r['x']:<12.2f} | {r['y']:<12.2f} | {r['max_alpha_deg']:<12.1f} | {r['max_phi_deg']:<12.1f} | {status:<10}")

    print("\n" + "=" * 80)
    print("4. BEARING FRICTION VS KEEL RESTORING TORQUE (WORST-CASE CORNERS)")
    print("=" * 80)
    sweep4 = run_bearing_keel_stress_test()
    # Find minimum margin
    min_margin_run = min(sweep4, key=lambda x: x["wind_lock_ratio"])
    print(f"Absolute Worst-Case Margin: {min_margin_run['wind_lock_ratio']:.2f}:1")
    print(f"Conditions: Speed={min_margin_run['v']} m/s, RPM={min_margin_run['rpm']}, Viscosity Mult={min_margin_run['visc_mult']}x")
    print(f"K_align: {min_margin_run['k_align_mNm']:.3f} mN*m/rad, Tau_f: {min_margin_run['tau_f_mNm']:.3f} mN*m, Beta_eq: {min_margin_run['beta_eq_deg']:.3f} deg")
    
    # Table of nominal (1x) vs sub-zero cold (3x) at low speed (10-15 m/s)
    print("\n--- Low Airspeed & Extreme Viscosity Degradation Matrix ---")
    print(f"{'Visc Mult':<10} | {'V (m/s)':<8} | {'RPM':<6} | {'K_align (mNm)':<14} | {'Tau_f (mNm)':<12} | {'Ratio':<10} | {'Beta_eq (deg)':<14} | {'Verdict':<8}")
    for mult in [1.0, 3.0]:
        for v in [10.0, 15.0]:
            for rpm in [1000.0, 2500.0, 3500.0]:
                match = next(r for r in sweep4 if r["visc_mult"] == mult and r["v"] == v and r["rpm"] == rpm)
                verdict = "PASS" if match["pass_ratio"] and match["pass_offset"] else "FAIL"
                print(f"{mult:<10.1f} | {v:<8.1f} | {rpm:<6.0f} | {match['k_align_mNm']:<14.3f} | {match['tau_f_mNm']:<12.3f} | {match['wind_lock_ratio']:<10.2f} | {match['beta_eq_deg']:<14.3f} | {verdict:<8}")

