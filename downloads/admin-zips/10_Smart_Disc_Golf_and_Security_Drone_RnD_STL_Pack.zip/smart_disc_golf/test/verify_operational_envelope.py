"""
Operational Envelope Verification and Adversarial Stress Harness.
Tests flight dynamics across the entire envelope:
  - Airspeeds: 15, 20, 25, 26 m/s
  - Spin rates: 1000, 2000, 2500 RPM
  - Elevon deflections: 18 deg and 25 deg
  - Pitch reflex lift compensation and turf dive prevention
"""

import math
import os
import sys

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOT_DIR = os.path.dirname(BASE_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from smart_disc_golf.aero.trajectory_sim import SixDofTrajectorySim

def main():
    sim = SixDofTrajectorySim()
    speeds = [15.0, 20.0, 25.0, 26.0]
    rpms = [1000.0, 2000.0, 2500.0]

    header = (
        "{:<8} | {:<6} | {:<9} | {:<9} | {:<9} | {:<9} | {:<11} | {:<11} | {:<10} | {:<9} | {:<8}"
    ).format(
        "V (m/s)", "RPM", "Nom T(s)", "Rgt T(s)", "Lft T(s)", "Nom Y", "Delta R(m)", "Delta L(m)", "Corridor", "MaxAlt(m)", "Status"
    )
    print("=" * len(header))
    print("OPERATIONAL ENVELOPE STRESS TEST (Elevon Deflection = 18 deg, Steer Window = 0.5s - 2.5s)")
    print("=" * len(header))
    print(header)
    print("-" * len(header))

    envelope_results = []
    turf_dive_count = 0
    anomalies = []

    for v in speeds:
        for rpm in rpms:
            nom = sim.simulate_throw("nominal", v0_m_s=v, rpm0=rpm)
            rgt = sim.simulate_throw("right", v0_m_s=v, rpm0=rpm, elevon_deflection_deg=18.0)
            lft = sim.simulate_throw("left", v0_m_s=v, rpm0=rpm, elevon_deflection_deg=18.0)

            dr = rgt.terminal_y - nom.terminal_y
            dl = lft.terminal_y - nom.terminal_y
            corr = rgt.terminal_y - lft.terminal_y

            # Check flight duration maintenance (sustained vertical lift vs premature turf dive)
            # In banked turns without reflex compensation, flight time drops by >40% (e.g. from 4.4s down to 2.4s)
            flight_time_ratio_r = rgt.flight_time_s / nom.flight_time_s
            flight_time_ratio_l = lft.flight_time_s / nom.flight_time_s
            
            turf_dive = (flight_time_ratio_r < 0.75) or (flight_time_ratio_l < 0.75)
            if turf_dive:
                turf_dive_count += 1
                status = "TURF_DIVE"
            else:
                status = "PASS"

            # Check max roll angle and stability
            max_phi_r = max(abs(p.phi) for p in rgt.points)
            max_phi_l = max(abs(p.phi) for p in lft.points)
            if math.degrees(max_phi_r) > 80.0 or math.degrees(max_phi_l) > 80.0:
                status = "TUMBLE"
                anomalies.append(f"V={v}, RPM={rpm}: Excessive bank angle")

            row = (
                "{:<8.1f} | {:<6.0f} | {:<9.2f} | {:<9.2f} | {:<9.2f} | {:<+9.2f} | {:<+11.2f} | {:<+11.2f} | {:<10.2f} | {:<9.2f} | {:<8}"
            ).format(
                v, rpm, nom.flight_time_s, rgt.flight_time_s, lft.flight_time_s, nom.terminal_y, dr, dl, corr, nom.max_altitude_m, status
            )
            print(row)
            envelope_results.append({
                "v": v, "rpm": rpm, "nom_t": nom.flight_time_s,
                "rgt_t": rgt.flight_time_s, "lft_t": lft.flight_time_s,
                "dr": dr, "dl": dl, "corr": corr, "status": status
            })

    print("=" * len(header))
    print(f"Summary: Total Grid Points: {len(envelope_results)}, Turf Dives: {turf_dive_count}, Anomalies: {len(anomalies)}")

    # Test Adaptive Steering Window / High Deflection (25 deg) for low speed (15 m/s)
    print("\n" + "=" * len(header))
    print("LOW-SPEED / ADAPTIVE STEERING STRESS TEST (V = 15 m/s, Deflection = 25 deg, Steer Window = 0.5s - 3.0s)")
    print("=" * len(header))
    print(header)
    print("-" * len(header))
    for rpm in rpms:
        nom = sim.simulate_throw("nominal", v0_m_s=15.0, rpm0=rpm)
        rgt = sim.simulate_throw("right", v0_m_s=15.0, rpm0=rpm, elevon_deflection_deg=25.0, steer_start_s=0.5, steer_end_s=3.0)
        lft = sim.simulate_throw("left", v0_m_s=15.0, rpm0=rpm, elevon_deflection_deg=25.0, steer_start_s=0.5, steer_end_s=3.0)
        dr = rgt.terminal_y - nom.terminal_y
        dl = lft.terminal_y - nom.terminal_y
        corr = rgt.terminal_y - lft.terminal_y
        row = (
            "{:<8.1f} | {:<6.0f} | {:<9.2f} | {:<9.2f} | {:<9.2f} | {:<+9.2f} | {:<+11.2f} | {:<+11.2f} | {:<10.2f} | {:<9.2f} | {:<8}"
        ).format(
            15.0, rpm, nom.flight_time_s, rgt.flight_time_s, lft.flight_time_s, nom.terminal_y, dr, dl, corr, nom.max_altitude_m, "PASS"
        )
        print(row)

if __name__ == "__main__":
    main()
