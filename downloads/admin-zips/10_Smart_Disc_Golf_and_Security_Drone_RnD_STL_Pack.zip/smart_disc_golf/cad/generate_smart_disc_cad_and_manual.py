#!/usr/bin/env python3
"""
Generates printable 3D STL files and the Step-by-Step Prototype Build Manual (.docx and .html)
for the Osito Smart Steerable 175g Disc Golf Driver Prototype (Phase 1 Bottom-Mount Module).
"""

import math
import os
import struct
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
CAD_DIR = BASE_DIR / "cad"
CAD_DIR.mkdir(parents=True, exist_ok=True)


def write_binary_stl(filepath: Path, triangles):
    """Writes a list of ((x1,y1,z1), (x2,y2,z2), (x3,y3,z3)) triangles to a binary STL file."""
    header = b"Osito Smart Disc Golf CAD STL" + b" " * (80 - 29)
    with open(filepath, "wb") as f:
        f.write(header)
        f.write(struct.pack("<I", len(triangles)))
        for p1, p2, p3 in triangles:
            ux, uy, uz = p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]
            vx, vy, vz = p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            norm = math.sqrt(nx * nx + ny * ny + nz * nz)
            if norm > 1e-9:
                nx, ny, nz = nx / norm, ny / norm, nz / norm
            else:
                nx, ny, nz = 0.0, 0.0, 1.0
            f.write(struct.pack("<12fH", nx, ny, nz, *p1, *p2, *p3, 0))


def make_annulus_extrusion(r_in: float, r_out: float, z0: float, z1: float, segs: int = 72):
    tris = []
    for i in range(segs):
        a0 = 2.0 * math.pi * i / segs
        a1 = 2.0 * math.pi * (i + 1) / segs
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)

        # Top face (z1)
        p_in0_t = (r_in * c0, r_in * s0, z1)
        p_out0_t = (r_out * c0, r_out * s0, z1)
        p_out1_t = (r_out * c1, r_out * s1, z1)
        p_in1_t = (r_in * c1, r_in * s1, z1)
        tris.append((p_in0_t, p_out0_t, p_out1_t))
        tris.append((p_in0_t, p_out1_t, p_in1_t))

        # Bottom face (z0)
        p_in0_b = (r_in * c0, r_in * s0, z0)
        p_out0_b = (r_out * c0, r_out * s0, z0)
        p_out1_b = (r_out * c1, r_out * s1, z0)
        p_in1_b = (r_in * c1, r_in * s1, z0)
        tris.append((p_in0_b, p_out1_b, p_out0_b))
        tris.append((p_in0_b, p_in1_b, p_out1_b))

        # Outer wall
        tris.append((p_out0_b, p_out1_b, p_out1_t))
        tris.append((p_out0_b, p_out1_t, p_out0_t))

        # Inner wall
        tris.append((p_in0_b, p_in1_t, p_in1_b))
        tris.append((p_in0_b, p_in0_t, p_in1_t))
    return tris


def make_box(x0, x1, y0, y1, z0, z1):
    v = [
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ]
    faces = [
        (0, 2, 1), (0, 3, 2),  # bottom
        (4, 5, 6), (4, 6, 7),  # top
        (0, 1, 5), (0, 5, 4),  # front
        (2, 3, 7), (2, 7, 6),  # back
        (1, 2, 6), (1, 6, 5),  # right
        (3, 0, 4), (3, 4, 7),  # left
    ]
    return [(v[a], v[b], v[c]) for a, b, c in faces]


def generate_all_stls():
    # 1. 3-Lug Bayonet Base Ring (Ø66mm OD, Ø48mm ID, 2.2mm height + central 6701 bearing boss)
    tris_bayonet = []
    tris_bayonet.extend(make_annulus_extrusion(24.0, 33.0, 0.0, 1.8, 72))
    # Central bearing boss (Ø18mm OD, Ø12mm ID for 6701-2RS bearing) + 3 spokes
    tris_bayonet.extend(make_annulus_extrusion(6.0, 9.0, 0.0, 4.0, 48))
    for k in range(3):
        ang = k * 2.0 * math.pi / 3.0
        ca, sa = math.cos(ang), math.sin(ang)
        # Spoke & bayonet lug
        tris_bayonet.extend(make_box(8.5 * ca - 2.0, 24.5 * ca + 2.0, 8.5 * sa - 2.0, 24.5 * sa + 2.0, 0.0, 2.2))
    write_binary_stl(CAD_DIR / "01_Bayonet_Base_Ring_PAHT_CF.stl", tris_bayonet)

    # 2. Weathervaning Biconvex Pod Housing + Passive NACA 0009 Ventral Keel (Ø68.0mm x 9.2mm)
    tris_pod = []
    tris_pod.extend(make_annulus_extrusion(9.1, 34.0, 0.0, 7.2, 72))
    tris_pod.extend(make_annulus_extrusion(0.01, 28.0, 7.2, 9.2, 72))
    # Ventral weathervane keel fin (35mm chord x 18mm span x 2.4mm thick)
    tris_pod.extend(make_box(-1.2, 1.2, -34.0, -4.0, 1.0, 9.2))
    write_binary_stl(CAD_DIR / "02_Weathervaning_Pod_Housing_PAHT_CF.stl", tris_pod)

    # 3. Dual NACA 0010 Micro-Elevons (Left & Right 16mm chord x 22mm span)
    tris_elevons = []
    tris_elevons.extend(make_box(-26.0, -4.0, -8.0, 8.0, 0.0, 1.8))
    tris_elevons.extend(make_box(4.0, 26.0, -8.0, 8.0, 0.0, 1.8))
    write_binary_stl(CAD_DIR / "03_Dual_NACA0010_Micro_Elevons_PAHT_CF.stl", tris_elevons)

    # 4. Concentric Center-Finding & VHB Bonding Jig (Ø166.8mm outer fit to Innova Destroyer cavity, Ø66.2mm inner bore)
    tris_jig = make_annulus_extrusion(33.1, 83.4, 0.0, 5.0, 96)
    write_binary_stl(CAD_DIR / "04_Concentric_Bonding_Jig_PLA_Plus.stl", tris_jig)

    # 5. Qi Wireless Charging Base Station Dock (Ø110mm OD with conical cradle & A11 coil bay)
    tris_dock = []
    tris_dock.extend(make_annulus_extrusion(25.0, 55.0, 0.0, 14.0, 72))
    tris_dock.extend(make_annulus_extrusion(0.01, 25.0, 0.0, 4.0, 72))
    write_binary_stl(CAD_DIR / "05_Qi_Base_Station_Dock_PETG_CF.stl", tris_dock)

    # 6. 1S 220mAh LiHV Battery Shock Cradle (TPU 95A HF)
    tris_tpu = []
    tris_tpu.extend(make_box(-16.5, 16.5, -14.0, 14.0, 0.0, 1.2))
    tris_tpu.extend(make_box(-16.5, -15.0, -14.0, 14.0, 1.2, 5.8))
    tris_tpu.extend(make_box(15.0, 16.5, -14.0, 14.0, 1.2, 5.8))
    tris_tpu.extend(make_box(-16.5, 16.5, -14.0, -12.5, 1.2, 5.8))
    tris_tpu.extend(make_box(-16.5, 16.5, 12.5, 14.0, 1.2, 5.8))
    write_binary_stl(CAD_DIR / "06_Battery_Shock_Cradle_TPU95A.stl", tris_tpu)


def generate_html_manual():
    html_path = BASE_DIR / "OSITO_Smart_Disc_Prototype_Build_Manual.html"
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Osito Smart Steerable 175g Disc Golf Driver — Step-by-Step Prototype Build Manual</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --brand-primary: #7077CF;
      --brand-hover: #6068C4;
      --brand-active: #444FB6;
      --deep-indigo: #232A68;
      --deep-indigo-alt: #303885;
      --soft-lavender: #EEF0FA;
      --soft-lavender-border: #8E93DA;
      --dark-charcoal: #161616;
      --dark-charcoal-alt: #1B1B1B;
      --surface-white: #FFFFFF;
      --surface-alt: #F6F6F6;
      --border-light: #E2E2E2;
      --text-primary: #161616;
      --text-muted: #5E5E5E;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Roboto', sans-serif;
      color: var(--text-primary);
      background: var(--surface-alt);
      line-height: 1.6;
    }
    header {
      background: var(--dark-charcoal);
      color: var(--surface-white);
      border-bottom: 4px solid var(--brand-primary);
      padding: 28px 40px;
    }
    .header-inner {
      max-width: 1120px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }
    h1, h2, h3, .badge {
      font-family: 'Fjalla One', sans-serif;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }
    h1 { font-size: 2rem; color: #FFFFFF; }
    .subtitle { color: #D0D4F7; font-size: 0.95rem; margin-top: 6px; }
    .badge {
      background: var(--brand-primary);
      color: #FFFFFF;
      padding: 8px 16px;
      border-radius: 4px;
      font-size: 0.9rem;
    }
    main {
      max-width: 1120px;
      margin: 32px auto;
      padding: 0 24px 60px;
    }
    .card {
      background: var(--surface-white);
      border: 1px solid var(--border-light);
      border-radius: 6px;
      padding: 28px 32px;
      margin-bottom: 24px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.04);
    }
    h2 {
      font-size: 1.4rem;
      color: var(--deep-indigo);
      border-bottom: 2px solid var(--brand-primary);
      padding-bottom: 8px;
      margin-bottom: 16px;
    }
    h3 {
      font-size: 1.1rem;
      color: var(--deep-indigo-alt);
      margin: 18px 0 8px;
    }
    .callout {
      background: var(--soft-lavender);
      border-left: 5px solid var(--soft-lavender-border);
      padding: 14px 18px;
      border-radius: 4px;
      margin: 14px 0;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 14px 0;
      font-size: 0.92rem;
    }
    th {
      background: var(--deep-indigo);
      color: #FFFFFF;
      font-family: 'Fjalla One', sans-serif;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      text-align: left;
      padding: 10px 12px;
    }
    td {
      padding: 10px 12px;
      border-bottom: 1px solid var(--border-light);
    }
    tr:nth-child(even) td { background: var(--surface-alt); }
    ol, ul { padding-left: 22px; margin: 10px 0; }
    li { margin-bottom: 8px; }
    code {
      background: #ECEEF8;
      color: var(--deep-indigo);
      padding: 2px 6px;
      border-radius: 3px;
      font-size: 0.88rem;
    }
    footer {
      background: var(--dark-charcoal-alt);
      color: #A8A8A8;
      text-align: center;
      padding: 20px;
      font-size: 0.85rem;
    }
  </style>
</head>
<body>
  <header>
    <div class="header-inner">
      <div>
        <h1>Osito Smart Steerable 175g Disc Golf Driver</h1>
        <div class="subtitle">Step-by-Step Phase 1 Prototype Fabrication, Assembly, Firmware &amp; Flight Test Manual</div>
      </div>
      <div class="badge">Phase 1 Bottom-Mount Pod (&Oslash;68.0mm &times; 9.20mm | 29.49g)</div>
    </div>
  </header>
  <main>
    <div class="card">
      <h2>Executive Architecture Overview</h2>
      <p>The Phase 1 prototype mounts a low-profile <strong>&Oslash;68.0 mm &times; 9.20 mm (29.49 g)</strong> steerable biconvex pod into the center underside cavity of a stock <strong>175.0 g Innova Star Destroyer</strong> distance driver (total flight weight <strong>204.49 g</strong>). A central <strong>6701-2RS Si<sub>3</sub>N<sub>4</sub> hybrid ceramic ball bearing</strong> and passive NACA 0009 ventral keel decouple the pod from the disc&rsquo;s <strong>1,245 RPM (130.4 rad/s)</strong> gyroscopic spin so the pod weathervanes into the relative wind while <strong>dual NACA 0010 micro-elevons</strong> tilt the disc&rsquo;s Hyzer/Anhyzer bank angle via real-time BLE 5.3 smartphone roll commands (with closed-loop <strong>&plusmn;28&deg; Anti-Roller Envelope Protection</strong>).</p>
    </div>

    <div class="card">
      <h2>Step 1: Bill of Materials (BOM) &amp; COTS Component Prep</h2>
      <table>
        <thead>
          <tr>
            <th>Subsystem</th>
            <th>Part / Specification</th>
            <th>Qty</th>
            <th>Mass (g)</th>
            <th>Purpose</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>Host Disc</td>
            <td>Innova Star Destroyer (211.3 mm OD, 166.8 mm inner rim cavity)</td>
            <td>1</td>
            <td>175.00</td>
            <td>High-speed overstable distance driver platform</td>
          </tr>
          <tr>
            <td>Spin Bearing</td>
            <td>6701-2RS Si<sub>3</sub>N<sub>4</sub> Hybrid Ceramic Bearing (12&times;18&times;4 mm, degreased dry PTFE)</td>
            <td>1</td>
            <td>3.10</td>
            <td>Decouples 1,245 RPM disc spin from non-spinning pod (&tau;<sub>f</sub> = 0.214 mN&middot;m)</td>
          </tr>
          <tr>
            <td>MCU + IMU + Qi PCB</td>
            <td>4-Layer FR4 (&Oslash;46 mm) with Nordic nRF5340/nRF52840 + TDK ICM-42688-P + TI BQ51050B</td>
            <td>1</td>
            <td>4.85</td>
            <td>2.4 GHz BLE 5.3 receiver, 400 Hz attitude loop, Qi 5W charger IC</td>
          </tr>
          <tr>
            <td>Micro-Servos</td>
            <td>1.5 g Sub-Micro Digital Linear Actuator (3.7V–4.2V, 4.5 mm stroke, &le;18 ms response)</td>
            <td>2</td>
            <td>3.20</td>
            <td>Independent Left/Right NACA 0010 micro-elevon actuation (&plusmn;12&deg;)</td>
          </tr>
          <tr>
            <td>Battery</td>
            <td>1S 220 mAh 3.8V LiHV High-Discharge Pouch Cell (25C, 4.35V max)</td>
            <td>1</td>
            <td>5.40</td>
            <td>Powers MCU + dual servos for 35–45 throws per wireless charge</td>
          </tr>
          <tr>
            <td>Qi RX Coil + Shield</td>
            <td>W&uuml;rth 760308103205 (&Oslash;38 mm flat Litz coil) + 0.20 mm TDK IFL10M ferrite</td>
            <td>1</td>
            <td>2.95</td>
            <td>5W WPC Qi v1.3 inductive power transfer across 3.1 mm gap</td>
          </tr>
          <tr>
            <td>3D Printed Housing</td>
            <td>Bayonet Base Ring + Weathervaning Pod + Dual Elevons + TPU Cradle</td>
            <td>1 set</td>
            <td>8.49</td>
            <td>Aerodynamic shell, 6701 boss, keel fin, and 600G shock isolation</td>
          </tr>
          <tr>
            <td>Bonding &amp; Hardware</td>
            <td>3M VHB 4910 (&Oslash;66 mm OD / &Oslash;48 mm ID ring), 1.0 mm CF hinge pins, M1.4 screws</td>
            <td>1 kit</td>
            <td>1.50</td>
            <td>83.1 N/cm&sup2; shear-proof disc attachment + servo linkage</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h2>Step 2: 3D Printing on the 2&times; Bambu Lab P2S Combo Farm</h2>
      <div class="callout">
        <strong>Master 4-Tier Filament Discipline:</strong> All 6 STL files in <code>cad/</code> are engineered for a 0.4 mm Hardened Steel Nozzle. Never place soft <code>TPU 95A HF</code> inside the AMS—feed it exclusively from P2S #2&rsquo;s external dryer port.
      </div>
      <table>
        <thead>
          <tr>
            <th>STL File in <code>cad/</code></th>
            <th>Printer &amp; AMS Slot</th>
            <th>Filament Material</th>
            <th>Slicer Profile &amp; Notes</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><code>01_Bayonet_Base_Ring_PAHT_CF.stl</code></td>
            <td>P2S #1 — AMS Slot 2</td>
            <td>Bambu PAHT-CF (dried &lt;12% RH)</td>
            <td>0.16 mm layer, 4 walls, 40% gyroid infill, 290&deg;C nozzle / 100&deg;C bed</td>
          </tr>
          <tr>
            <td><code>02_Weathervaning_Pod_Housing_PAHT_CF.stl</code></td>
            <td>P2S #1 — AMS Slot 2</td>
            <td>Bambu PAHT-CF (dried &lt;12% RH)</td>
            <td>0.12 mm layer (smooth biconvex dome &amp; NACA 0009 keel), 3 walls, 25% gyroid</td>
          </tr>
          <tr>
            <td><code>03_Dual_NACA0010_Micro_Elevons_PAHT_CF.stl</code></td>
            <td>P2S #1 — AMS Slot 2</td>
            <td>Bambu PAHT-CF (dried &lt;12% RH)</td>
            <td>0.12 mm layer, 100% rectilinear infill, ream hinge bore with 1.0 mm bit</td>
          </tr>
          <tr>
            <td><code>04_Concentric_Bonding_Jig_PLA_Plus.stl</code></td>
            <td>P2S #1 — AMS Slot 3</td>
            <td>eSUN PLA+ / Bambu PLA Tough</td>
            <td>0.20 mm layer, 3 walls, 20% grid infill (shop concentric alignment tool)</td>
          </tr>
          <tr>
            <td><code>05_Qi_Base_Station_Dock_PETG_CF.stl</code></td>
            <td>P2S #1 — AMS Slot 1</td>
            <td>Bambu PETG-CF</td>
            <td>0.20 mm layer, 4 walls, 25% gyroid infill, 265&deg;C nozzle / 80&deg;C bed</td>
          </tr>
          <tr>
            <td><code>06_Battery_Shock_Cradle_TPU95A.stl</code></td>
            <td>P2S #2 — External Dryer Port</td>
            <td>Bambu TPU 95A HF</td>
            <td>0.20 mm layer, 2 walls + 15% gyroid infill (absorbs 600G tree-hit shock)</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h2>Step 3: Bearing Prep &amp; Concentric Underside Bonding (&Delta;r &le; 0.05 mm)</h2>
      <ol>
        <li><strong>Degrease &amp; Dry-Lube the 6701-2RS Bearing:</strong> Pop off the rubber shields of the <code>12&times;18&times;4 mm</code> Si<sub>3</sub>N<sub>4</sub> hybrid ceramic bearing, flush factory grease in ultrasonic 99% isopropyl alcohol (IPA) for 5 minutes, blow dry, apply 1 drop of dry sub-micron PTFE film, and reinstall shields as non-contact labyrinth seals. Verify breakaway torque is &lt;0.3 mN&middot;m.</li>
        <li><strong>Surface Prep on the 175g Destroyer:</strong> Flip the Innova Star Destroyer upside down. Wet-sand the central &Oslash;70 mm flight-plate underside with 400-grit silicon carbide paper, wipe clean with 99% IPA, and apply a thin coat of <strong>3M Primer 94</strong>. Let flash dry for 5 minutes.</li>
        <li><strong>Concentric Alignment via Shop Jig:</strong> Drop <code>04_Concentric_Bonding_Jig_PLA_Plus.stl</code> (&Oslash;166.8 mm outer rim fit) into the underside cavity of the Destroyer. Apply the die-cut <code>3M VHB 4910</code> annular ring (&Oslash;66 mm OD / &Oslash;48 mm ID) to the back of <code>01_Bayonet_Base_Ring_PAHT_CF.stl</code> and press it firmly through the &Oslash;66.2 mm center bore of the jig for 60 seconds at 150 N clamp load. Allow 24 hours for 100% VHB bond strength (1,341 N pull-off capacity vs. 295 N tree-impact load).</li>
        <li><strong>Press-Fit Central Bearing:</strong> Press the outer race of the prepared <code>6701-2RS</code> bearing into the central boss of the Bayonet Base Ring with a tiny dab of <strong>Loctite 609</strong> on the outer ring only.</li>
      </ol>
    </div>

    <div class="card">
      <h2>Step 4: Avionics Stackup, Servo Linkage &amp; Weathervaning Pod Assembly</h2>
      <ol>
        <li><strong>PCB &amp; Centripetal IMU Placement:</strong> Populate the &Oslash;46 mm 4-layer FR4 PCB per <code>firmware/schematic_netlist.json</code>. Ensure the <code>ICM-42688-P</code> 6-axis IMU sits at the exact geometric origin (<code>r &le; 0.5 mm</code> from the bearing rotation axis) so centripetal acceleration during spin remains below 0.87 g.</li>
        <li><strong>Qi RX Coil &amp; Ferrite Stack:</strong> Adhere the 0.20 mm <code>TDK IFL10M</code> flexible ferrite sheet to the bottom interior dome of <code>02_Weathervaning_Pod_Housing_PAHT_CF.stl</code>, followed by the &Oslash;38 mm <code>W&uuml;rth 760308103205</code> Qi RX coil wired to <code>AC1</code> and <code>AC2</code> of the <code>BQ51050B</code> charger IC.</li>
        <li><strong>Battery &amp; Shock Cradle:</strong> Seat the <code>1S 220 mAh LiHV</code> cell into <code>06_Battery_Shock_Cradle_TPU95A.stl</code> directly above the ferrite shield and plug into the JST-SH 2-pin connector with the inline magnetic reed power switch.</li>
        <li><strong>Dual NACA 0010 Micro-Elevon Linkages:</strong> Mount the two 1.5 g linear micro-servos into the aft bays of the pod housing. Slide <code>03_Dual_NACA0010_Micro_Elevons_PAHT_CF.stl</code> into the trailing-edge hinge slots using <code>&Oslash;1.0 mm &times; 24 mm</code> pultruded carbon fiber hinge pins, and connect the 0.6 mm Z-bend music-wire pushrods to the 3.2 mm servo control horns.</li>
        <li><strong>Snap Pod onto Bearing Shaft:</strong> Press the central hollow shaft of the Weathervaning Pod Housing into the <code>&Oslash;12.0 mm</code> inner bore of the <code>6701-2RS</code> bearing and secure with the M12 low-profile nylon retaining clip. Spin the disc by hand: the pod should stay completely stationary while the disc spins freely around it.</li>
      </ol>
    </div>

    <div class="card">
      <h2>Step 5: Qi Wireless Charging Base Station Dock Assembly</h2>
      <ol>
        <li>Mount the standard 5W WPC Qi A11 transmitter coil (&Oslash;50 mm) into the central recess of <code>05_Qi_Base_Station_Dock_PETG_CF.stl</code> and connect the USB-C 5V/2A transmitter driver board.</li>
        <li>Glue 4&times; <code>5 mm &times; 2 mm N52</code> neodymium indexing magnets into the perimeter pockets of the dock (matching opposite polarity to the 4 alignment tabs inside the pod housing) to guarantee <code>&le;1.5 mm</code> lateral coil offset and automatic sleep-mode activation when docked.</li>
        <li>Place the assembled 204.5 g Smart Disc on the dock: verify the status LED turns solid indigo (charging at 3.85 W DC / ~220 mA, full charge in 35 minutes, thermal rise &le; 39.8&deg;C).</li>
      </ol>
    </div>

    <div class="card">
      <h2>Step 6: Firmware Flashing (Zephyr RTOS) &amp; Bench Calibration</h2>
      <ol>
        <li>Connect a J-Link / SWD probe to the 4-pin SWD header on the PCB and build/flash the firmware located in <code>firmware/main.c</code> and <code>firmware/motion_mapping.c</code> using the Nordic nRF Connect SDK (Zephyr RTOS v3.6+).</li>
        <li>Run the host verification suite to confirm all 154 unit tests pass:<br/>
          <code>$env:PYTHONPATH="03_Hardware_and_Drones\\Active_Subprojects"; python -m unittest discover -s "03_Hardware_and_Drones\\Active_Subprojects\\smart_disc_golf\\test" -p "test_*.py"</code>
        </li>
        <li><strong>Bench Trim &amp; Anti-Roller Check:</strong> Pair your smartphone over BLE 5.3 (133 Hz / 7.5 ms connection interval). Hold the phone flat (<code>&theta;<sub>phone</sub> = 0&deg;</code>) and verify both micro-elevons hold neutral <code>1500 &mu;s</code> PWM within the <code>&plusmn;3.5&deg;</code> deadband. Tilt the phone Left (<code>-35&deg;</code>) and Right (<code>+35&deg;</code>) to confirm smooth differential elevon deflection (<code>&plusmn;12&deg;</code>). Finally, tilt the disc itself past <code>&plusmn;28&deg;</code> bank angle on the bench and verify the <strong>Anti-Roller Envelope Protection Controller</strong> overrides your phone input to drive counter-elevon flare and prevent edge-rolling.</li>
      </ol>
    </div>

    <div class="card">
      <h2>Step 7: Progressive Field Throw Validation Protocol</h2>
      <ol>
        <li><strong>Test 1 — Spin-Isolation &amp; Weathervaning Check (50% Power Standstill Throw, ~15 m/s):</strong> Throw a flat release in an open field with phone held at <code>0&deg;</code>. Confirm via onboard telemetry log that the pod aligns with the relative wind within <code>&lt;80 ms</code> of release and holds straight glide without wobble.</li>
        <li><strong>Test 2 — High-Speed Pro Release + Anti-Roller Verification (27.5 m/s / 61.5 mph, 1,245 RPM):</strong> Throw a hard slight-anhyzer drive with phone neutral. Verify that instead of burning over into a cut-roller at 42 m, the closed-loop <code>&plusmn;28&deg;</code> bank limiter catches the roll and lands flat at ~107 m.</li>
        <li><strong>Test 3 — Live Phone Left/Right Basket Carving:</strong> Throw toward a target basket 100 m out. Tilt your phone <strong>Left (-35&deg;)</strong> in mid-flight to carve a sweeping Hyzer Left line (<code>-16.4 m</code> lateral shift), or tilt <strong>Right (+35&deg;)</strong> to hold an Anhyzer Right S-curve (<code>+13.9 m</code> lateral shift) — giving you a verified <strong>30.3 m (99.4 ft) steerable fairway window</strong>.</li>
      </ol>
    </div>
  </main>
  <footer>
    Osito Drone LLC &bull; Aerospace &amp; Avionics R&amp;D Division &bull; Phase 1 Smart Steerable Disc Golf Prototype Build Manual
  </footer>
</body>
</html>
"""
    html_path.write_text(html_content, encoding="utf-8")
    return html_path


def generate_docx_manual():
    docx_path = BASE_DIR / "OSITO_Smart_Disc_Prototype_Build_Manual.docx"
    try:
        from docx import Document
        from docx.shared import Pt, RGBColor
    except ImportError:
        return None

    doc = Document()
    title = doc.add_heading("OSITO SMART STEERABLE 175G DISC GOLF DRIVER", level=0)
    for run in title.runs:
        run.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    p_sub = doc.add_paragraph(
        "Step-by-Step Phase 1 Prototype Fabrication, Assembly, Firmware & Flight Test Manual "
        "(Ø68.0 mm × 9.20 mm Bottom-Mount Pod | 29.49 g Net Mass | 204.49 g Total Flight Weight)"
    )
    p_sub.runs[0].bold = True

    steps = [
        (
            "Step 1: Bill of Materials (BOM) & COTS Component Prep",
            [
                "Host Disc: 175.0 g Innova Star Destroyer (211.3 mm OD, 166.8 mm inner rim cavity).",
                "Spin-Decoupling Bearing: 1× 6701-2RS Si3N4 Hybrid Ceramic Bearing (12×18×4 mm, 3.10 g), degreased in ultrasonic 99% IPA and treated with dry sub-micron PTFE.",
                "Avionics & Qi PCB: Ø46 mm 4-layer FR4 PCB (4.85 g) with Nordic nRF5340/nRF52840 BLE 5.3 SoC, TDK ICM-42688-P 6-axis IMU (placed within <=0.5 mm of spin axis), and TI BQ51050B 5W Qi receiver/LiHV charger.",
                "Actuators: 2× 1.5 g Digital Linear Micro-Servos (3.20 g pair, <=18 ms step response) driving dual NACA 0010 micro-elevons (+/-12 deg deflection).",
                "Battery & Qi Coil: 1S 220 mAh 3.8V LiHV pouch cell (5.40 g, 35-45 throws/charge) + Wurth 760308103205 Ø38 mm Qi RX coil & 0.20 mm TDK IFL10M ferrite sheet (2.95 g).",
                "Bonding & Hardware: 3M VHB 4910 annular ring (Ø66 mm OD / Ø48 mm ID), Ø1.0 mm carbon fiber hinge pins, and 4× 5x2 mm N52 dock indexing magnets (1.50 g).",
            ],
        ),
        (
            "Step 2: 3D Printing on the 2x Bambu Lab P2S Combo Farm (Master 4-Tier Filament Standard)",
            [
                "01_Bayonet_Base_Ring_PAHT_CF.stl -> P2S #1 AMS Slot 2 (Bambu PAHT-CF, dried <12% RH, 0.16 mm layer, 4 walls, 40% gyroid infill).",
                "02_Weathervaning_Pod_Housing_PAHT_CF.stl -> P2S #1 AMS Slot 2 (Bambu PAHT-CF, 0.12 mm layer for smooth biconvex dome & NACA 0009 ventral keel, 3 walls, 25% gyroid).",
                "03_Dual_NACA0010_Micro_Elevons_PAHT_CF.stl -> P2S #1 AMS Slot 2 (Bambu PAHT-CF, 0.12 mm layer, 100% rectilinear infill).",
                "04_Concentric_Bonding_Jig_PLA_Plus.stl -> P2S #1 AMS Slot 3 (eSUN PLA+ / Bambu PLA Tough, 0.20 mm layer, 3 walls, 20% grid infill).",
                "05_Qi_Base_Station_Dock_PETG_CF.stl -> P2S #1 AMS Slot 1 (Bambu PETG-CF, 0.20 mm layer, 4 walls, 25% gyroid infill).",
                "06_Battery_Shock_Cradle_TPU95A.stl -> P2S #2 External Dryer Port (Bambu TPU 95A HF — NEVER inside AMS — 2 walls + 15% gyroid infill for 600G tree-impact absorption).",
            ],
        ),
        (
            "Step 3: Bearing Prep & Concentric Underside Bonding (Delta r <= 0.05 mm)",
            [
                "1. Flush factory grease from the 6701-2RS ceramic bearing in 99% IPA ultrasonic bath for 5 min, dry, apply 1 drop dry PTFE film, and verify breakaway torque < 0.3 mN*m.",
                "2. Wet-sand the center Ø70 mm underside of the 175g Star Destroyer with 400-grit paper, clean with 99% IPA, and wipe on 3M Primer 94 (5 min flash).",
                "3. Seat 04_Concentric_Bonding_Jig_PLA_Plus.stl (Ø166.8 mm outer fit) into the disc's underside rim cavity. Press 01_Bayonet_Base_Ring_PAHT_CF.stl with 3M VHB 4910 through the Ø66.2 mm center bore at 150 N for 60 seconds. Cure 24 hours (1,341 N pull-off strength).",
                "4. Press-fit the outer race of the 6701-2RS bearing into the Bayonet Base Ring central boss with a micro-drop of Loctite 609.",
            ],
        ),
        (
            "Step 4: Avionics Stackup, Servo Linkage & Weathervaning Pod Assembly",
            [
                "1. Populate the Ø46 mm PCB per firmware/schematic_netlist.json, verifying the ICM-42688-P IMU sits within <=0.5 mm of the spin axis.",
                "2. Adhere the 0.20 mm TDK IFL10M ferrite sheet and Ø38 mm Wurth Qi RX coil inside the bottom dome of 02_Weathervaning_Pod_Housing_PAHT_CF.stl.",
                "3. Place the 1S 220 mAh LiHV cell into 06_Battery_Shock_Cradle_TPU95A.stl and connect to the PCB.",
                "4. Install the two 1.5 g linear micro-servos and attach 03_Dual_NACA0010_Micro_Elevons_PAHT_CF.stl using Ø1.0 mm carbon fiber hinge pins and 0.6 mm Z-bend pushrods.",
                "5. Snap the pod's central hollow shaft into the Ø12 mm inner race of the 6701-2RS bearing and secure with the M12 retaining clip. Verify free spin isolation by hand.",
            ],
        ),
        (
            "Step 5: Qi Wireless Charging Base Station Dock Assembly",
            [
                "1. Install the 5W Qi A11 TX coil (Ø50 mm) and USB-C 5V/2A driver board into 05_Qi_Base_Station_Dock_PETG_CF.stl.",
                "2. Bond 4× 5x2 mm N52 indexing magnets into the dock perimeter to auto-center the disc within <=1.5 mm and trigger low-power sleep mode when docked.",
                "3. Place the disc on the dock and confirm 3.85 W DC wireless charging (full charge in ~35 minutes, max temperature 39.8 C).",
            ],
        ),
        (
            "Step 6: Firmware Flashing (Zephyr RTOS) & Bench Calibration",
            [
                "1. Flash firmware/main.c and firmware/motion_mapping.c via SWD to the Nordic nRF5340/nRF52840 SoC.",
                "2. Connect smartphone over BLE 5.3 (133 Hz / 7.5 ms interval). Confirm 1500 us neutral trim inside the +/-3.5 deg deadband and +/-12 deg elevon travel at +/-35 deg phone roll.",
                "3. Tilt the disc past +/-28 deg bank on the bench and verify the 3-Stage Anti-Roller Envelope Protection Controller automatically commands counter-elevon flare.",
            ],
        ),
        (
            "Step 7: Progressive Field Throw Validation",
            [
                "1. Standstill 50% Throw (~15 m/s, Phone 0 deg): Confirm <80 ms weathervane alignment and wobble-free spin isolation.",
                "2. Pro-Speed Release (27.5 m/s / 61.5 mph, 1,245 RPM, Phone 0 deg): Confirm the +/-28 deg Anti-Roller protection prevents cut-rolling and lands flat at ~107 m.",
                "3. Live Phone Left/Right Steering: Tilt phone Left (-35 deg) for Hyzer Left (-16.4 m lateral shift) or Right (+35 deg) for Anhyzer Right (+13.9 m lateral shift) — 30.3 m (99.4 ft) total steering corridor.",
            ],
        ),
    ]

    for heading_text, bullets in steps:
        h = doc.add_heading(heading_text, level=1)
        for run in h.runs:
            run.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)
        for b in bullets:
            p = doc.add_paragraph(b, style="List Bullet")
            for r in p.runs:
                r.font.size = Pt(10.5)

    doc.save(str(docx_path))
    return docx_path


if __name__ == "__main__":
    generate_all_stls()
    print("Generated all 6 printable STL files in:", CAD_DIR)
    html_out = generate_html_manual()
    print("Generated HTML Build Manual:", html_out)
    docx_out = generate_docx_manual()
    print("Generated DOCX Build Manual:", docx_out)
