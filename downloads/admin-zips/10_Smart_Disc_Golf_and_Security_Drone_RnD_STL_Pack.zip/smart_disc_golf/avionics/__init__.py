"""Avionics package."""
