"""
Avionics simulation runner forwarding to firmware/controller_sim.py.
"""
import os
import sys

# Add repository root (parent of smart_disc_golf) and smart_disc_golf root to path
SMART_DISC_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_ROOT = os.path.dirname(SMART_DISC_ROOT)

for path in [PROJECT_ROOT, SMART_DISC_ROOT]:
    if path not in sys.path:
        sys.path.insert(0, path)

from smart_disc_golf.firmware.controller_sim import run_all_tests

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
