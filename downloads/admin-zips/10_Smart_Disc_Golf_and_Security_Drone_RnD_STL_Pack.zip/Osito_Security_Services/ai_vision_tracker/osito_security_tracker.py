#!/usr/bin/env python3
"""
OSITO DRONE SERVICES — AI COMPUTER-VISION SECURITY TRACKER & NON-CONTACT DETERRENCE
File: osito_security_tracker.py

Legal & Operational Architecture:
- Maintains a safe 35m–50m (115–165 ft) standoff altitude above ground level (AGL).
- Never makes physical contact with subjects; uses AI bounding-box lock, PID gimbal steering,
  ground-plane WGS84 GPS raycasting, high-output 10,000-lumen LED spotlight control,
  and 110 dB PA speaker warnings while streaming live target GPS pins to ground security.
"""

import argparse
import json
import math
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@dataclass
class BoundingBox:
    track_id: int
    label: str  # "person", "vehicle"
    confidence: float
    x_min: int
    y_min: int
    x_max: int
    y_max: int

    @property
    def center(self) -> Tuple[float, float]:
        return ((self.x_min + self.x_max) / 2.0, (self.y_min + self.y_max) / 2.0)


@dataclass
class DroneState:
    lat: float
    lon: float
    agl_m: float
    heading_deg: float
    gimbal_pitch_deg: float  # Negative = looking down (e.g., -45.0 deg)
    gimbal_yaw_deg: float


@dataclass
class DeterrenceTelemetry:
    frame_index: int
    timestamp_utc: str
    target_id: int
    target_class: str
    pixel_error_x: float
    pixel_error_y: float
    cmd_yaw_rate_dps: float
    cmd_pitch_rate_dps: float
    estimated_target_lat: float
    estimated_target_lon: float
    slant_range_m: float
    standoff_agl_m: float
    spotlight_pwm: int      # 1000 = OFF, 2000 = 10,000-Lumen Strobe/Beam ON
    pa_speaker_pwm: int     # 1000 = IDLE, 1900 = Broadcast Audio Deterrence Warning
    deterrence_state: str   # "MONITORING", "SPOTLIGHT_ILLUMINATE", "PA_AUDIO_WARNING_AND_DISPATCH"


class PIDController:
    """Discrete PID controller with anti-windup and output clamping for gimbal/yaw tracking."""

    def __init__(self, kp: float, ki: float, kd: float, max_output: float = 45.0):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.max_output = max_output
        self.integral = 0.0
        self.prev_error = 0.0

    def update(self, error: float, dt: float) -> float:
        if dt <= 0.0:
            return 0.0
        self.integral = max(-100.0, min(100.0, self.integral + error * dt))
        derivative = (error - self.prev_error) / dt
        self.prev_error = error
        output = (self.kp * error) + (self.ki * self.integral) + (self.kd * derivative)
        return max(-self.max_output, min(self.max_output, output))


def project_pixel_to_wgs84(
    bbox_center: Tuple[float, float],
    image_size: Tuple[int, int],
    hfov_deg: float,
    vfov_deg: float,
    drone: DroneState,
) -> Tuple[float, float, float]:
    """
    Raycast a 2D camera pixel coordinate onto the flat ground plane using drone AGL altitude,
    heading, and gimbal pitch/yaw to estimate the intruder's exact WGS84 (lat, lon) and slant range.
    """
    img_w, img_h = image_size
    cx, cy = bbox_center

    # Normalized angular offsets from optical axis
    norm_x = (cx - (img_w / 2.0)) / (img_w / 2.0)
    norm_y = (cy - (img_h / 2.0)) / (img_h / 2.0)

    delta_yaw_deg = norm_x * (hfov_deg / 2.0)
    delta_pitch_deg = -norm_y * (vfov_deg / 2.0)

    # Total depression angle below horizon (positive downward)
    total_pitch_down_deg = max(5.0, min(89.5, -(drone.gimbal_pitch_deg + delta_pitch_deg)))
    pitch_rad = math.radians(total_pitch_down_deg)

    # Horizontal ground distance and 3D slant range from drone nadir
    ground_dist_m = drone.agl_m / math.tan(pitch_rad)
    slant_range_m = math.hypot(drone.agl_m, ground_dist_m)

    # True compass bearing to target
    target_bearing_deg = (drone.heading_deg + drone.gimbal_yaw_deg + delta_yaw_deg) % 360.0
    bearing_rad = math.radians(target_bearing_deg)

    # Offset in meters North and East
    north_m = ground_dist_m * math.cos(bearing_rad)
    east_m = ground_dist_m * math.sin(bearing_rad)

    # Convert meters to WGS84 degrees
    dlat = north_m / 111111.0
    dlon = east_m / (111111.0 * math.cos(math.radians(drone.lat)))

    return (round(drone.lat + dlat, 7), round(drone.lon + dlon, 7), round(slant_range_m, 2))


class OsitoSecurityVisionTracker:
    """
    Tracks trespassers/vehicles from a safe standoff altitude, keeps the camera locked on target,
    computes live ground GPS coordinates, and sequences non-contact deterrence (Spotlight + PA Audio).
    """

    def __init__(
        self,
        image_size: Tuple[int, int] = (1920, 1080),
        hfov_deg: float = 64.0,
        vfov_deg: float = 38.0,
        safe_standoff_agl_m: float = 45.0,
    ):
        self.image_size = image_size
        self.hfov_deg = hfov_deg
        self.vfov_deg = vfov_deg
        self.safe_standoff_agl_m = max(30.0, safe_standoff_agl_m)  # Enforce >= 30m safe standoff
        self.yaw_pid = PIDController(kp=0.045, ki=0.002, kd=0.012, max_output=35.0)
        self.pitch_pid = PIDController(kp=0.040, ki=0.002, kd=0.010, max_output=25.0)
        self.dwell_frames: Dict[int, int] = {}

    def process_detection(
        self,
        frame_index: int,
        bbox: BoundingBox,
        drone: DroneState,
        dt: float = 0.05,
    ) -> DeterrenceTelemetry:
        img_w, img_h = self.image_size
        cx, cy = bbox.center

        # Pixel error relative to image center reticle
        err_x = cx - (img_w / 2.0)
        err_y = cy - (img_h / 2.0)

        # PID angular rate commands (deg/sec) to center target in frame
        cmd_yaw_rate = round(self.yaw_pid.update(err_x, dt), 2)
        cmd_pitch_rate = round(self.pitch_pid.update(-err_y, dt), 2)

        # Raycast target ground GPS coordinate
        t_lat, t_lon, slant_m = project_pixel_to_wgs84(
            (cx, cy), self.image_size, self.hfov_deg, self.vfov_deg, drone
        )

        # Non-contact deterrence escalation based on loiter time in restricted perimeter
        count = self.dwell_frames.get(bbox.track_id, 0) + 1
        self.dwell_frames[bbox.track_id] = count

        if count < 5:
            state = "MONITORING"
            spotlight_pwm = 1000
            pa_pwm = 1000
        elif count < 10:
            state = "SPOTLIGHT_ILLUMINATE"
            spotlight_pwm = 2000  # 10,000-lumen beam ON
            pa_pwm = 1000
        else:
            state = "PA_AUDIO_WARNING_AND_DISPATCH"
            spotlight_pwm = 2000  # Spotlight locked on intruder
            pa_pwm = 1900         # Trigger onboard 110dB PA announcement

        return DeterrenceTelemetry(
            frame_index=frame_index,
            timestamp_utc=datetime.now(timezone.utc).isoformat(),
            target_id=bbox.track_id,
            target_class=bbox.label,
            pixel_error_x=round(err_x, 1),
            pixel_error_y=round(err_y, 1),
            cmd_yaw_rate_dps=cmd_yaw_rate,
            cmd_pitch_rate_dps=cmd_pitch_rate,
            estimated_target_lat=t_lat,
            estimated_target_lon=t_lon,
            slant_range_m=slant_m,
            standoff_agl_m=drone.agl_m,
            spotlight_pwm=spotlight_pwm,
            pa_speaker_pwm=pa_pwm,
            deterrence_state=state,
        )


def run_synthetic_overwatch_test(output_path: Path) -> List[DeterrenceTelemetry]:
    """Simulate a 15-frame night thermal perimeter intrusion lock & deterrence sequence."""
    tracker = OsitoSecurityVisionTracker()
    drone = DroneState(
        lat=37.7706000,
        lon=-122.3916000,
        agl_m=45.0,
        heading_deg=90.0,
        gimbal_pitch_deg=-42.0,
        gimbal_yaw_deg=0.0,
    )

    history: List[DeterrenceTelemetry] = []
    # Simulated intruder starts off-center at (1320, 720) and gimbal steers toward center (960, 540)
    cur_x, cur_y = 1320.0, 720.0

    print("=" * 82)
    print("OSITO OVERWATCH-T — AI VISION TRACKER & NON-CONTACT DETERRENCE LOG")
    print(f"Safe Standoff Altitude: {drone.agl_m:.1f}m AGL (Zero-Contact Overwatch Mode)")
    print("=" * 82)

    for frame_idx in range(1, 16):
        bbox = BoundingBox(
            track_id=101,
            label="person_intruder",
            confidence=0.94,
            x_min=int(cur_x - 40),
            y_min=int(cur_y - 90),
            x_max=int(cur_x + 40),
            y_max=int(cur_y + 90),
        )
        telem = tracker.process_detection(frame_idx, bbox, drone, dt=0.1)
        history.append(telem)

        # Simulate closed-loop gimbal convergence toward optical center
        cur_x -= telem.pixel_error_x * 0.35
        cur_y -= telem.pixel_error_y * 0.35

        print(
            f"Frame {frame_idx:02d} | Err: ({telem.pixel_error_x:6.1f}, {telem.pixel_error_y:6.1f}) px | "
            f"Gimbal Rate: ({telem.cmd_yaw_rate_dps:5.2f}, {telem.cmd_pitch_rate_dps:5.2f}) deg/s | "
            f"Intruder GPS: ({telem.estimated_target_lat:.6f}, {telem.estimated_target_lon:.6f}) | "
            f"State: {telem.deterrence_state}"
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps([asdict(t) for t in history], indent=2), encoding="utf-8")
    print("-" * 82)
    print(f"Saved AI Tracking & Deterrence Telemetry Log: {output_path}")
    return history


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Osito AI Security Vision Tracker")
    parser.add_argument(
        "--output",
        type=str,
        default=str(Path(__file__).parent / "logs" / "ai_overwatch_telemetry.json"),
        help="Output telemetry JSON file",
    )
    args = parser.parse_args()
    run_synthetic_overwatch_test(Path(args.output))
