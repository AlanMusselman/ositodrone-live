# Osito Drone Services (A Commercial Division of Osito Drone LLC) — B2B Airspace & Perimeter Security Playbook, Hardware BOM & Pricing Model

**Owners:**
- **Alan Musselman** — COO & Co-Founder (`alan@ositodrone.com` | `415-810-4158`) — *Pricing, Security Contracts, Insurance & FAA/Venue Compliance*
- **Miguel Flores** — CEO & Co-Founder (`miguel@ositodrone.com` | `415-571-6614`) — *Enterprise, Construction, Stadium & VIP Estate Accounts*
- **Jesus Aceves** — CTO & Co-Founder (`jesus@ositodrone.com` | `415-269-1206`) — *`WATCHTOWER-1` Sensor Nodes, `OVERWATCH-T` Fleet & Edge AI Integration*

---

## 1. Executive Summary: 100% Legal, High-Margin Drone Security

Private security clients (construction sites, auto dealerships, solar farms, stadiums, corporate campuses, and VIP estates) face two major threats:
1. **Ground Trespassers & Property Theft:** Paying 2–4 ground security guards `$45–$75/hr` each (`$7,500–$25,000+/month`) to walk fence lines in the dark with flashlights leaves massive blind spots.
2. **Unauthorized Drones & Corporate Espionage / Disruption:** Clients want to know immediately when an unauthorized drone enters their airspace—and more importantly, **where the pilot is standing on the ground** so security or police can confront them without violating federal anti-jamming or aircraft sabotage laws.

Osito Drone Services solves both problems with **100% FAA Part 107 / Part 89 and FCC-compliant technology**:
- **`OSITO WATCHTOWER-1` (Passive FAA Remote ID & Pilot Locator Node):** A `$184.40` BOM weatherproof sensor node that passively decodes ASTM F3411 Wi-Fi/BLE Remote ID packets up to 1.5 km away, plotting both the rogue drone and **the pilot's exact ground GPS coordinates** in real time.
- **`OSITO OVERWATCH-T` (AI Thermal + 10,000-Lumen Spotlight + 110dB PA Security Drone):** Flies at a safe, non-contact standoff altitude (`45m / 150 ft AGL`, `>= 30m AGL` minimum floor), locks onto intruders in total darkness using LWIR thermal + YOLOv8 computer vision, illuminates them with a 10,000-lumen gimbal spotlight, announces warnings via a 110dB onboard PA speaker, and drops a live GPS pin on ground guards' tablets. *(Cross-Reference Note: Outdoor B2B perimeter overwatch utilizes the 7-inch `OSITO OVERWATCH-T` at `>=30m AGL`, whereas indoor GPS-denied containment research utilizes the sub-250g `101.9g–114.4g` ducted `OSITO-INT-95` testbed documented in [`../../../../AI Security Drone/`](../../../../AI%20Security%20Drone/)).*

---

## 2. Deterministic Security Hardware BOM & Fleet CapEx

### 2A. `OSITO WATCHTOWER-1` Passive Remote ID & Spectrum Sensor Node (`$184.40` Unit BOM)
Designed for permanent rooftop/pole installation or portable tripod deployment at events. Because it is **100% passive (receive-only)**, it requires **zero FCC transmit waivers** and is legal to deploy at any commercial venue.

| Component | Spec & Model | Unit Cost | Sourcing / Role |
| :--- | :--- | :---: | :--- |
| **Dual-Radio MCU Sniffer** | ESP32-S3-DevKitC-1U (External U.FL IPEX Antenna Port) | \$14.50 | Promiscuous 2.4 GHz Wi-Fi Beacon/NAN + BLE 5 Long Range ASTM F3411 decoder |
| **Edge Gateway & SDR Host** | Raspberry Pi 5 (4GB) + Official Active Cooler + 64GB Industrial microSD | \$74.90 | Runs `remote_id_dashboard.py`, local SQLite evidence logger & Tailscale VPN |
| **High-Gain 2.4 GHz Outdoor Antenna** | 9 dBi Fiberglass Omni N-Female Antenna + Low-Loss LMR-200 Coax Pigtail | \$34.00 | Extends passive Remote ID reception radius to `1.2–1.8 km` line-of-sight |
| **Passive 5.8 GHz FPV Analog Scanner** | RX5808 5.8GHz 48-Channel Diversity Receiver Module (SPI controlled) | \$18.50 | Passively detects & previews unencrypted 5.8 GHz hobby FPV video feeds nearby |
| **Weatherproof Enclosure & Power** | IP66 Polycarbonate NEMA Box + Active PoE Splitter (802.3af 48V to 5V 4A) | \$29.50 | Single-cable Ethernet + Power installation on client rooftops or light poles |
| **In-House 3D-Printed Mounts** | ASA UV-Resistant Pole/Tripod Bracket & Cable Gland Set (`180g` ASA) | \$5.50 | Printed in-house by Jesus Aceves |
| **Fasteners & Surge Arrestor** | Stainless M4 hardware, RJ45 Lightning Arrestor, Silicone Gasket | \$7.50 | Weatherproofing & ESD protection |
| **TOTAL `WATCHTOWER-1` NODE BOM** | **Complete Passive Airspace & Pilot-Locating Sensor Node** | **\$184.40** | **Amortized over 12 months = \$15.37 / month** |

---

### 2B. `OSITO OVERWATCH-T` AI Thermal + Non-Contact Deterrence Drone (`$1,645.00` Unit BOM)
Custom 7-inch heavy-endurance quadcopter engineered for 32-minute flight times, whisper-quiet low-RPM props, thermal/starlight vision, and non-contact deterrence payloads.

| Component | Spec & Model | Unit Cost | Sourcing / Role |
| :--- | :--- | :---: | :--- |
| **Airframe & Folding Arms** | 7-Inch Long-Range Carbon Fiber Frame (`5mm` arms) + Osito 3D-Printed ASA Payload Bay | \$89.00 | Vibration-isolated payload rail for thermal gimbal & spotlight |
| **Flight Controller & ESC Stack** | Holybro Kakute H7 v1.3 + Tekko32 F4 50A 4-in-1 BLHeli_32 ESC (ArduCopter firmware) | \$139.00 | Dual-IMU redundancy, MAVLink telemetry routing, automated RTL & geofencing |
| **Propulsion & Low-Noise Props** | 4x BrotherHobby Avenger 2806.5 1300KV Motors + HQProp 7x4x3 Glass-Nylon Props | \$136.00 | High efficiency, low acoustic signature at 45m standoff altitude |
| **GNSS & Precision Hold** | Matek M10Q-5883 GPS/Compass + Downward Rangefinder LiDAR | \$48.00 | Centimeter-level loiter stability & automated waypoint perimeter patrols |
| **Companion AI Computer** | Raspberry Pi 5 (8GB) + Hailo-8L 13-TOPS AI Accelerator HAT | \$150.00 | Runs `osito_security_tracker.py` (YOLOv8 at 34 FPS + WGS84 ground GPS raycasting) |
| **Thermal + Starlight Gimbal** | 2-Axis Stabilized 256×192 / 640×512 LWIR Thermal + 4K Low-Light Starlight Camera | \$649.00 | Detects human heat signatures at 250m+ in zero illumination |
| **Non-Contact Deterrence Kit** | 10,000-Lumen CREE LED Strobe/Spotlight (`Ch 9`) + 110dB Digital PA Megaphone (`Ch 10`) | \$185.00 | Illuminates trespassers from 150 ft up & broadcasts live/recorded voice warnings |
| **FAA Compliance & Safety** | FAA 3-Statute-Mile Anti-Collision Strobe + Built-in ASTM F3411 Standard Remote ID | \$69.00 | Full 14 CFR Part 107.29 Night Operations & Part 89 Remote ID compliance |
| **High-Density Battery Pack** | 6S2P 8000mAh 21700 Li-Ion Endurance Pack (2x packs per kit) | \$180.00 | 32–36 minutes continuous patrol time per pack |
| **TOTAL `OVERWATCH-T` DRONE BOM** | **Complete AI Thermal + Spotlight + PA Security UAV** | **\$1,645.00** | **Amortized over 60 patrol shifts = \$27.42 / shift** |

*(Optional Add-On: **Kevlar Micro-Tether Ground Power Station** — `$680.00` BOM using a 1200W 48V ground PSU + 60m high-voltage micro-tether + airborne buck converter for unlimited 8–24 hour continuous hover at stadiums and festivals).*

---

## 3. Client-Facing Security Packages & Unit Economics

| Pkg Code | Security Service Package | Format & Deliverables | Staffing & Hardware Deployed | Client Price | Hardware + Spares Cost | Founder-Led Gross Profit (Margin) | Hired-Pilot Gross Profit (Margin @ \$65/hr Part 107 Pilot) |
| :--- | :--- | :--- | :--- | :---: | :---: | :---: | :---: |
| **`SEC-1`** | **`WATCHTOWER` Passive Airspace & Pilot-Locator Subscription** | **24/7 Automated Monitoring** (1x Rooftop `WATCHTOWER-1` Node + Live Web Radar + Instant SMS/Email Pilot-GPS Breach Alerts + Monthly FAA Evidence Log) | Automated Node (0 On-Site Staff Required; `$300` One-Time Install Fee) | **\$495.00 / mo** *(+\$300 install)* | **\$25.37 / mo** *(\$15.37 node amort + \$10 cloud/SIM)* | **\$469.63 / mo** (**94.9%**) | **\$469.63 / mo** (**94.9%**) |
| **`SEC-2`** | **Nightly Thermal Perimeter Patrol (Mobile Strike Subscription)** | **4x Scheduled/Random Night Patrols per Week** (30-Min Thermal + Spotlight Overwatch Sweep of Construction Site, Solar Farm, or Auto Lot + Incident Video Report) | 1x Part 107 Night Pilot (`$65/hr`) + 1x `OVERWATCH-T` Drone (`16 patrols/mo`, ~12 hrs total labor/mo) | **\$2,400.00 / mo** *(\$150 / patrol)* | **\$160.00 / mo** *(\$10/patrol amort & battery wear)* | **\$2,240.00 / mo** (**93.3%**) | **\$1,460.00 / mo** (**60.8%**) |
| **`SEC-3`** | **VIP Event / Festival Airspace & Tethered Thermal Overwatch (1-Day)** | **6-Hour Live Security Deployment** (1x Tethered/Free-Flight `OVERWATCH-T` + 1x `WATCHTOWER-1` Rogue Drone/Pilot Locator Radar at Security Command Post) | 2 Staff (1x Part 107 Pilot @ `$65/hr` + 1x Airspace Radar Tech @ `$30/hr`) | **\$2,200.00 / event** | **\$75.00 / event** | **\$2,125.00** (**96.6%**) | **\$1,555.00** (**70.7%**) |
| **`SEC-4`** | **Corporate / Facility "Red-Team" Airspace & Perimeter Audit** | **Half-Day Authorized Penetration Test** (Simulated Rogue Drone Intrusion, Fence/Roof Thermal Blind-Spot Mapping, Guard Response Timing & Executive Remediation Report) | 2 Staff (Miguel + Jesus/Alan, or Hired Part 107 Pilot @ `$65/hr`) + 2x Drones + 1x `WATCHTOWER-1` | **\$3,500.00 / audit** | **\$85.00 / audit** | **\$3,415.00** (**97.6%**) | **\$2,895.00** (**82.7%**) |
| **`SEC-5`** | **Turnkey `WATCHTOWER` Enterprise Campus Hardware + 1-Yr SaaS Bundle** | **3x `WATCHTOWER-1` Triangulation Nodes** (Covers 50+ Acre Campus/Stadium) + Turnkey Installation + 12 Months 24/7 Airspace & Pilot-Locating Dashboard | 3x `WATCHTOWER-1` Nodes + 1-Day Install | **\$14,500.00 / yr** | **\$853.20** *(Full 3-Node BOM paid off Day 1 + \$300 cloud)* | **\$13,646.80** (**94.1%**) | **\$13,196.80** (**91.0%**) |

---

## 4. Client ROI Comparison: Why Security Directors Buy Osito

When pitching construction general contractors, auto dealership groups, event producers, or corporate security directors, use this side-by-side ROI math:

| Metric | Traditional Ground Guard Patrol (2 Overnight Guards) | Osito `SEC-2` Thermal Overwatch + `SEC-1` Watchtower | Client Savings / Advantage |
| :--- | :--- | :--- | :--- |
| **Monthly Cost** | **\$14,400 / mo** (`2 guards × $45/hr × 40 hrs/wk × 4 wks`) | **\$2,895 / mo** (`$2,400 Thermal Patrol + $495 Watchtower`) | **Saves \$11,505 / month (80% Cost Reduction)** |
| **Time to Sweep 15-Acre Lot** | **45–60 Minutes** on foot with a flashlight | **4 Minutes** from `150 ft AGL` with 640×512 Thermal Camera | **12x Faster Perimeter Verification** |
| **Night Visibility** | `30 ft` flashlight cone; easily evaded by hiding behind vehicles/containers | **250m+ heat-signature detection**; impossible to hide behind shadows or brush | **Zero Blind Spots** |
| **Intruder Engagement** | Guard walks into dark corner alone (high physical liability & assault risk) | Drone stays at **150 ft safe altitude**, hits intruder with **10,000-lumen spotlight + 110dB voice warning**, and pins exact GPS for police | **Zero Physical Confrontation / Zero Guard Injury Risk** |
| **Rogue Drone Defense** | Guards look up at blinking light with no idea who is flying it | `WATCHTOWER-1` immediately logs drone serial number and **pins the pilot's exact GPS location on the ground** | **Actionable Pilot Interception & FAA Evidence** |

---

## 5. Standard Operating Procedures (SOP) & Legal Compliance Checklist

To keep Osito Drone Services 100% protected legally and insured under your `$1M/$2M` Aviation CGL policy:

1. **Zero Physical Contact / Safe Standoff Floor (`>= 30m / 100 ft AGL`):**
   - `OVERWATCH-T` flight controllers have a hard-coded minimum altitude floor during tracking (`30m–45m AGL`). The drone **never** dives at, touches, or chases a person at low level. Deterrence is achieved strictly via **high-altitude thermal lock, 10,000-lumen spotlight illumination, 110dB PA audio warnings, and real-time GPS coordinate dispatch** to ground security/law enforcement.
2. **Zero Active RF Jamming or Spoofing (100% Passive Reception):**
   - `WATCHTOWER-1` nodes operate strictly in **receive-only (promiscuous sniffer) mode**. They never transmit jamming noise, deauthentication packets, or protocol hijacks, keeping Osito 100% compliant with **FCC 47 U.S.C. § 333** and **18 U.S.C. § 32**.
3. **14 CFR Part 107 Night Operations & Anti-Collision Lighting:**
   - All night patrols use dual 3-statute-mile anti-collision strobes (`14 CFR § 107.29`) and maintain visual line of sight (VLOS) or operate within tethered/waivered parameters.
4. **Privacy & Data Retention Compliance:**
   - Thermal/optical recording is restricted to the client's private property boundary under a signed **Property Owner Authorization & Aerial Monitoring Agreement**.
