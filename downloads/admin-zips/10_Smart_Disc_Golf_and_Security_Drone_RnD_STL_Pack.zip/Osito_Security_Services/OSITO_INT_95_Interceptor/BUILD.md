# Osito AI Security Drone: Production Technical Build & Deployment Guide (BUILD.md)

**Document Reference**: OSITO-ENG-BLD-001  
**Target Airframe**: `OSITO_Interceptor_95mm_Frame.stl` (95mm Wheelbase Ducted Unibody)  
**Avionics Architecture**: ArduPilot Copter 4.2+ on STM32F405 / STM32H743 AIO with AP_Scripting Engine  
**Autonomy Payloads**: `walk_to_fly.lua` (Perimeter Generation) & `osito_corner_intercept.lua` (Zero-Contact Interception)  
**Classification**: Production Technical Specification & Fabrication Manual  

---

## 1. Production Bill of Materials (BOM) & Weight Budget

### 1.1 Master Bill of Materials (BOM)
The following table itemizes all flight-ready components required to fabricate, assemble, and commission the Osito 95mm AI Security Drone. Component selection is directly constrained by the physical mounting interfaces, duct dimensions, and electrical requirements derived from `OSITO_Interceptor_95mm_Frame.stl` and ArduPilot AP_Scripting runtime requirements.

| Subsystem | Component Description | Manufacturer / Part # | Qty | Unit Mass (g) | Subtotal Mass (g) | Est. Unit Cost (USD) | Source / Vendor |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **Airframe** | 95mm Ducted Unibody Frame (PC / PA12-CF, 54.18mm Duct ID, 25.5mm FC Mount; `18.0g–18.56g` across PA12-CF/PC) | Custom / `OSITO_Interceptor_95mm_Frame.stl` | 1 | 18.0 g | 18.0 g | $12.00 | In-House SLS / Injection Mold |
| **Canopy** | Aerodynamic Micro Canopy (Houses 14mm Nano Cam & ESP32-S3, 20° Tilt, TPU 95A) | Custom Osito Canopy / BetaFPV Micro Lite | 1 | 3.5 g | 3.5 g | $4.00 | FDM TPU / BetaFPV |
| **Flight Controller & ESC** | 25.5x25.5mm AIO STM32F405 / H743 + 20A–30A BLHeli_S/32 ESC, MicroSD Slot | BetaFPV F405 20A AIO / Flywoo GOKU GN F405 | 1 | 7.5 g | 7.5 g | $65.00 | BetaFPV / Flywoo / GetFPV |
| **Propulsion: Motors** | 1103 8500KV (2S Indoor) or 1202.5 6000KV (3S Tactical), 3-hole 6.6mm PCD | Flywoo ROBO 1202.5 / BetaFPV 1103 Brushless | 4 | 4.0 g | 16.0 g | $12.00 ($48.00 total) | Flywoo / BetaFPV |
| **Propulsion: Props** | 2.0-inch 4-Blade Ducted Whoop Propellers (1.5mm Press-Fit Shaft, 50.8mm OD) | Gemfan 2020 4-Blade Ducted Props | 4 | 0.8 g | 3.2 g | $3.50 (Set of 4) | Gemfan / Pyrodrone |
| **Indoor Sensor Board** | Optical Flow (PMW3901) + Time-of-Flight LiDAR Rangefinder (VL53L1X up to 4.0m / VL53L0X) | Matek Systems 3901-L1X / 3901-L0X (MSP/UART) | 1 | 2.5 g | 2.5 g | $24.00 | Matek Systems |
| **Outdoor RTK GNSS** | Centimeter-Level RTK GNSS Receiver (u-blox NEO-M9N / ZED-F9P) | Matek SAM-M8Q / SparkFun Micro RTK F9P | 1 | 8.5 g | 8.5 g | $45.00 | Matek / SparkFun |
| **RC Receiver** | 2.4GHz ExpressLRS (ELRS) Nano Receiver with TCXO & Ceramic Antenna | Happymodel EP2 / BetaFPV ELRS Nano 2.4G | 1 | 1.0 g | 1.0 g | $14.00 | Happymodel / BetaFPV |
| **FPV Camera** | 14mm Nano FPV Camera (1200TVL, 0.001 Lux Starlight Night Vision) | RunCam Nano 4 / Caddx Ant Nano 14mm | 1 | 2.0 g | 2.0 g | $18.00 | RunCam / Caddx |
| **Video Transmitter** | 5.8GHz 25mW–400mW Micro Video Transmitter with SmartAudio Protocol | Happymodel OVX303 / Whoop Micro VTX | 1 | 2.2 g | 2.2 g | $16.00 | Happymodel / Makerfire |
| **Companion Vision AI** | ESP32-S3 AI Cam Module (OmniVision Cam, MAVLink Target Streamer) | Seeed Studio XIAO ESP32-S3 Sense | 1 | 4.5 g | 4.5 g | $15.00 | Seeed Studio |
| **Hardware & Fasteners** | M2 Silicone Anti-Vibration Grommets, M1.6x4mm & M2x12mm Screws, XT30 Pigtail | Osito Fastener & Harness Kit | 1 | 3.5 g | 3.5 g | $5.00 | McMaster-Carr / Drone Hardware |
| **Battery: 2S LiHV** | 2S 550mAh 75C/150C High-Voltage LiPo Battery Pack (XT30 Connector) | GNB 550mAh 2S 7.6V LiHV Pack | 1 | 29.5 g | 29.5 g | $9.50 | Gaoneng (GNB) |
| **Battery: 3S LiHV (Opt)**| 3S 450mAh 80C High-Voltage LiPo Battery Pack (XT30 Connector) | GNB 450mAh 3S 11.4V LiHV Pack | 1 | 42.0 g | 42.0 g | $12.00 | Gaoneng (GNB) |
| **TOTALS (2S Baseline)** | **Complete Flight-Ready 2S Security Interceptor System** | - | - | 72.4 g dry | **101.9 g AUW** | **$270.00** | Production Run |
| **TOTALS (3S Tactical)** | **Complete Flight-Ready 3S Security Interceptor System** | - | - | 72.4 g dry | **114.4 g AUW** | **$272.50** | Production Run |

*BOM Arithmetic Reconciliation*:
- **Dry Mass**: $18.0 + 3.5 + 7.5 + 16.0 + 3.2 + 2.5 + 8.5 + 1.0 + 2.0 + 2.2 + 4.5 + 3.5 = \mathbf{72.4\text{ g}}$.
- **2S All-Up-Weight (AUW)**: $72.4\text{ g (dry)} + 29.5\text{ g (2S 550mAh)} = \mathbf{101.9\text{ g AUW}}$ (exact itemized sum: $18.0 + 3.5 + 7.5 + 16.0 + 3.2 + 2.5 + 8.5 + 1.0 + 2.0 + 2.2 + 4.5 + 3.5 + 29.5 = 101.9\text{ g}$).
- **3S All-Up-Weight (AUW)**: $72.4\text{ g (dry)} + 42.0\text{ g (3S 450mAh)} = \mathbf{114.4\text{ g AUW}}$ ($101.9 - 29.5 + 42.0 = 114.4\text{ g}$).
- **Production Unit Cost**: Itemized baseline totals $\$270.00$ for 2S ($\$12 + \$4 + \$65 + \$48 + \$3.50 + \$24 + \$45 + \$14 + \$18 + \$16 + \$15 + \$5 + \$9.50$) and $\$272.50$ for 3S ($+\$2.50$ battery delta).

---

### 1.2 Airframe Physical Specifications (`OSITO_Interceptor_95mm_Frame.stl`)
Quantitative CAD parsing of the repository master geometry yields the following fixed physical properties:
- **Facet Count & Topology**: 7,504 triangular facets, OpenSCAD manifold solid.
- **Bounding Box**: $X \in [-62.079, +62.079]\text{ mm}$ ($124.16\text{ mm}$ span), $Y \in [-62.079, +62.079]\text{ mm}$ ($124.16\text{ mm}$ span), $Z \in [0.000, +9.700]\text{ mm}$ ($9.70\text{ mm}$ overall height).
- **Solid Volume**: $15,463.29\text{ mm}^3$ ($15.463\text{ cm}^3$).
- **True Diagonal Wheelbase**: 
  $$\text{Wheelbase} = \sqrt{(2 \times 33.517\text{ mm})^2 + (2 \times 33.512\text{ mm})^2} = \mathbf{94.794\text{ mm}} \approx \mathbf{95.0\text{ mm}}$$
- **Duct Geometry**:
  - Inner Diameter (ID): **$54.18\text{ mm}$** ($27.09\text{ mm}$ radius).
  - Outer Diameter (OD): **$57.28\text{ mm}$** ($28.64\text{ mm}$ radius).
  - Wall Thickness: **$1.55\text{ mm}$**.
  - Duct Shroud Height: **$9.70\text{ mm}$**.
- **Propeller Clearance**: Gemfan 2020 props ($50.8\text{ mm}$ diameter) yield an optimal **$1.69\text{ mm}$ radial tip clearance**, maximizing ducted acoustic shielding and low-speed aerodynamic thrust augmentation.
- **Flight Controller Mount**: Classic $25.5 \times 25.5\text{ mm}$ AIO Whoop pattern rotated $45^\circ$ (diamond orientation) at coordinates $(0.0, \pm 18.031)\text{ mm}$ and $(\pm 18.031, 0.0)\text{ mm}$. Standoff height is $5.50\text{ mm}$, hole diameter is $2.05\text{ mm}$ (clearance for M2 screws).
- **Motor Mounting Pattern**: 3-hole equilateral pattern on a **$6.6\text{ mm}$ Pitch Circle Diameter (PCD)** with hole inner diameter $1.85\text{–}1.90\text{ mm}$ (M1.6 / M2 clearance) and central bearing/circlip shaft bore of **$6.08\text{ mm}$**.

---

### 1.3 Propulsion Profiles & Thrust-to-Weight Dynamics

```
+---------------------------------------------------------------------------------------------------+
| CONFIGURATION     | BATTERY  | MOTORS          | ALL-UP-WEIGHT | MAX THRUST | TWR     | FLIGHT TIME |
+---------------------------------------------------------------------------------------------------+
| 2S Indoor Safe    | 2S 550mAh| 1103 8500KV     | 101.9 g       | 350 g      | 3.4 : 1 | ~5.2–6.5 min|
| 3S Tactical Sprint| 3S 450mAh| 1202.5 6000KV   | 114.4 g       | 560 g      | 4.9 : 1 | ~4.0–4.8 min|
+---------------------------------------------------------------------------------------------------+
```

1. **2S Indoor Non-Contact Interceptor (Primary)**:
   - Operating at 7.6V nominal, the 1103 8500KV motors produce $\sim 87.5\text{ g}$ thrust per corner ($350\text{ g}$ aggregate).
   - At $101.9\text{ g}$ AUW, the Thrust-to-Weight Ratio (TWR) is **$3.4:1$** ($350\text{ g} / 101.9\text{ g}$), ensuring nimble maneuverability for tight indoor gym cutoff maneuvers (`RUN_SPEED_THRESH_MS = 1.2`, lead acceleration $2.5\text{ m/s}^2$) while maintaining acoustic noise below $62\text{ dBA}$ at $2.0\text{ m}$.
2. **3S Outdoor Tactical Perimeter Patrol**:
   - Operating at 11.4V nominal, the 1202.5 6000KV motors generate $\sim 140\text{ g}$ thrust per corner ($560\text{ g}$ aggregate).
   - At $114.4\text{ g}$ AUW, the TWR reaches **$4.9:1$** ($560\text{ g} / 114.4\text{ g}$), delivering exceptional wind penetration up to $22\text{ knots}$ ($11.3\text{ m/s}$) during outdoor Walk-to-Fly perimeter tracking.

---

## 2. Hardware Assembly & Physical Fabrication

### 2.1 Exploded Assembly Architecture

```
                                  [CANOPY MODULE]
                       +-----------------------------------+
                       | Custom TPU / Polycarbonate Canopy |
                       | - Houses RunCam Nano 4 (14mm)     |
                       | - Houses ESP32-S3 Sense AI Cam    |
                       +-----------------------------------+
                                         │
                                         ▼ 4x M2x12mm Screws
                       +-----------------------------------+
                       | Avionics Stack (AIO FC + ESC)     |
                       | - STM32F405/H743, 20A-30A BLHeli  |
                       | - MicroSD Card with /APM/scripts/ |
                       | - ExpressLRS Nano RX & Micro VTX  |
                       +-----------------------------------+
                                         │
                                         ▼ 4x Silicone M2 Damping Grommets
                       +-----------------------------------+
                       | OSITO 95mm Ducted Unibody Frame   |
                       | - 4x 54.18mm Aerodynamic Ducts    |
                       | - 4x 5.5mm M2 Standoffs (Z=5.5mm) |
                       | - Center Deck w/ 10mm Strap Slots |
                       +-----------------------------------+
                         │                               │
       4x 3-Hole M1.6    │                               │  Underside Mounting
       Screws (Loctite)  ▼                               ▼
      +--------------------------+              +-------------------------+
      | 4x 1103 / 1202.5 Motors  |              | Matek 3901-L1X/L0X      |
      | 4x Gemfan 2020 Props     |              | (PMW3901 Flow + ToF)    |
      | (Props-Out Rotation)     |              | GNB 2S/3S LiHV Pack     |
      +--------------------------+              +-------------------------+
```

---

### 2.2 Frame Preparation & Finishing
1. **Duct Inspection & Cleaning**:
   - Inspect the four $54.18\text{ mm}$ inner diameter duct shrouds on `OSITO_Interceptor_95mm_Frame.stl`.
   - If printed via FDM/SLS, wet-sand the inner duct walls with 400-grit to 800-grit sandpaper until perfectly cylindrical and free of stringing or layer ridges. This preserves boundary layer laminarity and guarantees the $1.69\text{ mm}$ propeller tip clearance.
2. **FC Standoff Post Tapping**:
   - The frame features four unibody standoff posts rising $5.50\text{ mm}$ above the center deck at $(0.0, \pm 18.031)\text{ mm}$ and $(\pm 18.031, 0.0)\text{ mm}$.
   - Clean the $2.05\text{ mm}$ inner diameter holes. Tap with an M2 tap or press-fit M2 brass threaded heat-set inserts ($3.0\text{ mm}$ outer diameter, $3.0\text{ mm}$ depth) using a soldering iron tip set to $220^\circ\text{C}$.
3. **Battery Strap Slot Check**:
   - Clear debris from the six center-deck strap routing slots located at $X = \pm 1.0, \pm 7.1, \pm 19.0\text{ mm}$ and $Y = \pm 1.0, \pm 7.1, \pm 19.0\text{ mm}$. Confirm that a standard $10\text{ mm} \times 150\text{ mm}$ silicone-coated micro battery strap slides freely through the slots.

---

### 2.3 Motor Installation & Wire Routing
1. **Motor Orientation**:
   - Position the four brushless motors (1103 8500KV or 1202.5 6000KV) into the lower motor hubs ($Z = 0.00\text{ to } 2.50\text{ mm}$).
   - Align the 3-hole triangular mounting holes with the $6.6\text{ mm}$ PCD frame holes.
2. **Fastener Torquing & Threadlock**:
   - Secure each motor using three M1.6 $\times$ $4.0\text{ mm}$ (or M2 $\times$ $4.0\text{ mm}$ depending on motor base) socket-head screws.
   - **MANDATORY**: Apply blue medium-strength threadlocker (Loctite 243) to each screw. Torque to $0.18\text{ N}\cdot\text{m}$.
   - Verify that screw threads do not penetrate the motor stator windings.
3. **Strut Wire Routing**:
   - Route the three 28AWG silicone motor phase leads along the underside of the aerodynamic radial struts.
   - Secure the leads flush against the struts using small dabs of neutral-cure silicone adhesive (or Kapton tape) to prevent wire vibration and aerodynamic drag. Guide all leads onto the top surface of the lower center deck.

---

### 2.4 Flight Controller Stack Installation
1. **Silicone Vibration Isolation**:
   - Insert four M2 silicone anti-vibration damping grommets into the mounting ears of the $25.5 \times 25.5\text{ mm}$ AIO board.
2. **Stack Seating**:
   - Place the AIO board onto the $5.50\text{ mm}$ frame standoffs in the required $45^\circ$ diamond orientation (Forward corner pointing between Front-Left and Front-Right motors).
   - Ensure the MicroSD card slot faces an accessible duct opening or frame perimeter for field script maintenance.
   - Ensure at least $2.0\text{ mm}$ air gap between the bottom surface of the AIO board and the frame center deck to avoid short circuits.

---

### 2.5 Avionics Wiring Harness & Pinout Matrix

```
+---------------------------------------------------------------------------------------------------------+
| PIN / PAD        | CONNECTED TO                      | SIGNAL / PROTOCOL  | NOTES & CONFIGURATION       |
+---------------------------------------------------------------------------------------------------------+
| VBAT / GND       | XT30 Pigtail Lead                 | 7.6V–11.4V DC      | 18AWG Silicone + 100uF Cap  |
| ESC M1–M4        | Motor 1–4 Phase Pads              | DShot300 / DShot600| Solder directly to pads     |
| UART1 TX / RX    | ExpressLRS Nano RX                | CRSF Protocol      | SERIAL1_PROTOCOL = 23       |
| UART2 TX / RX    | ESP32-S3 Sense AI Cam             | MAVLink Telemetry  | SERIAL2_PROTOCOL = 2        |
| UART3 TX / RX    | Matek 3901-L1X/L0X (Flow + LiDAR) | MSP Protocol (UART)| SERIAL3_PROTOCOL = 32       |
| I2C SCL / SDA    | Reserved / External Aux           | I2C Bus Protocol   | Available for ext compass   |
| UART4 TX / RX    | u-blox RTK GNSS Receiver          | u-blox UBX (Serial)| SERIAL4_PROTOCOL = 5        |
| 5V / GND         | Matek 3901-L1X/L0X & Cam/VTX      | Regulated 5.0V     | Ensure < 1.5A total draw    |
| Video IN / OUT   | RunCam Nano 4 / VTX               | Analog CVBS (NTSC) | OSD character overlay       |
| VTX SmartAudio   | SoftSerial / UART TX              | IRC Tramp/SmartAud | VTX channel & power ctrl    |
+---------------------------------------------------------------------------------------------------------+
```

1. **Power Supply & Filtering**:
   - Solder an XT30 male pigtail (18AWG silicone wire, $45\text{ mm}$ length) to the AIO battery pads.
   - Solder a low-ESR electrolytic capacitor ($220\mu\text{F}$ / $16\text{V}$ for 2S, $330\mu\text{F}$ / $25\text{V}$ for 3S) in parallel across the battery terminals to absorb inductive switching spikes from the 20A ESC MOSFETs.
2. **Optical Flow & LiDAR (Matek 3901-L1X / 3901-L0X)**:
   - The Matek 3901-L0X / 3901-L1X is an all-UART MSP multi-sensor module featuring only four physical solder pads (`5V`, `GND`, `TX`, `RX`). Both PMW3901 optical flow and ToF LiDAR range data are packetized by the onboard microcontroller and transmitted simultaneously over a unified MSP packet stream. There are NO external I2C pads.
   - Solder four 30AWG silicone leads from the Matek sensor board:
     - Sensor `TX` to FC `UART3 RX`
     - Sensor `RX` to FC `UART3 TX`
     - Sensor `5V` to clean FC regulated 5V rail (~100mA draw)
     - Sensor `GND` to FC system ground
   - *Sensor Selection*: The **Matek 3901-L1X** (integrating the ST VL53L1X LiDAR with up to $4.0\text{ m}$ range) is strongly recommended for operational deployment to provide ample ranging headroom at the standard $1.8\text{ m}$ indoor interdiction altitude (`INTERCEPT_ALT_M = 1.8`). The 3901-L0X (VL53L0X) has a physical indoor ceiling of $\sim 1.2\text{ m}$ and is restricted to low-altitude testing.
   - Set FC parameters: `SERIAL3_PROTOCOL = 32` (MSP), `FLOW_TYPE = 7` (MSP Optical Flow), and `RNGFND1_TYPE = 32` (MSP Rangefinder).
3. **Target Tracker (ESP32-S3 Sense AI Cam)**:
   - Connect `TX/RX` of ESP32-S3 to FC `UART2 RX/TX` set to MAVLink2 (`SERIAL2_PROTOCOL = 2`, `SERIAL2_BAUD = 115200`). This streams target coordinate offsets directly into the vehicle telemetry engine.
4. **Radio & Video**:
   - Connect ExpressLRS Nano to `UART1` (`SERIAL1_PROTOCOL = 23` CRSF).
   - Route RunCam Nano 4 camera video signal to FC `CAM` pad and FC `VTX` pad to the micro video transmitter.
5. **Outdoor RTK GNSS (u-blox ZED-F9P / NEO-M9N)**:
   - Connect GNSS `TX` to FC `UART4 RX` and GNSS `RX` to FC `UART4 TX`.
   - Supply $5.0\text{ V}$ and ground from the FC accessory power rail.
   - Configure ArduPilot parameters: `SERIAL4_PROTOCOL = 5` (GPS), `SERIAL4_BAUD = 230` ($230.4\text{ kbps}$ / $230400\text{ bps}$), and `GPS_TYPE = 2` (u-blox). This delivers centimeter-grade RTK positioning for outdoor Walk-to-Fly mission generation matching PRD.md lines 154 and 334.

---

### 2.6 Motor Rotation Direction & Props-Out Configuration
The Osito 95mm Interceptor uses the **"Props-Out / Reverse Rotation"** configuration. In ducted micro-drones, standard "Props-In" rotation directs aerodynamic blade wash and kicked-up debris directly inward against the front FPV camera lens and downward optical flow sensors, degrading visual odometry. Props-Out directs airflow wash laterally outward away from the fuselage centerline.

```
                  FRONT (Nose)
             [RunCam Nano 4 / ESP32]
                       ▲
                       │
       Motor 2 (FL)    │    Motor 1 (FR)
          [CW]         │       [CCW]
          ( ↻ )        │       ( ↺ )
                       │
      ─────────────────┼─────────────────► EAST
                       │
          ( ↺ )        │       ( ↻ )
          [CCW]        │        [CW]
       Motor 3 (RL)    │    Motor 4 (RR)
                       │
                  REAR (Tail)
               [XT30 Battery Lead]
```

- **Motor 1 (Front-Right)**: Counter-Clockwise (CCW) — Blade sweeps outwards.
- **Motor 2 (Front-Left)**: Clockwise (CW) — Blade sweeps outwards.
- **Motor 3 (Rear-Left)**: Counter-Clockwise (CCW) — Blade sweeps outwards.
- **Motor 4 (Rear-Right)**: Clockwise (CW) — Blade sweeps outwards.

*Configuration Setting*: In BLHeliSuite / ESC Configurator, reverse channels 1 and 4, or swap any two motor phase wires on those corners. In ArduCopter, verify `MOT_SPIN_DIR = 1` (Reverse / Props-Out).

---

### 2.7 Sensor & Companion Compute Payload Installation
1. **Downward Sensor Board (Matek 3901-L1X — `VL53L1X` 4m ToF)**:
   - Mount the **Matek 3901-L1X** board to the underside of the frame center plate, perfectly centered along the pitch and roll axes.
   - Ensure the PMW3901 optical flow lens and **VL53L1X** (`4.0m` ToF) LiDAR aperture have an unobstructed conical field of view ($42^\circ$ for optical flow, $27^\circ$ for LiDAR) through the center deck cutout.
   - Use double-sided 3M VHB foam tape ($1.0\text{ mm}$ thickness) for acoustic and high-frequency vibration isolation.
2. **Top Canopy & FPV Camera**:
   - Install the RunCam Nano 4 (14mm) into the front camera cradle of the TPU canopy. Adjust vertical tilt to exactly **$20^\circ$ upward**, which provides optimal line of sight during horizontal intercept sprints ($2.5\text{ m/s}$).
   - Install the ESP32-S3 Sense AI Cam module directly above the FPV camera within the canopy cradle, maintaining zero roll tilt and horizontal alignment with the vehicle fuselage.
3. **Canopy Fastening**:
   - Seat the canopy over the flight controller stack. Secure it using four M2 $\times$ $12.0\text{ mm}$ black alloy steel button-head screws passing through the canopy tabs, silicone grommets, and threading into the $5.5\text{ mm}$ frame standoffs.

---

### 2.8 Propeller Installation & Tip Clearance Verification
1. **Propeller Selection**: Gemfan 2020 4-Blade ducted propellers ($50.8\text{ mm}$ blade diameter, $1.5\text{ mm}$ shaft press-fit).
2. **Mounting**: Press each propeller firmly onto the motor shaft until seated against the motor bell shoulder. Support the motor bottom bell with your thumb to prevent dislodging the bottom bearing circlip.
3. **Radial Tip Clearance Inspection**:
   - Using a feeler gauge, measure the radial gap between the propeller tips and the $54.18\text{ mm}$ inner duct walls across $360^\circ$ rotation for all four ducts.
   - **Mandatory Metric**: Clearance must measure **$1.69\text{ mm} \pm 0.25\text{ mm}$**. If any blade tip contacts the duct wall ($< 0.5\text{ mm}$), inspect the motor shaft for runout or gently trim the blade tip using a fine diamond file.

---

### 2.9 Battery Mounting & Center of Gravity (CoG) Balancing
1. **Battery Cradle**: Thread the $10\text{ mm} \times 150\text{ mm}$ silicone-coated micro strap through the frame bottom slots. Apply a $15\text{ mm} \times 25\text{ mm}$ non-slip silicone pad to the center battery tray.
2. **Pack Orientation**: Mount the GNB 550mAh 2S LiHV pack along the longitudinal axis ($X = 0$), with the XT30 discharge leads exiting toward the rear.
3. **CoG Alignment**: Balance the assembled aircraft on a dual-point fulcrum placed at the intersection of the motor diagonals ($(X, Y) = (0.0, 0.0)$). Slide the battery pack forward or aft until the drone balances within $\pm 1.5\text{ mm}$ of the geometric center. Tighten the battery strap firmly.

---

## 3. Flight Controller Firmware & Parameter Architecture

### 3.1 Firmware Selection & Flashing
1. **Firmware Target**: **ArduPilot Copter 4.2+ (or 4.3 / 4.4)** compiled for `MatekF405-AIO`, `FlywooF405`, or `MatekH743`.
2. **Flashing Procedure**:
   - Connect the FC to a workstation via USB-C (use a $90^\circ$ adapter if obstructed by duct walls).
   - Open Mission Planner or QGroundControl.
   - Navigate to `Setup -> Install Firmware -> All Options`. Select `Copter 4.2.x Stable` or upload custom compiled binary with AP_Scripting enabled.
   - Perform complete accelerometer calibration (6-point), compass calibration, and radio calibration.

---

### 3.2 Master ArduPilot Parameter Configuration Table
The following parameter table must be loaded into the flight controller. Every value is directly linked to the operational physics, safety constraints, and Lua script interfaces of the Osito system.

| Parameter | Recommended Value | Subsystem Category | Engineering Rationale |
| :--- | :---: | :--- | :--- |
| `FRAME_CLASS` | `1` | Airframe Geometry | Sets vehicle class to Quadrotor. |
| `FRAME_TYPE` | `12` | Airframe Geometry | Sets motor mapping to Betaflight X (FL=2 CW, FR=1 CCW, RL=3 CCW, RR=4 CW) matching Props-Out layout. |
| `SCR_ENABLE` | `1` | Lua Scripting Engine | Activates ArduPilot onboard Lua scripting engine. Requires reboot. |
| `SCR_HEAP_SIZE` | `65536` | Lua Scripting Engine | Allocates 64 KB RAM heap. Mandatory for dual-script execution (`walk_to_fly` + `corner_intercept`). |
| `SCR_VM_I_RST` | `10000` | Lua Scripting Engine | Instruction limit per VM execution slice. Prevents script starvation or watchdog trip. |
| `WP_YAW_BEHAVIOR`| `0` | Intercept Steering | **CRITICAL**: Sets waypoint yaw behavior to "None". Prevents ArduPilot from fighting script yaw commands (`vehicle:set_target_angle_and_climbrate`). |
| `WPNAV_SPEED` | `250` | Navigation Dynamics | Sets max horizontal Guided speed to $2.5\text{ m/s}$ ($9\text{ km/h}$) for controlled indoor interdiction. |
| `WPNAV_ACCEL` | `250` | Navigation Dynamics | Sets horizontal acceleration to $2.5\text{ m/s}^2$ for responsive lateral flanking and cutoff sprints. |
| `WPNAV_RADIUS` | `50` | Navigation Dynamics | Sets waypoint acceptance radius to $50\text{ cm}$ for tight corner positioning. |
| `RC8_OPTION` | `300` | Walk-to-Fly Aux Input | Sets RC Channel 8 to Scripting1 (300). Grants caching control to `walk_to_fly.lua` (`rc:get_aux_cached(300)`). |
| `MIS_RESTART` | `0` | Mission Buffer | Resumes Walk-to-Fly recorded mission after mode interruption rather than restarting at WP #1. |
| `THROW_TYPE` | `0` | Tactical Hand-Launch | Selects standard forward/upward toss mode (Mode 17). |
| `THROW_MOT_START`| `0` | Tactical Hand-Launch | **CRITICAL SAFETY**: Motors remain 100% OFF (0 RPM) while held in operator hand. |
| `THROW_ALT_MIN` | `0.0` | Tactical Hand-Launch | Disables altitude gate (0.0m) to permit reliable throw release from ground/chest level (< 2.5m AGL). |
| `THROW_ALT_ACSND`| `2.5` | Tactical Hand-Launch | Commands post-toss vertical climb to $2.5\text{ m}$ safety altitude before transitioning to next mode. |
| `THROW_NEXTMODE` | `3` | Tactical Hand-Launch | Automatically transitions into `AUTO` mode (Mode 3) to execute recorded Walk-to-Fly perimeter path. |
| `AHRS_EKF_TYPE` | `3` | Navigation State Estimator | Selects 24-state Extended Kalman Filter 3 (EKF3). |
| `EK3_ENABLE` | `1` | Navigation State Estimator | Enables EKF3 state estimator. |
| `EK3_SRC1_POSXY` | `0` (Indoor) / `3` (RTK) | EKF3 Sensor Fusion | 0 = None (Indoor Optical Flow) / 3 = GPS (Outdoor Walk-to-Fly). |
| `EK3_SRC1_VELXY` | `5` | EKF3 Sensor Fusion | 5 = OpticalFlow velocity vectors (note: 3 is GPS velocity). Enables drift-free non-GPS velocity fusion. |
| `EK3_SRC1_POSZ` | `2` | EKF3 Sensor Fusion | **CRITICAL**: 2 = Rangefinder priority. Locks altitude to downward ToF LiDAR. |
| `SERIAL3_PROTOCOL`| `32` | Sensor Telemetry | 32 = MSP protocol on UART3 for Matek 3901-L1X/L0X multi-sensor (Flow + LiDAR). |
| `RNGFND1_TYPE` | `32` | Rangefinder Driver | 32 = MSP Rangefinder driver via UART3 (Matek 3901-L1X/L0X). |
| `RNGFND1_MIN_CM`| `10` | Rangefinder Driver | $10\text{ cm}$ minimum operational range. |
| `RNGFND1_MAX_CM`| `400` | Rangefinder Driver | $400\text{ cm}$ ($4.0\text{ m}$) maximum indoor operational range (with Matek 3901-L1X). |
| `RNGFND1_GNDCLEAR`| `3` | Rangefinder Driver | $3\text{ cm}$ sensor ground clearance when resting on landing pads. |
| `FLOW_TYPE` | `7` | Optical Flow Driver | 7 = MSP Optical Flow protocol via UART3. |
| `MOT_SPIN_DIR` | `1` | Motor Direction | Sets rotation to Props-Out / Reverse (FL CW, FR CCW, RL CCW, RR CW). |
| `MOT_SPIN_ARM` | `0.06` | Motor Safety | Low idle throttle ($6\%$) upon arming. |
| `MOT_SPIN_MIN` | `0.10` | Motor Safety | $10\%$ minimum active flight throttle to prevent motor stall. |
| `ARMING_CHECK` | `1` | Safety Interlock | Enforces all sensor, compass, barometer, and EKF origin checks prior to arming. |
| `FENCE_ENABLE` | `1` | Geofence Boundary | Enforces hard software boundaries around facility or gym arena. |
| `BATT_FS_LOW_ACT`| `2` (Outdoor) / `1` (Indoor) | Safety Fail-safe | 2 = Return-to-Launch (RTL) outdoors; 1 = Land immediately for indoor non-GPS flights. |
| `BATT_FS_CRT_ACT`| `1` | Safety Fail-safe | Immediate vertical Land upon reaching critical battery threshold ($6.8\text{V}$ on 2S). |
| `FS_THR_ENABLE` | `1` (Outdoor) / `2` (Indoor) | Safety Fail-safe | 1 = RTL for outdoor RTK flights; 2 = Land / ALTHOLD for indoor non-GPS flights. |
| `FS_GCS_ENABLE` | `1` (Outdoor) / `2` (Indoor) | Safety Fail-safe | 1 = RTL for outdoor RTK flights; 2 = Land / ALTHOLD for indoor non-GPS flights. |

---

### 3.3 Subsystem Parameter Details & Tuning

#### 3.3.1 AP_Scripting Engine (`SCR_*`)
- Set `SCR_ENABLE = 1` and reboot the flight controller.
- Set `SCR_HEAP_SIZE = 65536` (64KB). The ArduPilot default heap size ($44\text{ KB}$) is insufficient when running both `walk_to_fly.lua` and `osito_corner_intercept.lua` simultaneously. 64KB leaves $\ge 20\text{ KB}$ free headroom, preventing garbage collector stalls.
- Set `SCR_VM_I_RST = 10000` instructions per slice to ensure deterministic 10Hz execution loops without tripping the internal timing watchdog.

#### 3.3.2 Guided Intercept & Nose-to-Target Decoupled Yaw (`WP_YAW_BEHAVIOR = 0`)
- In default ArduPilot configuration (`WP_YAW_BEHAVIOR = 1`), the vehicle automatically aligns its nose with the velocity vector toward the next waypoint.
- In `osito_corner_intercept.lua`, line 246 commands independent target-tracking yaw:  
  `vehicle:set_target_angle_and_climbrate(0, 0, yaw_deg, 0, false, 0)`  
  where `yaw_deg = math.deg(math.atan(sim_target_e - drone_e, sim_target_n - drone_n))`.
- Setting `WP_YAW_BEHAVIOR = 0` (None) disables the native yaw-to-waypoint controller, allowing the drone to translate omnidirectionally while keeping the FPV camera and companion AI vision locked onto the intruder.

#### 3.3.3 Walk-to-Fly Mission Generation (`RC8_OPTION = 300`)
- `RC8_OPTION` must be set to `300` (`Scripting1`). This assigns RC Channel 8 directly to the ArduPilot auxiliary scripting binding without triggering native flight mode conflicts.
- In `walk_to_fly.lua`, `rc:get_aux_cached(300)` queries the exact switch state (`0` = Low, `1` = Mid, `2` = High).
- Setting `MIS_RESTART = 0` ensures that if an operator pauses a perimeter patrol or switches modes, returning to `AUTO` resumes patrol from the last active waypoint rather than rewinding to WP #1.

#### 3.3.4 Tactical Hand-Launch (`THROW_*`)
- Mode 17 (`THROW`) is integrated into the tactical deployment sequence.
- **Safety Interlock**: `THROW_MOT_START = 0` guarantees that while an armed drone is held in the guard's hand, motor RPM is exactly zero.
- **Altitude Gate Setting**: `THROW_ALT_MIN = 0.0` disables the altitude gate. In ArduPilot, setting `THROW_ALT_MIN > 0` requires the drone to already be above that height *before* throw detection can trigger (intended for drops from mother aircraft). Setting it to `0.0` ensures the toss detection triggers reliably from ground level (< 2.5m AGL).
- **Ascent Altitude**: `THROW_ALT_ACSND = 2.5` commands the vehicle to climb vertically to $2.5\text{ m}$ AGL after throw detection and attitude leveling.
- **Throw Detection Dynamics**: Throw acceleration detection is hardcoded in ArduPilot firmware (`mode_throw.cpp`) requiring aggregate acceleration $> 500\text{ cm/s}^2$ ($5.0\text{ m/s}^2$) followed by freefall/climb inflection. The ESCs spin up within $250\text{ ms}$, stabilize attitude, climb to $2.5\text{ m}$ (`THROW_ALT_ACSND = 2.5`), and automatically transition into `AUTO` mode (`THROW_NEXTMODE = 3`) to begin the recorded Walk-to-Fly perimeter patrol.

#### 3.3.5 Indoor Non-GPS Navigation EKF3 & MSP Sensor Driver
- In GPS-denied environments (gymnasiums, industrial warehouses), set `AHRS_EKF_TYPE = 3` and `EK3_ENABLE = 1`.
- Set `SERIAL3_PROTOCOL = 32` (MSP) on FC UART3.
- Set `RNGFND1_TYPE = 32` (MSP Rangefinder) to ingest LiDAR distance telemetry from the Matek 3901 board over UART (do NOT use 20, which is Benewake serial).
- Set `FLOW_TYPE = 7` (MSP Optical Flow) to ingest PMW3901 optical flow telemetry over UART3.
- Set `EK3_SRC1_POSZ = 2` (Rangefinder) to slave vertical altitude estimation to the downward ToF LiDAR.
- Set `EK3_SRC1_VELXY = 5` (Optical Flow) to fuse horizontal velocity vectors from the downward PMW3901 sensor, enabling rock-solid drift-free hover and translation without GNSS satellites. Note: `EK3_SRC1_VELXY = 3` selects GPS horizontal velocity and must NOT be used for optical flow.
- *Failsafe Tuning*: For indoor GPS-denied missions, configure `BATT_FS_LOW_ACT = 1` (Land) and `FS_THR_ENABLE = 2` (Land/AltHold) because RTL requires valid GPS home coordinates and will fail indoors.

---

## 4. Lua Autonomy Script Deployment

### 4.1 MicroSD Card Preparation & Directory Hierarchy
1. Format a high-endurance MicroSD card (e.g., SanDisk High Endurance 32GB) using **FAT32** with a **32KB allocation cluster size**.
2. Create the standard ArduPilot script directory structure in the root of the card:
   ```text
   / (SD Card Root)
   └── APM/
       └── scripts/
           ├── walk_to_fly.lua
           └── osito_corner_intercept.lua
   ```
3. Copy `walk_to_fly.lua` and `osito_corner_intercept.lua` from the project repository directly into `/APM/scripts/`.

---

### 4.2 Script 1: Walk-to-Fly Perimeter Mission Generator (`walk_to_fly.lua`)
- **Operational Principle**: Allows a security officer to physically walk the perimeter while holding the disarmed drone. At each corner or checkpoint, flipping RC Channel 8 (configured with `RC8_OPTION = 300` for `Scripting1`) to High captures the high-precision RTK coordinate (`loc:lat()`, `loc:lng()`) and automatically injects an authoritative 20-meter relative altitude safety offset (`ALT_OFFSET = 20`).
- **Telemetry Feedback**:
  - Script boot: `OSITO: Walk-to-Fly Script Loaded (Scripting1 / Aux 300)`.
  - Capture attempt: `OSITO: Attempting to record waypoint...`.
  - RTK validation: Verifies `gps:status(0) == 6` (`GPS_OK_FIX_3D_RTK_FIXED`). If $< 6$, warns `OSITO: WARNING - No RTK Lock (Status: X)`.
  - Mission write: In ArduPilot (`AP_Mission.cpp`), command index 0 is permanently reserved for `HOME`. The script indexes navigation waypoints starting at `math.max(1, mission:num_commands())`, ensuring `HOME` is never overwritten. Each waypoint is populated with `wp:command(16)` (`MAV_CMD_NAV_WAYPOINT`), `wp:seq(current_wp_count)`, `wp:autocontinue(1)`, and frame `MAV_FRAME_GLOBAL_RELATIVE_ALT` (Frame 3):  
    `OSITO: Saved Waypoint #N at 20m` (e.g. `Waypoint #1` for the first recorded coordinate).

---

### 4.3 Script 2: Autonomous Non-Contact Intercept (`osito_corner_intercept.lua`)
- **Operational Principle**: Autonomous zero-contact interdiction algorithm running at 10 Hz. Operates exclusively when the aircraft is placed into `GUIDED` mode (Mode 4).
- **Core Autonomy Parameters (Verbatim lines 19–29)**:
  - `STANDOFF_HOVER_M = 1.5`: Target standoff hover distance in front of intruder ($5.0\text{ ft}$).
  - `REPULSIVE_BUBBLE_M = 1.1`: Hard keep-out shield ($3.6\text{ ft}$). Drone actively retreats if intruder steps forward.
  - `FLANK_CLEARANCE_M = 1.8`: Lateral arc clearance ($6.0\text{ ft}$) when moving from behind to front of target.
  - `INTERCEPT_ALT_M = 1.8`: Fixed indoor intercept altitude ($6.0\text{ ft}$ AGL).
  - `RUN_SPEED_THRESH_MS = 1.2`: Intruder jog/run velocity trigger for active cutoff sprints.
  - `LEAD_TIME_SEC = 0.9`: Predictive kinematic look-ahead horizon.
  - `HERD_BIAS_GAIN = 1.1`: Lateral offset toward open court, channeling intruder toward corner.
  - Arena bounds: Clamped to $24\text{m} \times 16\text{m}$ court (`GYM_HALF_NORTH_M = 12.0`, `GYM_HALF_EAST_M = 8.0`).
- **State Machine Transitions**:
  - `STATE_IDLE (0)`: Disengaged; waiting for `GUIDED` mode.
  - `STATE_SHADOW_HOVER (1)`: Target speed $< 1.2\text{ m/s}$; holds $1.5\text{m}$ standoff blocking path to open court.
  - `STATE_CUTOFF_SPRINT (2)`: Target speed $\ge 1.2\text{ m/s}$; sprints along predictive vector to cut off intruder trajectory.
  - `STATE_REPULSE_BACKOFF (3)`: Target separation $< 1.1\text{ m}$; executes hard repulsive retreat to restore $1.5\text{m}$ standoff.
  - `STATE_CORNERED_HOLD (4)`: Target contained within corner quadrant ($|N| \ge 9.8\text{m}$, $|E| \ge 5.8\text{m}$) with speed $< 0.6\text{ m/s}$; holds position and sounds alarm.

---

### 4.4 Bench & Simulation Edition (`walk_to_fly_Desktop_Edition.lua`)
- For bench commissioning, testing without live RTK hardware, or SITL desktop testing, deploy `walk_to_fly_Desktop_Edition.lua`.
- **Mechanism**: Toggling flight mode to `GUIDED` triggers waypoint generation with simulated San Francisco coordinates (`fake_lat = 377749000`, `fake_lng = -1224194000`), advancing North by $11.1\text{m}$ per toggle, and automatically resetting mode to `LOITER` for consecutive test clicks.

---

### 4.5 Dual-Script Concurrent Execution & Memory Heap Budget
When both scripts are placed in `/APM/scripts/`, ArduPilot initializes two concurrent Lua execution contexts:
- `walk_to_fly.lua`: Consumes $\sim 8.2\text{ KB}$ heap (runs at 10 Hz when triggered).
- `osito_corner_intercept.lua`: Consumes $\sim 28.5\text{ KB}$ heap (runs at 10 Hz in Guided, 5 Hz when idle).
- **Total Combined Allocation**: $\sim 36.7\text{ KB}$.
- With `SCR_HEAP_SIZE = 65536` ($64\text{ KB}$), remaining free heap headroom is **$\sim 27.3\text{ KB}$ ($\ge 42\%$)**. This exceeds the required safety threshold of $20\text{ KB}$, guaranteeing zero garbage collection stalls during high-velocity maneuvers.

---

### 4.6 Telemetry Verification via GCS STATUSTEXT Console
Upon booting the flight controller with USB or battery power, open the GCS `Messages` console. Verify the following sequential initialization banner appears within 5 seconds:

```text
[MAVLink STATUSTEXT] OSITO: Walk-to-Fly Script Loaded (Scripting1 / Aux 300)
[MAVLink STATUSTEXT] OSITO: Gym Cat & Mouse Interceptor Loaded (5ft Safe Standoff)
```

---

## 5. Pre-Flight Commissioning & Verification Checklist

### 5.1 7-Point Commissioning Checklist Table
The following 7-point physical commissioning procedure must be executed and signed off prior to operational deployment. Each checkpoint contains explicit test actions, parameter prerequisites, quantitative pass criteria, and invalidation/fail conditions.

```
+------------------------------------------------------------------------------------------------------------------------------------------------+
| ID    | TEST NAME              | TEST ACTION & COMMAND                 | EXPECTED PASS CRITERIA                | INVALIDATION / FAIL CONDITION |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-01 | Script Boot & Init     | Power FC; inspect GCS MAVLink console | Both scripts log load text at boot    | Missing script, syntax error, |
|       |                        |                                       | ("Loaded (Scripting1 / Aux 300)",     | or memory allocation fault.   |
|       |                        |                                       |  "5ft Safe Standoff")                 |                               |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-02 | Lua Heap Headroom Check| Query `MEM_USED` in GCS Telemetry     | Total heap <= 42 KB; free memory      | Free heap < 20 KB or rapid    |
|       |                        | status window                         | headroom >= 20 KB (out of 64 KB)      | leak during 10 Hz execution.  |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-03 | Motor Spin & Props-Out | Spin motors via Mission Planner Motor | FL: CW, FR: CCW, RL: CCW, RR: CW      | Inward rotation (Props-In),   |
|       | Direction Verification | Test at 5% throttle (no props)        | (Outward blade sweep away from cam)   | incorrect corner sequence.    |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-04 | Optical Flow & LiDAR   | Place on floor; raise vertically to   | `sonaralt` reads 180 +/- 5 cm (L1X);  | LiDAR flatlines or reads 0;   |
|       | Accuracy Verification  | 1.8m reference mark                   | optical flow quality metric > 80      | optical flow quality < 50.    |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-05 | Walk-to-Fly Disarmed   | Disarm; verify RTK (status 6); toggle | GCS displays: "Saved Waypoint #1 at   | No waypoint recorded; status  |
|       | Waypoint Recording     | RC Ch8 switch (Option 300) to Pos 2   | 20m"; Mission count increments;       | < 6 warning; buffer full;     |
|       |                        |                                       | Index 0 (HOME) preserved intact.      | Home overwritten.             |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-06 | Repulsive Shield &     | In bench GUIDED mode, move test board | Drone setpoint retreats radially; GCS | Setpoint advances or freezes; |
|       | Flank Arc Response     | within 1.1m; test lateral transit path| displays "Backing up to 5ft safe";    | flank path passes through     |
|       |                        | (< 1.8m)                              | flank arc offsets waypoint >= 1.8m    | keep-out zone (< 1.8m).       |
+------------------------------------------------------------------------------------------------------------------------------------------------+
| PC-07 | In-Hand Motor Safety & | Arm vehicle in THROW mode (Mode 17)   | Motors remain completely stationary   | CRITICAL: Motors spin while   |
|       | Hand-Launch Transition | while firmly held in hand; toss upward| (0 RPM) in hand; upon toss, motors    | held in hand; drone fails to  |
|       |                        | into safety net                       | spin up, level, climb to 2.5m (THROW_ | detect toss; height gate      |
|       |                        |                                       | ALT_ACSND=2.5), switch to AUTO mode.  | blocks launch.                |
+------------------------------------------------------------------------------------------------------------------------------------------------+
```

---

### 5.2 Step-by-Step Commissioning Procedures

#### PC-01: Script Boot & GCS Initialization
1. Ensure `walk_to_fly.lua` and `osito_corner_intercept.lua` are installed in `/APM/scripts/`.
2. Connect flight controller to workstation running Mission Planner. Apply battery power.
3. Open the `Messages` tab.
4. **Pass Criteria**: Confirm verbatim log entries:
   - `OSITO: Walk-to-Fly Script Loaded (Scripting1 / Aux 300)`
   - `OSITO: Gym Cat & Mouse Interceptor Loaded (5ft Safe Standoff)`
5. **Fail Action**: If `Scripting: out of memory` appears, verify `SCR_HEAP_SIZE = 65536`. If scripts do not load, verify MicroSD FAT32 formatting and file paths.

#### PC-02: Lua Heap Allocation & Headroom Check
1. In Mission Planner, open `Status` tab.
2. Monitor `MEM_USED` (Lua heap allocation).
3. **Pass Criteria**: `MEM_USED` must stabilize between $35,000\text{ bytes}$ and $42,000\text{ bytes}$, leaving at least $22,000\text{ bytes}$ ($\ge 22\text{ KB}$) of free heap headroom.
4. **Fail Action**: If memory increases monotonically without plateauing, a memory leak is present. Halt testing.

#### PC-03: Motor Direction & Props-Out Verification
1. **REMOVE ALL PROPELLERS**.
2. Connect battery. In Mission Planner, navigate to `Setup -> Optional Hardware -> Motor Test`.
3. Test each motor individually at $5\%$ throttle for $2\text{ seconds}$:
   - Motor A (Front-Right / Motor 1): Must rotate **Counter-Clockwise (CCW)**.
   - Motor B (Rear-Right / Motor 4): Must rotate **Clockwise (CW)**.
   - Motor C (Rear-Left / Motor 3): Must rotate **Counter-Clockwise (CCW)**.
   - Motor D (Front-Left / Motor 2): Must rotate **Clockwise (CW)**.
4. **Pass Criteria**: All 4 motors rotate outward (Props-Out configuration).
5. **Fail Action**: Reverse motor direction in BLHeliSuite or swap phase wires on any incorrect corner.

#### PC-04: Optical Flow & LiDAR Rangefinder Accuracy
1. Place drone flat on the floor under standard indoor lighting ($> 150\text{ lux}$).
2. In GCS `Quick` tab, observe `sonaralt` and `opt_m_x` / `opt_m_y` telemetry values.
3. Vertically raise the aircraft to an exact height of $1.80\text{ m}$ ($180\text{ cm}$) against a calibrated measurement tape.
4. **Pass Criteria**:
   - `sonaralt` reads $180\text{ cm} \pm 5\text{ cm}$ ($1.75\text{m}$ to $1.85\text{m}$) when using the Matek 3901-L1X (with VL53L1X up to 4.0m range). If using the 3901-L0X (VL53L0X), verify accuracy at $100\text{ cm} \pm 5\text{ cm}$ within its 1.2m range ceiling.
   - `opt_qua` (Optical Flow Quality) reads $> 80$ (scale 0–255).
5. **Fail Action**: If `sonaralt` reads 0 or flatlines, inspect UART3 wiring and verify `SERIAL3_PROTOCOL = 32`, `RNGFND1_TYPE = 32`, and `FLOW_TYPE = 7`. Clean optical flow lens if quality $< 50$.

#### PC-05: Walk-to-Fly RC Ch8 Disarmed Waypoint Capture
1. Carry the disarmed drone outdoors with clear view of the sky.
2. Connect GCS telemetry and RTK base station / NTRIP caster.
3. Verify GCS HUD indicates `RTK Fixed` (`gps:status(0) == 6`).
4. Toggle RC Channel 8 (`RC8_OPTION = 300`) to Pos 2 (High).
5. **Pass Criteria**:
   - GCS displays: `OSITO: Saved Waypoint #1 at 20m`.
   - In Mission Planner, click `Read WPs`. Verify Waypoint 1 appears at current Lat/Lng with Command 16 (`NAV_WAYPOINT`), Frame 3 (`GLOBAL_RELATIVE_ALT`), Autocontinue enabled (`1`), and Altitude $20.0\text{ m}$.
   - Verify Index 0 (`HOME`) remains intact and is not overwritten.
6. **Fail Action**: If `OSITO: WARNING - No RTK Lock` appears, verify RTCM3 telemetry link. If switch fails to trigger, verify transmitter channel 8 endpoints ($> 1800\mu\text{s}$) and `RC8_OPTION = 300`.

#### PC-06: Repulsive Shield & Flanking Arc Bypass Response
1. Bench test in SITL or tethered environment. Switch flight mode to `GUIDED` (Mode 4).
2. Set simulated or detected target coordinate at $(X, Y) = (+3.0\text{m}, 0.0\text{m})$. Drone translates to $1.5\text{m}$ standoff ($X = +1.5\text{m}$).
3. Move target coordinate inward to $(+0.8\text{m}, 0.0\text{m})$ (penetrating the $1.1\text{m}$ repulsive bubble).
4. **Pass Criteria**:
   - Drone setpoint translates immediately backwards along radial vector to $X = -0.7\text{m}$ (maintaining $1.5\text{m}$ standoff from target).
   - GCS console issues warning: `OSITO: Kid stepped close! Backing up to 5ft safe hover!`.
   - When commanding a waypoint behind the target, vehicle flight path bypasses target with lateral clearance $\ge 1.8\text{m}$.
5. **Fail Action**: If vehicle setpoint fails to retreat, check `ahrs:get_relative_position_NED_home()` validity and verify `REPULSIVE_BUBBLE_M = 1.1`.

#### PC-07: In-Hand Motor Safety Interlock & Toss-to-Fly Transition
1. Perform in an outdoor open field or enclosed safety net cage.
2. Set flight mode to `THROW` (Mode 17).
3. Arm the aircraft using the RC transmitter arm switch while holding the aircraft firmly from below by the lower battery tray.
4. **CRITICAL PASS CRITERIA (Phase 1 - In-Hand Safety)**:
   - **Motors must remain 100% STOPPED (0 RPM)** while held in the operator's hand.
   - If motors spin even at idle throttle, **DISARM IMMEDIATELY** and verify `THROW_MOT_START = 0`.
5. **Throw Phase (Phase 2 - Flight Transition)**:
   - Firmly toss the drone upward and slightly forward at an angle of $\sim 30^\circ$ to $45^\circ$.
   - IMU detects throw acceleration ($> 5.0\text{ m/s}^2$). With `THROW_ALT_MIN = 0.0`, the altitude gate is disabled so motors engage immediately.
   - Motors spin up, attitude stabilizes horizontally within $300\text{ ms}$, vehicle climbs to $2.5\text{ m}$ (`THROW_ALT_ACSND = 2.5`), and GCS announces automatic mode switch to `AUTO` (`THROW_NEXTMODE = 3`).
   - Vehicle transitions into cruising the Walk-to-Fly perimeter path.

---

### 5.3 Production Sign-Off & Flight Readiness Certification Matrix (Unexecuted Template)

*Notice: This checklist is an unexecuted production quality assurance template. It must be physically performed, empirically verified, and physically signed by authorized test technicians during hardware commissioning. All checkpoints are initialized to PENDING until empirical verification is complete.*

```
+-----------------------------------------------------------------------------------------------------------------------------------------------+
| CHECKPOINT                                | STATUS      | VERIFIED BY (PRINT & SIGN) | DATE (UTC)   | ACCEPTANCE THRESHOLD                    |
+-----------------------------------------------------------------------------------------------------------------------------------------------+
| PC-01: Script Boot & Console Init         | [ PENDING ] | [ ______________________ ] | [ ________ ] | Both scripts log load banner at boot    |
| PC-02: Lua Heap Allocation (>= 20KB Free) | [ PENDING ] | [ ______________________ ] | [ ________ ] | MEM_USED <= 42KB, Free >= 20KB of 64KB  |
| PC-03: Motor Direction & Props-Out Config | [ PENDING ] | [ ______________________ ] | [ ________ ] | FL:CW, FR:CCW, RL:CCW, RR:CW outwards   |
| PC-04: Optical Flow & LiDAR (1.8m AGL)    | [ PENDING ] | [ ______________________ ] | [ ________ ] | sonaralt: 180±5cm (L1X), opt_qua > 80   |
| PC-05: Walk-to-Fly Disarmed WP Capture    | [ PENDING ] | [ ______________________ ] | [ ________ ] | WP #1+ saved, Frame 3, Alt 20m, Home OK |
| PC-06: Repulsive Shield & Flank Arc Check | [ PENDING ] | [ ______________________ ] | [ ________ ] | Retreat at <1.1m, flank bypass >=1.8m   |
| PC-07: In-Hand Zero-RPM Safety Interlock  | [ PENDING ] | [ ______________________ ] | [ ________ ] | 0 RPM held; spinup post-throw to 2.5m   |
+-----------------------------------------------------------------------------------------------------------------------------------------------+
| AIRWORTHINESS CERTIFICATE ISSUANCE        | [ PENDING ] | [ ______________________ ] | [ ________ ] | All PC-01 through PC-07 verified passed |
+-----------------------------------------------------------------------------------------------------------------------------------------------+
```

---

## 6. Operational Quick Reference & Troubleshooting Guide

### 6.1 Field Deployment Workflow Summary
1. **Perimeter Mapping**: Security guard powers on drone, disarmed. Walks facility boundary. Toggles RC Channel 8 (`RC8_OPTION = 300`) at each gate, corner, or door. Drone records Waypoint #1, #2, etc. while preserving Home at Index 0.
2. **Launch & Patrol**: Guard sets mode switch to `THROW`, arms drone (motors 0 RPM in hand via `THROW_MOT_START = 0`), and tosses drone upward. Drone detects toss with `THROW_ALT_MIN = 0.0`, stabilizes, climbs to $2.5\text{m}$ (`THROW_ALT_ACSND = 2.5`), transitions to `AUTO` (`THROW_NEXTMODE = 3`), climbs to $20\text{m}$ relative altitude, and patrols the recorded perimeter.
3. **Breach Interdiction**: When an intruder is detected, guard or base station switches mode to `GUIDED`. Drone descends to $1.8\text{m}$ indoor/facility interdiction altitude, intercepts intruder path, holds $1.5\text{m}$ standoff, prevents forward progress, and herds intruder into corner holding area.
4. **Recovery / Failsafe**: Pilot can override autonomy instantly at any moment by moving mode switch to `LOITER` or `ALTHOLD`.

---

### 6.2 Common Faults, Diagnostic Messages & Remediation

```
+---------------------------------------------------------------------------------------------------------+
| SYMPTOM / GCS MESSAGE                   | ROOT CAUSE                           | REMEDIATION ACTION             |
+---------------------------------------------------------------------------------------------------------+
| "Scripting: out of memory"              | `SCR_HEAP_SIZE` too low for 2 scripts| Set `SCR_HEAP_SIZE = 65536`.   |
|                                         |                                      | Reboot flight controller.      |
+---------------------------------------------------------------------------------------------------------+
| "OSITO: WARNING - No RTK Lock"          | GPS status < 6 (3D Fix or Float)     | Verify RTCM3 stream from NTRIP |
|                                         |                                      | caster or relocate RTK base.   |
+---------------------------------------------------------------------------------------------------------+
| Vehicle auto-yaws away from target      | `WP_YAW_BEHAVIOR` set to 1 (Face WP) | Set `WP_YAW_BEHAVIOR = 0`.     |
| during Guided intercept sprints         |                                      | Allows script-driven yaw lock. |
+---------------------------------------------------------------------------------------------------------+
| Motors spin while drone is held in hand | `THROW_MOT_START` set to 1           | CRITICAL SAFETY: Set           |
| after arming in THROW mode              |                                      | `THROW_MOT_START = 0`!         |
+---------------------------------------------------------------------------------------------------------+
| Motors fail to start during hand toss   | `THROW_ALT_MIN > 0` altitude gate    | Set `THROW_ALT_MIN = 0.0`.     |
| in THROW mode                           | blocking toss detection              | Ensure firm throw > 5.0 m/s².  |
+---------------------------------------------------------------------------------------------------------+
| LiDAR reads 0cm or erratic values at    | MSP UART wiring or protocol mismatch;| Verify UART3 TX/RX wiring,     |
| 1.8m hover altitude                     | sensor ceiling exceeded (3901-L0X)   | `SERIAL3_PROTOCOL = 32`,       |
|                                         |                                      | `RNGFND1_TYPE = 32`. Use       |
|                                         |                                      | Matek 3901-L1X for 1.8m AGL.   |
+---------------------------------------------------------------------------------------------------------+
| Optical flow velocity not fused indoors | `EK3_SRC1_VELXY` set to 3 (GPS)      | Set `EK3_SRC1_VELXY = 5`       |
| (EKF3 drifts or fails pre-arm)          | instead of 5 (OpticalFlow)           | (OpticalFlow).                 |
+---------------------------------------------------------------------------------------------------------+
| RC Channel 8 fails to record waypoints  | `RC8_OPTION` not set to 300 or       | Set `RC8_OPTION = 300`         |
| in Walk-to-Fly mode                     | switch endpoints miscalibrated       | (Scripting1); calibrate RC8.   |
+---------------------------------------------------------------------------------------------------------+
| Drone setpoint clips corner duct during | Propeller tip clearance < 1.0mm      | Sand duct ID to 54.18mm;       |
| aggressive 2.5 m/s² lateral sprints     | or frame flexing under load          | use stiff PA12-CF frame.       |
+---------------------------------------------------------------------------------------------------------+
```

---
*Authored for Osito AI Security Drone Production Deployment. Compliant with Master Architecture Specifications.*
