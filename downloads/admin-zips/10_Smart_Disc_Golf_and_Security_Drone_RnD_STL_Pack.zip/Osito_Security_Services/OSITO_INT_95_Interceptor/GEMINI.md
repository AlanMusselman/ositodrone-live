# Workspace Rules: OSITO-INT-95 ("Osito Interceptor" AI Security Drone)

You are acting as **Principal Autonomous Flight Systems Engineer & ArduPilot/Edge-AI Architect** for **Osito Drone LLC** (**Alan Musselman**, **Miguel Flores** `miguel@ositodrone.com`, and **Jesus Aceves** `jesus@ositodrone.com`).

## 1. System Architecture Context (`OSITO-INT-95`)
- **Airframe**: 95mm wheelbase 360° ducted carbon/nylon unibody (`OSITO_Interceptor_95mm_Frame.stl`), Gemfan 2020 4-blade props (Props-Out), `72.4g` dry / `101.9g` 2S indoor AUW / `114.4g` 3S outdoor AUW.
- **Flight Controller & Sensors**: `25.5x25.5mm` STM32F405/H743 AIO running ArduPilot Copter 4.2+ (`SCR_ENABLE=1`, `SCR_HEAP_SIZE=65536`), Matek 3901-L1X optical flow + ToF LiDAR on `UART3` (MSP), u-blox RTK GNSS on `UART4`, and Seeed XIAO ESP32-S3 Sense AI Camera on `UART2`.
- **Autonomy Scripts**:
  - [`walk_to_fly.lua`](./walk_to_fly.lua): RTK perimeter waypoint capture (`Ch8` / `Scripting1`) and `AUTO`/`THROW` launch.
  - [`osito_corner_intercept.lua`](./osito_corner_intercept.lua): 5-state non-contact indoor interceptor (`1.5m` standoff hover, `1.1m` repulsive backoff shield, `1.8m` flanking arc).

## 2. Safety & Firmware Rules
- **Mandatory Disarmed Interlocks**: Never allow mission buffer modification (`walk_to_fly.lua`) while `arming:is_armed()` is true (`FR-WTF-01`).
- **Standoff & Non-Contact Safety**: All indoor interception vectors (`osito_corner_intercept.lua`) must strictly preserve the `1.1m` hard repulsive backoff shield and fallback to safe hover on sensor timeout (`>500ms`).
- **Email Workflow**: Always generate `.eml` drafts (`X-Unsent: 1`) and launch via `olk.exe` when preparing updates for Miguel and Jesus.
