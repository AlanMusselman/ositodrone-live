# OSITO-INT-95 ("Osito Interceptor") — AI Security Drone

Autonomous 95mm 360°-ducted indoor/outdoor security and perimeter patrol micro-UAV built on ArduPilot Copter 4.2+ Lua scripting and Edge-AI vision.

## Key Files
- [`PRD.md`](./PRD.md) — Product Requirements Document (`FR-WTF-01`, `FR-CAT-01`, hardware & sensor specs).
- [`BUILD.md`](./BUILD.md) — Complete bill of materials (`~$270`), UART pinout, and ArduPilot commissioning guide.
- [`walk_to_fly.lua`](./walk_to_fly.lua) — Walk-to-Fly RTK perimeter waypoint teaching and `THROW`/`AUTO` launch script.
- [`osito_corner_intercept.lua`](./osito_corner_intercept.lua) — 5-state indoor non-contact pursuit and corner-containment autonomy engine.
- [`OSITO_Interceptor_95mm_Frame.stl`](./OSITO_Interceptor_95mm_Frame.stl) — 3D-printable 95mm 360° ducted unibody airframe.
