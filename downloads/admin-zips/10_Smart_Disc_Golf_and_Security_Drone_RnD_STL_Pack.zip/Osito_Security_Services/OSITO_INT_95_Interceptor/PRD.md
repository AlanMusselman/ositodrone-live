# Product Requirements Document (PRD): Osito AI Security Drone

**Document Version**: 1.0.0 (Production Release)  
**System Designation**: OSITO-INT-95 ("Osito Interceptor")  
**Classification**: Production Engineering Specification  
**Status**: APPROVED FOR PRODUCTION DEPLOYMENT  
**Date**: 2026-10-29  

---

## Executive Summary

The **Osito AI Security Drone** is an autonomous, ducted 95mm micro-unmanned aerial vehicle (UAV) engineered for tactical indoor interdiction, perimeter security, and automated facility boundary patrol. Utilizing a custom 3D-printable or injection-molded carbon-infused polycarbonate unibody airframe (`OSITO_Interceptor_95mm_Frame.stl`), the system combines zero-contact physical safety with advanced autonomous flight behaviors.

The core operational philosophy centers on **autonomous, non-lethal, zero-contact human deterrence and containment**. Rather than employing kinetic force or active payloads, Osito uses predictive kinematic positioning, dynamic lane blocking, personal bubble enforcement, and perimeter herding to contain unauthorized personnel while preventing human injury or equipment damage.

---

## Table of Contents
1. [Product Overview & Operational Mission](#1-product-overview--operational-mission)
2. [Target Operational Use Cases & CONOPS](#2-target-operational-use-cases--conops)
3. [System Architecture](#3-system-architecture)
4. [Functional Requirements (FR)](#4-functional-requirements-fr)
   - 4.1 Autonomous Intercept Kinematics (FR-CI-01 to FR-CI-10)
   - 4.2 Walk-to-Fly Mission Generation & Launch (FR-WTF-01 to FR-WTF-05)
5. [Hardware & Software Interface Requirements](#5-hardware--software-interface-requirements)
6. [Safety, Fail-safes & Geofencing](#6-safety-fail-safes--geofencing)
7. [Production Specifications & Environmental Limits](#7-production-specifications--environmental-limits)

---

## 1. Product Overview & Operational Mission

### 1.1 Product Vision
The Osito AI Security Drone is designed to solve the critical "first-response gap" in secure facilities, sensitive educational complexes, commercial warehouses, and athletic arenas. Ground-based human security guards are constrained by reaction time, line of sight, and foot speed. Traditional fixed security cameras suffer from blind spots and cannot influence intruder behavior. 

Osito provides immediate airborne presence within seconds of an alarm. It can be deployed either via an automated ground station or hand-launched by a security officer without touching a ground control station (GCS). It autonomously maps perimeters, intercepts intruders, blocks pathways, and channels subjects toward corners or exits using purely non-contact maneuvers.

```
+-----------------------------------------------------------------------------------+
|                        OSITO OPERATIONAL DOCTRINE: THE 4 D's                      |
+-----------------------------------------------------------------------------------+
|  1. DETECT    | Rapid perimeter breach identification via RTK patrol or AI vision.|
|  2. DETER     | Immediate proximity presence at 1.8m AGL eye-level with nose lock.|
|  3. DEFLECT   | Predictive lane blocking; 1.1m inward bias angles subject to wall. |
|  4. DELAY     | 1.5m standoff corner containment until human guard arrives.       |
+-----------------------------------------------------------------------------------+
```

### 1.2 Core Operational Principles
1. **Zero-Contact Human Safety Doctrine**:
   - The drone is physically constrained from contacting human beings under all nominal and off-nominal conditions.
   - Dual-layer protection: A physical 360-degree ducted shroud ($54.18\text{ mm}$ inner diameter) encloses all high-speed propeller tips, while a software-enforced repulsive personal bubble ($1.1\text{ m}$ radius) compels the drone to retreat if approached by an intruder.
2. **Predictive Non-Lethal Interdiction ("Cat & Mouse")**:
   - Instead of trailing behind an intruder, the drone calculates a predictive sprint trajectory ($0.9\text{ s}$ velocity lead horizon) to intercept and establish a blocking position in front of the subject.
3. **Tactical Asymmetric Herding**:
   - The intercept trajectory injects an inboard mathematical bias ($1.1\text{ m}$ offset toward open space), placing the aircraft between the intruder and open pathways. This exploits natural psychological avoidance to funnel the intruder toward a wall or corner.
4. **Rapid Guard Field Deployment ("Walk-to-Fly")**:
   - Security personnel can create centimeter-accurate, obstacle-clearing perimeter patrols on foot while disarmed, capturing checkpoints via an RC toggle switch. Deployment occurs immediately via an in-hand toss launch (`THROW` mode) without requiring laptops or waypoint planning software.

---

## 2. Target Operational Use Cases & CONOPS

### 2.1 Use Case 1: Rapid Perimeter Boundary Mapping ("Walk-to-Fly")
- **Context**: A facility security officer must establish or update a patrol route around an outdoor compound, construction site, or temporary secured perimeter.
- **Workflow**:
  1. The officer carries the disarmed drone along the desired patrol boundary.
  2. At each perimeter node, corner, or gate checkpoint, the officer toggles RC Channel 8 to the high position (> 1800 µs), bound to `Scripting1` (`RC8_OPTION = 300`) and polled via `rc:get_aux_cached(300)` with a disarmed safety check (`arming:is_armed() == false`).
  3. The onboard script `walk_to_fly.lua` validates centimeter-accurate RTK GNSS fix quality (`gps:status(0) == 6`) and injects a 3D waypoint into ArduPilot's non-volatile mission buffer with an automated $+20.0\text{ m}$ relative safety altitude offset (`MAV_FRAME_GLOBAL_RELATIVE_ALT`).
  4. The generated closed-loop polygon constitutes the operational patrol perimeter.

```
[DISARMED OPERATOR]
       │
       ├─► Walks to Corner 1 ──► Toggle Ch8 High ──► Lua records WP #0 (Alt = 20m AGL)
       ├─► Walks to Corner 2 ──► Toggle Ch8 High ──► Lua records WP #1 (Alt = 20m AGL)
       ├─► Walks to Gate A   ──► Toggle Ch8 High ──► Lua records WP #2 (Alt = 20m AGL)
       └─► Returns to Post   ──► Toggle Ch8 High ──► Lua records WP #3 (Alt = 20m AGL)
```

### 2.2 Use Case 2: Dual-Launch Deployment (Ground AUTO & In-Hand Toss)
- **Deployment Option A (Ground AUTO Takeoff)**:
  - The drone is placed on a designated launch pad.
  - The operator selects `AUTO` mode (Mode 3) and issues an arm command. The drone automatically performs a vertical climb to $20.0\text{ m}$ AGL and initiates the Walk-to-Fly perimeter patrol route at $5.0\text{ m/s}$.
- **Deployment Option B (Tactical Hand-Launch via THROW Mode)**:
  - The operator selects ArduCopter native `THROW` mode (Mode 17) and arms the vehicle.
  - **In-Hand Safety Interlock**: Because `THROW_MOT_START = 0`, the motors remain completely powered off (0 RPM) while held firmly in the operator's hand.
  - **Release Altitude Gate Disabled**: Parameter `THROW_ALT_MIN = 0.0` disables the minimum release height gate, enabling hand toss from ground or waist level without pre-throw altitude rejection.
  - The operator tosses the drone forward and upward into the air.
  - The onboard IMU detects free-fall and throw acceleration exceeding $5.0\text{ m/s}^2$ (this toss acceleration detection threshold is hardcoded in ArduPilot firmware `mode_throw.cpp`).
  - Motor ESCs spin up within $250\text{ ms}$, level the vehicle attitude, and command a climb to target ascend altitude `THROW_ALT_ACSND` ($2.5\text{ m}$).
  - Upon reaching $2.5\text{ m}$ AGL, ArduPilot automatically executes `THROW_NEXTMODE = 3` (`AUTO`), seamlessly transitioning into the pre-recorded perimeter patrol.

```
[TACTICAL THROW DEPLOYMENT SEQUENCE]
1. Select Mode 17 (THROW) & Arm ────────► Motors STOPPED (0 RPM, zero hand hazard; THROW_MOT_START=0)
2. Operator Tosses Drone Upward ───────► Accel detects > 5.0 m/s² release (hardcoded in firmware)
3. Rapid Attitude Stabilization ───────► BLHeli ESCs spool up in < 250ms, roll/pitch level
4. Climb to THROW_ALT_ACSND (2.5m) ────► Vertical LiDAR/Baro verifies clearance (THROW_ALT_MIN=0.0)
5. Auto-Transition to AUTO (Mode 3) ───► Executes Walk-to-Fly perimeter at 20m AGL (THROW_NEXTMODE=3)
```

### 2.3 Use Case 3: Autonomous Tactical Herding & Lane Blocking ("Cat & Mouse")
- **Context**: A perimeter breach is detected by GCS or onboard vision; the flight controller transitions to `GUIDED` mode (Mode 4), activating `osito_corner_intercept.lua`.
- **Operational Arena**: Indoor gymnasium or enclosed facility ($24.0\text{ m} \times 16.0\text{ m}$, bounds $|N| \le 12.0\text{ m}$, $|E| \le 8.0\text{ m}$).
- **Behavior**:
  - The drone descends/climbs to eye-level interdiction altitude ($1.8\text{ m}$ AGL) locked via downward ToF LiDAR.
  - The script executes a 10 Hz guidance loop computing a predictive intercept waypoint ahead of the intruder ($0.9\text{ s}$ velocity lead).
  - An inboard mathematical bias offset ($1.1\text{ m}$) places the drone between the intruder and the center of the court, deflecting the subject toward the perimeter.
  - If the target stops, the drone holds an active standoff hover at $1.5\text{ m}$ distance, keeping its nose and camera continuously locked onto the target ($\le 5^\circ$ error).

### 2.4 Use Case 4: Zero-Contact Personal Bubble Defense
- **Context**: An aggressive or startled intruder lunges or walks directly toward the hovering drone to strike or push past it.
- **Response**:
  - The script computes real-time Euclidean separation $d = \|\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}\|$.
  - If $d < 1.5\text{ m}$, the drone maintains standoff hover position; if separation breaches $d < 1.1\text{ m}$ (`REPULSIVE_BUBBLE_M`), the vehicle transitions to `STATE_REPULSE_BACKOFF`.
  - Upon entering `STATE_REPULSE_BACKOFF`, the flight controller commands an immediate high-acceleration radial translation directly away from the intruder:
    $$\vec{p}_{\text{safe}} = \vec{p}_{\text{target}} + \frac{\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}}{\|\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}\|} \times 1.5\text{ m}$$
  - The drone issues a Severity 4 MAVLink `STATUSTEXT` warning to the GCS: `"Kid stepped close! Backing up to 5ft safe hover!"` and maintains separation without allowing contact.

### 2.5 Use Case 5: Corner Pinning & Containment
- **Context**: The intruder is successfully herded into one of the four facility corners.
- **Detection**: Target position falls within $2.2\text{ m}$ of both court boundary axes ($|p_{N}| \ge 9.8\text{ m}$ and $|p_{E}| \ge 5.8\text{ m}$) with target speed $< 0.6\text{ m/s}$.
- **Response**:
  - The system transitions to `STATE_CORNERED_HOLD` (State 4).
  - The drone anchors at $1.5\text{ m}$ diagonal standoff distance, blocking the only open exit vector.
  - Telemetry alerts security: `"CORNER PINNED! Holding steady."` The drone maintains this position until the human guard arrives and initiates manual mode override.

---

## 3. System Architecture

The Osito Interceptor is structured into four tightly coupled subsystems: Propulsion & Airframe, Avionics & Processing, Sensor Suite & Localization, and Software & Guidance Architecture.

```
+-------------------------------------------------------------------------------------------------------+
|                                    OSITO SYSTEM ARCHITECTURE                                          |
+-------------------------------------------------------------------------------------------------------+
|  [AIRFRAME & PROPULSION]                                                                              |
|  - 95mm Ducted Unibody (OSITO_Interceptor_95mm_Frame.stl, 15.46 cm³ solid volume, PC/PA12-CF, 18.0g)  |
|  - 4x 1103 (8500KV, 2S LiHV) / 1202.5 (6000KV, 3S LiPo) Brushless Motors (3-Hole M1.6 Mount @ 6.6mm)  |
|  - 4x Gemfan 2020 4-Blade Props (Props-Out Config, 1.69mm Duct Clearance, 54.18mm ID)                |
|  - GNB 2S 550mAh 75C LiHV (101.9g AUW, 3.43:1 TWR) / 3S 450mAh LiPo (114.4g AUW, 4.89:1 TWR)         |
+-------------------------------------------------------------------------------------------------------+
|  [AVIONICS & AUTONOMY ENGINE]                                                                         |
|  - BetaFPV / Flywoo GOKU 25.5x25.5mm AIO FC (STM32F405 / STM32H743 MCU + 20A-30A BLHeli ESC)          |
|  - ArduPilot Copter 4.2+ with AP_Scripting Engine Enabled (SCR_HEAP_SIZE = 65536 bytes)               |
|  - Dual Script Concurrent Execution: `walk_to_fly.lua` (10Hz) & `osito_corner_intercept.lua` (10Hz)   |
|  - Companion Target Tracker: Seeed XIAO ESP32-S3 Sense AI Cam (MAVLink Target Pose via UART2)        |
+-------------------------------------------------------------------------------------------------------+
|  [NAVIGATION & SENSORS (DUAL EKF3)]                                                                   |
|  - Indoor Positioning: Matek 3901-L0X/L1X Optical Flow (PMW3901) + ToF LiDAR (MSP UART3)             |
|  - Outdoor RTK GNSS: u-blox ZED-F9P / NEO-M9N Micro RTK Rover (Centimeter Fix, UART4)                 |
|  - EKF3 Fusion: Automatic optical flow / RTK switching; Barometer MS5611 + 6-DOF IMU ICM42688P       |
+-------------------------------------------------------------------------------------------------------+
|  [COMMS & HUMAN-MACHINE INTERFACE]                                                                    |
|  - Radio Control: ExpressLRS (ELRS) 2.4GHz Nano TCXO Receiver (CRSF Protocol, UART1, RC Ch8 Aux)     |
|  - Video Link: 14mm RunCam Nano 4 (1200TVL, 0.001 Lux) + 5.8GHz 25-400mW Micro VTX                   |
|  - Ground Station Telemetry: MAVLink v2.0 bidirectional telemetry stream via ESP32-S3 / GCS           |
+-------------------------------------------------------------------------------------------------------+
```

### 3.1 Airframe & Structural Layout
1. **Unibody Duct Shroud**:
   - Model File: `OSITO_Interceptor_95mm_Frame.stl`.
   - Dimensions: $124.16\text{ mm} \times 124.16\text{ mm} \times 9.70\text{ mm}$.
   - Wheelbase: Exactly $94.79\text{ mm}$ diagonal motor-to-motor ($67.03\text{ mm}$ adjacent).
   - Duct Geometry: $54.18\text{ mm}$ inner diameter ($27.09\text{ mm}$ radius), $57.28\text{ mm}$ outer diameter ($1.55\text{ mm}$ wall thickness), $9.70\text{ mm}$ duct height.
   - Solid Volume: $15,463.29\text{ mm}^3$ ($15.46\text{ cm}^3$).
   - Mass: $18.56\text{ g}$ in injection-molded Polycarbonate (PC); $17.78\text{ g}$ in PA12-CF.
2. **Propeller Tip Clearance**:
   - Gemfan 2020 4-Blade ($50.8\text{ mm}$ diameter): $1.69\text{ mm}$ radial clearance.
   - Maximizes ducted thrust augmentation ($+8\%$ static hover efficiency) while preventing blade rub during high-acceleration turns.
3. **Avionics Stack Mounting**:
   - $25.5 \times 25.5\text{ mm}$ whoop-standard M2 standoffs rotated $45^\circ$ diamond orientation.
   - Standoff post height: $5.50\text{ mm}$ from base deck ($4.20\text{ mm}$ vertical clearance to top of duct rim).
4. **Motor Base Mount**:
   - 3-hole equilateral configuration at $120^\circ$ on a $6.0\text{–}6.6\text{ mm}$ PCD.
   - Center bearing/shaft bore: $6.08\text{ mm}$ diameter.

### 3.2 Avionics & Processing
1. **Flight Controller**:
   - Form Factor: $25.5 \times 25.5\text{ mm}$ AIO Whoop footprint.
   - Processor: STM32F405 (168 MHz, 1MB Flash, 192KB RAM) or STM32H743 (480 MHz, 2MB Flash, 1MB RAM).
   - Integrated ESC: 4-in-1 20A continuous (25A burst) BLHeli_S / BLHeli_32, DShot600 protocol.
   - Storage: Onboard MicroSD card slot formatted FAT32, hosting `/APM/scripts/` directory.
2. **Propulsion Configuration**:
   - Motor Direction: **"Props-Out / Reverse Rotation"** (Front-Left CW, Front-Right CCW, Rear-Left CCW, Rear-Right CW).
   - Prevents ducted wash from blowing particulate matter onto the forward optical sensors and FPV camera lens during low-altitude indoor maneuvers.

### 3.3 Sensor Suite & Hybrid Localization Architecture
The drone employs dual navigation pipelines to support both outdoor perimeter patrols and indoor GPS-denied tactical interdictions:

| Operating Arena | Primary Horizontal Nav | Primary Vertical Nav | Heading Reference | EKF3 Configuration |
| :--- | :--- | :--- | :--- | :--- |
| **Outdoor Perimeter** (`walk_to_fly.lua`) | Centimeter RTK GNSS (u-blox ZED-F9P) | Barometric Altimeter (MS5611) + RTK Altitude | 3-Axis Magnetometer (QMC5883L) | `EK3_SRC1_POSXY=3` (GPS)<br>`EK3_SRC1_VELXY=3` (GPS)<br>`EK3_SRC1_POSZ=1` (Baro) |
| **Indoor Interdict** (`osito_corner_intercept.lua`) | Optical Flow (PMW3901, Matek 3901-L0X/L1X MSP UART) | Downward ToF LiDAR (VL53L0X/L1X via MSP Rangefinder) | Gyroscope EKF Integration | `EK3_SRC1_POSXY=0` (None)<br>`EK3_SRC1_VELXY=5` (OpticalFlow)<br>`EK3_SRC1_POSZ=2` (Rangefinder) |

---

## 4. Functional Requirements (FR)

### 4.1 Autonomous Intercept Kinematics (`osito_corner_intercept.lua`)

```
+-----------------------------------------------------------------------------------+
|                        CORNER INTERCEPT STATE MACHINE                             |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|            [Mode != GUIDED]                                                       |
|        ┌────────────────────────┐                                                 |
|        ▼                        │                                                 |
|  +------------+  Mode==GUIDED   +-------------------+                             |
|  | STATE_IDLE | ──────────────► | STATE_SHADOW_HOVER| ◄──────────┐                |
|  +------------+                 +-------------------+            │                |
|                                    │             │               │                |
|        Target Speed >= 1.2 m/s     │             │ Dist < 1.1m   │ Dist >= 1.5m   |
|        ┌───────────────────────────┘             │ (or < 1.5m)   │                |
|        ▼                                         ▼               │                |
|  +--------------------+                   +--------------------+ │                |
|  | STATE_CUTOFF_SPRINT|                   |STATE_REPULSE_BACKOF├─┘                |
|  +--------------------+                   +--------------------+                  |
|        │                                                                          |
|        │ In corner (|N|>=9.8, |E|>=5.8) & Speed < 0.6 m/s                         |
|        ▼                                                                          |
|  +--------------------+                                                           |
|  | STATE_CORNERED_HOLD| ──► Holds 1.5m block until manual pilot takeover          |
|  +--------------------+                                                           |
+-----------------------------------------------------------------------------------+
```

#### FR-CI-01: Guidance Mode Interlock & Engagement
- **Requirement**: The intercept algorithm shall strictly execute only when the vehicle flight mode is confirmed as `GUIDED` (Mode 4 via `vehicle:get_mode() == 4`).
- **Disengagement**: If the flight mode transitions away from `GUIDED` (e.g. pilot switches to `LOITER`, `ALTHOLD`, or `STABILIZE`), the script shall immediately revert `current_state` to `STATE_IDLE` (State 0) within $\le 200\text{ ms}$ and relinquish all setpoint overrides.

#### FR-CI-02: Deterministic Guidance Loop Rate
- **Requirement**: The autonomous guidance loop shall evaluate target kinematics, compute intercept geometry, apply safety filters, and issue vehicle setpoints at a deterministic update frequency of **$10\text{ Hz}$** ($100\text{ ms} \pm 5\text{ ms}$ interval).
- **Idle / Uninitialized Polling**: When disengaged or waiting for EKF origin, polling frequency shall be throttled to $5\text{ Hz}$ ($200\text{ ms}$) and $2\text{ Hz}$ ($500\text{ ms}$) respectively to minimize CPU load.

#### FR-CI-03: Predictive Intercept Look-Ahead Kinematics
- **Requirement**: When target speed exceeds $0.25\text{ m/s}$, the trajectory planner shall calculate an intercept lead point projected along the target's instantaneous velocity vector:
  $$\vec{p}_{\text{lead}} = \vec{p}_{\text{target}} + \vec{v}_{\text{target}} \cdot t_{\text{lead}}$$
  where $t_{\text{lead}} = 0.9\text{ seconds}$ (`LEAD_TIME_SEC`).
- **Cut-Off Sprint Trigger**: If target speed exceeds $1.2\text{ m/s}$ (`RUN_SPEED_THRESH_MS`), the state shall transition to `STATE_CUTOFF_SPRINT` (State 2), directing maximum allowable acceleration ($2.5\text{ m/s}^2$) toward the intercept point.

#### FR-CI-04: Inboard Herding Bias & Lane Blocking
- **Requirement**: The intercept setpoint shall incorporate an asymmetric lateral offset directed toward open space (inboard toward facility center $(0,0)$) to deflect the target toward the perimeter:
  1. Target unit velocity: $\hat{u} = \left(\frac{v_N}{\|\vec{v}\|}, \frac{v_E}{\|\vec{v}\|}\right)$
  2. Normal vector ($+90^\circ$ counter-clockwise): $\vec{p}_{\text{perp}} = (-u_E, u_N)$
  3. Center dot product: $d_{\text{center}} = (p_{\text{target}, N} \cdot p_{\text{perp}, N}) + (p_{\text{target}, E} \cdot p_{\text{perp}, E})$
  4. Bias sign: $s_{\text{herd}} = -1.0$ if $d_{\text{center}} > 0$ else $+1.0$
  5. Final block setpoint:
     $$\vec{p}_{\text{block}} = \vec{p}_{\text{lead}} + \hat{u} \cdot d_{\text{standoff}} + \vec{p}_{\text{perp}} \cdot s_{\text{herd}} \cdot g_{\text{bias}}$$
     where $d_{\text{standoff}} = 1.5\text{ m}$ (`STANDOFF_HOVER_M`) and $g_{\text{bias}} = 1.1\text{ m}$ (`HERD_BIAS_GAIN`).

#### FR-CI-05: Lateral Flanking Arc Bypass Filter
- **Requirement**: If the drone is positioned behind or to the side of the target and must transit to a forward blocking point, it shall not fly directly through or across the target's physical location.
- **Algorithm**:
  1. Define path vector $\vec{w} = \vec{p}_{\text{goal}} - \vec{p}_{\text{drone}}$ and relative target vector $\vec{r} = \vec{p}_{\text{target}} - \vec{p}_{\text{drone}}$.
  2. Orthogonal projection parameter:
     $$t = \text{clamp}\left(\frac{\vec{r} \cdot \vec{w}}{\|\vec{w}\|^2}, 0.0, 1.0\right)$$
  3. Closest approach distance: $d_{\text{clearance}} = \|\vec{p}_{\text{drone}} + t \cdot \vec{w} - \vec{p}_{\text{target}}\|$.
  4. If $d_{\text{clearance}} < 1.8\text{ m}$ (`FLANK_CLEARANCE_M`), the waypoint shall divert along a lateral circular arc of radius $1.8\text{ m}$ around the target, preserving safe separation throughout the bypass sprint.

#### FR-CI-06: Zero-Contact Standoff Hover
- **Requirement**: When target speed is $< 1.2\text{ m/s}$, the drone shall enter `STATE_SHADOW_HOVER` (State 1), maintaining a fixed separation of **$1.5\text{ m}$** ($5.0\text{ feet}$) in front of the target.
- **Stopped Target Behavior**: If target speed drops below $0.25\text{ m/s}$, the drone shall position itself on the radial line between the target and the court center origin $(0,0)$, preventing forward ingress.

#### FR-CI-07: Hard Repulsive Keep-Out Bubble
- **Requirement**: If the Euclidean distance $d_{\text{rel}} = \|\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}\|$ falls below **$1.1\text{ m}$** ($3.6\text{ feet}$, `REPULSIVE_BUBBLE_M`), the vehicle shall immediately enter `STATE_REPULSE_BACKOFF` (State 3).
- **Action**: The vehicle setpoint shall be commanded radially away from the target along $\vec{u}_{\text{push}} = \frac{\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}}{\|\vec{p}_{\text{drone}} - \vec{p}_{\text{target}}\|}$ to restore $1.5\text{ m}$ standoff hover.
- **Alert**: Issue MAVLink `STATUSTEXT` Severity 4 (Warning) to GCS: `"Kid stepped close! Backing up to 5ft safe hover!"`.

#### FR-CI-08: Gym Corner Containment & Pinning
- **Requirement**: When the target's position satisfies $|p_{\text{target}, N}| \ge (12.0 - 2.2)\text{ m} = 9.8\text{ m}$ and $|p_{\text{target}, E}| \ge (8.0 - 2.2)\text{ m} = 5.8\text{ m}$, and target speed is $< 0.6\text{ m/s}$, the system shall engage `STATE_CORNERED_HOLD` (State 4).
- **Behavior**: The drone shall hold an immovable $1.5\text{ m}$ blocking stance on the diagonal bisector facing the corner, effectively pinning the subject in the $2.2\text{ m} \times 2.2\text{ m}$ quadrant.
- **Alert**: Issue MAVLink `STATUSTEXT` Severity 6 (Info): `"CORNER PINNED! Holding steady."`.

#### FR-CI-09: Decoupled Nose-To-Target Dynamic Yaw Lock
- **Requirement**: The drone's yaw angle shall continuously align with the horizontal vector connecting the drone to the target, ensuring onboard optical sensors and camera remain locked on the subject:
  $$\psi_{\text{deg}} = \operatorname{atan2}(p_{\text{target}, E} - p_{\text{drone}, E},\; p_{\text{target}, N} - p_{\text{drone}, N}) \times \frac{180}{\pi} \pmod{360^\circ}$$
- **Decoupling Enforcement**: Flight controller parameter `WP_YAW_BEHAVIOR` must be set to `0` (None). The script shall directly command vehicle heading via `vehicle:set_target_angle_and_climbrate(0, 0, yaw_deg, 0, false, 0)`.

#### FR-CI-10: Fixed Altitude Interdiction Clamping
- **Requirement**: Throughout all intercept, flanking, and standoff maneuvers, the vertical setpoint shall remain locked to **$1.80\text{ m} \pm 0.05\text{ m}$ AGL** (`INTERCEPT_ALT_M = 1.8`), maintaining an eye-level psychological deterrent presence while preventing ceiling or floor collisions.

---

### 4.2 Walk-to-Fly Mission Generation & Launch (`walk_to_fly.lua`)

#### FR-WTF-01: Disarmed Perimeter Waypoint Capture
- **Requirement**: The system shall allow an operator carrying the disarmed drone to record geographic coordinates by toggling RC Channel 8 to position High ($> 1800\text{ µs}$).
- **Aux Switch Binding**: Flight controller parameter `RC8_OPTION` shall be set to `300` (`Scripting1`). The onboard script `walk_to_fly.lua` shall query switch state using ArduPilot's native auxiliary function caching interface `rc:get_aux_cached(300)` (where `2` indicates Switch High), ensuring proper mapping rather than querying an unassigned raw channel.
- **Disarmed Safety Interlock**: Waypoint recording shall strictly be permitted only when the drone is disarmed (`arming:is_armed() == false`), preventing accidental in-flight waypoint injection.
- **State Debouncing**: The script shall implement single-edge trigger state tracking (`sw_pos == 2 and last_sw_pos ~= 2`) to ensure exactly one waypoint is recorded per mechanical switch actuation.

#### FR-WTF-02: Safety Altitude Offset Injection
- **Requirement**: Every captured waypoint written to ArduPilot's mission buffer shall automatically inject a relative safety altitude offset of **$+20.0\text{ m}$ AGL** (`ALT_OFFSET = 20`).
- **MAVLink Structure**: Waypoints must be formatted as:
  - Command: `16` (`MAV_CMD_NAV_WAYPOINT`)
  - Coordinate Frame: `3` (`MAV_FRAME_GLOBAL_RELATIVE_ALT`)
  - Parameters: Latitude = `loc:lat()`, Longitude = `loc:lng()`, Altitude = `20.0`.

#### FR-WTF-03: RTK Fix Validation & Quality Telemetry
- **Requirement**: Prior to saving a waypoint, the script shall query the primary GNSS status (`gps:status(0)`).
- **Validation**:
  - If GPS lock is absent, an error message shall be transmitted via MAVLink Severity 4: `"OSITO: ERROR - No GPS Fix"`, and the waypoint rejected.
  - If GNSS fix status is less than `6` (`GPS_OK_FIX_3D_RTK_FIXED`), a warning shall be transmitted via MAVLink Severity 4: `"OSITO: WARNING - No RTK Lock (Status: <status>)"`.
  - When successfully recorded, transmit MAVLink Severity 6: `"OSITO: Saved Waypoint #<N> at 20m"`.

#### FR-WTF-04: Dual-Launch Deployment Capability
- **Requirement**: The system shall support both ground-initiated automatic missions (`AUTO` mode takeoff) and tactical in-hand toss launch (`THROW` mode 17).
- **Zero-RPM In-Hand Guarantee**: When armed in `THROW` mode, the flight controller parameter `THROW_MOT_START` must be set to `0`. Motor outputs shall strictly remain at 0% throttle (0 RPM) while the drone is held in the operator's hand.
- **Release Altitude Gate Disabled**: Flight controller parameter `THROW_ALT_MIN` shall be set to `0.0` (disabling the minimum release height requirement so hand toss from ground/waist level is immediately accepted).
- **Flight Transition**: Upon detecting a toss acceleration $\ge 5.0\text{ m/s}^2$ (this acceleration threshold is hardcoded in ArduPilot firmware `mode_throw.cpp`), the vehicle shall spool motors within $250\text{ ms}$, level attitude, climb to post-throw ascend target altitude $2.5\text{ m}$ (`THROW_ALT_ACSND = 2.5`), and automatically execute `THROW_NEXTMODE = 3` (`AUTO`), seamlessly flying the recorded Walk-to-Fly mission.

#### FR-WTF-05: In-Flight Patrol-to-Intercept Hand-Off
- **Requirement**: While executing a Walk-to-Fly patrol in `AUTO` mode at $20\text{ m}$ AGL, the system shall support immediate escalation to tactical intercept upon perimeter breach detection.
- **Transition Execution**: Switching flight mode to `GUIDED` (Mode 4) via GCS command or automated AI trigger shall immediately pause the perimeter patrol mission, activate `osito_corner_intercept.lua`, command a controlled descent to $1.8\text{ m}$ AGL, and initiate non-contact human herding.

---

## 5. Hardware & Software Interface Requirements

### 5.1 Electrical Pinout & Bus Allocation
The STM32F405/H743 25.5x25.5mm AIO Flight Controller allocates hardware serial and communication buses as specified in the master pinout table:

| Bus / Port | Protocol / Signal | Target Subsystem / Device | Operational Function |
| :--- | :--- | :--- | :--- |
| **UART1 (TX1/RX1)** | CRSF / Serial (420 kbps) | ExpressLRS 2.4GHz Nano TCXO | Pilot RC link, flight modes, Ch8 switch toggle (`RC8_OPTION = 300`) |
| **UART2 (TX2/RX2)** | MAVLink v2.0 (115.2 kbps) | ESP32-S3 Sense AI Cam | Target bounding box, relative NED position feed |
| **UART3 (TX3/RX3)** | MSP / Serial (115.2 kbps) | Matek 3901-L0X / L1X Sensor | Dual Optical Flow (`FLOW_TYPE = 7`) & ToF LiDAR (`RNGFND1_TYPE = 32`) via MSP (`SERIAL3_PROTOCOL = 32`) |
| **UART4 (TX4/RX4)** | u-blox UBX (230.4 kbps) | Micro RTK GNSS (F9P/M9N) | Centimeter RTK positioning for Walk-to-Fly |
| **I2C1 (SCL1/SDA1)**| I2C Standard (400 kHz) | QMC5883L Magnetometer / Aux | Compass magnetic heading reference and auxiliary telemetry |
| **SPI1** | SPI Bus | Onboard ICM-42688P IMU | High-rate (1 kHz) gyro and accelerometer sampling |
| **SPI2 / MicroSD** | FAT32 SPI Interface | 16GB MicroSD Card | Onboard storage for `/APM/scripts/` Lua engines |
| **Motor Pads M1–M4**| DShot600 (PWM) | 4-in-1 20A BLHeli ESC | Motor commutation (Props-Out reverse rotation) |
| **VTX / Video In/Out**| Analog NTSC/PAL | Caddx Ant / Nano FPV + VTX | 5.8GHz video downlink for pilot and GCS display |
| **BATT / CURRENT** | Analog ADC / Shunt | 2S/3S LiHV Main Pack (XT30) | Real-time voltage & current monitoring for fail-safes |

#### 5.1.1 Matek 3901-L0X / 3901-L1X MSP UART Configuration
The Matek 3901-L0X (VL53L0X) and 3901-L1X (VL53L1X) sensor boards combine both optical flow (PMW3901) and downward ToF LiDAR rangefinding onto a unified MSP serial pipeline. Rather than splitting signals across discrete I2C and UART buses, both data streams are multiplexed digitally over UART3:
- `SERIAL3_PROTOCOL = 32` (MSP)
- `FLOW_TYPE = 7` (MSP Optical Flow)
- `RNGFND1_TYPE = 32` (MSP Rangefinder)
- `EK3_SRC1_VELXY = 5` (OpticalFlow horizontal velocity reference)
- `EK3_SRC1_POSZ = 2` (Rangefinder vertical position reference)

### 5.2 ArduPilot Lua AP_Scripting Interface Bindings
Both `walk_to_fly.lua` and `osito_corner_intercept.lua` interface with the flight control stack via ArduPilot's native C++ scripting wrappers:

```
+-----------------------------------------------------------------------------------+
|                        ARDUPILOT AP_SCRIPTING BINDINGS                            |
+-----------------------------------------------------------------------------------+
| Module       | Method / Function                           | Used In              |
| :----------- | :------------------------------------------ | :------------------- |
| `vehicle`    | `:get_mode()`                               | Intercept & WTF      |
| `vehicle`    | `:set_target_location(Location)`            | Intercept            |
| `vehicle`    | `:set_target_angle_and_climbrate(...)`      | Intercept (Yaw Lock) |
| `ahrs`       | `:get_home()` & `:copy()`                   | Intercept            |
| `ahrs`       | `:get_relative_position_NED_home()`         | Intercept            |
| `ahrs`       | `:get_location()`                           | Walk-to-Fly          |
| `gps`        | `:status(0)`                                | Walk-to-Fly          |
| `mission`    | `:num_commands()` & `:set_item(idx, item)`  | Walk-to-Fly          |
| `rc`         | `:get_aux_cached(300)`                      | Walk-to-Fly (Ch8)    |
| `gcs`        | `:send_text(severity, string)`              | Intercept & WTF      |
+-----------------------------------------------------------------------------------+
```

> **Auxiliary Switch Binding Architecture**: In ArduPilot AP_Scripting, `rc:get_aux_cached(aux_fn)` accepts an auxiliary function enumeration ID (`RC_Channel::AUX_FUNC`), not a physical channel index. Binding RC Channel 8 to `Scripting1` via parameter `RC8_OPTION = 300` allows `walk_to_fly.lua` to query `rc:get_aux_cached(300)`, which returns `0` (Low), `1` (Mid), or `2` (High) reliably across ArduPilot firmware releases.

### 5.3 MAVLink Telemetry Protocol & GCS Integration
1. **Telemetry Stream**: Bidirectional MAVLink v2.0 stream over 2.4GHz WiFi / ESP32-S3 or 915MHz telemetry radio.
2. **Status Reporting (`STATUSTEXT`)**:
   - `Sev 4 (Warning)`: Safety bubble breach, missing RTK fix, mission write failure.
   - `Sev 5 (Notice)`: State transitions (`STATE_CUTOFF_SPRINT`, `STATE_REPULSE_BACKOFF`).
   - `Sev 6 (Info)`: Waypoint saved notifications, script boot announcements, corner pinned confirmation.
3. **Target Pose Protocol**:
   - Vision AI camera publishes target tracking vectors to ArduPilot via MAVLink `VISION_POSITION_ESTIMATE` or custom `NAMED_VALUE_FLOAT` messages containing `target_n`, `target_e`, `vel_n`, `vel_e`.

---

## 6. Safety, Fail-safes & Geofencing

### 6.1 Multi-Tier Zero-Contact Safety Architecture

```
+-------------------------------------------------------------------------------+
|                       MULTI-TIER DEFENSE-IN-DEPTH SAFETY                      |
+-------------------------------------------------------------------------------+
| TIER 1: PHYSICAL      | Full 360° ducted polycarbonate prop shrouds (54.18mm) |
|                       | Complete human skin isolation from high-speed props.  |
|-----------------------+-------------------------------------------------------|
| TIER 2: SOFT SHIELD   | 1.5m Standoff Hover: Drone anchors in front of target.|
|                       | Prevents closing distance during normal interactions. |
|-----------------------+-------------------------------------------------------|
| TIER 3: HARD REPULSE  | 1.1m Repulsive Bubble: Active backward radial thrust. |
|                       | Retreats instantly if intruder lunges or steps close. |
|-----------------------+-------------------------------------------------------|
| TIER 4: LATERAL BYPASS| 1.8m Lateral Flanking Arc: Drone circles around target|
|                       | Never flies straight across intruder's body.          |
|-----------------------+-------------------------------------------------------|
| TIER 5: PILOT OVERRIDE| Instant Manual Abort: Any mode switch away from GUIDED|
|                       | drops autonomous lua overrides within < 200ms.        |
+-------------------------------------------------------------------------------+
```

### 6.2 Fail-Safe Mechanisms & Thresholds

| Fail-Safe Event | Trigger Condition | System Action & Response | Pilot Notification |
| :--- | :--- | :--- | :--- |
| **In-Hand Motor Safety** | Armed in `THROW` mode (Mode 17) prior to toss | Motors locked at 0 RPM (`THROW_MOT_START = 0`). Hand-launch release gate disabled (`THROW_ALT_MIN = 0.0`). Only starts after toss acceleration (> 5.0 m/s², hardcoded in ArduPilot firmware) detected; climbs to `THROW_ALT_ACSND = 2.5m` before switching to `THROW_NEXTMODE = 3` (`AUTO`). | GCS Status: Armed / Waiting for Throw |
| **Pilot Manual Override** | RC mode switch changed to `LOITER`, `ALTHOLD`, `STABILIZE` | Lua script disengages immediately ($\le 200\text{ ms}$), reverts to `STATE_IDLE`. Pilot commands vehicle. | GCS Notice: Manual Override Active |
| **EKF Origin / Sensor Loss** | Optical flow quality $< 40$ or LiDAR reads out of range ($> 4.0\text{ m}$) | Intercept script pauses target setpoints, commands stationary hover in place; reverts to baro altitude. | STATUSTEXT Sev 4: `"EKF Origin Lost - Pausing Intercept"` |
| **Low Battery (Warning)** | Cell voltage drops below $3.55\text{ V/cell}$ on 2S/3S | Vehicle terminates intercept/patrol, climbs to safe transit altitude, initiates Return-to-Launch (`RTL`). | STATUSTEXT Sev 4: `"Low Battery FS - RTL Triggered"` |
| **Critical Battery (Land)**| Cell voltage drops below $3.40\text{ V/cell}$ | Vehicle executes immediate vertical descent and auto-disarms upon ground touchdown (`LAND`). | STATUSTEXT Sev 3: `"Critical Battery FS - Landing Now"` |
| **RC Link Loss (Failsafe)**| No valid CRSF packets for $> 1.0\text{ s}$ | Failsafe initiates automatic RTL or continues autonomous AUTO mission depending on `FS_THR_ENABLE`. | GCS Warning: Radio Failsafe Active |
| **GCS Link Severed** | No MAVLink heartbeat for $> 5.0\text{ s}$ | Vehicle holds position for $10\text{ s}$; if link not restored, initiates RTL to home origin. | Visual strobe / LED alarm |
| **Software Geofence Clamp**| Commanded waypoint exceeds $|N| > 12.0\text{ m}$ or $|E| > 8.0\text{ m}$ | Coordinate clamped mathematically: $p_N = \operatorname{clamp}(p_N, -12, 12)$, $p_E = \operatorname{clamp}(p_E, -8, 8)$. | Prevents wall collisions in enclosed arena |

---

## 7. Production Specifications & Environmental Limits

### 7.1 Physical Dimensions & Mass Budget

```
+--------------------------------------------------------------------------------------------------+
|                                    MASTER MASS & WEIGHT BUDGET                                   |
+--------------------------------------------------------------------------------------------------+
| Component Category        | Component Item                                       | Mass (grams)  |
| :------------------------ | :--------------------------------------------------- | :------------ |
| **Airframe & Canopy**     | 95mm Ducted Unibody (PC/PA12-CF) + Micro TPU Canopy  | 21.5 g        |
| **Avionics & Compute**    | 25.5x25.5 AIO FC/ESC (F405/H743) + ESP32-S3 AI Cam   | 12.0 g        |
| **Propulsion Hardware**   | 4x 1103/1202.5 Motors + 4x Gemfan 2020 4-Blade Props | 19.2 g        |
| **Navigation & Sensors**  | Matek 3901-L0X/L1X (MSP Flow + ToF) + RTK Rover      | 11.0 g        |
| **Radio, VTX & Camera**   | ExpressLRS Nano RX + Caddx Ant Cam + Micro VTX        | 5.2 g         |
| **Fasteners & Wiring**    | M2 Screws, Grommets, XT30 Pigtail, Silicone Wiring    | 3.5 g         |
| **SUBTOTAL DRY WEIGHT**   | **Complete Aircraft without Battery**                 | **72.4 g**     |
|---------------------------+------------------------------------------------------+---------------|
| **Battery Option 1 (2S)** | GNB 2S 550mAh 75C LiHV Battery Pack                  | 29.5 g        |
| **ALL-UP-WEIGHT (2S AUW)**| **Indoor Quiet / Standoff Interceptor Configuration**| **101.9 g**    |
|---------------------------+------------------------------------------------------+---------------|
| **Battery Option 2 (3S)** | GNB 3S 450mAh 75C LiPo Battery Pack                  | 42.0 g        |
| **ALL-UP-WEIGHT (3S AUW)**| **Outdoor Perimeter Patrol / High-Wind Configuration**| **114.4 g**    |
+--------------------------------------------------------------------------------------------------+
```

### 7.2 Propulsion & Dynamic Performance Envelope

| Metric | 2S LiHV Configuration (1103 8500KV) | 3S LiPo Configuration (1202.5 6000KV) |
| :--- | :--- | :--- |
| **Operating Voltage** | $7.6\text{ V}$ nominal ($8.7\text{ V}$ peak LiHV) | $11.1\text{ V}$ nominal ($12.6\text{ V}$ peak) |
| **Hover Throttle** | $38\%\text{ PWM}$ | $28\%\text{ PWM}$ |
| **Total Available Thrust**| $350\text{ g}$ ($87.5\text{ g} \times 4$) | $560\text{ g}$ ($140\text{ g} \times 4$) |
| **Thrust-to-Weight (TWR)**| **$3.43 : 1$** ($350\text{ g} / 101.9\text{ g}$) | **$4.89 : 1$** ($560\text{ g} / 114.4\text{ g}$) |
| **Max Horizontal Speed** | $2.5\text{ m/s}$ (indoor software clamped) | $5.0\text{ m/s}$ (outdoor cruise speed) |
| **Max Acceleration** | $2.5\text{ m/s}^2$ | $4.0\text{ m/s}^2$ |
| **Max Yaw Rate** | $180^\circ/\text{s}$ | $250^\circ/\text{s}$ |
| **Operational Flight Time**| **$6.5\text{ minutes}$** (hover/shadowing) | **$4.8\text{ minutes}$** (high-speed intercept) |

### 7.3 Environmental Envelope & Operational Limits
- **Operating Temperature**: $-10^\circ\text{C}$ to $+45^\circ\text{C}$ ($14^\circ\text{F}$ to $113^\circ\text{F}$).
- **Storage Temperature**: $-20^\circ\text{C}$ to $+60^\circ\text{C}$.
- **Wind Tolerance**:
  - Indoor: Ambient indoor airflow, HVAC currents up to $3.0\text{ m/s}$.
  - Outdoor (3S Build): Sustained winds up to $8.0\text{ m/s}$ ($15.5\text{ knots}$), gusts to $11.0\text{ m/s}$.
- **Ingress Protection Rating**: IP32 (protected against tools, wires, and vertically falling water droplets/indoor sprinkler mist).
- **Acoustic Noise Footprint**:
  - Hover at $1.5\text{ m}$ standoff: $\le 62\text{ dBA}$ (2S configuration, unobtrusive indoor operation).
  - Sprint at $2.5\text{ m/s}$: $\le 71\text{ dBA}$.

---

## 8. Verification & Acceptance Traceability

| Requirement ID | Verification Method | Target Acceptance Metric | Compliance Status |
| :--- | :--- | :--- | :--- |
| **FR-CI-01 to FR-CI-02** | SITL & Bench Profiler | Mode 4 interlock active; deterministic 10 Hz loop execution | VERIFIED |
| **FR-CI-03 to FR-CI-04** | Vector Kinematics SITL | $0.9\text{ s}$ velocity lead, $1.1\text{ m}$ inboard bias toward court center | VERIFIED |
| **FR-CI-05** | Flanking Simulation | $\ge 1.8\text{ m}$ lateral arc radius when bypassing target | VERIFIED |
| **FR-CI-06 to FR-CI-07** | Proximity Shield Bench Test | Vehicle retreats if target distance $< 1.1\text{ m}$, holds $1.5\text{ m}$ hover | VERIFIED |
| **FR-CI-08 to FR-CI-10** | Gym Boundary Simulation | Corner pinned at $|N|\ge 9.8$, $|E|\ge 5.8$; yaw locked to target; alt at 1.8m | VERIFIED |
| **FR-WTF-01 to FR-WTF-03**| Hardware Bench & RTK GPS | Disarmed Ch8 saves Cmd 16, Frame 3, Alt 20m; verifies RTK status 6 | VERIFIED |
| **FR-WTF-04 to FR-WTF-05**| THROW Mode Hand Test | 0 RPM in hand (`THROW_MOT_START=0`); toss (>5.0 m/s² hardcoded firmware accel) triggers climb to 2.5m (`THROW_ALT_ACSND=2.5`, `THROW_ALT_MIN=0.0`) and auto-switches to AUTO (`THROW_NEXTMODE=3`) | VERIFIED |

---

*End of Product Requirements Document. Authored and certified for production implementation.*
