# OSITO DRONE LLC — DEEP EXECUTIVE STRATEGY & CROSS-PROJECT CONSISTENCY BIBLE (2026–2027)

**Legal Entity:** **Osito Drone LLC** (`d/b/a Osito Drone Services` & `d/b/a Osito Drone Academy`)  
**Executive Leadership & Contact Roster:**
- **Miguel Flores** — *Chief Executive Officer (CEO & Co-Founder)* | `415-571-6614` | `miguel@ositodrone.com` (Primary School, Camp & Commercial Account Booking)
- **Alan Musselman** — *Chief Operating Officer (COO & Co-Founder)* | `415-810-4158` | `alan@ositodrone.com` (Revenue Operations, Pricing/Finance, AI & Flight Simulators, B2B Oil/Gas & Venue Partnerships)
- **Jesus Aceves** — *Chief Technology Officer (CTO & Co-Founder)* | `415-269-1206` | `jesus@ositodrone.com` (Avionics Engineering, Fleet Manufacturing, Field Safety & Makerspace Labs)

---

## 1. EXECUTIVE SUMMARY & STRATEGIC ARCHITECTURE

**Osito Drone LLC** operates a high-margin, dual-engine business model designed to generate immediate Q4 2026 cash flow in the San Francisco Bay Area while scaling recurring B2B/B2G retainers in 2027:

1. **Division 1: `Osito Drone Academy` (Youth STEM Education, Holiday Camps & Mobile Flight Labs)**
   - **Core Value Proposition:** Turnkey, 100% indoor-safe mobile STEM & FPV flight labs for K–12 schools, holiday vacation camps, youth clubs, and private events—requiring zero teacher prep and zero school hardware CapEx.
   - **Standardized 4-Station Rotation Architecture (12–16 Students per Rotation):**
     - **Station 1: 4-Pilot Tablet Flight Sim Pod** — `4× ANTEMPER 10.1" Android 16 Tablets` + `4× RadioMaster T8L ELRS Controllers` + `90° USB-C OTG+PD Splitters` + `Anker SOLIX C300 DC` packed inside a single weatherproof **Apache 4800 / Pelican 1550** hard case, running **Acrobee65 Flight Simulator v0.5 (SF Tour Edition, 42-Waypoint C2 Spline)**.
     - **Station 2: Pop-Up Netted Hover Pods** — Line-of-sight throttle, yaw, pitch, and hover mastery using featherweight ducted classroom micro-drones (**`39.5g CUB-75`** & **`~30g AcroBee65 / Hover65`**).
     - **Station 3: FPV Goggle Obstacle Course** — Seated cockpit FPV co-piloting through illuminated LED gates inside a contained safety perimeter.
     - **Station 4: Modular Tear-Down & Staff Pit-Crew Hub** — *Standard School/Camp Mode:* Osito Pit-Crew staff perform all hot-tool maintenance and `BT2.0` battery swaps so students never touch hot soldering irons while exploring tool-free modular snap-together drone diagnostics. *Advanced Makerspace / Elective Mode:* Supervised low-voltage USB-C soldering (`Pinecil`) with mandatory ANSI Z87.1 safety glasses.

2. **Division 2: `Osito Drone Services` (B2B Commercial Aerial Inspections, Energy, Events & Airspace Security)**
   - **6 Standardized Service Pillars (`2027 Full-Spectrum Annual Lock-In Target: $323,900+ ARR`):**
     - **Pillar 1 (STEM & Schools):** 3-Season School Partner MOUs (`STEM-3S`, `$16,200/yr`) & Vacation Camp Blocks (`$600` / `$960`).
     - **Pillar 2 (Construction & Civil Progress):** Single Ortho/4K (`CON-01`, `$450`), Monthly Lender-Draw Retainer (`CON-12M`, `$595/mo`), Bi-Weekly Progress (`CON-BIW`, `$1,095/mo`).
     - **Pillar 3 (Commercial Roof, Facade & HVAC Thermal):** Single Roof Trial (`ROOF-01`, `$245` Standard / `$195` Nov Promo), Quarterly Property Manager Portfolio (`ROOF-PM`, `$1,450/qtr`), and **`OSITO THERMO-95`** confined-space/attic thermal diagnostics.
     - **Pillar 4 (Real Estate & Hospitality Marketing):** Single 4K + Indoor FPV Bundle (`$495` Promo / `$500` MSA), 4-Listing Pre-Paid Pack (`RE-4PK`, `$1,600`).
     - **Pillar 5 (Taproom, Corporate Offsite & Festival Attractions):** **`SHARD-75 / KODIAK-75`** Magnetic-Armor Drone Combat + **`TURBOPAW-64`** Dual-Monitor FPV Race Rig (`$15/pilot` Pay-Per-Battle, `$800/night` Brewery Rig, `$1,500/mo` 2-Night Taproom Residency, `$1,800–$3,500` Corporate Offsite).
     - **Pillar 6 (B2B Airspace & Perimeter Security + Oil & Gas Basin Surveys):** **`OSITO WATCHTOWER-1`** 24/7 Remote ID Sensor (`SEC-1`, `$495/mo`), **`OSITO OVERWATCH-T`** Thermal Patrol (`SEC-2`, `$2,400/mo`), VIP Overwatch (`SEC-3`, `$2,200/event`), Red-Team Audit (`SEC-4`, `$3,500`), Enterprise 3-Node Bundle (`SEC-5`, `$14,500/yr`), and **Southwest Operating East Texas Basin Surveys** (`Tier 1` `$1,500` Proof-of-Value, `Tier 2` `$6,250` Manziel 5-Well Pre-Spud Package, `Tier 3A` `$3,500/qtr` 25-Well Retainer, `Tier 3B` `$95/well` Enterprise).

---

## 2. MASTER PRICING & UNIT ECONOMICS SCHEDULE (SINGLE SOURCE OF TRUTH)

| Code | Service / Package Name | Duration / Scope | Cohort / Capacity | Official Client Price | Hired-Staff COGS & Labor Basis | Verified Net Margin |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **`CAMP-BLK`** | Holiday Camp / School Single Guest Block | `90–120 Mins` | Up to `16–20` Pilots | **`$600.00`** | Lead (`$45/hr`) + 2 Coaches (`$30/hr`) | **`~64%` (`$900` Founder Net)** |
| **`PKG-1`** | 1-Day STEM Discovery Workshop / Half-Day Camp | `2.0 Hours` (or Two 90m Blocks) | `16` (`4×4` Squads) or `32` Split | **`$960.00`** (`$60/student`) | `$45/hr` Lead + `2× $30/hr` Coaches | **`57.5%` Hired / `93%` Founder** |
| **`PKG-1X`** | Extended Family STEM Night / 3-Hr Workshop | `3.0 Hours` | `16–24` Students | **`$1,200.00`** (`$75/student`) | `$45/hr` Lead + `2× $30/hr` Coaches | **`61.0%` Hired / `92%` Founder** |
| **`PKG-2B`** | 8-Week After-School Autonomous Drone & Flight Lab | `12.0 Hours` (`8 × 90m`) | `16` Students | **`$5,600.00`** (`$350/student`) | `$45/hr` Lead + `2× $30/hr` Coaches | **`46.0%` (`$2,575.44` Net)** |
| **`PKG-3A`** | 5-Day Half-Day Vacation / Summer Flight Camp | `15.0 Hours` (`5 × 3.0h`) | `16` Students (`12` Kid Option) | **`$6,800.00`** (`$425/student`; `$5,100` for 12) | `$45/hr` Lead + `2× $30/hr` Coaches | **`52.4%` (`$3,563.00` Net)** |
| **`PKG-3B`** | 5-Day Full-Day Vacation / Summer Flight Camp | `30.0 Hours` (`5 × 6.0h`) | `16` Students (`12` Kid Option) | **`$10,800.00`** (`$675/student`; `$8,100` for 12) | `$45/hr` Lead + `2× $30/hr` Coaches | **`54.8%` (`$5,918.00` Net)** |
| **`STEM-3S`** | 3-Season Annual School Partner MOU | Spring + Summer + Fall | `16` Students / Season | **`$16,200.00 / yr`** (`10%` off `$18,000`) | Annualized 3-Season Staffing | **`50.2%` (`$8,132.00` Net)** |
| **`BDAY-60`** | 60-Min Mobile Drone Party / Pop-Up | `60 Mins` | Up to `8` Pilots | **`$200.00`** | 1 Lead + 1 Coach | **`55.0%` Hired / `90%` Founder** |
| **`BDAY-90`** | 90-Min November Launch Special Party | `90 Mins` | `8–12` Pilots | **`$299.00`** | 1 Lead + 1 Coach | **`60.0%` Hired / `91%` Founder** |
| **`BDAY-120`**| 2-Hour Deluxe Drone Battle & FPV Party | `120 Mins` | Up to `10–12` Pilots | **`$400.00`** | 1 Lead + 1 Coach | **`63.0%` Hired / `92%` Founder** |
| **`CON-01`** | Single Construction Ortho + 4K Progress Shoot | `1 Visit` (`48h` SLA) | 1 Jobsite | **`$450.00`** (`$395` First Trial) | Part 107 Pilot (`$65/hr`) | **`72.0%` Hired / `92%` Founder** |
| **`CON-12M`** | Monthly Construction Progress Retainer | `12 Visits / yr` (`1/mo`) | 1 Jobsite | **`$595.00 / mo`** (`$7,140/yr`) | Part 107 Pilot (`$65/hr`) | **`76.0%` Hired / `93%` Founder** |
| **`CON-BIW`** | Bi-Weekly Construction Progress Retainer | `24 Visits / yr` (`2/mo`) | 1 Jobsite | **`$1,095.00 / mo`** (`$13,140/yr`) | Part 107 Pilot (`$65/hr`) | **`75.0%` Hired / `93%` Founder** |
| **`ROOF-01`** | Single Commercial Roof Thermal + 4K Scan | `1 Building` | Up to `25k sq ft` | **`$245.00`** (`$195` First Trial) | Part 107 Pilot (`$65/hr`) | **`66.0%` Hired / `91%` Founder** |
| **`ROOF-PM`** | Property Manager Quarterly Roof & Gutter Plan | `4 Scans / yr` | Up to `5` Properties | **`$1,450.00 / qtr`** (`$5,800/yr`) | Part 107 Pilot (`$65/hr`) | **`74.0%` Hired / `92%` Founder** |
| **`RE-4PK`** | Luxury Real Estate 4-Listing Pre-Paid Pack | `4 Complete Shoots` | Aerial + Indoor FPV | **`$1,600.00`** (`$400/listing`; `$495` Single Promo) | Part 107 / FPV Pilot (`$65/hr`) | **`71.0%` Hired / `91%` Founder** |
| **`BREW-2N`** | Taproom Bi-Weekly Drone Combat & Race Night | `2 Nights / mo` (`3h/night`) | `SHARD-75` + `TURBOPAW-64` | **`$1,500.00 / mo`** (`$800` Single Night) | 2 Event Ops Staff | **`70.0%` Hired / `90%` Founder** |
| **`SEC-1..5`**| B2B Airspace & Perimeter Security Suites | Passive RF to Nightly Thermal | `WATCHTOWER-1` / `OVERWATCH-T` | **`$495/mo`** (`SEC-1`) to **`$2,400/mo`** (`SEC-2`) / **`$14,500/yr`** (`SEC-5`) | Part 107 Security Pilot (`$65/hr`) | **`68%–82%` Gross Margin** |
| **`SWO-1..3`**| Southwest Operating East Texas Basin Program | Pre-Spud Pad & Lease Integrity | 1 to 100+ Wells | **`$1,500`** (`Tier 1`) / **`$6,250`** (`Tier 2` 5-Well) / **`$3,500/qtr`** (`Tier 3A`) | Saves `$4,500–$8,500/pad` (`20%–35%` dirt work) | **`75%+` Gross Margin** |

---

## 3. MASTER HARDWARE FLEET & AVIONICS SPECIFICATION TABLE

| Platform Designation | Role & Division | Verified Mass (AUW) | Battery & Connector Standard | Radio / Sensor Architecture | Verified Unit BOM Cost |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`OSITO CUB-75`** | Primary 75mm Ducted STEM Trainer (`Osito Drone Academy`) | **`39.5g`** (LOS) / **`41.1g`** (Dual LOS+FPV) | `1S 550mAh LiHV` (**`BT2.0`**) | ELRS 2.4GHz (`RadioMaster T8L` Fleet Standard / `Pocket` Compatible) | **`$98.04`** Bare Aircraft (`$146.03` Take-Home Kit w/ T8L Radio & Charger) |
| **`OSITO HOVER-65 / LILBEAR-65 / ACROBEE-65`** | 65mm Featherweight Indoor Classroom Fleet (`Osito Drone Academy`) | **`25.5g–30.0g`** | `1S 300mAh LiHV` (**`BT2.0`** Standard; `PH2.0` Legacy) | `AT32F435` / `STM32F411` + `SPL06` Baro + `MTF-01` Optical Flow + ELRS | **`$25.75–$34.65`** CM Turnkey Box-Build |
| **`OSITO SHARD-75 (KODIAK-75)`** | 75mm N52 Magnetic Breakaway-Armor Combat Drone (`Events & Academy`) | **`37.1g`** (LOS) / **`38.8g`** (Dual LOS+FPV) / **`45.5g`** (Full OptFlow + LiDAR + Armor) | `1S 550mAh LiHV` (**`BT2.0`**) | ELRS 2.4GHz + N52 Hall-Effect Hit Detection + WS2812B Damage Bars | **`$101.44`** (LOS) / **`$121.43`** (Dual LOS+FPV) / **`$112.50`** Blended Avg |
| **`OSITO TURBOPAW-64`** | 1:64 Scale Dual-Monitor FPV Micro Race Rig (`Brewery & Corporate Events`) | Sub-50g Micro FPV Car | `1S LiHV` + `VIFLY WhoopStor V3` | Dual 5.8GHz FPV Monitors + Lap Timer Arch | **`$1,126.90`** Complete 2-Player Turnkey Rig |
| **`OSITO THERMO-95`** | 95mm Confined-Space & Attic HVAC Thermal Drone (`Osito Drone Services`) | Sub-250g Ducted (`0.77 A` / `5.82 W` at `7.6V` Perched Mode) | `2S LiHV` (`XT30`) | Radiometric Thermal + Perched-Mode Telemetry (`RadioMaster T8L / Pocket`) | **`$628.20`** Tier A Aircraft / **`$1,060.64`** Tier B Complete Field Kit |
| **`OSITO-INT-95 ("Interceptor")`** | 95mm Indoor Autonomous Acoustic Deterrent R&D Testbed (`AI Security Drone/`) | **`101.9g`** (2S) / **`114.4g`** (3S); Frame `18.0g–18.56g` | `2S/3S` (`~5.2–6.5m` 2S / `~4.0–4.8m` 3S) | `Matek H743-MINI` + **`Matek 3901-L1X` (`VL53L1X` 4m ToF)** + `1.8m AGL` Indoor Standoff | **`$270.00`** Prototype BOM |
| **`OSITO WATCHTOWER-1 & OVERWATCH-T`** | Outdoor B2B Airspace RF Sensor & 7-Inch Thermal Overwatch (`Osito_Security_Services`) | Fixed Node + 7" Outdoor Quad (`>=30m / 100ft AGL` Safe Floor) | AC/PoE (Node) / `6S Li-Ion` (Quad) | Passive ASTM F3411 Remote ID + 640×512 Radiometric Thermal + Spotlight | **`$184.40`** (`WATCHTOWER-1`) / **`$1,645.00`** (`OVERWATCH-T`) |

---

## 4. UC BERKELEY EXECUTIVE AI STRATEGY & WORKFLOW ARCHITECTURE

Applying the **UC Berkeley Executive Education AI Strategy Framework** (`Perception` → `Prediction` → `Generation & Agentic Action` across **Tiers 1, 2, and 3**):

### A. Capabilities Decomposition across Osito Drone Operations
1. **Perception (Structuring Unstructured Inputs):**
   - **Field & Sales Voice Capture (`Osito Note Taker PWA`):** Transcribes walk-in notes from Miguel's school/camp drop-ins (`02_Web_Apps_and_Tools/osito-note-taker/`) and extracts contact names, camp dates, and objection tags.
   - **Aerial Thermal & Orthomosaic Ingestion (`THERMO-95`, `DJI Mavic 3T/3E`):** Reads radiometric RJPEG roof/HVAC thermal imagery and East Texas well-pad elevation rasters (`Southwest operating`) to flag moisture anomalies (`Delta-T > 4.5°C`) and cut-and-fill volumes.
2. **Prediction & Scoring (Tier 1 Deterministic Rules + Tier 2 Classical ML):**
   - **Tier 1 Deterministic Pricing & Margin Engine:** All program ratios (`1 drone per 2 students`, `1 coach per 4-station pod`, `$45/hr` Lead + `$30/hr` Coach, `$65/hr` Part 107 Pilot) are locked into [`Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html`](../../02_Web_Apps_and_Tools/production-cost-estimator/Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html) so quotes never suffer from math hallucinations.
   - **Tier 2 Lead Prioritization (`drone-stem-sales-engine`):** Scores SF schools, camps, and commercial leads (`01_Sales_and_STEM_Academy/November_2026_Fast_Cash_Blitz/`) by student cohort volume, Title I/IV & ELO-P grant readiness, and proximity along Miguel's 5 neighborhood walk-in corridors.
3. **Generation & Agentic Action (Tier 3 Multi-Agent Workflows):**
   - **Automated `.docx` & `.eml` Dispatch Pipeline:** Generates client-ready `.docx` rate cards/proposals and pre-populated Microsoft Outlook `.eml` drafts (`05_Outbox_Emails/`) with `X-Unsent: 1` for instant founder review.

### B. Governance & Risk Gate (Human-in-the-Loop Checkpoints)
- **Zero Unreviewed Outbound Dispatch:** All `.eml` files generated in `05_Outbox_Emails/` use `X-Unsent: 1` so Miguel, Alan, or Jesus explicitly reviews and clicks **Send** in Outlook (`olk.exe`).
- **Avionics & Physical Safety Interlocks:** `AI Security Drone` Lua scripts enforce `16-bit millisecond rollover` protection, disarmed safety interlocks, and hardware rangefinder validation (`Matek 3901-L1X`), while youth STEM sessions strictly enforce sub-250g ducted prop guards, FAA TRUST compliance, and parent waivers releasing **Osito Drone LLC**.

---

## 5. SUMMARY OF CROSS-FOLDER & CROSS-PROJECT RECONCILIATIONS EXECUTED

1. **Legal Entity & Waiver Protection Fixed:** Updated [`Osito_Participant_Safety_Waiver.html`](../STEM_Academy_Collateral/Osito_Participant_Safety_Waiver.html) and [`Osito_2027_Commercial_Rate_Card_and_Order_Form.html`](../Commercial_Rate_Cards_and_Plans/Osito_2027_Commercial_Rate_Card_and_Order_Form.html) so the Indemnification & Release clauses explicitly protect **`Osito Drone LLC (d/b/a Osito Drone Services and Osito Drone Academy)`**.
2. **Station 1 & Station 4 Pedagogical Alignment:** Standardized Station 1 across all playbooks, workflows, and `.eml` drafts to the **4-Pilot Tablet Flight Sim Pod** (`Apache 4800 / Pelican 1550` with `4× ANTEMPER 10.1" Tablets + 4× RadioMaster T8L controllers`), and harmonized Station 4 into **Standard School/Camp Mode (Staff-Only Pit Crew — zero student hot tools)** vs. **Advanced Makerspace Soldering Elective**.
3. **Pricing & Margin Harmonization:** Eliminated the `$4,800` vs. `$6,800` 5-Day Camp discrepancy in [`Team_Miguel_CEO_Account_Playbook.md`](./Team_Miguel_CEO_Account_Playbook.md), added `SEC-1..5` and `TURBOPAW-64` to the 2027 Commercial Rate Cards, and reconciled `TAKEHOME_KIT_BOM` (`$98.04` bare / `$146.03` w/ T8L Radio) and `SHARD-75 / KODIAK-75` BOM/weights across [`Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html`](../../02_Web_Apps_and_Tools/production-cost-estimator/Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html) and `03_Hardware_and_Drones/`.
4. **Outbox `.eml` Consolidation & Dollar-Sign Repair:** Consolidated all `.eml` files into `05_Outbox_Emails/`, restored every stripped `$` figure caused by earlier unescaped shell variables, and fixed the duplicate `Station 2` line across all school/camp outreach emails.
5. **100% `.docx` Coverage & `ositodrone.com` Brand Parity:** Upgraded all HTML rate cards, waivers, and secondary web tools to Google Fonts `'Fjalla One'` + `'Roboto'` and `#7077CF` / `#232A68` / `#161616` brand tokens, and generated/updated **35 branded `.docx` files** across `01_Sales_and_STEM_Academy/` and `Southwest operating/`.
