# Osito Drone Website Staging & Production Cutover Runbook
**Zero-Downtime Migration, Email Preservation & GoDaddy Deployment Playbook**

**Document Version**: 1.0.0  
**Effective Date**: November 2026  
**Target Domains**: `ositodrone.com` | `www.ositodrone.com` | `staging.ositodrone.com`  
**Immediate Preview URL**: [https://alanmusselman.github.io/ositodrone-staging/](https://alanmusselman.github.io/ositodrone-staging/)  
**GitHub Repository**: `AlanMusselman/ositodrone-staging`  
**Authors**: Alan Musselman (COO), Miguel Flores (CEO), Jesus Aceves (CTO)  
**Security & Operations Standards**: FAA TRUST / Part 107 Compliant, Microsoft 365 Exchange Zero-Downtime Interlock, Let's Encrypt TLS Automation  

---

## Executive Summary & Architecture

This runbook defines the authoritative, step-by-step procedure to transition the Osito Drone primary commercial website (`ositodrone.com`) from the legacy GoDaddy Website Builder (DPS) to the newly engineered, high-performance web deployment hosted on GitHub Pages.

### Architectural Overview
- **Source Web Application**: `02_Web_Apps_and_Tools/ositodrone-homepage-sim-and-estimator/` (133 web assets: HTML5, CSS3, JavaScript, WebGL 3D Flight Simulator, interactive Instant Quote Estimator, STEM Academy portal, Custom Aerial Solutions portfolio, engineering CAD toolbox, and client download deliverables).
- **Deployment Platform**: Dedicated public GitHub repository `AlanMusselman/ositodrone-staging` serving static assets via GitHub Pages Anycast Content Delivery Network (CDN) with automated Let's Encrypt SSL/TLS certificate generation.
- **Apex & Subdomain Routing**:
  - Apex Domain: `ositodrone.com` (pointed to 4 Anycast IPv4 A records: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`).
  - WWW Subdomain: `www.ositodrone.com` (pointed via CNAME to `alanmusselman.github.io`).
  - Staging Preview Subdomain: `staging.ositodrone.com` (pointed via CNAME to `alanmusselman.github.io`).
- **Immediate Live Staging URL**: `https://alanmusselman.github.io/ositodrone-staging/` (live immediately without DNS waiting, complying with the GEMINI.md SSL Pre-Flight Rule).
- **Enterprise Email Safeguard**: 100% preservation of active Microsoft 365 Exchange DNS records (`ositodrone-com.mail.protection.outlook.com` MX, SPF TXT, and autodiscover CNAME), guaranteeing zero email downtime or bounced client inquiries for Alan, Miguel, or Jesus.
- **Rollback Guarantee**: Sub-5-minute rollback mechanism to restore legacy GoDaddy Website Builder A records (`76.223.105.230`, `13.248.243.5`) in the event of an unforeseen failure.

---

## Authoritative Pricing & Rate Cards (Preserved 25% Off New Year Special)

To maintain aggressive competitiveness against local Bay Area STEM and aerial inspection competitors, the website features the **25% Off Till the New Year** pricing structure. All calculations, estimators, and rate cards across the web platform reflect these authoritative rates:

| Package / Service Offering | Base Audience / Scope | Regular Rate | 25% Off New Year Rate | Savings | Included Deliverables |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **VIP Drone Birthday Party** | Up to 12 Pilots (2 Hours) | ~~$495~~ | **$371** | $124 | Ducted CUB-75 fleet, Netted Hover Cage, 4-Tablet Sim Pod, LED FPV Gates, FAA TRUST Wings |
| **TK–5 Aero-Cub Aeronautics Workshop** | Up to 15 Students (2 Hours) | ~~$600~~ | **$450** | $150 | Airfoil gliders, 3D printed prop plane assembly, Bernoulli lift math, ducted micro-drone flight |
| **2-Hour 4-Station STEM Flight Lab** | Up to 15 Students (4 Stations) | ~~$950~~ | **$713** | $237 | Engineering, Betaflight config, 4-Tablet 3D Sim Pod, ELRS radios, netted drone flight |
| **6-Week STEM Academy Cohort** | Up to 15 Students (6 Weeks) | ~~$2,400~~ | **$1,800** | $600 | Comprehensive after-school curriculum ($300/wk), Spanish/English bilingual instruction, take-home materials |
| **Corporate / Brewery Taproom FPV Race Night** | Up to 15 Challengers (2 Hours) | ~~$1,200~~ | **$900** | $300 | SHARD-75 Bumper-Drone Arena, Dual-Monitor FPV Track, live leaderboard, referee & timing system |
| **Commercial Aerial Roof & Thermal Inspection** | Per Zone / Structure | ~~$395+~~ | **$296+** | $99+ | FAA Part 107 licensed pilot, 4K orthomosaic, FLIR thermal imaging, 24-hr engineering PDF report |
| **Take-Home 3D Aero-Cub Drone Kit** | Per Student Add-On | ~~$35/kid~~ | **$26/kid** | $9/kid | 6-part Bambu Lab 3D printed airframe, carbon fiber motor rods, high-discharge LiPo & USB charger |

*Note: The platform includes the administrative portal (`admin.html` and `assets/osito-admin-data.js`) with No-Code Visual Editing enabled (`contenteditable` point-and-click text and rate modification).*

---

## Phase 1: Pre-Flight Verification & Staging Preview Sign-off

Before initiating any DNS changes in GoDaddy, execute the automated pre-flight audit to confirm 100% health across all web pages, interactive tools, and static assets.

### 1.1 Automated Health Verification Command
Execute the pre-flight check from the repository root:
```bash
python 06_Scripts_and_Automation/cutover_production.py check-preflight
```

### 1.2 Validation Gates & Pass Criteria
The automated script verifies four sequential operational gates:
1. **Gate 1: Network & Route Delivery**: All 13 routes (`index.html`, `flight-sim.html`, `osito-drone-academy.html`, `custom-aerial-solutions.html`, `toolbox.html`, `about.html`, `privacy-policy.html`, `stl-editor.html`, `osito-design-tool.html`, plus 4 subfolder tools in `toolbox/`) return HTTP `200 OK` with sub-400ms latency.
2. **Gate 2: Static Asset Integrity**: All 46 embedded static assets (including `dist/bundle.js` at 2.48 MB, `dist/bundle.css`, 15 MP4 video clips, 25+ JPG/PNG images, PDF guides, and ZIP archives) return HTTP `200 OK` with zero 404 failures.
3. **Gate 3: Interactive Features & DOM Logic**:
   - Hero photo carousel controls and thumbnail strip.
   - Instant Quote Estimator math logic verifying 25% off calculations.
   - 3D Flight Simulator canvas mount (`#root`), Three.js WebGL context creation, 6-DoF physics loop, Web Audio synthesizer, and SF landmarks.
   - STEM Academy 3-step curriculum cards, booking triggers, and 10-volume coloring book preview drawer.
   - In-house 3D STL editor and flowchart application launchers.
4. **Gate 4: JavaScript Syntax & Console Health**: Node.js AST syntax validation (`node -c`) passes cleanly on `dist/bundle.js`, `assets/osito-admin-data.js`, and all 13 inline script blocks with zero `SyntaxError` exceptions.

### 1.3 Executive Sign-Off Gate
Do not proceed to Phase 2 until `check-preflight` displays:
```text
============================================================================
 PRE-FLIGHT VERDICT
============================================================================
  >>> PRE-FLIGHT CHECKS PASSED: READY FOR PRODUCTION CUTOVER <<<
```

---

## Phase 2: DNS TTL Reduction (T-2 Hours Before Cutover)

DNS Time-To-Live (TTL) controls how long recursive DNS resolvers (e.g., Google `8.8.8.8`, Cloudflare `1.1.1.1`, Comcast, AT&T) cache existing DNS records. Standard GoDaddy TTLs are set to 1 hour (3600 seconds) or 1 day (86400 seconds).

Reducing the TTL to **600 seconds (10 minutes)** two hours prior to the live cutover ensures that when the A records are switched in Phase 3, worldwide traffic migrates to GitHub Pages within minutes rather than hours.

### Step-by-Step TTL Reduction Instructions
1. Open your browser and navigate to the **GoDaddy Domain Control Center**: [https://dcc.godaddy.com/](https://dcc.godaddy.com/).
2. Log in using the Osito Drone LLC account credentials.
3. Click on **ositodrone.com** in your Domain Portfolio.
4. Under the **DNS** tab, click **DNS Records**.
5. Locate the existing **A Records** pointing to:
   - `76.223.105.230`
   - `13.248.243.5`
6. Click the **Pencil (Edit)** icon next to each A record.
7. Change the **TTL** dropdown from `1 Hour` or `1 Day` to **`1/2 Hour` (or `600 seconds` / `Custom: 600`)**.
8. Click **Save**.
9. Locate the **CNAME Record** for `www` and change its TTL to **`1/2 Hour` (or `600 seconds`)**. Click **Save**.
10. **Wait 2 Hours**: Allow the previous 1-hour or 1-day TTL cache to expire globally.

---

## Phase 3: The Live Switch (DNS Update & Custom Domain Binding)

### 3.1 Step A: Update GoDaddy DNS Records
Once the 2-hour TTL window has elapsed, apply the production DNS entries:

1. In the GoDaddy DNS Records table, **Delete** the two legacy GoDaddy DPS A records:
   - Delete `A` -> `@` -> `76.223.105.230`
   - Delete `A` -> `@` -> `13.248.243.5`
2. Click **Add New Record** and create the **4 GitHub Pages Anycast A Records**:
   - **Type**: `A` | **Name**: `@` | **Value**: `185.199.108.153` | **TTL**: `600 seconds` (or `1/2 Hour`)
   - **Type**: `A` | **Name**: `@` | **Value**: `185.199.109.153` | **TTL**: `600 seconds` (or `1/2 Hour`)
   - **Type**: `A` | **Name**: `@` | **Value**: `185.199.110.153` | **TTL**: `600 seconds` (or `1/2 Hour`)
   - **Type**: `A` | **Name**: `@` | **Value**: `185.199.111.153` | **TTL**: `600 seconds` (or `1/2 Hour`)
3. Update or Add the **WWW CNAME Record**:
   - **Type**: `CNAME` | **Name**: `www` | **Value**: `alanmusselman.github.io` | **TTL**: `600 seconds` (or `1/2 Hour`)
4. *(Optional Staging Subdomain)* Add the **Staging CNAME Record**:
   - **Type**: `CNAME` | **Name**: `staging` | **Value**: `alanmusselman.github.io` | **TTL**: `600 seconds` (or `1/2 Hour`)
5. Click **Save All Records**.

### 3.2 Step B: Automated Custom Domain Binding via Cutover Tool
Immediately following DNS record entry in GoDaddy, execute the automated cutover command:
```bash
python 06_Scripts_and_Automation/cutover_production.py execute-cutover
```

#### What This Command Does Automatically:
1. Calls the GitHub REST API (`gh api repos/AlanMusselman/ositodrone-staging/pages -X PUT -F "cname=ositodrone.com"`).
2. Sets the custom domain to `ositodrone.com` and creates an automatic redirect from `www.ositodrone.com`.
3. Initiates the Let's Encrypt TLS certificate challenge.
4. Polls the GitHub Pages build status until the TLS certificate is provisioned.
5. Automatically executes HTTPS enforcement (`https_enforced=true`), guaranteeing all HTTP port 80 requests redirect to HTTPS port 443 with HSTS headers.

---

## Phase 4: Post-Cutover Verification

Confirm worldwide availability, TLS certificate validity, and zero-downtime routing.

### 4.1 Automated Post-Flight Verification Command
Run the post-flight verification suite:
```bash
python 06_Scripts_and_Automation/cutover_production.py verify-postflight
```

### 4.2 Automated Verification Steps Executed:
1. **Apex HTTPS Probe**: Connects to `https://ositodrone.com/`, verifies that IP resolves to the GitHub Anycast cluster, confirms Let's Encrypt SSL certificate, tests HTTP 200 on all routes, and asserts 0 asset 404s.
2. **WWW Subdomain Probe**: Connects to `https://www.ositodrone.com/`, verifies 301 redirection to apex or direct 200 delivery with valid SAN certificate coverage.
3. **Interactive Simulator & Logic Probe**: Executes `verify_interactive_features.py` against `https://ositodrone.com/` asserting complete DOM interactivity, estimator calculation accuracy, and zero JavaScript console errors.

### 4.3 Manual Founder Smoke-Test Checklist
Have Alan, Miguel, or Jesus perform this quick 2-minute smoke test on a desktop browser and mobile device:
- [ ] Open `https://ositodrone.com` in an incognito/private browser window.
- [ ] Verify browser address bar displays the security padlock (HTTPS valid, zero SSL warnings).
- [ ] Click through the top navigation: *3D Simulator*, *STEM Academy*, *Custom Solutions*, *Toolbox*.
- [ ] On the homepage, adjust the Instant Quote Estimator slider (select *VIP Party* and verify **$371**, *STEM Flight Lab* and verify **$713**, *6-Week Academy* and verify **$1,800**).
- [ ] Click *Launch 3D Flight Simulator* and verify Three.js canvas loads with flight physics and audio.
- [ ] Send a test email from an external personal account (e.g. Gmail) to `alan@ositodrone.com` and `miguel@ositodrone.com` to confirm immediate receipt in Microsoft Outlook.

---

## Phase 5: Normalization (T+24 Hours After Cutover)

After 24 hours of stable production operation:
1. Sign in to GoDaddy Domain Control Center (`dcc.godaddy.com`).
2. Navigate to **ositodrone.com** -> **DNS Records**.
3. Edit the 4 GitHub Anycast A records and the `www` CNAME record.
4. Increase the **TTL** from `600 seconds` (10 minutes) back to **`1 Hour` (3600 seconds)** or **`1 Day`**.
5. Save changes. This reduces authoritative DNS query volume and enhances performance.

---

## Critical Email Preservation Guarantee (Microsoft 365 Exchange)

### Protection Rationale
The executive team relies on Microsoft 365 Outlook for all daily business operations:
- Alan Musselman (COO): `alan@ositodrone.com`
- Miguel Flores (CEO): `miguel@ositodrone.com`
- Jesus Aceves (CTO): `jesus@ositodrone.com`

Website hosting and email delivery operate on completely independent DNS record types. Web traffic uses `A` and `CNAME` records, while email delivery uses `MX`, `TXT` (SPF), and autodiscover `CNAME` records.

### Mandatory Preservation Rule
**UNDER NO CIRCUMSTANCES DELETE, MODIFY, OR OVERWRITE THE FOLLOWING 4 RECORDS IN GODADDY:**

| Record Type | Host / Name | Target / Points To | Priority | Function |
| :--- | :--- | :--- | :--- | :--- |
| **MX** | `@` | `ositodrone-com.mail.protection.outlook.com` | `0` | Directs all incoming email to Microsoft 365 Exchange |
| **TXT** | `@` | `v=spf1 include:secureserver.net -all` | — | SPF authorization allowing Outlook servers to send mail |
| **TXT** | `@` | `NETORGFT19579025.onmicrosoft.com` | — | Microsoft 365 tenant identity verification |
| **CNAME** | `autodiscover` | `autodiscover.outlook.com` | — | Automatically configures desktop/mobile Outlook clients |

By strictly modifying only the `@` A records and `www` CNAME record, **zero email downtime occurs**, and no client emails will be dropped or delayed.

---

## Emergency Rollback Plan (< 5-Minute Execution)

If an unrecoverable defect, critical network failure, or severe TLS anomaly occurs during cutover, execute this emergency rollback procedure to immediately restore the legacy GoDaddy Website Builder.

### Rollback Step 1: Execute Rollback Display Command
```bash
python 06_Scripts_and_Automation/cutover_production.py rollback
```

### Rollback Step 2: Restore GoDaddy DNS Records (< 3 Minutes)
1. In GoDaddy DNS Manager, **Delete** the 4 GitHub Pages A records (`185.199.108.153` - `185.199.111.153`).
2. Add the original **GoDaddy Website Builder (DPS) A Records**:
   - **Type**: `A` | **Host**: `@` | **Value**: `76.223.105.230` | **TTL**: `600 seconds`
   - **Type**: `A` | **Host**: `@` | **Value**: `13.248.243.5` | **TTL**: `600 seconds`
3. Edit the **`www` CNAME record**:
   - Change Value to `@` (or `ositodrone.com`).
4. Click **Save**.

### Rollback Step 3: Release Custom Domain on GitHub Pages (< 1 Minute)
From your terminal, execute:
```bash
gh api repos/AlanMusselman/ositodrone-staging/pages -X PUT -F "cname="
```
This removes `ositodrone.com` from GitHub Pages, releasing domain ownership and resetting the repository to serve exclusively on `https://alanmusselman.github.io/ositodrone-staging/`.

### Rollback Step 4: Verification
Verify that DNS resolves back to GoDaddy DPS:
```bash
python -c "import socket; print(socket.getaddrinfo('ositodrone.com', 80))"
```
Within 3 to 5 minutes, global resolvers will direct traffic back to the legacy GoDaddy Website Builder with zero data loss.

---

## Founder Step-by-Step GoDaddy Navigation Guide

A simplified visual walk-through tailored specifically for Alan, Miguel, or Jesus when logged into GoDaddy:

```
[GoDaddy Home] -> [Sign In] -> [My Account] -> [Domains / Domain Portfolio]
       │
       ▼
[Click "ositodrone.com"] -> [Select "DNS" Tab] -> [Select "DNS Records"]
       │
       ├─► [PHASE 2: T-2 HOURS]
       │     └─► Click Pencil on @ A-Records -> Change TTL to "1/2 Hour" -> Save.
       │
       ├─► [PHASE 3: LIVE SWITCH]
       │     ├─► Delete A-records (76.223.105.230, 13.248.243.5)
       │     ├─► Add 4 A-records (@ -> 185.199.108.153, .109.153, .110.153, .111.153)
       │     └─► Update CNAME (www -> alanmusselman.github.io)
       │
       └─► [CRITICAL CHECK]
             └─► Confirm MX record (ositodrone-com.mail.protection.outlook.com) IS UNTOUCHED!
```

### Direct GoDaddy Navigation Links:
- Domain Portfolio: [https://dcc.godaddy.com/control/portfolio](https://dcc.godaddy.com/control/portfolio)
- Direct DNS Manager for `ositodrone.com`: [https://dcc.godaddy.com/manage/ositodrone.com/dns](https://dcc.godaddy.com/manage/ositodrone.com/dns)

---

## Technical Support & Escalation Contacts

- **Operations & Systems**: Alan Musselman (`alan@ositodrone.com`)
- **Executive Direction & Approvals**: Miguel Flores (`miguel@ositodrone.com`)
- **Avionics & Engineering**: Jesus Aceves (`jesus@ositodrone.com`)
- **Emergency Telephone Hotline**: Alan Musselman / Miguel Flores internal mobile lines.
- **Hosting Infrastructure**: GitHub Status ([https://www.githubstatus.com/](https://www.githubstatus.com/)) | GoDaddy System Status ([https://www.godaddy.com/help/system-status-2808](https://www.godaddy.com/help/system-status-2808))
