# Welcome, Miguel — Your `ositodrone` Sales Command Center

Unzip this `ositodrone` folder directly onto your Desktop or into your `Documents` folder, then **right-click the `sales` folder and select "Pin to Quick Access"**.

---

## Folder-by-Folder Quick Guide (In Exact Daily Order)

### 1. `sales/01_Daily_Action_and_Scripts/` — **OPEN FIRST AT 8:30 AM**
- **`Miguel_CEO_5_Day_Action_Orders.md`**: Your day-by-day checklist, 15 phone numbers, word-for-word 25-second phone scripts, and 2-stop afternoon walk-in clusters.
- **`Osito_Team_Operating_Rhythm_and_Scorecard.md`**: Our 8:30 AM 15-minute standup agenda, 5-minute inbound phone SLA, and your 3 weekly KPI numbers.

### 2. `sales/02_Ready_To_Send_Emails/` — **OPEN AT 9:00 AM (TAKES 60 SECONDS)**
- Contains all **10 of your week's pre-written Outlook `.eml` emails** with our PDF one-pagers already attached.
- **How to use:** Double-click today's 2 `.eml` files, click **Send** in Outlook, and drag the sent `.eml` file into the **`Sent_Archive/`** folder so you always see what's left for the week.

### 3. `sales/03_Leads_and_Account_Playbooks/` — **DECISION-MAKER DOSSIERS & CSV TRACKERS**
- **`Team_Miguel_CEO_Account_Playbook.md`**: Deep-dive profiles, decision-maker names, and custom opening hooks for your 17 flagship SF schools, camps, and corporate venues.
- **`Osito_November_Fast_Cash_Jobs_Tracker.csv`** & **`Osito_SF_Sales_Leads_Tracker.csv`**: Master spreadsheets to log call outcomes and booked demos.

### 4. `sales/04_Flyers_and_Print_OnePagers/` — **PRINT & CARRY ON 1:30 PM WALK-INS**
- **`one pager Osito services.pdf`**: Commercial aerials, FPV real estate, roof audits & corporate events.
- **`Osito Academy.pdf`**: Youth STEM Drone & Soldering Academy brochure for schools and camps.
- **`birthday osito drone events.pdf`**: Weekend birthday party & pop-up flyer.

### 5. `sales/05_Closing_Docs_Rates_and_Waivers/` — **WHEN A CLIENT SAYS "YES"**
- **`Osito_2027_Commercial_Rate_Card_and_Order_Form.html`**: Double-click to open in any browser (or print) for on-the-spot booking signatures.
- **`Osito_Participant_Safety_Waiver.html`**: Participant waiver required before live flights.
- Save signed copies/photos inside **`Signed_Contracts_and_Waivers/`**.

### 6. `sales/06_Interactive_Demos_and_Estimators/` — **LIVE TABLET / LAPTOP WOW DEMOS**
- **`OSITO_Kids_Garage_Loadout_Menu.html`**: Interactive offline menu showing 2,500 3D-printed parts and 550,069,884 drone combinations.
- **`KODIAK75_3D_Viewer.html`**: Interactive 3D drone hardware viewer (works 100% offline).
- **`Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html`**: Interactive unit economics and pricing calculator.
