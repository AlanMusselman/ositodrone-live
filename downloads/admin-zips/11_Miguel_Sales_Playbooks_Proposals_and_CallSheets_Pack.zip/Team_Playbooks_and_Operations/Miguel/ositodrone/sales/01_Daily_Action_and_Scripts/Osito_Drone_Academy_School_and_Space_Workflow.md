# Osito Drone Academy — Complete Workflow for Running Events in Schools & Community Spaces

**Focus:** 100% **Osito Drone Academy** (Youth STEM Enrichment, School Break Camps, In-School Assemblies & Community Space Events)  
**Hardware Used Today:** Commercial off-the-shelf indoor ducted micro-drones (AcroBee / Tiny Whoop class with full prop guards), 4-Pilot Tablet Flight Sim Pod (4× ANTEMPER 10.1" Tablets + 4× RadioMaster T8L controllers in an Apache 4800 / Pelican 1550 hard case), pop-up netted Hover Pods, FPV goggles + soft indoor LED gates, and a **Staff-Only Repair & Battery Pit-Crew Station**.  
*(Note: No unbuilt R&D or future 3D-printed drone projects are pitched, and students never handle hot soldering irons—all repairs are handled by Osito staff at the Pit-Crew Station.)*

---

## 1. The Core Product: 3 Student Flight Stations + 1 Staff Pit-Crew Station

Every school classroom, multipurpose room, recreation center, or community space event runs on this **3+1 Station Architecture**. Look at why this is the ultimate layout for a team of 3 co-founders:
1. **1 Co-Founder per Student Station (Zero Unsupervised Kids):** Each of the 3 student stations has its own dedicated co-founder flight coach (`1:4` ratio, **12 students per session** split into 3 squads of 4).
2. **Zero Student Safety Risk from Hot Tools:** Station 4 (Soldering, Repairs & Battery Charging) is **for Osito Staff Only**, positioned right next to Jesus at the Simulator desk so Jesus can swap batteries or fix a bent prop in 30 seconds while students watch the "Pit Crew" in action safely from outside the bench.
3. **We only need 4–6 flying drones in the air at any moment** to keep 12 students 100% engaged.

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    SCHOOL / COMMUNITY ROOM FLOOR PLAN                   │
│             (12 Students = 3 Squads of 4 Rotating Every 15 Mins)        │
├───────────────────────────────────┬─────────────────────────────────────┤
│ 🛠 STATION 4: STAFF REPAIR PIT CREW│ 💻 STATION 1: 4-TABLET SIMULATOR POD │
│    (OSITO STAFF ONLY — NO KIDS)   │    (Student Rotation 1 — 4 Pilots)  │
│ • Battery charging (6-port 1S     │ • 4× 10.1" Tablets + T8L controllers │
│   chargers + fireproof Bat-Safe)  │ • Risk-free "crash & restart"       │
│ • Staff soldering, hot-glue fixes,│   training to build stick muscle    │
│   prop/frame swaps & spare drones │   memory before real flight         │
│                                   │                                     │
│ 👤 Staff Tech: JESUS (CTO)        │ 👤 Coached by: JESUS (CTO)          │
├───────────────────────────────────┼─────────────────────────────────────┤
│ 🎯 STATION 2: NETTED HOVER PODS   │ 🥽 STATION 3: FPV OBSTACLE COURSE   │
│    (Student Rotation 2 — 4 Pilots)│    (Student Rotation 3 — 4 Pilots)  │
│ • 4 pop-up netted hover enclosures│ • Soft LED gates & hoops            │
│ • Students learn manual throttle  │ • Students wear real FPV goggles    │
│   control & stable hovering       │   ("inside the cockpit") with a     │
│   inside 100% contained nets      │   coach spotting right beside them  │
│                                   │                                     │
│ 👤 Coached by: MIGUEL (CEO)       │ 👤 Coached by: ALAN (COO)           │
└───────────────────────────────────┴─────────────────────────────────────┘
```

### Exact Co-Founder Floor Roles During Every Event:
- **Jesus Aceves (CTO) — Station 1 (Simulator Coach) + Station 4 (Staff Repair & Battery Pit Crew):**
  - Coaches the 4 students on the **4-Pilot Tablet Flight Sim Pod** (`Station 1`, `4× ANTEMPER 10.1" Tablets + 4× RadioMaster T8L controllers`).
  - Because the simulators sit right beside the **Staff Pit-Crew Desk (`Station 4`)**, Jesus keeps the 6-port `1S` battery chargers cycling continuously, hands fresh battery packs to Miguel and Alan between rotations, and performs any on-the-fly prop swaps, frame swaps, or soldering repairs so no student ever loses flight time to a broken drone.
- **Miguel Flores (CEO) — Station 2 (Netted Hover Pod Coach & School Host):**
  - Coaches the 4 students at the pop-up netted Hover Pods (`Station 2`), teaching manual throttle control, stable hovering, and line-of-sight orientation while welcoming school administrators/parents observing the room.
- **Alan Musselman (COO) — Station 3 (FPV Obstacle Course Coach & Operations Lead):**
  - Coaches the 4 students flying with First-Person View (FPV) goggles through the soft LED obstacle gates (`Station 3`), calls the 15-minute station rotations, collects signed waivers (`Osito_Participant_Safety_Waiver.html`), and greets parents with flyers at pickup.

---

## 2. Step-by-Step Event Execution Workflow (Pre-Arrival → Setup → Run → Pack-Out)

### Phase 1: Pre-Event Packing & Load-Out (4 Plastic Tote Bins + Pop-Up Bags)
Before leaving for any school or event space, pack the **4 Standardized Bins**:
- **Bin 1 (Station 4 — Staff-Only Repair & Battery Pit Crew):** 30× `1S` micro batteries inside a fireproof **Bat-Safe** box, 2× 6-port `1S` chargers, 2 power strips + extension cord, 4 backup ready-to-fly AcroBee/Whoop drones, spare props/frames/motors, mini screwdrivers, prop puller, low-temp hot glue gun, and staff soldering iron for quick field repairs.
- **Bin 2 (Station 1 — 4-Pilot Tablet Flight Sim Pod):** `Apache 4800 / Pelican 1550` hard case containing `4× ANTEMPER 10.1" Tablets` (`Acrobee65 Flight Simulator v0.5 (SF Tour Edition)`), `4× RadioMaster T8L` controllers, and 4-way USB-C GaN charging harness.
- **Bin 3 (Stations 2 & 3 — Active Student Flight Fleet):** 6 primary ducted indoor micro-drones (4 for Hover Pods + 2 for FPV Course), 6 student radio controllers, 4 FPV goggles + 1 spectator monitor (so waiting kids/parents can watch the live cockpit video feed).
- **Bin 4 (Course Enclosures & Admin Kit):** 4 pop-up netted Hover Pods (folded flat), 4–6 soft pop-up LED gates/hoops, clipboard with printed **Participant Safety Waivers**, and 20 printed copies of the **Osito Drone Academy One-Pager**.

---

### Phase 2: On-Site Arrival & 30-Minute Setup (`T-30 mins` to `T-0`)
1. **`T-30 mins` — Check-In & Room Zoning (5 mins):**
   - Sign in at the school front office or venue desk.
   - Place **Station 1 (4-Pilot Tablet Flight Sim Pod)** and **Station 4 (Staff Repair & Battery Pit Desk)** along the wall with AC power outlets (keeping the Staff Repair Desk behind the simulator table so students cannot reach staff tools or chargers).
   - Designate the open floor area for **Station 2 (Hover Pods)** and **Station 3 (FPV Obstacle Course)**.
2. **`T-25 mins` — Pop Up the Enclosures & Gates (10 mins):**
   - **Miguel:** Unfold the 4 netted Hover Pods in a neat row (`Station 2`).
   - **Alan:** Pop up the soft neon LED gates and hoops (`Station 3`) and set up the check-in/waiver clipboard by the door.
   - **Jesus:** Open the 4-Pilot Tablet Flight Sim Pod (`Station 1`), plug in the 6-port battery chargers at the Staff Pit Desk (`Station 4`), and stage 2 backup drones ready to swap in instantly if a student drone takes a hard hit.
3. **`T-15 mins` — Pre-Flight Radio & Video Check (10 mins):**
   - Power on the 4 Hover Pod drones and 2 FPV course drones to verify clean FPV video channels and transmitter binding.
4. **`T-5 mins` — Welcome & 3-Squad Split (5 mins):**
   - Greet students at the door, verify waivers, and divide students into **3 equal squads of 4 students** (*Squad Alpha, Squad Bravo, Squad Charlie*).

---

### Phase 3: The 60-Minute or 90-Minute Live Class Run-of-Show

| Time Block (60-Min Class) | Time Block (90-Min Workshop) | Activity | What Happens on the Floor |
| :--- | :--- | :--- | :--- |
| **Min 00–06** | **Min 00–08** | **Flight Briefing & Pit-Crew Intro** | Miguel welcomes the group. 3 Golden Rules: (1) *Disarm immediately when landing*, (2) *Stay behind the flight line*, (3) *If a prop pops off, hand your drone to Jesus at the Staff Pit Crew Desk for an instant pit-stop swap!* Split into 3 squads. |
| **Min 06–21** *(15 mins)* | **Min 08–31** *(23 mins)* | **Rotation 1** | • **Squad A** @ Station 1 (Simulators — *Jesus*)<br>• **Squad B** @ Station 2 (Hover Pods — *Miguel*)<br>• **Squad C** @ Station 3 (FPV Goggles — *Alan*)<br>• *Staff Station 4 (Jesus):* Charging packs & hot-swapping any bumped drone in <15 seconds. |
| **Min 21–36** *(15 mins)* | **Min 31–54** *(23 mins)* | **Rotation 2** *(Rotate Clockwise)* | Alan calls *"Disarm drones & rotate!"* Jesus hands fresh `1S` batteries from the Staff Pit Desk to Miguel and Alan (takes 45 seconds) and puts depleted packs onto the 6-port chargers. |
| **Min 36–51** *(15 mins)* | **Min 54–77** *(23 mins)* | **Rotation 3** *(Final Station)* | Every student has now completed all 3 progressive flight stages: **Simulator → Netted Hover Pod → FPV Goggle Obstacle Course!** |
| **Min 51–60** *(9 mins)* | **Min 77–90** *(13 mins)* | **Pit-Crew Show-and-Tell + Final Relay Race** | Jesus does a 3-minute live "Under the Hood" Pit-Crew demo holding up an open micro-drone to show the camera, flight controller, and motors; followed by a 5-minute Top Pilot FPV Relay Race & handing out **Osito Drone Academy flyers** at parent pickup! |

---

### Phase 4: 15-Minute Pack-Out & Post-Event Conversion (`T+0` to `T+15 mins`)
1. **Parent Pickup Window (First 5 mins after class):**
   - While Jesus and Miguel fold the Hover Pods and pack the 4-Tablet Sim Pod and pit-crew bench into the cases/bins, **Alan stands at the pickup door with printed flyers** to greet parents:
   - *"Your kid just went from the simulator to flying through obstacle gates with FPV goggles! We also do weekend birthday parties ($200 60-Min / $299 90-Min Promo / $400 2-Hr) and holiday break camps—here is our flyer."*
2. **School / Venue Director Check-Out (2 mins before walking out):**
   - **Miguel** stops by the Extended Day Director or Venue Manager's desk:
   - *"The kids had an awesome session today, our staff Pit Crew kept all drones running nonstop, and the room is spotless. Let's get our next 8-week session or camp dates on your calendar."*
