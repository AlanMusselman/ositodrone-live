# MIGUEL FLORES — CEO 5-DAY ACTION ORDERS (ZERO PREP, ZERO FLUFF)

**TO:** **Miguel Flores**, CEO & Co-Founder (`miguel@ositodrone.com` | `415.571.6614`)  
**FROM:** **Alan Musselman** (COO, `415.810.4158`) & **Jesus Aceves** (CTO, `415.269.1206`)  
**MISSION:** Close immediate November 2026 fast cash (`$5,000–$12,000`) & lock in 2026/2027 SF School & Corporate contracts.

---

## 🚨 RULE #1 FOR MIGUEL (9:00 AM – 3:30 PM)
**ZERO CAD. ZERO LOGO TWEAKING. ZERO SPREADSHEET PLANNING BETWEEN 9:00 AM AND 3:30 PM.**  
As CEO, your **#1 job for the next 14 days** is putting the physical `39.5g` **`OSITO CUB-75`** drone and printed copies of **`one pager Osito services.pdf`** into the hands of **20 San Francisco decision-makers**.

We eliminated **100% of your prep work**:
- **All 10 of your week's emails are already written, addressed, and have the PDF attached** inside `c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\05_Outbox_Emails\Miguel_CEO_Ready_To_Send_Emails\`. You literally **double-click the `.eml` file and click Send**.
- **All 15 phone numbers and 25-second word-for-word scripts** are printed below.
- **All 10 afternoon walk-ins** are grouped into tight 2-stop neighborhood clusters so you park once and walk.

---

## ⏱️ YOUR DAILY CLOCK (MONDAY TO FRIDAY)

| Time Block | Activity | Exact Execution Rule |
| :--- | :--- | :--- |
| **8:30 AM – 8:45 AM** | **15-Min Co-Founder Standup** | Quick call with Alan (`415.810.4158`) & Jesus (`415.269.1206`). Confirm yesterday's walk-ins and which 10-min tabletop demos Jesus is joining today. |
| **9:00 AM – 10:30 AM** | **The Power 90 (2 Clicks + 3 Calls)** | 1. Open `05_Outbox_Emails\Miguel_CEO_Ready_To_Send_Emails\`, **double-click today's 2 `.eml` files**, and hit **Send** (takes 60 seconds).<br>2. **Dial today's 3 phone numbers** back-to-back using the 25-second script below. |
| **10:30 AM – 1:30 PM** | **Follow-Ups, Site Visits & Lunch** | Run scheduled 10-min tabletop hover demos with Jesus or commercial drone shoots. |
| **1:30 PM – 3:30 PM** | **The Neighborhood Walk-In Blitz (2 Stops)** | Carry **1 physical `CUB-75` drone in your hand** (no box—hold it so receptionists see the 3D-printed finger cage immediately) + **5 printed copies of `one pager Osito services.pdf`**. Walk into today's 2 nearby SF locations. |

---

## 📞 THE 25-SECOND UNIVERSAL PHONE SCRIPTS (READ WORD-FOR-WORD)

### Script A — For Schools & Holiday Camps (Days 1, 2, 3, 5)
> *"Hi [Name], this is Miguel Flores, CEO of Osito Drone Services here in San Francisco. I just sent you a quick note with our one-pager. We engineer and 3D-print a 39.5-gram, 100% finger-safe indoor training drone right here in the city and run turnkey 1-to-4 Youth Flight & Soldering Labs. I'm going to be in [Neighborhood] this week with our CTO Jesus—can we swing by for literally 10 minutes so you can hold the drone and test the safety cage at your desk?"*

### Script B — For Commercial Real Estate, GCs, HOAs & Event Venues (Days 1, 4)
> *"Hi, this is Miguel Flores, CEO of Osito Drone Services here in SF. We're a three-engineer FAA Part 107 drone team based in the Mission. For November, we're offering [a free 30-second Indoor FPV fly-through on one active listing / a $395 Pre-Winter Roof & Gutter Drone Audit / a $395 Lender-Draw Progress Shoot / our 8.4x8.4 ft netted Drone Combat Arena for corporate holiday parties]. I just emailed over our one-pager—who is the best person on your team to look at a 60-second sample reel today?"*

---

## 📅 DAY-BY-DAY EXECUTION ORDERS (DAYS 1 – 5)

---

### DAY 1: MISSION CORRIDOR + FAST-CASH LAUNCH
**Neighborhood Focus:** *Mission St (`2501–2949 Mission`) & Dolores/Valencia (`333 Dolores`)*

#### 1. 9:00 AM — Double-Click & Send These 2 `.eml` Files:
- [ ] `01_Sports_Basement_Bryant_Free_Room_Nov14.eml` → Reserves "The Treeline" free 1,750 sq ft room at 1590 Bryant St for Sat Nov 14 & Nov 21 (`$1,020` gross / 2-hr pop-up).
- [ ] `04_Vanguard_Properties_Mission_HQ_FPV_Spec.eml` → Pitches Vanguard Mission HQ (`2501 Mission St`) on 1 free 30-sec Indoor FPV spec shoot to unlock `$450–$850` listings.

#### 2. 9:10 AM – 10:30 AM — Dial These 3 Numbers:
1. **Sports Basement Bryant St ("The Treeline" Community Room):** Call **`(415) 575-3001`** → Ask for Community/Events Coordinator to confirm Saturday Nov 14 & Nov 21 (10:00 AM – 12:00 PM) room hold.
2. **Children's Day School (CDS — 333 Dolores St):** Call **`(415) 861-5432`** → Ask for **Tanner Taylor** (Extended Program Director) or **Charlotte Doughty** (`$5,600/sem` Extended Program).
3. **Alta Vista School (AVS Middle — 2558 Mission St):** Call **`(415) 510-8492`** → Ask for **Rob Cousins** (Head of School) or **BookEnds Extended Day Director** (`$5,600/campus` STEAM lab).

#### 3. 1:30 PM – 3:30 PM — Mission Corridor Walk-In Blitz (Park Once near 21st & Mission):
- **Walk-In #1: Vanguard Properties SF HQ — `2501 Mission St` (at 21st St)**
  - **Carry:** Tablet/Phone with FPV reel + `one pager Osito services.pdf`.
  - **Ask For:** Listing Marketing Director or Office Manager. Offer 1 free 30-second Indoor Cinewhoop FPV fly-through on a November listing.
  - *(Bonus 4 blocks south at `2949 Mission St`: Drop a one-pager at **G&M Builders GC**, `(415) 571-0823`, for `$395` remodel/progress shoots!)*
- **Walk-In #2: Children's Day School (CDS) / Alta Vista Middle — `333 Dolores St` & `2558 Mission St`**
  - **Carry:** Physical `CUB-75` drone in hand + `Osito Academy.pdf` / `one pager Osito services.pdf`.
  - **Action:** Show front desk/Tanner Taylor the `39.5g` enclosed finger cage; leave 1-pager and lock in a 10-minute tabletop hover demo with Jesus.

---

### DAY 2: PRESIDIO + NOVEMBER HOLIDAY CAMPS
**Neighborhood Focus:** *The Presidio (`682 Schofield Rd` & `610 Old Mason St`)*

#### 1. 9:00 AM — Double-Click & Send These 2 `.eml` Files:
- [ ] `02_JCCSF_Mitch_Sanchez_Nov11_Camp_Block.eml` → Pitches **Mitch Sanchez** (`msanchez@jccsf.org`) & **Bryan Wells** (`bwells@jccsf.org`) on `$960` Nov 11 Veterans Day & Nov 23–25 Vacation Camp rotations.
- [ ] `03_Steve_and_Kates_Camp_Thanksgiving_Guest.eml` → Pitches **Steve & Kate's Camp SF** (`sf.trips@steveandkate.com`) on a `$600–$960` Thanksgiving Break (Nov 23–25) Special Guest Drone Block.

#### 2. 9:10 AM – 10:30 AM — Dial These 3 Numbers:
1. **JCCSF Camp & Youth Dept (`3200 California St`):** Call **`(415) 292-1200`** → Ask for **Mitch Sanchez** (Camp Manager) or **Bryan Wells** (Dir. of Youth & Family) for Nov 11 / Nov 23–25 (`$960` half-day) + Winter After-School (`$5,600`).
2. **Steve & Kate's Camp SF:** Call **`(415) 523-2204`** → Follow up on `sf.trips@steveandkate.com` email for Nov 23–25 Thanksgiving Special Guest booking (`$600–$960`).
3. **Brightworks School (`682 Schofield Rd`, Presidio):** Call **`(415) 701-8700`** → Ask for **Lisa Nowell** (Dir. of Community Growth) or **Michlene Cotter** (Head of School) to let them know you and Jesus are in the Presidio this afternoon.

#### 3. 1:30 PM – 3:30 PM — Presidio Walk-In Blitz (Bring Jesus if Available!):
- **Walk-In #1: Brightworks School + Tinkering School — `682 Schofield Rd, Presidio`** *(2 high-value accounts in the exact same Presidio warehouse!)*
  - **Carry:** Physical `CUB-75` drone + spare 3D-printed PETG-CF/TPU frame + `Osito Academy.pdf`.
  - **Ask For:** **Lisa Nowell / Michlene Cotter** (Brightworks) and **Gever Tulley / Camp Director** (Tinkering School). Show how kids solder and 3D-print their own `39.5g` airframes (`$5,600–$14,000` combined potential).
- **Walk-In #2: Sports Basement Presidio — `610 Old Mason St, Presidio`**
  - **Carry:** Physical `CUB-75` drone + `one pager Osito services.pdf`.
  - **Ask For:** Store Community Manager to confirm free reservation of **"The Sign Room" / "The Dairy"** community room for Saturday Direct-to-Parent `$85/ticket` pop-ups (`$1,020` gross per 2-hr session).

---

### DAY 3: HAYES VALLEY / NOPA INDEPENDENT SCHOOL BLITZ
**Neighborhood Focus:** *NOPA / Hayes Valley (`350 Masonic Ave`, `735 Fell St`, `150 Oak St`)*

#### 1. 9:00 AM — Double-Click & Send These 2 `.eml` Files:
- [ ] `07_Childrens_Day_School_Tanner_Taylor_Demo.eml` → Formal follow-up/booking with **Tanner Taylor** (`tannert@cds-sf.org`) for the 10-min tabletop `CUB-75` demo at `333 Dolores St`.
- [ ] `09_SF_Day_School_Nicole_Lane_Demo.eml` → Pitches **Nicole Lane** (`nlane@sfday.org`, Dir. of Afterschool Programs / AEP) at SF Day School (`350 Masonic Ave`).

#### 2. 9:10 AM – 10:30 AM — Dial These 3 Numbers:
1. **San Francisco Day School (`350 Masonic Ave`):** Call **`(415) 931-2422`** → Ask for **Nicole Lane** (Director of Afterschool Programs / AEP) (`$5,600` AEP Lab + `$6,800` Summer Cohort).
2. **San Francisco Schoolhouse (`735 Fell St`):** Call **`(415) 966-2252`** → Ask for **Patrick Ardinger** (Dir. of Middle School) or **Jina Kim** (Head of School) (`$4,200` 8-Wk Flight Lab).
3. **The International School of SF (`150 Oak St`):** Call **`(415) 558-2000`** → Ask for **Sean Donaldson** (Extended Care & Vacation Camps Director) or **Daisy Estrada** (`$12,400–$19,200/yr` Extended Care + Vacation Camps).

#### 3. 1:30 PM – 3:30 PM — Hayes Valley / NOPA Walk-In Blitz:
- **Walk-In #1: San Francisco Day School (`350 Masonic Ave`) OR SF Schoolhouse (`735 Fell St`)**
  - **Carry:** Physical `CUB-75` drone + `Osito Academy.pdf`.
  - **Action:** Hand-deliver attention **Nicole Lane** (350 Masonic) and **Patrick Ardinger** (735 Fell, 4 mins down Fell St). Have front desk coordinator press a finger against the `CUB-75` top/bottom safety grille.
- **Walk-In #2: The International School of SF — `150 Oak St` (Hayes Valley)**
  - **Carry:** Physical `CUB-75` drone + `Osito Academy.pdf`.
  - **Ask For:** **Sean Donaldson** or **Daisy Estrada** (Extended Care Office). Pitch both the weekly 90-minute Extended Care Flight Lab AND 5-day February/April/Summer Vacation Camps.

---

### DAY 4: SOMA / DOGPATCH COMMERCIAL & CORPORATE CASH BLITZ
**Neighborhood Focus:** *SoMa / Potrero / Dogpatch (`160 S. Van Ness`, `1555 Mariposa`, `900 Marin St`, `3450 Third St`)*

#### 1. 9:00 AM — Double-Click & Send These 2 `.eml` Files:
- [ ] `05_Build_Group_SF_Construction_Trial.eml` → Pitches **Build Group Inc.** (`info@buildgc.com`) on a `$395` November Lender-Draw Orthomosaic & Progress Trial Shoot.
- [ ] `06_CitiScape_HOA_PreWinter_Roof_Audit.eml` → Pitches **CitiScape Property Management** (`info@citiscapesf.com`) on a `$395` Pre-Winter Storm HOA Roof & Gutter Drone Visual Audit.

#### 2. 9:10 AM – 10:30 AM — Dial These 3 Numbers:
1. **Build Group Inc. (`160 S. Van Ness Ave`):** Call **`(415) 367-9399`** → Ask for Project Controls / Estimating or Active SF Site Superintendent to book a `$395` November Trial Progress Shoot.
2. **CitiScape Property Management (`3450 Third St`):** Call **`(415) 401-2000`** → Ask for Director of HOA Management to book a `$395` Pre-Winter Roof & Scupper Visual Audit before November rains.
3. **Malin Giddings Team / Compass SF (`891 Beach St`):** Call **`(415) 531-5033`** → Pitch a complimentary 30-sec Indoor-to-Outdoor FPV spec fly-through on one luxury listing to convert into `$500–$850` shoots.

#### 3. 1:30 PM – 3:30 PM — SoMa / Dogpatch Walk-In Blitz:
- **Walk-In #1: Build Group Inc. HQ — `160 S. Van Ness Ave` (SoMa)** *(or stop at **Live Oak School**, `1555 Mariposa St`, on the way to Dogpatch)*
  - **Carry:** `one pager Osito services.pdf` + Part 107 card.
  - **Ask For:** Reception / Project Management Desk. Leave 2 copies of the Osito Commercial One-Pager offering `$395` same-week orthomosaic & lender-draw progress aerials.
- **Walk-In #2: The Midway SF / Non Plus Ultra (`900 Marin St`) + CitiScape (`3450 Third St`, 2 blocks away)**
  - **Carry:** Physical `CUB-75` / `SHARD-75` drone + `one pager Osito services.pdf`.
  - **Ask For:** Private Events Manager at **The Midway (`900 Marin St`)** to show how our `8.4×8.4 ft` netted `SHARD-75` Drone Combat Arena sets up inside *Ride* or *Gods & Monsters* for `$1,800–$3,200` November/December tech holiday parties. Then drop a commercial roof audit flyer 2 blocks over at **CitiScape (`3450 Third St, Suite 1A`)**.

---

### DAY 5: LAUREL HEIGHTS / PAC HEIGHTS INSTITUTIONAL CLOSER
**Neighborhood Focus:** *Laurel Heights / Presidio Heights / Pac Heights (`3200 California St`, `3839 Washington St`, `2750 Jackson St`)*

#### 1. 9:00 AM — Double-Click & Send These 2 `.eml` Files:
- [ ] `08_Live_Oak_School_Dorothy_Martinez_Demo.eml` → Pitches **Dorothy Martinez** (`dorothy_martinez@liveoaksf.org`, Dir. of Extended Day & Summer Oaks) at Live Oak School (`$12,400–$18,000/yr`).
- [ ] `10_Non_Plus_Ultra_The_Midway_Holiday_Events.eml` → Pitches **Non Plus Ultra / The Midway** (`events@npu.co`) on adding the `8.4×8.4 ft` `SHARD-75` Combat Arena to November/December corporate holiday buyouts.

#### 2. 9:10 AM – 10:30 AM — Dial These 3 Numbers:
1. **Live Oak School (`1555 Mariposa St`):** Call **`(415) 861-8820`** → Ask for **Dorothy Martinez** (Director of Extended Day & Summer Oaks Camp) to lock in a 10-min tabletop hover demo (`$5,600` Extended Day + `$6,800` Summer Oaks).
2. **Town School for Boys (`2750 Jackson St`):** Call **`(415) 921-3747`** → Ask for **LEAP Extended Day Director** or **Lorri Hamilton Durbin** (`$5,600` LEAP Drone Racing & Soldering Lab).
3. **Non Plus Ultra / The Midway Corporate Events (`900 Marin St`):** Call **`(415) 608-2220`** (or Midway line `(415) 325-2620`) → Follow up on `events@npu.co` email for Q4 tech holiday party activations (`$1,800–$3,200/event`).

#### 3. 1:30 PM – 3:30 PM — Laurel Heights / Pac Heights Walk-In Blitz:
- **Walk-In #1: Jewish Community Center of SF (JCCSF) — `3200 California St` (at Presidio Ave)**
  - **Carry:** Physical `CUB-75` drone + `Osito Academy.pdf` + `one pager Osito services.pdf`.
  - **Ask For:** **Mitch Sanchez** (Camp Manager) or **Bryan Wells** (Director of Youth & Family). Show the `39.5g` `CUB-75` cage in person to close (a) Nov 11 / Nov 23–25 Vacation Days (`$960`), (b) Winter/Spring After-School (`$5,600`), and (c) JCCSF Summer Camp (`$10,800`).
- **Walk-In #2: Town School for Boys (`2750 Jackson St`) OR Presidio Hill School (`3839 Washington St`, 3 blocks from JCCSF)**
  - **Carry:** Physical `CUB-75` drone + `Osito Academy.pdf`.
  - **Ask For:** **LEAP Extended Day Office** at Town School (`2750 Jackson St`) or **Eli Barragan** ("The Neighborhood" Supervisor, `(415) 213-8630`) at Presidio Hill (`3839 Washington St`).

---

## ✅ MIGUEL'S 5-DAY SCOREBOARD (CHECK OFF AS YOU GO)

| Metric | 5-Day Target | Completed |
| :--- | :--- | :--- |
| **Pre-Built `.eml` Emails Double-Clicked & Sent** | **10 / 10** | `[ ] 1  [ ] 2  [ ] 3  [ ] 4  [ ] 5  [ ] 6  [ ] 7  [ ] 8  [ ] 9  [ ] 10` |
| **Morning Power 90 Phone Dials Completed** | **15 / 15** | `[ ] Day 1 (3)  [ ] Day 2 (3)  [ ] Day 3 (3)  [ ] Day 4 (3)  [ ] Day 5 (3)` |
| **Physical `CUB-75` + One-Pager Walk-Ins** | **10 / 10** | `[ ] Day 1 (2)  [ ] Day 2 (2)  [ ] Day 3 (2)  [ ] Day 4 (2)  [ ] Day 5 (2)` |
| **10-Min Tabletop Demos Booked with Jesus** | **4+ Demos** | `[ ] Demo 1     [ ] Demo 2     [ ] Demo 3     [ ] Demo 4` |
| **November Fast-Cash Bookings Closed** | **2+ Bookings** | `[ ] Booking 1 ($______)       [ ] Booking 2 ($______)` |
