# Osito Drone Services — Team Operating Rhythm, SLA & Weekly KPI Scorecard

**Effective Date:** Friday, October 30, 2026 (November Fast-Cash Blitz & 2027 Lock-In Window)  
**Founding Strike Team:**
- **Miguel Flores — CEO & Co-Founder** (`miguel@ositodrone.com` | `415-571-6614`) — *Outbound Sales Leader: Schools, Break Camps, Luxury Real Estate Brokerages & SF General Contractors*
- **Alan Musselman — COO & Co-Founder** (`alan@ositodrone.com` | `415-810-4158`) — *Commercial Engine, Pricing, Contracts/COIs, Breweries, Q4 Corporate Venues & Roof/Solar Inspections*
- **Jesus Aceves — CTO & Co-Founder** (`jesus@ositodrone.com` | `415-269-1206`) — *Fleet Readiness, On-Demand Dispatch, Real Estate Media FPV Subcontracting, Makerspaces & Live Hardware Demo Closer*

---

## 1. Honest Team Diagnosis: Where We Were Falling Short & How We Fix It Today

Alan asked the critical question: ***"Determine where we are not as a team. Miguel needs direction to get us going."***

Here is the candid diagnosis of why Osito has world-class hardware (`CUB-75` and `SHARD-75`), polished brochures, and 65+ verified leads—yet had `$0` in closed November revenue prior to today:

1. **Planning Without a Daily Outbound Scoreboard:** We built engineering CAD files, flight simulators, and master lead trackers, but we did **not** enforce a daily 9:00 AM–11:30 AM outbound call/walk-in block where each founder is accountable for 5 live conversations per day.
2. **Ambiguity for Miguel (CEO):** Giving a CEO a 65-row spreadsheet without a daily checklist creates paralysis. Miguel is at his best when he has **4 specific phone calls every morning at 9:30 AM** and **1 specific neighborhood walk-in corridor every afternoon at 1:30 PM** with printed flyers in hand.
3. **No Shared Inbound SLA on `415-269-1206` and `info@ositodrone.com`:** All printed flyers and commercial playbooks route inbound leads to `(415) 269-1206` (Jesus's cell / main Osito dispatch line) and `info@ositodrone.com`. Without a strict 5-minute callback rule and a 3-way Founder Group Text, warm leads go cold before anyone quotes them.
4. **Missing Point-of-Sale Closing Docs:** Before today, if a roofer, brewery manager, or school director said *"Yes, let's do it,"* we didn't have a 1-page signable **Commercial Rate Card / Order Form** or a **Participant Safety Waiver** ready on a clipboard. Now we have both.

---

## 2. Non-Negotiable Rule #1: Inbound Phone (`415-269-1206`) & Email (`info@ositodrone.com`) SLA

Every flyer, `.eml` signature, and marketplace listing points to **`(415) 269-1206`**, **`(415) 810-4158`**, **`(415) 571-6614`**, and **`info@ositodrone.com`**. We treat every inbound ring or email like a `$1,000` bill on the sidewalk:

| Channel | Primary Owner | Backup Owner (If Primary Is Driving/Flying) | Mandatory Response SLA | Standard Action Protocol |
| :--- | :--- | :--- | :--- | :--- |
| **Main Dispatch Line:** `(415) 269-1206` | **Jesus Aceves (CTO)** | **Alan Musselman (COO)** *(via conditional call-forward after 4 rings)* | **Answer Live** (or return missed call/text within **5 minutes**) | Answer every unknown `415`/`650`/`510` call with: *"Osito Drone Services, this is Jesus, how can I help you?"* If missed, immediately text back: *"Hi, this is Osito Drone Services in SF—just saw your call! How can we help?"* and drop a screenshot in the **Founder 3-Way SMS Group**. |
| **COO / Venue & Roof Line:** `(415) 810-4158` | **Alan Musselman (COO)** | **Miguel Flores (CEO)** | **Answer Live / 5-Min Callback** | Handles all Brewery Pop-Up approvals, Corporate Holiday quotes, Roofer trials, and instant COI/Invoice links. |
| **CEO / School & GC Line:** `(415) 571-6614` | **Miguel Flores (CEO)** | **Alan Musselman (COO)** | **Answer Live / 5-Min Callback** | Handles all Break-Camp Directors (`JCCSF`, `Steve & Kate's`), Independent School Principals, Luxury Realtors, and General Contractors. |
| **Shared Inbox:** `info@ositodrone.com` | **Alan Musselman (COO)** *(Primary Triage)* | **Jesus & Miguel** *(Auto-forwarded to all 3 founders)* | **Under 15 Minutes** (8:00 AM – 7:00 PM) | Whoever sees an inbound email first replies *"Claiming this!"* in the Founder SMS thread and sends the quote/booking link within 15 minutes. |

---

## 3. Non-Negotiable Rule #2: The 15-Minute 8:30 AM Daily Standup

Every Monday through Friday at **8:30 AM sharp** (by 3-way phone call or in-person before loading gear), Miguel, Alan, and Jesus run a strict **15-minute standup**. No philosophical debates, no new CAD designs during sales hours—only numbers and commitments:

* **Minutes 0–5 (Yesterday's Receipts):**
  - **Miguel:** How many live decision-maker calls and walk-ins did I complete yesterday? Which leads moved to `Demo Booked` or `Paid`?
  - **Alan:** How many `.eml` pitches, venue calls, and quotes/invoices went out yesterday?
  - **Jesus:** Are all 5 dispatch portals (`FlyGuys`, `Zeitview`, `Bees360`, `Droners.io`, `IMGING`) active, and how many FPV/makerspace pitches did I make?
* **Minutes 5–10 (Today's 3 Non-Negotiable Targets Per Founder):**
  - **Miguel** names his **4 Morning Calls (9:30–11:30 AM)** and **1 Afternoon Walk-In Corridor (1:30–4:00 PM)** from [`Miguel_CEO_5Day_Daily_Action_Sheet.md`](./Miguel_CEO_5Day_Daily_Action_Sheet.md).
  - **Alan** names his **3 Brewery/Corporate Venue or Roofer Calls** and **1 Walk-In** (`Barebottle`, `Southern Pacific`, `Thriller Social Club`, `Lawson Roofing`).
  - **Jesus** names his **2 Real Estate Media Agency Calls** (`Open Homes`, `Aerial Canvas`) and **2 Break-Camp/Makerspace Contacts** (`STEMful`, `Mission Science Workshop`).
* **Minutes 10–15 (Handoffs & Hardware Check):**
  - Does Miguel or Alan need Jesus on a **10-minute live `CUB-75` / `SHARD-75` hardware demo** today?
  - Are `1S 550mAh` batteries charged in the Bat-Safe and is the demo kit in the trunk?

---

## 4. Non-Negotiable Rule #3: Weekly KPI Scorecard (Each Founder Owns 3 Numbers)

Every **Friday at 4:30 PM**, the team updates [`Osito_November_Fast_Cash_Jobs_Tracker.csv`](./Osito_November_Fast_Cash_Jobs_Tracker.csv) and grades the week against these **9 Founder KPIs** (3 per founder). Nobody can hide behind "busywork"—either the number hit target or it didn't:

### A. Miguel Flores (CEO) — *The Outbound Door-Opener*
| KPI # | Miguel's Weekly Metric | Weekly Target | November 4-Week Goal |
| :---: | :--- | :---: | :--- |
| **M-1** | **Live Outbound Phone Conversations** *(Camp Directors, GCs, Realtors, Principals)* | **20 live conversations / wk** *(4/day)* | **80 live conversations** |
| **M-2** | **In-Person SF Corridor Walk-Ins** *(leaving printed 1-pager + booking spec/demo)* | **8 walk-ins / wk** *(Mission, SoMa, Marina, Presidio)* | **32 in-person drops** |
| **M-3** | **Closed Paid Short-Cycle Bookings** *(Break Camps, Sat Pop-Up, GC/Realtor Trial Shoots)* | **1–2 paid bookings / wk** (`$600–$1,500/wk`) | **`$3,000+` closed CEO revenue** |

### B. Alan Musselman (COO) — *The Commercial Closer & Venue Architect*
| KPI # | Alan's Weekly Metric | Weekly Target | November 4-Week Goal |
| :---: | :--- | :---: | :--- |
| **A-1** | **Brewery, Corporate Venue & Roofer Outbound Pitches** *(Emails + Follow-up Calls)* | **15 pitches / wk** *(3/day)* | **60 B2B venue/roofer pitches** |
| **A-2** | **Live Inbound Marketplace Channels Maintained** *(Thumbtack Pro, GigSalad, Nextdoor SF)* | **3 active channels** + `<5 min` lead reply | **3 booked `$299` Nov Birthday Parties** |
| **A-3** | **Booked Brewery Pop-Up Nights & Corporate/Roofing Jobs** | **1 Brewery Pop-Up (`$480`) or 1 Roof/Corp Job / wk** | **`$3,500+` closed COO revenue** |

### C. Jesus Aceves (CTO) — *The Technical Wedge & Dispatch Engine*
| KPI # | Jesus's Weekly Metric | Weekly Target | November 4-Week Goal |
| :---: | :--- | :---: | :--- |
| **J-1** | **On-Demand Commercial Dispatch & FPV Subcontractor Bids** *(`FlyGuys`, `Zeitview`, `Open Homes`, `Aerial Canvas`)* | **10 bids or agency touches / wk** | **4+ subcontracted FPV or dispatch flights** |
| **J-2** | **Live 10-Minute Hardware Demos Executed** *(Makerspaces, Camp Directors, or with Miguel/Alan)* | **3 live hardware demos / wk** | **12 live demos** (converting at 50%+) |
| **J-3** | **100% Fleet & Media Turnaround Readiness** *(8 `CUB-75` + 4 `SHARD-75` + 24-hr video delivery)* | **Zero delayed shoots / 100% pass rate** | **`$2,500+` closed CTO revenue** |

---

## 5. Non-Negotiable Rule #4: The Lead Reply & Handoff Protocol ("Who Does What When They Say YES")

When a prospect replies to an email or says *"Yes, let's test this"* on the phone, we execute this exact 3-step handoff within **30 minutes** so no deal ever stalls:

### Scenario A: A Roofer (`Lawson`, `Mr. Roofing`), GC (`Build Group`, `G&M`), or HOA (`CitiScape`) Says "Yes to a `$195–$395` Trial Shoot"
1. **Whoever Got the Yes (Miguel or Alan):** Captures the exact **property address, requested date/time window, and on-site contact cell number** on the call.
2. **Alan (COO — Within 30 Mins):** Emails the calendar confirmation, attaches [`Osito_2027_Commercial_Rate_Card_and_Order_Form.html`](./Osito_2027_Commercial_Rate_Card_and_Order_Form.html) (highlighting that 100% of the `$195` trial credits toward the `$2,250` 10-Roof Pass or `$595/mo` GC Retainer), and sends the Square/Stripe invoice link + COI if needed.
3. **Jesus (CTO — Within 2 Hours):** Checks FAA LAANC airspace for the SF property address, flies the 30-minute mission, and delivers the Google Drive/Dropbox folder of 40+ annotated 4K photos + orthomosaic within **24 hours**.

### Scenario B: A Real Estate Media Agency (`Open Homes`, `Aerial Canvas`) or Luxury Agent (`Vanguard`, `Compass`) Books the "Free 30-Sec FPV Spec Shoot"
1. **Miguel or Jesus:** Locks in the **date, time (ideally 30 mins before broker tour/open house), and listing address**.
2. **Jesus (CTO):** Arrives 15 minutes early in unbranded professional attire (for white-label agency shoots), flies 3 clean indoor-to-outdoor cinewhoop passes (`4K/60fps` Gyroflow), and delivers the speed-ramped 9:16 vertical Reel + 16:9 cut within **24 hours**.
3. **Alan & Miguel (Next Morning):** Follow up with the agent/agency the moment they praise the video to lock in the **`$350/shoot` RE-MSA White-Label Subcontractor Agreement** or **`$1,600` 4-Listing Luxury Pack**.

### Scenario C: A Break Camp (`STEMful`, `JCCSF`, `Steve & Kate's`) or Makerspace (`MSW`) Books a `$600–$960` Nov 11 / Nov 23–25 Block
1. **Miguel or Jesus:** Confirms the date (**Wed Nov 11** or **Mon–Wed Nov 23–25**), student headcount (up to 20 per rotation), and indoor room location.
2. **Alan (COO — Within 30 Mins):** Sends the `$600` (2-hr) or `$960` (half-day) Square/Stripe invoice, Osito's W-9, Additional Insured COI, and printable [`Osito_Participant_Safety_Waiver.html`](./Osito_Participant_Safety_Waiver.html) for the camp director.
3. **All 3 Founders (Event Day):** Arrive 25 minutes early with the 10-drone `CUB-75` fleet, Bat-Safe chargers, LED gates, and soldering demo kit to deliver a 10/10 session—and pitch the **`$16,200` 2027 3-Season School/Camp MOU (`STEM-3S`)** before packing up.

### Scenario D: A Brewery (`Barebottle`, `Southern Pacific`) or Corporate Venue (`Thriller`, `The Midway`) Approves a `SHARD-75` Pop-Up Night or Q4 Buyout
1. **Alan (COO):** Confirms the `8.5' × 8.5'` floor spot, load-in time, and sends the host venue an Additional Insured COI.
2. **Jesus (CTO):** Preps the `101" × 101"` Alvantor netted arena tent, 4 `SHARD-75` combat quads with extra N52 magnetic armor shards, dual FPV goggles, and the live HDMI scoreboard.
3. **Miguel (CEO — At the Event):** Stands outside the net cage as the **Arena MC & Corporate Lead Closer**, having every pilot sign [`Osito_Participant_Safety_Waiver.html`](./Osito_Participant_Safety_Waiver.html) (capturing their name, phone, email, and company) and pitching every tech manager watching the cage on booking a **`$1,200–$1,800` November Work Friendsgiving or December Holiday Party**!
