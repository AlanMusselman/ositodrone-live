# Osito Drone LLC (d/b/a Osito Drone Services and Osito Drone Academy) — 2027 Commercial Retainer Rate Card & Service Order Agreement

**Osito Drone LLC (`ositodrone.com`) — d/b/a `Osito Drone Services` & `Osito Drone Academy`**  
FAA Part 107 Certified • `$1M / $2M` Commercial Aviation Liability Insured • San Francisco, CA  
- **Miguel Flores (CEO & Co-Founder):** `miguel@ositodrone.com` | `415-571-6614`  
- **Alan Musselman (COO & Co-Founder):** `alan@ositodrone.com` | `415-810-4158`  
- **Jesus Aceves (CTO & Co-Founder):** `jesus@ositodrone.com` | `415-269-1206`

---

## 1. 2027 Commercial Retainer & Volume Packages

> **🎯 November/December Trial Credit Offer:**  
> Apply **100% of your first Trial Shoot fee (up to `$200` credit)** toward any 2027 Commercial Retainer or Prepaid Pack signed on or before **January 15, 2027**.

### A. Real Estate Media: Indoor FPV & Twilight Aerials
| Package Code | Package Name & Scope | Standard Single Rate | **2027 Retainer / Pack Rate** | Turnaround & Deliverables |
| :--- | :--- | :---: | :---: | :--- |
| **`RE-MSA`** | **Media Agency White-Label Subcontractor MSA** *(Min. 3 shoots/mo)*<br>• One-take 4K/60fps stabilized Indoor-to-Outdoor Cinewhoop FPV fly-through (`60–90 sec` raw + speed-ramped edit) OR 15 exterior aerials (`$495` Real Estate Aerial + Indoor FPV Bundle) | \$500 / shoot | **\$350 / shoot**<br>*(Net-15 Monthly Billing)* | **24–48 Hours**<br>Unbranded white-label delivery link |
| **`RE-4PK`** | **Luxury Brokerage 4-Listing Quarterly Pack** *(Prepaid, valid 6 mos)*<br>• Complete Indoor FPV Walkthrough + 15 HDR Exterior/Neighborhood Aerials + 5 Golden-Hour Twilight Aerials per listing | \$2,200<br>(\$550 × 4) | **\$1,600 / 4 listings**<br>*(\$400 / listing — Save \$600)* | **48 Hours**<br>MLS-ready + vertical IG/TikTok Reels |

---

### B. Construction Monitoring, Orthomosaic Mapping & Volumetrics
| Package Code | Package Name & Scope | Single / Month-to-Month Rate | **2027 12-Month Site Subscription** | Turnaround & Deliverables |
| :--- | :--- | :---: | :---: | :--- |
| **`CON-01`** | **Single Construction Ortho / 4K Progress Shoot**<br>• 15 repeatable GPS-locked 4K progress angles + 4K orbital video + 2D GeoTIFF/PDF Orthomosaic Map | **\$450 / shoot** | Credited toward `CON-12M` or `CON-BIW` | **24 Hours** |
| **`CON-12M`** | **Automated Monthly Lender-Draw Progress Subscription**<br>• Flown automatically on the **1st Tuesday of every month** (or GC's draw cutoff date)<br>• 15 repeatable GPS-locked 4K progress angles + 4K orbital video<br>• 1 High-Resolution 2D GeoTIFF/PDF Orthomosaic Map & 3D Point Cloud | \$750 / mo<br>(\$9,000 / yr) | **\$595 / month**<br>*(\$7,140 / yr — Save \$1,860)* | **By 9:00 AM Next Morning**<br>Branded Lender-Draw PDF & Cloud Link |
| **`CON-BIW`** | **Bi-Weekly Active Excavation / Framing Subscription** *(24 visits/yr)*<br>• Includes stockpile volumetric cut/fill calculations + safety perimeter audit | \$1,400 / mo | **\$1,095 / month**<br>*(\$547.50 / visit)* | **24 Hours** |

---

### C. Roofing, Solar & HOA Preventative Infrastructure Inspections
| Package Code | Package Name & Scope | Standard Single Rate | **2027 Volume / Annual Rate** | Turnaround & Deliverables |
| :--- | :--- | :---: | :---: | :--- |
| **`ROOF-10`** | **2027 Roofer & Solar "10-Roof Estimator Pass"** *(Prepaid, valid 12 mos)*<br>• 30-min no-ladder 4K/Thermal zoom inspection of steep 3–4 story SF Victorians or commercial flat roofs (`40+` high-res photos of flashing, parapets, gutters, skylights & ponding + 3D roof geometry; Single Roof Thermal/4K Trial is `$245` standard / `$195` Nov Flash Promo) | \$2,450<br>(\$245 × 10) | **\$2,250 / 10 roofs**<br>*(\$225 / roof)* | **24 Hours**<br>Annotated Inspection Folder |
| **`HOA-2X`** | **Biannual HOA "Spring + Fall" Roof, Gutter & Facade Audit**<br>• **Visit 1 (April — Post-Winter):** Storm wear, flashing & membrane check<br>• **Visit 2 (October — Pre-Winter):** Gutter, scupper & downspout clearance check | \$890 / yr<br>(\$445 × 2) | **\$695 / yr per building**<br>*(Or **\$595/yr** for 5+ HOA buildings)* | **48 Hours**<br>Board-Ready PDF Visual Audit Report |

---

### D. Youth STEM Academy (`STEM-3S`), `SHARD-75` Combat Arena & `TURBOPAW-64` Race Rig
| Package Code | Package Name & Scope | Standard Rate | **2027 Preferred Partner Rate** | Footprint & Throughput |
| :--- | :--- | :---: | :---: | :--- |
| **`STEM-3S`** | **3-Season School Partner MOU** *(Spring + Summer + Fall)*<br>• Spring 8-Wk After-School Lab (`$5,600`) + 5-Day Summer Camp (`$6,800`) + Fall 8-Wk After-School Lab (`$5,600`) with `39.5g CUB-75` trainers, **4-Pilot Tablet Flight Sim Pod**, and 1 Free Family STEM Night | \$18,000 / yr | **\$16,200 / yr**<br>*(10% Partner Discount)* | Classroom / Gym (`1:4` Coach Ratio, 16 Students/Cohort) |
| **`CORP-ARENA`** | **Turnkey `SHARD-75` Aerial Combat Tournament** *(2–3 Hours)*<br>• 100% net-enclosed `8.4' × 8.4'` battle tent, `45.5g` optical-flow / `38.8g` base magnetic breakaway-armor combat drones, live digital scoreboard, and 2 Osito Flight Referees | \$1,800 – \$3,200 | **\$1,450 Wholesale (Venues)**<br>**\$5,000 / 4-Event Annual Pass** | `8.4' × 8.4'` indoor/outdoor space; 20–100+ guests |
| **`TURBOPAW-64`** | **Dual-Monitor FPV Race Rig Activation** *(4-Hour Event)*<br>• Turnkey dual-monitor head-to-head FPV micro-drone racing track, LED gates, and modular pit-crew bench | \$1,000 / event | **\$800 / 4-hr event** | `10' × 15'` indoor/patio footprint |

---

### E. B2B Airspace & Perimeter Security (`Osito Drone Services — Security Division`)
| Package Code | Package Name & Scope | Standard Rate | **2027 Retainer / Contract Rate** | Deployment & Deliverables |
| :--- | :--- | :---: | :---: | :--- |
| **`SEC-1`** | **24/7 RF & FAA Remote-ID Airspace Monitoring Node**<br>• Continuous perimeter airspace detection & unauthorized drone alert log | \$650 / mo | **\$495 / month** | Cloud Dashboard + Monthly Airspace Log |
| **`SEC-2`** | **Recurring Nighttime Thermal Perimeter Patrol Subscription**<br>• Scheduled after-hours autonomous/Part 107 thermal roof, yard & fence-line sweeps | \$3,000 / mo | **\$2,400 / month** | Thermal Anomaly Video + Incident Dispatch |
| **`SEC-3`** | **Tactical Event Aerial Overwatch & Crowd Perimeter Security**<br>• Live thermal/4K tethered or rotational aerial overwatch for VIP/corporate events | \$2,800 / event | **\$2,200 / event** | Live Command Feed + Part 107 Flight Crew |
| **`SEC-4`** | **Physical & Aerial Facility Vulnerability Audit**<br>• Comprehensive 3D thermal/optical roof, blind-spot, HVAC & perimeter security assessment | \$4,200 / audit | **\$3,500 / audit** | Executive Security & CAD/3D Audit Report |
| **`SEC-5`** | **Annual Autonomous Drone-in-a-Box Perimeter Dock Lease**<br>• Turnkey on-site autonomous security dock, maintenance, Part 107 oversight & software | \$18,000 / yr | **\$14,500 / year** | 24/7 Autonomous Launch + Full Maintenance |

---

## 2. Simple 1-Page 2027 Service Order & Retainer Authorization

**Client / Company Name:** `___________________________________________________________`  
**Primary Contact & Title:** `_________________________________________________________`  
**Site / Billing Address:** `__________________________________________________________`  
**Phone:** `___________________________` **Email:** `__________________________________`

### Selected 2027 Service Package(s):
- [ ] **`RE-MSA`** — Real Estate White-Label Subcontractor MSA (`$350/shoot`, Net-15)
- [ ] **`RE-4PK`** — Real Estate 4-Listing Luxury Pack (`$1,600` prepaid; `-$______` Nov Trial Credit applied)
- [ ] **`CON-12M`** — 12-Month Construction Lender-Draw Subscription (`$595/mo` × 12 mos | Project Site: `______________________`)
- [ ] **`CON-BIW`** — Bi-Weekly Construction Excavation & Volumetric Retainer (`$1,095/mo` | Project Site: `______________________`)
- [ ] **`ROOF-10`** — 10-Roof Estimator Pass (`$2,250` prepaid; `-$______` Nov Trial Credit applied)
- [ ] **`HOA-2X`** — Biannual Spring/Fall HOA Roof & Gutter Audit (`$695/yr` × `____` Buildings = `$_________`)
- [ ] **`STEM-3S`** — 3-Season School Partner MOU (`$16,200/yr` — Spring + Summer + Fall Youth STEM Flight Labs)
- [ ] **`CORP-ARENA`** — 2027 Preferred Venue / Corporate Offsite Partner (`$1,450` wholesale / `$5,000` 4-Event Pass)
- [ ] **`TURBOPAW-64`** — Dual-Monitor FPV Race Rig (`$800 / 4-hr event`)
- [ ] **`SEC-1` / `SEC-2` / `SEC-3` / `SEC-4` / `SEC-5`** — B2B Airspace & Perimeter Security (`SEC-1` `$495/mo` | `SEC-2` `$2,400/mo` | `SEC-3` `$2,200/event` | `SEC-4` `$3,500/audit` | `SEC-5` `$14,500/yr`)

### Standard Terms & Safety Guarantee:
1. **FAA & Insurance Compliance:** All outdoor flights are conducted by FAA Part 107 Certified Remote Pilots under **Osito Drone LLC (d/b/a Osito Drone Services and Osito Drone Academy)**'s `$1,000,000 / $2,000,000` Commercial General & Aviation Liability policy. A Certificate of Insurance (COI) naming Client as Additional Insured is provided upon request prior to flight.
2. **Indoor FPV Safety:** All indoor real estate, school, and event flights utilize ultra-lightweight (`39.5g CUB-75` and `38.8g–45.5g SHARD-75`), 360° ducted propeller guards and non-marking TPU bumpers.
3. **Weather Rescheduling:** Outdoor flights delayed by rain, high winds (`>22 mph`), or low visibility are automatically rescheduled to the next clear flight window at zero penalty.
4. **Media & Data Rights:** Client receives full, perpetual commercial usage rights to all delivered photos, videos, orthomosaics, and inspection reports upon payment.

**Client Signature:** `_____________________________________` **Date:** `_______________`  
**Osito Drone LLC Representative:** `_______________________` **Date:** `_______________`
