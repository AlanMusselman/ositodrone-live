# Osito Drone LLC (d/b/a Osito Drone Services and Osito Drone Academy) — 2027 Full-Spectrum Annual Lock-In Master Plan

**Prepared For:** Miguel Flores (CEO, `415-571-6614` | `miguel@ositodrone.com`), Alan Musselman (COO, `415-810-4158` | `alan@ositodrone.com`), and Jesus Aceves (CTO, `415-269-1206` | `jesus@ositodrone.com`)  
**Target Year:** 2027 (Procurement Lock-In Window Starts **November 2026 – February 2027**)  
**Full-Spectrum Annual Revenue Target:** **$338,400 Gross / ~$265,000 Founder-Led Net Profit** across all **6 Service Pillars**

---

## 1. The Golden Rule of Locking In 2027: Procurement Happens 60–90 Days *Before* Delivery

Most drone and STEM companies miss out on annual contracts because they pitch summer camps in May or real estate agents in April. To lock in **all of 2027**, you must sell into each vertical's **actual buying window**:

| Service Pillar | When Delivery Happens in 2027 | **WHEN 2027 BUDGETS LOCK IN (When You Must Close)** | Who Owns the Close |
| :--- | :--- | :--- | :--- |
| **1. Spring 2027 School After-School Labs** (`CUB-75`) | Jan 19 – May 28, 2027 | **Nov 1 – Dec 15, 2026** *(Right Now!)* | **Miguel (CEO)** + **Jesus (CTO Demo)** |
| **2. Summer 2027 STEM & Maker Camps** (`CUB-75` + `AI Gym`) | June 7 – Aug 13, 2027 | **Dec 1, 2026 – Jan 31, 2027** *(Catalogs print in Feb!)* | **Miguel (CEO)** + **Jesus (CTO)** |
| **3. Displaced House of Air Birthday & Camp Wave** | Feb 16 – Dec 31, 2027 | **Nov 15, 2026 – Feb 15, 2027** *(Closes permanently Feb 15!)* | **Alan (COO)** |
| **4. 2027 Construction Monitoring & Mapping Retainers** | Jan – Dec 2027 (12 Monthly Flights) | **Nov 2026 – Feb 2027** *(New project starts & Q1 budgets)* | **Miguel (CEO)** + **Alan (COO)** |
| **5. Real Estate Spring/Summer Listing Surge** (FPV + Aerials) | Feb 15 – Oct 31, 2027 | **Jan 5 – Feb 15, 2027** *(Pre-Spring Listing Kickoff)* | **Jesus (CTO)** + **Miguel (CEO)** |
| **6. Annual HOA, Roofer & Perimeter Security Subscriptions** | Spring (Apr) & Fall (Oct) 2027 / Monthly | **Nov 2026 (First Trial) → Jan 2027 Annual Renewal** | **Alan (COO)** |
| **7. Corporate `SHARD-75` Offsites & Brewery Leagues** | Q1–Q4 2027 | **Rolling Quarterly (Lock Preferred Venue MSAs in Q4 2026)** | **Alan (COO)** + **Miguel (CEO)** |
| **8. Fall 2027–2028 School Year & DCYF/SFUSD Grants** | Sept 2027 – May 2028 | **March 1 – May 15, 2027** *(School & DCYF budget lock)* | **Miguel (CEO)** + **Jesus (CTO)** |

---

## 2. How Every November 2026 Job Converts into a 12-Month 2027 Contract ("Land & Expand")

Never sell a one-off job without attaching a **2027 Annual Retainer Option** on the invoice. Here is the exact conversion mechanism for all **6 Service Pillars**:

### Pillar A: Youth STEM & Flight Academy (`CUB-75`, 4-Station Lab w/ 4-Pilot Tablet Flight Sim Pod & `AI Gym Cat & Mouse`)
* **The Trap to Avoid:** Negotiating single 8-week semesters three separate times a year.
* **The 2027 Lock-In Offer — The "3-Season School Partner MOU" (`STEM-3S` at `$16,200/yr` — 10% off `$18,000/yr` standard):**
  When Miguel and Jesus do the 10-minute tabletop `CUB-75` demo in November/December 2026 for Extended Day Directors (like Dorothy Martinez at **Live Oak**, Nicole Lane at **SF Day**, Mirza Kopelman at **Brandeis**, Sean Donaldson at **International School of SF**, and Tanner Taylor at **CDS**), present the standardized **3-Season Bundle (`STEM-3S`)**:
  1. **Spring 2027 After-School Lab (`PKG-2B`, 8 Wks):** *Level 1 — `39.5g CUB-75` Hover, 4-Pilot Tablet Flight Sim Pod & Modular Diagnostics* (`$5,600`)
  2. **Summer 2027 Specialty Camp Week (`PKG-3A`, 5-Day Half-Day Camp, 15 hrs, 16 students):** *Level 2 — 3D-Printed Drone Build, FPV Racing & **AI Gym "Cat & Mouse" Autonomous Standoff Game** (`osito_corner_intercept.lua`)* (`$6,800` at `$425/student`, or `$5,100` for a 12-student compact cohort)
  3. **Fall 2027 After-School Lab (`PKG-2B`, 8 Wks):** *Level 3 — Advanced FPV Gates & `SHARD-75` Team Engineering* (`$5,600`)
  - **The Incentive:** Schools that sign the 2027 3-Season Partner Schedule (`STEM-3S`) by **January 15, 2027** lock in **`$16,200/yr`** (10% off the `$18,000/yr` combined rate) PLUS one **Free Back-to-School / Family STEM Night Drone Showcase (`$960` 2-Hr `PKG-1` / `$1,200` 3-Hr value)**.
  - **Target:** Just **4 SF Independent Schools + 2 Makerspaces/Camps** on 3-Season schedules = **`$108,240` locked in for 2027**.

---

### Pillar B: Commercial Construction Monitoring, Mapping & Surveying
* **The Trap to Avoid:** Waiting for a General Contractor to call you when they remember they need a photo.
* **The 2027 Lock-In Offer — The "12-Month Automated Lender-Draw Progress Subscription" (`CON-12M` at `$595/month` = `$7,140/year` per job site, or `CON-BIW` at `$1,095/month` bi-weekly):**
  - Every major SF commercial/multi-family builder (`Build Group`, `CCI`, `Current Construction`, `G&M Builders`) must submit **monthly progress documentation to their construction lender and equity partners** to release their monthly draw checks.
  - **How It Works:** After flying a **`$450` Single Construction Ortho/4K Shoot (`CON-01`)** (or `$395` November trial), Alan and Miguel pitch a 12-month subscription for 2027:
    - On the **1st Tuesday of every month in 2027**, an Osito pilot automatically flies the exact same GPS waypoint mission (`15 identical 4K progress angles + 1 high-res 2D Orthomosaic & 3D Volumetric Map`) and delivers a branded link by 9:00 AM Wednesday before the GC's monthly owner/lender meeting.
    - **Price:** `$750/mo` month-to-month, OR **`$595/month` (`$7,140/yr`) on a 12-month 2027 Site Subscription (`CON-12M`)** (and **`$1,095/month`** for Bi-Weekly `CON-BIW`).
  - **Target:** Locking in just **5 active SF construction sites for 2027** = **`$35,700` in guaranteed, 90-minute-per-month recurring revenue**.

---

### Pillar C: Real Estate Indoor FPV Walkthroughs & Twilight Aerials
* **The Trap to Avoid:** Chasing individual agents for one-off `$495–$500` shoots every week.
* **The 2027 Lock-In Offer — Two Dual Retainer Tracks:**
  1. **Track 1: White-Label Subcontractor MSA with SF Real Estate Media Houses (`RE-MSA` at `$350/shoot` Volume Agreement):**
     - Agencies like **Open Homes Photography (`415-592-5187`)**, **Aerial Canvas (`650-241-0095`)**, and **Reel & Shutter** shoot 50–150 properties a week in SF, and their peak season runs **February through October 2027**.
     - Lock in a **2027 Preferred SF Indoor FPV Subcontractor Agreement** in November/December 2026: Osito guarantees 48-hour SF turnaround for `$350` wholesale per one-take Indoor-to-Outdoor Cinewhoop fly-through (which the agency sells to agents as a `$650` luxury add-on).
     - **Target:** Just **3 subcontracted FPV shoots per week (`12/month`)** across 2 media agencies = **`$50,400/year`**.
  2. **Track 2: The "Quarterly 4-Listing Luxury Pack" (`RE-4PK` at `$1,600/quarter` Prepaid) for Top SF Teams:**
     - In January 2027 (right before the Spring listing surge), pitch top SF luxury teams (`Vanguard Properties`, `Malin Giddings Team @ Compass`, `Sotheby's SF`) a prepaid **4-Shoot Spring Listing Pack for `$1,600`** (`$400/listing` instead of `$495` bundle / `$500` single rate, including Indoor FPV + Twilight Aerials).

---

### Pillar D: Infrastructure, Roofing, Solar, HOA & B2B Airspace/Perimeter Security
* **The Trap to Avoid:** Only flying roofs when there is an emergency leak.
* **The 2027 Lock-In Offer — Biannual HOA "Spring + Fall Roof & Gutter Audit", Roofer Volume Blocks & Security Retainers:**
  1. **For HOA Property Managers (`CitiScape Property Management` & SF Condo Boards):**
     - Pitch a **`$695/year` per building Biannual Preventative Roof, Gutter & Parapet Audit (`HOA-2X`)**:
       - **Visit 1 (April 2027 — Post-Winter Assessment):** Document winter storm wear, ponding water, and cracked flashing while warranties/insurance claims are fresh.
       - **Visit 2 (October 2027 — Pre-Winter Clearance):** Verify all gutters, downspouts, and scuppers are clear before the 2027 rains.
     - One HOA management company manages **40 to 150+ SF buildings**! Enrolling just **15 buildings across 2 property managers** = **`$10,425/year`**.
  2. **For SF Roofers & Solar Installers (`Lawson Roofing`, `Mr. Roofing`, `Wedge Roofing`, `Luminalt Solar`):**
     - Single Roof Scan is **`$245 Standard ($195 First-Shoot Promo)`**. After their first scan, transition them to a **2027 "10-Roof Estimator Pass" (`ROOF-10` at `$2,250` prepaid = `$225/roof`)** so their estimators never have to haul a 40-foot ladder onto a steep SF Victorian just to write a quote.
  3. **B2B Airspace & Perimeter Security (`SEC-1` `$495/mo`, `SEC-2` `$2,400/mo`, `SEC-3` `$2,200/event`, `SEC-4` `$3,500/audit`, `SEC-5` `$14,500/yr`):**
     - Upsell construction sites, HOAs, and corporate campuses on recurring thermal perimeter patrols and Remote-ID airspace monitoring.

---

### Pillar E & F: Corporate `SHARD-75` Combat Arena, `TURBOPAW-64` FPV Race Rig & Displaced House of Air Birthday Pipeline
* **The Trap to Avoid:** Relying on random one-off party inquiries.
* **The 2027 Lock-In Offer — 3 Predictable Event Engines:**
  1. **The "Post-House of Air" 2027 Birthday Pipeline (Starts Feb 15, 2027):**
     - When **House of Air SF (`926 Mason St`) permanently closes on February 15, 2027**, over **500+ annual SF kids' birthday parties (ages 8–14)** in the Presidio/Marina/Richmond will suddenly need a new high-adrenaline indoor venue.
     - By partnering with **House of Air (Nov 2026 – Feb 2027)**, **SPARK Social SF (`$60–$75/hr` turf pits)**, **AcroSports**, **JCCSF**, and pre-filing Osito's COI with **SF Rec & Parks (`Moscone`, `Eureka Valley`, & `Presidio/Richmond` rec gyms)**, Osito becomes the go-to replacement (`$200` 60-Min, `$299` 90-Min Promo, `$400` 2-Hour Standard Party).
     - **Target:** **6 Birthday Parties/month in 2027** (`72 parties/yr` at `$400` avg + 25% take-home `$200` drone kit attach rate) = **`$32,400/year`**.
  2. **Preferred Corporate Venue Roster (`SHARD-75` Combat Arena `$1,450` Whsl / `$5,000` 4-Pack & `TURBOPAW-64` Dual-Monitor FPV Race Rig `$800 / 4-hr event`):**
     - Get listed in Q4 2026 on the official 2027 Event PDF menus at **SPIN SF**, **Thriller Social Club**, **Emporium SF**, **The Midway / Non Plus Ultra**, **Fort Mason**, and **Venture Up Team Building**.
     - **Target:** **2 Corporate `SHARD-75` (`45.5g` optical-flow / `38.8g` base) Tournaments per month in 2027 (`24/year` at `$2,000` avg)** = **`$48,000/year`**.
  3. **Monthly "SF Drone Combat League Night" at Barebottle / Southern Pacific Brewing + Noisebridge:**
     - Lock in the **1st Friday of every month in 2027** at a flagship SF brewery (`$480/night` pay-per-battle cash) and **1st Wednesday/Monday** at **Noisebridge (`272 Capp St`)** as your permanent 2027 customer acquisition funnel.

---

## 3. Deterministic 2027 Annual Revenue Roll-Up (All 6 Service Pillars)

| Service Pillar | 2027 Locked-In Volume Target (Conservative) | Avg Contract / Unit Value | **2027 Annual Gross Revenue** | Primary Co-Founder Owner |
| :--- | :--- | :---: | :---: | :--- |
| **1. Youth STEM Schools & Camps** (`CUB-75` + `4-Tablet Sim Pod`) | **6 School/Camp Partners** on `STEM-3S` MOUs + **11 Sat Pop-Ups** | \$16,200/partner + \$1,020/pop-up | **\$108,240** | **Miguel (CEO)** & **Jesus (CTO)** |
| **2. Real Estate FPV & Aerial Media** | **2 Media Agency MSAs** (3 FPV shoots/wk) + **8 Luxury Packs** | \$350/wholesale + \$1,600/pack | **\$63,200** | **Jesus (CTO)** & **Miguel (CEO)** |
| **3. Corporate `SHARD-75` Offsites, `TURBOPAW-64` & Brewery Nights** | **24 Corporate Tournaments** (2/mo) + **24 Brewery Nights** | \$2,000/corp + \$480/brewery | **\$59,520** | **Alan (COO)** & **Miguel (CEO)** |
| **4. Construction Monitoring & Mapping** | **5 Active SF Job Sites** on 12-Month Progress Subscriptions | \$595/mo (\$7,140/yr per site) | **\$35,700** | **Miguel (CEO)** & **Alan (COO)** |
| **5. Kids Birthday Parties & Take-Home Kits** | **6 Parties/Month** (72/yr) + **18 Take-Home `CUB-75` Kits** | \$400/party + \$200/RTF kit | **\$32,400** | **Alan (COO)** |
| **6. Roof, Solar, HOA & B2B Perimeter Security** | **15 HOA Buildings** (Biannual) + **6 Roofer 10-Packs** + Security/Dispatch | \$695/HOA + \$2,250/roofer pack + Security | **\$39,340** | **Alan (COO)** & **Jesus (CTO)** |
| **TOTAL 2027 FULL-SPECTRUM PIPELINE (6 SERVICE PILLARS)** | **Diversified Across Consumer, Education & B2B Commercial** | — | **\$338,400 / yr** | **All 3 Co-Founders** |

---

## 4. Month-by-Month 90-Day Lock-In Timeline (Nov 2026 → Jan 2027)

### 📍 November 2026: "Prove & Plant" (Land First Cash + Book Spring/Summer Demos)
1. **Commercial:** Deliver your first 3 **`$245 Standard ($195 First-Shoot Promo)`** pre-storm roof inspections (`Lawson`, `Mr. Roofing`, `CitiScape`) and your first 2 Indoor FPV spec reels (`Open Homes Photography`, `Aerial Canvas`, `Vanguard Properties`).
2. **STEM & Camps:** Run your Nov 11 (Veterans Day) / Nov 23–25 (Thanksgiving) guest blocks (`$600` 90–120 min / `$960` half-day) and Sat Nov 14 / Nov 21 Sports Basement Pop-Ups (`$1,020/session`), while **Miguel & Jesus run 10-minute tabletop `CUB-75` demos at the 11 SF Independent Schools to lock in Spring 2027 After-School cohorts before Thanksgiving**.
3. **Events:** Run your first 2 Friday/Saturday Brewery Pop-Up nights (`Barebottle`, `Southern Pacific`) and lock in **House of Air's final-season party rev-share + post-Feb 2027 referral deal**.

### 📍 December 2026: "Sign the 2027 Annual Agreements"
1. **Summer 2027 Camp Lock-In Deadline (Dec 1 – Dec 20):** Have **Live Oak (`Summer Oaks`)**, **JCCSF (`Camp JCC`)**, **SF Day**, **Brandeis**, **International School of SF**, **STEMful**, and **Tinkering School** sign their **Summer 2027 Camp Week (`PKG-3A` `$6,800`) or 3-Season (`STEM-3S` `$16,200/yr`) MOUs** before they leave for Winter Break on Dec 18.
2. **Commercial Retainer Conversions:** Pitch every roofer, GC (`Build Group`, `CCI`), and real estate agency you flew for in November on a **2027 12-Month Construction Subscription (`CON-12M` `$595/mo` / `CON-BIW` `$1,095/mo`)** or **White-Label FPV Subcontractor MSA (`RE-MSA` `$350/shoot`)** starting Jan 1, 2027.
3. **Corporate Holiday Parties:** Deliver Q4 holiday `SHARD-75` (`45.5g`) tournaments at `SPIN`, `Thriller Social Club`, `Emporium`, and `The Midway`, and get added to their **2027 Preferred Vendor PDF Packets**.

### 📍 January – February 15, 2027: "Launch Spring Cohorts & Capture the Presidio Wave"
1. **Week of Jan 19, 2027:** Launch **Spring 2027 8-Week After-School Flight Labs (`PKG-2B` `$5,600`)** across your signed SF schools.
2. **Jan 10 – Feb 10, 2027:** Blitz SF luxury real estate teams (`Compass`, `Vanguard`, `Sotheby's`) with the **`$1,600` 4-Shoot Spring Listing Pack (`RE-4PK`)** right before the February post-Super-Bowl SF real estate listing surge.
3. **February 15, 2027 (House of Air Closure Day):** Launch your targeted **"Presidio & SF Indoor Drone Birthday + Adventure Party"** campaign with **SF Rec & Parks COI pre-approval** and **SPARK Social / AcroSports / Sports Basement** venue partnerships to capture displaced SF birthday families for the rest of 2027.
