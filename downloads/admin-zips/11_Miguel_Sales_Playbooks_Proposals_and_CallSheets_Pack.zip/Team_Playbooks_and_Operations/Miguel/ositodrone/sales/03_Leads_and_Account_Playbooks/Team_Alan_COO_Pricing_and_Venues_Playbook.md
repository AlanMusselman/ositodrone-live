# Osito Drone Services — COO Pricing, Unit Economics & Venue Partnerships Playbook

**Owner:** Alan Musselman — COO & Co-Founder (`alan@ositodrone.com` | `415-810-4158`)  
**Strike Team Counterparts:**
- **Miguel Flores** — CEO & Co-Founder (`miguel@ositodrone.com` | `415-571-6614`) — *Independent Schools, Corporate Offsites & Executive Accounts*
- **Jesus Aceves** — CTO & Co-Founder (`jesus@ositodrone.com` | `415-269-1206`) — *Hardware Manufacturing, Firmware (`CUB-75` / `SHARD-75`), Makerspaces & Technical Demos*

**Supporting Workspace References:**
- Master Lead Tracker: [`Osito_SF_Sales_Leads_Tracker.csv`](./Osito_SF_Sales_Leads_Tracker.csv)
- Classroom Drone BOM: [`CUB75_BOM_and_Sourcing.md`](./Kids%20Training%20Drone/CUB75_BOM_and_Sourcing.md)
- Combat Arena Drone BOM: [`KODIAK75_BOM_and_Sourcing.md`](./Bumper%20Drones/KODIAK75_BOM_and_Sourcing.md)
- Outreach Templates: [`Osito_SF_Outreach_Playbook_and_Templates.md`](./Osito_SF_Outreach_Playbook_and_Templates.md)

---

## 1. Alan's Role in the 3-Man Strike Team (COO Charter)

As Chief Operating Officer, Alan Musselman owns the commercial engine that turns Osito's in-house 3D-printed micro-drone fleet into repeatable, high-margin B2B/B2G contracts and weekend recurring venue cashflow:

1. **Deterministic Pricing, Proposals & Grant Packaging:**
   - Owns all school, camp, and municipal pricing tables, ensuring every quote maintains a **79%–94% Founder-Led Gross Margin** and a **40%–80% Hired-Coach Gross Margin** after full hardware amortization, `$0.52` airframe spares, and insurance allocations.
   - Packages per-student and per-student-hour metrics (`$22.50–$30.00/student-hour`) so SF public/nonprofit programs (`OS-015` CYC, `OS-016` JCYC SF STEM Academy, `OS-018` YMCA, `OS-019` Boys & Girls Clubs) can plug Osito directly into **Title I, Title IV Part A (Well-Rounded Education / STEM), and DCYF (Department of Children, Youth and Their Families)** grant budgets.
2. **Birthday & Social Venue Revenue-Share Territory (`7 Core Accounts`):**
   - Owns direct relationship management, rev-share contracting, and event calendar integration across San Francisco's top family birthday venues, municipal gyms, and gamified social bars:
     - **Youth & Family Birthday Venues:** `OS-020` (House of Air SF), `OS-021` (AcroSports), `OS-022` (Circus Center), `OS-023` (SPARK Social SF), `OS-024` (SF Recreation & Parks Indoor Facility Rentals).
     - **Gamified Social & Corporate Tournament Venues:** `OS-026` (SPIN San Francisco), `OS-027` (Emporium SF Arcade Bar).
3. **Insurance, Municipal Permits & Risk Compliance:**
   - Manages Osito's **$1M/$2M Commercial General Liability (CGL) & Aviation Endorsement policy**, issuing 24-hour turnaround **Additional Insured Certificates of Insurance (COIs)** required by the Presidio Trust, SF Recreation & Parks (`RPDReservations@sfgov.org`), Parklab (SPARK Social), and corporate venues.
   - Enforces indoor LiPo fire safety (**Bat-Safe** steel charging enclosures and `VIFLY WhoopStor V3` auto-storage discharge to `3.80V`), instructor background checks (LiveScan / TB clearance for school vendors), and net-containment protocols.
4. **Field Logistics, Staffing & Turnkey Deployment:**
   - Coordinates Pelican 1560/1450 fleet transport, 15-minute on-site setup of the `101"×101"×84"` Alvantor netted combat arena tent, and staffing transitions from **Founder-Led Strike Team** (Miguel + Alan + Jesus) to trained part-time Lead Instructors (`$45/hr`) and Station Flight Coaches (`$30/hr`).

---

## 2. Deterministic Hardware Fleet Cost & Amortization Model

All hardware figures below are deterministically calculated in Python from [`CUB75_BOM_and_Sourcing.md`](./Kids%20Training%20Drone/CUB75_BOM_and_Sourcing.md) and [`KODIAK75_BOM_and_Sourcing.md`](./Bumper%20Drones/KODIAK75_BOM_and_Sourcing.md).

### 2A. Unit BOM Reference Constants
| Hardware Item | Exact Unit BOM | Specification & Sourcing Notes |
| :--- | :---: | :--- |
| **`OSITO CUB-75` (LOS Classroom Trainer)** | **\$98.04** | BetaFPV Matrix 1S 5-in-1 ELRS AIO (\$44.99), 0802/1002 motors (\$39.99), Gemfan 1610 props (\$2.99), Lava 1S 550mAh LiHV (\$4.80), COB LED (\$3.50), Fasteners (\$1.25), In-Office 3D-Printed Airframe Set (\$0.52). `39.5g` AUW. |
| **`OSITO CUB-75 Dual` (LOS + FPV Convertible)** | **\$118.03** | Adds plug-in BetaFPV `C03` Nano FPV camera (+\$19.99) and swap-in TPU FPV pod. `41.1g` AUW. |
| **In-Office 3D-Printed Replacement Airframe Set** | **\$0.52** | `CUB75_Frame_KidSafe_75mm.stl` (\$0.22 PETG-CF) + `CUB75_TPU_Bumper_Ring.stl` (\$0.10) + `CUB75_550mAh_Trainer_Skids.stl` (\$0.12) + `CUB75_Canopy_LOS/FPV.stl` (\$0.08). |
| **`SHARD-75` / `KODIAK-75` Dual-Mode Combat Drone** | **\$121.43** | `$101.44` LOS + `$19.99` FPV camera; includes 4-zone N52 magnetic breakaway EPP armor shards. `38.8g` AUW. |
| **Radiomaster Pocket (ELRS 2.4GHz Built-In)** | **\$64.99** | Gamepad-style controller with Hall-effect gimbals & wireless ELRS Buddy-Box master/slave trainer mode. |
| **VIFLY WhoopStor V3 6-Port 1S Storage Charger** | **\$42.99** | Charges 6x `1S 550mAh` packs at `1.3A` in ~22 mins; auto-discharges to `3.80V` storage voltage. |
| **Take-Home `CUB-75` Complete RTF Student Kit** | **\$177.84** | 1x `CUB-75` LOS (\$98.04) + 1x Radiomaster Pocket (\$64.99) + 1x Extra 550mAh Battery (\$4.80) + 1x USB-C 1S Charger (\$6.50) + 1x Spare 3D-Printed Airframe Set (\$0.52) + 1x Spare Prop Set (\$2.99). Sold as a **+\$200** add-on (**\$22.16** net hardware profit; or **\$132.84 BOM / \$67.16 profit** for Drone-Only Upgrade Pack). |

---

### 2B. Turnkey Fleet CapEx & Per-Session Amortization Schedule

#### Fleet 1: 16-Student 4-Station STEM Academy Fleet (1:4 Instructor Ratio, 1:2 Drone-to-Student Ratio)
| Fleet Component | Qty | Unit Cost | Extended CapEx | Operational Role |
| :--- | :---: | :---: | :---: | :--- |
| **`OSITO CUB-75 Dual` (LOS + FPV) Drones** | 8 | \$118.03 | **\$944.24** | 1 active programmable/FPV drone per 2 students (Pilot + Spotter/Flight Engineer) |
| **`OSITO CUB-75` (LOS) Hot-Spare Drones** | 2 | \$98.04 | **\$196.08** | Instant bench swap so class never pauses during Station 1 repair diagnostics |
| **Radiomaster Pocket ELRS Transmitters** | 8 | \$64.99 | **\$519.92** | 6 student flight radios + 2 instructor Wireless Buddy-Box master radios |
| **VIFLY WhoopStor V3 6-Port 1S Chargers** | 3 | \$42.99 | **\$128.97** | 18 simultaneous charging ports (cycles 18 batteries every 22 minutes) |
| **Extra BetaFPV Lava 1S 550mAh 75C Batteries** | 24 | \$4.80 | **\$115.20** | 34 total packs across fleet (continuous flight rotation with zero downtime) |
| **5.8GHz Diversity FPV Box Goggles** | 4 | \$89.99 | **\$359.96** | Station 4 cockpit goggles with spectator DVR out |
| **Fireproof Bat-Safe Steel LiPo Enclosures** | 2 | \$59.99 | **\$119.98** | Mandatory indoor charging & transport containment for school/venue compliance |
| **Station 1–4 Bench, Sim & Obstacle Gate Kit** | 1 lot | \$350.00 | **\$350.00** | 4x Pinecil/USB-C soldering stations, multimeter, 2x hover pods, 4x USB sim dongles, neon LED gates |
| **TOTAL STEM ACADEMY 16-STUDENT FLEET CAPEX** | — | — | **\$2,734.35** | **Amortized over 60 sessions = \$45.57 / session** |

#### Fleet 2: `SHARD-75` Aerial Combat Arena Turnkey Event Kit (`101"×101"` Netted Tent)
| Fleet Component | Qty | Unit Cost | Extended CapEx | Operational Role |
| :--- | :---: | :---: | :---: | :--- |
| **Base 2-Drone Arena Turnkey Kit** | 1 kit | \$607.88 | **\$607.88** | 2x Dual-Mode Combat Quads (\$221.90), 12x 550mAh packs (\$57.60), 6x prop sets (\$17.94), PC-CF & TPU spools + EPP armor/N52 magnets (\$127.46), 1x WhoopStor V3 (\$42.99), 1x Alvantor `101"×101"×84"` Pop-Up Netted Arena Tent (\$139.99) |
| **Backup `SHARD-75` Dual-Mode Combat Drones** | 2 | \$121.43 | **\$242.86** | Brings arena fleet to 4 combat quads (2 active in cage + 2 pit-crew hot spares) |
| **Radiomaster Pocket ELRS Transmitters** | 4 | \$64.99 | **\$259.96** | Red & Blue Team primary transmitters + 2 backup/buddy-box controllers |
| **5.8GHz FPV Cockpit Goggles** | 2 | \$89.99 | **\$179.98** | Optional cockpit dogfighting mode for experienced gamers |
| **Fireproof Bat-Safe LiPo Enclosure** | 1 | \$59.99 | **\$59.99** | On-site LiPo charging safety compliance for venues |
| **Live Digital Scoreboard Display, Tripod & PA** | 1 set | \$149.33 | **\$149.33** | Portable LED scoreboard & timer display for 3-minute heats (first to 10 pts) |
| **TOTAL `SHARD-75` COMBAT ARENA FLEET CAPEX** | — | — | **\$1,500.00** | **Amortized over 50 events = \$30.00 / event** |
| **COMBINED OSITO MASTER FLEET INVESTMENT** | — | — | **\$4,234.35** | Covers 100% of School STEM Labs, Summer Camps, Birthdays & Corporate Buyouts |

---

## 3. Client-Facing Pricing Table & Grant Eligibility Metrics

This table is formatted for school principals, Extended Day directors, nonprofit grant writers (Title I / Title IV / DCYF), and corporate event buyers.

| Pkg Code | Program / Package Name | Format & Duration | Capacity & Staffing Ratio | Client Retail Price | Effective Cost per Student / Guest | Effective Cost per Student-Hour | Venue Partner / Grant Notes |
| :--- | :--- | :--- | :---: | :---: | :---: | :---: | :--- |
| **`PKG-1`** | **1-Day STEM Discovery Workshop** | 2.0 Hours (Single Day, 4 Rotating Stations) | Up to **16 Students** (`1:4` Instructor Ratio, 4 Staff) | **\$960.00** | **\$60.00** / student | **\$30.00** / student-hr | Ideal trial workshop for `OS-001` STEMful, `OS-002` Mission Science Workshop, `OS-015` CYC, and school STEM nights. |
| **`PKG-2A`** | **8-Week After-School Flight & Engineering Lab (12-Student Cohort)** | 1.5 Hrs/Wk × 8 Weeks (**12.0 Hours Total**) | **12 Students** (`1:4` Instructor Ratio, 3 Staff) | **\$4,200.00** | **\$350.00** / student | **\$29.17** / student-hr | Fits smaller independent schools (`OS-006` SF Schoolhouse, `OS-009` Synergy, `OS-012` Presidio Hill). Schools often mark up 15%–25% to parents. |
| **`PKG-2B`** | **8-Week After-School Flight & Engineering Lab (16-Student Cohort)** | 1.5 Hrs/Wk × 8 Weeks (**12.0 Hours Total**) | **16 Students** (`1:4` Instructor Ratio, 4 Staff) | **\$5,600.00** | **\$350.00** / student | **\$29.17** / student-hr | Flagship semester package for `OS-005` Alta Vista, `OS-007` Live Oak, `OS-008` CDS, `OS-010` SF Day, `OS-013` Town School. |
| **`PKG-3A`** | **5-Day Summer Flight & Maker Camp (Half-Day)** | 3.0 Hrs/Day × 5 Days (**15.0 Hours Total**) | **16 Students** (`1:4` Instructor Ratio, 4 Staff) | **\$6,800.00** | **\$425.00** / student | **\$28.33** / student-hr | Morning (9am–12pm) or Afternoon (1pm–4pm) camp block for `OS-003` Tinkering School, `OS-017` JCCSF, `OS-018` YMCA. |
| **`PKG-3B`** | **5-Day Summer Flight & Maker Camp (Full-Day)** | 6.0 Hrs/Day × 5 Days (**30.0 Hours Total**) | **16 Students** (`1:4` Instructor Ratio, 4 Staff) | **\$10,800.00** | **\$675.00** / student | **\$22.50** / student-hr | Lowest per-student-hour cost (`$22.50/hr`) for Title IV / DCYF summer grant compliance; includes Friday FPV & Aerial Combat Showcase. |
| **`PKG-3C`** | **5-Day Full-Day Camp + Take-Home `CUB-75` RTF Bundle** | 6.0 Hrs/Day × 5 Days (**30.0 Hours Total**) + Own Drone & Radio | **16 Students** (`1:4` Instructor Ratio, 4 Staff) | **\$14,000.00** *(+\$200/student)* | **\$875.00** / student | **\$29.17** / student-hr *(incl. hardware)* | Each student builds, tunes, and keeps their own `CUB-75` drone, Radiomaster Pocket ELRS radio, 2 batteries, USB-C charger & spare frame set. |
| **`PKG-4A`** | **Turnkey Birthday Party — Solo Pilot 60-Min Package** | 60 Minutes (Hover Pods + Neon Gates + FPV / Arena Intro) | Up to **8 Pilots** (Ages 8+, 1 Lead Flight Coach) | **\$200.00** *(+\$200 Take-Home Kit optional)* | **\$25.00** / pilot | **\$25.00** / pilot-hr | **Venue Partner Rate:** `20% Rev-Share` (\$40 commission to venue / **\$160** wholesale to Osito). |
| **`PKG-4B`** | **Turnkey Birthday Party — Extended 2-Hr Flight & `SHARD-75` Battle** | 120 Minutes (Full Flight Training + `101"×101"` Netted Arena Tournament) | Up to **10 Pilots** (Ages 8+, 1 Lead Flight Coach) | **\$400.00** *(+\$200 Take-Home Kit optional)* | **\$40.00** / pilot | **\$20.00** / pilot-hr | **Direct Booking Rate** (e.g., `OS-024` SF Rec & Park gyms or private homes). |
| **`PKG-4C`** | **Turnkey Birthday Party — Extended 2-Hr Venue Partner Tier** | 120 Minutes (Bundled VIP Upgrade at Partner Venue) | Up to **10 Pilots** (Ages 8+, 1 Lead Flight Coach) | **\$320.00 Net** *(\$400 Retail)* | **\$32.00** / pilot *(Wholesale)* | **\$16.00** / pilot-hr *(Wholesale)* | **Venue Partner Rate:** Partner venue sells at \$400+ and retains **\$80 (20%)**, or buys wholesale at \$320 and marks up to \$450–\$500. |
| **`PKG-5A`** | **Corporate `SHARD-75` Aerial Combat Arena — 2-Hr Tournament** | 2.0 Hours Active + 45-Min Setup (`101"×101"` Netted Cage + Live Scoreboard) | **20–50 Guests** (3-Min Heats, ~40 Pilot Slots, 2 Staff: MC + Pit Tech) | **\$1,800.00** | **\$45.00** / guest *(at 40 guests)* | **\$22.50** / guest-hr | Turnkey interactive entertainment for tech offsites & happy hours (`OS-023` SPARK Social, `OS-026` SPIN SF, `OS-027` Emporium). |
| **`PKG-5B`** | **Corporate `SHARD-75` Aerial Combat Arena — 4-Hr Buyout** | 4.0 Hours Active + 60-Min Setup (Dual-Bracket Tournament + FPV Cockpit Lounge) | **50–100+ Guests** (80+ Pilot Slots, 3 Staff: MC + 2 Pit/Flight Techs) | **\$3,200.00** | **\$40.00** / guest *(at 80 guests)* | **\$10.00** / guest-hr | Full corporate tournament buyout (`OS-025` The Midway, `OS-026` SPIN SF, `OS-028` Venture Up team-building challenge). |

---

## 4. Internal Executive Margin Table (Founder-Led vs. Hired Coach Delivery)

> [!IMPORTANT]
> **Labor & Cost Accounting Rules (Python-Verified):**
> 1. **Founder-Led Delivery (`Miguel + Alan + Jesus`):** During Phase 1 ramp-up, the 3 co-founders run the first stations/events directly (`$0` external payroll draw; 100% of net operating profit stays in Osito/founder distributions). When a 16-student class requires a strict `1:4` ratio (4 instructors), the 3 founders add **1 Hired Station Coach (`$30/hr`)**.
> 2. **Fully Hired Staff Delivery (Scale Mode):** Assumes 0 founders on-site—staffed 100% by a hired **Lead Instructor / Arena MC (`$45/hr`, including 1.0 hr setup/teardown)** plus hired **Station Flight Coaches / Pit Techs (`$30/hr`, including 0.5 hr setup/teardown)**.
> 3. **Hardware Reserve & Spares (`$0.52`/frame):** Explicitly budgets in-office 3D-printed replacement airframe sets at **\$0.52 each** plus replacement props (`$2.99`/set), solder wire/practice PCBs, EPP foam armor shards, and battery cycle wear.

| Pkg Code | Package Name | Gross / Net Revenue to Osito | HW Spares Reserve *(incl. `$0.52` Frames)* | Fleet Amort. | Insurance & Transport | Non-Labor COGS Subtotal | **Founder-Led** Ext. Labor | **Founder-Led Net Profit (\$)** | **Founder-Led Margin (%)** | **Hired-Staff** Total Labor | **Hired-Staff Net Profit (\$)** | **Hired-Staff Margin (%)** |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **`PKG-1`** | **1-Day STEM Workshop (2 Hr, 16 Kids)** | **\$960.00** | \$18.00 *(4 frames = \$2.08)* | \$45.57 | \$35.00 | **\$98.57** | \$75.00 *(1 coach)* | **\$786.43** | **81.9%** | \$360.00 *(1 Lead + 3 Coach)* | **\$501.43** | **52.2%** |
| **`PKG-2A`** | **8-Wk After-School Lab (12 Kids)** | **\$4,200.00** | \$96.00 *(15 frames = \$7.80)* | \$364.56 | \$200.00 | **\$660.56** | \$0.00 *(3 Founders)* | **\$3,539.44** | **84.3%** | \$1,860.00 *(1 Lead + 2 Coach)* | **\$1,679.44** | **40.0%** |
| **`PKG-2B`** | **8-Wk After-School Lab (16 Kids)** | **\$5,600.00** | \$120.00 *(20 frames = \$10.40)* | \$364.56 | \$200.00 | **\$684.56** | \$480.00 *(1 coach)* | **\$4,435.44** | **79.2%** | \$2,340.00 *(1 Lead + 3 Coach)* | **\$2,575.44** | **46.0%** |
| **`PKG-3A`** | **5-Day Summer Camp — Half-Day (16 Kids)** | **\$6,800.00** | \$125.00 *(20 frames = \$10.40)* | \$227.85 | \$150.00 | **\$502.85** | \$525.00 *(1 coach)* | **\$5,772.15** | **84.9%** | \$2,475.00 *(1 Lead + 3 Coach)* | **\$3,822.15** | **56.2%** |
| **`PKG-3B`** | **5-Day Summer Camp — Full-Day (16 Kids)** | **\$10,800.00** | \$200.00 *(35 frames = \$18.20)* | \$455.70 | \$200.00 | **\$855.70** | \$975.00 *(1 coach)* | **\$8,969.30** | **83.0%** | \$4,500.00 *(1 Lead + 3 Coach)* | **\$5,444.30** | **50.4%** |
| **`PKG-3C`** | **5-Day Full-Day Camp + 16x Take-Home Kits** | **\$14,000.00** | \$3,045.44 *(incl. 16 RTF Kits @ \$177.84)* | \$455.70 | \$200.00 | **\$3,701.14** | \$975.00 *(1 coach)* | **\$9,323.86** | **66.6%** | \$4,500.00 *(1 Lead + 3 Coach)* | **\$5,798.86** | **41.4%** |
| **`PKG-4A`** | **Birthday — Solo Pilot 60-Min (Direct)** | **\$200.00** | \$6.00 *(2 frames = \$1.04)* | \$15.00 | \$20.00 | **\$41.00** | \$0.00 *(1 Founder)* | **\$159.00** | **79.5%** | \$90.00 *(1 Lead × 2h)* | **\$69.00** | **34.5%** |
| **`PKG-4B`** | **Birthday — Extended 2-Hr (Direct)** | **\$400.00** | \$12.00 *(3 frames = \$1.56)* | \$30.00 | \$25.00 | **\$67.00** | \$0.00 *(1 Founder)* | **\$333.00** | **83.2%** | \$135.00 *(1 Lead × 3h)* | **\$198.00** | **49.5%** |
| **`PKG-4C`** | **Birthday — Extended 2-Hr (Venue 20% Share)** | **\$320.00** *(\$400 - \$80)* | \$12.00 *(3 frames = \$1.56)* | \$30.00 | \$25.00 | **\$67.00** | \$0.00 *(1 Founder)* | **\$253.00** | **79.1%** | \$135.00 *(1 Lead × 3h)* | **\$118.00** | **36.9%** |
| **`PKG-5A`** | **Corporate `SHARD-75` Arena — 2-Hr Buyout** | **\$1,800.00** | \$30.00 *(5 frames = \$2.60)* | \$30.00 | \$50.00 | **\$110.00** | \$0.00 *(2 Founders)* | **\$1,690.00** | **93.9%** | \$247.50 *(1 Lead + 1 Tech)* | **\$1,442.50** | **80.1%** |
| **`PKG-5B`** | **Corporate `SHARD-75` Arena — 4-Hr Buyout** | **\$3,200.00** | \$60.00 *(10 frames = \$5.20)* | \$60.00 | \$75.00 | **\$195.00** | \$0.00 *(3 Founders)* | **\$3,005.00** | **93.9%** | \$547.50 *(1 Lead + 2 Tech)* | **\$2,457.50** | **76.8%** |

> [!TIP]
> **Key COO Financial Takeaway:**  
> Running just **ONE 5-Day Full-Day Summer Camp (`PKG-3B` at \$10,800)** generates **\$8,969.30 in Founder-Led Net Profit** (or **\$5,444.30** with 100% hired staff)—paying back Osito's **entire \$4,234.35 combined STEM + `SHARD-75` fleet CapEx more than 2x over in a single week**. Similarly, **two 2-hour Corporate `SHARD-75` Arena events (`PKG-5A` at \$1,800 each)** generate **\$3,380.00 net profit**, paying back the entire \$1,500 `SHARD-75` arena kit more than twice over.

---

## 5. Alan's Venue & Entertainment Partnership Territory (7 Accounts Dossier)

### Summary Comparison: Revenue-Share vs. Floor-Rental Math Across Alan's 7 Venues

| Lead ID & Venue | Target Deal Structure | Retail Price Paid by Client | Venue Cut / Floor Fee | Osito Net Revenue | Osito Non-Labor COGS | **Founder-Led Net Profit (\$ / %)** | **Hired-Coach Net Profit (\$ / %)** |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **`OS-020` House of Air SF** *(Tier 1: Birthday Upgrade)* | **20% Partner Rev-Share** on 2-Hr Extended Party Add-On | \$400.00 | \$80.00 *(20% comm.)* | **\$320.00** | \$67.00 | **\$253.00** (`79.1%`) | **\$118.00** (`36.9%`) |
| **`OS-020` House of Air SF** *(Tier 2: Park Buyout Add-On)* | **20% Partner Rev-Share** on Half/Full Park Buyout `SHARD-75` Arena | \$1,500.00 | \$300.00 *(20% comm.)* | **\$1,200.00** | \$110.00 | **\$1,090.00** (`90.8%`) | **\$842.50** (`70.2%`) |
| **`OS-021` AcroSports SF** | **20% Partner Rev-Share** on \$400 Party Add-On *(or Wholesale \$320)* | \$400.00 | \$80.00 *(20% comm.)* | **\$320.00** | \$67.00 | **\$253.00** (`79.1%`) | **\$118.00** (`36.9%`) |
| **`OS-022` Circus Center SF** | **20% Partner Rev-Share** on Birthday / Friday Camp Showcase | \$400.00 | \$80.00 *(20% comm.)* | **\$320.00** | \$67.00 | **\$253.00** (`79.1%`) | **\$118.00** (`36.9%`) |
| **`OS-023` SPARK Social SF** *(Model A: All-In Turf Party)* | **Floor-Rental Bundle:** Osito charges \$550 All-In & pays \$150 2-Hr Fire Pit Rental | \$550.00 | \$150.00 *(\$75/hr × 2h)* | **\$400.00** | \$67.00 | **\$333.00** (`83.2%`) | **\$198.00** (`49.5%`) |
| **`OS-023` SPARK Social SF** *(Model B: Corp Offsite)* | **15% Venue Referral Fee** on 2-Hr Corporate `SHARD-75` Turf Activation | \$1,800.00 | \$270.00 *(15% comm.)* | **\$1,530.00** | \$110.00 | **\$1,420.00** (`92.8%`) | **\$1,172.50** (`76.6%`) |
| **`OS-024` SF Rec & Parks** | **Approved Insured Vendor:** Parent rents gym directly; pays Osito \$400 direct | \$400.00 | \$0.00 *(Parent pays RPD)* | **\$400.00** | \$67.00 | **\$333.00** (`83.2%`) | **\$198.00** (`49.5%`) |
| **`OS-026` SPIN San Francisco** | **20% Preferred Vendor Markup** on \$2,200 Corporate Ping-Pong + Drone Buyout | \$2,200.00 | \$440.00 *(20% comm.)* | **\$1,760.00** | \$110.00 | **\$1,650.00** (`93.8%`) | **\$1,402.50** (`79.7%`) |
| **`OS-027` Emporium SF** | **15% Venue Commission** on \$2,000 Skydeck / Private Buyout `SHARD-75` Arena | \$2,000.00 | \$300.00 *(15% comm.)* | **\$1,700.00** | \$110.00 | **\$1,590.00** (`93.5%`) | **\$1,342.50** (`79.0%`) |

---

### Account-by-Account Dossiers & Partnership Pitches

#### 1. `OS-020` — House of Air San Francisco (The Presidio)
- **Address:** Building 926, 926 Mason St (Crissy Field), The Presidio, San Francisco, CA 94129
- **Contacts:** General Manager **Daniel Matsumoto** & Events Team | 📞 `(415) 345-9675` | ✉️ `management@houseofair.com` / `info@houseofair.com` | 🌐 [houseofair.com/events](https://www.houseofair.com/events)
- **Verified Venue Pricing & Operations Intelligence:**
  - **CRITICAL STRATEGIC INTEL:** House of Air announced it will permanently close after 16 years on **February 15, 2027** due to lease disagreements with the Presidio Trust. Between now and Feb 15, 2027, weekend birthday tables and corporate buyouts are in high demand as SF families book "farewell" parties.
  - **Existing Birthday Tiers (10 Jumpers baseline):**
    - *Green Circle (General Access):* **\$500** (1 hr jump + 1.5 hr party table)
    - *Black Diamond (Training Ground, Ages 7+):* **\$650** (1 hr access + 1.5 hr table)
    - *Blue Square (Ultimate Airtime):* **\$900** (2 hr jump + 2.5 hr party table)
    - *Double Black (Training Ground, Ages 7+):* **\$1,300** (2 hr access + 2.5 hr table)
  - **Private Zone & Facility Buyouts:** *South Matrix Buyout* (**\$950**, 20–25 guests), *Dodgeball Colosseum Buyout* (**\$950**, up to 20 guests), *Half Park Buyout* (**\$2,450**, 50–60 guests), *Full Facility Buyout* (**\$3,650**, 70–80+ guests).
- **Alan's Two-Pronged Partnership Pitch:**
  1. **Immediate High-Margin Add-On Through Feb 2027 (Zero Extra Space Needed):** During the 90–150 minute party table window on *Blue Square* (\$900) and *Double Black* (\$1,300) packages—or during *Half/Full Park Buyouts* (\$2,450–\$3,650)—Osito pops up the `101"×101"` netted `SHARD-75` Aerial Combat Tent right beside the party tables. House of Air pockets **20% (\$80 on a \$400 birthday upgrade; \$300 on a \$1,500 buyout activation)** with zero staff labor required.
  2. **Post-February 2027 Presidio Parent Referral Alliance:** As House of Air winds down toward Feb 15, 2027, offer Daniel Matsumoto and his events team a **15% outbound referral commission** on every Presidio/Marina birthday inquiry they refer to Osito's mobile birthday packages (hosted at Presidio Trust picnic/indoor spaces, AcroSports, or SPARK Social).

#### 2. `OS-021` — AcroSports San Francisco (Cole Valley / Haight)
- **Address:** 639 Frederick St, San Francisco, CA 94117 (501(c)(3) Nonprofit Youth Gymnastics & Circus Arts Center)
- **Contacts:** Party & Events Coordinator / Customer Experience Team | 📞 `(415) 665-2276` | ✉️ `info@acrosports.org` | 🌐 [acrosports.org](https://acrosports.org)
- **Verified Venue Pricing & Operations Intelligence:**
  - **Standard Youth Birthday Package:** **\$475** for up to **25 participants** (ages 5+).
  - **Exact 2-Hour Party Structure:** **1 hour 15 minutes** on the main gym floor (trampolines, tumble track, obstacle courses, foam pit) led by **2 dedicated AcroSports Birthday Coaches**, followed by **45 minutes upstairs** in the party/dining area (tables with colorful oilcloth tablecloths & fridge provided).
  - **Pain Point:** Parents booking for older kids (ages 8–13) love the gym floor but want a high-tech activity during the second half or for kids resting between tumbling rotations, and AcroSports books out 6–8 weeks in advance.
- **Alan's Partnership Pitch & Rev-Share Math:**
  - **Option A — Upstairs / Annex Party Upgrade (\$200 Solo Pilot / \$400 Extended):** Add an *"AcroSports + Osito Aerial & Drone Engineering Party Upgrade"*. For \$200 (60-min) or \$400 (2-hr with hover pods/FPV), Osito pays AcroSports a **20% nonprofit mission contribution (\$40–\$80 per party)**.
  - **Option B — School-Break & Summer Camp Co-Lab (`PKG-3A`):** Co-host a *"Tumble & Fly: Acrobatics + Micro-Drone Engineering Camp"* during SFUSD holiday breaks (Morning AcroSports gymnastics + Afternoon Osito `CUB-75` 4-station STEM lab).

#### 3. `OS-022` — Circus Center San Francisco (Cole Valley)
- **Address:** 755 Frederick St, San Francisco, CA 94117 *(1 block west of AcroSports, steps from Golden Gate Park & Kezar Stadium)*
- **Contacts:** Youth Program & Events Director | 📞 `(415) 759-8123` | ✉️ `youth@circuscenter.org` | 🌐 [circuscenter.org](https://circuscenter.org)
- **Verified Venue Pricing & Operations Intelligence:**
  - Operates the Bay Area's only indoor flying trapeze rig inside a massive historic gymnasium at 755 Frederick St.
  - Runs **Private Milestone Birthdays & Corporate Team-Building Events**, weekly **Recreational Youth Classes**, and multi-week **Circus Day Camps** that culminate every Friday in a live showcase for parents.
- **Alan's Partnership Pitch & Rev-Share Math:**
  - **Birthday & Corporate Trapeze Waiting-Line Solver:** On a flying trapeze rig, only 1 person can climb and swing at a time while 12–20 guests wait on the floor. Placing Osito's `101"×101"` netted `SHARD-75` Combat Arena or `CUB-75` FPV Hover Station on the gym floor keeps waiting guests 100% engaged in 3-minute heats!
  - **Rev-Share Structure:** **20% commission (\$80)** to Circus Center on \$400 youth birthday add-ons, and **20% (\$360)** on \$1,800 corporate trapeze + drone combat team-building packages.

#### 4. `OS-023` — SPARK Social SF (Mission Bay)
- **Address:** 601 Mission Bay Blvd North, San Francisco, CA 94158 *(Operated by Parklab, adjacent to Stagecoach Greens Mini Golf & UCSF/Chase Center)*
- **Contacts:** Events & Activations Manager (Tripleseat Portal) | 📞 `(415) 851-1260` | ✉️ `info@sparksocialsf.com` | 🌐 [sparksocialsf.com](https://sparksocialsf.com)
- **Verified Venue Pricing & Operations Intelligence:**
  - **Fire Pit Rentals (Birthday & Small Group Hub):** Individual fire pits (*Big Sur*, *Angel Island*, etc.) seat 8 guests with standing room for **up to 20 guests** per pit. Pricing is **\$60/hr (Mon–Wed)** and **\$75/hr (Thu–Sun)** (1-hr minimum, includes s'mores kit; outside food/alcohol prohibited except birthday cake/cupcakes).
  - **Corporate Offsites & Buyouts:** Custom quotes via Tripleseat for private lawn alcoves, the vintage Double-Decker Bus, Beer/Sangria Garden, and combos with Stagecoach Greens Mini Golf.
  - **Why Osito Wins Outdoors Here:** Normally, outdoor drones near Chase Center/Mission Bay trigger wind drift and FAA/crowd safety worries. Because Osito's `101"×101"×84"` Alvantor battle tent is **100% enclosed in heavy-duty no-see-um mesh**, the FAA classifies an enclosed netted structure as an **indoor/contained operation**—zero flyaways, zero wind loss, and 100% safe on the turf!
- **Alan's Partnership Pitch & Floor-Rental vs. Rev-Share Math:**
  - **Weekend Kids Birthday "S'mores & Drones" Turf Package (\$550 All-In or \$400 Add-On):**
    - *Parent-Rented Pit:* Parent books a fire pit directly with SPARK (\$150 for 2 hrs Thu–Sun) and books Osito's Extended 2-Hr Party (\$400). If referred by SPARK's booking page, Osito pays SPARK a **20% (\$80) commission** (SPARK makes \$150 pit + \$80 drone cut = **\$230 total**; Osito nets **\$320 revenue / \$253 Founder Net Profit**).
    - *Turnkey Osito Turf Package:* Osito charges parents **\$550 All-In**, rents the 2-hour turf/fire-pit zone for **\$150**, and nets **\$400 revenue / \$333 Founder Net Profit (83.2% margin)**.
  - **Weekday Tech Team Offsite Add-On (\$1,800 `PKG-5A`):** Pitch Parklab's corporate sales team to list the `SHARD-75` Combat Arena alongside Stagecoach Greens Mini Golf as an interactive add-on for Mission Bay biotech/AI team offsites (15% venue commission = **\$270 to SPARK / \$1,530 net to Osito**).

#### 5. `OS-024` — SF Recreation & Parks (Indoor Facility Rentals)
- **Address:** McLaren Lodge, 501 Stanyan St, San Francisco, CA 94117 *(Permits for Moscone, Eureka Valley, Bernal Heights, Sunset, Potrero Hill & Mission Rec Center Gyms)*
- **Contacts:** Permits & Reservations Coordinator | 📞 `(415) 831-5500` | ✉️ `RPDReservations@sfgov.org` | 🌐 [sfrecpark.org](https://sfrecpark.org)
- **Verified Municipal Permit & Insurance Rules:**
  - **Booking Window & Deposit:** Parents reserve indoor gyms/multipurpose rooms **30 to 90 days in advance** during non-program weekend hours, paying an hourly rental fee plus a refundable **\$250+ security deposit**.
  - **Facility Restrictions:** Standard SF Rec & Park gyms **do not** have a Dance Hall License (no heavy amplified DJs) and prohibit floor-scuffing equipment or open-flame catering.
  - **City Insurance Trigger:** When a third-party commercial vendor operates interactive equipment inside an SF Rec & Park facility, the vendor must provide a **\$1,000,000 per occurrence / \$2,000,000 aggregate Commercial General Liability COI** with an **Additional Insured Endorsement** explicitly naming: *"The City and County of San Francisco, the Recreation & Park Department, and its agents, employees, and commissioners."*
- **Alan's Partnership Pitch & Execution Plan:**
  1. **Pre-File Osito's Master COI with `RPDReservations@sfgov.org`:** By having Osito's blanket Additional Insured endorsement and Bat-Safe/TPU non-marking floor certification already on file at 501 Stanyan St, Alan can advertise Osito to SF parents as **"100% Pre-Cleared for SF Rec & Park Gymnasium Birthdays (Eureka Valley, Moscone, Bernal Heights, Potrero Hill)."**
  2. **Zero Venue Commission (`100% Direct Margin`):** Because the parent pays SF Rec & Park directly for the gym permit, Osito retains **100% of the \$200 / \$400 party fee** (**\$333.00 Founder Net Profit / 83.2% margin** on `PKG-4B`).

#### 6. `OS-026` — SPIN San Francisco (SoMa Corporate Tournament Hub)
- **Address:** 690 Folsom St, Suite 100, San Francisco, CA 94107 *(SoMa / Yerba Buena, 1 block from Moscone Center)*
- **Contacts:** Private Events Sales Manager | 📞 `(415) 432-8685` / `(415) 636-5995` | 🌐 [wearespin.com/location/san-francisco](https://wearespin.com/location/san-francisco/)
- **Verified Venue Pricing & Operations Intelligence:**
  - **Layout:** 12,000 sq ft social club with **18 Stiga ping-pong tables** (13 on the main floor + a **Private Room** with its own dedicated bar, lounge seating, and private tables; full buyouts up to 400–500 guests).
  - **Corporate Pricing Benchmarks:** Small group packages (4–20 guests) run **\$55–\$70/person** for 2 hours (*Beer & Wine* \$55, *Call Brand* \$60, *Top-Shelf* \$70); larger corporate offsites book on custom F&B minimums + "SPIN Pro" tournament brackets.
- **Alan's Partnership Pitch & Rev-Share Math:**
  - **The "Ping-Pong + Drone Dogfighting" Dual Bracket:** Tech companies booking SPIN's Private Room or a 50–150 person floor buyout love tournament brackets. By temporarily sliding 1 ping-pong table aside (`9 ft × 5 ft` table footprint), Osito's `101"×101"` (`8.4 ft × 8.4 ft`) netted `SHARD-75` Aerial Combat Cage drops into the exact footprint of a single ping-pong table!
  - **Pricing & Commission:** SPIN's Private Events Manager pitches the `SHARD-75` Combat Arena to corporate clients at **\$2,200 (2-Hr) or \$3,600 (4-Hr)** and retains a **20% preferred vendor commission (\$440–\$720 pure profit for SPIN)**, while Osito nets **\$1,760–\$2,880** (**\$1,650 Founder Net Profit / 93.8% margin** on the 2-hour activation).

#### 7. `OS-027` — Emporium SF Arcade Bar (NOPA / Divisadero)
- **Address:** 616 Divisadero St, San Francisco, CA 94117 *(Historic 4-Level Harding Theater)*
- **Contacts:** Private Events Manager | 📞 `(773) 697-7922` | ✉️ `sf@emporiumarcadebar.com` | 🌐 [emporiumarcadebar.com/locations/san-francisco](https://www.emporiumarcadebar.com/locations/san-francisco/)
- **Verified Venue Pricing & Operations Intelligence:**
  - **Layout & Tiers:** 4-level historic theater (up to 900 full buyout capacity).
    - *Small Groups (<40 guests):* **Free table reservations** with no minimum tab and a **BYOF (Bring Your Own Food)** policy.
    - *Semi-Private Level Rental — **The Skydeck**:* Top level accommodating up to **225 guests** with its own private full bar.
    - *Main Stage & 50-Foot Movie Screen:* Full stage with pro sound/lighting and a massive **50-foot theater screen** + multiple HD TVs.
- **Alan's Partnership Pitch & Rev-Share Math:**
  - **"Live FPV Drone Combat on the 50-Foot Harding Theater Screen":** When a gaming studio, AI startup, or tech team rents **The Skydeck** (up to 225 guests) or books a full theater buyout, Osito sets up the `101"×101"` `SHARD-75` Combat Cage on the stage or Skydeck and plugs our **5.8GHz Diversity FPV video receiver HDMI output directly into Emporium's 50-foot movie screen / Skydeck TVs**. Guests drink craft beer while watching live cockpit dogfights and magnetic armor explosions on the giant screen!
  - **Pricing & Commission:** Quoted at **\$2,000 (2-Hr Skydeck Activation)** or **\$3,500 (4-Hr Full Buyout Tournament)** with a **15% venue commission (\$300–\$525)** to Emporium's events team (**\$1,700 net to Osito / \$1,590 Founder Net Profit / 93.5% margin**).

---

## 6. Operations & Safety Checklist for Venue Managers

Alan includes this 1-page **Venue Risk & Operations Sheet** with every partnership pitch to eliminate facility manager objections on the spot:

### A. Insurance & Regulatory Compliance
- [x] **\$1M / \$2M Commercial General Liability (CGL) + Aviation Coverage:** Same-day Additional Insured Certificate of Insurance (COI) issued naming the host venue, property owner (e.g., Presidio Trust, City & County of SF, Parklab), and officers.
- [x] **100% FAA Indoor / Net-Contained Exemption:** All `SHARD-75` combat flights occur inside a fully enclosed `101"×101"×84"` no-see-um mesh tent (classified as a contained indoor structure—zero FAA airspace authorization required, even on outdoor turf at SPARK Social).
- [x] **Sub-40-Gram Featherweight Aircraft:** Both `OSITO CUB-75` (`39.5g` AUW) and `SHARD-75` (`38.8g` AUW) weigh **less than a golf ball (`45.9g`)** and **84% below the FAA's `250g` registration threshold**—producing less than `0.3 Joules` of kinetic energy on wall bounce.

### B. Facility Surface, Wall & Guest Protection
- [x] **Non-Marking 360° TPU 95A Bumpers & Skids:** `CUB-75` drones feature slip-on 360° soft thermoplastic polyurethane (`TPU 95A`) bumper belts and `52mm` wide flexible skids—guaranteed zero scuffing on hardwood basketball courts, gymnastics mats, or painted drywall.
- [x] **Full Top-and-Bottom Finger Guards:** Unlike consumer toy drones with open top/bottom blades, `CUB-75` encloses its `40mm` props inside `10mm` tall 360° ducts with **3 upper arched ribs and 4 lower radial struts**—impossible for a child's finger to touch a spinning blade.
- [x] **Instructor Master Kill Switch & ELRS Wireless Buddy-Box:** Every student controller is wirelessly linked to the Osito Flight Coach's master radio; releasing a single spring switch instantly returns control to the instructor or disarms the motors in `<15 milliseconds`.

### C. Indoor LiPo Battery Fire Safety Protocol (`Bat-Safe` Standard)
- [x] **Micro 1-Cell (`1S 550mAh`, `13.8g`, `3.8V`) Chemistry Only:** Youth classes and `SHARD-75` arena events use tiny single-cell `1S` packs encased in shock-absorbing TPU belly cradles (never exposed high-voltage multi-cell racing bricks).
- [x] **Certified Fireproof `Bat-Safe` Steel Enclosures:** 100% of on-site battery charging and storage happens inside double-walled insulated steel **Bat-Safe** boxes equipped with flame arrestors and fiberglass smoke filters.
- [x] **Smart Current-Regulated Charging (`VIFLY WhoopStor V3`):** Packs are charged at a gentle `1.3A` (~22 mins) and automatically discharged to a safe `3.80V` storage voltage immediately after the event.

### D. Footprint, Power & Setup/Teardown Timeline
| Operational Parameter | `SHARD-75` Netted Combat Arena | 4-Station Youth STEM / Birthday Setup |
| :--- | :--- | :--- |
| **Floor Footprint Required** | **`9 ft × 9 ft` (`101"×101"` Tent)** + `6 ft` spectator table (`84"` ceiling height) | **1 Standard Classroom, Party Room, or Quarter-Gym** (`20 ft × 20 ft` min) |
| **Power Requirement** | **1 Standard 110V Wall Outlet** (`<150W` total draw for charger + LED scoreboard)—or 100% battery-powered via Osito's portable LiFePO4 power station (for SPARK Social turf). | **1–2 Standard 110V Wall Outlets** (`<300W` total draw for USB-C soldering irons & 1S chargers). |
| **Load-In & Setup Time** | **15 Minutes** (2 Pelican cases on a folding cart; pop-up fiberglass hub tent opens in 90 seconds). | **20 Minutes** (Pop-up neon LED gates, Hover Pods, laptop simulators, and Bat-Safe station). |
| **Teardown & Load-Out Time** | **10 Minutes** (Zero confetti, zero tape residue, zero trash left behind). | **15 Minutes** (Complete tool & battery count check before departure). |
