# Team Jesus (CTO) — Makerspace, Community STEM & Live Hardware Demo Playbook

**Owner:** **Jesus Aceves** — CTO & Co-Founder, Osito Drone Services  
**Direct Contact:** `jesus@ositodrone.com` | `415.269.1206`  
**3-Man Strike Team Roster:**
- **Miguel Flores (CEO & Co-Founder):** Independent K-8 Schools, Community Centers & Extended Day Accounts (`miguel@ositodrone.com` | `415.571.6614`)
- **Alan Musselman (COO & Co-Founder):** Corporate Venues, Team-Building Agencies & Birthday Partners (`alan@ositodrone.com` | `415.810.4158`)
- **Jesus Aceves (CTO & Co-Founder):** Makerspaces, DCYF-Funded Community STEM/Workforce Partners, & Lead Hardware Demo Closer (`jesus@ositodrone.com` | `415.269.1206`)

**Core Technical References:**
- Classroom Trainer PRD: [`CUB-75_PRD_and_Blueprint.md`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/CUB-75_PRD_and_Blueprint.md)
- Aerial Combat / Bumper Arena PRD: [`KODIAK-75_PRD_and_Blueprint.md`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Bumper%20Drones/KODIAK-75_PRD_and_Blueprint.md) (`SHARD-75` / `KODIAK-75` 75mm Open-Prop & 360° Guarded Magnetic Breakaway Architecture)
- Event Handout: [`OSITO_KODIAK75_Event_Handout.html`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Bumper%20Drones/OSITO_KODIAK75_Event_Handout.html)
- Master Lead Tracker: [`Osito_SF_Sales_Leads_Tracker.csv`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Osito_SF_Sales_Leads_Tracker.csv)

---

## 1. Jesus's Strategic Role in the 3-Man Strike Team

While **Miguel** opens doors with K-8 Heads of School and Extended Day Directors and **Alan** structures high-margin revenue-share and corporate event activations, **Jesus is the technical wedge that turns skeptical buyers into instant believers**.

### Three Core Responsibilities:
1. **Owner of the 6 Makerspace, Community STEM & Workforce Accounts (`OS-001`, `OS-002`, `OS-003`, `OS-015`, `OS-016`, `OS-030`):**
   - Makerspace founders, shop teachers, and community science directors do not respond to generic sales pitches—they respond to **builders**. When Jesus walks into Mission Science Workshop, Tinkering School, or CYC with an in-house 3D-printed `PETG-CF` / `PC-CF` airframe, a custom motor-shaft press jig ([`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl)), and an open Betaflight CLI configuration, he speaks peer-to-peer as a fellow engineer and educator.
2. **DCYF & Grant-Funded Community STEM Lead:**
   - San Francisco's **Department of Children, Youth and Their Families (DCYF)** funds Out-of-School Time (OST), STEAM enrichment, and Youth Workforce Development across grantees like **Mission Science Workshop (`OS-002`)**, **Community Youth Center / CYC (`OS-015`)**, and **JCYC Workhub / SF STEM Academy (`OS-016`)**. Jesus positions Osito's **Station 1 (Soldering, Multimeter Diagnostics & 3D-Printed CAD Repair)** and **Station 2–4 (Simulator to FPV Flight)** as turnkey, grant-compliant technical modules with concrete, measurable youth learning outcomes.
3. **"The Closer via the 10-Minute Live Hardware Demo" (Supporting Miguel & Alan):**
   - **With Miguel at K-8 Schools (`OS-004` to `OS-014`):** School principals and auxiliary directors have one overriding fear: *“Will a drone cut a 7-year-old's finger or gouge our classroom drywall?”* Jesus eliminates that objection in 90 seconds by handing them a hovering `39.5g CUB-75` and inviting them to press their fingers directly against the top/bottom finger cages and bounce the `TPU 95A` bumper off their desk.
   - **With Alan at Corporate & Birthday Venues (`OS-020` to `OS-029`):** Event managers at The Midway, SPIN SF, and House of Air want visceral spectacle with zero venue liability. Jesus closes them by snapping magnetic `N52` breakaway armor shards/crowns onto the `38g SHARD-75` (`KODIAK-75`), demonstrating `<0.5s` Betaflight Active Crash Recovery, and showing how the `101" × 101"` netted pop-up tent contains 100% of the kinetic action.

---

## 2. Technical Selling Points Matrix (Extracted from PRDs)

Before stepping into any demo or makerspace meeting, Jesus anchors the conversation on **five verifiable engineering advantages** built in-house by Osito:

| Engineering Pillar | `OSITO CUB-75` (Classroom & Camp Trainer) | `SHARD-75` / `KODIAK-75` (Aerial Combat & Bumper Arena) | Why Buyers Care (The "So What?") |
| :--- | :--- | :--- | :--- |
| **1. Mass & Power Architecture** | **`25.7g` Dry / `39.5g` AUW** with `1S 550mAh LiHV` pack in an under-belly `70.0 × 18.5 × 7.5mm` TPU tunnel (**6.0–7.5 min flight time** vs. 2.5 min on 300mAh toys). | **`37.1g` (LOS) / `38.8g` (FPV) AUW** on `1S 550mAh LiHV` (`BT2.0`/`A30` high-current lead) delivering **4.5–6.0 min** of high-load dogfighting (enough for full 3-minute tournament heats). | Instructors don't spend half the class swapping dead batteries; sub-40g mass means near-zero kinetic hazard indoors. |
| **2. Finger, Wall & Net Protection** | **`10.0mm` tall 360° ducts** (`42.0mm` ID for `40mm` props) + **3 upper arched finger-guard ribs + center hub ring** + **4 bottom radial motor struts** + slip-on **Neon `TPU 95A` 360° wall-bounce bumper belt** ([`CUB75_TPU_Bumper_Ring.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_TPU_Bumper_Ring.stl)). | **`75.0mm` CarbonX `PC-CF` / `ePA-CF` chassis** with **sandwich-printed `TPU 95A + ePA-CF` Net-Deflection Standoff Horns** (`105.0mm` span, clearing blades by `5.0mm`) or 360° carbon-polymer prop hoops inside a **`101" × 101"` (`2.56m × 2.56m`) netted tent**. | **100% finger-safe from top, bottom, and sides** for ages 6+; zero black scuff marks on school drywall or gym floors; zero net entanglement in the battle tent. |
| **3. Magnetic Breakaway & Modularity** | Tool-free swap between **LOS "Osito Cub" Directional Canopy** ([`CUB75_Canopy_LOS_CubDome.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Canopy_LOS_CubDome.stl) with `+X` nose arrow & bear-ear roll hoops) and **10° Nano FPV Camera Pod** ([`CUB75_Canopy_FPV_Pod.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Canopy_FPV_Pod.stl)). | **4-Zone `N52` (`2×1mm` / `5×2mm`) Magnetic Breakaway Armor System** (`1×` Top Crown = `+2 pts`, `2×` Cheek Shields/Wings = `+1 pt ea`, `1×` Belly Skid = `+1 pt`; total armor mass $\le 2.1\text{g}$, shifting CoG $<1.5\text{mm}$ when shed). Recessed `0.20mm` anti-shatter TPU magnet sockets + `0.5mm` shear keyway. | Creates a real-life video game ("Smash Armor, Keep Flying!") with **2,080+ snap-on loadout combinations** (Bear Ears, Dragon Spikes, Starfighter Wings) that kids & tech employees obsess over. |
| **4. Firmware & Flight Control** | **3-Stage Progressive Betaflight 4.5 CLI** ([`CUB75_Betaflight45_Kids_Trainer_CLI.txt`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt)) switchable via transmitter sticks (Left Stick Up+Left, Right Stick Left):<br>• **Profile 0 (*Cub Mode*):** `22°` max tilt, `140°/s` rate, `68%` motor cap, `ANGLE + HEADFREE`<br>• **Profile 1 (*Scout Mode*):** `35°` max tilt, `260°/s` rate, `80%` motor cap, `ANGLE`<br>• **Profile 2 (*Pilot Mode*):** `50°` max tilt, `420°/s` rate, `92%` motor cap, FPV `25mW` VTX | **BetaFPV Matrix 1S `5-in-1` AIO FC** (`STM32G473` 170MHz, `ICM42688P` gyro, `12A` continuous / `18A` peak ESCs with **Bluejay 48kHz Bidirectional DShot** & RPM notch filtering). **Betaflight Active Crash Recovery** re-levels mid-air in **`<500ms`** after collisions; `AUX 3` **Turtle Mode** flips inverted drones upright; `VTX Pit Mode (0mW)` protects thermal envelope in LOS mode. | A 6-year-old can hover safely in the first 5 minutes without slamming into ceilings, and two corporate executives can ram each other mid-air without dropping out of the sky. |
| **5. Bench Repair & Safety Tooling** | Plug-and-play `JST-1.25` motor sockets + 3D-printed **Motor Prop Press Jig** ([`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl)) prevents bent `1.5mm` shafts; all `1S 550mAh` packs charged at `4.35V` on **VIFLY WhoopStor V3** inside fireproof **Bat-Safe** steel enclosures. | Zero-solder field maintenance via `JST-1.25` motor plugs and `3-pin JST-SH` camera header; passes **4 QA Gates** (Prop-Free Runaway Disarm `<0.5s`, 15G Acro Retention, 45° Net Deflection Glancing Test, 10-Drop 2.5m Concrete Fatigue Test). | Turns crashes into a 3-minute student engineering lesson (*"Fly, Crash, Build, Repeat"*) and satisfies strict school/venue risk-management and fire marshals. |

---

## 3. Account-by-Account Dossier: Jesus's 6 Makerspace & Community STEM Accounts

### Strategic Note on Pitching San Francisco DCYF-Funded Nonprofits (`OS-002`, `OS-015`, `OS-016`)
The **San Francisco Department of Children, Youth and Their Families (DCYF)** funds community-based organizations under Service Areas including **Out-of-School Time (OST) Enrichment**, **STEAM Learning**, and **Youth Workforce Development (High School & Transitional Age Youth 14–24)**.
- **How DCYF Grantees Buy:** Nonprofits like **Mission Science Workshop**, **CYC**, and **JCYC** operate on fiscal-year grant budgets (July 1 – June 30) plus summer programming allocations (`Summer Together` / DCYF Summer learning). They frequently have unspent **"Specialized Contractor / Guest Instructor / Program Supplies"** line items ($2,500–$6,000) that must be encumbered before spring/summer deadlines, or they write specialist partners directly into their upcoming grant renewals.
- **How Jesus Frames the Pitch for DCYF Alignment:**
  1. **Tangible Skill Acquisition & PBA (Project-Based Assessment):** Every student completes a measurable artifact—soldering a practice circuit, assembling a 3D-printed `CUB-75` frame using [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl), and logging flight progression from *Cub Mode* (`22°`) to *Scout Mode* (`35°`).
  2. **Bilingual & Culturally Accessible Delivery:** Emphasize hands-on, visual, tool-first instruction where youth in the Mission, Excelsior, Chinatown/Richmond, and Western Addition see Latino/local San Francisco founders leading aerospace engineering.
  3. **All-Inclusive Per-Student Unit Economics:** Quote clear, audit-ready flat cohort rates (e.g., **$2,500 for a 4-week hands-on workshop series for 16 youth = $156.25/student total**, or **$39/student per session**, all hardware, soldering stations, and 1:4 instructors included).

---

### Account 1: `OS-001` — STEMful San Francisco
* **Address:** 30 29th St, San Francisco, CA 94110 (Bernal Heights / Mission border)
* **Phone / Email / Web:** `(415) 660-5975` | `info@stemful-sf.com` | https://sf-stemful.com
* **Key Decision-Maker:** **Kim Nguyen-Ehrenreich** — Founder & Creative Managing Director (scientist-turned-educator who built STEMful around curiosity-driven STEAM play for ages 1–12).
* **Current Programs & Schedule:**
  - Runs **Summer Camps** & **School Break Camps** (week-long themed STEAM camps for elementary students), **Afterschool Enrichment Programs**, **School Partnerships** (bringing STEAM classes onto SF school campuses), **Weekend Birthday Parties**, and Friday **"Movie / Parents' Night Out"** events at their 30 29th St studio.
* **Estimated Deal Value:** `$3,500 – $8,000 / season`
* **Jesus's Technical Hook & Partnership Pitch:**
  - STEMful excels at general elementary science (chemistry, biology, simple machines) for ages 4–10, but lacks a high-tech **Micro-Aviation, CAD & Flight Control module** for their older camper tier (ages 7–12).
  - **Pitch Two Turnkey Revenue Streams:**
    1. **Co-Branded School-Break & Summer Camp Track:** *"Micro-Aviation & 3D-Printed Drone Engineering Week"* hosted at 30 29th St. Osito provides the 1:4 flight instructors, `CUB-75` fleet, laptop simulators, and soldering bench; STEMful handles registration and parent marketing (`60/40` or flat `$3,500–$4,500/week` cohort fee).
    2. **STEMful Birthday Party "Drone Flight Lab" Upgrade:** Offer Osito's 60-minute `$200–$400` `CUB-75` indoor hover-and-obstacle party add-on for parents booking STEMful's 29th St space on weekends.
* **Custom Outreach Email (Jesus to Kim Nguyen-Ehrenreich):**
  > **Subject:** Bernal/Mission neighbor: 39.5g 3D-printed Kid-Safe Drone Lab for STEMful camps?
  >
  > Hi Kim,
  >
  > I’m Jesus Aceves, CTO and Co-Founder of **Osito Drone Services** right here in SF. We love what you’ve built at **STEMful** on 29th St—especially how you make real science tactile and confidence-building for elementary kids.
  >
  > Because standard toy drones have exposed top/bottom propellers and 2-minute batteries that frustrate young learners, I engineered our **`39.5g OSITO CUB-75` classroom trainer** in-house specifically for indoor spaces like STEMful:
  > - **100% Finger-Safe & Drywall-Safe:** 360° full-height ducts with 3 upper arched finger-guard ribs, 4 bottom struts, and a soft `TPU 95A` bumper ring that bounces gently off walls and tables.
  > - **3-Stage Betaflight Firmware (*Cub → Scout → Pilot*):** We cap beginner motor power at `68%` and max tilt at `22°` with auto-leveling so a 7-year-old can hover safely in 5 minutes, while getting 6.5 minutes of flight per `1S 550mAh` battery.
  > - **"Fly, Crash, Build, Repeat" Bench Work:** Kids learn how our `PETG-CF` and `TPU` 3D-printed parts fit together, press props with custom jigs, and test real electronics.
  >
  > I’m right in the Mission/Bernal neighborhood this week—could I swing by **30 29th St** for 10 minutes to let you hold the `CUB-75`, test the finger cages while it’s hovering on a table, and explore partnering on a **School-Break Camp track or Weekend Workshop**?
  >
  > Best,  
  > **Jesus Aceves**  
  > CTO & Co-Founder | Osito Drone Services  
  > 415.269.1206 | jesus@ositodrone.com

---

### Account 2: `OS-002` — Mission Science Workshop (MSW)
* **Addresses:**
  - **Mission Site:** 3750 18th St, San Francisco, CA 94114 (historic auto-shop space at Mission High School, near Church St / Dolores Park)
  - **Excelsior Site:** 4458 Mission St, San Francisco, CA 94112
  - **Bayview Site:** 50 Pomona St, San Francisco, CA 94124 (inside Charles Drew Elementary)
* **Phone / Email / Web:** `(415) 621-1240` | `paul@missionscienceworkshop.org` | https://www.missionscienceworkshop.org
* **Key Decision-Makers:**
  - **Sonia Gandiaga** — Executive Director (leads MSW's citywide programs, Title I school partnerships, and DCYF/foundation grants, carrying forward late founder Dan Sudran's grassroots tinkering legacy).
  - **Paul** (`paul@missionscienceworkshop.org`) — Site Coordinator / Bayview & Program Operations Lead.
* **Current Programs, Funding & Schedule:**
  - Serves thousands of SFUSD Title I students, bilingual (Spanish/English) families, and neighborhood youth through **School-Day Field Trips**, **After-School Tinkering Programs**, **Summer Camps**, and **Free Community Drop-In Science Saturdays** (typically 3rd Saturdays / monthly open shop days where neighborhood families build wooden toys, take apart electronics, and explore physics).
  - Heavily supported by **SF DCYF**, SFUSD partnerships, and local family foundations (Hellman Foundation, etc.).
* **Estimated Deal Value:** `$2,500 – $6,000 / program series` (plus flagship grassroots parent/community funnel)
* **Jesus's Technical Hook & Partnership Pitch:**
  - MSW's entire ethos is *"tinkering with real tools, taking things apart, and seeing how electricity and mechanics work—no black boxes."* Consumer plastic drones violate MSW's philosophy because when they break, they go in the trash.
  - **Jesus pitches Osito's `CUB-75` as the ultimate Open-Hardware Tinkering Aircraft:**
    1. **Station 1 (Soldering, Multimeter Diagnostics & Motor Jig Assembly):** Show Sonia and Paul how MSW students use [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl), test continuity with multimeters, understand brushed vs. `0802 19,500KV` brushless 3-phase motors, and see how `52mm` wide TPU trainer skids absorb landing G-forces.
    2. **Bilingual Delivery (Spanish/English):** Jesus and Miguel can co-lead workshops in Spanish and English for Mission and Excelsior youth—an enormous differentiator for MSW's board and DCYF grant reporting.
    3. **Trojan-Horse Entry:** Offer to bring a **Free 2-Hour "Micro-Drone Tinkering & Hover Table"** to MSW's next **Community Drop-In Saturday** at `3750 18th St` or `4458 Mission St` to prove student engagement before locking in a paid `$3,500–$5,000` DCYF after-school or summer camp contract.
* **Custom Outreach Email (Jesus to Paul & Executive Director Sonia Gandiaga):**
  > **Subject:** Bilingual Micro-Drone Tinkering & Soldering Lab for Mission Science Workshop (Mission / Excelsior)
  >
  > Hola Paul and Sonia,
  >
  > I’m Jesus Aceves, CTO and Co-Founder of **Osito Drone Services** here in San Francisco. We have huge respect for **Mission Science Workshop’s** legacy of giving Mission, Excelsior, and Bayview youth real tools to tinker, build, and understand how the physical world works.
  >
  > Most youth drone programs hand kids sealed plastic toys that end up in a landfill the first time a motor wire snaps. We built our program around the exact opposite philosophy—**"Fly, Crash, Build, Repeat"**:
  > - **100% In-House 3D-Printed Open Airframe (`OSITO CUB-75`):** We print our own `39.5g` finger-safe frames (`PETG-CF`) and shock-absorbing `TPU 95A` bumpers and landing skids, and we bring raw frames, `0802` brushless motors, and custom 3D-printed prop-press jigs so kids actually assemble and repair the aircraft.
  > - **Station 1 Electronics & Soldering:** Students learn real soldering, continuity testing, and aerodynamic thrust physics before stepping up to our netted hover pods and `Cub Mode` (`22°` angle-capped) flight trainers.
  > - **Bilingual Instruction:** Our team leads workshops in both **Spanish and English**.
  >
  > We’d love to explore running a **After-School / Summer Tinkering Series** at **3750 18th St** or **4458 Mission St**—and to kick things off, I’d be thrilled to bring a free live demo table to an upcoming **Community Science Saturday** so your staff and kids can test the hardware firsthand.
  >
  > Could I drop by 3750 18th St for 10 minutes this week to show you the `CUB-75` and our repair station kit?
  >
  > Un saludo cordial,  
  > **Jesus Aceves**  
  > CTO & Co-Founder | Osito Drone Services  
  > 415.269.1206 | jesus@ositodrone.com

---

### Account 3: `OS-003` — Tinkering School (Presidio)
* **Address:** 682 Schofield Rd, San Francisco, CA 94129 (Presidio of San Francisco — co-located with Brightworks School `OS-004`)
* **Phone / Email / Web:** `(415) 562-6268` | `info@tinkeringschool.com` | https://www.tinkeringschool.com
* **Key Decision-Makers:**
  - **Gever Tulley** — Founder (author of *50 Dangerous Things You Should Let Your Children Do*, founder of Tinkering School & Brightworks).
  - **Camp Director / Presidio Program Lead** (oversees Summer Day Camps, Young Tinkerers, and Odyssey/after-school build tracks at 682 Schofield Rd).
* **Current Programs & Schedule:**
  - Runs intensive 1-week **Summer Day Camps**, **Spring/Winter Break Camps**, and **After-School Tinkering** for ages 6–14 at their Presidio warehouse/yard (`682 Schofield Rd`). Famous for trusting kids with real tools (drills, saws, soldering irons) to build go-karts, kinetic sculptures, and robotics.
  - **Bonus Co-Location Leverage:** Shares the exact same `682 Schofield Rd` building with **Brightworks School (`OS-004`, Miguel's account)**—meaning a single on-site hardware demo by Jesus and Miguel pitches **both** Tinkering School (`$4,000–$10,000/summer`) and Brightworks (`$3,500–$7,500/semester`).
* **Estimated Deal Value:** `$4,000 – $10,000 / summer or break camp series`
* **Jesus's Technical Hook & Partnership Pitch:**
  - Tinkering School loves **authentic engineering constraints, iterative prototyping, and real tools**.
  - **Pitch a Specialty 1-Week Camp Track: *"Build, Tune & Battle Your Own 3D-Printed Micro-Drone"*:**
    - **Days 1–2 (CAD, Materials & Bench Build):** Tinkerers examine the difference between rigid `CarbonX PC-CF` / `PETG-CF` structural arms and flexible `TPU 95A` energy-absorbing bumpers ([`CUB75_TPU_Bumper_Ring.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_TPU_Bumper_Ring.stl)), press `40mm` propellers using [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl), solder practice joints, and mount the `25.5 × 25.5mm` AIO flight controller on silicone vibration grommets.
    - **Days 3–4 (PID Tuning & Flight Progression):** Connect to Betaflight Configurator to see real-time `ICM42688P` gyroscope traces, test how changing max tilt from `22°` (*Cub Mode*) to `35°` (*Scout Mode*) alters flight authority, and design custom snap-on magnetic `N52` armor plates (Bear Ears, Dragon Spikes, Starfighter Wings from the **40-part Kodiak Garage library**).
    - **Day 5 (The Presidio Aerial Bumper Finale):** Pilots test their custom magnetic armor inside Osito's `101" × 101"` netted arena tent!
* **Custom Outreach Email (Jesus to Tinkering School Camp Director):**
  > **Subject:** Presidio Camp Track Idea: Build, Solder & Fly 3D-Printed Micro-Drones at 682 Schofield
  >
  > Hi Tinkering School Team,
  >
  > I’m Jesus Aceves, CTO of **Osito Drone Services** here in SF. Tinkering School’s philosophy—trusting kids with real tools, real materials, and iterative failure—is the exact blueprint we used to engineer our in-house micro-drone fleet.
  >
  > Instead of flying sealed off-the-shelf plastic drones, we designed two 100% 3D-printed 75mm micro-aircraft right here in our SF shop:
  > 1. **The `39.5g OSITO CUB-75` Trainer:** Printed in `PETG-CF` and `TPU 95A` with full top/bottom finger cages, a 360° wall-bounce bumper belt, and a 3-stage Betaflight firmware progression (*Cub → Scout → FPV Pilot*).
  > 2. **The `38g SHARD-75 / KODIAK-75` Magnetic Bumper Drone:** Equipped with 5 universal `N52` neodymium magnet sockets where kids can CAD, 3D-print, or snap on custom sacrificial armor (wings, crowns, skids) that shear off on mid-air impact inside our `101" × 101"` netted arena tent while Betaflight’s active crash recovery re-levels the drone in `<0.5s`.
  >
  > We’d love to co-develop a specialty **"Build, Solder & Fly Micro-Drones"** camp week or after-school arc at **682 Schofield Rd** (for both **Tinkering School** and **Brightworks**).
  >
  > Could my co-founder Miguel and I bring our backpack demo kit out to the Presidio next week for a 10-minute tabletop flight and hardware breakdown?
  >
  > Best,  
  > **Jesus Aceves**  
  > CTO & Co-Founder | Osito Drone Services  
  > 415.269.1206 | jesus@ositodrone.com

---

### Account 4: `OS-015` — CYC STEAM Maker Lab (Community Youth Center of SF)
* **Address:** 980 Clement St, San Francisco, CA 94118 (Richmond District Office & Maker Lab; HQ also in Tenderloin/Chinatown)
* **Phone / Email / Web:** `(415) 775-2636` | `cyc@cycsf.org` | https://www.cycsf.org
* **Key Decision-Makers:**
  - **STEAM Maker Lab Coordinator** (Richmond District Branch, `980 Clement St`).
  - **Sarah Ching-Ting Wan** — Executive Director of CYC (has led CYC since 2002, scaling its DCYF-funded youth workforce, Beacon Center, and Richmond STEAM initiatives).
* **Current Programs & Funding:**
  - Major **SF DCYF grantee** operating the **CYC STEAM Maker Lab at 980 Clement St**, where middle and high school youth learn **3D print design, coding, robotics, screenprinting, and engineering** for 21st-century career readiness.
* **Estimated Deal Value:** `$2,500 – $5,000 / grant-funded series`
* **Jesus's Technical Hook & Partnership Pitch:**
  - **Direct Tie-In to CYC's Existing 3D Printers:** CYC *already teaches 3D print design* at 980 Clement St, but static 3D prints (keychains, figurines) don't fly!
  - **Pitch: *"From CAD Slicer to Mid-Air Flight — The 3D-Printed Micro-Drone Engineering Lab"*:**
    - Jesus brings the open parametric CAD files ([`CUB75_Parametric_Master.scad`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Parametric_Master.scad)) and the **40-part `N52` Magnetic Snap-On Loadout Library** (`KODIAK75_Crown_*`, `KODIAK75_Cheek_*`, `KODIAK75_Belly_*` STL files).
    - CYC students can **slice and 3D-print their own custom `TPU 95A` canopies or magnetic breakaway armor plates on CYC's own 3D printers at 980 Clement St**, snap them onto Osito's `CUB-75` and `SHARD-75` drones during Osito's weekly flight & soldering lab, and test how their CAD geometry affects Center of Gravity (`<1.5mm` shift tolerance) and flight stability!
* **Custom Outreach Email (Jesus to CYC STEAM Maker Lab Coordinator):**
  > **Subject:** 980 Clement STEAM Maker Lab: Let CYC students fly the parts they 3D-print!
  >
  > Hi CYC STEAM Maker Lab Team,
  >
  > I’m Jesus Aceves, CTO and Co-Founder of **Osito Drone Services** here in San Francisco. I saw that your **STEAM Maker Lab at 980 Clement St** already teaches youth 3D print design, coding, and robotics—and I wanted to share a partnership idea that connects directly to the 3D printers in your lab.
  >
  > We manufacture our **`39.5g OSITO CUB-75` classroom training drone** and our **`38g SHARD-75` magnetic modular drone** 100% via FDM 3D printing (`PETG-CF`, `PC-CF`, and `TPU 95A`). Our frames feature universal `N52` magnetic sockets and modular canopies designed so students can CAD and 3D-print their own custom canopies, landing skids, and snap-on wing pods (`<0.8g` per piece), snap them onto our flight controllers, and immediately test their designs in flight!
  >
  > In a **4-to-8 week grant-funded workshop series at 980 Clement**, we bring a strict **1:4 instructor ratio** and our **4-Station Drone Academy**:
  > 1. **CAD & Hardware Bench:** Soldering, multimeter diagnostics, and fitting student-printed `TPU` parts onto our `75mm` airframes.
  > 2. **Flight Simulators:** Mastering pitch, roll, yaw, and throttle on laptops.
  > 3. **Indoor Hover Lab:** Flying our 100% finger-safe `CUB-75` (`22°` angle-capped *Cub Mode*).
  > 4. **FPV Goggles & Obstacle Course:** Navigating neon indoor gates via First-Person View goggles.
  >
  > Could I stop by **980 Clement St** for 10 minutes next week to show you our 3D-printed `CUB-75` airframes and discuss how this could fit your upcoming DCYF STEAM programming?
  >
  > Best regards,  
  > **Jesus Aceves**  
  > CTO & Co-Founder | Osito Drone Services  
  > 415.269.1206 | jesus@ositodrone.com

---

### Account 5: `OS-016` — SF STEM Academy (JCYC Workhub / Galileo High School)
* **Addresses:**
  - **JCYC Workhub HQ:** 1830 Sutter St, San Francisco, CA 94115 (Japantown / Western Addition)
  - **School Program Sites:** Galileo Academy of Science and Technology (`1150 Francisco St`) & Balboa High School (`1000 Cayuga Ave`)
* **Phone / Email / Web:** `(415) 921-5590` | `ajallow@jcyc.org` | https://www.jcycworkhub.com/sf-stem-academy
* **Key Decision-Maker:** **Alasan (Abdoulie) Jallow** — Program Coordinator / STEM Advisor (`ajallow@jcyc.org`).
* **Current Programs & Funding:**
  - Part of **JCYC (Japanese Community Youth Council) Workhub**, San Francisco's largest youth workforce provider (alongside MYEEP and SF YouthWorks), heavily backed by **SF DCYF**.
  - Runs in-class and after-school STEM career workshops at **Galileo High School** and **Balboa High School**, connecting SFUSD high schoolers to hands-on engineering skills, guest speakers, and paid summer internships.
* **Estimated Deal Value:** `$2,500 – $6,000 / workshop series` (plus pipeline for training paid high school assistant flight coaches via MYEEP/YouthWorks!)
* **Jesus's Technical Hook & Partnership Pitch:**
  - High schoolers (ages 14–18) at Galileo HS don't want "kiddie" toys—they want **career-grade embedded systems, avionics, and commercial UAV pathways**.
  - **Pitch a High-Impact Career & Engineering Module: *"Avionics, Betaflight Firmware, Soldering & Commercial Drone Pathways"*:**
    1. **Real Avionics Architecture:** Jesus walks students through the **BetaFPV Matrix 1S `5-in-1` AIO PCB** (`STM32G473CEU6` 170MHz ARM Cortex-M4 MCU, `ICM42688P` SPI gyro, `UART2` Serial ELRS 2.4GHz packet link, `UART1` 5.8GHz OpenVTX, and `48kHz` Bluejay ESCs with Bidirectional DShot RPM telemetry).
    2. **Hands-On Soldering & Diagnostics (Station 1):** High schoolers learn IPC-style wire tinning, `BT2.0` high-current connector soldering, multimeter short-circuit smoke-stopper testing, and Betaflight CLI rate/PID tuning.
    3. **Workforce Bonus Angle:** Offer to serve as a **JCYC Workhub / MYEEP Host Employer or Training Partner**, where top SF STEM Academy graduates can earn stipends assisting Osito at weekend STEM camps and events!
* **Custom Outreach Email (Jesus to Alasan Jallow):**
  > **Subject:** Hands-on Avionics, Soldering & FPV Drone Engineering Workshop for SF STEM Academy (Galileo HS / JCYC)
  >
  > Hi Alasan,
  >
  > I’m Jesus Aceves, CTO and Co-Founder of **Osito Drone Services** here in San Francisco. I’ve been following the awesome work **JCYC Workhub and the SF STEM Academy** are doing at **Galileo High School** and **1830 Sutter St** to connect SF youth with real-world STEM careers.
  >
  > We’d love to partner with you to bring a hands-on **Micro-Avionics, Soldering & FPV Flight Engineering Workshop** (either as a single-day intensive or a multi-week cohort) to your SF STEM Academy students:
  > - **Embedded Systems & Firmware:** Students look under the hood of our in-house 3D-printed `CUB-75` and `SHARD-75` drones—exploring `STM32G473` flight controllers, `ICM42688P` gyro filtering, `ELRS 2.4GHz` radio links, and Betaflight 4.5 CLI tuning.
  > - **Station 1 Soldering & Diagnostics:** Every student gets hands-on bench experience with soldering irons, multimeters, motor phase testing, and mechanical CAD assembly (`PETG-CF` / `PC-CF` and `TPU 95A`).
  > - **FPV Flight & Commercial Drone Pathways:** Students progress from laptop simulators to flying real First-Person View (FPV) goggles through indoor gates while learning how micro-aviation translates to commercial inspection, cinematography, and aerospace careers.
  >
  > Could I swing by **1830 Sutter St** (or meet you at Galileo) for 10 minutes next week to show you our 3D-printed aircraft and discuss your upcoming workshop calendar?
  >
  > Best regards,  
  > **Jesus Aceves**  
  > CTO & Co-Founder | Osito Drone Services  
  > 415.269.1206 | jesus@ositodrone.com

---

### Account 6: `OS-030` — Noisebridge Makerspace
* **Address:** 272 Capp St, San Francisco, CA 94110 (Mission District, between 17th & 18th St, 2 blocks from 16th St Mission BART)
* **Contact / Channels:** `secretary@noisebridge.net` | https://www.noisebridge.net | Live Calendar: https://noisebridge.today | Noisebridge Discord & Tuesday 7:00 PM Weekly Meeting
* **Key Community Touchpoints:**
  - **Tuesday Weekly Meeting (7:00 PM at 272 Capp St & Jitsi/Discord):** Where members, keyholders, and organizers introduce projects and announce upcoming community workshops.
  - **Circuit Hacking Mondays (Mondays at 7:00 PM):** Long-running beginner electronics and soldering night—prime overlap for Osito's **Station 1 Soldering & Micro-Drone Build**.
  - **Do-ocracy Culture:** Anyone can host a free/donation-supported workshop at Noisebridge as long as it is open to the community and coordinated with a member/philanthropist keyholder (note: workspace already contains `noisebridge_membership.pdf`!).
* **Estimated Deal Value:** `$500 – $2,000 / month` in direct DIY Kit/Frame sales + **High-Velocity Grassroots Lead Generation** for `$1,500–$5,000` Corporate Offsites (Alan) and `$3,000–$10,000` School/Camp Contracts & `$400` Birthday Parties (Miguel/Alan).
* **Jesus's Technical Hook & Partnership Pitch:**
  - Noisebridge is the beating heart of San Francisco's open-source hardware, hacker, and maker scene. By showing up at Tuesday 7:00 PM meetings with our OpenSCAD parametric generators ([`CUB75_Parametric_Master.scad`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Parametric_Master.scad)) and hosting a monthly **"SF Micro-Drone Build & SHARD-75 Battle Night"** at 272 Capp St, Jesus positions Osito as an iconic SF hardware startup (full blueprint in **Section 5** below).

---

## 4. The 10-Minute "Roadshow in a Backpack" Live Demo Script

Every time **Miguel** books a meeting with a K-8 school principal/Extended Day director, or **Alan** books a walkthrough with a corporate/birthday venue manager, **Jesus brings the "Roadshow in a Backpack"** to close the deal on the spot.

### Backpack Packing Checklist (Total Carry Weight: `< 4.8 lbs`, Zero Setup Delay)
1. **1× `OSITO CUB-75` Classroom Trainer (`39.5g` AUW)** — Pre-fitted with bright Neon `TPU 95A` 360° Bumper Ring ([`CUB75_TPU_Bumper_Ring.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_TPU_Bumper_Ring.stl)), green/yellow LOS "Osito Cub" Bear-Ear Directional Canopy ([`CUB75_Canopy_LOS_CubDome.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Canopy_LOS_CubDome.stl)), and `52mm` Wide-Stance Trainer Skids ([`CUB75_550mAh_Trainer_Skids.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_550mAh_Trainer_Skids.stl)).
2. **1× `SHARD-75` (`KODIAK-75`) Aerial Combat Drone (`38.4g` AUW)** — Loaded with **4 magnetic `N52` breakaway armor shards** (`1×` Top Bear-Ear or Dragon Crown, `2×` Starfighter/Booster Cheek Shields, `1×` Bear-Claw Belly Skid) + 3 extra snap-on crowns from the 40-part Kodiak Garage menu in a pocket tray.
3. **1× Pocket ELRS 2.4GHz Radio Transmitter** (Radiomaster Pocket, pre-bound to both drones via model match or instant switch) + **1× Compact 5.8GHz FPV Watch/Goggle Monitor** (to show live OSD profile switching on the table without requiring the principal to mess up their hair/glasses unless they want to put on the goggles).
4. **1× Bench Engineering Prop Kit:** 1× bare `PETG-CF` / `PC-CF` 3D-printed frame, 1× [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl) with an `0802` brushless motor, and 1× mini **Bat-Safe** / `VIFLY WhoopStor V3` charger holding 4× charged `1S 550mAh LiHV` (`4.35V`) batteries.
5. **2× Printed Leave-Behinds:** School STEM Flyer (`flyer final.jpg`) + [`OSITO_KODIAK75_Event_Handout.html`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Bumper%20Drones/OSITO_KODIAK75_Event_Handout.html) printed in color.

---

### Minute-by-Minute Choreography (School Principal OR Venue Manager)

```
+---------------------------------------------------------------------------------------------------+
|                     OSITO 10-MINUTE LIVE HARDWARE DEMO CHOREOGRAPHY                               |
+-------------------+---------------------------------------+---------------------------------------+
|   TIME WINDOW     |      PHYSICAL ACTION (JESUS)          |     PSYCHOLOGICAL SHIFT (BUYER)       |
+-------------------+---------------------------------------+---------------------------------------+
| Min 0:00 - 2:00   | Hand buyer the unpowered 39.5g CUB-75.| "Wait, it weighs less than a golf     |
| The Tactile Hook  | Press thumb into top/bottom cages &   |  ball and my finger physically cannot |
|                   | bounce TPU 95A bumper off their desk. |  touch the blades!"                   |
+-------------------+---------------------------------------+---------------------------------------+
| Min 2:00 - 4:30   | Plug in 1S 550mAh battery. Take off   | "It's whispering quiet, rock-solid    |
| The Cub Mode      | from conference table in Profile 0    |  above my desk, and bounced off the   |
| Tabletop Hover    | (22° tilt, 68% cap). Deliberately     |  wall without a scratch!"             |
|                   | bump a wall/chair & auto-recover.     |                                       |
+-------------------+---------------------------------------+---------------------------------------+
| Min 4:30 - 6:30   | Disarm. Enter Betaflight OSD via      | "They aren't just babysitting kids    |
| Live OSD Profile  | sticks (L-Stick Up+Left, R-Stick L).  |  with toys—this is a real 3-stage     |
| Switch & Bench    | Switch Profile 0 -> Profile 1 (Scout  |  aerospace & hardware curriculum."    |
| Engineering       | 35°). Show Motor Prop Press Jig.      |                                       |
+-------------------+---------------------------------------+---------------------------------------+
| Min 6:30 - 8:30   | Bring out 38g SHARD-75 (KODIAK-75).   | School: "Our 6th-8th graders will go  |
| The SHARD-75      | Let buyer snap on magnetic N52 Crown  |  crazy for this."                     |
| Magnetic Armor    | & Cheek Wings, then flick one off to  | Venue: "Tech offsites & birthday      |
| & Crash Recovery  | feel the shear keyway & <0.5s level.  |  groups will pay a premium for this." |
+-------------------+---------------------------------------+---------------------------------------+
| Min 8:30 - 10:00  | Show Bat-Safe fireproof box & 101"    | Miguel/Alan locks in the pilot date,  |
| Safety Seal &     | tent footprint. Hand off to Miguel    | semester contract, or venue rev-share |
| Commercial Close  | (Schools) or Alan (Venues) for dates. | while excitement is at 100%.          |
+-------------------+---------------------------------------+---------------------------------------+
```

#### **Minutes 0:00 – 2:00: The Tactile Hand-Off & Finger-Cage Test (Disarming Fear First)**
* **Miguel / Alan (30 sec):** Sets the frame: *"Thanks for giving us 10 minutes, [Name]. Instead of showing you slides, our CTO Jesus brought the exact micro-aircraft we engineer and 3D-print here in San Francisco."*
* **Jesus (Action):** Pulls the **`39.5g OSITO CUB-75`** out of the backpack (battery unplugged) and places it directly into the Principal's or Venue Manager's open palm.
* **Jesus (Script):**
  > *"First, feel the weight—`39.5 grams` total with the battery, which is lighter than a golf ball. Most school or indoor drone programs fail because standard off-the-shelf Tiny Whoops only put a thin plastic ring around the sides of the propellers. When a 7-year-old grabs a hovering drone from underneath or on top, their fingers go right into the blades.*
  >
  > *Try pressing your index finger or thumb into the top or bottom of our `CUB-75` duct right now. You’ll feel **3 arched upper finger-guard ribs, a center hub ring, and 4 bottom radial struts** completely enclosing the `40mm` blade plane inside a `10mm` tall duct. Even a kindergartner's pinky finger cannot reach the propeller."*
* **Jesus (The Table-Bounce Test):** Takes the `CUB-75` and firmly bounces its outer perimeter against the edge of the conference table or wall.
  > *"And around the outside is our slip-on **Neon `TPU 95A` Bumper Belt** ([`CUB75_TPU_Bumper_Ring.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_TPU_Bumper_Ring.stl)) and **`52mm` wide flexible landing skids**. It acts like a bumper-car tire—zero marks on painted drywall, hardwood floors, or glass."*

#### **Minutes 2:00 – 4:30: The Tabletop Hover & Deliberate Wall/Book Bounce (*Cub Mode*)**
* **Jesus (Action):** Slides a **`1S 550mAh LiHV` battery** into the `70.0 × 18.5 × 7.5mm` under-belly TPU sleeve, sets the `CUB-75` in the center of the conference table (pointing the oversized `+X` nose arrow on the `CUB75_Canopy_LOS_CubDome` forward), and arms it in **Profile 0 (*Cub Mode*)**.
* **Jesus (Script while hovering 18 inches above the table):**
  > *"Notice two things right away: First, because we engineered a custom `550mAh` under-belly bay instead of using tiny `300mAh` toy batteries, we get **6.5 to 7.5 minutes of continuous training flight** per pack—nearly triple a standard micro-drone.*
  >
  > *Second, watch what happens when I push the right stick all the way to the wall."* (Jesus pushes stick and lets the `CUB-75` gently kiss a vertical notebook, wall, or Jesus's own outstretched forearm, where it bounces cleanly and stays level.)
  > *"Right now we’re running **Stage 1: Cub Mode** in our custom Betaflight 4.5 firmware. We’ve capped motor output at **`68%`**, locked maximum bank angle to **`22 degrees`**, slowed yaw/pitch rotation to a gentle **`140 degrees per second`**, and enabled **Headfree + Automatic Wall-Bounce Crash Recovery**. Even if a beginner panics and jams the stick full forward, the drone cannot build up dangerous speed."*
* **Interactive Beat:** Jesus hands the transmitter to the Principal or Venue Manager for 20 seconds while hovering over the table: *"Push the right stick left and right—feel how docile and self-leveling that is?"*

#### **Minutes 4:30 – 6:30: Live Betaflight OSD Profile Switch (*Cub → Scout Mode*) & Bench Tooling**
* **Jesus (Action):** Lands on the table, disarms, turns on the compact 5.8GHz FPV screen/goggles, and holds **Left Stick Up + Left, Right Stick Left** for 1 second to pull up the live **Betaflight OSD Menu**.
* **Jesus (Script):**
  > *"Here is why schools and makerspaces renew us semester after semester. As students improve, we don’t need to buy new drones or plug into a computer. Right from the controller sticks, our instructors open the on-screen firmware menu and switch the student from **Profile 0 (Cub Mode — `22°` tilt, `68%` power)** to **Profile 1 (Scout Mode — `35°` tilt, `260°/s` rates, `80%` power)**, and finally **Profile 2 (FPV Pilot Mode — `50°` tilt, `92%` power)** where we snap on our `10°` FPV camera pod ([`CUB75_Canopy_FPV_Pod.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Canopy_FPV_Pod.stl))."*
* **Jesus (Action — The 20-Second "Station 1" Bench Flex):** Places [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl) on the table.
  > *"And with our **1:4 instructor ratio**, kids aren't standing in line waiting for a turn. While 4 students fly, 4 are on Flight Simulators, and 4 are at **Station 1: Hardware & Soldering**—using our custom 3D-printed motor-shaft press jigs, multimeters, and soldering irons. We call it **'Fly, Crash, Build, Repeat.'**"*

#### **Minutes 6:30 – 8:30: The Showstopper — Popping Off a Magnetic Armor Shard on `SHARD-75` (`KODIAK-75`)**
* *(Note: For **Alan's Corporate & Birthday Venue meetings**, Jesus moves this segment up to **Minute 2:00** as the primary centerpiece! For **Miguel's School/Camp meetings**, this is the closer that proves 5th–8th graders will beg their parents to sign up.)*
* **Jesus (Action):** Pulls out the **`38g SHARD-75` (`KODIAK-75`)** carbon-polymer (`CarbonX PC-CF` / `ePA-CF`) combat drone with its **4 color-coded magnetic breakaway armor plates** attached (`Top Crown`, `Left/Right Cheek Wings`, `Belly Bear-Claw Skid`).
* **Jesus (Script & Physical Interaction):**
  > *"Now, for older students, birthday battles, and corporate team-building tournaments, meet the **`38-gram SHARD-75 / KODIAK-75`**. Go ahead and pull off that top **Bear-Ear Crown** and one of the side **Starfighter Wings**, then snap them back on."*
  >
  > *(Buyer pulls the armor plate off and feels the crisp snap of the recessed `N52` neodymium magnets.)*
  >
  > *"Those are **`N52` neodymium magnet sockets** recessed `0.20mm` into `TPU 95A` cups with a `0.5mm` shear keyway. We have a **40-part modular library (2,080 combinations)**—Dragon Spikes, Mecha Crests, Turbo Boosters, Tank Treads. All four armor shards combined weigh only **`2.1 grams`** (less than 6% of the drone's weight), so when two pilots ram each other mid-air inside our **`101" × 101"` netted pop-up battle tent**:*
  > *1. The magnetic shard pops off cleanly (`+2 points` for a Top Crown, `+1 point` for a Cheek Wing or Belly Skid).*
  > *2. Because the Center of Gravity shifts by less than `1.5mm`, our **`STM32G473` flight controller's Active Crash Recovery** re-levels the drone mid-air in **under 0.5 seconds** (`500 milliseconds`)!*
  > *3. Both pilots keep dogfighting for the full **3-minute heat** while spectators watch the live digital scoreboard right outside the net."*

#### **Minutes 8:30 – 10:00: The Risk-Management Seal & Hand-Off to Close**
* **Jesus (Action):** Points to the compact **Bat-Safe** steel fireproof box and `VIFLY WhoopStor V3` storage charger.
  > *"Finally, from a facilities and safety standpoint: every `1S` micro-battery is stored and charged inside a certified **Bat-Safe** fireproof steel enclosure, every drone has an instant manual master disarm (`AUX 1`) plus automatic `<0.5s` runaway shutoff, and our `101" × 101"` (`8.5 ft × 8.5 ft`) battle tent is 100% net-enclosed with sandwich-printed `TPU + ePA-CF` net-deflection horns so blades never snag the mesh."*
* **Miguel (Closing the School / Camp Buyer):**
  > *"We have Tuesday/Thursday afternoon slots open for the upcoming session [or: week-long summer camp cohorts]. Should we pencil in an 8-week After-School Flight Lab for grades 3–8, or start with a free 30-minute demo table at your next Family STEM Night?"*
* **Alan (Closing the Corporate / Birthday Venue Manager):**
  > *"All we need is a `9 ft × 9 ft` patch of floor or turf and one standard wall outlet. Can we add the `SHARD-75` Arena and our `$200/$400` Solo Pilot packages to your preferred party & corporate offsite menu starting next month?"*

---

## 5. Grassroots Lead-Gen Blueprint: Monthly "SF Micro-Drone Build & SHARD-75 Battle Night"

To generate a self-sustaining pipeline of **high-income SF parents** (who book `$400` birthday parties and lobby their K-8 PTA/Extended Day directors) and **SF tech engineers/managers** (who book `$1,500–$5,000` corporate team-building offsites at SPIN, The Midway, or SPARK Social), Jesus will run a recurring monthly community activation across two anchor Mission District spaces:

1. **Tech / Maker / Corporate Offsite Funnel:** **Noisebridge Makerspace (`272 Capp St`, Mission)** — *1st Thursday or 3rd Tuesday Evening of Every Month (6:30 PM – 9:30 PM)*
2. **Parent / Family / School PTA Funnel:** **Mission Science Workshop (`3750 18th St` or `4458 Mission St`)** — *Monthly Community Science Saturday Afternoon (11:00 AM – 2:00 PM)*

---

### Part A: The Noisebridge "Micro-Drone Solder, CAD & SHARD-75 Battle Night" (`272 Capp St`)

#### **1. How to Get It on the Calendar at 272 Capp St (Step-by-Step)**
1. **Activate Membership / Philanthropist Status:** Submit the Noisebridge membership/philanthropist form (already in our workspace at `noisebridge_membership.pdf`) and attend the **Tuesday 7:00 PM Weekly Meeting** at `272 Capp St`.
2. **60-Second Tuesday Announcements Pitch (Jesus):**
   > *"Hey everyone, I’m Jesus from Osito Drone Services here in the Mission. We design open-parametric 3D-printed `75mm` micro-drones (`PETG-CF` / `PC-CF` + `TPU 95A`) with magnetic breakaway armor and Betaflight 4.5 crash recovery. Starting next week, we’re hosting a free monthly **Micro-Drone Soldering, OpenSCAD & SHARD-75 Arena Night** right here at 272 Capp. We’ll bring our `101" × 101"` netted battle tent, soldering jigs, and spare `CUB-75` and `SHARD-75` kits—come fly, hack, or battle!"*
3. **Cross-List on High-Traffic SF Channels:**
   - Post on `noisebridge.today`, the `#events` channel on **Noisebridge Discord**, **SF Hardware Startups Meetup**, **Bay Area FPV / Tiny Whoop Discord**, **Luma (`lu.ma/sf`)**, and **Eventbrite** (*"Free Entry / Optional $35–$199 DIY Frame & Kit Build Ticket"*).

#### **2. 3-Hour Event Run-of-Show (6:30 PM – 9:30 PM)**

| Time | Station / Activity | What Happens | Lead-Gen & Monetization Mechanism |
| :--- | :--- | :--- | :--- |
| **6:30 – 7:15 PM** | **Open Bench: OpenSCAD, 3D Slicing & Soldering Clinic** | Jesus demonstrates how [`CUB75_Parametric_Master.scad`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Parametric_Master.scad) generates watertight STLs, how `PC-CF` arms and `TPU 95A` bumpers are sliced, and how to press props using [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl). Attendees practice soldering on dummy PCBs or assemble their own pre-purchased `CUB-75` / `SHARD-75` frame kit (**$25 Printed Frame Set** or **$199 Complete Bind-and-Fly Kit**). | Generates **$500–$1,500/night** in high-margin 3D-printed frame sets, magnetic armor packs, and DIY kits (our filament COGS on a full `CUB-75` or `SHARD-75` printed frame + armor set is **`< $3.50`**!). |
| **7:15 – 8:00 PM** | **Rookie Flight School & `Kodiak Garage` Loadout Customization** | Attendees scan a QR code at the pit table to unlock their pilot callsign on the live [`KODIAK75_Arena_Scoreboard.html`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Bumper%20Drones/KODIAK75_Arena_Scoreboard.html) display. First-time flyers warm up on `CUB-75` in *Cub Mode* (`22°`), then pick their 4 magnetic `N52` armor pieces from the **40-part Kodiak Garage wall** (Bear Ears, Dragon Spikes, Laser Pods, Tank Treads). | **Mandatory QR Pilot Registration Form** captures: `Name`, `Email`, `Phone`, `Company / Employer` (*"Where do you work in SF?"*), and `Do you have kids ages 6–14? (Y/N)`. |
| **8:00 – 9:15 PM** | **The `SHARD-75` 16-Pilot Bracket Tournament (Inside the `101" × 101"` Tent)** | Head-to-head **3-minute heats** (First to 10 points: Top Crown = `+2`, Cheek = `+1`, Belly Skid = `+1`, 5s Ground Takedown = `+3`). Music pumping, LEDs glowing, magnetic armor flying off mid-air while crowd films 15-second vertical videos for Instagram/TikTok/LinkedIn. | Every pilot receives a printed [`OSITO_KODIAK75_Event_Handout.html`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Bumper%20Drones/OSITO_KODIAK75_Event_Handout.html) card with: *"Want the SHARD-75 Combat Arena at your next company offsite or team happy hour? Get $250 off your team booking."* |
| **9:15 – 9:30 PM** | **Championship Heat, Trophy Crown & Offsite Pitch** | Tournament winner takes home a custom metallic-printed **Golden Osito Bear Crown** (`KODIAK75_Crown_BearEars.stl`) and a free 1-hour voucher toward a corporate or birthday event. | Alan and Miguel follow up within 24 hours with every tech employee (`Stripe`, `OpenAI`, `Salesforce`, `Anthropic`, `Block`, etc.) who registered on the QR scoreboard. |

---

### Part B: The Mission Science Workshop "Family Micro-Drone Tinkering Saturday" (`3750 18th St` & `4458 Mission St`)

#### **1. Setup & Footprint**
* Partner with **Sonia Gandiaga** and **Paul** at MSW to set up a **2-Table + 1-Hover-Pod Pop-Up** during MSW's monthly **Community Drop-In Saturday** (or Friday Family Science Night) at `3750 18th St` (Mission High) and `4458 Mission St` (Excelsior).
* **Table 1 (The "Cut-Away & Tool Bench" led by Jesus):**
  - Displays a disassembled `CUB-75` alongside a completed `39.5g CUB-75` and `38g SHARD-75`.
  - Kids (ages 6–14) use [`CUB75_Motor_Prop_Press_Jig.stl`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl) to press a propeller onto an `0802` motor, snap magnetic `N52` Bear Ears and Starfighter Wings onto a `SHARD-75` chassis, and see how a `1S 550mAh` circuit powers LEDs.
* **Table 2 / Netted Pod (The "5-Minute Pilot Wing Challenge" led by Miguel & Alan):**
  - Kids step up to fly the `CUB-75` in **Stage 1: Cub Mode (`22°` max tilt, `68%` motor cap, `HEADFREE` + `ANGLE`)**:
    1. Take off from the green launch pad.
    2. Hover steady for 10 seconds inside the netted pod.
    3. Fly through one neon LED hoop and land on the target pad.
  - Every child who completes the 3- minute challenge earns an official **"Osito Cub Pilot Wing Sticker"** + a printed flyer (`flyer final.jpg` / `birthday osito drone events.pdf`) handed directly to their parent.

#### **2. The Parent & PTA Lead-Capture Funnel**
To get their child's **Pilot Certificate & Free Flight Video Clip**, parents scan the table QR code (30-second form):
1. **Parent Name, Email & 415 Cell Number**
2. **Child's Age & Current School** (*Critical field!* When 4 parents from **Children's Day School (`OS-008`)**, **Synergy (`OS-009`)**, **Alta Vista (`OS-005`)**, or **SF Schoolhouse (`OS-006`)** sign up at MSW, Miguel immediately emails that school's Extended Day Director on Monday morning: *"We just had 4 families from [School Name] fly our `39.5g CUB-75` trainer at Mission Science Workshop this weekend and ask us to bring our After-School Flight Lab to your campus!"*)
3. **Upcoming Birthday Month** (Triggers an automated email from Alan 6 weeks before the child's birthday offering our **$200 / $400 Solo Pilot Birthday Package** or **$200 Take-Home Drone Kit**).

---

## 6. Jesus's Immediate 7-Day Execution Checklist

| Day | Action Item | Target Account(s) | Deliverable / Goal |
| :--- | :--- | :--- | :--- |
| **Day 1 (Mon)** | Print & prep 2× `CUB-75` (`39.5g`, Neon TPU bumper, CubDome canopy) + 2× `SHARD-75` (`38g`, 12× magnetic armor shards) + 1× `CUB75_Motor_Prop_Press_Jig.stl` for the Demo Backpack. | Internal Shop Prep | Backpack Demo Kit 100% charged (`4.35V LiHV` in Bat-Safe) and ready for drop-ins. |
| **Day 2 (Tue)** | Send personalized CTO emails to **Kim** (`OS-001` STEMful), **Paul & Sonia** (`OS-002` Mission Science Workshop), and **CYC STEAM Lab** (`OS-015`). Attend **Noisebridge 7:00 PM Tuesday Meeting** at `272 Capp St` (`OS-030`). | `OS-001`, `OS-002`, `OS-015`, `OS-030` | Announce first monthly **Noisebridge Micro-Drone Build & SHARD-75 Battle Night**; book 2 in-person demos. |
| **Day 3 (Wed)** | Send CTO emails to **Tinkering School** (`OS-003`) and **Alasan Jallow at SF STEM Academy / JCYC** (`OS-016`). Walk into **STEMful (`30 29th St`)** and **Mission Science Workshop (`3750 18th St`)** in person with the backpack demo kit. | `OS-001`, `OS-002`, `OS-003`, `OS-016` | Perform the **10-Minute Tabletop Hover & Finger-Cage Demo** live for Mission/Bernal neighbors. |
| **Day 4 (Thu)** | Visit **980 Clement St (CYC STEAM Maker Lab)** and **1830 Sutter St (JCYC Workhub)** with the backpack kit; show how CYC's 3D printers can print `N52` magnetic armor for `SHARD-75`. | `OS-015`, `OS-016` | Scope `$2,500–$6,000` DCYF grant-funded workshop proposals for CYC and JCYC. |
| **Day 5 (Fri)** | Co-visit **Presidio (`682 Schofield Rd`)** with **Miguel** (hitting both **Tinkering School `OS-003`** and **Brightworks `OS-004`** in one trip) and **House of Air (`926 Mason St`, `OS-020`)** with **Alan**. | `OS-003`, `OS-004`, `OS-020` | Run back-to-back 10-minute hardware demos in the Presidio to close camp + birthday arena partnerships. |
