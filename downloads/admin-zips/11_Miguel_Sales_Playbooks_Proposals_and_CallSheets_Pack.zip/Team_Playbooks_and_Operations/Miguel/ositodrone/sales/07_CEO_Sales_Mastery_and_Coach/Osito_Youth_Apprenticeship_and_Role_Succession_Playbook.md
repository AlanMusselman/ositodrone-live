# Osito Drone Services — "Young Minds" Expansion, Apprenticeship & Founder Role Succession Playbook

**Prepared For:**
- **Miguel Flores** — CEO & Co-Founder (`miguel@ositodrone.com` | `415-571-6614`)
- **Alan Musselman** — COO & Co-Founder (`alan@ositodrone.com` | `415-810-4158`)
- **Jesus Aceves** — CTO & Co-Founder (`jesus@ositodrone.com` | `415-269-1206`)

**Connected Workspace Playbooks & Technical References:**
- COO Pricing & Venue Playbook: [`Team_Alan_COO_Pricing_and_Venues_Playbook.md`](./Team_Alan_COO_Pricing_and_Venues_Playbook.md)
- CTO Makerspace & Demo Playbook: [`Team_Jesus_CTO_Makerspace_and_Demo_Playbook.md`](./Team_Jesus_CTO_Makerspace_and_Demo_Playbook.md)
- CEO Institutional Account Playbook: [`Team_Miguel_CEO_Account_Playbook.md`](./Team_Miguel_CEO_Account_Playbook.md)
- Classroom Trainer PRD & BOM: [`CUB-75_PRD_and_Blueprint.md`](./Kids%20Training%20Drone/CUB-75_PRD_and_Blueprint.md) | [`CUB75_BOM_and_Sourcing.md`](./Kids%20Training%20Drone/CUB75_BOM_and_Sourcing.md)
- Combat Arena PRD & BOM: [`KODIAK-75_PRD_and_Blueprint.md`](./Bumper%20Drones/KODIAK-75_PRD_and_Blueprint.md) | [`KODIAK75_BOM_and_Sourcing.md`](./Bumper%20Drones/KODIAK75_BOM_and_Sourcing.md)

---

## 1. Executive Charter: From "3-Man Strike Team" to a Youth-Powered Operating Engine

Right now, Osito Drone Services wins because **Miguel (CEO)**, **Alan (COO)**, and **Jesus (CTO)** operate as a high-trust 3-man strike team. However, as long as the three founders personally teach every after-school class, solder every broken motor wire, pack every Pelican case, and MC every weekend birthday party, **Osito is capped at 1 active event at a time**.

This document is the operational blueprint to **clone, modularize, and hand off 100% of our day-to-day instructional, technical, logistical, and account-management roles to capable young minds (ages 16–25)** across San Francisco.

### Why "Young Minds" Are Osito's Ultimate Unfair Advantage:
1. **Peer-to-Near-Peer Magnetism for Kids (Ages 6–14):** Elementary and middle school students idolize 17-to-23-year-old makers, gamers, and college engineering students who build drones, fly FPV, and speak their language.
2. **Mission & Grant Synergy (SF DCYF / Title IV / Workforce Development):** When Osito hires and trains local youth from **Mission Science Workshop (`OS-002`)**, **CYC (`OS-015`)**, **JCYC Workhub (`OS-016`)**, and **Boys & Girls Clubs (`OS-019`)**, our staffing model *itself* becomes a funded **Youth Workforce Development outcome**—unlocking wage subsidies and deeper DCYF institutional contracts.
3. **Built-In Unit Economics (`40.0%–80.1%` Hired-Staff Gross Margin):** As verified in [`Team_Alan_COO_Pricing_and_Venues_Playbook.md`](./Team_Alan_COO_Pricing_and_Venues_Playbook.md), our pricing packages (`PKG-1` through `PKG-5B`) are already engineered so that **even with 0 founders on-site** (paying a Lead Instructor `$45/hr` and Station Flight Coaches `$30/hr`), Osito retains **$1,679–$5,798 net profit per school/camp cohort** and **$1,442–$2,457 net profit per corporate arena event**.
4. **Founder Liberation for R&D & Multi-Pod Scaling:** Replacing ourselves on the front lines frees Miguel, Alan, and Jesus to run **3+ simultaneous SF event pods** while focusing on high-valuation autonomous/commercial hardware (e.g., *Osito Tactical Ball Drone*, *Scout85 Autonomous*, *Grizzly85 SkyRover*, *BerryBot*).

```mermaid
flowchart TD
    subgraph FOUNDERS["Phase 1: 3-Founder Strike Team (Current)"]
        M1["Miguel (CEO)<br/>Institutional Sales & School Close"]
        A1["Alan (COO)<br/>Pricing, COIs, Venues & Logistics"]
        J1["Jesus (CTO)<br/>3D Print Farm, Firmware & Live Demos"]
    end

    subgraph PIPELINE["Phase 2: The 'Young Minds' Talent Funnel (Ages 16–25)"]
        P1["Tier 1: Junior Maker Apprentices (Ages 16–19)<br/>Sourced via MSW, JCYC Workhub, CYC, BGCSF (DCYF Subsidized)"]
        P2["Tier 2: Station Flight Coaches & Pit Techs ($30/hr)<br/>SFSU / CCSF / USF STEM Students & Noisebridge Makers"]
        P3["Tier 3: Lead Instructors & Arena MCs ($45/hr)<br/>Certified On-Site Commanders (Zero Founders On-Site)"]
        P4["Tier 4: Associate Strike-Team Leads ($35–$45/hr + Comm.)<br/>Junior CTO (Fleet/Print) • Junior COO (Ops/Venues) • Junior CEO (Campus Sales)"]
    end

    FOUNDERS -->|"SOP Modularization & 14-Day Bootcamp"| P1
    P1 -->|"Pass 4 Bench & Flight Gates"| P2
    P2 -->|"Lead 5 Shadow Sessions"| P3
    P3 -->|"Master Domain Playbook"| P4
```

---

## 2. Where We Recruit "Young Minds" (San Francisco Talent Pipelines & Wage Subsidies)

Instead of posting generic gig ads on Craigslist, Osito recruits directly from five high-density San Francisco ecosystems where mechanically curious, bilingual, and charismatic young people already gather:

| Pipeline Source | Target Age & Profile | Partner Contact / Location | How Osito Recruits & Subsidizes Wages |
| :--- | :--- | :--- | :--- |
| **1. JCYC Workhub & SF STEM Academy (`OS-016`) + MYEEP** | **Ages 16–24** (High School Juniors/Seniors & Transitional Age Youth) | **Alasan Jallow** (`1830 Sutter St`) & SF Mayor's Youth Employment & Education Program | **DCYF Wage Subsidy:** Become an approved JCYC / MYEEP employer host site. JCYC/DCYF pays **50%–100% of wages** for youth interns during their first 100–200 hours as **Tier 1 Shop & Flight Apprentices**! |
| **2. Mission Science Workshop (`OS-002`) Junior Staff & Alumni** | **Ages 16–22** (Bilingual Spanish/English Mission & Excelsior Youth Tinkers) | **Sonia Gandiaga & Paul** (`3750 18th St` / `4458 Mission St`) | MSW trains teen "Junior Instructors" who already know woodworking, soldering, and circuits. Offer them weekend & afternoon shifts at **`$25–$30/hr`** as **Station 1 & 3 Flight Coaches**. |
| **3. SFSU, CCSF & USF Engineering / Computer Science / Education Clubs** | **Ages 18–24** (Mechanical/Electrical Engineering, Robotics & Teaching Credential Students) | SFSU ASME / IEEE / Robotics Club (`1600 Holloway Ave`) & CCSF Maker Sphere (`50 Frida Kahlo Way`) | College students have Tuesdays/Thursdays after 2:30 PM and weekends open. `$30–$45/hr` beats campus food-service jobs by 2x and puts *"Micro-UAV Firmware & Flight Instructor"* on their engineering resume. |
| **4. Noisebridge (`OS-030`) & Bay Area Tiny Whoop / FPV Racers** | **Ages 18–26** (OpenSCAD coders, 3D-printer modders, Betaflight FPV pilots) | `272 Capp St` (Monthly Osito Build & Battle Night) | Scout the sharpest young builders at our monthly **Noisebridge SHARD-75 Battle Night**. If they can already solder an AIO board and fly acro, fast-track them to **Tier 2 Pit Tech (`$30/hr`)** and **Junior Print-Farm Tech**. |
| **5. Graduating Osito 8th-Grade & High-School Camp Alumni** | **Ages 14–17** (Counselors-in-Training / CITs) | Top graduates from `OS-004` Brightworks, `OS-019` BGCSF, `OS-015` CYC | Create the **"Osito Wing Leader (CIT)"** badge: students who master *Pilot Mode* (Profile 2) and Station 1 soldering return the following summer as Junior Assistants, creating a self-replenishing multi-year loop. |

---

## 3. The 4-Tier "Young Minds" Career Ladder & Compensation Architecture

To motivate young hires to take ownership and stay with Osito for years, we structure a clear, video-game-style progression ladder where every promotion unlocks higher hourly pay, leadership autonomy, and revenue-share bonuses.

| Tier & Title | Age / Experience Target | Compensation Rate | Core On-Site & Shop Role | Prerequisite Gate to Unlock |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1: Junior Maker & Flight Apprentice** | **Ages 16–19**<br>*(Entry-Level / High School or DCYF Intern)* | **`$22–$25/hr`**<br>*(or DCYF/JCYC Grant-Underwritten Stipend)* | • Preps 3D-printed `CUB-75` (`$0.52`) frame kits & snaps `N52` magnets into `SHARD-75` armor.<br>• Runs `VIFLY WhoopStor V3` battery charging inside `Bat-Safe` boxes.<br>• Assists students at **Station 2 (Flight Simulators)** and resets obstacle hoops. | • Pass **Gate 1**: Basic Soldering, Prop-Press Jig, and LiPo `Bat-Safe` Safety Quiz.<br>• Hover `CUB-75` in *Cub Mode* (`22°`) for 60s. |
| **Tier 2: Certified Station Flight Coach & Arena Pit Tech** | **Ages 18–24**<br>*(College STEM Student / Young Maker)* | **`$30.00/hr`**<br>*(incl. 0.5 hr setup/teardown pay)* | • Independently teaches **1 of the 4 Rotational Stations** (1:4 ratio, 4 students at a time).<br>• Operates the **ELRS Wireless Buddy-Box Master Switch** during Station 3/4 flights.<br>• Serves as **Pit Crew Tech** at `SHARD-75` corporate/birthday tournaments (swaps batteries/armor in `<30s`, runs QR scoreboard). | • Pass **Gate 2**: 3-Minute Motor/Frame Swap Test + Live Buddy-Box Takeover Test.<br>• Complete 2 shadowed workshops with a Founder or Tier 3 Lead. |
| **Tier 3: Lead Instructor & Tournament MC ("Pod Commander")** | **Ages 20–26**<br>*(Experienced Educator, Maker, or Performer)* | **`$45.00/hr`**<br>*(incl. 1.0 hr setup/teardown + `$25` per Take-Home Kit upsold)* | • **Replaces Founders 100% On-Site.**<br>• Picks up Pelican 1560/1450 fleet cases, leads the 3 Station Coaches, enforces the 20-minute station rotation clock, interfaces with School Director / Venue Manager, and MCs live `SHARD-75` tournament brackets on the mic. | • Pass **Gate 3**: Solo Command of a 16-Student Workshop or 40-Guest Arena Event with `100%` safety compliance & `9/10+` client rating.<br>• LiveScan + TB + First Aid/CPR cleared. |
| **Tier 4: Associate Strike-Team Lead (Founder Successor)** | **Ages 21–27**<br>*(Promoted from Tier 3)* | **`$35–$45/hr` Base** + **`10%` New Account Commission** or **Pod Profit Bonus** | • Steps directly into **Jesus's (Tech/Fleet)**, **Alan's (Ops/Venues)**, or **Miguel's (Sales/Schools)** weekly executive workflows so the company scales without founder bottlenecks. | • Master the specific **Founder Replacement Track (Section 4)** over a 30-day co-pilot period. |

---

## 4. Deconstructing the 3 Founders: Role-by-Role Replacement Blueprints

To replace ourselves without losing Osito's magic, we split each co-founder's job into **concrete, repeatable SOP modules** that a smart 20-to-25-year-old can execute from a checklist.

---

### Track A: Replacing JESUS ACEVES (CTO) → The "Junior Fleet Engineer & Demo Specialist"

**What Jesus Does Today:** Prints `PETG-CF` / `PC-CF` / `TPU 95A` airframes, flashes Betaflight 4.5 CLI, repairs fleet drones, runs Station 1 (Soldering/Diagnostics), and performs the 10-Minute Tabletop Hardware Demo for schools and makerspaces.

#### How We Hand Off Jesus's Role to Young Minds (4 Modular SOPs):

##### **SOP-CTO-01: The In-House 3D Print Farm & `$0.52` Airframe Production Line**
Any mechanically inclined 17-to-22-year-old apprentice can run Osito's print queue using pre-sliced `.3mf` / `.gcode` plates:
1. **Standardized Print Plates (Zero CAD Edits Required):**
   - **Plate A (`PETG-CF` / `PC-CF` Rigid Structural):** Prints 4× [`CUB75_Frame_KidSafe_75mm.stl`](./Kids%20Training%20Drone/cad/CUB75_Frame_KidSafe_75mm.stl) (`$0.22` filament/ea) or 4× `SHARD-75` carbon-polymer frames per build plate.
   - **Plate B (`TPU 95A` High-Vis Neon Impact Armor):** Prints 6× [`CUB75_TPU_Bumper_Ring.stl`](./Kids%20Training%20Drone/cad/CUB75_TPU_Bumper_Ring.stl) (`$0.10`/ea), [`CUB75_550mAh_Trainer_Skids.stl`](./Kids%20Training%20Drone/cad/CUB75_550mAh_Trainer_Skids.stl) (`$0.12`/ea), and canopies (`$0.08`/ea).
   - **Plate C (`SHARD-75` Magnetic Breakaway Armor & `N52` Press-Fit):** Prints batches of Top Crowns, Cheek Wings, and Belly Skids; apprentice presses `2×1mm` / `5×2mm` `N52` magnets into the recessed `0.20mm` TPU sockets using a polarity-marked master magnet tool (Blue = North / Red = South so every shard snaps onto every drone universally).
2. **Inventory KanBan Rule:** The Apprentice checks the **Spares Bin** every Friday. If pre-built `CUB-75` replacement frame sets drop below **20 sets** (or `SHARD-75` armor shards below **30 pieces**), they trigger a weekend print batch automatically.

##### **SOP-CTO-02: The 10-Minute "Zero-Think" Firmware Flash & 4-Gate QA Bench Check**
Instead of tuning PIDs from scratch, the Junior Fleet Tech follows a 4-step computer checklist whenever building or repairing a drone:
1. **Mechanical Assembly (`< 8 Mins`):** Mount the BetaFPV Matrix 1S `5-in-1` AIO FC onto the 4 gummy grommets, plug the four `0802/1002` motors into the `JST-1.25` sockets (zero soldering required for motor swaps!), and press on `40mm` Gemfan 1610 props using [`CUB75_Motor_Prop_Press_Jig.stl`](./Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl) so the `1.5mm` shaft never bends.
2. **One-Click CLI Restore (`< 2 Mins`):** Plug USB-C into Betaflight Configurator $\rightarrow$ click **CLI Tab** $\rightarrow$ load [`CUB75_Betaflight45_Kids_Trainer_CLI.txt`](./Kids%20Training%20Drone/firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt) $\rightarrow$ type `save`. This automatically loads:
   - **Profile 0 (*Cub Mode*):** `22°` max tilt, `140°/s` rates, `68%` motor output cap, `ANGLE + HEADFREE`.
   - **Profile 1 (*Scout Mode*):** `35°` max tilt, `260°/s` rates, `80%` motor cap, `ANGLE`.
   - **Profile 2 (*Pilot Mode*):** `50°` max tilt, `420°/s` rates, `92%` motor cap, FPV `25mW` VTX.
3. **Pass/Fail 4-Gate QA Sign-Off:**
   - [ ] **Gate 1 (Finger-Cage Clearance):** Spin all 4 props by hand—zero rub against the `42.0mm` ID ducts, 3 top ribs, or 4 bottom struts.
   - [ ] **Gate 2 (Runaway Disarm `<0.5s`):** Arm in *Cub Mode* and flick chassis `>45°`—motors must cut in `<500ms`.
   - [ ] **Gate 3 (ELRS Buddy-Box Link):** Hold Master Trainer switch on Instructor Radio—verify instant stick takeover from Student Radio.
   - [ ] **Gate 4 (30-Second Hover & Wall Bounce):** Hover inside test pod and bump the `TPU 95A` ring against a vertical board—verify clean self-leveling recovery.

##### **SOP-CTO-03: Cloning Jesus at Station 1 (The 20-Minute Student Soldering & Tinkering Script)**
Any Tier 2 Coach (`$30/hr`) can run **Station 1** by following this exact 20-minute rotational script for 4 students:
- **Minutes 0–4 (The Crash Anatomy Challenge):** Hand each 2-student crew a "crashed" demonstration `CUB-75` frame and a multimeter set to Continuity (Beep Mode). Have them test motor wires and see why a `39.5g` `PETG-CF` frame with a `TPU 95A` bumper absorbs kinetic energy ($E_k = \frac{1}{2}mv^2 < 0.3\text{ J}$).
- **Minutes 4–12 (The Prop-Press & Modular Swap):** Students use [`CUB75_Motor_Prop_Press_Jig.stl`](./Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl) to safely press a propeller onto an `0802` brushless motor, plug the `JST-1.25` connector into an AIO board, and swap between the [`CUB75_Canopy_LOS_CubDome.stl`](./Kids%20Training%20Drone/cad/CUB75_Canopy_LOS_CubDome.stl) and [`CUB75_Canopy_FPV_Pod.stl`](./Kids%20Training%20Drone/cad/CUB75_Canopy_FPV_Pod.stl).
- **Minutes 12–18 (Hands-On Pinecil Soldering):** Using USB-C temperature-capped (`320°C`) Pinecil irons on fume-extracted silicone mats, each student solders two LED practice pads on an Osito training PCB until the LED lights up on a `1S` battery tester.
- **Minutes 18–20 (Tool Count & Station Reset):** Coach verifies 4 irons unplugged, 4 multimeters off, and stamps the students' **Osito Engineering Passports** before calling *"Station Rotate!"*

##### **SOP-CTO-04: Cloning Jesus's 10-Minute Tabletop Sales Demo**
Train our top Tier 3 Lead Instructor to carry the **Demo Backpack** (1× `CUB-75`, 1× `SHARD-75` with magnetic armor, 1× `Bat-Safe`, 1× `CUB75_Motor_Prop_Press_Jig`) and execute the 5-step sequence from [`Team_Jesus_CTO_Makerspace_and_Demo_Playbook.md`](./Team_Jesus_CTO_Makerspace_and_Demo_Playbook.md#L306-L351):
1. **Min 0–2:** Hand the unplugged `39.5g` `CUB-75` to the principal/manager $\rightarrow$ invite them to press their finger into the top 3-rib and bottom 4-strut finger cage $\rightarrow$ bounce the `TPU 95A` bumper on the desk.
2. **Min 2–4:30:** Hover 18 inches above the conference table in *Cub Mode* (`22°` tilt, `68%` motor cap) $\rightarrow$ gently bounce off a vertical notebook $\rightarrow$ hand the radio to the buyer for 20 seconds so they feel how docile it is.
3. **Min 4:30–6:30:** Show the stick-activated Betaflight OSD menu (*Cub $\rightarrow$ Scout $\rightarrow$ Pilot*) and place the 3D-printed prop press jig on the table.
4. **Min 6:30–8:30:** Have the buyer pull off and snap back the `N52` magnetic Bear-Ear Crown and Cheek Wings on the `38g SHARD-75`.
5. **Min 8:30–10:00:** Point to the `Bat-Safe` steel enclosure and lock in the trial workshop or venue launch date.

---

### Track B: Replacing ALAN MUSSELMAN (COO) → The "Junior Operations, Logistics & Venue Coordinator"

**What Alan Does Today:** Manages Pelican case packing, battery charging protocols, venue/city COI certificates (`RPDReservations@sfgov.org`), instructor scheduling, and revenue-share accounting across `OS-020` to `OS-027`.

#### How We Hand Off Alan's Role to Young Minds (4 Modular SOPs):

##### **SOP-COO-01: The Pelican Fleet Case "Shadow-Board" & `Bat-Safe` Charging Protocol**
Our Pelican 1560/1450 foam cutouts (designed in `Pelican Fleet Case Foam/`) make missing gear impossible to overlook. A Tier 2/3 Operations Lead executes this checklist 24 hours before and 1 hour after every deployment:
- **Pre-Deployment (24 Hrs Prior):**
  1. Charge all 34× `1S 550mAh LiHV` packs to `4.35V` at `1.3A` (~22 mins per 6-pack batch) on the 3× `VIFLY WhoopStor V3` chargers **strictly inside closed `Bat-Safe` steel boxes**.
  2. Verify Pelican Case 1 (`STEM Academy Fleet`): 8× active `CUB-75 Dual` drones + 2× `CUB-75` hot spares + 8× Radiomaster Pocket radios (USB-C charged `>80%`) + 4× 5.8GHz FPV Box Goggles + 10× `$0.52` spare airframe sets + 20× spare Gemfan 1610 props.
  3. Verify Pelican Case 2 (`Station 1–4 & Arena Kit`): 4× Pinecil irons, 2× multimeters, 4× laptop sim dongles, pop-up neon LED gates, `101"×101"×84"` Alvantor netted tent (if running `SHARD-75` arena), and portable LED scoreboard.
- **Post-Deployment (Within 2 Hours of Return):**
  1. Plug all used and unused `1S` packs into the `VIFLY WhoopStor V3` set to **`3.80V` STORAGE MODE**. *(Never leave `1S LiHV` packs at `4.35V` overnight—this single rule doubles battery lifespan!)*
  2. Log any cracked frames (`$0.52`) or bent props in the **Fleet Repair Sheet** so the Tier 1 Apprentice swaps them during Friday shop hours.

##### **SOP-COO-02: The 15-Minute Arena & 20-Minute 4-Station Classroom Setup Clock**
When a Tier 3 Lead Instructor (`$45/hr`) and Tier 2 Coaches (`$30/hr`) arrive on campus or at a venue (30 minutes before start time), each person has a fixed 15-minute physical assignment:
- **Lead Instructor (Minutes 0–15):** Checks in at front desk with COI & LiveScan binder $\rightarrow$ sets up **Station 3/4 Flight Zone** (unfolds pop-up Hover Pods / neon LED gates or pops open the `101"×101"` Alvantor netted battle tent in 90 seconds) $\rightarrow$ powers on Master Buddy-Box Radio and tests emergency `AUX 1` kill switches.
- **Coach 1 (Minutes 0–15):** Sets up **Station 1 (Hardware & Soldering Bench)** $\rightarrow$ lays down silicone mats, plugs in 110V surge strip, sets out 4× Pinecil irons (unheated until Station 1 starts), 2× multimeters, [`CUB75_Motor_Prop_Press_Jig.stl`](./Kids%20Training%20Drone/cad/CUB75_Motor_Prop_Press_Jig.stl), and `Bat-Safe` charging station.
- **Coach 2 (Minutes 0–15):** Sets up **Station 2 (Flight Simulators)** $\rightarrow$ opens [`Osito_SF_Flight_Simulator`](./Osito_SF_Flight_Simulator) / [`Acrobee65-Flight-Simulator-0.5`](./Acrobee65-Flight-Simulator-0.5) on 4 stations, connects USB-C trainer controllers, and displays the 20-minute rotational timer.

##### **SOP-COO-03: The 3-Click Venue Booking, COI & Staffing Dispatch Workflow**
A Junior Operations Coordinator (working 5–8 hrs/week from laptop at `$30/hr`) handles Alan's back-office pipeline:
1. **When a Birthday (`PKG-4A/B/C`), School (`PKG-1/2/3`), or Corporate (`PKG-5A/B`) Booking Arrives:**
   - Select the pre-approved pricing row from [`Team_Alan_COO_Pricing_and_Venues_Playbook.md`](./Team_Alan_COO_Pricing_and_Venues_Playbook.md#L85-L98) (zero custom math allowed without COO sign-off).
   - Request a same-day **Additional Insured COI** from Osito's insurance broker portal using our pre-saved venue templates (`Presidio Trust`, `City and County of San Francisco / RPDReservations@sfgov.org`, `Parklab / SPARK Social`, `SPIN SF`, `Emporium`, or the target K-8 school).
2. **Staffing Dispatch Rule (`1:4` Strict Ratio):**
   - Post the shift on the **Osito Crew Discord / Google Calendar** 10 days prior:
     - **12-Student Class (`PKG-2A`):** Assign `1× Tier 3 Lead ($45/hr)` + `2× Tier 2 Coaches ($30/hr)`.
     - **16-Student Class/Camp (`PKG-1`, `PKG-2B`, `PKG-3A/B/C`):** Assign `1× Tier 3 Lead ($45/hr)` + `3× Tier 2 Coaches ($30/hr)`.
     - **Birthday Party (`PKG-4A/B/C`):** Assign `1× Tier 3 Lead ($45/hr)`.
     - **Corporate `SHARD-75` Arena (`PKG-5A/B`):** Assign `1× Tier 3 Lead/MC ($45/hr)` + `1–2× Tier 2 Pit Techs ($30/hr)`.

---

### Track C: Replacing MIGUEL FLORES (CEO) → The "Junior Campus & Community Growth Rep"

**What Miguel Does Today:** Cold/warm outreach to K-8 Heads of School and Extended Day Directors (`OS-004` to `OS-019`), corporate event producers (`OS-025`, `OS-028`, `OS-029`), QR lead follow-up, and semester renewal contracting.

#### How We Hand Off Miguel's Role to Young Minds (3 Modular SOPs):

##### **SOP-CEO-01: Running the Weekend Grassroots QR Lead Machine (MSW & Noisebridge)**
Instead of Miguel and Alan standing at every weekend festival table, two charismatic college reps (`Tier 2/3`) run the **5-Minute Pilot Wing Challenge** at Mission Science Workshop (`3750 18th St`), Sunday Streets, or school STEM fairs:
1. **The Hook:** Every kid (ages 6–14) gets a free 3-minute flight inside the netted pod in *Cub Mode* (`22°` tilt cap) to earn an **"Osito Cub Pilot Wing Sticker"**.
2. **The Mandatory Parent QR Gate:** To receive their child's official **Pilot Certificate & 15-Second Flight Video**, the parent scans the table QR code and enters:
   - `Parent Name, Email & Cell`
   - `Child's Current School` *(e.g., Children's Day School, Alta Vista, Live Oak, Synergy, SF Day)*
   - `Child's Birthday Month`
3. **The Monday Morning 24-Hour Automated Follow-Up (Executed by Junior Growth Rep):**
   - **If `>= 3` parents from the same school sign up:** The Rep sends Miguel's pre-written school email template from [`Team_Miguel_CEO_Account_Playbook.md`](./Team_Miguel_CEO_Account_Playbook.md) to that school's Extended Day Director: *"Hi [Director Name], we just had 4 families from [School Name] fly our 39.5g finger-safe CUB-75 trainer this weekend and ask us to bring our 4-Station Flight Lab to your afternoon roster..."*
   - **6 Weeks Before Child's Birthday Month:** Rep texts/emails the parent the `$200 / $400` Turnkey Drone Birthday Party package (at AcroSports, SPARK Social, or SF Rec & Park gyms).

##### **SOP-CEO-02: The Semester "Auto-Renewal & Upsell" Sequence (Week 6 of Every 8-Week Lab)**
Once an independent school (`OS-004` to `OS-014`) books their first workshop or 8-week cohort (`PKG-2A/2B`), the **Tier 3 Lead Instructor** on campus executes a built-in renewal sequence so Miguel doesn't have to resell the account:
- **Week 4 (Mid-Semester Video Drop):** Lead Instructor texts a 20-second vertical video to the school's Extended Day Director showing their students soldering at Station 1 and flying through neon LED gates in *Scout Mode* (`35°`), captioned: *"Your 4th graders just graduated from Cub Mode to Scout Mode today!"* (Directors immediately forward this to the Head of School and parent newsletter.)
- **Week 6 (Next-Semester Lock-In):** Junior Growth Rep emails the Extended Day Director the next trimester's **Level 2 Curriculum (*FPV Pilot Mode & SHARD-75 Magnetic Engineering*)** + **Summer Camp (`PKG-3A/B/C`)** reservation agreement.
- **Week 7 (Parent Take-Home Kit Upsell):** Send parents the opt-in link for the **+\$200 Take-Home `CUB-75` RTF Bundle** (`$177.84` BOM = `$22.16`–`$67.16` extra hardware margin per student, plus the Tier 3 Lead earns a `$25` bonus for every kit sold!).

---

## 5. The 14-Day "Osito Young Minds Bootcamp" (Certification & Sign-Off Rubric)

No young hire touches a live classroom or corporate event until they complete this **10-hour, 14-day certification track** and pass all 5 physical gates:

| Training Module | Duration | What the Trainee Learns & Practices | Physical Pass/Fail Gate (Signed Off by CTO/COO) |
| :--- | :---: | :--- | :--- |
| **Module 1: Hardware Anatomy, `Bat-Safe` Fire Rules & Bench Tooling** | **2.5 Hours**<br>*(Shop Evening 1)* | • Disassemble & reassemble a `39.5g CUB-75` and `38g SHARD-75`.<br>• Practice `CUB75_Motor_Prop_Press_Jig` prop installation, multimeter continuity testing, and Pinecil `320°C` PCB soldering.<br>• Master `VIFLY WhoopStor V3` (`4.35V` charge / `3.80V` storage) inside `Bat-Safe` steel boxes. | **GATE 1:** Swap a damaged motor + press a prop + replace a `$0.52` 3D-printed frame in **under 4 minutes** with zero bent shafts; recite the 3 `Bat-Safe` LiPo rules with 100% accuracy. |
| **Module 2: Progressive Flight Mastery & ELRS Wireless Buddy-Box** | **2.5 Hours**<br>*(Shop Evening 2)* | • Fly `CUB-75` across all 3 Betaflight profiles (*Cub `22°` $\rightarrow$ Scout `35°` $\rightarrow$ FPV Pilot `50°`*).<br>• Switch OSD profiles via transmitter stick commands (`Left Stick Up+Left, Right Stick Left`).<br>• Practice **ELRS Wireless Buddy-Box** emergency recovery when a simulated student panics and jams full throttle toward a wall. | **GATE 2:** Recover an out-of-control student drone via the Master Buddy-Box switch in **under 1.0 second** (5 consecutive blind trials) and complete a 3-lap FPV gate circuit without crashing. |
| **Module 3: The 4-Station Classroom Choreography & Pedagogical Voice** | **2.0 Hours**<br>*(Weekend Lab)* | • Roleplay managing a 4-student crew at Station 1 (Soldering), Station 2 (Sim), Station 3 (Hover Pods), and Station 4 (FPV/Arena).<br>• Learn classroom crowd-control rules: *"Radios on the table before anyone steps into the net"* and *"Goggles down until battery is plugged in."* | **GATE 3:** Deliver the 5-minute Station 1 Soldering safety briefing and Station 3 *Cub Mode* takeoff briefing clearly, energetically, and without filler words. |
| **Module 4: `101"×101"` Arena Tent Pop-Up & Live Tournament MCing** | **1.5 Hours**<br>*(Shop / Turf)* | • Unpack Pelican cases, pop up and stake/weight the `101"×101"×84"` Alvantor netted tent, connect the 5.8GHz Diversity HDMI video receiver to a TV/monitor, and launch [`KODIAK75_Arena_Scoreboard.html`](./Bumper%20Drones/KODIAK75_Arena_Scoreboard.html).<br>• Run a mock 3-minute `SHARD-75` heat scoring magnetic armor hits (`+2` Crown, `+1` Wing/Skid, `+3` Takedown). | **GATE 4:** Full load-in to live arena readiness in **under 15 minutes** and full teardown/pack-out (with 100% battery & tool count) in **under 10 minutes**. |
| **Module 5: On-Site Shadow Shift (Live Field Qualification)** | **1.5–2.0 Hours**<br>*(Live School/Venue)* | • Co-teach a live `PKG-1`/`PKG-2` school workshop or `PKG-4`/`PKG-5` venue event alongside a Founder or Senior Tier 3 Lead. | **GATE 5:** Zero safety violations, high kid/guest energy, and sign-off from the on-site Lead to unlock **`$30/hr` Tier 2 Station Coach** status. |

---

## 6. Financial Proof: Scaling to 3 Youth-Staffed Pods (Zero Founders On-Site)

Once we train a bench of **3× Tier 3 Lead Instructors (`$45/hr`)** and **9× Tier 2 Station Coaches (`$30/hr`)** from SFSU, CCSF, JCYC Workhub, and Mission Science Workshop, Osito is no longer limited by Miguel, Alan, and Jesus's personal calendars.

Here is the deterministic monthly financial model (using the verified **100% Hired-Staff Net Profit** figures from [`Team_Alan_COO_Pricing_and_Venues_Playbook.md`](./Team_Alan_COO_Pricing_and_Venues_Playbook.md#L109-L121)) when running **3 Youth-Staffed Pods** across San Francisco while the 3 Founders spend **0 hours** teaching on-site:

| Monthly Revenue Stream (100% Youth-Staffed Delivery) | Monthly Volume Across 3 Pods | Gross Client / Net Venue Revenue | Youth Staff Payroll (`$45/hr` Leads + `$30/hr` Coaches) | Non-Labor COGS *(HW Spares `$0.52`, Fleet Amort., Ins.)* | **Net Operating Profit to Osito (Founders Off-Site)** | **Hired-Staff Net Margin (%)** |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **1. Independent School 8-Week After-School Labs (`PKG-2B`, 16 Kids)**<br>*(6 active afternoon school cohorts running Tue/Wed/Thu = 3/month amortized)* | **3 Cohorts / mo**<br>*(6 active across 2-mo cycle)* | **\$16,800.00** | \$7,020.00<br>*(\$2,340 × 3)* | \$2,053.68<br>*(\$684.56 × 3)* | **\$7,726.32** | **46.0%** |
| **2. DCYF / Community STEM Discovery Workshops (`PKG-1`, 2-Hr)**<br>*(MSW, CYC, JCYC, STEMful, BGCSF single-day workshops)* | **4 Workshops / mo** | **\$3,840.00** | \$1,440.00<br>*(\$360 × 4)* | \$394.28<br>*(\$98.57 × 4)* | **\$2,005.72** | **52.2%** |
| **3. Weekend Youth Birthday Parties (`PKG-4B` Direct & `PKG-4C` Venue)**<br>*(8 parties/mo across AcroSports, House of Air, SPARK Social, Rec & Park)* | **8 Parties / mo**<br>*(4 Direct + 4 Venue)* | **\$2,880.00** | \$1,080.00<br>*(\$135 × 8)* | \$536.00<br>*(\$67.00 × 8)* | **\$1,264.00** | **43.9%** |
| **4. Corporate `SHARD-75` Aerial Combat Buyouts (`PKG-5A` 2-Hr & `PKG-5B` 4-Hr)**<br>*(3× 2-Hr offsites at SPIN/Emporium/SPARK + 1× 4-Hr buyout at The Midway)* | **4 Corporate Events / mo** | **\$8,600.00** | \$1,290.00<br>*(3×\$247.50 + 1×\$547.50)* | \$525.00<br>*(3×\$110 + 1×\$195)* | **\$6,785.00** | **78.9%** |
| **5. Take-Home `CUB-75` RTF Student Kit Upsells (`+$200` Retail / `$177.84` BOM)**<br>*(Conservative 25% attach rate across ~120 monthly students/birthday kids = 30 kits)* | **30 Kits / mo** | **\$6,000.00** | \$750.00<br>*(\$25 Lead Bonus × 30)* | \$4,660.20<br>*(Blended RTF/Drone BOM)* | **\$589.80** | **9.8%** *(Pure Brand Flywheel)* |
| **TOTAL SCHOOL-YEAR MONTHLY RUN RATE (100% YOUTH-STAFFED)** | **19 Events + 6 Weekly School Labs** | **\$38,120.00 / mo** | **\$11,580.00 / mo**<br>*(Paid to SF Youth & College Staff!)* | **\$8,169.16 / mo** | **\$18,370.84 / mo**<br>*(**\$220,450 / yr**)* | **48.2% Blended Net Margin** |
| **SUMMER PEAK BOOST: 5-Day Full-Day Camps (`PKG-3B` @ \$10,800)**<br>*(Running 2 parallel camp pods/week × 4 weeks in June/July/August = 8 camp weeks/mo)* | **8 Camp Cohorts / summer mo** | **\$86,400.00 / mo** | **\$36,000.00 / mo**<br>*(\$4,500 × 8)* | **\$6,845.60 / mo**<br>*(\$855.70 × 8)* | **\$43,554.40 / mo** | **50.4% Summer Net Margin** |

> [!IMPORTANT]
> **What This Table Proves:**
> By investing **\$11,580/month** during the school year (and **\$36,000/month** during summer camp peak) directly into the pockets of trained San Francisco youth, college engineering students, and young educators, Osito generates **\$18,370/month in school-year net profit** and **\$43,554/month in summer net profit**—with **zero founder hours spent teaching classes or packing vans**.

---

## 7. Ready-to-Post Job Descriptions (Copy & Paste to Recruit Today)

### Posting 1: For SFSU / CCSF / USF Engineering Boards & Noisebridge Discord (`$30–$45/hr`)

> **TITLE: Micro-Drone Flight Coach, Soldering Instructor & Arena Pit Tech (`$30–$45/hr`) — Osito Drone Services (San Francisco)**
>
> **About Osito Drone Services:**  
> Based right here in San Francisco, Osito designs and 3D-prints our own custom `39.5g` indoor training micro-drones (`OSITO CUB-75` in `PETG-CF` + `TPU 95A`) and `38g` magnetic breakaway-armor combat drones (`SHARD-75` / `KODIAK-75`). We run hands-on **4-Station Aeronautical Engineering & Flight Labs** at SF's top independent K-8 schools and makerspaces, plus high-energy **Netted Aerial Combat Tournaments** at corporate offsites and arcade bars (SPIN SF, Emporium, The Midway, SPARK Social).
>
> **Why Join the Osito Crew?**
> - **High Pay, Flexible Hours:** Start at **`$30/hr`** as a Certified Station Flight Coach / Pit Tech and advance within 30 days to **`$45/hr` (+ kit upsell bonuses)** as a Lead Instructor & Tournament MC.
> - **Fits College & Maker Schedules:** Afternoon school labs run **2:45 PM – 5:15 PM (Tue/Wed/Thu)**; birthday and corporate arena tournaments run on **weekends and Thursday/Friday evenings**.
> - **Real Aerospace & Firmware Experience:** Work hands-on with `STM32` AIO flight controllers, Betaflight 4.5 CLI tuning, ExpressLRS 2.4GHz wireless buddy-box systems, `PC-CF`/`TPU` 3D printing, and soldering diagnostics.
>
> **What You'll Do (After Our Paid 14-Day Certification Bootcamp):**
> 1. **Lead a 1:4 Rotational Station (4 Students at a Time):** Coach 2nd–8th graders through Station 1 (Pinecil soldering, multimeters & 3D-printed motor jigs), Station 2 (3D Flight Simulators), Station 3 (Line-of-Sight hover pods), or Station 4 (5.8GHz FPV Goggle obstacle courses).
> 2. **Pit Crew & MC at `SHARD-75` Combat Tournaments:** Help set up our `101"×101"` netted pop-up combat cage in 15 minutes, snap on `N52` magnetic breakaway armor plates between 3-minute heats, and run the live digital tournament scoreboard.
> 3. **Optional Track into Fleet Engineering or Ops Leadership:** Top performers can take over our in-house 3D print farm queue, firmware flashing bench, or campus account operations.
>
> **Requirements:**
> - Ages 18+ (able to pass standard CA school vendor LiveScan background check & TB clearance—paid for by Osito).
> - Passion for tinkering, RC/FPV drones, 3D printing, robotics, gaming, or youth STEM coaching (we train you on our exact `CUB-75` and `SHARD-75` hardware!).
> - Bilingual Spanish/English or Cantonese/English is a huge plus for our Mission, Excelsior, and Chinatown community workshops.
>
> **To Apply:** Text or email **Jesus Aceves (CTO)** at `jesus@ositodrone.com` (`415-269-1206`) or **Alan Musselman (COO)** at `alan@ositodrone.com` (`415-810-4158`) with a quick note on what you love to build or teach, and come fly our `SHARD-75` combat drones at our next shop night!

---

### Posting 2: For JCYC Workhub (`OS-016`), CYC (`OS-015`) & Mission Science Workshop (`OS-002`) Youth Apprentices (Ages 16–20)

> **TITLE: Osito Youth Aerospace & 3D-Printing Apprentice (Paid After-School & Weekend Internship)**
>
> **Learn to Build, Solder, Code & Fly Custom 3D-Printed Micro-Drones in San Francisco!**  
> Osito Drone Services is looking for 4 mechanically curious high school and transitional-age youth (ages 16–20) in San Francisco to join our **Youth Aerospace Apprenticeship**.
> - **No Prior Drone Experience Required:** You'll learn directly from San Francisco aerospace/hardware founders how to run carbon-fiber and flexible `TPU` 3D printers, solder micro-electronics, flash Betaflight firmware, and fly First-Person View (FPV) micro-drones.
> - **Paid Career Ladder:** Start as a **Tier 1 Shop & Flight Apprentice (`$22–$25/hr` or via JCYC/DCYF Youth Workforce placement)** prepping 3D-printed `CUB-75` kits and assisting at weekend flight workshops, and graduate at age 18 into a **`$30/hr` Certified Station Flight Coach**!
> - **Contact:** Ask your JCYC Workhub / CYC / Mission Science Workshop coordinator to connect you with **Miguel Flores (`miguel@ositodrone.com`)** and **Jesus Aceves (`jesus@ositodrone.com`)**.

---

## 8. Immediate 30-Day Execution Roadmap to Replace Founders on the First Pod

| Week | Founder Action | Target Milestone |
| :--- | :--- | :--- |
| **Week 1** | • **Jesus & Miguel** pitch **Alasan Jallow (`OS-016` JCYC Workhub)** and **Sonia/Paul (`OS-002` MSW)** on hosting 2–4 DCYF-subsidized **Tier 1 Youth Apprentices**.<br>• **Alan** posts the **Tier 2/3 Flight Coach (`$30–$45/hr`)** role on SFSU/CCSF engineering boards and scouts at **Noisebridge (`272 Capp St`)**. | **8 Qualified Young Candidates** invited to Shop Night Tryouts. |
| **Week 2** | • Run **Shop Night Tryouts + Bootcamp Modules 1 & 2** (Soldering, `CUB75_Motor_Prop_Press_Jig`, `Bat-Safe` rules, `Cub/Scout/Pilot` flight test, ELRS Buddy-Box recovery). | Select & onboard **1× Tier 3 Lead (`$45/hr`)**, **3× Tier 2 Coaches (`$30/hr`)**, and **2× Tier 1 Apprentices**. |
| **Week 3** | • Run **Bootcamp Modules 3, 4 & 5**: New crew shadows Miguel, Alan, and Jesus during 1 live school workshop (`PKG-1`) and 1 weekend venue activation (`PKG-4`/`PKG-5`).<br>• Hand off Friday `PETG-CF` / `TPU 95A` 3D printing and `WhoopStor V3` battery storage duties to the Tier 1 Apprentices. | **Jesus is freed from routine frame printing and battery charging.** |
| **Week 4** | • **First 100% Youth-Led Deployment ("Zero-Founder Flight Test"):** The Tier 3 Lead and 3× Tier 2 Coaches pick up the Pelican 1560/1450 cases, run a full 16-student workshop or weekend party solo, and return the fleet at `3.80V` storage voltage.<br>• Promote the sharpest Tier 3 Lead to co-pilot **Alan's COI/Venue checklist** and **Miguel's QR follow-up funnel**. | **Pod 1 is 100% self-sustaining (`40%–80%` gross margin) with 0 founders on-site.** |
