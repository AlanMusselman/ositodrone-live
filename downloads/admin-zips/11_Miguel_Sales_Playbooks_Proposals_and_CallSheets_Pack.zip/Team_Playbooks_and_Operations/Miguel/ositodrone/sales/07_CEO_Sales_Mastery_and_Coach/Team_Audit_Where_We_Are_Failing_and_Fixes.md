# OSITO DRONE SERVICES: ORGANIZATIONAL & DIGITAL PRESENCE DIAGNOSTIC AUDIT
## Why We Have 0 Jobs Booked Right Now — And Our 48-Hour Turnaround Plan

**Date:** October 30, 2026  
**Prepared For:**
- **Miguel Flores, CEO & Co-Founder** (`415-571-6614` | `miguel@ositodrone.com`)
- **Alan Musselman, COO & Co-Founder** (`415-810-4158` | `alan@ositodrone.com`)
- **Jesus Aceves, CTO & Co-Founder** (`415-269-1206` | `jesus@ositodrone.com`)

---

## Executive Reality Check: Why We Are at $0 Revenue

Alan asked the question every serious founding team must face: ***"Determine where we are not working as a team. Miguel needs direction to get us going."***

Here is the unvarnished truth after auditing our live digital footprint (`ositodrone.com`, Maker Faire Bay Area, `@OSITODroneServices` on YouTube, Google Maps/Yelp, and local competitors like `sfdroneservice.com`) alongside every file in our shared workspace (`c:\Users\Alan Musselman\OneDrive\Documents\Osito drone`):

**We do not have a technology problem, a drone problem, or a market demand problem. We have an execution avoidance and sales-routing problem.**

Right now, the three of us are acting like an R&D hobby club pretending to be a commercial service company. We have built **1,355 `.stl` 3D-print files, 23 Affinity Designer (`.afdesign`) logo/flyer files, 22 OpenSCAD scripts, and 17 speculative drone engineering projects**—while logging **zero outbound sales calls, zero live booking links on our website, and printing an accidental AI prompt disclaimer at the bottom of our flagship school flyer.**

Below is the exact breakdown of **1) What a buyer sees when they look us up online today**, **2) The 5 Team Blind Spots keeping us at 0 jobs**, and **3) The exact 48-Hour Fix & Daily Operating Cadence** for Miguel, Alan, and Jesus.

---

## Part 1: Public Digital Presence Audit (What Customers See Today)

When a San Francisco school principal, parent, property manager, or event planner searches for **Osito Drone Services** today, here is what exists publicly:

| Channel | Current Live State | Conversion Impact |
| :--- | :--- | :--- |
| **Website (`ositodrone.com`)** | Built on GoDaddy Website Builder (`commercePlus` plan). Has 4 pages: `/`, `/osito-drone-academy`, `/custom-aerial-solutions`, `/about`, and `/shop`. | **CRITICAL FRICTION:**<br>1. **Zero Phone Number on the Entire Website:** Not in the header, footer, or Contact section (only lists `San Francisco` and `info@ositodrone.com`).<br>2. **Empty `/shop` Page & Disabled Booking:** Visiting `ositodrone.com/shop` shows a blank page. GoDaddy Online Appointments (`wam_site_hasOla: false`) is turned off. The *"Book a Pop-Up"* button cannot take a deposit.<br>3. **No Real Video or Photos:** The social preview (`og:image`) is a generic GoDaddy Getty stock photo (`getty/917916050`). There is zero real video of kids flying in hover pods or our `SHARD-75` netted cage.<br>4. **Anonymous `/about` Page:** Contains 4 sentences (*"3 Co-Founders with a passion for training folks how to fly, crash, and repair drones"*). Does not name Miguel, Alan, or Jesus, and lists no FAA Part 107 cert numbers or insurance proof. |
| **Maker Faire Bay Area (`makerfaire.com`)** | Official exhibitor profile live for **OSITO Drone Academy**, highlighting youth STEM, palm-sized Tiny Whoop training, and FPV flight education. | **MISSED LEVERAGE:** Maker Faire is huge credibility with SF schools and parents, yet we have **zero real photos or 30-second video clips from Maker Faire embedded on `ositodrone.com`!** |
| **YouTube (`@OSITODroneServices`) & Socials** | YouTube channel exists with raw test uploads (simulator screen tests, Clarion Alley 360 test). Facebook link on site points to an unbranded numerical profile (`profile.php?id=61588329698167`). No active Instagram Reels presence showing kids' reactions or real estate FPV fly-throughs. | **NO SOCIAL PROOF:** A parent booking a $400 birthday party or a principal booking a $1,200 STEM assembly wants to see a **30-second video of real kids smiling in FPV goggles**—not a raw simulator test. |
| **Google Maps / Yelp (San Francisco)** | **No verified Google Business Profile pin or Yelp page with customer reviews.** | **INVISIBLE TO LOCAL INTENT:** When an SF property manager or roofer searches Google Maps for drone services, we do not appear. |
| **Local Competitor Benchmark (`sfdroneservice.com`)** | **San Francisco Drone Service (`sfdroneservice.com`)** plus local competitors (*We Fly Aerial Media*, *Drone Studios*, *FLY.PHOTOS*) rank on Page 1 for SF commercial UAV work. | **WHY THEY WIN JOBS:** `sfdroneservice.com` puts a clickable local phone number (`(628) 309-3546`), FAA Part 107 + insurance callouts, and specific commercial deliverables right at the top of the page. |

---

## Part 2: The 5 Team Blind Spots Keeping Osito at 0 Jobs

### Blind Spot 1: The "Engineering & Design Comfort Zone" Trap
Look at the actual file inventory inside `c:\Users\Alan Musselman\OneDrive\Documents\Osito drone`:
- **1,355 `.stl` 3D-printing mesh files**
- **23 `.afdesign` (Affinity Designer) logo, brochure, and flyer iterations** (`ositologo.afdesign`, `ositologo blak.afdesign`, `ositologo blak back.afdesign`, `desing on logo_only.afdesign`, `osito_brochure.afdesign`, `osito_brochure2.afdesign`, `birthday osito drone event.afdesign`, `birthday osito drone event2.afdesign`, `Birthday_hand_out.afdesign`, `Full page.afdesign`, `one pager Osito services.afdesign`, `services flyer.afdesign`, `SIGN FORM1.afdesign`, `SIGN FORM2.afdesign`)
- **22 `.scad` OpenSCAD parametric CAD files, 64 `.py` scripts, 6 `.step` files, and 6 `.lua` firmware scripts** spread across **17 speculative R&D folders**:
  - `baseball_security_drone` (a baseball-sized toss-to-hover police drone in `PROJECT.md`)
  - `anti_drone_swarm_system`
  - `Osito_PorcupineX_BattleBot_Drone`
  - `Laubacher_Osito_BerryBot_24_7`
  - `Osito_HiveMind_24_7_Swarm_Dock`
  - `Surface Cling Drone`, `Project Morpho`, `smart_disc_golf`, `Osito_Grizzly85_SkyRover`, etc.

**Why are we doing this?** Because designing our 23rd logo iteration in Affinity Designer or writing OpenSCAD scripts for a theoretical "Baseball Tactical Security Drone" feels productive and **cannot reject us**. Picking up the phone, calling 20 SF school principals or property managers, walking into 5 local venues, and hearing *"No"* feels uncomfortable. **Until we impose an immediate R&D and logo-design freeze, we will keep hiding in CAD files while our bank balance stays at $0.**

---

### Blind Spot 2: Broken Inbound Routing & Role Confusion
Look at the three co-founder business cards (`business cards\Miguel.jpg`, `Alan.jpg`, `Jesus.jpg`) versus our outbound flyers (`flyer final.jpg`, `one pager Osito services.pdf`, `birthday osito drone events.pdf`):

| Co-Founder | Title | Direct Cell on Business Card | Email on Business Card | Listed on Flyers? | Listed on `ositodrone.com`? |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Miguel Flores** | **CEO & Co-Founder** (Sales Lead) | `415-571-6614` | `miguel@ositodrone.com` | **NO** | **NO** |
| **Alan Musselman** | **COO & Co-Founder** (Ops/Venues) | `415-810-4158` | `alan@ositodrone.com` | **NO** | **NO** |
| **Jesus Aceves** | **CTO & Co-Founder** (Tech/Flight) | `415-269-1206` | `jesus@ositodrone.com` | **YES (On ALL 3 Flyers!)** | **NO** |

**What is wrong with this picture?**
1. **Every single flyer (`flyer final.jpg`, `one pager Osito services.pdf`, `birthday osito drone events.pdf`) routes 100% of inbound sales calls to `415-269-1206`—which is Jesus the CTO's personal cell phone!**
2. Meanwhile, **Miguel is the CEO (`415-571-6614`)** whose primary job is leading outbound sales and closing accounts, and **Alan is the COO (`415-810-4158`)** structuring pricing, venues, and operations.
3. Worse, `info@ositodrone.com` is printed everywhere, yet there is no single accountable owner with a 15-minute response SLA, and `ositodrone.com` lists **no phone number at all**. When everyone owns `info@ositodrone.com`, **nobody owns it**.

---

### Blind Spot 3: Website & Flyer Credibility Killers (`ositodrone.com` & `flyer final.jpg`)
Even when we hand out a flyer or send someone to `ositodrone.com`, we are actively sabotaging our own credibility:

1. **The AI Prompt Leak on `flyer final.jpg`:**
   Look at the very bottom bar of `flyer final.jpg`:
   > ***"Disclosures & Grounded Sources: Grounded references to internal plans and hardware standards. Honest disclosure of uncertainties: final facility lease launch dates, seasonal pricing finalization, and Maker Faire RF environment coordination."***
   
   **STOP AND READ THAT AGAIN.** That is raw AI generation prompt text printed directly onto the bottom of our customer-facing flyer! If Miguel or Alan emails `flyer final.jpg` as-is to a school principal or parent, it literally announces that our pricing and facility dates are "uncertainties" and that our flyer was auto-generated without anyone proofreading it.
2. **Spelling & Visual Contradictions on `flyer final.jpg` and `Osito Academy.pdf`:**
   - Box 2 of the roadmap on `flyer final.jpg` spells Hovering as ***"Line-of-Sight Hovaring"***.
   - The AI photos on `flyer final.jpg` and `Osito Academy.pdf` show teenagers flying **unshielded open-prop 5-inch carbon-fiber racing drones** inside pop-up laundry hampers—directly contradicting our safety checklist right below it (*"Ultra-lightweight 28.8g ducted drones"*).
3. **Zero Instant Proof or Booking on `ositodrone.com`:**
   - A parent, school director, or realtor visiting `ositodrone.com` cannot watch a 30-second real video of kids flying our ducted AcroBee65 / Tiny Whoops in the hover pods or `SHARD-75` cage, cannot see prices, cannot see a phone number, and cannot click a Square/Stripe link to pay a deposit.

> **IMMEDIATE ASSIST COMPLETED:** A cropped, cleaned version of `flyer final.jpg` with the bottom AI disclaimer bar removed has already been generated for you in the workspace at:  
> [`flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg)

---

### Blind Spot 4: No Daily Accountability Cadence or Swimlane Separation
Right now, Miguel, Alan, and Jesus do not have a rigid **15-minute daily morning standup** or strict role boundaries. As a result:
- **Miguel (CEO)** doesn't have a daily morning call block with a hard target of 20 dials + 5 walk-ins, so outreach gets delayed while waiting for "better flyers" or "new drone builds."
- **Jesus (CTO)** gets pulled into graphic design (`services flyer.afdesign`) or speculative hardware R&D (`baseball_security_drone`) instead of filming a 30-second real flight demo video and running 10-minute live pop-up demos for schools.
- **Alan (COO)** ends up carrying the strategic burden alone, trying to figure out how to get the team moving.

---

### Blind Spot 5: Missing Point-of-Sale & School Vendor Infrastructure
Suppose Miguel walks into a middle school or a parent calls today and says: *"Yes! Let's book the $395 Birthday Party this Sunday"* or *"Let's book the $950 STEM Assembly next Friday."*
**How do they pay us right now?**
- We have **no live Square or Stripe checkout links** (`ositodrone.com/shop` is empty).
- We have **no 1-page Participant Liability & Photo Release Waiver** loaded on a tablet/QR code for parents to sign in 30 seconds.
- We have **no pre-packaged "School & Venue Compliance Folder"** (Signed W-9, 1-page Certificate of Insurance / Thimble.com COI instructions, Live Scan / TB clearance attestation, and 1-page Indoor Micro-Drone Safety SOP) ready to attach the moment an SFUSD or private school director asks for vendor paperwork.

---

## Part 3: The 48-Hour Fix Plan (Who Does What in the Next 2 Days)

To book our first 3 paying jobs within the next 7 days, **all three co-founders must execute these exact fixes over the next 48 hours.**

### 1. Rules of Engagement (Effective Immediately)
- **100% R&D and Graphic Design Freeze:** Nobody opens Affinity Designer (`.afdesign`), OpenSCAD (`.scad`), or any of the 17 speculative drone folders (`baseball_security_drone`, `anti_drone_swarm_system`, etc.) until Osito has collected **$10,000 in paid customer bookings**. We sell **only what we can fly this weekend** with our existing `39.5g CUB-75` / `~30g AcroBee65` kits, hover pods, 4-Pilot Tablet Flight Sim Pod (`Apache 4800 / Pelican 1550`), and DJI/FPV camera gear.
- **Daily 8:30 AM 15-Minute Standup (Phone/Zoom — Mandatory for Miguel, Alan, Jesus):**
  1. **Miguel reports:** How many dials made yesterday? How many walk-ins completed? How many demos/deposits booked? What are today's 20 calls + 5 walk-ins?
  2. **Jesus reports:** Is the demo fleet (8 Tiny Whoops, batteries charged in Bat-Safe, 4-Pilot Tablet Flight Sim Pod (4× 10.1" Tablets + 4× RadioMaster T8L controllers), hover pods/net) 100% packed in the car for today's demos?
  3. **Alan reports:** All inbound leads routed, quotes/payment links sent within 15 minutes, venue/insurance paperwork cleared.

---

### 2. Miguel Flores (CEO) — 48-Hour Action Plan: "Chief Outbound & Closing Officer"
**Miguel's Single Metric That Matters:** **20 Outbound Calls + 5 In-Person SF Walk-Ins Per Day -> 3 Live Demos Booked This Week.**

- [ ] **Hours 1–4 (Fix Your Sales Kit):**
  - Stop using `flyer final.jpg` with the AI disclaimer at the bottom. Use [`flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg) and [`Osito_2027_Commercial_Rate_Card_and_Order_Form.html`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Osito_2027_Commercial_Rate_Card_and_Order_Form.html).
  - Open [`Osito_November_Fast_Cash_Jobs_Tracker.csv`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Osito_November_Fast_Cash_Jobs_Tracker.csv) and [`Osito_SF_Sales_Leads_Tracker.csv`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/Osito_SF_Sales_Leads_Tracker.csv).
- [ ] **Day 1 Morning (9:00 AM – 12:00 PM) — 15 Youth STEM & Camp Calls:**
  - Call the top 15 San Francisco after-school directors, private school STEM coordinators, and Thanksgiving Camp sites from [`November_2026_Fast_Cash_Camps_and_PopUps.md`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/November_2026_Fast_Cash_Camps_and_PopUps.md).
  - **The Pitch (Do NOT try to sell a $10,000 semester over the phone—sell a 10-minute free live pop-up demo or a $600 single block / $960 half-day workshop!):**
    > *"Hi [Name], this is Miguel Flores, CEO of Osito Drone Services here in SF. We exhibited our hands-on Youth Drone & FPV Academy at Maker Faire Bay Area, and we have two open slots in November for a 90-minute Pop-Up Drone Flight & Repair Workshop or Thanksgiving Break Camp using 28-gram enclosed-prop micro-drones inside our safety net. Jesus, our CTO, and I are in your neighborhood this week—can we pop in for 10 minutes on Thursday at 2:00 PM to show you the hover pods in person?"*
- [ ] **Day 1 Afternoon (1:30 PM – 4:30 PM) — 5 In-Person SF Walk-Ins:**
  - Walk into **3 SF real estate/property management offices or luxury listing open houses** and **2 SF breweries/event venues** (from [`November_2026_Events_Brewery_and_Corporate_Blitz.md`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/November_2026_Events_Brewery_and_Corporate_Blitz.md)) with your business card (`415-571-6614`) and tablet showing a 30-second flight clip.
- [ ] **Day 2 (9:00 AM – 4:30 PM) — 15 Commercial Calls (Roofing/Solar/Construction) + 5 Walk-Ins:**
  - Call 15 SF roofing, solar, and general contractors from [`November_2026_Commercial_Drone_Fast_Cash_Leads.md`](file:///c:/Users/Alan%20Musselman/OneDrive/Documents/Osito%20drone/November_2026_Commercial_Drone_Fast_Cash_Leads.md) offering a **$245 Single Roof Thermal/4K Inspection ($195 Nov Flash Promo) or $450 Construction Ortho/4K Shoot** so they don't have to climb a ladder before winter rains.

---

### 3. Alan Musselman (COO) — 48-Hour Action Plan: "Chief Conversion, Routing & Operations Officer"
**Alan's Single Metric That Matters:** **Zero Lead Leakage (<15 Min Response Time) + 1-Click Payment & Compliance Ready Today.**

- [ ] **Fix #1: Unify Phone & Email Routing (Today, 60 Mins):**
  - Set up a free **Google Voice or OpenPhone shared business number** (`(415) XXX-XXXX`) that rings **Miguel (`415-571-6614`) and Alan (`415-810-4158`) simultaneously** (and only rings Jesus if unanswered after 4 rings), OR make **Miguel's cell (`415-571-6614`)** the primary sales line on all outbound pitches and **Alan's cell (`415-810-4158`)** the primary operations/venue line.
  - Set `info@ositodrone.com` to auto-forward immediately to `miguel@ositodrone.com`, `alan@ositodrone.com`, and `jesus@ositodrone.com`, with **Miguel as Primary Owner** (must reply/call within 15 minutes) and **Alan as Backup Owner**.
  - Update the Affinity source files (`services flyer.afdesign`, `one pager Osito services.afdesign`, `birthday osito drone event2.afdesign`) to:
    1. Delete the bottom AI disclaimer bar on `services flyer.afdesign` and fix the typo *"Hovaring"* $\rightarrow$ *"Hovering"*.
    2. Put the Sales/Booking phone number (`415-571-6614` / `415-810-4158`) on the flyers instead of routing cold sales calls to Jesus's cell (`415-269-1206`).
- [ ] **Fix #2: Overhaul `ositodrone.com` in GoDaddy Website Builder (Today, 2 Hours):**
  - Log into GoDaddy Website Builder (`ositodrone.com`) and make 5 immediate changes:
    1. **Add Phone Number to Header & Contact Section:** Put our clickable phone number in the top navigation bar and Contact section.
    2. **Turn On Online Booking / Deposit Buttons:** Enable GoDaddy Online Appointments or add **3 direct Square/Stripe payment buttons**:
       - *Book Youth Drone Birthday Party ($200 60-Min / $299 90-Min Promo / $400 2-Hour — $150 Deposit)*
       - *Book School/Youth STEM Pop-Up Demo (Free 10-Min Principal Demo / $600 Single Block / $960 Half-Day)*
       - *Book Commercial Roof Scan ($245 / $195 Promo) or Real Estate Aerial+FPV Bundle ($495)*
    3. **Hide or Populate `/shop`:** Either delete the empty `/shop` link from the header or populate it with those 3 bookable packages so visitors don't hit a blank page.
    4. **Embed Real Video on Homepage:** Replace the generic Getty stock image with a 30-second YouTube/video embed of our actual Maker Faire booth / hover pods / SF aerial footage.
    5. **Fix the `/about` Page:** Add the names, titles, photos, and contact info of **Miguel Flores (CEO)**, **Alan Musselman (COO)**, and **Jesus Aceves (CTO)**, plus our **FAA Part 107 Certified & Insured** credentials.
- [ ] **Fix #3: Claim Google Business Profile & Create the 3-File Compliance Folder (Day 2, 2 Hours):**
  - Claim **Osito Drone Services** on **Google Business Profile (Google Maps)** and **Yelp San Francisco** as a Service-Area Business in SF, upload our real DJI aerial photos (`DJI_20260717063510_0044_D.JPG`, etc.) and Maker Faire photos, and ask 5 Maker Faire/community contacts for our first 5-star reviews.
  - Create a desktop folder `Osito_Ready_To_Book_Packet` containing:
    1. **Square/Stripe Instant Invoice Link**
    2. **1-Page Participant Liability & Photo Release Waiver (PDF + Google Form QR Code)**
    3. **Signed W-9 + Insurance COI Proof + 1-Page Indoor Micro-Drone Safety Sheet**

---

### 4. Jesus Aceves (CTO) — 48-Hour Action Plan: "Chief Demo & Flight Execution Officer"
**Jesus's Single Metric That Matters:** **2 Real 30-Second Proof Videos Live in 24 Hours + 100% Turnkey "Pop-Up in a Trunk" Demo Kit.**

- [ ] **Fix #1: Film & Upload Two 30-Second Real Proof Videos (Within 24 Hours):**
  - Customers buy with their eyes. Using existing footage from Maker Faire + a 1-hour shoot today, cut and upload to `@OSITODroneServices` YouTube (and send to Alan for `ositodrone.com`):
    1. **Video 1 (30 Seconds — Youth STEM & Birthday Proof):** Real clip of the pop-up hover pods / netted cage, a kid putting on FPV goggles, a ducted AcroBee65 / Tiny Whoop hovering safely bumping into a hand/net with zero harm, and kids cheering.
    2. **Video 2 (30 Seconds — Commercial Real Estate & Roof Inspection Proof):** Smooth indoor-to-outdoor FPV fly-through + crisp 4K DJI top-down roof/property reveal in San Francisco.
- [ ] **Fix #2: Pack the "10-Minute Trunk Demo Kit" for Miguel's Appointments (Within 24 Hours):**
  - Prepare one grab-and-go Pelican/bin kit that lives in the car for Miguel's school and venue appointments:
    - 4x Ducted Tiny Whoops / AcroBee65s (100% tested, props clean)
    - 12x Charged 1S batteries in a fireproof Bat-Safe box
    - 2x Radiomaster Pocket / controller radios + 2x FPV goggles + **1x spectator monitor** (so the school principal or parent can watch the live drone camera feed without putting on goggles!)
    - 1x Pop-Up Hover Pod (takes 30 seconds to unfold inside a principal's office!)
- [ ] **Fix #3: Hold the R&D Line:**
  - Do not build new drone prototypes this week. When Miguel books a 10-minute demo at a school, brewery, or real estate office, **you show up with the Pop-Up Hover Pod and spectator screen, put the controller in the client's hands for 60 seconds, and let Miguel close the check.**

---

## Summary Scorecard: How We Measure Success This Friday

By **Friday at 5:00 PM**, we do NOT judge our team by how many 3D models or flyers we created. We judge ourselves by these 5 binary numbers:

| # | Deliverable / Metric | Owner | Target by Friday 5:00 PM |
| :---: | :--- | :---: | :--- |
| **1** | **`ositodrone.com` Overhauled** (Phone number in header, empty `/shop` fixed, 3 payment/booking buttons live, real video embedded, `/about` page naming Miguel, Alan & Jesus) | **Alan (COO)** | **100% Live** |
| **2** | **Flyers & Routing Fixed** (`flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg` in use, shared ring-group or Miguel's sales number on pitches, <15-min SLA on `info@ositodrone.com`) | **Alan (COO)** | **100% Live** |
| **3** | **2 Real 30-Second Proof Videos + Trunk Demo Kit Packed** (1 Youth STEM/Birthday video + 1 Commercial Roof/FPV video; 1 pop-up hover pod + spectator monitor ready) | **Jesus (CTO)** | **2 Videos + 1 Kit** |
| **4** | **Outbound Sales Blitz Executed** (40+ phone calls + 10+ in-person SF walk-ins logged in `Osito_November_Fast_Cash_Jobs_Tracker.csv`) | **Miguel (CEO)** | **40 Calls / 10 Walk-Ins** |
| **5** | **First Live Demos & Paid Bookings Closed** (In-person 10-min principal/client demos completed and first paid jobs on the calendar) | **Miguel + Team** | **3+ Demos / 1–3 Paid Jobs** |
