# CUSTOM YOUTH DRONE STEM PROPOSAL: ST. JUDE ACADEMY OF SCIENCE

- **Prepared For**: St. Jude Academy of Science (Charter STEM School)
- **Recommended Program**: 8-Week STEM Drone Coding & Autonomous Flight Lab (16 Instruction Hours)
- **AI Lead Priority Score**: 99% Close Probability | Grant-Eligible: **Yes**

## 1. Program Highlights (Aligned with Next-Gen STEM & Aviation Standards)
- **Hands-On Pilot + Coder Pairing**: 96 students paired across **48 programmable safety drone kits** (2:1 student-to-drone ratio so every child flies and codes).
- **Turnkey Certified Instruction**: Includes **7 background-checked Youth Drone Instructors** plus full indoor/outdoor safety netting and FAA TRUST youth safety curriculum.
- **Real-World Autonomous Robotics Concepts**: Students learn how modern drones perceive obstacles and stabilize flight (inspired by UC Berkeley aerial robotics principles).

## 2. Financial & Pricing Summary Table
| Line Item | Quantity / Allocation | Amount (USD) |
| :--- | :--- | :--- |
| **Student Enrollment Capacity** | 96 Students (16 hrs) | Included |
| **Turnkey Programmable Drone Fleet** | 48 Classroom Drone Kits | Included |
| **Certified Flight Instructors** | 7 Instructors (15:1 ratio) | Included |
| **Multi-Site / Volume Partner Discount** | 8% Partner Discount Applied | Applied |
| **Total Turnkey Program Investment** | **All-Inclusive Package** | **$21,196.80** |
| *Effective Cost Per Student* | *$220.80 / student* | *Grant-Ready* |
