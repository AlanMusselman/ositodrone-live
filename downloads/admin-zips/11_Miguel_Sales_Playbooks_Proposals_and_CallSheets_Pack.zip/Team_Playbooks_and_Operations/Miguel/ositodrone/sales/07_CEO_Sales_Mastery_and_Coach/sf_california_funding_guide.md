# Osito Drone Services — San Francisco & California Youth STEM Funding Playbook
**Company:** Osito Drone Services (San Francisco, CA)  
**Leadership Structure:** 3 Co-Founders (Territory-Aligned B2G / B2B Sales & Instruction Engine)  
**Core Mission:** Delivering turnkey, FAA-safe Youth Autonomous Drone, Coding & Aviation STEM Labs across San Francisco schools, Beacon Centers, independent academies, and summer camps.

---

## Executive Overview (The 3-Layer Bridge for Osito Drone Services in SF)

1. **The Executive Mental Model:** San Francisco and the State of California have the highest per-pupil concentration of dedicated out-of-school-time (OST), municipal youth enrichment, and career pathway dollars in the United States. Between California's **$4 Billion ELO-P mandate**, San Francisco's **$300M+ Department of Children, Youth and Their Families (DCYF)** fund, **SF PEEF**, and the **California K12 Strong Workforce Program (SWP)**, youth organizations in SF are actively pressured to spend allocated enrichment budgets on high-engagement, turnkey STEAM vendors. With **3 Co-Founders**, Osito Drone Services has an unfair structural advantage: the team can simultaneously run B2G grant sales AND serve as the initial certified instructional cadre (handling up to 45 students concurrently across 3 cohorts at a 1:15 instructor ratio with $0 external instructor payroll overhead when co-founders teach, or scaling effortlessly with hired instructors).
2. **Under the Hood (SF & CA Procurement Mechanics):** Rather than waiting for slow SFUSD central office RFPs (which can take 9–12 months), Osito Drone Services can close contracts in **2 to 6 weeks** by contracting directly with:
   - **SF Community-Based Organizations (CBOs) & Beacon Lead Agencies** (YMCA of SF, Boys & Girls Clubs of SF, Mission Graduates, Sunset Youth Services) who hold pre-approved DCYF and ELO-P subcontractor budgets.
   - **SF Charter Management Organizations & Independent Schools** (KIPP Bay Area, Gateway, Lick-Wilmerding, Town School, Hamlin, FAIS) where site leaders have direct credit card / PO signing authority under $10,000–$25,000.
3. **Business & Capstone Application:** This playbook maps the exact California and San Francisco funding streams to a **3-Co-Founder Territory Division**, feeds a live 18-account San Francisco target pipeline (`sf_bay_area_target_leads.csv`), and powers our deterministic Python scoring & proposal automation engine (`run_osito_sf_pipeline.py`).

---

## 1. The Big 4 San Francisco & California Funding Pools

| Funding Pool | Annual Pool Scale | Who Holds the Purse Strings in SF? | Why Osito Drone Services Fits Perfectly | Typical Contract Size |
| :--- | :--- | :--- | :--- | :--- |
| **1. California ELO-P**<br>*(Expanded Learning Opportunities Program)* | **$4.0B Statewide**<br>*(~$35M+ in SF Public & Charter TK–6)* | SFUSD ExCEL (Extended Learning), Charter School Directors (KIPP, Creative Arts, Thomas Edison), and subcontracted Lead CBOs | Mandates **9-hour learning days** and **30 intercession/summer days** for TK–6 unduplicated pupils. CBO site coordinators desperately need specialized hands-on STEAM vendors to fill afternoon and summer blocks. | **$4,500 – $18,000**<br>*(8-Week After-School Lab or Summer Intercession Camp)* |
| **2. SF DCYF & SF Beacon Centers**<br>*(Dept. of Children, Youth & Their Families)* | **$300M+ Citywide**<br>*(SF Children & Youth Fund)* | SF Beacon Directors (Marina, Presidio, Everett, Visitacion Valley, Sunset), YMCA of SF, Boys & Girls Clubs of SF, Mission Graduates | DCYF explicitly funds **Project-Based STEAM Enrichment** and **Youth Workforce Readiness** inside neighborhood Beacon centers and clubhouses. CBO leads hire external specialty instructors via simple vendor invoices. | **$5,000 – $22,000**<br>*(Multi-Site Beacon Cohort or Summer Flight Academy)* |
| **3. SF PEEF & CA Prop 28**<br>*(Public Education Enrichment Fund & STEAM/Media Arts)* | **$70M+ SF Local + Prop 28 Site Allocations** | Individual SFUSD School Principals, School Site Councils (SSC), and PTSAs | Provides principal-discretionary funds for hands-on enrichment, technology integration, and creative aerial media/design partnerships. | **$2,200 – $9,500**<br>*(1-Day STEM Discovery Days, Family Flight Nights, or 8-Week Electives)* |
| **4. CA K12 Strong Workforce Program (SWP) & Golden State Pathways** | **$150M+ Statewide**<br>*(Bay Area Community College Consortium / BACCC)* | Middle & High School CTE Coordinators, Charter High Schools, SFUSD Career Pathways | Funds **Unmanned Aircraft Systems (UAS), Autonomous Robotics, Python Coding, and FAA TRUST Youth Aviation Safety** pathways connecting Grades 6–12 to Bay Area tech & aerospace careers. | **$6,500 – $25,000+**<br>*(Semester Autonomous Coding & FAA TRUST Pathway Lab)* |

---

### Deep-Dive: How to Unlock Each San Francisco Funding Stream

#### Stream 1: California ELO-P (Expanded Learning Opportunities Program)
* **The Insider Secret:** Every California public and charter school serving TK–6 receives up to **$1,500–$2,750 per student** specifically for before/after-school and 30 days of summer/intersession enrichment. Schools cannot keep this money for regular daytime teacher salaries—they *must* spend it on expanded learning.
* **How Osito Enters Fast:** In San Francisco, most ELO-P and ExCEL site budgets are managed by **Lead Community-Based Organizations (CBOs)** like **Mission Graduates, YMCA of San Francisco, Sunset Youth Services, and Richmond District Neighborhood Center**. Instead of waiting on SFUSD central procurement, Osito signs a simple Subcontractor Vendor Agreement directly with the Lead CBO or Charter School Executive Director.
* **The Pitch:** *"We bring a 100% turnkey 8-week Autonomous Drone & Block/Python Coding Lab to your ELO-P site—complete with propeller-guarded indoor micro-drones, tablets, curriculum, and certified instructors at a 2:1 student-to-drone ratio. Your core after-school staff gets a breather while students master real aerodynamics and coding."*

#### Stream 2: SF DCYF (Department of Children, Youth and Their Families) & SF Beacon Initiative
* **The Insider Secret:** San Francisco is unique in the nation because voters set aside a dedicated portion of property taxes (the Children and Youth Fund) administered by **DCYF**. This funds the **SF Beacon Initiative**—transforming SF middle and elementary schools (like **Marina Middle, Presidio Middle, Francisco Middle, and James Lick**) into year-round community youth hubs.
* **How Osito Enters Fast:** Each Beacon Center has a **Beacon Director** with discretionary budget for specialized enrichment partners in three seasons: **Fall (Sep–Dec), Spring (Jan–May), and Summer (Jun–Aug)**.
* **The Pitch:** *"Middle schoolers vote with their feet in after-school programs. Osito Drone Services delivers a high-retention 'Pilot + Coder' Autonomous Obstacle Course League tailored for SF Beacon youth, culminating in a neighborhood Family Flight Showcase."*

#### Stream 3: SF Public Education Enrichment Fund (PEEF), PTA Grants & Independent School Auxiliaries
* **The Insider Secret:** On the west and north sides of SF (Sunset, Richmond, Marina, Noe Valley, Pacific Heights), elementary/middle PTAs and Independent School Auxiliary Directors (at schools like **Town School for Boys, Hamlin, Lick-Wilmerding, and French American International School**) control substantial discretionary enrichment and auxiliary camp budgets.
* **How Osito Enters Fast:** Pitch **1-Day School-Wide STEM Discovery Workshops** (to build instant parent buzz) alongside **Revenue-Share or Flat-Fee After-School Auxiliary Classes** where tuition-paying families easily cover a premium per-student rate.

#### Stream 4: CA K12 Strong Workforce Program (SWP), Perkins V & Golden State Pathways
* **The Insider Secret:** The **Bay Area Community College Consortium (BACCC)** and California's **K12 SWP** prioritize emerging automation, AI/computer vision, and aviation technology pathways starting in middle school career exploration through high school CTE.
* **How Osito Enters Fast:** Highlight that every Osito student completes **FAA TRUST (The Recreational UAS Safety Test)** youth certification training alongside Python autonomous flight scripting—giving the school a tangible, reportable **Industry-Recognized Credential (IRC)** metric for their state grant report.

---

## 2. The 3-Co-Founder "Divide & Conquer" SF Territory Model

With **3 Co-Founders** based in San Francisco, Osito Drone Services avoids overlapping outreach and maximizes founder equity value by dividing the city into three specialized verticals:

```mermaid
flowchart TD
    Osito["Osito Drone Services (San Francisco, CA)<br>3 Co-Founders | Equal 1/3 Profit Split"]
    
    CF1["Co-Founder 1:<br>Public Schools & ELO-P / DCYF Grants"]
    CF2["Co-Founder 2:<br>Independent & Charter STEM Schools"]
    CF3["Co-Founder 3:<br>Summer Camps, SF Rec & Youth Hubs"]

    Osito --> CF1
    Osito --> CF2
    Osito --> CF3

    CF1 --> CF1_Acc["• SFUSD Beacon Centers (Marina, Presidio)<br>• Mission Graduates & YMCA SF ELO-P<br>• Sunset Youth Services & SFUSD CTE"]
    CF2 --> CF2_Acc["• KIPP SF Bay & Gateway Charter<br>• Lick-Wilmerding, Town School, Hamlin<br>• French American Int'l & Creative Arts"]
    CF3 --> CF3_Acc["• Boys & Girls Clubs of SF (Don Fisher)<br>• SF Rec & Parks (Eureka Valley / Upper Noe)<br>• Galileo, Steve & Kate's, Exploratorium, JCCSF"]
```

### Territory Breakdown & Co-Founder KPIs

| Co-Founder Role | Target Vertical & Neighborhood Hubs | Primary Funding / Revenue Mechanism | Strategic Advantage |
| :--- | :--- | :--- | :--- |
| **Co-Founder 1**<br>*Public & ELO-P / DCYF Grants Lead* | **SFUSD Middle/Elem Beacons & CBOs**<br>*(Marina, Presidio, Mission, Sunset, Chinatown/Western Addition)* | **CA ELO-P, SF DCYF, Title IV-A, K12 SWP**<br>*(B2G Grant POs & CBO Subcontracts)* | Builds recurring multi-site contracts where one CBO relationship (e.g., YMCA SF or Mission Graduates) unlocks 5–10 school sites. |
| **Co-Founder 2**<br>*Independent & Charter STEM Lead* | **SF Independent Schools & Public Charters**<br>*(Pacific Heights, Hayes Valley, Potrero, Fillmore, Noe Valley)* | **Auxiliary Programs, Tuition-Funded STEM, Charter ELO-P & Perkins V** | Fast decision cycles (1–3 weeks); high willingness to pay for Python/AI autonomy curriculum; high-margin repeat semesters. |
| **Co-Founder 3**<br>*Summer Camps & SF Youth Hubs Lead* | **Citywide Clubhouses, Rec Centers & Major Camp Brands**<br>*(NOPA, Castro/Noe, Embarcadero, Presidio Heights)* | **SF Rec & Parks Partnerships, Camp Sub-Licensing, Donor/Foundation STEM Grants** | Captures peak summer/holiday volume (June–August & school breaks) with 5-Day Summer Flight Camps to keep utilization high 12 months a year. |

---

## 3. Copy-Paste California & San Francisco Grant Justification Block

> **For SF Principals, Beacon Directors & CBO Grant Writers (ELO-P / DCYF / K12 SWP Ready):**  
> *"Osito Drone Services (San Francisco, CA) provides a turnkey, standards-aligned Youth Autonomous Drone & Coding Enrichment Program explicitly designed to meet California Expanded Learning Opportunities Program (ELO-P) quality standards, San Francisco Department of Children, Youth and Their Families (DCYF) STEAM & Workforce Readiness outcomes, and Next Generation Science Standards (NGSS MS-ETS1 / MS-PS2). Utilizing a collaborative 2:1 student-to-drone engineering model (1 Pilot + 1 Coder/Spotter per programmable aircraft) and a 15:1 student-to-certified-instructor ratio, students progress from FAA TRUST youth recreational aviation safety certification to block- and Python-based autonomous flight programming, 3D coordinate navigation, and sensor feedback loops. All hardware, propeller-guarded indoor/outdoor micro-drones, coding tablets, liability coverage, and certified instructors are provided turnkey by Osito Drone Services with zero burden on host site staff."*
