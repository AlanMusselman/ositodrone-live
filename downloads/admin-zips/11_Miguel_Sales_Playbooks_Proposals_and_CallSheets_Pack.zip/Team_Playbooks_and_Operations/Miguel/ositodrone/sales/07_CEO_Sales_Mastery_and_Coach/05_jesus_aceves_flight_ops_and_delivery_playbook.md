# CTO Hardware, Fleet Engineering & Technical Demo Playbook: Built for Jesus Aceves (CTO)

> **The Osito C-Suite Triangle (`ositodrone.com`)**:
> - **Miguel — CEO (Chief Executive Officer)**: Leads Revenue, Outbound Sales, and Executive Partnerships—running the Daily 5-Touch Sales Cockpit and booking the 12-Minute School & Camp Demos.
> - **Alan Musselman — COO (Chief Operating Officer)**: Leads AI Strategy & Automation (via UC Berkeley ExecEd), Program Operations, Unit Economics/Grants, Staffing Compliance, and Delivery Excellence.
> - **Jesus Aceves — CTO (Chief Technology Officer)**: Leads Drone Fleet Engineering, FPV & Autonomous Flight Systems (Blockly/Python/Sensors), Classroom Tech Reliability, and Commercial Aerial Hardware.

---

## 1. Jesus's Superpower #1: The "Zero-Glitch" 12-Minute Principal Demo Kit
When **Miguel** books a 12-minute drop-by with a San Francisco principal or camp director, the deal is won or lost in the first 90 seconds based on how smooth the physical drone demo is.

### Jesus's "Grab-and-Go" Demo Pelican Case Checklist (Always Charged & Ready)
- [ ] **3 Palm-Sized 360°-Guarded Micro-Drones** (1 for the Principal to fly in Line-of-Sight mode, 1 pre-paired with an iPad running Blockly/Python autonomous takeoff-hover-land code, 1 backup).
- [ ] **8 Fully Charged 1S LiPo/LiHV Batteries** (labeled `#1–#8` in a fireproof LiPo safe bag + 6-port USB-C field charger).
- [ ] **1 Pop-Up LED Micro-Gate** (takes 10 seconds to unfold on the principal's office rug—instantly transforms a boring office into an indoor flight arena!).
- [ ] **3 Printed Leave-Behind Folders** containing:
  1. Osito Drone Services 1-Page Executive Flyer
  2. Sample **FAA TRUST Youth Safety Certificate** with the school's name pre-printed on it as a souvenir for the Principal!
  3. Copy-paste **CA ELO-P / SF DCYF Grant Justification Sheet**

---

## 2. Jesus's Superpower #2: The 60-Student Classroom & Camp Delivery SOP
To protect our **50%+ gross margins** across San Francisco schools and camps, fleet reliability and battery logistics must run like clockwork:

1. **The "2:1 Pilot + Spotter/Coder" Classroom Rhythm**:
   - Every 15 minutes, students swap roles: **Student A (Pilot / Flight Engineer)** and **Student B (Air Traffic Spotter & Code Debugger)**.
   - This cuts battery consumption in half, guarantees 100% safety supervision, and keeps 30 drones flying smoothly for 60 students.
2. **Color-Coded Squads (Red, Blue, Gold, Green — 15 Students per Instructor)**:
   - Each drone kit is color-banded to match its controller and spare battery tray so middle schoolers never cross-pair controllers in the gym.
3. **The 5-Minute End-of-Class "Prop & Battery Check"**:
   - Students earn their "Chief Flight Mechanic" stamp by checking all 4 prop guards and plugging their drone into the charging station before dismissal—saving Jesus and the instructors 30 minutes of cleanup!

---

## 3. Jesus's Superpower #3: The On-Site "Re-Booking & Referral Trigger"
The easiest time to sell the *next* Osito contract is during the final 15 minutes of a successful session when kids are cheering and the site director is smiling.

### Jesus's 3-Step End-of-Program Handoff Back to Miguel:
1. **The 15-Second "Principal Walk-In" Moment**: During the final week's obstacle course challenge, invite the Principal or Camp Director into the gym for 3 minutes to hand out the **FAA TRUST Youth Pilot Certificates** and take a group photo (with school-approved media release).
2. **The On-Site Renewal Ask**: While the Principal is watching the kids fly, say:
   > *"The kids did amazing this session! Miguel is holding our Spring/Summer calendar slots this week—should I have him lock in your dates for the Level 2 Autonomous Coding cohort so you don't lose your ELO-P slot?"*
3. **Text Miguel the Green Light**: Drop a quick text to Miguel & Alan: *"Principal loved the finale—send the renewal invoice today!"*
