"""
Osito Drone Services (San Francisco, CA) — 3-Co-Founder B2G/B2B Pipeline & Proposal Engine
==========================================================================================
Follows the `drone-stem-sales-engine` skill & UC Berkeley Executive Education 3-Layer Bridge:
1. Perception & Lead Triage: Ingests `sf_bay_area_target_leads.csv` (18 real SF organizations across 3 Co-Founder territories)
   and scores each lead on Student Volume, SF/CA Funding Readiness (ELO-P, DCYF, K12 SWP, Auxiliary), and Urgency.
2. Deterministic Unit Economics (Zero Math Hallucinations):
   - Drone-to-Student Ratio: 1 programmable drone kit per 2 students (Pilot + Coder/Spotter)
   - Instructor-to-Student Ratio: 1 certified instructor per 15 students
   - Calculates Client Price, Per-Student Effective Grant Cost, COGS/Labor/Equipment Reserve,
     Gross Profit, and the 1/3 Profit Split per Co-Founder.
3. Tailored Proposal Generation:
   - Generates ready-to-send custom proposals for the #1 ranked lead in each of the 3 Co-Founder territories
     and saves them to `top_3_cofounder_proposals.md`.
"""

from __future__ import annotations
import csv
import math
from pathlib import Path
from typing import Dict, List, Any


BASE_DIR = Path(__file__).resolve().parent
CSV_PATH = BASE_DIR / "sf_bay_area_target_leads.csv"
PROPOSALS_PATH = BASE_DIR / "top_3_cofounder_proposals.md"


# ============================================================================
# 1. DETERMINISTIC PROGRAM CATALOG & UNIT ECONOMICS (SF BAY AREA RATES)
# ============================================================================
PROGRAM_CATALOG: Dict[str, Dict[str, Any]] = {
    "8-Week After-School Autonomous Drone & Coding Lab": {
        "short_name": "8-Week Autonomous Lab",
        "sessions": 8,
        "hours_per_session": 2.0,  # 16 total instructional hours + prep
        "base_fee": 2800.0,
        "per_student_rate": 165.0,
        "workbook_and_trust_cert_per_student": 18.0,
        "equipment_amortization_per_kit": 55.0,
        "instructor_hourly_cost": 65.0,  # SF certified STEM/aviation instructor rate
    },
    "5-Day Summer Flight Camp": {
        "short_name": "5-Day Summer Flight Camp",
        "sessions": 5,
        "hours_per_session": 6.0,  # 30 total camp hours
        "base_fee": 3400.0,
        "per_student_rate": 210.0,
        "workbook_and_trust_cert_per_student": 22.0,
        "equipment_amortization_per_kit": 75.0,
        "instructor_hourly_cost": 65.0,
    },
    "1-Day STEM Discovery Workshop": {
        "short_name": "1-Day Discovery Workshop",
        "sessions": 1,
        "hours_per_session": 5.0,  # Full school day or workshop + family showcase
        "base_fee": 1450.0,
        "per_student_rate": 55.0,
        "workbook_and_trust_cert_per_student": 10.0,
        "equipment_amortization_per_kit": 25.0,
        "instructor_hourly_cost": 65.0,
    },
}


def infer_program_format(inquiry_notes: str) -> str:
    """Selects the exact Osito Drone Services program format based on lead inquiry notes."""
    notes_lower = inquiry_notes.lower()
    if "1-day" in notes_lower or "discovery" in notes_lower:
        return "1-Day STEM Discovery Workshop"
    if "5-day" in notes_lower or "summer flight camp" in notes_lower:
        return "5-Day Summer Flight Camp"
    return "8-Week After-School Autonomous Drone & Coding Lab"


def score_sf_lead(row: Dict[str, str]) -> float:
    """
    Calculates a composite 0-100 Lead Priority Score based on:
    - Student Volume (up to 40 pts)
    - SF/CA Grant & Budget Readiness (up to 35 pts)
    - Timeline Urgency / Recency of Inquiry (up to 25 pts)
    """
    students = int(row["estimated_students"])
    days_ago = int(row["past_engagement_days_ago"])
    funding = row["primary_funding_source"].lower()
    notes = row["inquiry_notes"].lower()

    # 1. Volume Score (max 40 pts, scaled against 60 students)
    volume_score = min(40.0, (students / 60.0) * 40.0)

    # 2. Funding Readiness Score (max 35 pts)
    funding_score = 22.0
    if any(k in funding for k in ["elo-p", "dcyf", "title iv", "strong workforce", "perkins"]):
        funding_score = 35.0
    elif any(k in funding for k in ["auxiliary", "endowment", "tuition", "corporate"]):
        funding_score = 32.0

    # Bonus if inquiry explicitly mentions urgent/immediate/ready funds
    if any(k in notes for k in ["urgent", "immediate", "ready now", "unspent"]):
        funding_score = min(35.0, funding_score + 3.0)

    # 3. Timeline Urgency Score (max 25 pts: fresher inquiry = higher score)
    urgency_score = max(5.0, 25.0 - (days_ago * 1.1))

    return round(volume_score + funding_score + urgency_score, 1)


def calculate_osito_economics(row: Dict[str, str]) -> Dict[str, Any]:
    """
    Deterministic financial calculator for Osito Drone Services (San Francisco, CA).
    Enforces:
      - 1 programmable drone kit per 2 students (Pilot + Coder/Spotter)
      - 1 certified instructor per 15 students
      - Equal 1/3 gross profit split across the 3 Co-Founders
    """
    students = int(row["estimated_students"])
    program_name = infer_program_format(row["inquiry_notes"])
    spec = PROGRAM_CATALOG[program_name]

    # Required hardware & staffing ratios
    drone_kits_required = math.ceil(students / 2.0)
    instructors_required = math.ceil(students / 15.0)
    total_instructional_hours = spec["sessions"] * spec["hours_per_session"]

    # Client-facing pricing
    client_price = spec["base_fee"] + (students * spec["per_student_rate"])
    per_student_effective_cost = round(client_price / students, 2)

    # Internal COGS & operating costs
    instructor_labor_cost = (
        instructors_required * total_instructional_hours * spec["instructor_hourly_cost"]
    )
    equipment_reserve_cost = drone_kits_required * spec["equipment_amortization_per_kit"]
    materials_and_trust_certs = students * spec["workbook_and_trust_cert_per_student"]
    sf_insurance_and_logistics = 250.0

    total_cogs = (
        instructor_labor_cost
        + equipment_reserve_cost
        + materials_and_trust_certs
        + sf_insurance_and_logistics
    )
    gross_profit = client_price - total_cogs
    gross_margin_pct = round((gross_profit / client_price) * 100.0, 1)

    # 3 Co-Founders equal profit split (1/3 each)
    profit_per_cofounder = round(gross_profit / 3.0, 2)

    # Note: If the 3 Co-Founders teach the sessions themselves, they also capture the instructor labor pool!
    founder_taught_cash_flow = gross_profit + instructor_labor_cost
    founder_taught_per_cofounder = round(founder_taught_cash_flow / 3.0, 2)

    return {
        **row,
        "estimated_students": students,
        "past_engagement_days_ago": int(row["past_engagement_days_ago"]),
        "program_name": program_name,
        "short_program_name": spec["short_name"],
        "lead_score": score_sf_lead(row),
        "drone_kits_required": drone_kits_required,
        "instructors_required": instructors_required,
        "total_hours": total_instructional_hours,
        "client_price": round(client_price, 2),
        "per_student_effective_cost": per_student_effective_cost,
        "instructor_labor_cost": round(instructor_labor_cost, 2),
        "equipment_reserve_cost": round(equipment_reserve_cost, 2),
        "materials_and_trust_certs": round(materials_and_trust_certs, 2),
        "sf_insurance_and_logistics": sf_insurance_and_logistics,
        "total_cogs": round(total_cogs, 2),
        "gross_profit": round(gross_profit, 2),
        "gross_margin_pct": gross_margin_pct,
        "profit_per_cofounder": profit_per_cofounder,
        "founder_taught_cash_flow": round(founder_taught_cash_flow, 2),
        "founder_taught_per_cofounder": founder_taught_per_cofounder,
    }


def generate_proposal_markdown(top_leads_by_territory: Dict[str, Dict[str, Any]], all_leads: List[Dict[str, Any]]) -> str:
    """Creates `top_3_cofounder_proposals.md` with custom proposals for each Co-Founder's #1 SF lead."""
    total_rev = sum(x["client_price"] for x in all_leads)
    total_gp = sum(x["gross_profit"] for x in all_leads)
    total_founder_taught = sum(x["founder_taught_cash_flow"] for x in all_leads)

    lines = [
        "# Osito Drone Services (San Francisco, CA) — Top 3 Co-Founder Proposals",
        "**Generated By:** `run_osito_sf_pipeline.py` (Deterministic SF Lead Scoring & Unit Economics Engine)  ",
        "**Company Structure:** 3 Co-Founders | Equal 1/3 Profit Split | San Francisco, CA  ",
        "",
        "## Executive Pipeline Summary (All 18 San Francisco Target Accounts)",
        f"- **Total SF Pipeline Contract Value (18 Accounts):** `${total_rev:,.2f}`",
        f"- **Total Standard Gross Profit (After Paying External Instructors):** `${total_gp:,.2f}` (**`${total_gp / 3.0:,.2f}` per Co-Founder**)",
        f"- **Total Founder-Taught Net Cash Flow (When the 3 Co-Founders Instruct Cohorts Directly):** `${total_founder_taught:,.2f}` (**`${total_founder_taught / 3.0:,.2f}` per Co-Founder**)",
        "",
        "---",
        "",
    ]

    for idx, (territory, lead) in enumerate(top_leads_by_territory.items(), start=1):
        is_camp_or_hub = "Co-Founder 3" in territory
        persona_focus = (
            "Turnkey Summer Camp Staffing, Zero Burden on Clubhouse Staff, Indoor/Outdoor Netted Safety & High Youth Engagement"
            if is_camp_or_hub
            else "CA ELO-P / SF DCYF Grant Compliance, NGSS Physics & Engineering Standards, Python/Block Autonomous Coding & FAA TRUST Certification"
        )

        lines.extend([
            f"## Proposal #{idx}: {lead['organization_name']} ({lead['sf_neighborhood']}, SF)",
            f"**Territory Owner:** `{territory}`  ",
            f"**Lead Priority Score:** `{lead['lead_score']} / 100` (Rank #1 in Territory)  ",
            f"**Recommended Program:** **{lead['program_name']}**  ",
            f"**Primary Funding Stream:** `{lead['primary_funding_source']}`  ",
            f"**Buyer Persona Emphasis:** {persona_focus}  ",
            "",
            "### 1. Executive Pitch & Program Overview (Ready to Send to Buyer)",
            f"> **Dear Leadership Team at {lead['organization_name']},**  ",
            f"> Following up on your recent inquiry (*\"{lead['inquiry_notes']}\"*), **Osito Drone Services (San Francisco, CA)** is pleased to present this turnkey proposal for **{lead['estimated_students']} students** at your **{lead['sf_neighborhood']}** campus.  ",
            ">  ",
            f"> Our **{lead['program_name']}** transitions youth from passive screen users into active aviation engineers and autonomous robotics coders. Using our signature **2:1 Student-to-Drone Paired Engineering Model** (1 Pilot-in-Command + 1 Autonomous Coder/Visual Spotter per programmable aircraft) and a strict **15:1 Student-to-Certified-Instructor Ratio**, we bring every piece of equipment, tablet, spare battery, propeller guard, curriculum workbook, and FAA-certified instructor directly to your San Francisco site—placing **zero operational burden on your staff**.",
            "",
            "### 2. Client-Facing Pricing & Grant Justification Table",
            "| Deliverable / Program Component | Operational Ratio / Specification | Included in Package |",
            "| :--- | :--- | :--- |",
            f"| **Program Format** | {lead['program_name']} ({lead['total_hours']:.0f} Instructional Hours) | Included |",
            f"| **Student Capacity** | **{lead['estimated_students']} Students** ({lead['instructors_required']} Cohorts of up to 15) | Included |",
            f"| **Programmable Educational Drone Fleet** | **{lead['drone_kits_required']} Autonomous Drone Kits** (1:2 Drone-to-Student Ratio) | Included |",
            f"| **Certified Aviation & STEM Instructors** | **{lead['instructors_required']} Osito Certified Instructors** (1:15 Instructor-to-Student Ratio) | Included |",
            "| **Safety & Credentials** | Propeller-Guarded Indoor/Outdoor Fleet, Safety Obstacles & **FAA TRUST Youth Safety Certificates** | Included |",
            f"| **Total Turnkey Contract Investment** | **All-Inclusive Flat Fee (`{lead['primary_funding_source']}` Eligible)** | **${lead['client_price']:,.2f}** |",
            f"| **Effective Per-Student Grant Cost** | **For ELO-P / DCYF / Board Requisition Forms ({lead['estimated_students']} Students)** | **${lead['per_student_effective_cost']:,.2f} / student** |",
            "",
            "### 3. Copy-Paste San Francisco Grant / Board Justification Block",
            f"> *\"This requisition funds a turnkey contract with **Osito Drone Services (San Francisco, CA)** to deliver a **{lead['program_name']}** for **{lead['estimated_students']} youth** at **{lead['organization_name']}** (`${lead['per_student_effective_cost']:,.2f}` effective cost per student) funded via **{lead['primary_funding_source']}**. The program satisfies California ELO-P and SF DCYF hands-on STEAM and career readiness benchmarks, Next Generation Science Standards (NGSS MS-ETS1 Engineering Design & MS-PS2 Forces and Motion), and Computer Science autonomous robotics coding. Operating at a 2:1 student-to-drone ratio ({lead['drone_kits_required']} programmable drone kits) and a 15:1 student-to-certified-instructor ratio ({lead['instructors_required']} instructors), all participants complete FAA TRUST recreational aviation safety training alongside block- and Python-based autonomous flight programming.\"*",
            "",
            "### 4. Internal Osito Drone Services Margin & 3-Co-Founder Split (Confidential)",
            "| Financial Metric | Deterministic Calculation | Amount (USD) |",
            "| :--- | :--- | :--- |",
            f"| **Gross Client Contract Revenue** | Base Fee + ({lead['estimated_students']} Students × Per-Student Rate) | **${lead['client_price']:,.2f}** |",
            f"| **(-) Certified Instructor Labor Pool** | {lead['instructors_required']} Instructors × {lead['total_hours']:.0f} hrs × $65/hr | -${lead['instructor_labor_cost']:,.2f} |",
            f"| **(-) Drone Fleet Reserve & Maintenance** | {lead['drone_kits_required']} Programmable Kits Amortized Reserve | -${lead['equipment_reserve_cost']:,.2f} |",
            f"| **(-) Student Workbooks & FAA TRUST Certs** | {lead['estimated_students']} Students × Curriculum & Badge Kit | -${lead['materials_and_trust_certs']:,.2f} |",
            f"| **(-) SF Insurance & Site Transport** | Local San Francisco Van/Transit & Liability Alloc. | -${lead['sf_insurance_and_logistics']:,.2f} |",
            f"| **(=) Standard Net Gross Profit ({lead['gross_margin_pct']}%)** | Revenue Minus All COGS & External Instructor Labor | **${lead['gross_profit']:,.2f}** |",
            f"| **Standard 1/3 Profit Share Per Co-Founder** | Equal Split Across All 3 Osito Co-Founders | **${lead['profit_per_cofounder']:,.2f} / Co-Founder** |",
            f"| **Founder-Taught Net Cash Flow (Bonus Mode)** | If the 3 Co-Founders Instruct This Cohort Directly | **${lead['founder_taught_cash_flow']:,.2f} (${lead['founder_taught_per_cofounder']:,.2f} / Co-Founder)** |",
            "",
            "---",
            "",
        ])

    return "\n".join(lines)


def main() -> None:
    with CSV_PATH.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        raw_leads = list(reader)

    evaluated_leads = [calculate_osito_economics(row) for row in raw_leads]
    evaluated_leads.sort(key=lambda x: x["lead_score"], reverse=True)

    # Group by the 3 Co-Founder territories
    territories: Dict[str, List[Dict[str, Any]]] = {}
    for lead in evaluated_leads:
        owner = lead["cofounder_owner"]
        territories.setdefault(owner, []).append(lead)

    print("=" * 105)
    print("OSITO DRONE SERVICES (SAN FRANCISCO, CA) — 3-CO-FOUNDER PIPELINE & UNIT ECONOMICS ENGINE")
    print("=" * 105)

    top_leads_by_territory: Dict[str, Dict[str, Any]] = {}

    for owner in sorted(territories.keys()):
        owner_leads = sorted(territories[owner], key=lambda x: x["lead_score"], reverse=True)
        top_leads_by_territory[owner] = owner_leads[0]

        sub_rev = sum(x["client_price"] for x in owner_leads)
        sub_gp = sum(x["gross_profit"] for x in owner_leads)
        sub_students = sum(x["estimated_students"] for x in owner_leads)

        print(f"\n>>> TERRITORY: {owner}")
        print(f"{'ID':<7} | {'Organization (SF Neighborhood)':<44} | {'Score':<5} | {'Students':<8} | {'Price':<10} | {'Gross Profit':<12} | {'1/3 Split'}")
        print("-" * 105)
        for item in owner_leads:
            org_label = f"{item['organization_name'][:30]} ({item['sf_neighborhood'][:10]})"
            print(
                f"{item['org_id']:<7} | {org_label:<44} | {item['lead_score']:<5.1f} | "
                f"{item['estimated_students']:<8d} | ${item['client_price']:>8,.0f} | "
                f"${item['gross_profit']:>10,.0f} | ${item['profit_per_cofounder']:>8,.0f}"
            )
        print("-" * 105)
        print(
            f"TERRITORY SUBTOTAL ({len(owner_leads)} SF Accounts, {sub_students} Students): "
            f"Revenue = ${sub_rev:,.2f} | Gross Profit = ${sub_gp:,.2f} | "
            f"Per-Co-Founder Share = ${sub_gp / 3.0:,.2f}"
        )

    total_rev = sum(x["client_price"] for x in evaluated_leads)
    total_gp = sum(x["gross_profit"] for x in evaluated_leads)
    total_founder_cash = sum(x["founder_taught_cash_flow"] for x in evaluated_leads)
    total_students = sum(x["estimated_students"] for x in evaluated_leads)

    print("\n" + "=" * 105)
    print(f"GRAND TOTAL SF PIPELINE (18 Accounts | {total_students} SF Students):")
    print(f"  • Total Gross Revenue:                  ${total_rev:,.2f}")
    print(f"  • Total Standard Gross Profit:          ${total_gp:,.2f} (${total_gp / 3.0:,.2f} per Co-Founder @ 1/3 split)")
    print(f"  • Total Founder-Taught Net Cash Flow:   ${total_founder_cash:,.2f} (${total_founder_cash / 3.0:,.2f} per Co-Founder if Founders instruct)")
    print("=" * 105)

    # Write top 3 proposals file
    proposals_md = generate_proposal_markdown(top_leads_by_territory, evaluated_leads)
    PROPOSALS_PATH.write_text(proposals_md, encoding="utf-8")
    print(f"\n[SUCCESS] Wrote Top 3 Co-Founder Proposals to: {PROPOSALS_PATH}")


if __name__ == "__main__":
    main()
