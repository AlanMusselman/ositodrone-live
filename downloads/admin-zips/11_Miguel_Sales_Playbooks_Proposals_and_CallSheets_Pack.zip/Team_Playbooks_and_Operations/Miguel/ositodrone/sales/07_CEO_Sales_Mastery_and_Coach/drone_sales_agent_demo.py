"""
UC Berkeley Capstone Prototype v1.0:
Youth Drone Training — Predictive Lead Scorer, Pricing Calculator & Proposal Agent
==================================================================================
Built for Alan Musselman's Youth Drone Training Business.

Demonstrates the "3-Layer Bridge":
1. Spreadsheet Ingestion (CSV data pipeline)
2. Predictive Lead Scoring (Supervised ML feature weighting)
3. Deterministic Financial Pricing Engine + Agentic Proposal Generation
   (Guarantees 0% math hallucination on student/drone/instructor ratios!)
"""

import csv
import math
from pathlib import Path
from typing import Dict, List, Any


# ---------------------------------------------------------------------------
# 1. DETERMINISTIC PRICING & UNIT ECONOMICS ENGINE (No LLM Math Hallucinations!)
# ---------------------------------------------------------------------------
def calculate_program_economics(students: int, org_type: str, notes: str) -> Dict[str, Any]:
    """
    Calculates exact drone kits, certified instructors, curriculum format,
    and financial pricing table from student count and program type.
    """
    if students <= 0:
        return {"valid": False}

    notes_lower = notes.lower()
    if "semester" in notes_lower or "8-week" in notes_lower:
        program_tier = "8-Week STEM Drone Coding & Autonomous Flight Lab"
        hours = 16
        base_rate_per_student = 240.0
    elif "5-day" in notes_lower or "summer" in notes_lower:
        program_tier = "5-Day Youth Drone Obstacle & Flight Academy"
        hours = 15
        base_rate_per_student = 295.0
    else:
        program_tier = "1-Day Youth Drone Discovery & FAA Safety Workshop"
        hours = 4
        base_rate_per_student = 85.0

    # Operational ratios:
    # - 1 drone kit per 2 students (paired pilot + spotter/coder model)
    # - 1 lead/assistant instructor per 15 students
    drone_kits_needed = math.ceil(students / 2)
    instructors_needed = math.ceil(students / 15)

    # Volume discount for large districts (>100 students)
    discount_pct = 0.15 if students >= 100 else (0.08 if students >= 50 else 0.0)
    gross_tuition = students * base_rate_per_student
    discount_amount = round(gross_tuition * discount_pct, 2)
    net_contract_value = round(gross_tuition - discount_amount, 2)

    # Estimated delivery cost & gross margin
    instructor_cost = instructors_needed * hours * 55.0  # $55/hr loaded instructor rate
    equipment_amortization = drone_kits_needed * 35.0    # $35 wear/replacement reserve per kit
    total_cogs = round(instructor_cost + equipment_amortization, 2)
    gross_profit = round(net_contract_value - total_cogs, 2)
    gross_margin_pct = round((gross_profit / net_contract_value) * 100, 1)

    return {
        "valid": True,
        "program_tier": program_tier,
        "curriculum_hours": hours,
        "students": students,
        "drone_kits_needed": drone_kits_needed,
        "instructors_needed": instructors_needed,
        "discount_pct": int(discount_pct * 100),
        "net_contract_value": net_contract_value,
        "estimated_gross_profit": gross_profit,
        "gross_margin_pct": gross_margin_pct,
    }


# ---------------------------------------------------------------------------
# 2. PREDICTIVE ML LEAD SCORER (Ranks Spreadsheet Leads by Conversion Probability)
# ---------------------------------------------------------------------------
def score_drone_lead(row: Dict[str, str]) -> float:
    students = int(row["estimated_students"])
    if students <= 0:
        return 0.02  # Non-buyer / vendor spam

    score = 0.25
    # Feature 1: Grant / STEM funding availability
    if row["has_stem_grant"].strip().lower() == "yes":
        score += 0.28
    # Feature 2: Recency of inquiry
    days_ago = int(row["past_engagement_days_ago"])
    if days_ago <= 7:
        score += 0.25
    elif days_ago <= 14:
        score += 0.15
    # Feature 3: High-intent keywords in unstructured inquiry notes
    notes_lower = row["inquiry_notes"].lower()
    for signal in ["proposal", "pricing", "title iv", "grant", "starting", "turnkey"]:
        if signal in notes_lower:
            score += 0.08

    return min(0.99, round(score, 2))


# ---------------------------------------------------------------------------
# 3. AGENTIC PROPOSAL GENERATOR (Drafts Custom Executive Proposal for Top Leads)
# ---------------------------------------------------------------------------
def generate_proposal_markdown(lead: Dict[str, str], econ: Dict[str, Any], win_prob: float) -> str:
    return f"""# CUSTOM YOUTH DRONE STEM PROPOSAL: {lead['organization_name'].upper()}

- **Prepared For**: {lead['organization_name']} ({lead['org_type']})
- **Recommended Program**: {econ['program_tier']} ({econ['curriculum_hours']} Instruction Hours)
- **AI Lead Priority Score**: {int(win_prob * 100)}% Close Probability | Grant-Eligible: **{lead['has_stem_grant']}**

## 1. Program Highlights (Aligned with Next-Gen STEM & Aviation Standards)
- **Hands-On Pilot + Coder Pairing**: {econ['students']} students paired across **{econ['drone_kits_needed']} programmable safety drone kits** (2:1 student-to-drone ratio so every child flies and codes).
- **Turnkey Certified Instruction**: Includes **{econ['instructors_needed']} background-checked Youth Drone Instructors** plus full indoor/outdoor safety netting and FAA TRUST youth safety curriculum.
- **Real-World Autonomous Robotics Concepts**: Students learn how modern drones perceive obstacles and stabilize flight (inspired by UC Berkeley aerial robotics principles).

## 2. Financial & Pricing Summary Table
| Line Item | Quantity / Allocation | Amount (USD) |
| :--- | :--- | :--- |
| **Student Enrollment Capacity** | {econ['students']} Students ({econ['curriculum_hours']} hrs) | Included |
| **Turnkey Programmable Drone Fleet** | {econ['drone_kits_needed']} Classroom Drone Kits | Included |
| **Certified Flight Instructors** | {econ['instructors_needed']} Instructors (15:1 ratio) | Included |
| **Multi-Site / Volume Partner Discount** | {econ['discount_pct']}% Partner Discount Applied | Applied |
| **Total Turnkey Program Investment** | **All-Inclusive Package** | **${econ['net_contract_value']:,.2f}** |
| *Effective Cost Per Student* | *${econ['net_contract_value'] / econ['students']:,.2f} / student* | *Grant-Ready* |
"""


def main() -> None:
    base_dir = Path(__file__).parent
    csv_path = base_dir / "school_and_camp_leads.csv"
    output_proposal_path = base_dir / "sample_generated_proposal.md"

    with open(csv_path, mode="r", encoding="utf-8") as f:
        leads = list(csv.DictReader(f))

    print("=" * 88)
    print(" YOUTH DRONE TRAINING AI ENGINE — SPREADSHEET TRIAGE & PROPOSAL AUTOMATION")
    print("=" * 88)
    print(f"{'Rank':<5} {'Organization':<34} {'Students':<9} {'Win Prob':<10} {'Quote ($)':<12} {'Gross Margin'}")
    print("-" * 88)

    evaluated_leads: List[Dict[str, Any]] = []
    for row in leads:
        win_prob = score_drone_lead(row)
        econ = calculate_program_economics(
            int(row["estimated_students"]), row["org_type"], row["inquiry_notes"]
        )
        evaluated_leads.append({"row": row, "win_prob": win_prob, "econ": econ})

    # Sort highest priority opportunities first
    evaluated_leads.sort(
        key=lambda x: (x["win_prob"], x["econ"].get("net_contract_value", 0)),
        reverse=True,
    )

    for idx, item in enumerate(evaluated_leads, start=1):
        row = item["row"]
        econ = item["econ"]
        prob_str = f"{int(item['win_prob'] * 100)}%"
        if econ["valid"]:
            quote_str = f"${econ['net_contract_value']:,.2f}"
            margin_str = f"{econ['gross_margin_pct']}% (${econ['estimated_gross_profit']:,.0f} profit)"
        else:
            quote_str = "DISQUALIFIED"
            margin_str = "N/A (Non-buyer)"

        print(f"#{idx:<4} {row['organization_name']:<34} {row['estimated_students']:<9} {prob_str:<10} {quote_str:<12} {margin_str}")

    # Automatically generate a ready-to-send Markdown proposal for the #1 ranked lead
    top_lead = evaluated_leads[0]
    proposal_md = generate_proposal_markdown(
        top_lead["row"], top_lead["econ"], top_lead["win_prob"]
    )
    output_proposal_path.write_text(proposal_md, encoding="utf-8")

    print("-" * 88)
    print(f"Top Opportunity Identified: {top_lead['row']['organization_name']}")
    print(f"Auto-Generated Proposal Saved To: {output_proposal_path}")
    print("=" * 88)


if __name__ == "__main__":
    main()
