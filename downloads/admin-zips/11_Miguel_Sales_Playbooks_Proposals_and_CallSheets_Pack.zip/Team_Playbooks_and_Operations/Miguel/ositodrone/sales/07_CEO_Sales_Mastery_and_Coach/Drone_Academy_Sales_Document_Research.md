# Drone Academy Sales Document Research

Strategic Proposal: The OSITO Drone Academy Experiential STEM Program

Executive Prospectus

In the highly competitive and technologically advanced educational landscape of the San Francisco Bay Area, academic institutions face an ongoing imperative to provide out-of-school time (OST) enrichment that transcends foundational academics. Today’s student requires experiential, deeply engaging curricula that foster critical thinking, technological fluency, and psychological resilience. OSITO Drone Services, an established local leader in commercial aerial cinematography and precision aviation services known for capturing iconic vistas from the San Francisco-Oakland Bay Bridge to the rolling fog of Twin Peaks, introduces a transformative educational paradigm: The OSITO Drone Academy1.

This comprehensive sales prospectus details our proprietary STEM program, which leverages micro-scale First-Person View (FPV) aviation technology to deliver an unparalleled hands-on engineering experience. Utilizing the industry-leading, palm-sized AcroBee65 drone platform, the OSITO Drone Academy shifts the educational focus away from sterile, screen-bound coding exercises and into the dynamic, physics-bound reality of mechanical flight6.

The core of our programmatic offering is the "Build, Fly, Crash, Repair" workflow. This proprietary pedagogical framework intentionally destigmatizes failure, transforming inevitable operational crashes into high-value engineering diagnostics. By partnering with OSITO Drone Services, educational institutions, private academies, and specialized enrichment centers throughout San Francisco can offer a turnkey, profoundly engaging program that directly aligns with Next Generation Science Standards (NGSS) while cultivating the emotional resilience required of future innovators8. The following comprehensive analysis outlines the pedagogical theories, technical specifications, curriculum mapping, market alignment, and strict risk management protocols that define the OSITO Drone Academy.

The Pedagogical Paradigm: Institutionalizing the Mechanics of Failure

A foundational flaw in traditional K-12 education is the systemic stigmatization of failure. Students are heavily conditioned to prioritize correct answers, high standardized test scores, and the minimization of mistakes, which inadvertently breeds risk aversion and a hesitance to tackle complex, ambiguous problems10. However, in the professional realms of science, technology, engineering, and mathematics, failure is not the opposite of success; it is an integrated, indispensable mechanism for achieving it.

Resilience and the Iterative Process

The OSITO Drone Academy’s "Build, Fly, Crash, Repair" workflow is engineered to replicate the authentic, iterative cycles of professional laboratories and engineering firms. As historical precedent demonstrates, Thomas Edison famously characterized his development of the lightbulb not as a series of failures, but as the discovery of ten thousand ways that did not work11. Similarly, the contemporary engineering field is replete with high-profile iterations, such as the highly publicized robotic malfunctions at the DARPA Challenge, where years of programming are tested, broken, and subsequently refined on a public stage11.

When students pilot drones, crashes are an absolute certainty. The OSITO curriculum intercepts the emotional reaction to these crashes. Instead of viewing a downed drone as a finalized failure or a source of devastation, the curriculum frames the event as a data collection opportunity. When students learn that an error is merely a symptom requiring a diagnostic solution, they develop "cognitive resilience"—a robust willingness to persist through setbacks and adapt to new challenges10. This growth mindset encourages students to embrace challenges, ask critical questions, and continue exploring solutions, traits that are heavily correlated with long-term success in STEM disciplines12.

Alignment with the Next Generation Science Standards (NGSS)

The program’s methodology directly supports and operationalizes the Engineering Design components of the Next Generation Science Standards, specifically standards 3-5-ETS1 (for elementary students) and MS-ETS1 (for middle school students)9. These standards require students to define engineering problems, develop multiple viable solutions, and optimize design solutions through rigorous, iterative testing9.

The OSITO workflow transforms these abstract standards into tangible classroom activities. When an AcroBee65 quadcopter suffers a structural failure or software glitch, the student is forced to engage in immediate, applied problem-solving. They must isolate the variable that caused the crash—whether it was an aerodynamic miscalculation, an electrical short, or an aggressive throttle input—and formulate a hypothesis for repair8. This transition from theoretical learning to active, kinesthetic troubleshooting is what elevates the OSITO Drone Academy above traditional after-school coding classes.

The Hardware Ecosystem: Technical Architecture of the AcroBee65

To execute a curriculum where crashing is not just expected but mandated for learning, the hardware platform must be meticulously selected. The OSITO Drone Academy relies exclusively on the AcroBee65 ecosystem, manufactured by NewBeeDrone. This 65mm micro quadcopter—often referred to in the industry as a "Tiny Whoop"—is engineered specifically for indoor agility, modular repairability, and high-fidelity FPV flight6.

The AcroBee65 is not a consumer-grade toy; it is a sophisticated, micro-scale representation of commercial aviation electronics. The table below details the technical architecture of the platform and its corresponding educational applications:

Component Category

Technical Specifications

Educational Application and STEM Utility

Airframe Structure

Cockroach 65mm Brushless/Brushed Frame. Super-durable polymer construction.

Students study material science, impact distribution, and structural integrity. The frame is highly resilient but can break under severe stress, teaching physical replacement procedures6.

Flight Controller (FC)

BeeBrain BLV3 / BLV4 featuring STM32F411 MCU and BMI270 Gyroscope.

Introduces microcontrollers, spatial orientation algorithms, and the integration of processing hardware with kinetic outputs. Students learn how gyroscopes maintain level flight15.

Propulsion System

Unibell Gold 18,000 KV or Flow Double Ball Bearing 27,000 KV Motors.

Explores the physics of thrust, RPMs, electromagnetic fields, and the difference between brushed and brushless motor architectures6.

Video Transmitter (VTX)

SmartMAX VTX with switchable output (5mW, 25mW, 100mW, up to 400mW).

Provides lessons on radio frequency propagation, signal attenuation, heat dissipation (thermal boost), and FCC power regulations13.

Receiver Protocol (RX)

SPI ELRS 2.4GHz or TBS Crossfire Nano Receiver.

Teaches students about low-latency communication, packet rates, binding protocols, and the physical placement of qT or Minimortal T antennas15.

Aerodynamics

Azi Tri-Blade 31mm Propellers.

Students analyze lift, drag, pitch, and how damaged blades cause vibrations that negatively affect gyroscope sensor data6.

Modularity and the Elimination of Repair Bottlenecks

A critical advantage of the AcroBee65 platform is its advanced modularity, which is essential for maintaining momentum in a classroom setting. Previous generations of micro-drones required intricate micro-soldering to replace a burned-out motor or a severed antenna6. While the OSITO curriculum does introduce soldering as an advanced skill for older cohorts, it relies on the plug-and-play architecture of the BeeBrain flight controllers for standard operations16.

The BLV3 and BLV4 boards utilize JST-1.0 3-pin connectors for motors and U.FL/IPEX connectors for antennas15. This means a student who damages a motor during a high-speed collision can diagnose the issue, unclip the broken motor, snap in a replacement, and return to flight within minutes. This rapid prototyping and repair cycle is crucial for maintaining student engagement and preventing the frustration that occurs when technical bottlenecks halt the learning process.

The Curriculum Workflow: Build, Fly, Crash, Repair

The OSITO Drone Academy curriculum is structured as a continuous, cyclical workflow. Students progress through four distinct, interrelated phases, each tied to specific cognitive and technical learning outcomes.

Phase 1: Build (System Integration and Configuration)

The academy does not begin with flight; it begins with systems engineering. Students are introduced to the anatomy of the AcroBee65, tracing the path of electricity from the 1S 300mAh Nitro Nectar Gold LiPo battery, through the flight controller, to the Electronic Speed Controllers (ESCs), and finally to the motors6.

A significant portion of the "Build" phase requires students to interface with the drone digitally using the Betaflight Configurator, an open-source flight dynamics software system. Under instructor supervision, students connect their drones via USB and engage in sophisticated computational tasks:

Sensor Calibration: Students place the drone on a perfectly flat surface to calibrate the onboard accelerometer, ensuring the flight controller has an accurate baseline for gravity21.

Motor Mapping and Configuration: Students verify that software commands correctly correspond to physical motor outputs. They explore the ESC firmware (such as Bluejay 0.18 target S-H-40 48kHz) and ensure motors are spinning in the correct orientation for optimal aerodynamic thrust15.

PID Tuning and Power Management: The AcroBee65 features extremely powerful motors (e.g., 27,000 KV). Students learn that these components represent an excess of kinetic potential for indoor environments. Instructors guide them into the Proportional, Integral, Derivative (PID) tuning tabs to implement software-based throttle caps—restricting the drone to 50% or 80% maximum power15. This teaches students the critical engineering principle of configuring hardware limits via software to ensure operational safety.

Phase 2: Fly (Kinesthetic Application and Spatial Navigation)

Once the drone is configured and verified as airworthy, students transition to the "Fly" phase. Initial instruction begins with basic Line-of-Sight (LOS) hovering, where students master fundamental radio inputs: throttle (altitude), yaw (rotation), pitch (forward/backward), and roll (side-to-side).

Quickly, the curriculum advances to First-Person View (FPV) piloting. Students wear specialized goggles that receive a live, zero-latency 5.8GHz video feed broadcast from the drone’s onboard BeeEye C03 camera6. This shift is profoundly immersive. FPV flying requires immense concentration, radically enhancing spatial awareness, hand-eye coordination, and split-second cognitive processing.

Students navigate custom-designed indoor obstacle courses, utilizing modular balloon racing gates and utilizing classroom architecture6. Because the AcroBee65 operates dynamically in three dimensions, students must continuously calculate vectors, adjusting their pitch and throttle to manage inertia and momentum in real-time.

Phase 3: Crash (Data Collection and Destigmatization)

The "Crash" phase is the pedagogical pivot point of the OSITO curriculum. The AcroBee65’s Cockroach frame is marketed as super-durable, engineered to survive high-velocity impacts with drywall, concrete floors, and metal desks13. However, repeated kinetic stress will inevitably result in hardware failure14.

When a crash occurs, OSITO instructors immediately shift the student's mindset from frustration to diagnostic inquiry. The student is prompted to analyze the telemetry of the failure: Did the drone crash due to pilot error, such as a misjudged turn apex? Did a hardware component fail, such as a bent propeller causing a loss of thrust? Or was there a software issue, such as an aggressive PID tune causing the drone to oscillate out of control? This analytical framing teaches the student that a crash is simply an abrupt physical data point that demands a logical response8.

Phase 4: Repair (Diagnostics and Resolution)

The workflow concludes with the "Repair" phase, requiring the student to utilize their diagnostics to return the drone to an airworthy state. This phase is highly multidisciplinary and builds immense technical self-efficacy:

Mechanical Troubleshooting: Students perform microscopic inspections of the Cockroach frame, looking for stress fractures. They replace warped Azi Tri-Blade propellers and ensure the Goober canopy is securely protecting the internal electronics6.

Electrical and RF Diagnostics: If the drone loses its control link, students learn to troubleshoot the ExpressLRS (ELRS) 2.4GHz or TBS Crossfire protocols. They execute binding procedures, often requiring them to interface with the Betaflight CLI (Command Line Interface) to input binding phrases or manage receiver updates19. If the video feed is weak, they learn to adjust the SmartMAX VTX power, increasing it from 25mW to 100mW to improve signal penetration through walls13.

Software Debugging: Students learn to utilize features like "Turtle Mode," a software protocol that allows a crashed, inverted drone to briefly reverse its motor direction to flip itself upright. This teaches students how code can resolve physical logistical problems without human intervention13.

By executing successful repairs, students earn the immediate reward of returning to the "Fly" phase, generating a powerful cycle of intrinsic motivation and technical confidence8.

Strategic Alignment: The San Francisco Educational Ecosystem

The OSITO Drone Academy is meticulously designed to serve the highly demanding demographic of the San Francisco Bay Area. This region, defined by its proximity to Silicon Valley, possesses a distinct educational culture characterized by intense academic competitiveness, high baseline technological literacy, and parents who actively seek premium, forward-thinking enrichment programs24. Traditional after-school activities are frequently overlooked in favor of programs that offer demonstrable 21st-century skill acquisition26.

Synergy with Elite Independent and Public Institutions

The Bay Area hosts a robust network of highly-rated private and independent schools, such as the San Francisco Day School, Quarry Lane School, Stratford Middle School, and Marin Horizon School24. These institutions universally prioritize holistic, experiential learning, and advanced STEM integration.

The OSITO curriculum aligns perfectly with the institutional priorities of these schools. The San Francisco Day School (SF Day), for example, represents an ideal target integration profile. SF Day maintains a signature Innovation & Technology program, featuring dedicated Innovation and Robotics Labs29. The school prioritizes computational thinking and algorithmic design from an early age and hosts competitive robotics teams like the "Digital Dolphins" for the First Lego League29. Furthermore, SF Day’s pedagogical philosophy explicitly focuses on urging students to "embrace challenge and allow for the productive struggle"31.

The OSITO Drone Academy operates as a highly sophisticated extension of these existing programs. While ground-based, block-coded robotics (such as LEGO Mindstorms) are excellent foundational tools, the AcroBee65 FPV ecosystem represents a massive evolutionary leap. It transitions students from static, 2D programming environments into highly dynamic, high-speed, 3D aviation electronics8.

Institutional Priority

OSITO Drone Academy Solution

Educational Impact

Advanced STEM Engagement

Integration of Betaflight Configurator, PID tuning, and radio frequency management17.

Moves students beyond basic block coding into authentic software/hardware interfacing used in professional engineering.

Resilience and Character Building

The "Build, Fly, Crash, Repair" workflow normalizes failure and demands iteration10.

Directly supports educational goals of building grit, emotional regulation, and cognitive adaptability during challenging tasks.

Inclusivity and Differentiated Learning

Experiential, kinesthetic learning via FPV goggles bypasses traditional text-based learning barriers8.

Engages neurodiverse students and those who struggle with conventional classroom instruction by offering a highly visual, tactile learning medium.

Competitive Positioning in the Enrichment Market

The Bay Area is saturated with summer camps and after-school providers, including Camp Galileo, iD Tech, TechKnowHow, and GrowFit26. While these programs offer coding, AI, and basic robotics, they frequently rely on highly structured, predictable activities with pre-determined outcomes. The OSITO Drone Academy differentiates itself by introducing a chaotic, physics-based variable—flight—which guarantees unpredictable outcomes and forces spontaneous, organic problem-solving. This creates a highly marketable differentiator for partnering schools looking to attract enrollment or justify enrichment fees.

Furthermore, OSITO is deeply committed to educational equity. We actively seek partnerships with organizations like Breakthrough San Francisco, which provides tuition-free, intensive academic support to highly motivated, under-resourced students33. Providing access to elite aviation technology serves as a powerful equalizer, inspiring diverse, historically marginalized student cohorts to pursue advanced degrees and careers in aerospace, engineering, and computer science30.

Operational Modalities for Partner Institutions

To ensure frictionless integration into existing educational infrastructures, the OSITO Drone Academy offers highly flexible operational modalities. We recognize that scheduling and facility availability vary wildly between institutions, and our program is designed to adapt to the specific needs of San Francisco schools and recreation centers.

After-School Enrichment Programs (AEP): OSITO provides turnkey, 6-to-12-week programmatic arcs that integrate seamlessly into existing after-school care structures. For example, schools offering AEP from 3:00 PM to 6:00 PM can host weekly, 90-minute OSITO modules where students transition from classroom learning directly into the drone lab36. We supply all hardware, safety equipment, and lead instructors.

Summer Boot Camps: Intensive, full-day or half-day summer camp programming. These 5-day programs allow for deep immersion, where students spend mornings engaged in the "Build" and "Repair" phases (learning Betaflight and electrical diagnostics) and afternoons engaged in the "Fly" and "Crash" phases (competing in indoor FPV racing leagues)26.

In-School Curriculum Integration: For schools looking to update their science and engineering departments, OSITO offers consultative services and hardware provisioning to integrate the AcroBee65 workflow directly into the standard academic day. This model supports NGSS physical science standards and provides physics teachers with an incredibly engaging tool to demonstrate concepts like inertia, gravity, and electromagnetism8.

Weekend Seminars and Parent-Child Workshops: Recognizing the high level of parental involvement in the Bay Area, OSITO offers Saturday workshops designed for collaborative learning, allowing parents to engage with the FPV technology alongside their children, fostering community and shared technical enthusiasm37.

Risk Management, Institutional Liability, and Aviation Compliance

For school administrators and enrichment coordinators, the primary barrier to adopting a drone-based curriculum is the perceived risk of physical injury, institutional liability, and regulatory complexity. OSITO Drone Services addresses these concerns comprehensively, combining stringent hardware selection with rigorous operational protocols to create an environment that is overwhelmingly safe.

Hardware-Based Risk Mitigation

The OSITO Drone Academy is engineered around the AcroBee65 precisely because it neutralizes the physical risks associated with larger, consumer-grade camera drones.

Negligible Kinetic Energy: The AcroBee65 weighs approximately 21 to 24 grams without its battery, and under 30 grams fully loaded with a Nitro Nectar Gold 1S LiPo6. In the event of a collision with a student, a window, or a piece of classroom equipment, the drone lacks the mass to cause significant damage or injury.

Ducted Propeller Architecture: The defining feature of the "Tiny Whoop" class is its ducted frame. The polymer Cockroach frame completely encircles the spinning Azi Tri-Blade propellers13. It is physically impossible for the blades to cause lacerations to fingers or faces during normal operation, allowing students to safely retrieve crashed drones.

Software-Enforced Safety Limits: Before any drone takes flight, OSITO instructors utilize the Betaflight configurator to institute hard limits on motor output. By implementing a strict throttle cap via the PID tab, the drones are artificially restricted from reaching unsafe velocities in confined classroom spaces, ensuring operations remain highly controlled15.

Federal Aviation Administration (FAA) Compliance

Because the OSITO Drone Academy curriculum is designed primarily for indoor execution—utilizing gymnasiums, cafeterias, and standard classrooms—the flights fall entirely outside the jurisdiction of the Federal Aviation Administration (FAA) controlled airspace regulations. Indoor operations represent the ultimate controlled environment, entirely eliminating variables such as wind, weather, and interference with manned aircraft38.

However, OSITO is deeply committed to teaching proper aviation citizenship. Should a partnering institution request an outdoor curriculum extension, the academy adheres to the strictest FAA guidelines:

The Recreational UAS Safety Test (TRUST): Any student flying outdoors under the exception for limited recreational operations is required to complete the FAA-mandated TRUST certification. This ensures students understand fundamental airspace safety, visual line-of-sight requirements, and altitude limits (operating strictly at or below 400 feet in Class G airspace)38.

Commercial Oversight: All OSITO Lead Instructors possess active FAA Part 107 Remote Pilot Certificates. This commercial licensure ensures the educational program is managed by federally vetted aviation professionals who are deeply trained in airspace authorizations, preflight risk assessments, and liability management38.

Bridging the Gap: Micro Classroom to Macro Industry

While students operate ultra-safe, micro-scale drones in the classroom, OSITO actively bridges the conceptual gap to the broader aerospace industry. By leveraging OSITO Drone Services' professional portfolio—showcasing our commercial aerial videography of San Francisco landmarks, the Golden Gate, and infrastructure projects like the Bay Bridge—instructors provide vital real-world context1. Students realize that the Betaflight software they are configuring and the telemetry data they are analyzing on their 24-gram AcroBee65 are the exact same principles used to operate heavy-lift cinematic drones and advanced commercial UAVs. This connects classroom play directly to highly skilled, lucrative industrial career pathways.

Measurable Outcomes and Program Assessment

To justify educational expenditure and demonstrate clear Return on Investment (ROI) to partnering schools, parent-teacher associations, and grant providers, the OSITO Drone Academy utilizes a robust, multifaceted assessment matrix. We move beyond simple attendance metrics to quantify actual cognitive and technical growth.

Technical Proficiency Audits: Students undergo objective evaluations of their software and hardware competency. Instructors assess a student's ability to independently navigate the Betaflight configurator, execute a successful receiver binding process using ELRS protocols, and accurately diagnose a simulated hardware failure (e.g., identifying a burnt ESC versus a severed motor wire)15.

Piloting Competency and Spatial Metrics: Flight skills are measured quantitatively through timed laps and accuracy ratings on standardized indoor balloon gate courses. These metrics track tangible improvements in spatial navigation, hand-eye coordination, and fine-motor throttle control over the duration of the programmatic arc6.

The Resilience Index: Through structured observational assessments, instructors track the evolution of a student's reaction to the "Crash" phase. The primary indicator of developed cognitive resilience is the speed at which a student transitions from initial frustration to analytical, diagnostic inquiry11.

STEM Engagement Surveys: Pre- and post-program qualitative surveys assess shifts in a student’s self-reported interest in advanced mathematics, physics, and computer science. Historically, immersive robotics programs yield massive increases in long-term STEM engagement, and OSITO closely tracks this efficacy to ensure the program is generating lasting educational impact8.

Concluding Prospectus

The OSITO Drone Academy represents a highly sophisticated, deeply engaging evolution in experiential STEM education. By integrating the advanced micro-technology of the AcroBee65 platform with our proprietary pedagogical approach, we move students beyond the theoretical confines of textbook engineering and plunge them into the tactile, high-stakes, and infinitely rewarding reality of modern aviation technology.

Crucially, the "Build, Fly, Crash, Repair" philosophy directly addresses the primary psychological barrier to scientific innovation: the fear of failure. By normalizing the crash, demystifying complex electronics, and demanding kinesthetic, iterative problem-solving, the academy equips students with both the hard technical skills and the soft emotional resilience required to thrive in the 21st-century workforce.

For independent schools, public institutions, and educational enrichment centers throughout San Francisco, partnering with OSITO Drone Services presents a unique opportunity. It is an opportunity to offer a signature, elite-level technology program that is demonstrably safe, rigorously compliant, and profoundly inspiring. We invite you to partner with us to teach your students not just how to succeed, but how to master the inevitable failures that pave the road to true innovation.

Works cited

CCLEX ENTRANCE/EXIT RAMPS |4K CINEMATIC |AUGUST 12, 2021 #progressupdate, https://www.youtube.com/watch?v=0qWmmE0aA94

The fog trying to push its way down from Twin Peaks - YouTube, https://www.youtube.com/watch?v=X1wDBx4YPno

[4K] Relaxing Bike Ride Crossing The Iconic Golden State Warriors Logo (Oakland Bay Bridge) - YouTube, https://www.youtube.com/watch?v=dqN0irGmSGg

SFO Airspace DJI INSPIRE1 PRO (unedited flight) - YouTube, https://www.youtube.com/watch?v=mkfPdRSpJqc

San Francisco (Trip) The View of San Francisco - YouTube, https://www.youtube.com/watch?v=pclqueidz5s

AcroBee65 BLV3 BNF - The Park Pilot, https://www.theparkpilot.org/acrobee65-blv3-bnf

NewBeeDrone AcroBee65 BeeBrainBL Brushless Micro Drone - BNF - GetFPV, https://www.getfpv.com/newbeedrone-acrobee65-beebrainbl-brushless-micro-drone-bnf.html

The Rise of Robotics in Education - VAPS Group, https://vapstech.com/the-rise-of-robotics-in-education/

3-5-ETS1-1 Engineering Design | Next Generation Science Standards, https://www.nextgenscience.org/pe/3-5-ets1-1-engineering-design

Why Failure Is an Essential Part of Learning and Innovation - STEM blog, https://blog.stem-xpert.com/2026/06/why-failure-is-essential-part-of.html

Failure for Success - STEM at SET - SET High School, https://sethigh.org/failure-for-success-stem-at-set/

Enhancing Problem-Solving Skills with Robotics in STEM Classrooms - ResearchGate, https://www.researchgate.net/publication/385916668_Enhancing_Problem-Solving_Skills_with_Robotics_in_STEM_Classrooms

NewBeeDrone AcroBee65 Brushed V2 TinyWhoop ELRS - FpvFaster, https://www.fpvfaster.com/products/newbeedrone-acrobee65-brushed-v2-tinywhoop-elrs

BlueLooper : r/TinyWhoop - Reddit, https://www.reddit.com/r/TinyWhoop/comments/1ievqkg/bluelooper/

NewBeeDrone AcroBee65 BLV4 BNF Ghost - Dronivo - Your expert for dron, 164,22 €, https://www.dronivo.de/NewBeeDrone-AcroBee65-BLV4-BNF-Ghost_1

NewBeeDrone AcroBee65 Brushed V2 ELRS BNF with SmartMAX VTX - weBLEEDfpv, https://webleedfpv.com/products/newbeedrone-acrobee65-brushed-v2-elrs-bnf-with-smartmax-vtx

NewBeeDrone AcroBee65 BLV4 BNF Ghost - ORQA Shop, https://shop.orqafpv.com/products/newbeedrone-newbeedrone-acrobee65-blv4-bnf-ghost

NewBeeDrone AcroBee65 V4 BNF w/ BeeBrain BLV4 - TBS Crossfire - GetFPV, https://www.getfpv.com/newbeedrone-acrobee65-v4-bnf-w-beebrain-blv4-tbs-crossfire.html

Review: NewBeeDrone AcroBee65 BLV3 - Oscar Liang, https://oscarliang.com/newbeedrone-acrobee65-blv3/

NewBeeDrone AcroBee65 V3 BNF w/ BeeBrain BLV3 - GetFPV, https://www.getfpv.com/newbeedrone-acrobee65-v3-bnf-tiny-whoop-w-beebrain-blv3.html

NewBeeDrone AcroBee65 Brushed BNF, https://newbeedrone.com/a/p/products/newbeedrone-acrobee65-brushed-bnf

Binding issues with newbeedrone acrobee65 BLV4 with radiomaster pocket ELRS - Reddit, https://www.reddit.com/r/fpv/comments/1cxj7tl/binding_issues_with_newbeedrone_acrobee65_blv4/

AcroBee65 BLV4 CRSF Receiver Binding Instruction| A NewBeeDrone Tutorial - YouTube, https://www.youtube.com/watch?v=YsMhgB3OgN0

Private K-8 Schools in the San Francisco Bay Area - Niche, https://www.niche.com/k12/search/private-k8-schools/m/san-francisco-metro-area/

San Francisco - Marin - North Bay Private School & Preschool Guide - Parents Press, https://parentspress.com/san-francisco-marin-north-bay-private-school-preschool-guide/

STEM Camps for East Bay Kids - 510 Families, https://www.510families.com/stem-camps-east-bay/

The Quarry Lane School | Private School in Dublin, CA, https://www.quarrylane.org/

San Francisco Private Middle School | About Stratford School, https://www.stratfordschools.com/schools/northern-california/san-francisco/san-francisco-middle-school/about-us/our-school/

Innovation & Technology - San Francisco Day School, https://www.sfday.org/academics/innovation-technology

SF Day Signature Programs - San Francisco Day School, https://www.sfday.org/academics/sf-day-signature-programs

Lower School - San Francisco Day School, https://www.sfday.org/academics/lower-school

Best Math & Science Programs in the Bay Area, https://www.bayareaparent.com/best-math-science-support-programs-in-the-bay-area/

Breakthrough San Francisco at SF Day School - See 2026 Schedules, Reviews & More | ActivityHero.com, https://www.activityhero.com/biz/52691-breakthrough-san-francisco-at-sf-day-school-san-francisco-ca

Attend a free college preparatory program - Breakthrough San Francisco at San Francisco Day School | One Degree, https://www.1degree.org/opp/attend-a-free-college-preparatory-breakthrough-san-francisco-san-francisco-ca

Girls Get WISE—A programming model for engaging girls+ in STEM - PMC, https://pmc.ncbi.nlm.nih.gov/articles/PMC9807030/

Afterschool & Summer Camp - San Francisco Day School, https://www.sfday.org/school-life/afterschool

San Francisco After-School and Saturday Classes, https://sanfran.kidsoutandabout.com/content/san-francisco-after-school-and-saturday-classes

Drone Certification Guide: Inside the FAA's Part 107 Regulations - UAV Coach, https://uavcoach.com/drone-certification/

The Recreational UAS Safety Test (TRUST) - PCS Edventures, https://edventures.com/blogs/edu-drones-101/the-recreational-uas-safety-test-trust

VEX IQ & VEX V5 STEM Programs - Chattanooga Christian School Robotics, https://www.ccsk12.com/student-life/robotics