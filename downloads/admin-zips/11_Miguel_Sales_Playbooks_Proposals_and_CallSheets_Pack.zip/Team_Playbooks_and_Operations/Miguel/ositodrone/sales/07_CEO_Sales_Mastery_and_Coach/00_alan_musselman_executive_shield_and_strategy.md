# Executive Dossier, Risk Shield & Success Strategy: Alan Musselman & Osito Drone Services

## 1. Profile & Unfair Advantages Discovered
- **Name**: Alan Musselman (San Francisco, CA)
- **Venture**: **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) — 3 Co-Founders
- **Track Record & Credibility Assets**:
  1. **Software & Product Engineering Roots**: Former lead developer on **Adobe Fireworks** and founder of **Tribaloid** (open-source UI prototyping tools, mobile apps/games like *Around the Rock Disc Golf*, DevCamp SF hackathons).
  2. **Bay Area Drone & Maker Authority**: Active pioneer in the **Aerial Sports League** (FPV drone racing), featured exhibitor at **Maker Faire**, and recognized San Francisco aerial videographer.
  3. **Dual-Engine Business Model at Osito Drone Services**:
     - **Engine A (OSITO Drone Academy — Youth & Community STEM)**: Palm-sized micro-FPV drone training for kids via after-school programs, summer camps, and community events.
     - **Engine B (Commercial Drone Services)**: Real estate aerial imaging, promotional video production, site surveying, and security inspection.
  4. **Upcoming Catalyst**: Enrolling in **UC Berkeley Executive Education: *Artificial Intelligence: Business Strategies and Applications*** (starting Nov 12, 2026).

---

## 2. The "Protect Alan" Shield: 5 High-Stakes Risks & How We Guard Against Them

### Shield 1: 3-Co-Founder Alignment, Equity & Role Protection
- **The Risk**: In a 3-co-founder service + education business, resentment builds fast if one founder closes deals, builds curriculum/AI systems, and flies missions while roles, IP ownership, or revenue splits are informal.
- **The Protection**:
  - Separate **Delivery Labor Compensation** (paying the specific co-founder who teaches a 16-hour camp or flies a commercial shoot at `$60–$100/hr`) from **Company Net Profit Distribution** (split `1/3` each). Never mix sweat labor with equity distributions!
  - Document clear territory ownership and a Co-Founder Operating Agreement (including vesting and IP assignment for any AI software/curriculum you build during your UC Berkeley program).

### Shield 2: FAA, Youth Safety & California School Compliance (Zero-Liability Shield)
- **The Risk**: Operating drones around children and commercial sites in densely populated San Francisco carries strict regulatory and liability exposure.
- **The Protection**:
  - **Youth Indoor/Outdoor Firewall**: Keep all student hands-on flying strictly to **sub-250g (ideally sub-100g palm-sized whoop/micro-FPV) 360° prop-guarded drones** inside netted zones or indoor gyms—exempt from FAA Part 107 registration requirements and zero laceration hazard.
  - **Commercial Operations**: Ensure all commercial shoots (real estate, surveying) have logged **FAA Part 107** remote pilot credentials, LAANC airspace authorization (crucial near SFO/OAK/Crissy Field), and a separate Commercial Aviation General Liability policy (`$2M–$5M` COI naming SF school districts/camps as Additional Insured).
  - **California Youth Compliance**: Ensure all instructors complete **California DOJ/FBI Live Scan fingerprinting**, TB clearance, and Mandated Reporter training required by SFUSD, SF DCYF, and California ELO-P subcontractors.

### Shield 3: Brand & Search Engine Collision ("Osito" SF Restaurant vs. Osito Drone Services)
- **The Risk**: In San Francisco, searching *"Osito San Francisco"* heavily surfaces **Osito** (the Michelin-starred restaurant in the Mission District).
- **The Protection**:
  - Standardize all B2B/B2G digital assets, proposals, and LinkedIn titles around **"Osito Drone Services"** and **"OSITO Drone Academy"** (plus domain `ositodrone.com`) with structured local SEO keywords (*"San Francisco Youth Drone STEM Program"*, *"SF Bay Area Commercial Drone & FPV Academy"*).

### Shield 4: Time & Margin Protection (Escaping the "Custom Gig Trap")
- **The Risk**: Doing one-off low-ticket birthday parties, ad-hoc real estate shoots, or custom school demos without standardized packages burns out founders.
- **The Protection**:
  - Enforce a **Minimum Engagement Floor** (`$1,800+` for 1-day school/camp events; `$10,000–$25,000+` for 8-week ELO-P/DCYF cohorts) so every hour you invest compounds into repeatable B2B/B2G recurring contracts.

### Shield 5: AI Data Privacy & IP Protection
- **The Risk**: Pasting student names/photos or proprietary client site survey data into public AI tools.
- **The Protection**:
  - Never allow student PII or unconsented youth photos into external AI prompts. Keep all pricing math inside deterministic local Python scripts ([`run_osito_sf_pipeline.py`](./run_osito_sf_pipeline.py)).
