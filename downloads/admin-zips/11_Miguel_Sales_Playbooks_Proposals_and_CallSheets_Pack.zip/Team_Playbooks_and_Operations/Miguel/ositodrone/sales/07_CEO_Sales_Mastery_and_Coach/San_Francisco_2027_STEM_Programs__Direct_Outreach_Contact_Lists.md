# San Francisco 2027 STEM Programs_ Direct Outreach Contact Lists

Strategic Outreach and Partnership Acquisition for STEM Drone Education in the San Francisco Educational Ecosystem

The integration of advanced robotics, aeronautics, and coding into K-12 education represents a critical evolution in modern Science, Technology, Engineering, and Mathematics (STEM) programming. As educational institutions in the San Francisco Bay Area transition from foundational computer science toward applied, experiential learning, unmanned aerial vehicles (drones) offer a highly engaging platform for students to master physics, spatial reasoning, and algorithmic thinking. Preparing for a 2027 programmatic launch for Ostio drone services requires a highly targeted, multi-tiered business-to-education (B2E) outreach strategy. This analysis details the institutional landscape of the San Francisco market, providing exhaustive contact intelligence, procurement insights, and strategic alignment frameworks for penetrating public school districts, community-based organizations (CBOs), independent schools, commercial summer camps, and regional STEM exhibitions.

The educational procurement ecosystem in San Francisco is highly decentralized. While the San Francisco Unified School District (SFUSD) sets pedagogical standards, the actual execution and funding of out-of-school-time (OST) programming is largely delegated to a network of entrenched nonprofit partners and third-party vendors. Successfully securing exhibit booths, live demonstrations, and sustained training contracts requires navigating these overlapping spheres of influence, understanding municipal funding via the Department of Children, Youth and Their Families (DCYF), and building grassroots support among site-level educators.

San Francisco Unified School District (SFUSD) Central Administration

SFUSD represents the largest single market for STEM enrichment in the region. However, selling directly to individual schools requires an understanding of the district’s complex funding and approval mechanisms. SFUSD utilizes the Expanded Learning Opportunities Program (ELO-P) and the ExCEL (After School Education and Safety) funding streams to finance its before- and after-school programs1. On March 10, 2026, the Board of Education updated the ELO-P plan, stipulating that principals must select their expanded learning partners annually from a list of SFUSD ExCEL Qualified Lead Agencies2.

District-Level Science and Expanded Learning Leadership

Before pitching individual school sites, overarching approval and curriculum alignment must be established at the district level. SFUSD’s Science Department is responsible for aligning all external STEM curricula with the Next Generation Science Standards (NGSS)3. A drone training program must demonstrate how it supports NGSS objectives, such as teaching forces and interactions, engineering design, and energy transfer. Furthermore, the College and Career Readiness (CCR) department embeds site coordinators in schools to guide technical education pathways4.

Simultaneously, the ExCEL Expanded Learning Programs office oversees the compliance, safety, and funding of all after-school activities. Drone operators must adhere strictly to ExCEL Incident Protocols, ensuring that comprehensive liability, safety, and risk management frameworks are communicated during the initial outreach. For instance, any incident requires reporting via the ExCEL Incident Report Form within 48 hours5.

Contact Name

Title / Department

Email Address

Phone Number

Dr. Renée Marcy

SFUSD Director for STEM

MarcyR@sfusd.edu

628-900-4724

Eric Lewis

Middle School Science Content Specialist

lewise2@sfusd.edu

628-900-4724

Priscilla Perez

Middle & K-12 Science Content Specialist

perezp2@sfusd.edu

628-900-4724

Anastasia Pickens

Elementary School Content Specialist

pickensa@sfusd.edu

628-900-4724

Dawn Rege

High School Content Specialist (Biology)

reged@sfusd.edu

628-900-4724

David Barrios

High School Content Specialist (Physics)

barriosd@sfusd.edu

628-900-4724

Elaine Yu

STEM Administrative Assistant

yue@sfusd.edu

628-900-4724

N/A

ExCEL Expanded Learning Office

excelasp@sfusd.edu

415-340-1716

N/A

SFUSD Risk Management

riskmanagement@sfusd.edu

415-241-6307

N/A

SFUSD Student Family School Resource Link

sflink@sfusd.edu

415-340-1716

N/A

SFUSD Board of Education Office

boardoffice@sfusd.edu

415-241-6427

The district also operates specialized support units that vendors must occasionally coordinate with, such as Transportation Services for off-site events and the Special Education Services department for ensuring curriculum accessibility. Transportation can be reached at transportation@sfusd.edu (415-695-5505), and Special Education inquiries should be directed to the site's respective case managers6.

Site-Level Acquisition: Middle and K-8 Schools

Middle schools (grades 6-8) represent the optimal demographic for drone training programs. Students in this cohort possess the necessary fine motor skills for flight control and the cognitive maturity for block-based or Python coding. In SFUSD, principals retain significant autonomy in selecting their Expanded Learning partners from the district's approved list2. Outreach to these administrators should focus on offering limited-run pilot programs or on-campus demonstrations to build internal champions.

The strategy for site-level outreach should heavily emphasize programmatic benefits: increasing after-school retention rates, providing hands-on NGSS application, and offering unique career and technical education (CTE) pathways. However, principals are heavily shielded by administrative layers. Consequently, a multi-pronged approach that simultaneously targets Assistant Principals, Science Department Chairs, and Family Liaisons is required to penetrate the site successfully.

Presidio Middle School

Presidio Middle School utilizes the Richmond Neighborhood Center for its Beacon programming8. Reaching out to the science faculty with a targeted proposal demonstrating how drone kinematics align with their 6th, 7th, and 8th-grade syllabi is a highly effective entry vector. Furthermore, the PTSA at Presidio acts as a supplementary funding mechanism and should be engaged regarding their "Support the Presidio Annual Fund"9.

Contact Name

Title / Role

Email Address

Phone Number

Kevin Chui

Principal

chuik@sfusd.edu

415-750-8435

Maria Lourdes Nocedal-Geaga

Assistant Principal

nocedalm@sfusd.edu

415-750-8435

Ambar Panjabi

Assistant Principal

panjabia@sfusd.edu

415-750-8435

Jackie Warner

Science Teacher (8th Grade)

warnerj1@sfusd.edu

415-750-8435

Dr. Jennifer Ogden

Science Teacher (8th Grade)

erskine-ogdenj@sfusd.edu

415-750-8435

Jonathan Lee

Science Teacher (7th Grade)

leej14@sfusd.edu

415-750-8435

Victor Marano

Science Teacher (7th Grade)

maranov1@sfusd.edu

415-750-8435

Jill Trinh

Science Teacher (6th Grade)

trinhj@sfusd.edu

415-750-8435

Brendon Wong

Science Teacher (6th Grade)

wongb@sfusd.edu

415-750-8435

Janet Yieh

Family Partnerships Coordinator (PTSA)

janet@richmondsf.org

415-534-9420

Jeanetta Mitchell

Family Partnerships Coordinator

ms.mitchell@richmondsf.org

415-750-5240

Jennifer Clare

PTSA Fundraising Chair

fundraising@presidioptsa.com

N/A

Roosevelt Middle School

Roosevelt operates a robust science program and actively participates in the SFUSD Science Fair10. Outreach here should emphasize how a drone curriculum can generate competitive science fair projects, elevating the school's regional prestige.

Contact Name

Title / Role

Email Address

Phone Number

Emily Leicham

Principal

leichame@sfusd.edu

415-750-8446

Karla Alvord

Assistant Principal

alvordk@sfusd.edu

415-750-8446

Alanna Merchant

Science Dept (Gr. 6 & 7)

merchanta@sfusd.edu

415-750-8446

Elizabeth Whiteside

Science Dept (Gr. 6 & 8)

whitesidee@sfusd.edu

415-750-8446

Emilie Hayward-Allen

Science Dept (Gr. 7 & 8)

hayward-allene@sfusd.edu

415-750-8446

Kyle Chi

Science Dept (Gr. 6 & 8)

chik@sfusd.edu

415-750-8446

Heidi Galleni

Science Dept (Gr. 7)

gallenih@sfusd.edu

415-750-8446

A.P. Giannini Middle School

A.P. Giannini partners with Bay Area Community Resources (BACR) for its Beacon program11. Their after-school program runs Monday, Tuesday, Thursday, and Friday from 4:00 PM to 7:00 PM, and Wednesdays from 2:15 PM to 6:00 PM11. Providing Ostio drone services during these specific operational hours is critical for seamless integration.

Contact Name

Title / Role

Email Address

Phone Number

Tai-Sun Schoeman

Principal

schoemant@sfusd.edu

415-759-2770

Heidi Smoot

Assistant Principal

smooth@sfusd.edu

415-759-2770

Lizzy Hull Barnes

Assistant Principal

hullbarnese@sfusd.edu

415-759-2770

Allison Bamaca

Beacon Director (BACR)

abamaca@bacr.org

415-741-4310

Herbert Hoover Middle School

Herbert Hoover Middle School integrates heavily with BACR for its expanded learning and utilizes dedicated Family Liaisons to engage its bilingual communities12. A drone program pitch here should ideally include bilingual curriculum materials or highlight inclusive instructional strategies.

Contact Name

Title / Role

Email Address

Phone Number

Adrienne Sullivan Smith

Principal

smitha@sfusd.edu

415-759-2783

Julia Coffa

Assistant Principal

coffaj@sfusd.edu

415-759-2783

Michael Colvin

Assistant Principal

colvinm1@sfusd.edu

415-759-2783

Jeremy Lee

Beacon Director (BACR)

jlee@bacr.org

415-759-2783

Andrea Serpa

Beacon Site Coordinator (BACR)

aserpa@bacr.org

415-759-2783

Sara Hernandez-Tax

Spanish Bilingual Family Liaison

hernandez-taxs@sfusd.edu

415-759-2783

Kent Lau

Chinese Bilingual Family Liaison

klau@bacr.org

415-759-2783

N/A

Hoover Hawk Families (PTA)

HooverHawkFamilies@gmail.com

415-759-2783

James Lick Middle School

Located in the Mission District, James Lick partners with the Jamestown Community Center to execute its Beacon program13. They also feature a robust Spanish Secondary Dual Language Program15. Demonstrating an understanding of culturally responsive pedagogy and presenting Ostio drone operations as a pathway to high-paying STEM careers will resonate strongly with this administration.

Contact Name

Title / Role

Email Address

Phone Number

Norma Hernandez

Principal

hernandezn1@sfusd.edu

415-695-5675

Perla Rivas

Assistant Principal

rivasp@sfusd.edu

415-695-5675

Nathalie "Natty" Linares

Beacon Director (Jamestown)

nathaliel@jamestownsf.org

415-647-4709

Francisco Serrano

Program Manager (Jamestown)

franciscos@jamestownsf.org

415-647-4709

Alba Akrabawi

Math/Science (6th Grade)

akrabawia@sfusd.edu

415-695-5675

Mwana El-Kindiy

Math/Science (6th Grade)

el-kindiym1@sfusd.edu

415-695-5675

José Sandoval

Math/Science (6th Grade)

sandovalj3@sfusd.edu

415-695-5675

Chandandeep Kaur

Math/Science (7th Grade)

kaurc@sfusd.edu

415-695-5675

Mumum Nina Barker

Science (7th Grade)

barkerm@sfusd.edu

415-695-5675

Kailei Gallup

Science (8th Grade)

gallupk@sfusd.edu

415-695-5675

N/A

PTSA Contact

jameslickptsa@yahoo.com

N/A

Additional High-Value SFUSD Public School Targets

Other middle schools and specialized high schools present excellent opportunities for Ostio drone services, particularly those integrating Career and Technical Education (CTE).

School Name

Contact Name

Title / Role

Email Address

Phone Number

Marina Middle School

Michael Harris

Principal

harrism4@sfusd.edu

415-749-3495

Everett Middle School

Crisoforo Garza

Principal

garzac@sfusd.edu

415-241-6344

Everett Middle School

Heidi Avelina Smith

Principal

smithh@sfusd.edu

415-241-6344

Francisco Middle School

Hossein Koch

Principal

kochh@sfusd.edu

415-291-7900

Willie L. Brown Jr. Middle

Denise Ting

Science Teacher (6th Grade)

tingd@sfusd.edu

N/A

Willie L. Brown Jr. Middle

Rachel Kow

Robotics Teacher

kowr@sfusd.edu

N/A

Galileo Academy

David Barrios

NGSS Physics/Chemistry

BarriosD@sfusd.edu

N/A

Galileo Academy

Shannan Wong

AP Physics 1

WongS3@sfusd.edu

N/A

Raoul Wallenberg High

Laura Dale

Science Dept Lead

dalel@sfusd.edu

415-749-3469

John O'Connell High

Andrew Lemke

RSP Science - Math

lemkea@sfusd.edu

N/A

Pace/Burton High

Karla Ruiz

Community School Director

kruiz@ymcasf.net

N/A

Community-Based Organizations (CBOs) and Municipal Funding

In San Francisco, the execution of public OST programming is inextricably linked to highly established Community-Based Organizations through the Beacon Center model. These organizations are funded by both the school district and the San Francisco Department of Children, Youth and Their Families (DCYF)16. DCYF provides over $31 million annually for comprehensive year-round and summer learning16.

Because CBOs act as the prime contractors for SFUSD's after-school spaces, they frequently subcontract specialized enrichment providers to fulfill their grant requirements for STEAM engagement18. Securing a contract with a single CBO can instantly unlock access to dozens of school sites. Vendors must also monitor municipal procurement portals, such as the SF City Partner Portal and DCYF's Cityspan contract management system, to bid on direct city funding for 2027 programmatic cycles19.

The Richmond Neighborhood Center (TRNC)

TRNC is a dominant force in the Richmond District, operating extensive elementary and middle school programs at sites like Alamo, Argonne, Lafayette, McCoppin, Peabody, Presidio, and Roosevelt21. They utilize a robust vendor ecosystem, previously partnering with groups like Engineering for Kids and Tree Frog Treks22. Their infrastructure is highly formalized, mandating that enrichment providers coordinate directly with site-specific Program Managers.

Contact Name

Title / Role

Email Address

Phone Number

Michelle Cusano

Executive Director

michelle@richmondsf.org

415-941-7768

Alice Tam

Elementary School Program Director

alice@richmondsf.org

415-598-8802

Bishoy Abdelshaid

High School Programs Director

bishoy@richmondsf.org

N/A

Angie Thai

Program Manager, Lafayette

angie@richmondsf.org

415-867-1113

Kady Maniscalo

Program Manager, George Peabody

kady@richmondsf.org

415-867-7720

Raquel Lopez Monroy

Program Manager, McCoppin

raquel@richmondsf.org

415-941-7772

Chelsea Banh

Program Manager, Alamo

chelsea@richmondsf.org

415-867-7723

Craig Lai

Assistant Program Manager, Presidio

craig@richmondsf.org

415-770-5851

Bessie Natareno

Beacon Director, Roosevelt

bessie@richmondsf.org

415-770-5883

Sharon Lu

Registration Services Coordinator

sharon@richmondsf.org

415-941-7767

N/A

General Registration / Info

registration@richmondsf.org

415-751-6600

Vendor Outreach

General ASE Vendor Contact

asedirector@gppta.org

N/A

Boys & Girls Clubs of San Francisco (BGCSF)

Operating eight traditional clubhouses and six school-based clubs, BGCSF serves thousands of youth across the city23. The organization emphasizes leadership, academic success, and specialized programs like Camp Mendocino, a 2,000-acre residential summer camp23. Given their massive scale, BGCSF requires a top-down sales approach. Establishing a pilot program at a flagship location (such as the Don Fisher Clubhouse) or integrating drone programming into Camp Mendocino's 2027 summer roster can lead to a citywide rollout.

Contact Name

Title / Role

Email Address

Phone Number

Rob Connolly

President

rconnolly@kidsclub.org

415-445-5401

Harold Love

Senior VP of Club Services

hlove@kidsclub.org

415-445-5488

Carlton Eichelberger

VP of Club Services (School Based)

ceichelberger@kidsclub.org

510-917-5217

Brian Sauer

Citywide Director of Education

bsauer@kidsclub.org

415-445-5414

Jake Babick

Citywide Dir. of Sports, Fitness & Play

jbabick@kidsclub.org

415-933-1616

Earl Declet

Citywide Dir. of Youth Leadership

edeclet@kidsclub.org

N/A

Sara Richardson

Executive Director, Camp Mendocino

srichardson@kidsclub.org

415-445-5476

Anthony Alves

Dir. of Leadership Programs (Camp Mendocino)

aalves@kidsclub.org

N/A

Imani Payton

Dir. of Staff Experience (Camp Mendocino)

ipayton@kidsclub.org

N/A

Mia Amor Vega

Site Director, SF Community School Club

N/A

N/A

Dianna Baker

Site Director, Gateway Middle School Club

N/A

N/A

YMCA of Greater San Francisco

The YMCA is one of the largest providers of before- and after-school care in the Bay Area, operating ExCEL programs across numerous campuses including Commodore Sloat, Sheridan, Jose Ortega, and Dianne Feinstein Elementary24. The YMCA's programming focuses heavily on safe spaces and experiential learning. Drone programs pitched to the YMCA should highlight team-building, peer collaboration, and accessible entry points for students with no prior coding experience.

Contact Name

Title / Role

Email Address

Phone Number

General Membership

Central Point of Contact

memberservices@ymcasf.org

N/A

Kristina Hu

Site Coordinator

khu@ymcasf.org

415-576-9622

Alexandra Zussman

Jefferson OST Program

azussman@ymcasf.org

N/A

Stefanie Torres

Site Coordinator, Commodore Sloat

storres@ymcasf.org

415-850-2228

Lupita Troncoso

Youth Program Director, Sheridan

ltroncoso@ymcasf.org

N/A

Vanessa Gomez

Site Coordinator, Jose Ortega

VGomez@ymcasf.org

415-283-6999

Presidio Branch

Member Services

PresidioMembership@ymcasf.org

415-447-9622

Jamestown Community Center

Serving the Mission District, Jamestown provides critical support for predominantly Latino and low-income youth. Their Beacon programs at Buena Vista Horace Mann (BVHM), Cesar Chavez, and James Lick Middle School are central hubs for community enrichment13. Outreach to Jamestown should strongly emphasize bilingual (Spanish/English) curriculum capabilities, equity in STEM access, and workforce development pathways27.

Contact Name

Title / Role

Email Address

Phone Number

Nelly Sapinski

Executive Director

NellyS@JamestownSF.Org

415-647-4709

Jessica Linares

Deputy Director of Programs

Jessica@JamestownSF.Org

415-647-4709

Diana Diaz

Beacon Director, Cesar Chavez

DianaD@JamestownSF.Org

415-647-4709

Nathalie "Natty" Linares

Beacon Director, James Lick

nathaliel@jamestownsf.org

415-647-4709

Francisco Serrano

Program Manager, James Lick

franciscos@jamestownsf.org

415-647-4709

Dayanara Weisenburger

Expanded Learning Prog. Manager, BVHM

DayanaraA@JamestownSF.Org

415-647-4709

Gibran Gonzalez

Youth Workforce Manager

GibranG@JamestownSF.Org

415-647-4709

N/A

General Info

info@Jamestownsf.org

415-647-4709

Telegraph Hill Neighborhood Center (TEL HI)

TEL HI operates Beacon and ExCEL programs in the North Beach and Chinatown areas, servicing schools like Francisco Middle, Galileo High, Garfield, and Sherman Elementary28. TEL HI has a distinct focus on technology and science—evidenced by programs like the "Futurama" after-school initiative at Galileo Academy of Science & Technology28. Drone operations fit seamlessly into their existing programmatic narrative.

Contact Name

Title / Role

Email Address

Phone Number

Nestor L. Fernandez II

CEO / Executive Director

NFernandez@telhi.org

415-672-5252

Josh Feierstein

Chief Program Officer

JFeierstein@telhi.org

415-580-7230

Jimmy Le

Beacon Director, Francisco Middle

JLe@telhi.org

415-535-5597

Darcia Ale

Futurama Program Manager

DAle@telhi.org

323-430-3238

Michael Lee

Program Manager, Elementary Academy

MLee@telhi.org

415-580-7228

Ashley Latoof

Marketing & Communications Director

ALatoof@telhi.org

415-580-7222

Mission Graduates & Bay Area Community Resources (BACR)

Mission Graduates focuses heavily on college access and academic success within the Mission District, operating extended day programs at schools like Sanchez, Alvarado, and Everett Middle School30. BACR is a massive regional agency that manages ExCEL programs and mental health services across numerous campuses, notably at Herbert Hoover Middle School and Paul Revere PreK-834. Both organizations prioritize academic rigor and future career readiness, making them highly receptive to advanced STEM proposals.

Organization

Contact Name

Title / Role

Email Address

Phone Number

Mission Graduates

Natalie Guandique

Chief Program Officer

natalie@missiongraduates.org

415-864-5205

Mission Graduates

Dianna Caracoza

Senior Director, Extended Day

dianna@missiongraduates.org

415-864-5205

Mission Graduates

Yanira Perez

Program Director, Alvarado

yperez@missiongraduates.org

415-864-5205

Mission Graduates

Jason Boggs

Assistant Program Director, Everett

jboggs@missiongraduates.org

415-907-2942

Mission Graduates

General Info

General Inquiries

info@missiongraduates.org

415-864-5205

BACR

Kim Smith

After School Enrollment (Revere)

kim.smith@bacr.org

415-650-7462

BACR

Jeremy Lee

Beacon Director (Hoover)

jlee@bacr.org

415-650-7462

BACR

Allison Bamaca

Beacon Director (AP Giannini)

abamaca@bacr.org

415-650-7462

Additional Specialized Support Agencies

Navigating the child care funding ecosystem involves agencies like the Children's Council of San Francisco and Wu Yee Children's Services37. While they primarily focus on early childhood and subsidies, they function as vital resource hubs for families navigating out-of-school-time options and frequently host tabling events and community presentations39. Aligning Ostio services with their resource networks enhances visibility among low-income families utilizing city subsidies.

Organization

Contact Name / Dept

Email Address

Phone Number

Children's Council

Resource & Referral

rr@childrenscouncil.org

415-343-3300

Children's Council

Business Incubator Team

chouse@childrenscouncil.org

415-276-2900

Wu Yee Children's Services

Child Care Referrals

randr@wuyee.org

844-644-4300

Hunters Point Family

Administration

admin@hunterspointfamily.org

415-822-8895

Independent and Private School Networks

While public school procurement involves multiple stakeholders and strict district compliance, independent and private schools in San Francisco operate with significantly greater agility. These institutions possess dedicated budgets for premium after-school enrichment and can often bypass lengthy vendor qualification processes.

The strategy for engaging private schools differs fundamentally from public CBO outreach. Private schools are driven by parental demand for elite, cutting-edge extracurriculars that justify high tuition costs. An advanced drone engineering and piloting course serves as a highly marketable asset for these schools. Outreach should highlight the exclusivity of the curriculum, the use of professional-grade drone hardware, and the integration of advanced concepts such as aerial cinematography and autonomous flight programming.

San Francisco Day School, Friends School, Hamlin, and Town School for Boys

Engaging these elite institutions requires targeting their specific Directors of Afterschool Programs or Academic Program Directors. For instance, San Francisco Day School runs specialized enrichment modules where a vendor like Ostio could operate on a contracted fee-per-student basis40. The Hamlin School, an all-girls institution, presents an excellent opportunity to frame drone operations around empowering young women in STEM fields41.

School Name

Contact Name

Title / Role

Email Address

Phone Number

San Francisco Day School

Nicole Lane

Director of Afterschool Programs

nlane@sfday.org

415-568-3650

San Francisco Day School

Amber Baker

Director of Events (for demos)

abaker@sfday.org

415-568-3633

San Francisco Day School

Racheal Adriko

Head of School

radriko@sfday.org

415-931-2422

San Francisco Friends School

Ariel Mendez-Peñate

Academic Program Director

amendez-penate@sffriendsschool.org

415-565-0400

San Francisco Friends School

José Zamora

Director of Admission

jzamora@sffriendsschool.org

415-565-0400

San Francisco Friends School

Veronique Kessler

Administrator / Records

vkessler@sffriendsschool.org

415-565-0400

Town School for Boys

Erica Hernandez

BADA Coordinator

bayareabada@gmail.com

N/A

The Hamlin School

Olivia Jacob

Extended Day Leader

info@hamlin.org

415-922-0300

The Hamlin School

Lauren Thornhill

Exec. Dir. Institutional Advancement

thornhill@hamlin.org

415-922-0300

The Hamlin School

Emily Wong

Lower School Literacy Specialist

info@hamlin.org

415-922-0300

Commercial Summer Camps and STEM Enrichment Providers

The summer camp market in the Bay Area is highly lucrative and inherently modular. Large-scale camp operators continually seek novel, specialized curriculum modules to refresh their annual offerings and maintain high re-enrollment rates. Unlike CBOs, which run year-round, these organizations experience a massive surge in operational intensity between June and August.

Partnering with established commercial camps—rather than competing directly against them for student enrollment—is the most efficient scaling strategy for 2027. By acting as a specialized "push-in" vendor or curriculum licensor, Ostio drone services can access thousands of pre-enrolled students without bearing the cost of direct-to-consumer marketing, facility rentals, or baseline childcare compliance.

Steve & Kate's Camp

Steve & Kate's Camp operates on a radically different model of self-directed learning, where children choose their activities in real-time without rigid scheduling42. They operate across multiple Bay Area locations, including Mission Dolores, Sunset, Emeryville, and Belmont43. A drone flight simulator or a modular, rapid-deployment drone building station would align perfectly with their "Makers Crafts" and "Tech" hubs, allowing kids to drop in and learn at their own pace.

Branch Location

Contact Name

Email Address

Phone Number

SF - Mission Dolores

Preshia

sf.missiondolores@steveandkate.com

628-204-4119

SF - Sunset

Jess Baer

sf.sunset@steveandkate.com

415-604-0081

Emeryville

Branch Director

emeryville@steveandkate.com

650-264-7831

Palo Alto

Branch Director

paloalto@steveandkate.com

650-265-4152

San Mateo

Branch Director

sanmateo@steveandkate.com

650-539-0310

Walnut Creek

Branch Director

walnutcreek@steveandkate.com

925-215-4657

TechKnowHow

TechKnowHow specializes directly in technology enrichment, specifically LEGO engineering, Minecraft, and robotics45. Their highly technical focus makes them an ideal candidate for a drone partnership, as their student base is already primed for advanced robotics, spatial geometry, and coding concepts47. They offer specialized tracks like the "Girls Tech Academy," providing an avenue for Ostio to pitch gender-inclusive drone programming47.

Contact Name / Department

Email Address

Phone Number

Purpose

S. Robertson

s.robertson@TechKnowHowKids.com

650-638-0500

Director / Curriculum

Camp Info Desk

campinfo@TechKnowHowKids.com

650-638-0500

General Operations

EDMO, Camp Galileo, and Camp Captivate

EDMO operates camps focused on science, technology, and social-emotional learning across the Bay Area (including Richmond, Noe Valley, Sunset, and Marina locations)48. Their pedagogical model, the "EDMO Method," emphasizes empathy and problem-solving alongside technical skills50. Proposals to EDMO should highlight how drone operations teach students resilience (troubleshooting crashes), collaboration (pilot and spotter roles), and responsible technology use.

Camp Galileo operates highly structured innovation camps that blend art, science, and outdoor activities, featuring programs like "Galileo X" specifically designed for older children who possess the manual dexterity for complex drone flight51. Camp Captivate, operating out of Santa Clara, offers high-tier STEAM education and specializes in both summer camps and birthday parties53.

Organization

Contact Name / Department

Email Address

Phone Number

EDMO

Partnership Inquiries

yourfriends@edmo.org

415-282-6673

EDMO

Info Desk

info@edmo.org

415-282-6673

Camp Galileo

General Information

info@galileo-learning.com

628-286-3725

Camp Galileo

Scholarship Team

scholarships@galileo-learning.com

N/A

Camp Captivate

Ildiko Stennis (Director)

ildiko@sciencesmartkids.com

408-785-0121

STEM Fairs, Festivals, and Exhibition Opportunities (2026-2027)

To generate institutional leads, build public awareness, and demonstrate the safety and engagement level of the Ostio drone curriculum, active participation in the Bay Area’s robust circuit of STEM fairs is mandatory. These events concentrate the target demographic—educators, district administrators, STEM coordinators, and motivated parents—into singular, high-traffic venues. Securing exhibit booths and live demonstration spaces at these events in late 2026 and early 2027 will serve as the primary marketing catalyst for securing summer and fall 2027 contracts.

Maker Faire Bay Area & Open Sauce

Billed as "The Greatest Show & Tell on Earth," Maker Faire attracts inventors, startups, and educators55. For a commercial entity, the standard commercial maker fee is $500, but qualifying startups can access a $1,500 sponsorship package that offers significantly higher visibility and direct B2B networking57. The application window for priority review typically closes in mid-July57.

Similarly, Open Sauce (founded by YouTuber William Osman) has rapidly become one of the premier technology conventions in the country, drawing over 20,000 attendees to the San Mateo County Event Center58. The event bridges the gap between digital content creation and physical engineering58. Open Sauce features an "Industry Day" and a hardware hackathon ("Sauceathon")58. Sponsoring a drone-programming challenge during the hackathon would provide unparalleled networking opportunities and generate authentic, user-created marketing content. The next Open Sauce event is slated for July 17-18, 202759.

Event

Contact Department

Email Address

Key Dates

Maker Faire Bay Area

Partnerships Team

partnerships@make.co

Priority App: July 15

Maker Faire Bay Area

General Applications

makerfaire@make.co

Event: Sept 25-27

Open Sauce Festival

General Information

via website

Event: July 17-18, 2027

Regional Science Festivals and District Fairs

Beyond the massive commercial conventions, regional science festivals offer direct access to local school district decision-makers. The Bay Area Science Festival (frequently hosted in conjunction with UCSF) and the North Bay Science Discovery Day are cornerstone community events60. The North Bay Science Discovery Day is scheduled for May 2, 2027, providing an excellent lead-generation opportunity directly ahead of the summer camp season61.

Furthermore, SFUSD hosts its own internal science fairs, such as the Winter Literacy, Math, and Science Fair at César Chávez Elementary62. Exhibiting at district-sponsored events proves to administrators that a vendor is committed to community enrichment, easing the friction of future contract negotiations.

Event / Organization

Contact Name

Email Address

Phone Number

Bay Area Science Festival

Katherine Nielsen (Co-Founder)

katherine.nielsen@ucsf.edu

N/A

Bay Area Science Festival

Rachel Harris (Coordinator)

Rachel.Harris@ucsf.edu

N/A

Bay Area Science Festival

Sabine Jeske (Coordinator)

sabine.jeske@ucsf.edu

N/A

Bay Area Science Festival

General Exhibitors

exhibit@bayareasciencefestival.org

N/A

Randall Museum STEM Fair

Marcus Wojtkowiak (Director)

mwojtkowiak@randallmuseum.org

415-370-6342

Randall Museum STEM Fair

Katherine Galeas Veliz (Coord)

kgaleasveliz@randallmuseum.org

628-224-7603

Randall Museum STEM Fair

Bonny Gildin (Sponsors)

bgildin@randallmuseum.org

415-554-9600

North Bay Science Discovery

Event Organizers

info@northbayscience.com

N/A

The Randall Museum Golden Gate STEM Fair is of particular strategic importance. By sponsoring this event (the "Changemaker" tier requires a $5,000 to $9,999 investment), Ostio secures priority signage and the opportunity to physically present awards to winning students63. This embeds the brand deeply into the fabric of the San Francisco science education community, establishing authority and trust among the precise educators needed to authorize school-year contracts.

Strategic Execution and Next Steps

The educational procurement cycle operates on a rigid timeline. To secure widespread adoption for a 2027 programmatic launch, Ostio drone services must adhere to the following strategic sequence:

Immediate Pipeline Development (Q3 2026): Begin outreach to the SFUSD STEM office (Dr. Renée Marcy) and the ExCEL expanded learning hub. The objective is not immediate sales, but rather understanding the specific compliance, insurance, and pedagogical requirements necessary to become an approved vendor on the ELO-P list. Concurrently, register on the SF City Partner Portal to monitor upcoming municipal RFPs from DCYF.

CBO and Beacon Center Penetration (Q3-Q4 2026): Target the Executive Directors and Beacon Managers of the Richmond Neighborhood Center, YMCA, Boys & Girls Clubs, and Jamestown Community Center. Propose low-risk, highly visible pilot programs (e.g., a four-week introductory drone workshop) to run in the spring of 2027. Successful execution of these pilots will serve as the foundation for district-wide scaling in the fall.

Exhibition and Lead Generation (Fall 2026 - Spring 2027): Secure booth space and live demonstration areas at the Maker Faire Bay Area (September), the SFUSD Winter Science Fair (December), the Randall Museum Golden Gate STEM Fair (March), and the North Bay Science Discovery Day (May). Capture contact information from attending teachers and parents to build a grassroots demand network.

Summer Camp B2B Licensing (Q1 2027): Finalize partnership agreements with commercial camps like EDMO, Camp Galileo, TechKnowHow, and Steve & Kate's Camp. Position the drone curriculum as a turnkey solution that allows these camps to offer premium aeronautics and robotics modules without having to develop the curriculum or hardware infrastructure internally.

By systematically engaging the centralized district authorities, the decentralized non-profit CBO network, independent schools, commercial summer operators, and the regional STEM exhibition circuit, a comprehensive drone education program can achieve significant market penetration in the San Francisco Bay Area by 2027. The key to this acquisition strategy lies in framing drone technology not merely as a novel toy, but as a rigorous, NGSS-aligned, and highly engaging tool for next-generation workforce development.

Works cited

ExCEL Expanded Learning Programs - SFUSD, https://www.sfusd.edu/services/family-supports-services/before-after-school-programs/excel-expanded-learning-programs

Expanded Learning Opportunities Program (ELO-P) - SFUSD, https://www.sfusd.edu/ExCELHUB/expanded-learning-opportunities-program-elo-p

Science - SFUSD, https://www.sfusd.edu/school/galileo-academy-science-technology/academics/academic-departments/science

College and Career Readiness - SFUSD, https://www.sfusd.edu/departments/college-and-career-readiness

ExCEL Incident Protocol and Incident Reporting - SFUSD, https://www.sfusd.edu/ExCELHUB/excel-incident-protocol-and-incident-reporting

Special Education Extended School Year - SFUSD, https://www.sfusd.edu/sped/special-education-resources-families/special-education-extended-school-year

SFUSD Departmental Directory, https://www.sfusd.edu/about-sfusd/contact-us/sfusd-departmental-directory

Presidio Middle School - SFUSD, https://www.sfusd.edu/school/presidio-middle-school/details

About Presidio PTSA - SFUSD, https://www.sfusd.edu/school/presidio-middle-school/families/about-presidio-ptsa

SFUSD Middle and K-8 Schools Showcase Science Experiments, https://www.sfusd.edu/about-sfusd/sfusd-news/press-releases/2023-03-02-sfusd-middle-and-k-8-schools-showcase-science-experiments

Expanded Learning - SFUSD, https://www.sfusd.edu/school/ap-giannini-middle-school/families/expanded-learning

Contact Us - SFUSD, https://www.sfusd.edu/school/herbert-hoover-middle-school/about/contact-us

James Lick — Jamestown Community Center, https://www.jamestownsf.org/james-lick

James Lick Middle School Beacon Program - SF Service Guide, https://www.sfserviceguide.org/services/2972

James Lick Middle School - SFUSD, https://www.sfusd.edu/school/james-lick-middle-school/details

Out of school time - SF.gov, https://www.sf.gov/information--out-school-time

AGENCY PROFILE - Department of Children, Youth and Their Families, https://apps.dcyf.org/proposals/report_57157589.pdf

System of Support for Expanded Learning Contacts - California Department of Education, https://www.cde.ca.gov/ls/ex/sosexplearncontacts.asp

DCYF RFP - Department of Children, Youth and Their Families, https://contracts.dcyf.org/rfp

Work with us! - SF.gov, https://www.sf.gov/work-with-us

About Us - The Richmond Neighborhood Center, https://richmondsf.org/about/

Peabody ES After-School Enrichment - SFUSD, https://www.sfusd.edu/school/george-peabody-elementary-school/peabody-es-after-school/peabody-es-after-school-enrichment

Staff - Boys & Girls Clubs of San Francisco, https://www.kidsclub.org/about/staff

Before & Afterschool Programs - YMCA of San Francisco, https://www.ymcasf.org/program/before-afterschool-programs/

YMCA of San Francisco - Stonestown Family - AskDarcel - SF Service Guide, https://staging.askdarcel.org/organizations/1193

Cesar Chavez — Jamestown Community Center, https://www.jamestownsf.org/cesar-chavez

Our Team - Jamestown Community Center, https://www.jamestownsf.org/our-team

After School Programs - TEL HI Neighborhood Center, https://www.telhi.org/programs-services/youth-teens/beacon-afterschool-programs/

Staff - TEL HI Neighborhood Center, https://www.telhi.org/who-we-are/our-people/staff/

Building Success Beyond The Bell - Mission Graduates, https://www.missiongraduates.org/after-school-programs/

Sanchez Elementary School - Mission Graduates, https://www.missiongraduates.org/sanchez-elementary-school/

Alvarado Elementary School - Mission Graduates, https://www.missiongraduates.org/alvarado-elementary-school/

Everett Middle School - Mission Graduates, https://www.missiongraduates.org/everett-middle-school/

Our Programs | BACR, https://www.bacr.org/programs-we-provide

BACR After School - SFUSD, https://www.sfusd.edu/school/paul-revere-prek-8-school/bacr-after-school

Herbert Hoover Middle School - Families - SFUSD, https://www.sfusd.edu/school/herbert-hoover-middle-school/families

SFHSA Services Child Care, https://www.sfhsa.org/services/child-care

Early Learning For All - SF.gov, https://www.sf.gov/early-learning-for-all

Contact Us - Children's Council San Francisco, https://www.childrenscouncil.org/families/contact-us/

Afterschool & Summer Camp - San Francisco Day School, https://www.sfday.org/school-life/afterschool

Extended Day & Summer - The Hamlin School, https://hamlin.org/extended-day-and-summer/

Steve & Kate's Camp - San Francisco, https://sanfran.kidsoutandabout.com/content/steve-kates-camp-san-francisco

San Francisco - Mission Dolores Summer Camp, https://steveandkatescamp.com/sf-mission-dolores/

Contact - Steve & Kate's Camp, https://steveandkatescamp.com/contact/

TechKnowHow Summer Camps Contact Information, https://www.techknowhowkids.com/contact

TechKnowHow Camps: Summer Lego, Tech and Coding Camps | California, https://www.techknowhow.com/

Summer Girls Tech STEM Camp SF Bay Area - TechKnowHow, https://www.techknowhowkids.com/tech-girls-camp

Edventuremore - Mightycause, https://www.mightycause.com/organization/Edventuremore

CAMP EDMO - Berkeley in Berkeley, California | CampNavigator (Id:#13944), https://www.campnavigator.com/summer-camp/camp_edmo_berkeley_13944.html

FAQ - Camp EDMO, https://edmo.org/faq

Contact Us | Galileo Camps, https://galileo-camps.com/contact-us/

Frequently Asked Questions - Galileo Camps, https://galileo-camps.com/faqs/

Contact - Camp Captivate, https://campcaptivate.com/contact-2/

Birthday Parties - Camp Captivate, https://campcaptivate.com/birthday-parties/

Maker Faire | FAQ, https://makerfaire.com/bay-area/faq/

Maker Faire | Startup & Sponsor Application 2026, https://makerfaire.com/bay-area/call-for-makers/startup-sponsor-application/

Maker Faire | Call for Makers, https://makerfaire.com/bay-area/call-for-makers/

Open Sauce - Wikipedia, https://en.wikipedia.org/wiki/Open_Sauce

Open Sauce Technology & Creator Festival | July 17 - 18, 2027, https://www.opensauce.com/

Contact Us - Bay Area Science Festival, https://bayareasciencefestival.org/contact-us/

North Bay Science Discovery Day - March 7, 2026, https://www.northbayscience.com/

3rd Annual Winter Literacy, Math, and Science Fair - This Saturday, Dec. 6 | SFUSD, https://www.sfusd.edu/announcements/2025-12-03-3rd-annual-winter-literacy-math-and-science-fair-saturday-dec-6

Science Fair Sponsorship - Randall Museum, https://randallmuseum.org/stemfair26/