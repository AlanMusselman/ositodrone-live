# Ready-to-Send Nov/Dec San Francisco Outreach Batch (`info@ositodrone.com`)

> **Why Send Now (Late October – December Window)**: San Francisco Summer Camps (Boys & Girls Clubs, Galileo, Steve & Kate's, SF Rec & Parks) and SF DCYF Beacon After-School Directors finalize their **Spring 2027 ELO-P cohorts** and **Summer 2027 specialty vendor slots** between November and January.

Below are 6 copy-paste-ready outreach emails tailored specifically to **Osito Drone Services (`ositodrone.com`)**, weaving in your **Maker Faire** track record, **palm-sized 360°-guarded indoor micro-FPV drones**, and **turnkey staffing**.

---

## Email 1: Boys & Girls Clubs of SF — Don Fisher Clubhouse (Haight / Western Addition)
**Target**: Clubhouse Director / Education & STEM Director
**Program**: 5-Day Summer Flight & Obstacle Academy (`$16,000` / 60 youth) or Spring After-School Pilot
**Subject**: Turnkey Indoor Micro-Drone & Coding Academy for Don Fisher Clubhouse (Maker Faire Featured)

Hi [First Name],

My co-founders and I run **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) right here in San Francisco. You may have seen our youth micro-drone flight arenas at **Maker Faire**—we teach San Francisco kids how to code, pilot, and master aviation safety using **palm-sized, sub-100g 360° prop-guarded indoor drones**.

As you map out your Spring DCYF enrichment and Summer 2027 specialty programs at the **Don Fisher Clubhouse**, we would love to bring a **100% turnkey Youth Drone & Autonomous Coding Academy** to your members:

- **100% Gym-Safe & Indoor Ready**: We bring pop-up safety netting and featherweight, prop-guarded micro-FPV drones specifically engineered for indoor gymnasiums and multipurpose rooms.
- **Zero Burden on Clubhouse Staff**: We provide 4 background-checked (CA Live Scan), FAA TRUST-certified instructors and 30 programmable drone kits (a 2:1 Pilot + Coder pairing so every youth is hands-on).
- **SF DCYF & Grant Aligned**: Structured at **$266.67/youth** all-inclusive for a 60-student 5-Day Summer Flight Academy (or customizable for an 8-week Spring after-school block).

Could my co-founders and I stop by Don Fisher Clubhouse for **12 minutes** next week with two of our palm-sized micro-drones so you can fly one yourself and see how safe and engaging it is for the kids?

Warm regards,

**Alan Musselman & Co-Founders**
Osito Drone Services | OSITO Drone Academy (San Francisco, CA)
`info@ositodrone.com` | `https://ositodrone.com`

---

## Email 2: Marina Middle School — SF Beacon Center (YMCA of SF Lead Agency)
**Target**: Beacon Director / Expanded Learning Site Coordinator
**Program**: 8-Week Spring ELO-P / DCYF Autonomous Coding & Flight Lab (`$12,700` / 60 students)
**Subject**: Spring ELO-P / DCYF Turnkey STEM Lab for Marina Middle Beacon: Youth Drone Coding & Flight

Hi [First Name],

My co-founders and I lead **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) here in San Francisco. Following our hands-on youth flight showcases at **Maker Faire**, we are partnering with San Francisco Beacon sites to deliver turnkey **8-Week After-School Autonomous Drone Coding & Flight Labs** funded through **CA ELO-P and SF DCYF enrichment budgets**.

Why SF middle schoolers (and Site Coordinators) love the program:
- **More Than Flying—Real Coding & Physics**: Students pair up (2:1 student-to-drone ratio across 30 kits) to program autonomous flight paths in Blockly/Python, debug optical-flow sensors, and earn their **FAA TRUST Youth Safety Credential**.
- **We Supply the Certified Staff (15:1 Ratio)**: Your existing Beacon staff don't have to learn drone maintenance or coding—our 4 Live Scan-cleared instructors bring the entire fleet, spare batteries, and indoor safety netting.
- **ELO-P & DCYF Ready Pricing**: All-inclusive at **$12,700 for 60 students** across 16 instructional hours (**$211.67/student**, or **$13.23 per student-hour**).

Do you have 10 minutes this Thursday or Friday for a quick call—or a 15-minute live indoor demo in the Marina Middle gym?

Best regards,

**Alan Musselman & Co-Founders**
Osito Drone Services | OSITO Drone Academy (San Francisco, CA)
`info@ositodrone.com` | `https://ositodrone.com`

---

## Email 3: KIPP San Francisco Bay Academy (Western Addition)
**Target**: Principal / STEM Lead / Expanded Learning Coordinator
**Program**: 8-Week ELO-P Middle School Autonomous Drone & Coding Lab (`$12,700` / 60 students)
**Subject**: KIPP SF Bay Academy x Osito Drone Academy: Spring ELO-P Coding & Micro-Drone Lab

Hi [First Name],

We're big admirers of KIPP San Francisco Bay Academy's commitment to hands-on STEM. My co-founders and I run **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) in San Francisco, where we combine commercial aerial engineering with our **Maker Faire-featured Youth Micro-Drone Academy**.

We have an open slot this Spring to bring our **8-Week Autonomous Drone Coding & Flight Safety Lab** to 60 KIPP middle schoolers using your **California ELO-P / Title IV Part A STEM funds**:
- **NGSS & CSTA Standards Aligned**: Covers 3D coordinate geometry ($X, Y, Z$), Newton's laws of thrust/lift, sensor stability, and autonomous Python/Blockly flight loops.
- **Turnkey Hardware & Staffing**: Includes 30 palm-sized, 360°-guarded indoor drones (2:1 ratio) and 4 certified instructors (15:1 ratio)—zero prep required from KIPP classroom teachers.
- **Grant-Ready Unit Economics**: **$211.67 per student** ($12,700 total for 60 students across 8 weeks / 16 hours), complete with ready-to-paste ELO-P/Title IV budget justification paragraphs.

Would next Tuesday or Wednesday work for a 12-minute on-campus demo so you can see our micro-drones and curriculum firsthand?

Best regards,

**Alan Musselman & Co-Founders**
Osito Drone Services | OSITO Drone Academy (San Francisco, CA)
`info@ositodrone.com` | `https://ositodrone.com`

---

## Email 4: Lick-Wilmerding High School / Town School / Hamlin (SF Independent STEM)
**Target**: Director of Design & Tech / Head of Middle or Upper School / Auxiliary Programs Director
**Program**: Custom Design-Build-Fly Workshop or Semester Elective (`$12,700–$17,900`)
**Subject**: San Francisco Aerial Robotics & Micro-FPV Engineering Lab (Osito Drone Academy)

Hi [First Name],

As a fellow San Francisco technologist (former lead developer on Adobe Fireworks and Maker Faire drone exhibitor), I co-founded **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) with two close friends to bring authentic aerial robotics, FPV flight physics, and autonomous coding into SF independent schools.

Whether for a **Winter/Spring Design & Engineering Intensive**, an **After-School Auxiliary Enrichment Course**, or a **1-Day All-Grade STEAM Assembly**, we provide a turnkey lab where students:
1. Master **FPV & Line-of-Sight aerodynamics** using ultra-safe, palm-sized sub-100g indoor micro-drones.
2. Program **autonomous computer-vision and sensor-stabilized flight routines** (bridging the gap between classroom coding and real-world aerial platforms like Skydio and commercial survey drones).
3. Earn their official **FAA TRUST Youth Safety Certificate**.

We bring the entire 30-drone classroom fleet, safety arenas, and certified instructors. Would you be open to a quick 15-minute coffee or on-campus demo in the next two weeks?

Warmly,

**Alan Musselman & Co-Founders**
Osito Drone Services | OSITO Drone Academy (San Francisco, CA)
`info@ositodrone.com` | `https://ositodrone.com`

---

## Email 5: Galileo Summer Camps SF & SF Recreation & Parks (Summer 2027 Catalog Lock-In)
**Target**: Regional Camp Director / SF Rec & Parks Youth Program Manager
**Program**: 5-Day Turnkey Summer Flight & Obstacle Academy
**Subject**: Summer 2027 SF Specialty Partner: Turnkey Indoor/Outdoor Youth Micro-Drone Camp (Osito Drone)

Hi [First Name],

As you finalize specialty enrichment partners for the **Summer 2027 San Francisco camp season**, my co-founders and I at **Osito Drone Services / OSITO Drone Academy** (`ositodrone.com`) would love to partner on our most requested program: the **5-Day Youth Micro-Drone Obstacle & Flight Academy**.

Having run youth flight zones at **Maker Faire** and across the Bay Area, we solved the three biggest headaches camp directors face with tech camps:
1. **100% Fog/Wind/Indoor Proof**: Unlike outdoor toy drones that blow away in San Francisco summer winds, our palm-sized, 360°-guarded micro-drones fly smoothly inside any school gym, auditorium, or netted courtyard.
2. **Waitlist-Worthy Parent Appeal**: Kids fly through LED obstacle gates, learn paired Pilot + Spotter aviation teamwork, and take home their FAA TRUST Youth Pilot credential.
3. **100% Turnkey Staffing & Insurance**: We supply all drone kits (2:1 ratio), spare batteries, charging stations, Live Scan-cleared instructors (15:1 ratio), and Commercial General Liability COI naming your organization as Additional Insured.

Can we schedule a brief 10-minute call next week to share our Summer 2027 partner dates and revenue-share/wholesale rates?

Best,

**Alan Musselman & Co-Founders**
Osito Drone Services | OSITO Drone Academy (San Francisco, CA)
`info@ositodrone.com` | `https://ositodrone.com`

---

## Email 6: The "Dual-Engine Cross-Sell" Pitch (SF Commercial Real Estate / Construction + Community STEM Sponsorship)
**Target**: San Francisco Real Estate Developers, Brokerages, & Construction/Survey Managers
**Subject**: SF Aerial Cinematography & Site Surveying + Neighborhood School STEM Impact (Osito Drone Services)

Hi [First Name],

At **Osito Drone Services** (`ositodrone.com`), my co-founders and I deliver FAA Part 107 commercial aerial cinematography, 4K property marketing, and precision site surveying across San Francisco.

What makes working with Osito unique in the Bay Area: alongside our commercial aerial operations, we operate the **OSITO Drone Academy**, teaching San Francisco kids hands-on STEM, coding, and aviation safety with palm-sized micro-drones at local schools and Maker Faire events.

If you have upcoming San Francisco listings, development sites, or roof/facade inspections this quarter, we'd love to send you our commercial reel and rate card—and show you how every commercial project we fly helps put hands-on STEM drone labs into San Francisco neighborhood schools.

Do you have any sites coming up in November or December that need aerial coverage?

Best regards,

**Alan Musselman & Co-Founders**
Osito Drone Services (`ositodrone.com`) — San Francisco, CA
`info@ositodrone.com`
