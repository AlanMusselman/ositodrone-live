# MIGUEL FLORES — CEO & DRONE SALES EXPERT MASTER BIBLE
**Company:** Osito Drone LLC / Osito Drone Academy (`ositodrone.com`)  
**Prepared For:** **Miguel Flores**, CEO & Co-Founder (`miguel@ositodrone.com` | `415-571-6614`)  
**Co-Founders:** **Alan Musselman**, COO (`alan@ositodrone.com` | `415-810-4158`) & **Jesus Aceves**, CTO (`jesus@ositodrone.com` | `415-269-1206`)

---

## 🚀 QUICK LAUNCH: YOUR INTERACTIVE CEO COMMAND PORTAL
Double-click **[`MIGUEL_CEO_MASTER_COMMAND_PORTAL.html`](./ositodrone/MIGUEL_CEO_MASTER_COMMAND_PORTAL.html)** (or **[`miguel_ceo_sales_cockpit.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/miguel_ceo_sales_cockpit.html)**) in any browser every morning at **8:30 AM**.

---

## PART 1: HOW MIGUEL WINS AS CEO (THE "NO-PRESSURE" SALES SECRET)

1. **Never Try to Close a $5,600–$16,000 Contract on a Cold Phone Call:**
   - School principals, Extended Day directors, and camp managers get pitched boring software and workbooks all day.
   - **Your ONLY goal on a phone call, email, or afternoon walk-in is to book a 10-Minute On-Site Demo.**
   - Once you and Jesus walk in, set down a featherweight (`28.8g–39.5g`), 360°-guarded indoor micro-drone and a pop-up netted Hover Pod, and let the director touch the safety cage while it hovers, **the drone closes the deal.**

2. **The "Triad Close" (How You, Jesus, and Alan Work as a 3-Man Strike Team):**
   - **Phase 1 — Miguel (CEO — The Executive Door-Opener):** Makes the 9:00 AM calls, sends the pre-built `.eml` emails, runs the 1:30 PM neighborhood walk-ins, and books the 10-minute on-site demos. During live Academy classes, coaches **Station 2 (Netted Hover Pods)** and hosts school directors/parents.
   - **Phase 2 — Jesus (CTO — The Technical Closer & Pit-Crew Lead):** Joins Miguel on 10-minute demos to fly the micro-drone on the director's desk. During live classes, runs **Station 1 (Flight Simulator Laptops)** + **Station 4 (Staff-Only Repair, Soldering & Bat-Safe Battery Pit Crew)**.
   - **Phase 3 — Alan (COO — Pricing, Grants, COI & Operations Lead):** Delivers the custom quote, `$2M` General Liability COI, Live Scan compliance packet, and multi-semester contracts within 30 minutes of a warm demo. During live classes, runs **Station 3 (FPV Goggle Obstacle Course)**, waivers, and parent pickup flyers.

---

## PART 2: THE DRONE SALES EXPERT CHEAT SHEET (MEMORIZE THESE 5 FACTS)

When a school principal, camp director, parent, or commercial client asks how our drones work, drop these 5 exact facts to sound like a seasoned aerospace & STEM executive:

1. **Featherweight Sub-250g Mass (`28.8g` AcroBee65 / `39.5g` CUB-75):**
   - *"Our indoor classroom micro-drones weigh between 29 and 40 grams—less than a golf ball, and a fraction of the FAA's 250-gram threshold. Even if a student bumps into a wall or a hand, there is zero kinetic impact hazard."*
2. **360° Full Ducted Propeller Guards & Netted Hover Pods:**
   - *"Every propeller is enclosed inside a 360-degree ducted guard. Plus, beginners start on laptop flight simulators and inside our pop-up netted Hover Pods before graduating to the LED FPV obstacle course."*
3. **Software-Capped Beginner Firmware (`Betaflight` STM32F411 + BMI270 Gyro):**
   - *"We program the onboard flight controller to cap beginner motor power at 50%–68% ('Cub Mode') with auto-leveling (`ANGLE` mode) and a 22-degree tilt limit, so the drone never shoots into the ceiling."*
4. **Fireproof `Bat-Safe` 1S LiPo Battery Protocol:**
   - *"We use tiny 1-cell (3.8V LiHV) micro-batteries and store/charge every battery inside certified double-walled insulated steel **Bat-Safe** fireproof containers managed exclusively by our CTO at the Staff Pit-Crew desk."*
5. **"Build, Fly, Crash, Repair" Curriculum (NGSS & FAA TRUST Aligned):**
   - *"Traditional classes punish failure. Our curriculum destigmatizes failure by turning every crash into a hands-on engineering diagnostic lesson (`NGSS MS-ETS1` Engineering Design & `MS-PS2` Forces & Motion), and every student earns their official **FAA TRUST Youth Safety Certificate**."*

---

## PART 3: INSTANT OBJECTION COMEBACKS FOR MIGUEL

| What the Prospect Says | Miguel's Exact Word-for-Word Comeback |
| :--- | :--- |
| **"Just send me an email / flyer."** | *"I will definitely send the one-pager right after we hang up! The only reason I ask for 10 minutes in person is that a PDF can't show you how featherweight and quiet these palm-sized indoor drones are. If my CTO Jesus and I swing by Thursday at 1:30 PM for literally 8 minutes just to show you one at the front desk, would that be okay?"* |
| **"We don't have budget left."** | *"Totally understand general school funds are tight! That's actually why SF sites bring us in—our lab is 100% eligible under **California ELO-P (Expanded Learning)**, **SF DCYF Beacon enrichment**, and **Title IV Part A STEM** funds at $20–$29 per student-hour, and we give you the copy-paste grant justification paragraph. Can we show you how other SF coordinators fund it in a quick 10-minute visit?"* |
| **"Are drones safe indoors with kids?"** | *"Safety is our #1 priority too. We never use heavy outdoor camera drones with students. We use featherweight sub-40-gram indoor micro-drones with 360-degree full propeller guards, speed-capped beginner firmware, fireproof Bat-Safe battery boxes, and pop-up netted Hover Pods. You can literally press your finger against the safety cage while it hovers—let me bring one by this week so you can test it yourself!"* |
| **"Our teachers don't know how to teach or fix drones."** | *"They don't have to lift a finger! Unlike companies that sell you a box of drones that end up gathering dust in a closet when a propeller breaks, Osito Drone Academy is 100% turnkey. Our 3 co-founders bring the 4-Pilot Tablet Flight Sim Pod, netted Hover Pods, FPV gates, and our own Pit-Crew repair station so every drone stays flying."* |
| **"We already have a robotics or coding club."** | *"That's awesome—that means your kids already love STEM! What makes Osito the perfect next step is taking coding off a flat 2D screen or floor robot and into 3D space (aerodynamics, FPV goggles, and hands-on hardware repair). Even a 2-hour Holiday Camp Guest Block ($600) or 1-Day STEM Assembly ($1,200) is a huge hit alongside existing robotics."* |
| **"SFUSD central vendor approval takes too long."** | *"You're totally right about central district procurement! The shortcut in San Francisco is that we contract directly through your site's ExCEL / Beacon Lead CBO Agency (like YMCA of SF, Boys & Girls Clubs, Mission Graduates, or BACR) or your PTA in just 2 to 3 weeks."* |

---

## PART 4: PRICING, PACKAGES & GRANT CHEAT SHEET

### A. Osito Drone Academy (Schools, Camps, Nonprofits & Pop-Ups)
- **Holiday Break Camp Guest Block (2 Hours / Half-Day):** **`$600` (2-hr) / `$960` (Half-Day)** — *Fastest cash for Nov 11 Veterans Day, Nov 23–25 Thanksgiving, and Winter/Spring Breaks.*
- **Saturday Community Space Pop-Up (Sports Basement / STEMful):** **`$85 / student`** (`12 seats = $1,020` per 2-hr workshop).
- **Option A (`PKG-1`) — 1-Day Discovery Workshop (2 Hrs = `$960`) / Family STEM Night (3 Hrs = `$1,200`, up to 16 kids):** **`$960`–`$1,200`** (`$60–$75/student` | `$25–$30/student-hr`).
- **Option B (`PKG-3A`) — 5-Day Summer / Vacation Flight Camp (15 Hrs, 16 kids):** **`$6,800`** (`$425/student` | `$28.33/student-hr`; or **`$5,100`** for a 12-student cohort at `$425/student`).
- **Option C — 8-Week After-School Flight & Repair Lab (12 Hrs, up to 16 kids):** **`$5,600`** (`$350/student` | `$29.17/student-hr`).
- **Option D — 14-Week Full Semester Institutional Track (21 Hrs):** **`$8,400`** (`$525/student` | `$25/student-hr`).
- **Option E — Title IV / Nonprofit Grant Tier (8 Weeks, 1:8 Ratio):** **`$3,840`** (`$240/student` | `$20/student-hr`).
- **Large ELO-P / DCYF Beacon Multi-Cohort (60 Students across 4 cohorts, 8 Weeks):** **`$12,700`** (`$211.67/student`) — or **`$16,000`** for a 60-student 5-Day Summer Flight Academy.
- **Weekend Kids Drone Birthday Party:** **`$200` (60-Min, up to 8 pilots) / `$299` (90-Min Nov Launch Special) / `$400` (2-Hr Standard, up to 10–12 pilots)** or **`$550` All-In Venue Turf Party**.

### B. Commercial Drone Services (When Pitching Realtors, Roofers, GCs & Corporate Events)
- **Why Realtors Buy:** Listings with aerial photos sell **68% faster** (`89` vs `123` days on market), video tours generate **403% more inquiries**, and **82% of `$1M+` luxury listings** use drone media.
- **Real Estate & Construction Packages:** **`$495` Aerial + Indoor FPV Bundle** (`$500` standard single shoot, **`$1,600` 4-Listing Luxury Pack**) | **`$450` Single Construction Ortho/4K (`CON-01`)** | **`$595/mo` Monthly Construction Retainer (`CON-12M`)** | **`$1,095/mo` Bi-Weekly Construction Retainer (`CON-BIW`)**.
- **Roofers, HOAs & Property Managers:** **`$245` Single Roof Thermal/4K Trial (`$195` Nov Flash Promo)** (100% credited toward the **`$2,250` 10-Roof Pass** or **`$595/mo` Retainer**).
- **Corporate Offsites & Holiday Parties (`SHARD-75` Netted Combat Arena):** **`$1,500–$3,500`** per event (`69.5%` gross margin).

---

## PART 5: COMPLETE DIRECTORY OF MIGUEL'S CONSOLIDATED FILES IN THIS WORKSPACE

All files for Miguel have been organized inside **[`ositodrone/`](./ositodrone/)** (and mirrored at the root of this project):

1. **Interactive Portals & Dashboards:**
   - [`ositodrone/MIGUEL_CEO_MASTER_COMMAND_PORTAL.html`](./ositodrone/MIGUEL_CEO_MASTER_COMMAND_PORTAL.html) — **Master All-in-One Interactive CEO & Drone Sales Training Hub**
   - [`ositodrone/README_START_HERE_MIGUEL.md`](./ositodrone/README_START_HERE_MIGUEL.md) — Quick-start folder guide
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/miguel_ceo_sales_cockpit.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/miguel_ceo_sales_cockpit.html) — Daily 5-Touch Tracker, Objection Flashcards & Principal Roleplay Simulator
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/osito_three_founders_command_center.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/osito_three_founders_command_center.html) — 3-Co-Founder C-Suite Baton Pass Dashboard
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/osito_live_pricing_calculator.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/osito_live_pricing_calculator.html) — Client-Safe Live Pricing & Grant Calculator
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/Osito_Internal_Production_Cost_and_Business_Plan_Estimator.html) — Unit Economics & Margin Estimator
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/OSITO_Kids_Garage_Loadout_Menu.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/OSITO_Kids_Garage_Loadout_Menu.html) — 392M+ Drone Combination Interactive Menu
   - [`ositodrone/sales/06_Interactive_Demos_and_Estimators/KODIAK75_3D_Viewer.html`](./ositodrone/sales/06_Interactive_Demos_and_Estimators/KODIAK75_3D_Viewer.html) — Offline 3D Drone Hardware Viewer

2. **Daily Action Orders, Scripts & Event Workflows (`ositodrone/sales/01_Daily_Action_and_Scripts/`):**
   - [`Miguel_CEO_5_Day_Academy_Focus_Orders.md`](./ositodrone/sales/01_Daily_Action_and_Scripts/Miguel_CEO_5_Day_Academy_Focus_Orders.md) — 100% Osito Drone Academy 5-Day Call & Walk-In Plan
   - [`Miguel_CEO_5_Day_Action_Orders.md`](./ositodrone/sales/01_Daily_Action_and_Scripts/Miguel_CEO_5_Day_Action_Orders.md) — Hybrid School + Commercial Fast-Cash 5-Day Plan
   - [`Osito_Drone_Academy_School_and_Space_Workflow.md`](./ositodrone/sales/01_Daily_Action_and_Scripts/Osito_Drone_Academy_School_and_Space_Workflow.md) — 4-Bin Packing List, 30-Min Setup, and 15-Min Rotation Floor Plan
   - [`Osito_Team_Operating_Rhythm_and_Scorecard.md`](./ositodrone/sales/01_Daily_Action_and_Scripts/Osito_Team_Operating_Rhythm_and_Scorecard.md) — 8:30 AM Standup Agenda, 5-Min Phone SLA & Weekly Founder KPIs

3. **Pre-Built Ready-to-Send Outlook `.eml` Emails (`05_Outbox_Emails/Miguel_CEO_Ready_To_Send_Emails/`):**
   - `Academy_10_Focused_Emails/` — 10 `.eml` files with `Osito Academy.pdf` and `Osito_Drone_Academy_One_Pager.html` pre-attached (`STEMful`, `JCCSF`, `Sports Basement`, `Children's Day School`, `Live Oak`, `SF Day`, `International School`, `Steve & Kate's`, `Brandeis`, `Brightworks & Tinkering School`).
   - Root `02_Ready_To_Send_Emails/` — 10 Hybrid `.eml` files including `Vanguard Properties`, `Build Group GC`, `CitiScape HOA`, and `Non Plus Ultra / The Midway`.

4. **Account Dossiers, Lead Trackers & Deep Research (`03_Leads_and_Account_Playbooks/` & `07_CEO_Sales_Mastery_and_Coach/`):**
   - [`Team_Miguel_CEO_Account_Playbook.md`](./ositodrone/sales/03_Leads_and_Account_Playbooks/Team_Miguel_CEO_Account_Playbook.md) — Deep dossiers on Miguel's 17 flagship SF accounts
   - [`Osito_SF_Sales_Leads_Tracker.csv`](./ositodrone/sales/03_Leads_and_Account_Playbooks/Osito_SF_Sales_Leads_Tracker.csv) & [`Osito_November_Fast_Cash_Jobs_Tracker.csv`](./ositodrone/sales/03_Leads_and_Account_Playbooks/Osito_November_Fast_Cash_Jobs_Tracker.csv)
   - [`San_Francisco_2027_STEM_Programs__Direct_Outreach_Contact_Lists.md`](./ositodrone/sales/07_CEO_Sales_Mastery_and_Coach/San_Francisco_2027_STEM_Programs__Direct_Outreach_Contact_Lists.md) — Exhaustive SFUSD (Dr. Renée Marcy, ExCEL), CBO (BACR, Mission Graduates, Richmond Neighborhood Center, Urban Ed, Telegraph Hill), Independent School, and Camp directory imported from Downloads
   - [`Drone_Academy_Sales_Document_Research.md`](./ositodrone/sales/07_CEO_Sales_Mastery_and_Coach/Drone_Academy_Sales_Document_Research.md) — Full pedagogical & AcroBee65 technical prospectus imported from Downloads
   - [`Osito_Drone_Services_Infographic_Plan.md`](./ositodrone/sales/07_CEO_Sales_Mastery_and_Coach/Osito_Drone_Services_Infographic_Plan.md) — Commercial real estate & SEO market blueprint imported from Downloads
   - [`04_miguel_30_day_ceo_sales_playbook.md`](./ositodrone/sales/07_CEO_Sales_Mastery_and_Coach/04_miguel_30_day_ceo_sales_playbook.md) & [`sf_california_funding_guide.md`](./ositodrone/sales/07_CEO_Sales_Mastery_and_Coach/sf_california_funding_guide.md)

5. **Print Flyers, Rate Cards, Waivers & Business Cards (`04_Flyers_and_Print_OnePagers/`, `05_Closing_Docs_Rates_and_Waivers/`, `operations_and_brand/`):**
   - [`Osito_Drone_Academy_One_Pager.html`](./ositodrone/sales/04_Flyers_and_Print_OnePagers/Osito_Drone_Academy_One_Pager.html), [`Osito Academy.pdf`](./ositodrone/sales/04_Flyers_and_Print_OnePagers/Osito%20Academy.pdf), [`one pager Osito services.pdf`](./ositodrone/sales/04_Flyers_and_Print_OnePagers/one%20pager%20Osito%20services.pdf), [`birthday osito drone events.pdf`](./ositodrone/sales/04_Flyers_and_Print_OnePagers/birthday%20osito%20drone%20events.pdf), and [`flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg`](./ositodrone/sales/04_Flyers_and_Print_OnePagers/flyer_final_CLEAN_NO_AI_DISCLAIMER.jpg)
   - [`Osito_2027_Commercial_Rate_Card_and_Order_Form.html`](./ositodrone/sales/05_Closing_Docs_Rates_and_Waivers/Osito_2027_Commercial_Rate_Card_and_Order_Form.html) & [`Osito_Participant_Safety_Waiver.html`](./ositodrone/sales/05_Closing_Docs_Rates_and_Waivers/Osito_Participant_Safety_Waiver.html)
   - [`miguel.jpg`](./ositodrone/operations_and_brand/business_cards_and_logos/miguel.jpg) — Miguel's CEO Business Card (`415-571-6614` | `miguel@ositodrone.com`)
