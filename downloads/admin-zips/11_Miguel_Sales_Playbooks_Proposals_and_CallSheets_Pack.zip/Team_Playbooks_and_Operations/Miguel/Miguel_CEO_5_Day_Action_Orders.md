# MIGUEL FLORES (CEO) — 5-DAY OSITO DRONE ACADEMY ACTION ORDERS

**Focus:** 100% **Osito Drone Academy** (Schools, Holiday Break Camps, Makerspaces & Community Event Spaces)  
**What We Are Pitching:** Our turnkey **Youth Drone & STEM Flight Lab** where students rotate through **3 Progressive Flight Stations** (*Station 1: Laptop Flight Simulators*, *Station 2: Netted Hover Pods*, *Station 3: FPV Goggle Obstacle Course*) using safe, lightweight ducted indoor micro-drones—backed by our **Station 4 On-Site Staff Repair Pit Crew** (staff handles all repairs, battery charging, and maintenance so kids never touch hot tools and never lose flight time!).  
**What We Are NOT Pitching Right Now:** Do not mention unbuilt R&D drone projects or commercial real estate/roofing—keep 100% of every conversation focused on **Osito Drone Academy** for youth!

---

## ⏰ YOUR DAILY RHYTHM (MONDAY – FRIDAY)

- **8:30 AM – 8:45 AM (15-Min Co-Founder Standup):** Quick check-in with Alan (`415-810-4158`) and Jesus (`415-269-1206`). Report 3 numbers: **Calls Made, In-Person Drop-Ins Done, Demos Booked**.
- **9:00 AM – 10:30 AM (Morning Call & Email Block):** Call the **3 School / Camp Directors** listed for that day using the 25-second script below, and send the follow-up email with [`Osito Academy.pdf`](./Osito%20Academy.pdf) and [`Osito_Drone_Academy_One_Pager.html`](./Osito_Drone_Academy_One_Pager.html).
- **1:30 PM – 3:30 PM (Afternoon Neighborhood Walk-In Block):** Carry **1 ducted AcroBee micro-drone + 1 folded Hover Pod + 5 printed copies of the Osito Drone Academy One-Pager** and walk into **2 schools or community spaces** in the same neighborhood.

---

## 📞 YOUR 25-SECOND PHONE & WALK-IN SCRIPT (USE EVERY TIME)

> *"Hi [Name], this is Miguel Flores, CEO of Osito Drone Academy here in San Francisco. We run a mobile indoor Youth Drone & STEM program where kids rotate through three progressive flight stations—laptop flight simulators, pop-up netted hover pods, and an FPV goggle obstacle course—while our on-site staff Pit Crew handles all maintenance and battery swaps.*
>
> *We bring 100% of the equipment and 3 flight coaches, and our featherweight indoor drones have full propeller guards so they're completely safe for classrooms and gyms. Are you open to a quick 10-minute on-site demo this week so your team can see the hover pod and micro-drones firsthand for your upcoming [Holiday Camp / Spring After-School session]?"*

---

## 🗓️ YOUR 5-DAY TARGET SCHEDULE (SCHOOLS, CAMPS & SPACES ONLY)

### DAY 1: MISSION & POTRERO CORRIDOR (Immediate Holiday Camps + K–8 Schools)
**Morning Calls (9:00 AM – 10:30 AM):**
1. **STEMful SF (`30 29th St`)** — Call **Kim Nguyen-Ehrenreich** at **`(415) 660-5975`** (`info@stemful-sf.com`)  
   *Pitch:* $600 2-Hour Guest Block for their **Wednesday, Nov 11 (Veterans Day)** or **Nov 23–25 (Thanksgiving)** camp, OR a 70/30 revenue-split Saturday Pop-Up Flight Lab at their 29th St studio.
2. **Children's Day School (`333 Dolores St`)** — Call **Tanner Taylor** (Extended Program Dir.) at **`(415) 861-5432`** (`tannert@cds-sf.org`)  
   *Pitch:* Book a 10-minute on-site demo for their Extended Program.
3. **Live Oak School (`1555 Mariposa St`)** — Call **Dorothy Martinez** (Extended Day & Summer Oaks Dir.) at **`(415) 861-8820`** (`dorothy_martinez@liveoaksf.org`)  
   *Pitch:* Book a 10-minute demo for Spring Extended Day & Summer Oaks Camp.

**Afternoon Walk-Ins (1:30 PM – 3:30 PM — Mission Street Route):**
- **Stop 1:** **Children's Day School (`333 Dolores St`)** & **Synergy School (`1387 Valencia St` — Ask for Elizabeth Brown, After School Lead)**
- **Stop 2:** **Alta Vista Middle School (`2558 Mission St`)** & **Mission Science Workshop (`3750 18th St` — Ask for Paul or Sonia)**

---

### DAY 2: THE PRESIDIO & RICHMOND (Camps, Makerspaces & Free Pop-Up Venues)
**Morning Calls (9:00 AM – 10:30 AM):**
1. **Sports Basement Bryant St (`1590 Bryant St`) & Presidio (`610 Old Mason St`)** — Call **`(415) 575-3001`** (`friends@sportsbasement.com`)  
   *Pitch:* Reserve "The Treeline" free community space for a **Saturday, Nov 14 & Nov 21 Osito Drone Academy Pop-Up Workshop** (`12 seats × $85/kid = $1,020`).
2. **Tinkering School (`682 Schofield Rd`, Presidio)** — Call **`(415) 562-6268`** (`info@tinkeringschool.com`)  
   *Pitch:* Co-hosted weekend or school-break 4-Station Drone Repair & Flight Workshop.
3. **Brightworks School (`682 Schofield Rd`, Presidio)** — Call **Lisa Nowell** at **`(415) 701-8700`** (`lisa@sfbrightworks.org`)  
   *Pitch:* After-School Flight Lab & in-school STEM rotation.

**Afternoon Walk-Ins (1:30 PM – 3:30 PM — Presidio Route):**
- **Stop 1:** **`682 Schofield Rd` in the Presidio** (Both **Brightworks School** AND **Tinkering School** are inside this exact same warehouse building!).
- **Stop 2:** **Sports Basement Presidio (`610 Old Mason St`)** & **House of Air (`926 Mason St` — Ask for GM Daniel Matsumoto about Drone Birthday Party add-ons)**.

---

### DAY 3: HAYES VALLEY, NOPA & COLE VALLEY (Independent Schools & Camp Venues)
**Morning Calls (9:00 AM – 10:30 AM):**
1. **San Francisco Day School (`350 Masonic Ave`)** — Call **Nicole Lane** (Director of Afterschool Programs / AEP) at **`(415) 931-2422`** (`nlane@sfday.org`)  
   *Pitch:* 10-minute demo for SF Day's Afterschool Enrichment Program (AEP).
2. **The International School of SF (`150 Oak St`)** — Call **Sean Donaldson** (Extended Care & Vacation Camps Dir.) at **`(415) 558-2000`** (`seand@internationalsf.org`)  
   *Pitch:* Thanksgiving/Winter Vacation Camp 2-hour guest block (`$600–$960`) + Spring After-School Lab.
3. **AcroSports SF (`639 Frederick St`)** — Call **`(415) 665-2276`** (`info@acrosports.org`)  
   *Pitch:* Adding a 90-minute afternoon Drone Academy rotation to their Nov 11 / Nov 23–25 Holiday AcroCamps + Birthday Party upgrades.

**Afternoon Walk-Ins (1:30 PM – 3:30 PM — Hayes Valley / Cole Valley Route):**
- **Stop 1:** **The International School of SF (`150 Oak St`)** & **San Francisco Schoolhouse (`735 Fell St` — Ask for Patrick Ardinger)**
- **Stop 2:** **AcroSports (`639 Frederick St`)** & **Circus Center (`755 Frederick St` — 1 block apart!)**

---

### DAY 4: LAUREL HEIGHTS, PAC HEIGHTS & INNER RICHMOND (Large Youth Hubs)
**Morning Calls (9:00 AM – 10:30 AM):**
1. **JCCSF (`3200 California St`)** — Call **Mitch Sanchez** (Camp Mgr) & **Bryan Wells** (Youth & Family Dir.) at **`(415) 292-1200`** (`msanchez@jccsf.org`, `bwells@jccsf.org`)  
   *Pitch:* `$960` Half-Day Guest Block for JCCSF's **Nov 11 Veterans Day** & **Nov 23–25 Vacation Days** + Spring After-School classes.
2. **Celsius and Beyond (`Inner Richmond`)** — Call **`(415) 221-6161`** (`hello@celsiusandbeyond.com`)  
   *Pitch:* `$600` 2-Hour Guest STEM Block for their November Holiday Science Camps.
3. **CYC STEAM Maker Lab (`980 Clement St`)** — Call **`(415) 775-2636`** (`cyc@cycsf.org`)  
   *Pitch:* 4-Station Drone Repair & Flight workshop series for their Richmond STEAM Maker Lab youth.

**Afternoon Walk-Ins (1:30 PM – 3:30 PM — California / Clement Route):**
- **Stop 1:** **JCCSF (`3200 California St`)** & **Presidio Hill School (`3839 Washington St` — Ask for Eli Barragan, `415-213-8630`)**
- **Stop 2:** **Town School for Boys (`2750 Jackson St`)** & **CYC STEAM Maker Lab (`980 Clement St`)**

---

### DAY 5: CITYWIDE YOUTH CLUBS, REC CENTERS & HOLIDAY CAMPS
**Morning Calls (9:00 AM – 10:30 AM):**
1. **Steve & Kate's Camp SF (`58 West Portal Ave`)** — Call **`(415) 523-2204`** (`sf.trips@steveandkate.com`)  
   *Pitch:* Booking Osito Drone Academy as an afternoon "Special Guest" activity for Thanksgiving Break (`Nov 23–25`) and Summer.
2. **Boys & Girls Clubs of SF (`380 Fulton St` Don Fisher & `163 London St` Excelsior)** — Call **Antonio "Tone" Moreno** at **`(415) 221-6100`** (`amoreno@kidsclub.org`)  
   *Pitch:* Running the 4-Station Drone Academy inside their clubhouse gymnasium.
3. **The Brandeis School of SF (`655 Brotherhood Way`)** — Call **Mirza Kopelman** (Dir. of Auxiliary & Camps) at **`(415) 406-1035`** (`mkopelman@sfbrandeis.org`)  
   *Pitch:* 10-minute demo for Brandeis Extended Learning & Summer Camp.

**Afternoon Walk-Ins (1:30 PM – 3:30 PM):**
- **Stop 1:** **Boys & Girls Club Don Fisher Clubhouse (`380 Fulton St`)** & **SF Rec & Parks Permits Desk (`501 Stanyan St` — Pre-file COI for Rec Center Birthday Parties)**
- **Stop 2:** **SPARK Social SF (`601 Mission Bay Blvd N`)** — Pitch hosting weekend Kids Drone Birthday Parties & Pop-Up Flight Labs in their pavilion/turf space.
