# Osito Drone Services: November 2026 "Fast-Cash" Break Camps & Direct-to-Parent Pop-Up Playbook
**Prepared Date:** October 29, 2026  
**Leadership Team:** Miguel Flores (CEO) & Jesus Aceves (CTO) | Alan Musselman  
**Target Goal:** Close at least **1 to 4 paid jobs in the next 13–26 days (November 2026)** generating **`$600–$3,000+` in immediate short-cycle cash** without waiting on slow semester-long school procurement.

---

## 📅 Verified November 2026 SFUSD & SF Independent School Holiday Windows
According to the verified **2026–2027 SFUSD Academic Calendar** and SF Independent School calendars:
1. **Wednesday, November 11, 2026 — Veterans Day Holiday** *(All SFUSD & most independent schools CLOSED — 13 days from today!)*
2. **Saturday, November 14, 2026 — Weekend Pop-Up Window #1** *(Direct-to-Parent Ticketed Flight Lab)*
3. **Saturday, November 21, 2026 — Weekend Pop-Up Window #2** *(Pre-Thanksgiving Direct-to-Parent Ticketed Flight Lab)*
4. **Monday–Wednesday, November 23–25, 2026 — Fall Recess / Thanksgiving Break Camps** *(SFUSD closed all week Nov 23–27; SF day camps run high-enrollment Mon–Wed mini-camps before Thursday Thanksgiving)*

---

## 🚀 TRACK 1: The "Emergency Guest Module" Pitch for Nov 11 (Veterans Day) & Nov 23–25 (Thanksgiving Break) Camps
**Why This Closes in 48 Hours:** SF day camps (STEMful, JCCSF, AcroSports, Celsius and Beyond, etc.) are **already collecting `$115–$165/day` per child** from parents for Wednesday, Nov 11 and Mon–Wed, Nov 23–25. Right now (Oct 29–Nov 2), Camp Directors are scrambling to finalize special activities and fill staff ratios. Offering a **turnkey 2-Hour or Half-Day "Micro-Drone Flight & Soldering Guest Block"** for a flat **`$600` (2-hour block)** or **`$960` (half-day / two back-to-back rotations)** where Osito brings **100% of the drones, batteries, safety nets, and 3 bilingual engineering instructors** is an easy "Yes" on a camp director's credit card.

### Top 8 SF Break-Camp Operators (Call & Email Tomorrow Morning — Oct 30)

| # | Organization & Neighborhood | November 2026 Camp Status | Phone Number | Direct Email / Contact | Best Pitch Angle |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | **STEMful SF**<br>*(30 29th St, Bernal Heights / Mission)* | Runs School Holiday Day Camps on **Nov 11** & **Nov 23–25** (`9am–4pm`) | **(415) 660-5975** | `info@stemful-sf.com`<br>`afterschool@stemful-sf.com` | **#1 Highest Probability:** They specialize in hands-on STEAM for ages 5–10; pitch a 2-hr upper-elementary (ages 8–10) Micro-Drone Physics & Flight Lab or a Saturday 70/30 revenue-share workshop. |
| **2** | **Celsius and Beyond**<br>*(Inner Richmond / SF Science Camps)* | Runs Nov 11 Veterans Day & Nov 23–25 Thanksgiving Science Camps | **(415) 221-6161** | `hello@celsiusandbeyond.com` | Rigorous science camp clientele; pitch Jesus Aceves's **PID Flight Controller & Aerodynamics Lab** as a guest engineering block. |
| **3** | **Tinkering School**<br>*(Mission / Dogpatch Maker Camp)* | Runs Maker & Tool-Building Break Camps & Weekend Sessions | **(415) 562-6268** | `info@tinkeringschool.com` | They love real tools and hardware; pitch the **Hands-On Drone Soldering, Motor Wiring & Maiden Flight Lab**. |
| **4** | **JCCSF (Jewish Community Center of SF)**<br>*(3200 California St, Presidio Heights)* | Runs "Vacation Days" on **Nov 11** & **Nov 23–25** for Grades K–8 | **(415) 292-1200** | `camp@jccsf.org`<br>`support@jccsf.org` | High headcount (40–80+ kids) with big enrichment budgets; pitch two back-to-back 90-minute rotations (`$960` total) for Grades 3–8. |
| **5** | **AcroSports SF**<br>*(639 Frederick St, Cole Valley / Haight)* | Runs Full-Day **AcroCamps** during SFUSD school holidays | **(415) 665-2276** | `info@acrosports.org` | Kids get exhausted from 6 hours of tumbling; camp directors love a 90-min afternoon "STEM Flight Obstacle Course" rotation in the gym. |
| **6** | **Mission Science Workshop**<br>*(3750 18th St, Mission & 4458 Mission St, Excelsior)* | Bilingual hands-on community science centers open during school breaks | **(415) 621-1240** *(Mission)*<br>**(415) 594-9165** *(Excelsior)* | `paul@missionscienceworkshop.org`<br>`sonia@missionscienceworkshop.org` | **Bilingual Mission/Excelsior Alignment:** Miguel & Jesus can deliver in English & Spanish; pitch a grant-funded/stipend holiday workshop. |
| **7** | **Steve & Kate's Camp (SF Field Trips & Partner Sites)**<br>*(58 West Portal Ave / Mission Dolores / Sunset)* | Flexible holiday/break programming & special guest pop-ups | **(415) 523-2204** *(Lombard)*<br>**(415) 787-7916** *(Christopher Park)* | `sf.trips@steveandkate.com`<br>`sk.trips@steveandkate.com` | Steve & Kate's regularly books "Special Guest" afternoon pop-up vendors on site so kids can choose the drone station. |
| **8** | **YMCA of San Francisco (Stonestown, Embarcadero, Presidio & Mission Branches)** | Runs SFUSD Holiday Break Camps on **Nov 11** & **Nov 23–25** | **(415) 665-4100** *(Pomeroy)*<br>Branch lines via `ymcasf.org` | `memberservices@ymcasf.org` | Call branch Youth & Teen Directors directly; offer a **`$600` Veterans Day or Thanksgiving Monday 2-hour mobile drone obstacle course**. |

---

### 📧 Copy-Paste Email Script for Camp Directors (Send Tonight / Friday Morning)

**Subject:** Nov 11 (Veterans Day) or Nov 23–25 Camp — Turnkey 2-Hr Micro-Drone Flight Lab Guest Block?

Hi **[Camp Director Name / Team]**,

With SFUSD closed on **Wednesday, Nov 11 (Veterans Day)** and **Mon–Wed, Nov 23–25 (Thanksgiving Break)**, I'm reaching out to see if you have a 2-hour morning or afternoon block open for a high-energy **Special Guest STEM Activity** during your November break camps.

We run **Osito Drone Services**, a San Francisco-based mobile youth drone engineering team led by me (Miguel Flores) and our CTO, Jesus Aceves. We bring a 100% plug-and-play **"Indoor Micro-Drone Flight & Engineering Lab"** directly to your space so your staff gets a breather while your campers get an unforgettable hands-on aerospace experience:

* **100% Turnkey & Indoor-Safe:** We bring 10–15 fully ducted, palm-sized indoor training drones (zero exposed propellers), spare batteries, pop-up LED obstacle gates, and soldering/circuit demo stations.
* **3 Instructors On-Site:** Myself, Jesus, and Alan handle 100% of the instruction, safety briefing, and flight line management (2:1 student-to-drone ratio).
* **Dates Available:** **Wednesday, Nov 11** (Veterans Day) OR **Mon/Tue/Wed, Nov 23, 24, or 25** (Thanksgiving Break).
* **Simple Flat Rate:** **`$600`** for a single 2-hour workshop rotation (up to 20 campers), or **`$960`** for a half-day (two back-to-back rotations for up to 40 campers).

Would you like us to hold a slot on **Nov 11** or **Nov 23–25**? You can reply here or call/text me directly at **415-571-6614 (Miguel Flores, CEO) / 415-810-4158 (Alan Musselman, COO)** and we can lock it in today.

Best regards,

**Miguel Flores, CEO & Jesus Aceves, CTO**  
Osito Drone Services — San Francisco Youth Aerospace & Robotics  
**415-571-6614 (Miguel) / 415-810-4158 (Alan)** | **miguel@ositodrone.com | alan@ositodrone.com | www.ositodrone.com**

---

### 📞 30-Second Phone Script (Call Friday Between 9:30 AM and 11:30 AM)

> *"Hi! Could I speak with the Camp Director or whoever coordinates guest activities for your November 11 Veterans Day and Thanksgiving Break camps?"*  
> *(When connected)*:  
> *"Hi [Name], my name is Miguel with Osito Drone Services here in SF. I know you guys are gearing up for the November 11 Veterans Day camp in less than two weeks and the November 23rd Thanksgiving camp. We have 3 drone engineering instructors and 15 indoor-safe ducted micro-drones available on Nov 11 and Nov 23–25, and we're offering a plug-and-play 2-hour Indoor Drone Obstacle Course & Engineering Guest Block for a flat `$600`—we bring all the gear, batteries, and instructors so your counselors get an easy afternoon break and the kids get to fly real drones through LED gates. Do you still have an activity slot open on Wednesday Nov 11 or Monday Nov 23?"*

---

## 🎯 TRACK 2: Direct-to-Parent "Saturday Ticketed Pop-Up Flight Academy" (Nov 14 & Nov 21, 2026)
**Why This Guarantees a Paid Job in November:** You do **NOT** need a school principal's permission to teach kids in San Francisco. By booking a `$0–$150` community room for **Saturday, Nov 14 (10:00 AM – 12:00 PM)** and **Saturday, Nov 21 (10:00 AM – 12:00 PM)** and selling **12 Parent-Child Team Tickets at `$85/ticket`** on Eventbrite or Luma (`lu.ma`), you generate **`$1,020` per 2-hour session** (even **6 tickets sold = `$510` in your Stripe account this week!**).

### Unit Economics of One 2-Hour Saturday Pop-Up (12 Kids + Parents)
* **Gross Ticket Revenue:** 12 tickets × `$85` = **`$1,020.00`**
* **Venue Cost:** **`$0 – $150.00`** *(Free at Sports Basement Community Space or Noisebridge; or 70/30 split at STEMful)*
* **Equipment / Battery Wear Reserve:** **`$40.00`** *(Using existing fleet in Pilot + Spotter pairs = only 6–8 micro-drones needed in the air at once)*
* **Eventbrite / Luma / Stripe Processing (~3.5%):** **`$35.70`**
* **Net Cash Profit for 2 Hours of Work:** **`$794.30 – $944.30` per Saturday** *(or `$1,588 – $1,888` across both Nov 14 & Nov 21)*

### 4 Instant-Book SF Venues (`$0–$150` Upfront Cost)

| Venue Name & Address | Cost to Book | Capacity & Setup | Exact Booking Contact (Action Tonight) |
| :--- | :--- | :--- | :--- |
| **1. Sports Basement — Bryant St ("The Treeline" Room)**<br>`1590 Bryant St, San Francisco, CA 94103` | **`$0` (FREE)** | 1,750 sq. ft. indoor community room, tables/chairs, easy parent parking, high ceiling for micro-drones. | **Book Online Tonight:** Go to `shop.sportsbasement.com` → Community Spaces → SF Bryant ("The Treeline") AND call **(415) 575-3001** / email `friends@sportsbasement.com` to confirm **Sat Nov 14 or Sat Nov 21 (10am–12:30pm)**. *(Bonus: Parents love shopping at Sports Basement while or after their kids fly!)* |
| **2. Sports Basement — Presidio ("The Sign Room" or "The Dairy")**<br>`610 Old Mason St, San Francisco, CA 94129` | **`$0` (FREE)** | *The Sign Room* holds ~30 people; *The Dairy* holds up to 300. Right at Crissy Field. | **Book Online Tonight:** `shop.sportsbasement.com` → Community Spaces → SF Presidio or email `friends@sportsbasement.com`. High-income Marina/Presidio/Pac Heights parent demographic. |
| **3. STEMful SF (Revenue-Share Partner Venue)**<br>`30 29th St, San Francisco, CA 94110` | **`$0` upfront** *(Pitch 70/30 ticket split)* | Dedicated kid-friendly STEAM studio in Bernal/Mission with built-in mailing list of 2,000+ SF parents. | Call **(415) 660-5975** & email `info@stemful-sf.com`: *"Let's co-host a Saturday Nov 14 or Nov 21 'Parent & Kid Drone Flight Lab' at your 29th St studio—`$85/ticket`, you keep 30% (`$306`) just for providing the room and blasting your parent newsletter, we bring all drones and instructors."* |
| **4. SPARK Social SF (Covered Pavilion / Tent) or Noisebridge**<br>`601 Mission Bay Blvd N` / `272 Capp St` | **`$0–$150`** | SPARK Social has huge weekend Mission Bay family foot traffic; Noisebridge (`272 Capp St`) has full electronics/soldering benches. | SPARK Social: `info@sparksocialsf.com` (`visitsparksocial.com`).<br>Noisebridge: `secretary@noisebridge.net` / `treasurer@noisebridge.net` (donation-based community workshop space). |

---

### 🎟️ Copy-Paste Eventbrite / Luma (`lu.ma`) Event Listing (Create Live Page in 15 Minutes Tonight)

**Event Title:**  
🚁 **SF Youth Drone Flight & Engineering Pop-Up Lab (Ages 8–14 + Parent Optional!)**

**Dates & Times (Create 2 Dates):**  
* **Session 1:** Saturday, November 14, 2026 | 10:00 AM – 12:00 PM PST  
* **Session 2:** Saturday, November 21, 2026 | 10:00 AM – 12:00 PM PST  

**Location:**  
Sports Basement Bryant Street — Community Space (*1590 Bryant St, San Francisco, CA 94103*) — *Free Indoor Parking!*

**Ticket Price:**  
* **Early Bird Student Pilot Pass (First 6 Tickets):** `$75`  
* **Standard Student Pilot Pass (Includes all drone gear + parent spectator/co-pilot):** `$85`  
* **Sibling Duo Pass (2 Kids):** `$150`  
*(Strictly capped at 12 students so every child gets maximum flight time!)*

**Event Description (Copy-Paste):**
> **Skip the screen time this Saturday—come build, test, and pilot real indoor micro-drones through a glowing LED obstacle course!**
>
> Hosted by **Osito Drone Services** (Miguel Flores, CEO & Jesus Aceves, CTO), this hands-on **2-Hour Youth Aerospace & Drone Flight Lab** gives San Francisco kids and teens (Grades 3–8 / Ages 8–14) the chance to learn real drone engineering and flight control in a 100% safe, indoor environment.
>
> **What Your Child Will Do in 120 Action-Packed Minutes:**
> 1. **Minutes 0–25 | Under the Hood (Hardware & Physics):** Meet our engineering team, inspect real brushless motors, flight controllers, and soldering joints, and learn how pitch, roll, yaw, and thrust keep a quadcopter stable.
> 2. **Minutes 25–60 | Flight School (Hover, Box Patterns & Precision Landing):** Paired in 2-person flight crews (Pilot + Spotter) with fully ducted, palm-sized indoor training drones, students master takeoff, altitude control, and bullseye landing pads.
> 3. **Minutes 60–105 | The Osito LED Obstacle Course Challenge:** Pilots navigate through pop-up air-gates, keyhole rings, and rescue zones against the clock!
> 4. **Minutes 105–120 | Autonomous Flight Demo & Pilot Wings Certificate:** Watch a live custom-built FPV/autonomous drone demo by CTO Jesus Aceves and graduate with an official Osito Junior Drone Pilot Certificate.
>
> **Everything Included:** We provide all drones, controllers, batteries, safety goggles, and 3 dedicated instructors on-site. Zero prior experience required! Parents are welcome to stay and co-pilot for free or grab coffee/shop downstairs.

---

### 📱 Copy-Paste Nextdoor / SF Parent Group / PTA Slack Post (Post Tonight & Tomorrow)
*Post this in: **Nextdoor (Noe Valley, Bernal Heights, Potrero Hill, Mission, Castro, Marina/Presidio)**, **Main Street Mamas SF Facebook Group**, **SF Parents Slack**, and your local school PTA WhatsApp groups.*

> **🚁 Calling SF Parents of Kids Ages 8–14: Hands-On Indoor Drone Flight & Engineering Pop-Up Lab (Sat Nov 14 & Sat Nov 21!)**
>
> Hi neighbors! My partners **Miguel Flores** and **Jesus Aceves** and I run **Osito Drone Services** right here in San Francisco. We teach youth how drones actually work—from soldering motors and flight controllers to piloting real quadcopters through indoor obstacle courses.
>
> Before the Thanksgiving holiday rush, we are hosting two small-group **2-Hour Youth Drone Flight & Engineering Labs** on **Saturday, Nov 14 (10am–12pm)** and **Saturday, Nov 21 (10am–12pm)** at **[Sports Basement Bryant St / Mission Community Space]**.
>
> * **Ages:** 8–14 (Grades 3–8) — no prior experience needed!
> * **What's Included:** 3 instructors, 100% indoor-safe ducted micro-drones, live hardware/soldering breakdown, and a timed LED obstacle course flight challenge.
> * **Group Size:** Strictly limited to **12 kids** so every student gets tons of stick-time.
> * **Tickets:** `$75` Early Bird (first 6 spots) / `$85` Regular (parents welcome to join as co-pilot for free!).
>
> **👉 Grab one of the 12 spots here:** **[Insert Luma / Eventbrite Link]**
>
> *(P.S. If you run a November 11 Veterans Day camp, Thanksgiving break camp, or want to book us for a private STEM birthday party or school club this month, DM me or text **415-571-6614 (Miguel) / 415-810-4158 (Alan)**—we still have Nov 11 and Nov 23–25 open!)*

---

## ⚡ 48-Hour Execution Checklist for Alan, Miguel & Jesus (Oct 29 – Oct 31)

- [ ] **Tonight (Oct 29, 30 mins):** Go to [Sports Basement Community Spaces](https://shop.sportsbasement.com/) and request **"The Treeline" room at 1590 Bryant St** (or Presidio "Sign Room") for **Saturday, Nov 14 (9:30 AM – 12:30 PM)** and **Saturday, Nov 21 (9:30 AM – 12:30 PM)**.
- [ ] **Tonight (Oct 29, 20 mins):** Set up a free **Luma (`lu.ma`)** or **Eventbrite** ticket page using the exact copy above (6 Early Bird tickets at `$75`, 6 Standard tickets at `$85`) connected to your bank/Stripe account so cash lands immediately upon booking.
- [ ] **Friday Morning (Oct 30, 9:00 AM – 11:30 AM):** Call & email all **8 SF Break-Camp Operators** in Track 1 (starting with **STEMful at 415-660-5975**, **Celsius and Beyond at 415-221-6161**, **Tinkering School at 415-562-6268**, and **JCCSF at 415-292-1200**) pitching the **`$600` Nov 11 Veterans Day / Nov 23–25 Thanksgiving Guest Block**.
- [ ] **Friday Evening (Oct 30, 5:00 PM):** Post the Luma/Eventbrite link in **Nextdoor** and **3 SF Parent Groups**. Even **1 break-camp booking (`$600–$960`) + 1 Saturday Pop-Up (`$510–$1,020`)** puts **`$1,110–$1,980` of real paid revenue on the books in November 2026**.
