# Osito Drone Services — San Francisco Sales & Outreach Playbook

**Contact Details Used in Templates:**
- **Company:** Osito Drone Services (`ositodrone.com`)
- **Leadership Team:**
  - **Miguel Flores** — CEO & Co-Founder (`miguel@ositodrone.com` | `415-571-6614`)
  - **Alan Musselman** — COO & Co-Founder (`alan@ositodrone.com` | `415-810-4158`)
  - **Jesus Aceves** — CTO & Co-Founder (`jesus@ositodrone.com` | `415-269-1206`)
- **General Inquiries:** `info@ositodrone.com` | `415-269-1206`
- **Core Differentiators:**
  1. **Classroom & Indoor Safety (`OSITO CUB-75` & `AcroBee`):** Ultra-lightweight (`28.8g–39.5g`) micro-drones with **360° full-height ducts, upper/lower finger-guard grilles, and slip-on TPU wall-bounce bumpers**—zero risk to small fingers, drywall, or gym floors. LiPo batteries stored in fireproof **Bat-Safe** enclosures.
  2. **True Engineering + Flight Curriculum:** Strict **1:4 trainer-to-student ratio** across 4 interactive stations (**Station 1: Soldering & Hardware Repair**, **Station 2: Drone Flight Simulators**, **Station 3: Netted Hover Pods**, **Station 4: FPV Goggles & Neon Obstacle Courses**) plus a 3-stage firmware progression (*Cub Mode → Scout Mode → Pilot Mode*).
  3. **Turnkey Events & `SHARD-75` Combat Arena:**
     - **Kids Birthday Parties ($200 / $400 packages):** 1-hour or 2-hour mobile packages for up to 8 pilots (ages 8+), plus optional $200 take-home drone kit.
     - **SHARD-75 Aerial Combat Arena:** Real mid-air dogfighting inside a **100% contained 101"×101" netted battle tent** using 38g carbon-polymer drones with **4-zone magnetic breakaway armor shards**, Betaflight Active Crash Recovery (<0.5s re-leveling), and a live digital scoreboard (3-minute heats, first to 10 points wins).

---

## 1. Email Templates by Segment

### Template A: Independent K-8 Schools (Extended Day & STEAM Directors)
**Target Leads:** `OS-004` through `OS-014` (Alta Vista School, SF Schoolhouse, Live Oak, Children's Day School, SF Day, Town School for Boys, Synergy, Brandeis, Presidio Hill, International School of SF)

**Subject Line Options:**
- `Hands-on Micro-Aviation & STEM Flight Lab for [School Name] Extended Day`
- `15-min tabletop demo? Kid-safe indoor drone engineering for [School Name]`

**Body:**
> Hi [First Name / Extended Day Team],
>
> I’m reaching out from **Osito Drone Services** here in San Francisco because [School Name]’s commitment to hands-on STEAM and maker education is a natural fit for our **Youth Micro-Aviation & Flight Academy**.
>
> Most school drone programs fail indoors because off-the-shelf toy drones have exposed top/bottom propellers, brittle frames that break on the first wall bounce, and 2-minute batteries. We engineered our **39.5-gram `OSITO CUB-75` classroom drone** in-house specifically for San Francisco classrooms and gyms:
> - **100% Finger-Safe & Wall-Safe:** Full 360° top-and-bottom propeller finger cages plus a soft TPU bumper belt that bounces off walls and furniture without leaving a mark.
> - **Dual Skillset (Flight + Hardware Bench Work):** With a strict **1:4 instructor ratio**, students rotate through **Flight Simulators**, **Netted Hover Pods**, **FPV Goggles**, and **Hardware Maintenance** (learning real soldering, motor swaps, and circuitry diagnostics: *"Fly, Crash, Build, Repeat"*).
> - **Progressive 3-Stage Firmware:** Beginners start in speed-capped *Cub Mode* (22° max tilt, auto-leveling) and graduate to *Scout* and *FPV Pilot Mode* through neon LED obstacle gates.
> - **Turnkey & Insured:** We bring all transmitters, goggles, drones, tools, and fireproof Bat-Safe battery enclosures.
>
> Are you currently finalizing enrichment vendors for the upcoming **After-School session or Summer/Break Camps**? I’d love to drop by [School Name] for a **10-minute tabletop hover demo** so you can hold the `CUB-75` and test the finger-guards firsthand.
>
> Best regards,
>
> **Alan Musselman**  
> Osito Drone Services  
> 📞 415-269-1206 | ✉️ info@ositodrone.com | 🌐 ositodrone.com

---

### Template B: Youth Makerspaces & Community STEM Hubs
**Target Leads:** `OS-001` (STEMful), `OS-002` (Mission Science Workshop), `OS-003` (Tinkering School), `OS-015` (CYC STEAM Maker Lab), `OS-016` (SF STEM Academy), `OS-017` (JCCSF), `OS-018` (YMCA SF), `OS-019` (Boys & Girls Clubs SF)

**Subject Line Options:**
- `Partnership idea: "Fly, Crash, Build, Repeat" Youth Drone Workshop at [Organization Name]`
- `3D-Printed Micro-Drone & FPV STEM Module for [Organization Name]`

**Body:**
> Hi [First Name],
>
> I’m a big fan of the hands-on maker programming at **[Organization Name]**. I run **Osito Drone Services** here in SF, and I’m reaching out to explore co-hosting a **Weekend Micro-Drone Build & Flight Workshop** or adding an aviation module to your upcoming camp schedule.
>
> What makes our curriculum unique is that we don't treat drones as black-box toys—we treat them as an accessible entry point into aeronautical engineering and electronics:
> 1. **In-House 3D-Printed Modular Airframes (`CUB-75`):** Students see how CAD and 3D printing (PETG-CF & TPU 95A) solve real mechanical problems like impact absorption and finger protection.
> 2. **Station 1 — Repair & Soldering Lab:** Students learn real soldering, frame swaps, and multimeter diagnostics so a crash becomes an engineering puzzle rather than the end of class.
> 3. **Station 2–4 — Simulator to FPV Goggles:** Students progress from laptop flight simulators to netted hover pods, and finally strap on First-Person View (FPV) goggles to navigate indoor obstacle courses.
>
> We provide a **1:4 instructor ratio** and bring all gear, soldering stations, netted enclosures, and safety equipment. 
>
> Would you be open to a quick 10-minute call this week to see how a single-day workshop or multi-week cohort could work at your [Neighborhood, e.g., Mission / Richmond / Presidio] space?
>
> Warm regards,
>
> **Alan Musselman**  
> Osito Drone Services  
> 📞 415-269-1206 | ✉️ info@ositodrone.com | 🌐 ositodrone.com

---

### Template C: Kids Birthday Venues & Family Recreation Partners
**Target Leads:** `OS-020` (House of Air), `OS-021` (AcroSports), `OS-022` (Circus Center), `OS-023` (SPARK Social SF), `OS-024` (SF Rec & Park)

**Subject Line Options:**
- `New VIP Birthday Party Add-On for [Venue Name]: Contained FPV Drone Racing & Battles`
- `Partnership inquiry: Turnkey Kids Drone Party packages at [Venue Name]`

**Body:**
> Hi [First Name / Events Team],
>
> Parents in San Francisco are always looking for the next high-energy, screen-free (or rather, *real-world* tech) birthday experience for kids ages 8–14. 
>
> At **Osito Drone Services**, we run turnkey **FPV Micro-Drone Racing & Aerial Combat Birthday Events**, and we’re looking for 2–3 premier SF venue partners where we can cross-refer clients or offer our setup as a high-margin VIP party add-on.
>
> **How it works in your space (Zero facility risk):**
> - **100% Net-Contained or Prop-Guarded:** We can either run our featherweight (`28.8g`) ducted AcroBee/`CUB-75` trainers through soft neon gates, OR pop up our **101"×101" fully netted `SHARD-75` Aerial Combat Tent**—meaning drones never leave the netted cube.
> - **From Rookie to Cockpit Pilot:** Our flight coaches handle 100% of setup and coaching. Kids master hovering, put on real First-Person View (FPV) goggles, and race or battle magnetic breakaway-armor drones in 3-minute heats.
> - **Simple Revenue Share / Partner Pricing:** Our standard 60-minute ($200) and 2-hour ($400) packages (for up to 8 pilots) can be bundled directly into your party tiers with a partner commission, or we can rent floor/turf time directly for our incoming SF parent bookings.
>
> Could I stop by [Venue Name] for 10 minutes next week to show you our micro-drones and discuss how a partnership could drive extra party bookings for your team?
>
> Best,
>
> **Alan Musselman**  
> Osito Drone Services  
> 📞 415-269-1206 | ✉️ info@ositodrone.com | 🌐 ositodrone.com

---

### Template D: Corporate Team-Building Agencies & Experiential Tech Venues (`SHARD-75` Combat Arena)
**Target Leads:** `OS-025` (The Midway SF), `OS-026` (SPIN SF), `OS-027` (Emporium SF), `OS-028` (Venture Up), `OS-029` (Fort Mason), `OS-030` (Noisebridge)

**Subject Line Options:**
- `Interactive Tech Entertainment for [Venue/Agency Name]: The SHARD-75 Drone Combat Arena`
- `New 9x9 ft corporate team-building activation: Real mid-air drone dogfighting`

**Body:**
> Hi [First Name / Events Team],
>
> When San Francisco tech teams book an offsite or happy hour at **[Venue/Agency Name]**, they want an interactive experience they haven't seen at every other corporate mixer.
>
> We built the **OSITO `SHARD-75` Aerial Combat Arena** right here in SF specifically for indoor venues, tech offsites, and gamified tournaments:
> - **Real Mid-Air Dogfighting with Magnetic Breakaway Armor:** Two pilots go head-to-head in **3-minute heats** flying custom 38-gram carbon-polymer micro-drones equipped with **4 magnetic breakaway armor shards** (Top Crown = 2 pts, Cheek Shields = 1 pt, Belly Skid = 1 pt, 5-Second Takedown = 3 pts).
> - **Smash Armor, Keep Flying:** Unlike consumer drones that drop dead on contact, our Betaflight Active Crash Recovery re-levels the drone in under **0.5 seconds** after mid-air collisions so the dogfight keeps going.
> - **Tiny Footprint, 100% Contained Safety:** The entire arena runs inside a **101"×101" (8.5 ft × 8.5 ft) heavy-duty netted battle tent** with a live digital scoreboard display. Spectators can watch right against the net with drink in hand—zero danger to guests or venue decor.
> - **Beginner-Friendly Controls:** Any guest can fly Line-of-Sight from outside the tent using bright team LEDs on their very first try, while experienced gamers can strap on FPV goggles.
>
> We’d love to be on your preferred interactive entertainment roster for corporate buyouts and team-building tournaments. Do you have 15 minutes this week for a quick call or a live demo at your space?
>
> Best regards,
>
> **Alan Musselman**  
> Osito Drone Services  
> 📞 415-269-1206 | ✉️ info@ositodrone.com | 🌐 ositodrone.com

---

## 2. Phone Call & Voicemail Script (Schools & Venues)

### Gatekeeper / Direct Call Opener (30 Seconds)
> *"Hi [Name], this is Alan Musselman with Osito Drone Services here in San Francisco. I'm calling because we run a hands-on indoor Youth Drone STEM Academy [or: a 100% net-contained Drone Combat & Racing Arena for birthdays and corporate events], and I wanted to find out who coordinates your upcoming [after-school enrichment / private event packages]?"*
>
> *(When connected to the decision-maker):*  
> *"Hi [Name], I'll keep this brief! We design and 3D-print ultra-lightweight, 39-gram indoor training drones with full top-and-bottom finger guards and soft TPU wall bumpers right here in SF. We pair them with a 1:4 instructor ratio teaching kids both flight control and real electronics soldering. I’m in the [Mission / Presidio / Cole Valley] area this week—could I swing by for 5 minutes to show you the safety cage in person and leave a one-pager?"*

### 25-Second Voicemail Script
> *"Hi [Name], this is Alan with Osito Drone Services in San Francisco—415-269-1206. We run turnkey indoor Youth Drone STEM labs and birthday events using custom 39-gram finger-safe micro-drones and a 4-station engineering curriculum. I just sent a quick note to your inbox about bringing a 10-minute tabletop demo to [Organization Name]. Again, my number is 415-269-1206, or info@ositodrone.com. Talk soon!"*

---

## 3. Fast Objection-Handling Cheat Sheet

| Common Question / Objection | Osito's Concrete Engineering Answer |
| :--- | :--- |
| **"Are drones safe around kids' fingers or indoor classrooms?"** | "Standard toy drones only guard the sides of the props. Our custom 39.5g `CUB-75` has a 10mm tall 360° duct PLUS 3 upper arched finger-guard ribs and 4 bottom struts enclosing the blades completely, plus a soft TPU 95A bumper belt that bounces off walls without leaving marks." |
| **"What if kids lose control and fly it across the room?"** | "Two layers of protection: First, beginners start in netted Hover Pods or our 101"×101" netted tent. Second, our `Cub Mode` firmware caps motor power at 68%, limits tilt to 22°, and enables instant auto-leveling + an instructor master kill switch." |
| **"What about LiPo battery safety indoors?"** | "We use tiny 1-cell (`1S 550mAh`, 13.8g) micro-batteries protected inside shock-absorbing TPU sleeves, and all charging/storage on-site is done inside certified fireproof **Bat-Safe** steel enclosures." |
| **"How much space do you need?"** | "For the `SHARD-75` Combat Arena or Hover Station, just a **9 ft × 9 ft** floor footprint (101"×101" tent). For a full 4-station STEM lab, a standard classroom, multipurpose room, or half-gym works great." |

---

## 4. Recommended 2-Week Outreach Cadence

1. **Day 1 (Tue/Wed Morning):** Send personalized Email (Template A/B/C/D) + attach `flyer final.jpg` (for STEM) or `birthday osito drone events.pdf` / `OSITO_SHARD75_Event_Handout.html` (for Events).
2. **Day 3 (Thu/Fri Afternoon):** Call the 415 phone number in `Osito_SF_Sales_Leads_Tracker.csv`. Ask to drop off a printed flyer and show the `CUB-75` / `SHARD-75` airframe in person (bringing the physical 3D-printed drone converts schools and event planners immediately).
3. **Day 8 (Following Week):** Send a 3-sentence follow-up email offering a **free 30-minute pilot demo session** for their staff or a **Back-to-School / Family STEM Night booth** at no cost in exchange for distributing flyers to parents.
