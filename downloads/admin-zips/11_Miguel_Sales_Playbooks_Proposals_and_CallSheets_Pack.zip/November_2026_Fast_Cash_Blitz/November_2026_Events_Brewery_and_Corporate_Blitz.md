# November 2026 Immediate Cash-Flow Blitz: Brewery Pop-Ups, Q4 Corporate Friendsgiving/Holiday Offsites & 48-Hour Birthday Closer

**Prepared For:** Alan Musselman, COO — Osito Drone Services  
**Execution Date:** October 29, 2026 (Target Window: November 1 – November 30, 2026)  
**Hardware Asset Ready to Deploy:** `101" × 101" × 87"` (`8.4 ft × 8.4 ft`) 100% Net-Enclosed `SHARD-75` FPV Aerial Combat & Tag Arena + Dual FPV Goggles + Live External Spectator Screen  

---

## Executive Revenue Math: How We Guarantee Paid Jobs in November 2026

Waiting on school district POs or municipal summer camp contracts won't put cash in the bank next week. To guarantee **immediate paid revenue in November 2026**, Osito Drone Services is executing a **3-Play November Cash Blitz** starting tomorrow morning (Friday, Oct 30):

1. **Play 1: The "Zero-Cost Brewery Pop-Up Night" (`$120/hr` Instant Venmo/Square Cash + Live Corporate Lead Magnet)**
   - Pitch SF's largest indoor/patio breweries to set up our `8.4' × 8.4'` `SHARD-75` enclosed cage on a **Thursday, Friday, or Saturday in November** at **$0 cost to the brewery**.
   - **On-the-Spot Cash Model:** Taproom patrons pay **`$15 per pilot` (`$30 per 1v1 heat`)** via QR code (Venmo/Square) for a **3-Minute 1v1 Drone Dogfight Heat** with live HDMI spectator video. At 4 heats/hour, a single 4-hour Friday/Saturday pop-up generates **`$480` in instant cash**.
   - **The Hidden Jackpot:** SF taprooms in SoMa, Mission, Dogpatch, and Mission Bay are packed with engineering managers and startup founders every Thursday/Friday. One QR scan on our A-frame sign (*"Book This Cage for Your Team's November Friendsgiving or December Holiday Party — $1,800 Flat"*) turns a free pop-up into a **`$1,800` corporate booking**.
2. **Play 2: Q4 Tech "Use-It-Or-Lose-It Budget" Friendsgiving & Holiday Party Blitz (`$1,200 – $1,800` per 2–3 Hr Event)**
   - Corporate L&D, Engineering Culture, and Team Morale budgets **expire on December 31, 2026**. In November, SF Office Managers, Executive Assistants, and Event Venues (`Thriller Social Club`, `Emporium SF`, `SPIN SF`, `The Midway`) are scrambling for interactive, non-cringe entertainment for **November "Work Friendsgivings"** and **early December Holiday Parties**.
3. **Play 3: 48-Hour SF Birthday Party Lead Capture (`$299` November Launch Special — Normally `$400`)**
   - November weather in SF turns cold, dark by 5:00 PM, and rainy—killing outdoor park birthday parties. Parents are actively searching **Thumbtack, GigSalad, Yelp Request-a-Quote, Nextdoor SF, and Main Street Mamas** *this week* for indoor birthday entertainment that fits in a garage, living room, or rec room.

---

## PLAY 1: The "Pay-Per-Battle Brewery Pop-Up" (`$30/Heat` Instant Cash + Corporate Magnet)

> [!WARNING]
> **Dead-Lead Alert (Verified Oct 29, 2026):** Do **NOT** waste time contacting **Sunset Reservoir Brewing Co.** (`1735 Noriega St`) or **Olfactory Brewing** (`2245 3rd St`) — both SF taprooms have **permanently closed**. Focus 100% of your outreach on the **8 verified, high-traffic SF breweries and social hubs** below.

### Verified Dossier: Top 8 SF Breweries & Social Hubs (Open & Booking November 2026)

| # | Venue Name | Neighborhood & Address | Verified Phone & Direct Emails | Why the `8.4' × 8.4'` `SHARD-75` Cage Fits & Best Pop-Up Night |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Barebottle Brewing Co.** | **Bernal Heights / Mission**<br>`1525 Cortland Ave, San Francisco, CA 94110` | **Phone:** `(415) 926-8617`<br>**Events Email:** `events@barebottle.com`<br>**Sales Email:** `sales@barebottle.com` | Massive warehouse taproom packed with Bernal Heights families (4–7 PM) and tech workers (6–10 PM). Already hosts Trivia Tuesdays and rotating food pop-ups. **Pitch:** Friday Afternoon/Evening (4–9 PM) or Saturday Family Day (1–6 PM). |
| **2** | **Harmonic Brewing (Thrive City)** | **Mission Bay / Chase Center**<br>`7 Warriors Way, San Francisco, CA 94158` | **Phone:** `(415) 966-7128`<br>**Email:** `info@harmonicbrewing.com`<br>**Portal:** `harmonicbrewing.com/book-an-event` | Located right at Chase Center's Thrive City plaza; hosts 20–300 person groups and pre-game crowds. Huge indoor/outdoor footprint ideal for an `8.4' × 8.4'` enclosed cage before Warriors games or Friday happy hours. |
| **3** | **Standard Deviant Brewing (Mission & Pier 70)** | **Mission:** `280 14th St, SF, CA 94103`<br>**Dogpatch / Pier 70:** `1070 Maryland St, Suite 195, SF, CA 94107` | **Phones:** `(415) 690-2337` / `(415) 590-2550`<br>**Email:** `Info@standarddeviantbrewing.com` | Two prime locations! The `280 14th St` Mission taproom runs Thu–Sun pop-ups with heavy foot traffic; the brand-new `Pier 70` shipyard taproom has massive industrial square footage. |
| **4** | **Southern Pacific Brewing** | **Mission District**<br>`620 Treat Ave, San Francisco, CA 94110` | **Phone:** `(415) 341-0152`<br>**Direct Contact:** `jake@southernpacificbrewing.com`<br>**Web:** `southernpacificbrewing.com` | Sprawling **10,000 sq. ft.** industrial warehouse with The Alley (150 cap) and Mezzanine (75 cap). Heavily booked by SF tech teams on Thursdays and Fridays. |
| **5** | **Enterprise Brewing Co.** | **SoMa**<br>`1150 Howard St, San Francisco, CA 94103` | **Phone:** `(415) 212-8311`<br>**Events Email:** `events@enterprisebeer.com`<br>**General/Sales:** `hello@enterprisebeer.com` / `Jesse@enterprisebeer.com` | Right in the heart of SoMa (`1150 Howard St`). High concentration of tech startups and after-work happy hours looking for interactive taproom entertainment. |
| **6** | **Laughing Monk Brewing** | **Bayview**<br>`1439 Egbert Ave, Unit A, San Francisco, CA 94124` | **Phone:** `(415) 678-5157`<br>**Email:** `info@laughingmonkbrewing.com`<br>**Web:** `laughingmonkbrewing.com` | Community-oriented warehouse taproom that actively books weekend pop-ups, trivia, and local makers. Great low-barrier venue to lock in your **first Friday/Saturday November test night**. |
| **7** | **SPARK Social SF** | **Mission Bay**<br>`601 Mission Bay Blvd North, San Francisco, CA 94158` | **Emails:** `info@sparksocialsf.com` / `info@sparkmissionbay.com`<br>**Web:** `visitsparksocial.com` (Vendor & Event Portal) | SF's #1 outdoor food truck park, beer garden, and corporate fire-pit hangout in Mission Bay (surrounded by UCSF, Uber, OpenAI, and biotech HQ campuses). High family & corporate foot traffic 7 days a week. |
| **8** | **Fort Point Beer Co. (Valencia Beer Hall & Ferry Building)** | **Mission:** `742 Valencia St, SF, CA 94110`<br>**Embarcadero:** `One Ferry Building, #54, SF, CA 94111` | **Valencia Phone:** `(415) 361-7001`<br>**Support/Events:** `(415) 917-7647`<br>**Emails:** `shop@fortpointbeer.com` / `press@fortpointbeer.com` | High-visibility flagship SF beer brand; great for pitching a branded corporate holiday add-on for private buyouts at their Valencia Beer Hall. |

---

### Copy-Paste Email Pitch to Brewery Event Managers (Send Friday Morning, Oct 30)

**To:** `events@barebottle.com`, `info@harmonicbrewing.com`, `Info@standarddeviantbrewing.com`, `jake@southernpacificbrewing.com`, `events@enterprisebeer.com`, `info@laughingmonkbrewing.com`, `info@sparksocialsf.com`  
**Subject:** Zero-cost November Pop-Up for `[Venue Name]`: Enclosed 1v1 FPV Drone Dogfight Cage (8x8 ft footprint)

> Hi `[Venue Name]` Events Team,
>
> I’m Alan Musselman, COO of **Osito Drone Services** here in San Francisco. We run a **100% net-enclosed, ultra-safe indoor FPV Drone Aerial Combat & Tag Arena** (`SHARD-75` featherweight micro-drones with full propeller guards inside an `8.4 ft × 8.4 ft` pop-up safety net cage).
>
> We are looking to partner with 2 SF taprooms this **November** for a **"Zero-Cost Drone Combat Pop-Up Night"** (Thursday/Friday happy hour or Saturday afternoon) — and we’d love to bring it to `[Venue Name]`.
>
> **How it works for `[Venue Name]`:**
> 1. **100% Free to You (Or 20% Beer/Rev Share):** You pay us `$0`. We just need an `8.5' × 8.5'` corner of the taproom or covered patio and one standard wall outlet.
> 2. **Zero Liability / Zero Loose Drones:** Every flight happens **strictly inside our sealed `101" × 101"` mesh cage**. Nothing can ever fly into the taproom, and we carry full commercial liability insurance.
> 3. **Keeps Patrons Buying More Rounds:** Two friends put on FPV goggles Outside the cage and battle head-to-head in a **3-minute 1v1 Aerial Tag Heat** (`$15/pilot` via Venmo/Square) while their friends watch the live cockpit feed and scoreboard on our external monitor—and stay for another round of beers while waiting for their rematch.
> 4. **Upsell for Your Private Corporate Holiday Bookings:** When corporate groups inquire with you for November Friendsgivings or December Holiday Parties, you can offer our Drone Combat Cage as an exclusive turnkey entertainment add-on (and keep a **15% venue commission** on our `$1,800` corporate package).
>
> Can I swing by `[Venue Name]` this week with a 30-second video of the cage in action, or lock in a trial pop-up slot for **Friday, Nov 6, Saturday, Nov 7, or Friday, Nov 13**?
>
> Best regards,  
> **Alan Musselman**  
> COO, Osito Drone Services (San Francisco)  
> `415-571-6614 | miguel@ositodrone.com` | `www.ositodrone.com | @OSITODroneServices`

---

### 45-Second Phone Follow-Up Script (Call Between 1:30 PM – 3:30 PM Today/Tomorrow)

> *"Hi! Calling for the taproom manager or events coordinator—my name is Alan with Osito Drone here in SF. I just sent an email to `[events@...]` about bringing our enclosed `8-foot by 8-foot` indoor FPV Drone Dogfight Cage to `[Venue Name]` for a zero-cost pop-up night in November. Patrons put on goggles outside the net cage and fly 3-minute 1v1 micro-drone battles while their friends watch on a live screen and buy another round of beer. It takes up less space than a shuffleboard table, costs you zero dollars, and we're fully insured. Who’s the best person to approve a trial Friday or Saturday afternoon pop-up next week?"*

---

## PLAY 2: Q4 Tech "Friendsgiving & Holiday Party" Corporate Blitz (`$1,200 – $1,800` Packages)

### Why November 2026 is the #1 Corporate Window of the Year
Every SF tech company (SoMa, Mission Bay, Financial District) has **Q4 Team Building / Morale / Offsite funds that expire on December 31, 2026**. Because half the company travels during Thanksgiving week (Nov 23–27) and late December, **November 5–20 and December 1–18** are the peak weeks for **"Work Friendsgivings"** and **Engineering Team Offsites**.

Better yet: Instead of cold-emailing 500 random tech workers, **partner directly with the 5 SF Arcade Bars & Corporate Event Agencies** whose calendars are already overflowing with November/December corporate bookings!

### Verified Dossier: Top 5 SF Corporate Party Venues & Team-Building Planners

| # | Venue / Agency | Address & Neighborhood | Verified Phone & Direct Emails | The November Partnership Angle |
| :--- | :--- | :--- | :--- | :--- |
| **1** | **Thriller Social Club** | `508 4th St, San Francisco, CA 94107` (SoMa) | **Phone/Text:** `(415) 706-6568`<br>**Events Email:** `events@thrillersocialclub.com`<br>**General:** `thrills@thrillersocialclub.com` | 10,000 sq. ft., 2-story retro arcade & social club hosting 20–350+ person corporate parties. **Pitch:** Offer Osito's `SHARD-75` Drone Combat Cage as a **VIP Corporate Add-On (`$1,800` retail / `$1,450` wholesale to Thriller, so they make `$350` pure margin)** for their November/December tech buyouts! |
| **2** | **Emporium SF (Arcade Bar)** | `616 Divisadero St, San Francisco, CA 94117` (NoPa / Divisadero) | **Direct Email:** `sf@emporiumarcadebar.com`<br>**Phone:** `(773) 697-7922` *(Email preferred by management)* | Huge historic theater arcade bar hosting tech happy hours and tournaments. Pitch `sf@emporiumarcadebar.com` for both a **Public Tournament Night** and a **Private Event Add-On**. |
| **3** | **SPIN San Francisco** | `690 Folsom St, Suite 100, San Francisco, CA 94107` (SoMa / Moscone) | **Event Lines:** `(415) 636-5995` / `(415) 432-8685`<br>**Web:** `wearespin.com` | Premier SoMa ping-pong corporate venue right next to Moscone Center. Their private event sales reps book dozens of tech holiday parties every November—replace one ping-pong table footprint (`9' × 5'`) with our `8.4' × 8.4'` Drone Cage as a high-margin VIP upgrade! |
| **4** | **The Midway SF / Non Plus Ultra (NPU)** | `900 Marin St, San Francisco, CA 94124` (Dogpatch / Bayview) | **NPU Corporate Phone:** `(415) 608-2220`<br>**Midway Phone:** `(415) 301-4355`<br>**Direct Email:** `events@npu.co` | **Non Plus Ultra (`npu.co`)** manages The Midway, Palace of Fine Arts, and SVN West—the largest corporate event portfolio in SF. Getting on `events@npu.co`'s preferred November/December interactive vendor roster opens `$2,500+` corporate activations. |
| **5** | **Venture Up (SF Team Building Agency)** | Bay Area / San Francisco Corporate Offsites | **Phone:** `(888) 305-1065`<br>**Email:** `info@ventureup.com`<br>**Web:** `ventureup.com` | Corporate team-building agency hired by Fortune 500 and SF tech firms. Pitch Osito as their local SF turnkey **Indoor Drone Combat Team-Building Subcontractor** for November/December bookings. |

---

### November Corporate Pricing Packages (Built for Fast Expensing on Corporate Credit Cards)

> [!TIP]
> **Why `$1,450` and `$1,800` are magic numbers in SF Tech:** Most Engineering Directors, Office Managers, and Executive Assistants have a **`$1,500` to `$2,500` corporate credit card limit** that does **NOT** require Procurement/Legal vendor onboarding! Always highlight: *"Payable via instant Stripe/Square link—receipt formatted as 'STEM/Robotics Team-Building Workshop' for easy Q4 L&D or Morale expensing."*

1. **The "Friendsgiving Office Pop-Up" (90 Minutes — `$1,200` Flat)**:
   - Ideal for Thursday/Friday 3:30 PM – 5:00 PM in-office happy hours in SoMa/FiDi.
   - Fits in any conference room, all-hands space, or cafeteria (`8.4' × 8.4'` enclosed cage).
   - 16-pilot single-elimination tournament bracket + "Top Gun of Engineering" trophy.
2. **The "Q4 Team Offsite / Holiday Party" Package (2.5 Hours — `$1,800` Flat)**:
   - Up to 40 participants rotating through 3-minute 1v1 and 2v2 heats.
   - Live HDMI output to the office/venue big screen + MC commentary + leaderboard.

### Copy-Paste Pitch for SF Tech Office Managers, EAs & Workplace Experience Leads (LinkedIn / Email)

**Target Titles on LinkedIn (Filter: San Francisco, 50–500 employees):** *Workplace Experience Manager, Office Manager, Executive Assistant to CEO/CTO, People Ops Manager, Head of Internal Events*.

**Subject:** November "Work Friendsgiving" / Q4 Team Offsite Idea (Fits in an 8x8 conference room!)

> Hi `[First Name]`,
>
> If you have Q4 team-building or Friendsgiving budget to use up in **November** (and want something way more exciting than another catered lunch or trivia call), we bring a **100% enclosed `8.4 ft × 8.4 ft` Indoor FPV Drone Dogfight Arena** directly into your SF office or holiday venue!
>
> **How it works:**
> - **Fits Right in Your All-Hands Space:** We set up our sealed `101" × 101"` safety net cage in 25 minutes. Zero loose drones, zero damage risk, fully insured.
> - **Instant Tournament Hype:** Two teammates put on FPV pilot goggles outside the net and fly featherweight `SHARD-75` combat drones head-to-head while the whole team watches the live cockpit stream on your office TV and cheers.
> - **Swipe-and-Go Corporate Card Billing:** Our **90-Minute Office Pop-Up (`$1,200`)** and **2.5-Hour Holiday Tournament (`$1,800`)** sit right under standard corporate card limits—no procurement headache required.
>
> We still have **Thursday/Friday afternoon slots open for Nov 5–6, Nov 12–13, and Nov 19–20**. Want me to send over a 1-page flyer and hold a tentative November date for `[Company Name]`?
>
> Best,  
> **Alan Musselman** — COO, Osito Drone Services (`415-571-6614 | miguel@ositodrone.com`)

---

## PLAY 3: 48-Hour Birthday Party Lead Capture (`$299` November Launch Special)

### Why Parents Will Book This Week
In November, San Francisco temperatures drop, rain starts, and sunset hits at **4:55 PM**. Parents with kids turning 8–14 in November are panicking because outdoor park parties are rained out and bowling alleys/trampoline parks (`House of Air`) charge `$800–$1,200+` and are already booked solid.
- **Osito's Killer Advantage:** Our `101" × 101" × 87"` (`8.4' × 8.4' × 7.25'`) `SHARD-75` net cage fits inside a **standard SF 1-car garage, backyard patio, church basement, or apartment community room**!
- **The Irresistible Hook:** Offer a **"November Portfolio Launch Special: `$299` (Normally `$400`) for a 90-Minute Indoor FPV Drone Combat Birthday Party"** for the **first 3 SF families** who book a November date (in exchange for letting us film 30 seconds of the cage in action and leaving a 5-star review on Thumbtack/Google!).

### Step-by-Step 48-Hour Marketplace Setup Checklist (Do Tonight & Tomorrow)

1. **Thumbtack Pro (`thumbtack.com/pro`) — #1 Highest-Intent Parent Lead Source in SF**
   - **Categories to Select:** *Children's Party Entertainment*, *Party Entertainment*, *Event Entertainment*, *Game Truck / Mobile Arcade Rental*.
   - **Service Radius:** 20 miles around San Francisco (covers SF, Daly City, South SF, San Mateo, Burlingame, Marin/Mill Valley, Oakland/Berkeley).
   - **Turn on "Instant Book / Direct Leads"** with a `$40` weekly budget cap—parents searching "unique birthday party entertainment for 10 year old boy/girl SF" will see you immediately.
2. **GigSalad (`gigsalad.com`) & The Bash (`thebash.com`)**
   - Create a free/starter listing under *Mobile Video Game Truck / Interactive Party Entertainment / Kids Party Entertainer*.
3. **Nextdoor SF (Business Page + Neighborhood Post) & Local Parent Groups**
   - Post in **Nextdoor** (Bernal Heights, Noe Valley, Sunset, Richmond, Potrero Hill, Marina) and ask a friendly SF parent to share in **Main Street Mamas SF** and **Golden Gate Mothers Group (GGMG)**.
4. **Yelp for Business ("Request a Quote" Enabled)**
   - Enable **Yelp Request-a-Quote** under *Party & Event Planning / Kids Party Entertainment* so you get instant SMS alerts when an SF parent requests quotes from mobile game trucks or magicians.

---

### Copy-Paste Profile & Listing Text (Thumbtack / GigSalad / Yelp / Nextdoor SF)

#### Headline (60 Characters Max):
> **Indoor FPV Drone Battle Cage — Mobile Kids Birthday Party!**

#### Full Copy-Paste Listing Description & Nextdoor Post:
> **🚨 NOVEMBER SF LAUNCH SPECIAL: `$299` (Normally `$400`!) for the First 3 Families Who Book a November Birthday Party! 🚨**
>
> Looking for an unforgettable, high-tech **Indoor Birthday Party for ages 8–16** that works **rain or shine** right in your garage, backyard, or living room?
>
> **Osito Drone Services** brings a real **1v1 FPV (First-Person View) Aerial Drone Combat & Tag Arena** directly to your home or party venue anywhere in San Francisco & the Peninsula!
>
> **How It Works (100% Enclosed & Parent-Approved Safe!):**
> - **Fits in a 1-Car Garage, Living Room, or Patio:** We set up our professional **`8.4 ft × 8.4 ft` (`101" × 101"`) 100% Net-Enclosed Drone Arena** in just 20 minutes.
> - **Zero Loose Drones / Zero Broken Lamps:** The featherweight `SHARD-75` micro-drones stay **100% sealed inside the safety net cage** at all times. Kids wear pro FPV pilot goggles *outside* the net to fly head-to-head aerial tag battles while all their friends watch the live cockpit video feed on our spectator screen!
> - **Beginner-Friendly for Ages 8+:** Our Flight Director coaches every child step-by-step—even kids who have never touched a drone are flying 1v1 dogfights within 60 seconds!
> - **What's Included in the 90-Minute Birthday Package (`$299` November Special / `$400` Regular):**
>   - 90 minutes of non-stop 1v1 tournament heats (ideal for **8 to 16 kids**)
>   - `101" × 101"` enclosed safety arena + all `SHARD-75` drones, batteries, and FPV goggles
>   - Dedicated Osito Flight Director / Referee to run the bracket so parents can relax
>   - Special **"Top Gun Birthday Pilot" Flight Wings Certificate** for the birthday child!
>
> 📅 **Available Saturdays & Sundays in November 2026 (Nov 7–8, Nov 14–15, Nov 21–22, Nov 28–29).** Message us today with your date and neighborhood to claim one of the **3 discounted `$299` November Launch slots**!

---

## 72-Hour Execution Schedule to Lock In Job #1 by Monday, Nov 2

| Day & Time | Action Item | Target Outcome |
| :--- | :--- | :--- |
| **Tonight (Thu, Oct 29)** | Publish the **Thumbtack Pro**, **GigSalad**, and **Nextdoor SF** listings using the `$299` November Birthday Launch Special copy above. | Live before Friday morning when SF parents plan weekend/November parties. |
| **Friday, Oct 30 (9:30 AM)** | Send the **Play 1 Brewery Pop-Up Email** to all 8 verified SF Breweries (`Barebottle`, `Harmonic`, `Standard Deviant`, `Southern Pacific`, `Enterprise`, `Laughing Monk`, `SPARK Social`, `Fort Point`). | 8 warm emails in event managers' inboxes before Friday taproom prep. |
| **Friday, Oct 30 (11:00 AM)** | Send the **Play 2 Corporate Venue Partner Email** to `events@thrillersocialclub.com`, `sf@emporiumarcadebar.com`, `events@npu.co`, `info@ventureup.com`, and `SPIN SF`. | Get added as a turnkey November/December corporate entertainment add-on. |
| **Friday, Oct 30 (2:00 PM – 4:00 PM)** | **Walk-in / Call Blitz:** Call or walk into **Barebottle (`1525 Cortland`)**, **Standard Deviant (`280 14th St`)**, and **Laughing Monk (`1439 Egbert`)** during quiet pre-happy-hour prep (2–4 PM) with a tablet video of the `SHARD-75` cage. | Lock in **at least 1 Friday/Saturday November Pop-Up Night** (`$480` projected Venmo cash + live corporate leads). |
| **Monday, Nov 2 (9:00 AM)** | Message 25 SF Tech Office Managers / Workplace Experience Leads on LinkedIn offering the **`$1,200` 90-Minute "Work Friendsgiving" Office Pop-Up** for Nov 12–13 or Nov 19–20. | Book 1 paid `$1,200–$1,800` November corporate event on a corporate credit card. |
