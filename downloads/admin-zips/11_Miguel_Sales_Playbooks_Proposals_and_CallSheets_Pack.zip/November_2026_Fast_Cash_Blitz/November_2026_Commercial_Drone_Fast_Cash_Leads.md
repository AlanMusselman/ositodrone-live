# Osito Drone Services — November 2026 Commercial Fast-Cash Execution Playbook

**Prepared:** October 29, 2026  
**Target Window:** November 1 – November 30, 2026 (First Paid Commercial Shoot in 7–14 Days)  
**Osito Contact Line:** `(415) 269-1206` | `info@ositodrone.com` | `www.ositodrone.com`

---

## Why Commercial Drone Services Are Your #1 Fastest Path to Cash in November 2026

While school districts, rec centers, and youth grant cycles take 30–90 days to approve POs, **Osito Drone Services' existing one-pager** (`one pager Osito services.pdf`) already advertises four high-margin, rapid-turnaround commercial verticals:
1. **Real Estate: Indoor & Outdoor Solutions** (*FPV Interior Video Tours, Twilight Aerials, Professional Interior Photography, Virtual Tours*)
2. **Infrastructure Inspection** (*Safe, efficient inspections of hard-to-reach structures, roofs, and utilities*)
3. **Mapping & Surveying** (*Precise aerial mapping, 3D modeling, and volumetrics for construction & development*)
4. **Construction Monitoring** (*Regular site progress updates, safety monitoring, and project documentation*)

### Why This Closes in 7–14 Days (November 2026):
* **On-Demand Inspection Networks (Bucket A)** dispatch pre-sold roof, solar, and property insurance inspections in the `415`/`650` area codes directly to registered FAA Part 107 pilots at **`$85–$350/mission`** with zero cold-selling required.
* **SF Real Estate Media Agencies & Luxury Teams (Bucket B)** constantly struggle to find skilled **Indoor One-Take FPV Cinewhoop Pilots** who can fly ducted prop-guarded drones smoothly from the curb, through the front door, up Victorian/modern staircases, and out to the view deck. Subcontracting to SF real estate media houses (`Open Homes Photography`, `Aerial Canvas`) pays **`$350–$650/shoot`** with 48 hours' notice.
* **Pre-Winter Storm Roof & Solar Inspections (Bucket C):** November is peak pre-rainstorm season in San Francisco. Local roofers (`Lawson Roofing`, `Mr. Roofing`, `Wedge Roofing`), solar installers (`Luminalt`), and multi-building HOA property managers (`CitiScape`) have multi-week ladder/scaffolding backlogs on steep 3-to-4-story SF Victorians and commercial flat roofs. A 30-minute high-res/thermal orthomosaic roof report pays **`$250–$600/building`**.
* **SF General Contractors (Bucket D):** Local builders (`Build Group`, `CCI`, `Current Construction`, `G&M Builders`) pay **`$400–$850/month per site`** for bi-weekly or monthly aerial orthomosaic progress photos to attach to their owner/lender draw requests.

---

## 1. The 20 Verified San Francisco Commercial Fast-Cash Leads Table

### Bucket A: 5 On-Demand Commercial Drone Job Networks (Instant 415/650 Dispatch)

| # | Organization | Category | SF Coverage / HQ | Phone | Email / Pilot Registration Portal | Payout Per Job | How to Close in November 2026 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **1** | **FlyGuys** | National On-Demand Drone Data Network | Nationwide / SF Bay Area (`415`/`650`/`510`) | `(888) 837-0940` | `support@flyguys.com` / [flyguys.com](https://flyguys.com) ("Be a Pilot") | `$175 – $550+` (Roof, thermal, LiDAR, construction progression) | Complete pilot onboarding + upload Part 107 & COI on Oct 30; call `(888) 837-0940` to tell dispatch you have 3 Part 107 pilots covering all of SF/Peninsula for immediate November dispatch. |
| **2** | **Zeitview** *(formerly DroneBase)* | Property, Solar & Roof Inspection Network | SF Bay Area Commercial & Solar Dispatch | Ticket Portal | `pilots@zeitview.com` / [support.zeitview.com](https://support.zeitview.com/pilot-support/) | `$100 – $350` (Commercial roof, solar thermal, insurance claims) | Register all Part 107 certificates on Zeitview Pilot Portal; enable push alerts for `94101–94134` & `94080` zip codes; accept first commercial roof/solar mission within 5 minutes of notification. |
| **3** | **Bees360** | AI Roof & Property Insurance Drone Inspections | San Francisco & Peninsula Insurance Dispatch | `(800) 990-6108` | `flythehive@bees360.com` / [portal.bees360.com](https://portal.bees360.com) | `$85 – $225` per roof (stack 3–4 homes/day = `$350–$800/day`) | Email `flythehive@bees360.com` & `accounting@bees360.com` with W9 + Part 107; complete BeesPilot app onboarding to get steady November residential/commercial insurance underwriting flights. |
| **4** | **Droners.io** | Direct Client-to-Pilot Commercial Marketplace | San Francisco Bay Area Local Bids | Online Portal | [droners.io](https://droners.io) ("Become a Pilot") | `$200 – $750` (Real estate, roof, construction, events) | Create an Osito Drone Services profile featuring your indoor FPV & outdoor aerial reel; turn on instant SMS alerts and bid within 15 minutes on every SF Bay Area job posted in November. |
| **5** | **Loveland Innovations (IMGING)** | Automated Roof & Property Drone Inspections | SF Bay Area Roofing & Insurance Network | `(385) 498-0800` | `customersupport@lovelandinnovations.com` / [training.lovelandinnovations.com](https://training.lovelandinnovations.com) | `$100 – $275` per automated roof scan | Complete IMGING 3rd-Party Inspection Certification online; call `(385) 498-0800` (Press 1) to activate your SF Bay Area service radius for November storm-prep roof claims. |

---

### Bucket B: 6 SF Luxury Real Estate Teams & Media Agencies (Subcontract FPV Indoor Tours & Twilight Aerials)

| # | Organization | Category | SF Address | Phone | Email / Website | Payout Per Job | How to Close in November 2026 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **6** | **Open Homes Photography** | #1 SF Real Estate Visual Media Agency | 4104 24th Street #439, San Francisco, CA 94114 | `(415) 592-5187` / `(800) 647-8310` | `support@openhomesphotography.com` / [open-homes.com](https://www.open-homes.com) | `$300 – $550` (Subcontracted Indoor FPV fly-throughs & twilight aerials) | Pitch Production Manager as their **on-call SF Indoor Cinewhoop FPV Subcontractor** (`$350` wholesale rate so they can retail it to Compass/Sotheby's agents at `$650+`). Offer 1 free 30-sec spec fly-through this week. |
| **7** | **Aerial Canvas** | Luxury Real Estate Video & Drone Agency | 934 Laurel St #102, San Carlos, CA 94070 *(SF Bay Area HQ)* | `(650) 241-0095` | `hello@aerialcanvas.com` / [aerialcanvas.com](https://aerialcanvas.com) | `$350 – $650` (One-take indoor FPV tours & luxury twilight drone reels) | Email `hello@aerialcanvas.com` + call `(650) 241-0095`; offer overflow Part 107 & specialized ducted indoor FPV cinewhoop coverage specifically for San Francisco (`941xx`) listings so their Peninsula crew avoids SF bridge/city traffic. |
| **8** | **Reel & Shutter** *(formerly TourFactory Bay Area)* | Real Estate Photography & Video House | San Francisco Bay Area Regional Dispatch | `(855) 595-6113` | `support@reelandshutter.com` / [reelandshutter.com](https://reelandshutter.com) | `$250 – $500` (Subcontracted aerials & indoor FPV video add-ons) | Call `(855) 595-6113` (Mon–Fri 6am–5pm) and ask for the Bay Area Field Manager; pitch Osito as a fully insured, local SF Part 107 vendor for same-day aerials and one-take indoor FPV reels. |
| **9** | **Vanguard Properties (SF HQ)** | Boutique SF Luxury Real Estate Brokerage | 2501 Mission St, San Francisco, CA 94110 | `(415) 321-7000` | `info@vanguardproperties.com` / [vanguardproperties.com](https://vanguardproperties.com) | `$450 – $850` (Direct-to-agent Indoor FPV + Twilight Aerial Package) | Walk into 2501 Mission St with `one pager Osito services.pdf` on Tablet + QR code to FPV reel; ask Marketing Director to book a **free 30-second FPV spec fly-through** on one flagship `$3M+` November listing. |
| **10** | **Malin Giddings Team — Compass SF** | Top-Producing SF Luxury Real Estate Team | 891 Beach St, San Francisco, CA 94109 | `(415) 531-5033` (Cell) / `(415) 660-9955` | `malin@sfproperties.com` / [compass.com](https://www.compass.com) | `$500 – $850` (Luxury Pacific Heights / Marina view aerials + FPV tour) | Email `malin@sfproperties.com` & call `(415) 531-5033`; offer a complimentary 30-second Golden Gate / Bay view twilight drone clip on an active listing to prove 24-hour turnaround for November price-refresh campaigns. |
| **11** | **Sotheby's International Realty — SF Brokerage** | Ultra-Luxury SF Real Estate Brokerage | 117 Greenwich Street, San Francisco, CA 94111 | `(415) 901-1700` | [sothebysrealty.com](https://www.sothebysrealty.com) (SF Marketing Desk) | `$550 – $950` (Bespoke indoor-to-outdoor FPV one-take architectural film) | Call `(415) 901-1700` and ask for the Listing Marketing Coordinator; pitch the **"November Stale-Listing Refresher"**—a 45-second indoor-to-outdoor FPV fly-through for listings sitting 30+ days on market before the holidays. |

---

### Bucket C: 5 SF Roofing, Solar & HOA Property Managers (November Pre-Winter Storm Inspections)

| # | Organization | Category | SF Address | Phone | Email / Website | Payout Per Job | How to Close in November 2026 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **12** | **Lawson Roofing Co., Inc.** | Premier SF Commercial & Residential Roofer | 1495 Tennessee St, San Francisco, CA 94107 | `(415) 285-1661` | `lrc@lawsonroofing.com` / [lawsonroofing.com](https://lawsonroofing.com) | `$250 – $550` per steep/multi-story SF roof inspection | Call `(415) 285-1661` + email `lrc@lawsonroofing.com`; pitch **"No-Ladder 30-Minute Drone Roof & Flashing Inspection"** for steep 3-4 story SF Victorians & commercial buildings during their November pre-rain rush. |
| **13** | **Mr. Roofing** | SF & Peninsula Roofing & Solar Contractor | 101 1st Street, South San Francisco, CA 94080 | `(650) 832-9995` / `(650) 872-3232` | `info@mrroofing.net` / [mrroofing.net](https://mrroofing.net) | `$250 – $500` (Pre-estimate roof geometry, flashing & gutter inspection) | Call `(650) 832-9995` and speak to the Estimating Manager; offer same-day high-res roof & parapet photo packages for `$250` flat so their estimators can quote 3x more November roofs without climbing ladders. |
| **14** | **Wedge Roofing** | Commercial & Residential Spray Foam / Roofs | San Francisco & Marin Dispatch | `(888) 763-7663` | `info@wedgeroofing.com` / [wedgeroofing.com](https://wedgeroofing.com) | `$300 – $650` (Commercial flat roof & multi-family drone surveys) | Email `info@wedgeroofing.com` & call `(888) 763-7663`; pitch before/after commercial roof documentation & pre-winter ponding/drainage inspections in San Francisco. |
| **15** | **Luminalt Solar Energy Solutions** | San Francisco's Leading Local Solar Installer | 10 Carolina Street, San Francisco, CA 94103 | `(415) 641-4000` | `info@luminalt.com` / [luminalt.com](https://luminalt.com) | `$250 – $500` (Solar shading analysis, 3D roof modeling & panel inspection) | Visit or call `10 Carolina St` (`(415) 641-4000`); pitch rapid drone orthomosaic & 3D roof modeling for their November commercial/residential solar site surveys and annual panel maintenance checks. |
| **16** | **CitiScape Property Management Group** | SF HOA & Multi-Family Condo Management | 3450 Third Street, Suite 1A, San Francisco, CA 94124 | `(415) 401-2000` | [citiscapesf.com](https://citiscapesf.com) (HOA Maintenance Portal) | `$350 – $750` per HOA building (Pre-winter roof/gutter/facade audit) | Call `(415) 401-2000` and ask for the Director of HOA Property Management; pitch a **`$395` November Pre-Storm Roof & Gutter Visual Audit** that HOA boards can approve out of petty/operating maintenance funds without a full board vote. |

---

### Bucket D: 4 Active SF General Contractors (Monthly Aerial Progress & Site Mapping)

| # | Organization | Category | SF Address | Phone | Email / Website | Payout Per Job | How to Close in November 2026 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **17** | **Build Group, Inc.** | Major SF Commercial & Multi-Family Builder | 160 S. Van Ness Ave, San Francisco, CA 94103 | `(415) 367-9399` | `info@buildgc.com` / [buildgc.com](https://www.buildgc.com) | `$450 – $850/shoot` (Monthly orthomosaic map + 4K progress reel) | Call `(415) 367-9399` and ask for a Project Manager or Superintendent on an active SF jobsite; offer a `$395` November Trial Progress Shoot (orthomosaic + 15 high-res angles) for their monthly owner/lender draw package. |
| **18** | **Commercial Construction & Improvements (CCI)** | SF Commercial GC & Building Upgrades | 140 Geary Street, 9th Floor, San Francisco, CA 94108 | `(415) 626-3338` | `info@cci-gc.com` / [cci-gc.com](https://cci-gc.com) | `$350 – $700/shoot` (Roof/exterior upgrade documentation & site progress) | Email `info@cci-gc.com` & call `(415) 626-3338`; pitch exterior facade, roof mechanicals, and monthly progress drone documentation for downtown SF commercial projects. |
| **19** | **Current Construction** | SF Multi-Unit, Commercial & Residential GC | P.O. Box 40552, San Francisco, CA 94140 | `(415) 969-6915` | `info@currentcon.com` / [currentcon.com](https://currentcon.com) | `$300 – $650/shoot` (Multi-unit residential & infill site progress) | Call `(415) 969-6915` & email `info@currentcon.com`; pitch a flat `$350` pre-winter exterior/roofing waterproofing verification & site progress flight for their active SF builds. |
| **20** | **G&M Builders General Contractor Corp.** | SF High-End Residential & Commercial GC | 2949 Mission St, San Francisco, CA 94110 | `(415) 571-0823` / `(855) 508-1904` | `G.mgeneralccorp@gmail.com` / [g-mbuilders.com](https://g-mbuilders.com) | `$300 – $600/shoot` (Progress monitoring + finished project showcase reel) | Call `(415) 571-0823` or stop by 2949 Mission St; pitch a 2-for-1 November package: construction progress aerials on an active build OR an indoor-to-outdoor FPV completion showcase video on a recently finished remodel for `$395`. |

---

## 2. The "Pre-Winter Storm Roof Inspection" Pitch (Bucket C: SF Roofers, Solar & HOA Managers)

> **Why this works right now (Late October / November 2026):** Every November, the first atmospheric river rains hit San Francisco. Homeowners and HOA boards flood local roofers (`Lawson Roofing`, `Mr. Roofing`, `Wedge Roofing`) and HOA managers (`CitiScape`) with leak-prevention requests. Sending a 2-person crew with a 40-foot ladder to inspect a 3-story SF Victorian or Soma commercial roof takes 2–3 hours and carries high OSHA fall-liability. Osito can fly and deliver 40 ultra-sharp 4K/zoom inspection photos of every flashing, scupper, gutter, skylight, and parapet in **30 minutes for `$295–$395`**.

### A. Ready-to-Send Email Script (To SF Roofers & HOA Property Managers)

**Subject:** 30-min SF drone roof & gutter inspections before November rains (`$295` flat — no ladders)

Hi [First Name / Estimating & Maintenance Team at Lawson Roofing / CitiScape],

With November winter rains approaching in San Francisco, your estimators and maintenance crews are likely getting slammed with inspection requests on steep 3-to-4-story SF roofs and multi-unit buildings.

Rather than tying up a two-person crew and a 40-foot ladder just to diagnose flashing, clogged scuppers, ponding, or cracked skylights, **Osito Drone Services** (based right here in SF, FAA Part 107 certified & fully insured) can capture a complete **High-Resolution Aerial Roof, Gutter & Facade Inspection Package in 30 minutes** with **24-hour delivery**.

**Our November "Pre-Storm Rapid Roof Audit" (`$295` flat per building in SF):**
* **35–50 High-Resolution Annotated Photos:** Top-down orthomosaic overview + tight zoom shots of every valley, chimney flashing, parapet cap, gutter line, skylight, and solar array.
* **4K Slow-Motion Flyover Video:** Complete perimeter and roof-plane walkthrough for your estimator, HOA board, or insurance adjuster.
* **Zero Ladder Liability / 48-Hour Booking:** We handle airspace clearance, safety cones, and insurance certificates.

**Want to test us out this week?**  
Reply with the address of **one steep or hard-to-access SF property** on your November schedule, and we will shoot your **first inspection for `$195` (or a free 15-minute sample scan alongside your estimator)** so you can see the photo detail firsthand.

Best regards,

**Miguel Flores (CEO, `415-571-6614` | `miguel@ositodrone.com`) / Alan Musselman (COO, `415-810-4158` | `alan@ositodrone.com`)**  
Co-Founder & FAA Part 107 Commercial Pilot | Osito Drone Services  
📞 `(415) 269-1206` | ✉️ `info@ositodrone.com` | 🌐 `www.ositodrone.com`

---

### B. 45-Second Phone Script (Call `Lawson Roofing`, `Mr. Roofing`, `Wedge Roofing`, `CitiScape` at 8:30 AM)

> **You:** *"Hi, may I speak with the Estimating Manager [or HOA Maintenance Director]? ... Hi [Name], my name is Miguel Flores (CEO, `415-571-6614` | `miguel@ositodrone.com`) / Alan Musselman (COO, `415-810-4158` | `alan@ositodrone.com`) with Osito Drone Services here in San Francisco. I'll be super brief—with November rains coming up, do you guys have any steep 3- or 4-story SF roofs on your schedule this week where it's a pain to haul a 40-foot ladder or rent a lift just to get an estimate?"*
>
> **[Wait for response]**
>
> **You:** *"That's exactly why I'm calling. We're local FAA Part 107 insured drone operators in the 415. Instead of burning two hours of your estimator's day climbing steep roofs, we can meet them on-site—or go solo—and deliver 40 high-res zoom photos of every flashing, gutter, scupper, and skylight within 24 hours for a flat `$295`. In fact, so you can test our image quality this week, we'll run your toughest SF roof address this week for just `$195`—or do a quick 10-minute demo scan for free while your estimator is already on site. What address is giving your crew the biggest headache this week?"*

---

## 3. The "Free 30-Second FPV Indoor Fly-Through Spec Reel" Pitch (Bucket B: SF Real Estate Media Houses & Luxury Agents)

> **Why this works right now (November 2026):**  
> 1. **For Real Estate Media Houses (`Open Homes Photography`, `Aerial Canvas`, `Reel & Shutter`):** They already shoot 50–150 listings a week in SF, using standard tripod cameras and outdoor DJI Mavic drones. However, luxury agents constantly ask them for **"One-Take Indoor-to-Outdoor FPV Cinewhoop Fly-Throughs"** (flying smoothly from the street, through the front door, through the kitchen/living room, and out the back deck toward the Bay/City view). Flying an indoor FPV cinewhoop requires specialized manual acro skill and prop guards that 90% of standard real estate photographers don't have! By pitching Osito as their **white-label, on-call SF Indoor FPV Subcontractor at `$350/shoot`**, the media agency marks it up to `$650–$850` and books you repeatedly!
> 2. **For Luxury Listing Teams (`Vanguard Properties`, `Malin Giddings`, `Sotheby's`):** Any SF listing still sitting on the market in early November needs a viral Instagram/Reels video refresh before Thanksgiving slowdown.

### A. Ready-to-Send Email Script (To SF Real Estate Media Agencies — Subcontracting Pitch)

**Subject:** White-label SF Indoor FPV Cinewhoop Pilot for Open Homes / Aerial Canvas (`48-hr` notice)

Hi [Production Manager / Operations Team at Open Homes Photography / Aerial Canvas],

We love the work your team produces across San Francisco. I'm reaching out from **Osito Drone Services** (`www.ositodrone.com` — local SF FAA Part 107 certified & insured pilots) because we specialize in the one service most standard real estate photographers hate shooting: **One-Take Indoor-to-Outdoor FPV Cinewhoop Fly-Throughs**.

If your luxury agents at Compass, Sotheby's, or Vanguard are asking for smooth, continuous one-take FPV reels (flying from the exterior curb, through the front door, up multi-level SF floorplans, and out to the view deck)—or if you need reliable **overflow coverage in San Francisco (`941xx`) for Twilight Aerials**—we want to be your go-to white-label subcontractor.

**How We Partner With Real Estate Media Agencies:**
* **100% White-Label & Insured:** We show up wearing unbranded attire as part of your crew, flying ultra-quiet, fully prop-guarded indoor cinewhoops (`4K/60fps` stabilized with Gyroflow).
* **Wholesale Subcontractor Rate (`$350` flat):** You charge your agent `$650–$850+`, keep the margin, and we deliver either raw stabilized `4K` takes same-day or a speed-ramped, sound-designed cut within 24 hours.
* **Fast SF Dispatch:** Based right here in SF (`415-269-1206`), available on 24–48 hours' notice.

**Zero-Risk November Test:**  
Got a cool SF listing on your calendar next week? Let us tag along for **20 minutes at zero cost** to shoot a complimentary **30-second Indoor FPV Spec Reel** that you can gift to your top client (and use on your own portfolio).

Can I hop on a 3-minute call today at `(415) 269-1206` to coordinate a test shoot?

Best regards,

**Miguel Flores (CEO, `415-571-6614` | `miguel@ositodrone.com`) / Alan Musselman (COO, `415-810-4158` | `alan@ositodrone.com`)**  
Co-Founder & Lead FPV Pilot | Osito Drone Services  
📞 `(415) 269-1206` | ✉️ `info@ositodrone.com` | 🌐 `www.ositodrone.com`

---

### B. Ready-to-Send Email / DM Script (Direct to Luxury SF Listing Agents: Vanguard, Compass, Sotheby's)

**Subject:** Free 30-sec Indoor-to-Outdoor FPV Fly-Through for [Property Address / Your Next SF Listing]

Hi [Agent First Name, e.g., Malin],

In November, the fastest way to stop buyers scrolling on Instagram/Reels and get fresh feet through an open house is a **One-Take Indoor-to-Outdoor FPV Drone Fly-Through**—flying seamlessly from the front curb, right through the front door, through the main living spaces, and out onto the terrace into a panoramic San Francisco view.

We are **Osito Drone Services**, a local San Francisco team of FAA Part 107 & indoor micro-FPV pilots (fully insured, using soft prop-guarded indoor cinema drones that are 100% safe around staging and fine finishes).

Because we are adding 3 new San Francisco luxury properties to our November showcase reel, **we'd love to shoot a complimentary 30-second FPV Indoor-to-Outdoor Spec Reel on one of your active or upcoming listings this week** (`$550` value — zero cost or obligation).

* **Time required on-site:** Just 30 minutes (great right before an open house or broker tour).
* **Turnaround:** Fully edited, speed-ramped 9:16 vertical Reel + 16:9 widescreen cut delivered to your inbox within 24 hours.
* **Future Shoots:** When you love the result, our full **Indoor FPV + Twilight Aerial Package** is a flat `$495` with 48-hour booking.

Which of your current SF listings has the best indoor-to-outdoor flow or view for us to feature this week? Feel free to reply here or text/call me at `(415) 269-1206`.

Best regards,

**Miguel Flores (CEO, `415-571-6614` | `miguel@ositodrone.com`) / Alan Musselman (COO, `415-810-4158` | `alan@ositodrone.com`)**  
Co-Founder & FAA Part 107 Pilot | Osito Drone Services  
📞 `(415) 269-1206` | ✉️ `info@ositodrone.com` | 🌐 `www.ositodrone.com`

---

## 4. 7-Day Action Plan to Guarantee Job #1 in November 2026

1. **Day 1 (Oct 30 — 9:00 AM to 11:00 AM): Register on All 5 Bucket A Networks (`FlyGuys`, `Zeitview`, `Bees360`, `Droners.io`, `Loveland IMGING`).** Upload every co-founder's Part 107 certificate, W-9, and insurance policy, and call `FlyGuys` (`888-837-0940`) and `Bees360` (`800-990-6108`) to flag immediate availability in San Francisco (`415`/`650`).
2. **Day 1 (Oct 30 — 1:00 PM to 4:00 PM): Call & Email the 3 SF Real Estate Media Houses (`Open Homes Photography`, `Aerial Canvas`, `Reel & Shutter`).** Offer the **Free 20-Minute Indoor FPV Spec Shoot** next week so you become their white-label `$350/shoot` indoor FPV subcontractor for all of November.
3. **Day 2 (Oct 31 / Nov 2 — 8:00 AM to 10:30 AM): Call the 5 Bucket C Roofers, Solar & HOA Managers (`Lawson Roofing`, `Mr. Roofing`, `Wedge Roofing`, `Luminalt`, `CitiScape`).** Pitch the **`$195` First-Building Pre-Storm Drone Roof Audit** so estimators don't have to haul ladders up 3-story SF Victorians before November rains.
4. **Day 3 (Nov 3 — 10:00 AM to 2:00 PM): Walk In & Call Bucket B Luxury Brokerages (`Vanguard Properties` at 2501 Mission St) & Bucket D General Contractors (`G&M Builders` at 2949 Mission St, `Build Group` at 160 S. Van Ness Ave).** Leave your printed one-pager (`one pager Osito services.pdf`) and book your first `$395` November construction progress or luxury listing shoot!
