# Osito Drone — San Francisco 4-Hour "BART & Whoop" Local Meetup & Safari Playbook

**Event Concept:** "The SF BART & Whoop Safari" (4-Hour Transit-Linked Tiny Whoop Meetup)  
**Target Fleet:** Sub-50g 1S Ducted Tiny Whoops (`OSITO LILBEAR-65`, `OSITO CUB-75`, `SHARD-75` / `KODIAK-75`, or any 65mm–75mm 1S brush/brushless Whoop with full 360° prop guards)  
**Transit Backbone:** San Francisco Market/Mission BART Corridor (`Embarcadero` ↔ `Montgomery` ↔ `Civic Center` ↔ `16th St Mission` ↔ `24th St Mission` ↔ `Glen Park`)  
**Total Duration:** **4.0 Hours** (240 Minutes — ~185 mins active flying/socializing, ~55 mins total BART + walking transit)

---

## 1. Why the "BART Corridor Whoop Safari" Works in San Francisco
1. **Zero Car / Parking Headaches:** Pilots carry a single backpack (Radiomaster Pocket/Zorro, FPV goggles, 1–2 Tiny Whoops, 12–18 pre-charged `1S 300mAh/550mAh` packs, and 1x ultra-light pop-up cube gate). Every stop is within a **1 to 5 minute walk of an SF BART station escalator** and rides take **2 to 6 minutes** underground.
2. **100% Class G Airspace & Sub-250g Compliance:** The entire downtown/Mission BART spine in San Francisco sits in **uncontrolled Class G airspace** (well north of SFO's Class B surface shelf, which starts south of Daly City/San Bruno). Because `LILBEAR-65` (~22g–26g) and `CUB-75` (`39.5g`) are **well under 250g** with fully enclosed prop ducts, they do not trigger FAA Remote ID requirements and have near-zero kinetic energy.
3. **Wind-Sheltered Micro-Environments:** San Francisco afternoon winds (`12–20 mph`) can push a 65mm/75mm 1S Tiny Whoop hard in open fields. Every stop on this itinerary is specifically chosen for **architectural wind blocks, sunken plazas, dense tree canopies, indoor makerspaces, or brewery patios**.
4. **Built-In Osito Brand & Customer Acquisition:** Spectators along the Embarcadero, Yerba Buena, Dolores Park, and Mission breweries always stop to ask *"What are those?!"* Bringing a portable 7–10" 5.8GHz spectator monitor with an Osito QR code sticker turns a fun Saturday pilot meetup into free organic marketing for Osito's camps, birthday parties, and brewery pop-ups.

---

## 2. Recommended Basecamp Meetup Locations (Choose 1 to Start)

### Option A (South-to-North): **Noisebridge Hackerspace / 16th St Mission BART** *(Recommended Tech/Builder Basecamp)*
* **Meetup Spot:** **Noisebridge** (`272 Capp St, SF — 2.5 blocks from 16th St Mission BART`) OR the outdoor courtyard tables at **Mission Creek / 16th & Valencia**.
* **Why Start Here:** You already have the Noisebridge connection ([`NB_Membership_application_-_jan2026_-_Noisebridge.pdf`](./NB_Membership_application_-_jan2026_-_Noisebridge.pdf)). Pilots can meet 15 minutes early, top off `1S` packs on a `VIFLY WhoopStor V3`, check VTX channel assignments (`Raceband R1–R8` at `25mW`), do a quick indoor hover check, and walk 3 minutes to **16th St Mission BART**.

### Option B (North-to-South): **Ferry Building Back Plaza / Embarcadero BART** *(Recommended Scenic / Tourist-Friendly Basecamp)*
* **Meetup Spot:** **Sue Bierman Park / Ferry Building South Apron** (1-minute walk from `Embarcadero BART` Exit A2).
* **Why Start Here:** Easy meetup landmark for East Bay (Oakland/Berkeley) and Peninsula pilots arriving on BART; great morning light and calm morning winds before the afternoon sea breeze picks up, ending the 4-hour tour at a Mission brewery (`Standard Deviant` or `Southern Pacific`).

---

## 3. Master 4-Hour Timed Itinerary (North-to-South Route: Embarcadero $\rightarrow$ Glen Park $\rightarrow$ Mission Finale)

This route starts at **Embarcadero BART at 1:00 PM** (when downtown plazas have the best light) and finishes at **16th St Mission BART at 5:00 PM** at a Tiny Whoop-friendly brewery taproom with power outlets for charging.

```mermaid
flowchart LR
    S0["1:00 PM | MEETUP & STOP 1\nEmbarcadero BART\nSue Bierman Park & Vaillancourt Plaza\n(50 mins)"]
    S1["2:00 PM | STOP 2\nMontgomery St BART\nYerba Buena Gardens & Waterfall Concourse\n(50 mins)"]
    S2["3:00 PM | STOP 3\nGlen Park BART\nGlen Canyon Park Eucalyptus Grove\n(55 mins)"]
    S3["4:05 PM | STOP 4 (FINALE)\n16th St Mission BART\nStandard Deviant Brewing OR Noisebridge\n(55 mins)"]

    S0 -->|"BART: 2 mins"| S1
    S1 -->|"BART: 11 mins"| S2
    S2 -->|"BART: 5 mins"| S3
```

### Detailed 4-Hour Schedule & Flight Spot Breakdown

| Time Window | BART Station & Transit Time | Flight Location & Exact Spot | Why It's Safe & Popular for Tiny Whoops | Flight Style & Challenges |
| :--- | :--- | :--- | :--- | :--- |
| **1:00 PM – 1:15 PM**<br>*(15 mins)* | **Embarcadero BART**<br>*(Meet at Sue Bierman Park lawn benches, Washington & Drumm St)* | **Meetup Basecamp: Sue Bierman Park** | Wide-open landscaped lawn steps from BART Exit A2; away from Market St buses/streetcars. | **Frequency Check & Pack Up:** Assign pilot VTX channels (`R1, R3, R6, R8` @ `25mW`) so 4 pilots can fly simultaneously with zero video bleed. |
| **1:15 PM – 1:50 PM**<br>*(35 mins)* | *0 min walk (adjacent)* | **Stop 1: Sue Bierman Park Trees & Embarcadero Plaza Brick Ledges** | Surrounded by high-rise windbreaks on the west side; clusters of mature trees with low branches, curved park benches, and concrete stairs. | **Tree Proximity & Split-S Dive Lines:** Threading between tree trunks (`CUB-75` / `LILBEAR-65`), power-looping park sign frames, and chasing friends over the grass. |
| **1:50 PM – 2:00 PM**<br>*(10 mins)* | **BART:** `Embarcadero` $\rightarrow$ `Montgomery St` *(2 min ride + 4 min walk down 3rd/Mission)* | *In Transit* | Fast underground hop into SoMa. | Swap spent `1S` packs into storage pocket; keep 1x USB-C PD power bank connected to a `WhoopStor V3` inside your backpack to recharge 6 packs on the move! |
| **2:00 PM – 2:50 PM**<br>*(50 mins)* | **Montgomery St BART** *(or Powell St BART)* | **Stop 2: Yerba Buena Gardens — Esplanade & Sunken Waterfall Courtyard** *(750 Howard St)* | Recessed below street level with 360° building wind-shielding. Features architectural pergolas, steel walkways, manicured hedges, and stone arches. *(Tip: Stay on the open lawn/pergola side if security is near the main carousel).* **Backup 1 block away:** **Salesforce St. Mary's Square** or **560 Mission St Bamboo Plaza** (POPOS with dense bamboo groves!). | **Architectural Whooping:** Flying under pergola beams, orbiting tree planters, and smooth cine-whoop style lines with an extra monitor set up for passing families to watch. |
| **2:50 PM – 3:05 PM**<br>*(15 mins)* | **BART:** `Montgomery St` $\rightarrow$ `Glen Park` *(11 min ride + 3 min walk across Bosworth St)* | *In Transit* | Direct shot down the BART tunnel to SF's best natural canyon right outside a station. | Top off radio/goggle batteries; switch to fresh `1S` packs. |
| **3:05 PM – 3:55 PM**<br>*(50 mins)* | **Glen Park BART** | **Stop 3: Glen Canyon Park Lower Eucalyptus Grove & Rec Center Lawn** *(Elk St & Bosworth St)* | The canyon walls block 80% of the coastal Sunset/Twin Peaks wind. Giant eucalyptus trunks, wooden footbridges, and boulder outcrops create a real-life Endor forest course 3 minutes from BART. | **Forest Slalom & Footbridge Runs:** Set up 2 pop-up LED micro-gates between eucalyptus trees for 3-lap time trials or `SHARD-75` magnetic tag heats over soft dirt/grass. |
| **3:55 PM – 4:05 PM**<br>*(10 mins)* | **BART:** `Glen Park` $\rightarrow$ `16th St Mission` *(5 min ride + 3 min walk to 14th St or Capp St)* | *In Transit* | Quick 2-station jump back into the sunny Mission micro-climate. | Pack away outdoor pop-up gates; prep indoor/patio whoops. |
| **4:05 PM – 5:00 PM**<br>*(55 mins)* | **16th St Mission BART** | **Stop 4 (Finale): Standard Deviant Brewing (`280 14th St`) OR Noisebridge (`272 Capp St`)** | **Standard Deviant** is 2 blocks from 16th St BART, has a sheltered industrial roll-up garage/patio vibe, cold craft beer, and loves local SF maker pop-ups. **Noisebridge** is 2.5 blocks away if you want 100% indoor table/bench obstacle racing and soldering/charging access. | **Micro-Gate Time Trials & Pint Debrief:** Set up tabletop micro-arches, plug in chargers at the wall, run 1v1 `LILBEAR-65` micro-races, and hand out Osito Drone cards to curious patrons. |

---

## 4. Alternative BART Stops (Swappable Based on Weather or Crowd)

If it's unusually windy, rainy, or crowded on a given weekend, you can swap any stop above with these **BART-adjacent Tiny Whoop gems**:

| BART Station | Walk Time | Spot Name & Address | Vibe & Best Conditions |
| :--- | :---: | :--- | :--- |
| **24th St Mission BART** | 6 mins | **Parque Niños Unidos** (`23rd St & Treat Ave`) or **Garfield Square** (`25th & Harrison`) | Warmest micro-climate in SF; sheltered neighborhood park right down the street from **Southern Pacific Brewing** (`620 Treat Ave`). |
| **16th St Mission BART** | 8 mins | **Mission Dolores Park — South/West Palm Grove** (`19th & Church St`) | Iconic SF views and huge palm trees to orbit. **Best before 1:00 PM** before the lawn gets packed with picnickers—fly only over clear grassy slopes or palm trunks, never over crowded blankets. |
| **Civic Center BART** | 3 mins | **UN Plaza / Fulton Street Mall Columns** (`Market & Hyde / Fulton St`) | Massive granite colonnades and wide paved corridors between the Main Library and Asian Art Museum. Best on **Sunday mornings** when commuter foot traffic is low. |
| **Montgomery St BART** | 4 mins | **560 Mission St Bamboo Plaza (POPOS)** (`560 Mission St & 2nd St`) | Publicly Owned Private Open Space tucked behind high-rises with a dense forest of tall bamboo stalks and benches—completely blocked from wind. |
| **Balboa Park BART** | 2 mins | **Balboa Park North Lawn & Bleachers** (`Ocean Ave & San Jose Ave`) | Right across from the BART station; sunken lawn, concrete bleachers, and cypress trees for fast, open 75mm brushless runs. |

---

## 5. Osito "BART & Whoop" Safety, Legal & Etiquette Rules (Keep It 100% Drama-Free)

To ensure park rangers, BART police, and pedestrians love seeing your group rather than shutting it down:

1. **Strict BART Station No-Fly Rule:** Keep drones **powered off and clipped inside backpacks/cases** while inside BART stations, on escalators, and on trains. Never arm a drone on a BART platform.
2. **Prop-Guards Mandatory (65mm–75mm 1S Only):** Restrict the meetup to **fully ducted 1S Tiny Whoops under 50 grams** (`LILBEAR-65`, `CUB-75`, `SHARD-75`, Meteor65/75, Mobula6/7, AcroBee65). Leave loud open-prop 3"–5" quads at home—a quiet, palm-sized ducted whoop looks like a harmless toy to bystanders and park staff.
3. **The "Buddy Spotter & Spectator Screen" Rule:**
   - Never fly with 100% of the group under goggles at once. Always keep **at least 1–2 pilots goggles-off as active visual spotters** watching for dogs off-leash, toddlers, or security guards.
   - **Pro Move:** Bring one **portable 5.8GHz spectator screen** (or analog receiver plugged into a tablet/phone) on a mini tripod. When curious kids, parents, or park security walk up, hand them the screen so they can see the live cockpit view—99% of the time, potential complaints immediately turn into smiles and *"How do I buy one / book a party?"*
4. **VTX Power & Frequency Discipline:**
   - Lock all pilots to **`25mW` VTX output** (`Pit Mode` until ready to launch) so you don't stomp on each other's video feeds or overheat VTX chips while waiting on benches.
   - Pre-assign 4 clean channels before leaving Stop 1:
     - **Pilot 1:** `Raceband 1 (5658 MHz)`
     - **Pilot 2:** `Raceband 3 (5732 MHz)`
     - **Pilot 3:** `Raceband 6 (5843 MHz)`
     - **Pilot 4:** `Raceband 8 (5917 MHz)`
5. **On-the-Move Backpack Charging Setup:**
   - Carry a **`65W USB-C PD Power Bank` (`20,000mAh`)** plugged into a **`VIFLY WhoopStor V3`** inside a ventilated mesh/Bat-Safe pouch in your backpack. While riding BART between stops (10–15 mins), your charger tops up 6 spent `1S` packs so you have **infinite packs across all 4 hours**.

---

## 6. Copy-Paste Meetup Invite (Discord / Luma / Instagram / SF FPV Group)

> ### 🚁 SF "BART & Whoop" 4-Hour Tiny Whoop Safari — Hosted by Osito Drone
> **When:** `[Day/Date]`, `1:00 PM – 5:00 PM` (Sharp!)  
> **Start Meetup:** **Embarcadero BART** — Meet at the **Sue Bierman Park benches** (Exit A2, Drumm & Washington St) at `1:00 PM`  
> **End Spot:** **Standard Deviant Brewing** (`280 14th St` near 16th St Mission BART) at `4:05 PM` for tabletop micro-gates & beers!  
> **Cost:** **FREE** (Just bring your Clipper Card / tap-to-pay for ~$7 total BART fare)
>
> **The Plan (4 Stops in 4 Hours via BART):**
> - **1:00 PM – 1:50 PM (Stop 1 — Embarcadero BART):** Meetup, VTX channel check (`25mW`), and tree/ledge lines at **Sue Bierman Park & Embarcadero Plaza**.
> - **2:00 PM – 2:50 PM (Stop 2 — Montgomery BART):** Sunken wind-sheltered pergola & bamboo runs around **Yerba Buena Gardens / SoMa POPOS**.
> - **3:05 PM – 3:55 PM (Stop 3 — Glen Park BART):** Endor-style eucalyptus forest slalom & footbridge runs inside **Glen Canyon Park** (3 min walk from BART!).
> - **4:05 PM – 5:00 PM (Stop 4 — 16th St Mission BART):** Finale pints, wall-outlet charging, and micro-gate races at **Standard Deviant Brewing** (or indoor bench session at **Noisebridge**).
>
> **What to Bring (1 Backpack Only!):**
> - **1S Ducted Tiny Whoops ONLY (65mm–75mm, full prop guards required)** — e.g., `Osito LilBear-65`, `Osito Cub-75`, AcroBee65, Meteor65/75, Mobula6/7. *No open-prop quads!*
> - Radio, FPV Goggles, and 8–12+ charged `1S` batteries (bring a USB-C bank + WhoopStor to charge on BART between stops).
> - Clipper Card on your phone.
>
> **RSVP / Questions:** Text/DM Alan or Jesus at **Osito Drone** (`415-571-6614 / 415-810-4158 | www.ositodrone.com | @OSITODroneServices`) — we’ll bring pop-up micro-gates and a live spectator monitor!
