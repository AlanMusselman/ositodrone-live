﻿# Track 1 - November Fast Cash Blitz Machine v2 - REPORT

Built 2026-10-31. Focus: **Osito Drone Academy only** (schools, holiday camps, makerspaces, rec departments), per `Miguel_CEO_5_Day_Action_Orders.md`. Nothing was sent; no one was contacted; `olk.exe` was not launched.

## 1. What I audited (and reused, not duplicated)
| Existing asset | Finding |
|---|---|
| [Miguel_CEO_5_Day_Action_Orders.md](../Team_Playbooks_and_Operations/Miguel_CEO_5_Day_Action_Orders.md) | Source of the Mon Nov 2 - Fri Nov 6 call/walk-in schedule, the 25-second script, and the 3-stations + Pit Crew pitch. Used verbatim. |
| [Miguel_25_School_Outreach_Index.docx](../Team_Playbooks_and_Operations/Miguel/Miguel_25_School_Outreach_Index.docx) + 25 existing .eml drafts (`05_Outbox_Emails/Miguel_CEO_Ready_To_Send_Emails`, `Miguel_WalkIn_and_Expansion_Emails`) | Already cover the **first-touch** email per org. v2 does not rewrite them; v2 adds the **proposal-stage** email + attachment. |
| [November_2026_Fast_Cash_Blitz](../November_2026_Fast_Cash_Blitz) (`Osito_SF_Sales_Leads_Tracker.csv`, Camps & Pop-Ups playbook) | 30 leads with decision makers + the $600 / $960 / $85-seat offers. Merged in; commercial/events rows deliberately left out (Action Orders say Academy only). |
| `02_Web_Apps_and_Tools/osito-field-sales-crm` | 70 seeded accounts, **no CSV import**, localStorage key `osito_crm_accounts_v1`. Its ID series `M/G/S/B/C/R` are taken. M01-M10 `.eml` links pointed at an empty folder (now corrected in the import CSV). |
| COO pricing table, booking calculator, ELO-P kit | Verified price book (see `Price_Book` sheet). |

## 2. What I built
**(a) Master prospect tracker** - 42 organizations, every row cites its source files
- [Master_Prospect_Tracker.xlsx](Master_Prospect_Tracker.xlsx) (README, Master_Tracker, Segment_Summary, Action_Order_Schedule, Cadence, Price_Book, Discrepancy_Log, Sources; live formulas + dropdowns)
- [Master_Prospect_Tracker.csv](Master_Prospect_Tracker.csv)
- [Osito_Field_Sales_CRM_Import_Blitz_v2.csv](Osito_Field_Sales_CRM_Import_Blitz_v2.csv) + [crm_import_snippet.js](crm_import_snippet.js) (paste into the CRM page console; merges by ID, keeps stages/notes, new IDs `A01/A02`)
- Segments: Schools 17, Holiday Camps 7, Makerspaces 11, Rec/Youth Clubs/Venues 7. Verification levels: A = 16, B = 6, C = 6, D = 14.

**(b) Per-segment proposals + emails**
- 4 segment masters in [proposals/segment_masters](proposals/segment_masters)
- 12 org-personalized proposals in [proposals/org_personalized](proposals/org_personalized)
- 12 unsent `.eml` drafts (X-Unsent: 1, From Miguel, Cc Alan, proposal + One-Pager attached, pre-send checklist box) in [05_Outbox_Emails/2026-10-31_Blitz_Machine_v2](../../05_Outbox_Emails/2026-10-31_Blitz_Machine_v2): CDS, Live Oak, SF Day (schools); STEMful, JCCSF, Celsius and Beyond (camps); Mission Science Workshop, Tinkering School, CYC (makerspaces); SF Rec & Parks, Boys & Girls Clubs, YMCA of SF (rec/youth).

**(c) 5-touch sequence** - [Osito_Academy_5_Touch_Follow_Up_Sequence.docx](Osito_Academy_5_Touch_Follow_Up_Sequence.docx): Standard Day 0/2/5/9/14, Holiday Fast-Track Day 0/1/3/5/8 (weekend + Nov 11/26/27 roll forward); call, email, DM, voicemail, break-up scripts per segment; objection answers.

**(d) Daily call-sheet generator** - [generate_daily_call_sheet.py](../../06_Scripts_and_Automation/generate_daily_call_sheet.py) (reads the tracker; AM calls / follow-ups due / PM walk-in route / [VERIFY] watch-list / standup scoreboard; `--week`, `--date`, `--owner`, `--plan`, `--log`). Sample sheets Nov 2-17: [call_sheets](call_sheets).
Supporting builders: [build_blitz_machine_v2.py](../../06_Scripts_and_Automation/build_blitz_machine_v2.py), [blitz_v2_data.py](../../06_Scripts_and_Automation/blitz_v2_data.py), [blitz_v2_docs.py](../../06_Scripts_and_Automation/blitz_v2_docs.py), [blitz_v2_docx.py](../../06_Scripts_and_Automation/blitz_v2_docx.py).

## 3. Verified
- Ran every script; re-ran after the parent's process-kill notice. 129 automated checks pass.
- All 28 docx reload in python-docx; all prices in docs are from the price book; no R&D/commercial terms in proposals (the sequence doc names "roofing" once, only as an exclusion rule).
- All 12 `.eml` parse, carry X-Unsent: 1, both attachments reload as docx, logo CID present.
- Every email and phone in the tracker is traceable to a workspace source file; conflicts flagged, not silently resolved.
- XLSX formulas evaluated with the `formulas` engine: Segment_Summary totals (42 orgs, $134,620 list value) and Next_Touch_Due (Fast-Track T2 = Nov 3; Standard T4 rolls Nov 11 -> Nov 12; DONE after T5).
- Generator `--log` tested on xlsx and csv copies (follow-up chain T1->T5, xlsx validations/freeze panes survive).
- CRM import tested in headless Edge on a copy of the app: 70 -> 72 accounts, 40 updated / 2 added, stages preserved, idempotent, commercial B/C/R accounts untouched. (First test caught an ID collision with the CRM's `B01/B02`; fixed to `A01/A02`.)
- No ffmpeg/video work in this track.

## 4. Known gaps / [VERIFY]
See the `Discrepancy_Log` sheet (18 rows). Top items:
1. **HIGH - 8-week lab price:** COO table/Index/Tracker = PKG-2B $5,600 ($350/student); booking calculator = $280/student; CRM seed values $2,800-$5,040. v2 uses the COO table.
2. **HIGH - Insurance:** docs say only "COI and W-9 available on request". Team audit says the compliance folder (COI/W-9/LiveScan) was not ready. Alan must confirm before any send. No LiveScan claim was made.
3. Party pricing ($200/$400 COO vs $550-$850 calculator), Live Oak Summer Oaks ($4,800 vs $6,800), `$960` naming (Half-Day Guest Block vs PKG-1), Summer-2027 kit pricing (not used).
4. 6 phone conflicts (SF Schoolhouse has 3 numbers; Alta Vista, SPARK, Sports Basement Presidio, SF Rec & Parks, YMCA). 14 extension rows are role-only CRM seed contacts (Level D).
5. Station model: Action Orders (3 stations + staff Pit Crew) differs from the 25 older emls (4 hands-on stations incl. soldering). v2 follows the Action Orders.
6. House of Air reportedly closes Feb 15, 2027 (COO playbook). CRM seed stages (M01/M02 "Contacted", M03 "Demo Booked") have no sent-mail evidence.
7. No social-media handles exist in the workspace, so Touch-3 DMs need a manual handle lookup.
8. Word/LibreOffice not available here, so docx layout was checked structurally (reload, tables, text), not visually. Open one proposal in Word before sending.

## 5. Single next action
**Alan (COO) resolves the two HIGH items - the current 8-week price and a ready COI/W-9 - then Miguel runs `python 06_Scripts_and_Automation/generate_daily_call_sheet.py --date 2026-11-02`, starts the 9:00 AM calls, and only then sends the matching drafts.**

