# Track 2 - Commercial Inspection Sales Kit v2 (for Alan's commercial outreach)

> Positioning note: GEMINI.md and the 5-Day Action Orders make the Youth Drone Academy Miguel's current focus. This kit is Alan's parallel commercial track. Time-box it and do not pitch roofing in Academy conversations.

## Audited (not modified)
- `06_Scripts_and_Automation/generate_b2b_roof_hvac_kit.py` and its outputs in `Commercial_Rate_Cards_and_Plans/2026-10-31_B2B_Roof_and_HVAC_Inspection_Kit/` (rate card, fully-written sample report, 10 named-company .eml)
- `Commercial_Rate_Cards_and_Plans/` (2027 rate card, Municipal/Insurance kit, Security kit and siblings), MSA binder, `osito-b2b-inspection-roi-calculator`, `ositodrone-conversion-funnels/commercial-inspection-booking.html`, Consistency Bible pricing
- 30 existing commercial/GC/adjuster drafts in `05_Outbox_Emails/`

Existing coverage was strong on rate cards and named-company emails. Gaps: no blank report template, no segment-based email variants, no booking-copy rewrite, no objection sheet, no category-based lead plan.

## Built
| Deliverable | Path |
|---|---|
| Read-first: audit, price reconciliation, claims register | [00_READ_FIRST...docx](./00_READ_FIRST_Kit_Overview_Claims_and_Price_Register.docx) |
| Client inspection report template (placeholders, S1-S4 + confidence scale, scope/limits, Part 107/insurance [VERIFY], QA checklist) | [01_Client_Inspection_Report_TEMPLATE.docx](./01_Client_Inspection_Report_TEMPLATE.docx) |
| Cold email variants: contractor / property manager / adjuster | [02_Cold_Email_Variants...docx](./02_Cold_Email_Variants_Contractor_PropertyManager_Adjuster.docx) |
| 6 unsent .eml drafts (X-Unsent: 1, From Alan, To blank) | [05_Outbox_Emails/2026-10-31_Commercial_Inspection_Sales_Kit_v2/](../../05_Outbox_Emails/2026-10-31_Commercial_Inspection_Sales_Kit_v2/) |
| Booking-page copy rewrite (no live edits) | [.docx](./03_Booking_Page_Copy_Rewrite.docx), [.html preview](./03_Booking_Page_Copy_Rewrite.html) |
| Objection-handling sheet (16 objections) | [04_Objection_Handling_Sheet.docx](./04_Objection_Handling_Sheet.docx) |
| Lead-source / outreach plan (categories only) + tracker | [05_Lead_Source_and_Outreach_Plan.docx](./05_Lead_Source_and_Outreach_Plan.docx), [Lead_Tracker_TEMPLATE.csv](./Lead_Tracker_TEMPLATE.csv) |
| Builder scripts | `06_Scripts_and_Automation/build_commercial_inspection_sales_kit_v2.py`, `kit_v2_build_rest.py`, `kit_v2_content.py`, `kit_v2_docx_helpers.py` (reuses `set_cell_shading`/`set_cell_margins` from the existing generator) |

## Verified
- Builder runs clean end to end; all 6 .docx reload in python-docx (logo present, tables counted, tcPr/pPr element order enforced for Word strictness).
- All 6 .eml parse with Python `email`: `X-Unsent: 1`, From alan@ositodrone.com, plain + HTML parts, no To, no attachments. Nothing sent; `olk.exe` not launched.
- Booking HTML rendered in headless Edge (screenshot reviewed): brand tokens, responsive grid, [VERIFY] tags highlighted, logo relative path resolves.
- Not verified: .docx visual rendering (no Word/LibreOffice on this machine); preview form uses `mailto:` only; Fjalla One/Roboto load from Google Fonts online (fallback fonts offline).

## Important findings (see claims register in 00_READ_FIRST)
- Five different roof-scan price books across the workspace; this kit uses the 2027 Rate Card ($245 / $195 trial, ROOF-10 $2,250, HOA-2X $695/yr). **Pick one price book.**
- Existing booking page and sample report state a specific "FAA Part 107 Cert #4829104", "$2M COI" vs "$1M/$2M", a simulated LAANC result, "registration-exempt <249g" (not correct for Part 107 commercial use), and "Part 107 Night waivers". None could be verified; this kit does not repeat them.
- Legal entity named two ways ("Osito Drone LLC d/b/a..." vs "Osito Drone Services LLC").

## Known gaps / [VERIFY] / TBD
Pilot certificate no., COI limits and policy type, legal entity, promo end date, 24-hour delivery capacity, storm-response terms, chain-of-custody process, "we don't sell repairs" position, roof-size cap (25k vs 15k sq ft), ROOF-PM $1,450/qtr (Bible only), insurance-documentation pricing ($450/$895, not on 2027 card), business mailing address (CAN-SPAM), data-retention period, recipient addresses (none included on purpose).

## Single next action
Alan resolves the three blocking items (pilot certificate, COI, legal entity) and picks one price book, then sends the three initial emails to a handful of hand-verified recipients; delete the yellow draft box in each .eml first.
