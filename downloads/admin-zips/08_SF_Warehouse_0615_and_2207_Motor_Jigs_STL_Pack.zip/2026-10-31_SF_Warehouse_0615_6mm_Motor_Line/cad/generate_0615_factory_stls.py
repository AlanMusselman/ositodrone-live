"""
OSITO DRONE LLC — SF Warehouse Multi-Class Motor Factory STL Generator (6mm 0615 to 5-Inch 2207)
Generates 12 watertight binary STL files (Shop Tooling, Brushless Stator Arbors, Magnet Spiders,
and Retail Clamshell Packaging for 0615, 0802, 1404, and 2207 5-Inch Motors) for the 2x Bambu Lab P2S Farm.
"""
import math
import os
import struct

CAD_DIR = os.path.dirname(os.path.abspath(__file__))


def write_binary_stl(filepath: str, triangles: list, header_text: str) -> int:
    header = header_text.encode("ascii", errors="ignore")[:80].ljust(80, b"\x00")
    with open(filepath, "wb") as f:
        f.write(header)
        f.write(struct.pack("<I", len(triangles)))
        for p1, p2, p3 in triangles:
            ux, uy, uz = p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]
            vx, vy, vz = p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            nx, ny, nz = nx / length, ny / length, nz / length
            f.write(
                struct.pack(
                    "<12fH",
                    nx, ny, nz,
                    p1[0], p1[1], p1[2],
                    p2[0], p2[1], p2[2],
                    p3[0], p3[1], p3[2],
                    0,
                )
            )
    return len(triangles)


def make_box(x0, y0, z0, dx, dy, dz):
    x1, y1, z1 = x0 + dx, y0 + dy, z0 + dz
    v = [
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ]
    faces = [
        (0, 2, 1), (0, 3, 2),
        (4, 5, 6), (4, 6, 7),
        (0, 1, 5), (0, 5, 4),
        (1, 2, 6), (1, 6, 5),
        (2, 3, 7), (2, 7, 6),
        (3, 0, 4), (3, 4, 7),
    ]
    return [(v[a], v[b], v[c]) for a, b, c in faces]


def make_tube(cx, cy, z0, z1, r_in, r_out, r_in2=None, r_out2=None, segs=48):
    if r_in2 is None:
        r_in2 = r_in
    if r_out2 is None:
        r_out2 = r_out
    tris = []
    for i in range(segs):
        a0 = 2.0 * math.pi * i / segs
        a1 = 2.0 * math.pi * (i + 1) / segs
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)

        if r_in <= 1e-6 and r_in2 <= 1e-6:
            b_center = (cx, cy, z0)
            t_center = (cx, cy, z1)
            b0 = (cx + r_out * c0, cy + r_out * s0, z0)
            b1 = (cx + r_out * c1, cy + r_out * s1, z0)
            t0 = (cx + r_out2 * c0, cy + r_out2 * s0, z1)
            t1 = (cx + r_out2 * c1, cy + r_out2 * s1, z1)
            tris.append((b_center, b1, b0))
            tris.append((t_center, t0, t1))
            tris.append((b0, b1, t1))
            tris.append((b0, t1, t0))
        else:
            bi0 = (cx + r_in * c0, cy + r_in * s0, z0)
            bi1 = (cx + r_in * c1, cy + r_in * s1, z0)
            bo0 = (cx + r_out * c0, cy + r_out * s0, z0)
            bo1 = (cx + r_out * c1, cy + r_out * s1, z0)

            ti0 = (cx + r_in2 * c0, cy + r_in2 * s0, z1)
            ti1 = (cx + r_in2 * c1, cy + r_in2 * s1, z1)
            to0 = (cx + r_out2 * c0, cy + r_out2 * s0, z1)
            to1 = (cx + r_out2 * c1, cy + r_out2 * s1, z1)

            tris.append((bi0, bo1, bo0))
            tris.append((bi0, bi1, bo1))
            tris.append((ti0, to0, to1))
            tris.append((ti0, to1, ti1))
            tris.append((bo0, bo1, to1))
            tris.append((bo0, to1, to0))
            tris.append((bi0, ti1, bi1))
            tris.append((bi0, ti0, ti1))
    return tris


def build_all_stls():
    outputs = []

    # 1. PAHT-CF 5-Lobe Skewed Rhombic Coil Winding & 155C Curing Mandrel (0615)
    t1 = []
    t1 += make_tube(0, 0, 0.0, 12.0, 0.50, 5.00, segs=64)
    t1 += make_tube(0, 0, 12.0, 14.5, 0.50, 7.00, segs=64)
    for i in range(5):
        ang = 2.0 * math.pi * i / 5.0
        px, py = 5.8 * math.cos(ang), 5.8 * math.sin(ang)
        t1 += make_tube(px, py, 14.5, 16.5, 0.0, 0.60, segs=16)
    t1 += make_tube(0, 0, 14.5, 25.7, 0.50, 1.925, segs=64)
    t1 += make_tube(0, 0, 25.7, 29.7, 0.50, 1.60, segs=64)
    f1 = os.path.join(CAD_DIR, "1_PAHTCF_0615_5Lobe_Rhombic_Coil_Winding_Mandrel.stl")
    n1 = write_binary_stl(f1, t1, "OSITO PAHT-CF 0615 5-Lobe Rhombic Winding Mandrel")
    outputs.append((os.path.basename(f1), n1))

    # 2. eSUN PLA+ 4-Up 0615 Can & Endbell Press Fixture (18.0mm pitch)
    t2 = []
    t2 += make_box(-40, -16, 0.0, 80, 32, 6.5)
    for i in range(4):
        xp = -27.0 + i * 18.0
        t2 += make_tube(xp, 0, 6.5, 20.0, 3.05, 8.50, segs=48)
    f2 = os.path.join(CAD_DIR, "2_PLAPlus_0615_4Up_Can_and_Endbell_Press_Fixture.stl")
    n2 = write_binary_stl(f2, t2, "OSITO PLA+ 4-Up 0615 Can and Endbell Press Block")
    outputs.append((os.path.basename(f2), n2))

    # 3. eSUN PLA+ 0615 Brush-Spreader Fork & 4.50mm Shaft Gauge
    t3 = []
    t3 += make_box(-25, -8, 0.0, 50, 16, 4.0)
    t3 += make_box(15, -5, 4.0, 14, 3.8, 4.0)
    t3 += make_box(15, 1.2, 4.0, 14, 3.8, 4.0)
    t3 += make_tube(-18, 0, 4.0, 8.5, 0.55, 3.50, segs=36)
    f3 = os.path.join(CAD_DIR, "3_PLAPlus_0615_Brush_Spreader_Fork_and_Shaft_Gauge.stl")
    n3 = write_binary_stl(f3, t3, "OSITO PLA+ 0615 Brush Spreader Fork & Shaft Gauge")
    outputs.append((os.path.basename(f3), n3))

    # 4. eSUN PLA+ N52H/N52SH Magnet Polarity Wand & Cockroach 65 Pod/Prop Press
    t4 = []
    t4 += make_tube(0, 0, 0.0, 3.2, 3.08, 6.00, segs=48)
    t4 += make_tube(0, 0, 3.2, 58.0, 0.0, 6.00, segs=48)
    t4 += make_tube(0, 0, 58.0, 61.5, 0.0, 12.00, segs=48)
    t4 += make_tube(0, 0, 61.5, 65.0, 3.10, 12.00, segs=48)
    f4 = os.path.join(CAD_DIR, "4_PLAPlus_N52H_Magnet_Polarity_and_Cockroach65_Pod_Press.stl")
    n4 = write_binary_stl(f4, t4, "OSITO PLA+ N52H Polarity Wand & Cockroach 65 Press")
    outputs.append((os.path.basename(f4), n4))

    # 5. Bambu PETG-CF 4-Channel Break-In & Laser KV Optical Test Stand
    t5 = []
    t5 += make_box(-55, -22, 0.0, 110, 44, 6.0)
    t5 += make_box(-50, -14, 6.0, 12, 28, 12.0)
    t5 += make_box(38, -14, 6.0, 12, 28, 12.0)
    t5 += make_box(-50, -10, 18.0, 100, 20, 4.0)
    for i in range(4):
        xp = -33.0 + i * 22.0
        t5 += make_tube(xp, 0, 22.0, 34.5, 3.05, 4.50, segs=48)
    f5 = os.path.join(CAD_DIR, "5_PETGCF_4Channel_BreakIn_and_Laser_KV_Test_Stand.stl")
    n5 = write_binary_stl(f5, t5, "OSITO PETG-CF 4-Ch 0615 Break-In & KV Test Stand")
    outputs.append((os.path.basename(f5), n5))

    # 6. Bambu TPU 95A HF Cockroach 65 Strain-Relief Endbell Boots (8-Pack)
    t6 = []
    for row in range(2):
        for col in range(4):
            cx, cy = col * 12.0, row * 12.0
            t6 += make_tube(cx, cy, 0.0, 4.5, 2.975, 3.70, segs=40)
            t6 += make_tube(cx, cy, 4.5, 8.0, 1.10, 3.70, 1.10, 1.80, segs=40)
    f6 = os.path.join(CAD_DIR, "6_TPU95AHF_Cockroach65_0615_StrainRelief_Endbell_Boots_x8.stl")
    n6 = write_binary_stl(f6, t6, "OSITO TPU 95A HF 0615 Strain Relief Boots x8")
    outputs.append((os.path.basename(f6), n6))

    # 7. eSUN PLA+ 0615/0802 Micro Quad Retail Clamshell Tray (96.0 x 84.0 x 11.0 mm, 18.0mm pitch)
    t7 = []
    t7 += make_box(-48.0, -42.0, 0.0, 96.0, 84.0, 2.5)
    t7 += make_box(-48.0, -42.0, 2.5, 6.0, 84.0, 8.5)
    t7 += make_box(42.0, -42.0, 2.5, 6.0, 84.0, 8.5)
    t7 += make_box(-42.0, 36.0, 2.5, 84.0, 6.0, 8.5)
    t7 += make_box(-42.0, -42.0, 2.5, 84.0, 4.0, 8.5)
    for rx in [-36.0, -18.0, 0.0, 18.0, 36.0]:
        t7 += make_box(rx - 2.5, 9.5, 2.5, 5.0, 19.0, 7.0)
        t7 += make_box(rx - 1.5, -28.0, 2.5, 3.0, 32.0, 6.0)
    t7 += make_tube(0.0, -34.0, 2.5, 10.0, 0.0, 0.48, segs=24)
    f7 = os.path.join(CAD_DIR, "7_PLAPlus_0615_Quad_Retail_Clamshell_Tray.stl")
    n7 = write_binary_stl(f7, t7, "OSITO PLA+ 0615 & 0802 Micro Quad Retail Clamshell Tray")
    outputs.append((os.path.basename(f7), n7))

    # 8. eSUN PLA+ 0615/0802 Micro Quad Retail Clamshell Snap-Lid (96.0 x 84.0 x 7.5 mm)
    t8 = []
    t8 += make_box(-48.0, -42.0, 4.5, 96.0, 84.0, 2.5)
    t8 += make_box(-48.0, -42.0, 0.0, 2.0, 84.0, 4.5)
    t8 += make_box(46.0, -42.0, 0.0, 2.0, 84.0, 4.5)
    t8 += make_box(-46.0, 40.0, 0.0, 92.0, 2.0, 4.5)
    t8 += make_box(-46.0, -42.0, 0.0, 92.0, 2.0, 4.5)
    t8 += make_box(-48.0, -42.0, 7.0, 96.0, 13.0, 0.5)
    t8 += make_box(-48.0, 16.5, 7.0, 96.0, 25.5, 0.5)
    t8 += make_box(-48.0, -29.0, 7.0, 12.8, 45.5, 0.5)
    t8 += make_box(35.2, -29.0, 7.0, 12.8, 45.5, 0.5)
    f8 = os.path.join(CAD_DIR, "8_PLAPlus_0615_Quad_Retail_Clamshell_SnapLid.stl")
    n8 = write_binary_stl(f8, t8, "OSITO PLA+ 0615 & 0802 Quad Clamshell SnapLid")
    outputs.append((os.path.basename(f8), n8))

    # 9. Bambu PETG-CF 20-Motor (5-Quad) SF Warehouse WIP Kanban Tote (112.0 x 118.0 x 96.0 mm)
    t9 = []
    t9 += make_box(-56.0, -59.0, 0.0, 112.0, 118.0, 3.0)
    t9 += make_box(-56.0, -59.0, 3.0, 3.0, 118.0, 93.0)
    t9 += make_box(53.0, -59.0, 3.0, 3.0, 118.0, 93.0)
    t9 += make_box(-53.0, -59.0, 3.0, 106.0, 3.0, 93.0)
    t9 += make_box(-53.0, 56.0, 3.0, 106.0, 3.0, 93.0)
    for dy in [-30.0, -10.0, 10.0, 30.0]:
        t9 += make_box(-53.0, dy - 1.0, 3.0, 10.0, 2.0, 85.0)
        t9 += make_box(43.0, dy - 1.0, 3.0, 10.0, 2.0, 85.0)
    f9 = os.path.join(CAD_DIR, "9_PETGCF_20Quad_SF_Warehouse_WIP_Kanban_Tote.stl")
    n9 = write_binary_stl(f9, t9, "OSITO PETG-CF 20-Motor 5-Quad SF Warehouse Kanban Tote")
    outputs.append((os.path.basename(f9), n9))

    # 10. PAHT-CF Multi-Class Brushless Stator Winding Arbors (0802 9N, 1404 9N/12N, 2207 12N)
    t10 = []
    # 0802 Arbor (x=-28): 10mm chuck + 9-tooth index plate + 3.45mm ID stator core post
    t10 += make_tube(-28.0, 0.0, 0.0, 12.0, 0.80, 5.00, segs=48)
    t10 += make_tube(-28.0, 0.0, 12.0, 14.5, 0.80, 6.50, segs=9)
    t10 += make_tube(-28.0, 0.0, 14.5, 19.5, 0.80, 1.72, segs=36)
    # 1404 Arbor (x=0): 10mm chuck + 9/12-tooth index plate + 5.95mm ID stator core post
    t10 += make_tube(0.0, 0.0, 0.0, 12.0, 1.00, 5.00, segs=48)
    t10 += make_tube(0.0, 0.0, 12.0, 15.0, 1.00, 8.50, segs=12)
    t10 += make_tube(0.0, 0.0, 15.0, 22.0, 1.00, 2.97, segs=48)
    # 2207 5-Inch Arbor (x=+32): 10mm chuck + 12-tooth dLRK index plate + 8.95mm ID stator post
    t10 += make_tube(32.0, 0.0, 0.0, 12.0, 1.50, 5.00, segs=48)
    t10 += make_tube(32.0, 0.0, 12.0, 15.5, 1.50, 12.50, segs=12)
    t10 += make_tube(32.0, 0.0, 15.5, 25.5, 1.50, 4.47, segs=48)
    f10 = os.path.join(CAD_DIR, "10_PAHTCF_MultiClass_0802_1404_2207_Stator_Winding_Arbors.stl")
    n10 = write_binary_stl(f10, t10, "OSITO PAHT-CF Multi-Class Brushless Stator Winding Arbors")
    outputs.append((os.path.basename(f10), n10))

    # 11. PAHT-CF 12P (0802/1404) & 14P (2207 5-Inch) N52SH Magnet Bell Gluing Spiders
    t11 = []
    # 12P Spider for 0802/1404 (x=-22)
    t11 += make_tube(-22.0, 0.0, 0.0, 3.0, 1.00, 9.00, segs=48)
    t11 += make_tube(-22.0, 0.0, 3.0, 9.5, 1.00, 5.20, segs=12)
    # 14P Spider for 2207 5-Inch Bell (x=+22): spaces 14 curved N52SH arc magnets at exact 25.71 deg
    t11 += make_tube(22.0, 0.0, 0.0, 4.0, 2.00, 15.50, segs=56)
    t11 += make_tube(22.0, 0.0, 4.0, 13.5, 2.00, 9.80, segs=14)
    for p in range(14):
        ang = 2.0 * math.pi * p / 14.0
        rx, ry = 22.0 + 10.6 * math.cos(ang), 10.6 * math.sin(ang)
        t11 += make_tube(rx, ry, 4.0, 13.5, 0.0, 0.45, segs=12)
    f11 = os.path.join(CAD_DIR, "11_PAHTCF_12P_14P_N52SH_Magnet_Bell_Gluing_Spiders.stl")
    n11 = write_binary_stl(f11, t11, "OSITO PAHT-CF 12P & 14P N52SH Magnet Bell Gluing Spiders")
    outputs.append((os.path.basename(f11), n11))

    # 12. eSUN PLA+ Macro 1404 & 2207 (5-Inch) 4-Motor Quad Clamshell Tray (148 x 136 x 38 mm, 38mm pitch)
    t12 = []
    t12 += make_box(-74.0, -68.0, 0.0, 148.0, 136.0, 3.5)         # Heavy-duty 3.5mm floor
    t12 += make_box(-74.0, -68.0, 3.5, 5.0, 136.0, 34.5)          # Left wall
    t12 += make_box(69.0, -68.0, 3.5, 5.0, 136.0, 34.5)           # Right wall
    t12 += make_box(-69.0, 63.0, 3.5, 138.0, 5.0, 34.5)           # Back wall
    t12 += make_box(-69.0, -68.0, 3.5, 138.0, 5.0, 34.5)          # Front wall
    # 4x 2207 5-Inch Motor Base Saddles (2x2 array at +/-32mm X, +/-28mm Y -> 64mm/56mm pitch < 0.01N dipole pull)
    for sx in [-32.0, 32.0]:
        for sy in [-28.0, 28.0]:
            # Outer 28.2mm bell socket w/ stepped 14.0mm base shoulder (leaves M5 prop shaft suspended in air!)
            t12 += make_tube(sx, sy, 3.5, 22.0, 14.10, 18.50, segs=48)
            # Inner 16mm M3 bolt pattern pedestal with center hollow-shaft clearance
            t12 += make_tube(sx, sy, 3.5, 9.0, 4.50, 14.10, segs=48)
    f12 = os.path.join(CAD_DIR, "12_PLAPlus_1404_2207_5Inch_Quad_Retail_Clamshell_Tray.stl")
    n12 = write_binary_stl(f12, t12, "OSITO PLA+ 1404 & 2207 5-Inch Quad Clamshell Tray 148x136x38mm")
    outputs.append((os.path.basename(f12), n12))

    return outputs


if __name__ == "__main__":
    results = build_all_stls()
    for name, count in results:
        print(f"[OK] {name}: {count} triangles")
