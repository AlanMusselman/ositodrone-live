// ============================================================================
// OSITO DRONE LLC — SAN FRANCISCO WAREHOUSE 0615 (6x15mm) CORELESS MOTOR LINE
// Parametric OpenSCAD Tooling, Fixture & Packaging Suite (2x Bambu Lab P2S Farm)
// ============================================================================
// Strictly adheres to Osito Master 4-Tier Filament Discipline:
//   1. Bambu PETG-CF (P2S #1 AMS Slot 1)  -> #5 4-Ch Break-In & KV Stand (x6 Racks)
//                                            #9 20-Motor (5-Quad) SF WIP Kanban Tote
//   2. Bambu PAHT-CF (P2S #1 AMS Slot 2)  -> #1 155C 5-Lobe Rhombic Winding Mandrel
//   3. eSUN PLA+     (P2S #1 AMS Slot 3)  -> #2 4-Up Press Block, #3 Brush Spreader Fork,
//                                            #4 N52H Polarity Wand & Cockroach 65 Press,
//                                            #7 Cockroach 65 Quad Retail Clamshell Tray,
//                                            #8 Cockroach 65 Quad Retail Clamshell Snap-Lid
//   4. Bambu TPU 95A HF (P2S #2 Ext Port) -> #6 Cockroach 65 Anti-Rip Endbell Boots (x8)
// ============================================================================

PART_SELECT = "ALL"; // "ALL", "MANDREL", "PRESS_BLOCK", "BRUSH_FORK", "POD_PRESS", "KV_STAND", "TPU_BOOTS", "PACK_TRAY", "PACK_LID", "KANBAN_TOTE"
$fn = 64;

// --- Exact 0615 (6.0 x 15.0 mm) Cockroach 65 Coreless Motor Constants ---
motor_od         = 6.00;   // Drawn nickel-plated steel can OD (mm)
motor_slip_id    = 6.10;   // Slip-fit jig pocket ID (mm)
motor_can_h      = 15.00;  // Can length (mm)
shaft_d          = 1.00;   // Hardened SUS420J2 shaft diameter (mm) (0.80mm optional)
shaft_Command_h  = 4.50;   // Exposed top shaft length for 31mm prop boss (mm)
basket_id        = 3.85;   // Coreless 5-lobe rhombic copper basket ID (mm)
basket_od        = 4.85;   // Coreless 5-lobe rhombic copper basket OD (mm)
basket_h         = 11.20;  // Coreless basket length (mm)
comm_od          = 1.80;   // 5-segment AgPd commutator OD (mm)
brush_shim_t     = 0.20;   // Bifurcated brush spreader feeler thickness (mm)

// ============================================================================
// 1. PAHT-CF (P2S #1 AMS Slot 2): 5-Lobe Skewed Rhombic Winding & Curing Mandrel
// ============================================================================
module pahtcf_rhombic_winding_mandrel() {
    union() {
        cylinder(d = 10.0, h = 12.0);
        translate([0, 0, 12.0])
        difference() {
            cylinder(d = 14.0, h = 2.5);
            for (i = [0:4]) {
                rotate([0, 0, i * 72])
                    translate([5.5, -0.6, -0.1])
                        cube([3.0, 1.2, 2.7]);
            }
        }
        translate([0, 0, 14.5])
            cylinder(d = basket_id, h = basket_h);
        translate([0, 0, 14.5 + basket_h])
            cylinder(d = 3.20, h = 4.0);
    }
}

// ============================================================================
// 2. eSUN PLA+ (P2S #1 AMS Slot 3): 4-Up 0615 Can & Endbell Press Block
// ============================================================================
module plaplus_4up_press_block() {
    difference() {
        translate([-40, -16, 0])
            cube([80, 32, 20]);
        for (i = [0:3]) {
            xp = -27 + i * 18;
            translate([xp, 0, -0.1])
                cylinder(d = 2.40, h = 7.2);
            translate([xp, 0, 6.5])
                cylinder(d = motor_slip_id, h = 14.0);
            translate([xp - 1.5, -16.1, 14.0])
                cube([3.0, 16.5, 6.5]);
        }
    }
}

// ============================================================================
// 3. eSUN PLA+ (P2S #1 AMS Slot 3): Bifurcated Brush-Spreader Fork & Shaft Gauge
// ============================================================================
module plaplus_brush_spreader_fork() {
    difference() {
        union() {
            translate([-25, -8, 0])
                cube([50, 16, 4.0]);
            translate([15, -5, 0])
                cube([14, 10, 8.0]);
        }
        translate([22, 0, 4.0])
            cylinder(d = 6.15, h = 5.0);
        translate([10, -0.15, 2.0])
            cube([20, 0.30, 6.5]);
        translate([-18, 0, -0.1])
            cylinder(d = 1.20, h = shaft_Command_h + 0.1);
    }
}

// ============================================================================
// 4. eSUN PLA+ (P2S #1 AMS Slot 3): N52H Polarity Wand & Cockroach 65 Pod Press
// ============================================================================
module plaplus_polarity_and_pod_press() {
    difference() {
        union() {
            cylinder(d = 12.0, h = 65.0);
            translate([0, 0, 58.0])
                cylinder(d = 24.0, h = 7.0);
        }
        translate([0, 0, -0.1])
            cylinder(d = 6.15, h = 3.2);
        translate([0, 0, 61.5])
            cylinder(d = 6.20, h = 3.6);
    }
}

// ============================================================================
// 5. Bambu PETG-CF (P2S #1 AMS Slot 1): 4-Channel 1.8V Break-In & Laser KV Stand
// ============================================================================
module petgcf_4ch_breakin_kv_stand() {
    difference() {
        union() {
            translate([-55, -22, 0])
                cube([110, 44, 6]);
            translate([-48, -10, 6])
                cube([96, 20, 22]);
        }
        for (i = [0:3]) {
            xp = -33 + i * 22;
            translate([xp, 0, 14.0])
                cylinder(d = motor_slip_id, h = 15.0);
            translate([xp, 0, -0.1])
                cylinder(d = 4.80, h = 15.0);
            translate([xp - 1.5, -23, 22.0])
                cube([3.0, 46, 4.0]);
        }
    }
}

// ============================================================================
// 6. Bambu TPU 95A HF (P2S #2 External Dryer Port): Cockroach 65 Strain-Relief Boots
// ============================================================================
module tpu95a_strain_relief_boots_x8() {
    for (row = [0:1]) {
        for (col = [0:3]) {
            translate([col * 12.0, row * 12.0, 0])
            difference() {
                union() {
                    cylinder(d = 7.40, h = 4.5);
                    translate([0, 0, 4.5])
                        cylinder(d1 = 7.40, d2 = 3.60, h = 3.5);
                }
                translate([0, 0, -0.1])
                    cylinder(d = 5.95, h = 4.6);
                translate([0, 0, 4.4])
                    cylinder(d = 2.20, h = 3.8);
            }
        }
    }
}

// ============================================================================
// 7. eSUN PLA+ (P2S #1 AMS Slot 3): Cockroach 65 4-Motor Quad Retail Clamshell Tray
//    96.0 x 64.0 x 10.5 mm | 20.0mm Y-Pitch (<0.016N magnetic dipole force)
//    Suspended Can-Shoulder Cradle w/ Zero-Contact Shaft Vault & JST-1.25 Parking
// ============================================================================
module plaplus_0615_quad_retail_clamshell_tray() {
    difference() {
        // Outer Clamshell Tray Body (96 x 64 x 10.5 mm)
        translate([-48, -32, 0])
            cube([96.0, 64.0, 10.5]);

        // 4x Suspended 0615 Motor Cradles (M4 FL, M2 FR, M3 RL, M1 RR)
        // Y = +/-10.0mm (20.0mm pitch), X = +/-31.0mm
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * 31.0, sy * 10.0, 6.5]) {
                    // Clamped 6.05mm x 15.0mm steel can saddle
                    rotate([0, sx * 90, 0])
                        cylinder(d = 6.05, h = 15.0, center = true);
                    // Outer Zero-Contact Shaft Air Vault (5.0mm D x 6.0mm L)
                    translate([sx * 10.5, 0, 0])
                        rotate([0, sx * 90, 0])
                            cylinder(d = 5.00, h = 6.0, center = true);
                    // Inner Zero-Contact TPU Boot Vault (8.0mm D x 8.5mm L)
                    translate([-sx * 11.5, 0, 0])
                        rotate([0, sx * 90, 0])
                            cylinder(d = 8.00, h = 8.5, center = true);
                }
                // 38mm Silicone Wire Routing Trough & JST-1.25mm Plug Parking Pocket
                translate([sx * 14.0 - 2.2, sy * 10.0 - 1.7, 5.5])
                    cube([4.4, 3.4, 5.5]);
            }
        }
        // Center Spare 31mm Prop & M2 Screw Compartment (24 x 44 x 8.5 mm)
        translate([-12.0, -22.0, 2.0])
            cube([24.0, 44.0, 9.0]);
    }
    // Center 0.95mm Spare 31mm Prop Retention Post
    translate([0, 0, 2.0])
        cylinder(d = 0.95, h = 7.5);
}

// ============================================================================
// 8. eSUN PLA+ (P2S #1 AMS Slot 3): Cockroach 65 Quad Retail Clamshell Snap-Lid
//    96.0 x 64.0 x 6.5 mm | 4x Shaft Inspection Windows + 70x45mm QR Label Recess
// ============================================================================
module plaplus_0615_quad_retail_clamshell_snaplid() {
    difference() {
        // Outer Snap-Lid Shell (96 x 64 x 6.5 mm)
        translate([-48, -32, 0])
            cube([96.0, 64.0, 6.5]);

        // Underside Relief Cavity (92 x 60 x 4.5 mm)
        translate([-46, -30, -0.1])
            cube([92.0, 60.0, 4.6]);

        // Top Recessed 70 x 45 x 0.40 mm QR / KV-Binning Thermal Label Pocket
        translate([-35.0, -22.5, 6.1])
            cube([70.0, 45.0, 0.5]);

        // 4x 4.0mm Optical Shaft Inspection Windows over the Shaft Air Vaults
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * 41.5, sy * 10.0, -0.1])
                    cylinder(d = 4.0, h = 7.0);
            }
        }
    }
}

// ============================================================================
// 9. Bambu PETG-CF (P2S #1 AMS Slot 1): 20-Motor (5-Quad) SF Warehouse Kanban Tote
//    190.0 x 112.0 x 76.0 mm | Holds 5 Closed Quad Clamshells on 34.0mm Pitch
// ============================================================================
module petgcf_20quad_sf_warehouse_kanban_tote() {
    difference() {
        // Heavy-duty stackable shop tote body (190 x 112 x 76 mm)
        translate([-95, -56, 0])
            cube([190.0, 112.0, 76.0]);

        // 5x Vertical Quad Clamshell Slots (34.0mm X-pitch, 16.0 x 98.0 x 72.0 mm)
        for (i = [0:4]) {
            xp = -68.0 + i * 34.0;
            translate([xp - 8.0, -49.0, 4.0])
                cube([16.0, 98.0, 73.0]);
        }
        // Top Finger-Grip Access Cutout along front/back walls
        translate([-80, -57, 48.0])
            cube([160.0, 114.0, 29.0]);
    }
}

// ============================================================================
// 10. Bambu PAHT-CF (P2S #1 AMS Slot 2): Multi-Class 0802 / 1404 / 2207 Stator Arbors
//     ER16 10.0mm Collet Shanks + Precision Stator Bore Pilots (9N & 12N Tooth Keys)
// ============================================================================
module pahtcf_multiclass_stator_winding_arbors() {
    // 0802 (3.5mm ID, 9N), 1404 (5.0mm ID, 9N), 2207 (8.0mm ID, 12N)
    stator_ids = [3.48, 4.98, 7.98];
    stator_hs  = [4.5,  6.5,  9.5];
    flange_ods = [7.6,  12.5, 19.5];
    for (idx = [0:2]) {
        translate([(idx - 1) * 28.0, 0, 0]) {
            cylinder(d = 10.0, h = 14.0);
            translate([0, 0, 14.0])
                cylinder(d = flange_ods[idx], h = 2.5);
            translate([0, 0, 16.5])
                cylinder(d = stator_ids[idx], h = stator_hs[idx]);
        }
    }
}

// ============================================================================
// 11. Bambu PAHT-CF (P2S #1 AMS Slot 2): 12P (0802/1404) & 14P (2207) N52SH Bell Spiders
//     155C Epoxy Curing Fixtures for 30.0 deg (12P) & 25.714 deg (14P) Arc Magnets
// ============================================================================
module pahtcf_12p_14p_magnet_bell_spiders() {
    // 12P Spider (0802/1404) at X = -20, 14P Spider (2207) at X = +20
    translate([-20.0, 0, 0]) {
        cylinder(d = 16.0, h = 3.0);
        translate([0, 0, 3.0]) cylinder(d = 8.20, h = 6.0);
        for (k = [0:11])
            rotate([0, 0, k * 30.0])
                translate([3.8, -0.30, 3.0]) cube([1.2, 0.60, 6.0]);
    }
    translate([20.0, 0, 0]) {
        cylinder(d = 30.0, h = 3.5);
        translate([0, 0, 3.5]) cylinder(d = 21.80, h = 8.5);
        for (k = [0:13])
            rotate([0, 0, k * (360.0 / 14.0)])
                translate([10.2, -0.45, 3.5]) cube([1.8, 0.90, 8.5]);
    }
}

// ============================================================================
// 12. eSUN PLA+ (P2S #1 AMS Slot 3): 1404 & 2207 (5-Inch) Macro Quad Clamshell Tray
//     148.0 x 136.0 x 26.0 mm | 2x2 Matrix at 54.0mm Pitch (<0.011N dipole pull)
//     Stepped 28.0mm (2207) & 18.2mm (1404) Bell Pockets + Zero-Contact M5 Shaft Vault
// ============================================================================
module plaplus_1404_2207_macro_quad_clamshell_tray() {
    difference() {
        translate([-74.0, -68.0, 0])
            cube([148.0, 136.0, 26.0]);
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * 27.0, sy * 27.0, 0]) {
                    // Upper 2207 Bell Pocket (28.0mm ID)
                    translate([0, 0, 12.0]) cylinder(d = 28.0, h = 15.0);
                    // Lower Stepped 1404 Bell Pocket (18.2mm ID)
                    translate([0, 0, 6.5])  cylinder(d = 18.2, h = 6.0);
                    // Zero-Contact M5 Shaft & Rear Screw Air Vault (10.5mm ID)
                    translate([0, 0, 2.0])  cylinder(d = 10.5, h = 5.0);
                }
            }
        }
        // Center Hardware Vault for 4x M5 Nyloc Nuts + 16x M3x8 Screws
        translate([-11.0, -24.0, 4.0])
            cube([22.0, 48.0, 23.0]);
    }
}

// --- Master Render Dispatcher ---
if (PART_SELECT == "MANDREL")               pahtcf_rhombic_winding_mandrel();
else if (PART_SELECT == "PRESS_BLOCK")      plaplus_4up_press_block();
else if (PART_SELECT == "BRUSH_FORK")       plaplus_brush_spreader_fork();
else if (PART_SELECT == "POD_PRESS")        plaplus_polarity_and_pod_press();
else if (PART_SELECT == "KV_STAND")         petgcf_4ch_breakin_kv_stand();
else if (PART_SELECT == "TPU_BOOTS")        tpu95a_strain_relief_boots_x8();
else if (PART_SELECT == "PACK_TRAY")        plaplus_0615_quad_retail_clamshell_tray();
else if (PART_SELECT == "PACK_LID")         plaplus_0615_quad_retail_clamshell_snaplid();
else if (PART_SELECT == "KANBAN_TOTE")      petgcf_20quad_sf_warehouse_kanban_tote();
else if (PART_SELECT == "STATOR_ARBORS")    pahtcf_multiclass_stator_winding_arbors();
else if (PART_SELECT == "MAGNET_SPIDERS")   pahtcf_12p_14p_magnet_bell_spiders();
else if (PART_SELECT == "MACRO_5IN_TRAY")   plaplus_1404_2207_macro_quad_clamshell_tray();
else {
    translate([-60, 45, 0])   pahtcf_rhombic_winding_mandrel();
    translate([0, 45, 0])     plaplus_4up_press_block();
    translate([65, 45, 0])    plaplus_brush_spreader_fork();
    translate([-60, -15, 0])  plaplus_polarity_and_pod_press();
    translate([0, -15, 0])    petgcf_4ch_breakin_kv_stand();
    translate([65, -15, 0])   tpu95a_strain_relief_boots_x8();
    translate([-65, -85, 0])  plaplus_0615_quad_retail_clamshell_tray();
    translate([55, -85, 0])   plaplus_0615_quad_retail_clamshell_snaplid();
    translate([0, -175, 0])   petgcf_20quad_sf_warehouse_kanban_tote();
    translate([-135, -175, 0]) pahtcf_multiclass_stator_winding_arbors();
    translate([135, -175, 0])  pahtcf_12p_14p_magnet_bell_spiders();
    translate([0, -295, 0])    plaplus_1404_2207_macro_quad_clamshell_tray();
}
