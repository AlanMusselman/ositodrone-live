"""
Unit Tests for OSITO SF Warehouse 0615 (6x15mm) Coreless Motor Line
Verifies:
  1. 5-Lobe Skewed Rhombic Coil Winder kinematics & resistance targets (0.42 - 0.58 Ohm)
  2. 16-bit unsigned millisecond rollover-safe watchdog & timing arithmetic
  3. Disarmed safety interlocks, acrylic guard interlock, and over-current / thermal trips
  4. Cockroach 65 KV quad-matching binning acceptance criteria
  5. 7-Station Little's Law parallel rack sizing (6 racks @ Station 6 -> 140s Takt / 25.71 quads/hr)
  6. Station 7 Packaging magnetic dipole isolation (18.0mm pitch < 0.050N) & QR label serialization
"""
import unittest
from osito_0615_winder_and_kv_tester import (
    RhombicCoilSpec,
    BrushlessOutrunnerSpec,
    MotorChannelTelemetry,
    SFWarehouse0615TestBenchController,
    SFWarehouse7StationFlowModel,
    QuadPackPackagingAndSerializer,
    calculate_multiclass_fleet_savings,
    simulate_3engine_us_factory_pnl,
    elapsed_u16_ms,
)


class TestSFWarehouse0615MotorLine(unittest.TestCase):
    def test_16bit_millisecond_rollover_safety(self):
        self.assertEqual(elapsed_u16_ms(100, 65500), 136)
        self.assertEqual(elapsed_u16_ms(0, 65535), 1)
        self.assertEqual(elapsed_u16_ms(5000, 4500), 500)

    def test_rhombic_coil_specs_and_cnc_waypoints(self):
        spec_gold = RhombicCoilSpec(turns_per_lobe=13)
        self.assertEqual(spec_gold.total_turns, 65)
        rm_gold = spec_gold.estimate_phase_resistance_ohms()
        self.assertTrue(0.42 <= rm_gold <= 0.58, f"Unexpected Rm: {rm_gold}")

        wps = spec_gold.generate_cnc_winding_waypoints()
        self.assertEqual(len(wps), 135)
        taps = [w for w in wps if w["commutator_tap"] > 0]
        self.assertEqual(len(taps), 5)

    def test_disarmed_and_guard_safety_interlocks(self):
        bench = SFWarehouse0615TestBenchController(acrylic_guard_closed=False)
        self.assertFalse(bench.arm_bench(now_ms=1000))
        channels = [MotorChannelTelemetry(channel_id=i, voltage_v=1.8, current_a=0.08) for i in range(1, 5)]
        duties = bench.step_control_loop(1050, 1.80, 5.0, channels)
        self.assertEqual(duties, [0.0, 0.0, 0.0, 0.0])

        bench.acrylic_guard_closed = True
        self.assertTrue(bench.arm_bench(now_ms=1000))
        duties_armed = bench.step_control_loop(1200, 1.80, 5.0, channels)
        self.assertEqual(duties_armed, [0.36, 0.36, 0.36, 0.36])

    def test_watchdog_timeout_across_16bit_rollover(self):
        bench = SFWarehouse0615TestBenchController(acrylic_guard_closed=True, watchdog_timeout_ms=500)
        self.assertTrue(bench.arm_bench(now_ms=65300))
        channels = [MotorChannelTelemetry(channel_id=i, voltage_v=1.8, current_a=0.08) for i in range(1, 5)]

        duties_ok = bench.step_control_loop(now_ms=150, target_voltage_v=1.80, supply_bus_v=5.0, channels=channels)
        self.assertEqual(duties_ok, [0.36, 0.36, 0.36, 0.36])

        duties_trip = bench.step_control_loop(now_ms=400, target_voltage_v=1.80, supply_bus_v=5.0, channels=channels)
        self.assertEqual(duties_trip, [0.0, 0.0, 0.0, 0.0])
        self.assertFalse(bench.armed)
        self.assertTrue(bench.fault_latched)

    def test_overcurrent_and_thermal_cutoff(self):
        bench = SFWarehouse0615TestBenchController(acrylic_guard_closed=True)
        bench.arm_bench(now_ms=2000)
        channels = [
            MotorChannelTelemetry(channel_id=1, voltage_v=3.8, current_a=0.10, temp_c=32.0),
            MotorChannelTelemetry(channel_id=2, voltage_v=3.8, current_a=4.65, temp_c=45.0),
            MotorChannelTelemetry(channel_id=3, voltage_v=3.8, current_a=0.10, temp_c=31.0),
            MotorChannelTelemetry(channel_id=4, voltage_v=3.8, current_a=0.10, temp_c=32.0),
        ]
        duties = bench.step_control_loop(2100, 3.80, 5.0, channels)
        self.assertEqual(duties, [0.0, 0.0, 0.0, 0.0])
        self.assertTrue(bench.fault_latched)
        self.assertIn("CH2 Over-Current", bench.fault_log[0])

    def test_cockroach65_quad_binning(self):
        matched_quad = [
            MotorChannelTelemetry(1, voltage_v=3.80, current_a=0.095, rpm=74100, resistance_ohms=0.48),
            MotorChannelTelemetry(2, voltage_v=3.80, current_a=0.098, rpm=74350, resistance_ohms=0.49),
            MotorChannelTelemetry(3, voltage_v=3.80, current_a=0.094, rpm=73900, resistance_ohms=0.47),
            MotorChannelTelemetry(4, voltage_v=3.80, current_a=0.096, rpm=74200, resistance_ohms=0.48),
        ]
        passed, stats = SFWarehouse0615TestBenchController.bin_cockroach65_quad_set(matched_quad, target_kv=19500.0)
        self.assertTrue(passed)
        self.assertLessEqual(stats["kv_spread_pct"], 1.5)

    def test_7station_littles_law_flow_and_bottleneck_resolution(self):
        flow = SFWarehouse7StationFlowModel()
        ll_140 = flow.calculate_littles_law_racks(target_takt_quad_s=140.0)
        self.assertEqual(ll_140["racks_required"], 6.0)
        self.assertEqual(ll_140["active_motors_in_st6_wip"], 24.0)
        self.assertGreaterEqual(ll_140["throughput_motors_per_hr"], 100.0)

        sim_1rack = flow.simulate_shift_production(shift_hours=8.0, mode="SKD", num_st6_racks=1)
        sim_6rack = flow.simulate_shift_production(shift_hours=8.0, mode="SKD", num_st6_racks=6)
        self.assertGreater(sim_6rack["completed_quads_per_shift"], sim_1rack["completed_quads_per_shift"] * 5)
        self.assertEqual(sim_6rack["line_takt_quad_s"], 140.0)

    def test_station7_packaging_dipole_and_qr_serialization(self):
        pkg = QuadPackPackagingAndSerializer(pocket_pitch_mm=18.0)
        unsafe_10mm = pkg.compute_dipole_attraction_force_n(pitch_mm=10.0)
        self.assertFalse(unsafe_10mm["safe_for_open_tray_kitting"])

        safe_18mm = pkg.compute_dipole_attraction_force_n(pitch_mm=18.0)
        self.assertTrue(safe_18mm["safe_for_open_tray_kitting"])
        self.assertLess(safe_18mm["f_unshielded_max_n"], 0.050)
        self.assertLess(safe_18mm["f_shielded_nominal_n"], 0.005)

        matched_quad = [
            MotorChannelTelemetry(1, voltage_v=3.80, current_a=0.095, rpm=74150, resistance_ohms=0.49),
            MotorChannelTelemetry(2, voltage_v=3.80, current_a=0.096, rpm=74050, resistance_ohms=0.50),
            MotorChannelTelemetry(3, voltage_v=3.80, current_a=0.094, rpm=74180, resistance_ohms=0.49),
            MotorChannelTelemetry(4, voltage_v=3.80, current_a=0.095, rpm=74020, resistance_ohms=0.50),
        ]
        label = pkg.generate_station7_qr_label("SF2611-042", "Q0615-261101-0184", matched_quad, target_kv=19500.0)
        self.assertEqual(label["grade"], "A+")
        self.assertEqual(label["sku"], "OSITO-0615-19500KV-GOLD-Q4")
        self.assertIn("Q0615-261101-0184", label["qr_json_string"])

    def test_multiclass_brushless_outrunner_specs_0802_1404_2207(self):
        spec_0802 = BrushlessOutrunnerSpec.from_preset("0802_19500KV")
        self.assertEqual(spec_0802.winding_scheme_table, "ABCABCABC")
        rm_0802 = spec_0802.estimate_line_to_line_resistance_ohms()
        self.assertTrue(0.12 <= rm_0802 <= 0.22, f"Unexpected 0802 Rm: {rm_0802}")
        wps_0802 = spec_0802.generate_stator_indexing_waypoints()
        self.assertEqual(len(wps_0802), 9)
        self.assertEqual(wps_0802[1]["er16_index_angle_deg"], 40.0)

        spec_1404 = BrushlessOutrunnerSpec.from_preset("1404_3800KV")
        rm_1404 = spec_1404.estimate_line_to_line_resistance_ohms()
        self.assertTrue(0.40 <= rm_1404 <= 0.56, f"Unexpected 1404 Rm: {rm_1404}")

        spec_2207 = BrushlessOutrunnerSpec.from_preset("2207_1850KV")
        self.assertEqual(spec_2207.winding_scheme_table, "AaBbCcAaBbCc")
        rm_2207 = spec_2207.estimate_line_to_line_resistance_ohms()
        self.assertTrue(0.050 <= rm_2207 <= 0.075, f"Unexpected 2207 Rm: {rm_2207}")
        wps_2207 = spec_2207.generate_stator_indexing_waypoints()
        self.assertEqual(len(wps_2207), 12)
        self.assertEqual(wps_2207[0]["winding_direction"], "CW")
        self.assertEqual(wps_2207[1]["winding_direction"], "CCW")
        self.assertEqual(wps_2207[1]["er16_index_angle_deg"], 30.0)

    def test_station3_500v_hipot_and_station6_brushless_dyno_gates(self):
        passed_hipot, stats_hp = BrushlessOutrunnerSpec.verify_500v_hipot_and_kelvin_balance(
            hipot_insulation_mohm=550.0,
            hipot_leakage_ua=0.91,
            phase_resistances_ohm=[0.061, 0.062, 0.061],
        )
        self.assertTrue(passed_hipot)
        self.assertLessEqual(stats_hp["phase_imbalance_pct"], 2.0)

        failed_hipot, _ = BrushlessOutrunnerSpec.verify_500v_hipot_and_kelvin_balance(
            hipot_insulation_mohm=45.0,
            hipot_leakage_ua=11.2,
            phase_resistances_ohm=[0.061, 0.062, 0.061],
        )
        self.assertFalse(failed_hipot)

        passed_dyno, stats_dyno = BrushlessOutrunnerSpec.bin_brushless_quad_set(
            kvs=[1852.0, 1848.0, 1855.0, 1849.0],
            vibration_g_rms=[0.06, 0.08, 0.07, 0.09],
            dynamic_unbalance_g_mm=[0.018, 0.022, 0.015, 0.025],
            hipot_passed_all=True,
            target_kv=1850.0,
        )
        self.assertTrue(passed_dyno)
        self.assertLessEqual(stats_dyno["kv_spread_pct"], 1.5)

    def test_multiclass_fleet_savings_economics(self):
        econ = calculate_multiclass_fleet_savings(
            quads_0615=40, quads_0802=35, quads_1404=15, quads_2207=20, total_capex_usd=4480.0
        )
        self.assertEqual(econ["total_quads_per_month"], 110.0)
        self.assertAlmostEqual(econ["monthly_savings_usd"], 4450.60, places=2)
        self.assertLessEqual(econ["capex_payback_months"], 1.05)

    def test_gate3_lcr_shorted_turn_and_gate4_bemf_pole_envelope(self):
        # Healthy stator passes Gate 3 (10 kHz LCR Inductance & Q balance)
        ok_lcr, stats_lcr = BrushlessOutrunnerSpec.verify_lcr_inductance_and_q_turn_short_gate(
            phase_inductances_uh=[112.4, 111.8, 112.1],
            phase_q_factors=[6.80, 6.72, 6.78],
        )
        self.assertTrue(ok_lcr)
        self.assertLessEqual(stats_lcr["inductance_imbalance_pct"], 3.0)

        # Single shorted turn on Phase W drops Ls by 39% and Q to 2.15 -> caught immediately!
        bad_lcr, _ = BrushlessOutrunnerSpec.verify_lcr_inductance_and_q_turn_short_gate(
            phase_inductances_uh=[112.4, 111.8, 68.5],
            phase_q_factors=[6.80, 6.72, 2.15],
        )
        self.assertFalse(bad_lcr)

        # Gate 4: 14-pole 2207 Back-EMF symmetry & pole-to-pole flux envelope check
        ok_bemf, stats_bemf = BrushlessOutrunnerSpec.verify_3phase_bemf_and_pole_envelope_gate(
            bemf_line_rms_v=[1.621, 1.618, 1.624],
            pole_peak_voltages_v=[2.290, 2.294, 2.288, 2.292, 2.291, 2.289, 2.293,
                                  2.290, 2.295, 2.287, 2.291, 2.292, 2.289, 2.293],
        )
        self.assertTrue(ok_bemf)
        self.assertEqual(stats_bemf["pole_count_verified"], 14.0)

        # Weak/cracked magnet on Pole #7 drops peak voltage by 9% -> caught immediately!
        bad_bemf, _ = BrushlessOutrunnerSpec.verify_3phase_bemf_and_pole_envelope_gate(
            bemf_line_rms_v=[1.621, 1.618, 1.624],
            pole_peak_voltages_v=[2.290, 2.294, 2.288, 2.292, 2.291, 2.289, 2.080,
                                  2.290, 2.295, 2.287, 2.291, 2.292, 2.289, 2.293],
        )
        self.assertFalse(bad_bemf)

    def test_3engine_us_factory_pnl_sf_vs_low_cost_hub(self):
        sf_pnl = simulate_3engine_us_factory_pnl(site_profile="SF_FLAGSHIP")
        tx_pnl = simulate_3engine_us_factory_pnl(site_profile="US_LOW_COST_HUB")
        self.assertGreater(sf_pnl["monthly_ebitda_usd"], 80000.0)
        self.assertGreater(tx_pnl["monthly_ebitda_usd"], sf_pnl["monthly_ebitda_usd"])
        self.assertLessEqual(sf_pnl["breakeven_ndaa_2207_quads_per_mo"], 17.0)
        self.assertLessEqual(tx_pnl["breakeven_ndaa_2207_quads_per_mo"], 12.0)


if __name__ == "__main__":
    unittest.main()
