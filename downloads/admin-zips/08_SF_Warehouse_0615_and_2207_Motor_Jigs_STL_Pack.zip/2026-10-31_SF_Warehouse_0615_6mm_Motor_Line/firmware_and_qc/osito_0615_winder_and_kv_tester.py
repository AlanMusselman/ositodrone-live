"""
OSITO DRONE LLC — SF Warehouse 0615 (6x15mm) Coreless Motor Line
Automated 5-Lobe Rhombic Coil Winder, 6-Rack 1.80V Brush Break-In & Laser KV Binning Controller,
7-Station Little's Law Flow Simulator, and Station 7 Quad-Pack QR Serializer.

Safety & Avionics Discipline (Rule 3):
  - Explicit Disarmed Safety Interlock (zero PWM / stepper pulses unless armed + guard closed)
  - 16-bit unsigned millisecond rollover-safe watchdog & timing arithmetic:
      elapsed_ms = (now_ms - last_ms) & 0xFFFF
  - Instant thermal (>80.0 C) and stalled-commutator over-current (>4.20 A) hardware trip
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple
import json
import math


UINT16_MASK = 0xFFFF


def elapsed_u16_ms(now_ms: int, last_ms: int) -> int:
    """16-bit unsigned millisecond wrap-around safe delta calculation."""
    return (int(now_ms) - int(last_ms)) & UINT16_MASK


@dataclass
class RhombicCoilSpec:
    """
    5-Lobe Skewed Rhombic Coreless Basket Specification for 1S High-Thrust 0615 (6x15mm) Motor.
    Uses 34 AWG (0.160mm bare Cu / 0.180mm NEMA MW 130-C self-bonding coat):
      - 13 turns/lobe (65 total turns) -> 19,500 KV ("Gold" STEM/Hover spec, Rm = 0.50 Ohm)
      - 11 turns/lobe (55 total turns) -> 22,500 KV ("Plaid" Acro/Race spec, Rm = 0.43 Ohm)
    """
    wire_awg: int = 34
    bare_wire_d_mm: float = 0.160
    coated_wire_d_mm: float = 0.180
    mandrel_id_mm: float = 3.85
    basket_od_mm: float = 4.85
    basket_length_mm: float = 11.20
    commutator_segments: int = 5
    turns_per_lobe: int = 13
    skew_angle_deg: float = 36.0
    copper_resistivity_ohm_mm2_m: float = 0.01724

    @property
    def total_turns(self) -> int:
        return self.commutator_segments * self.turns_per_lobe

    def estimate_phase_resistance_ohms(self) -> float:
        """
        Calculates terminal resistance across two commutator bars at 180 deg in a 5-lobe
        Delta (2 lobes in series // 3 lobes in series => 6/5 * R_single_lobe + 0.06 Ohm AgPd brush contact).
        """
        mean_d_mm = 0.5 * (self.mandrel_id_mm + self.basket_od_mm)
        skew_rad = math.radians(self.skew_angle_deg)
        turn_length_mm = 2.0 * (self.basket_length_mm / max(math.cos(skew_rad), 0.2)) + math.pi * mean_d_mm * 0.4
        lobe_wire_len_m = (self.turns_per_lobe * turn_length_mm) / 1000.0
        wire_area_mm2 = math.pi * ((self.bare_wire_d_mm * 0.5) ** 2)
        r_lobe = self.copper_resistivity_ohm_mm2_m * (lobe_wire_len_m / wire_area_mm2)
        return round(1.20 * r_lobe + 0.06, 3)

    def generate_cnc_winding_waypoints(self) -> List[Dict[str, float]]:
        waypoints: List[Dict[str, float]] = []
        theta_deg = 0.0
        lobe_index_step_deg = 360.0 / self.commutator_segments
        pitch_step_deg = 360.0 / self.total_turns

        for lobe in range(self.commutator_segments):
            waypoints.append({
                "lobe": float(lobe + 1),
                "turn": 0.0,
                "spindle_theta_deg": round(theta_deg, 2),
                "traverse_z_mm": 0.0,
                "commutator_tap": float(lobe + 1),
            })
            for turn in range(1, self.turns_per_lobe + 1):
                theta_deg += 180.0 + self.skew_angle_deg
                waypoints.append({
                    "lobe": float(lobe + 1),
                    "turn": float(turn) - 0.5,
                    "spindle_theta_deg": round(theta_deg, 2),
                    "traverse_z_mm": round(self.basket_length_mm, 2),
                    "commutator_tap": 0.0,
                })
                theta_deg += (180.0 - self.skew_angle_deg) + pitch_step_deg
                waypoints.append({
                    "lobe": float(lobe + 1),
                    "turn": float(turn),
                    "spindle_theta_deg": round(theta_deg, 2),
                    "traverse_z_mm": 0.0,
                    "commutator_tap": 0.0,
                })
            theta_deg += lobe_index_step_deg
        return waypoints


@dataclass
class MotorChannelTelemetry:
    channel_id: int
    voltage_v: float = 0.0
    current_a: float = 0.0
    temp_c: float = 25.0
    rpm: float = 0.0
    resistance_ohms: float = 0.50
    fault_reason: str = ""

    @property
    def measured_kv(self) -> float:
        if self.voltage_v <= 0.20:
            return 0.0
        return round(self.rpm / self.voltage_v, 1)


@dataclass
class SFWarehouse0615TestBenchController:
    """
    4-Channel 0615 Coreless Motor Break-In (1.80V for 12 min) & KV Binning Controller
    with disarmed interlock, watchdog, and 16-bit rollover-safe timers.
    """
    armed: bool = False
    acrylic_guard_closed: bool = False
    watchdog_timeout_ms: int = 500
    max_current_limit_a: float = 4.20
    max_temp_limit_c: float = 80.0
    last_heartbeat_ms: int = 0
    stage_start_ms: int = 0
    pwm_duty_All: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0, 0.0])
    fault_latched: bool = False
    fault_log: List[str] = field(default_factory=list)

    def arm_bench(self, now_ms: int) -> bool:
        if self.fault_latched or not self.acrylic_guard_closed:
            self.armed = False
            self.pwm_duty_All = [0.0, 0.0, 0.0, 0.0]
            return False
        self.armed = True
        self.last_heartbeat_ms = now_ms & UINT16_MASK
        self.stage_start_ms = now_ms & UINT16_MASK
        return True

    def disarm_bench(self, reason: str = "Manual Disarm") -> None:
        self.armed = False
        self.pwm_duty_All = [0.0, 0.0, 0.0, 0.0]
        if reason != "Manual Disarm":
            self.fault_latched = True
            self.fault_log.append(reason)

    def clear_faults(self) -> None:
        if not self.armed:
            self.fault_latched = False

    def feed_watchdog(self, now_ms: int) -> None:
        self.last_heartbeat_ms = now_ms & UINT16_MASK

    def step_control_loop(
        self,
        now_ms: int,
        target_voltage_v: float,
        supply_bus_v: float,
        channels: List[MotorChannelTelemetry],
    ) -> List[float]:
        if not self.armed or self.fault_latched:
            self.pwm_duty_All = [0.0, 0.0, 0.0, 0.0]
            return [0.0, 0.0, 0.0, 0.0]

        if not self.acrylic_guard_closed:
            self.disarm_bench("Safety Interlock Open while Armed")
            return [0.0, 0.0, 0.0, 0.0]

        dt_watchdog = elapsed_u16_ms(now_ms, self.last_heartbeat_ms)
        if dt_watchdog > self.watchdog_timeout_ms:
            self.disarm_bench(f"Watchdog Timeout ({dt_watchdog} ms > {self.watchdog_timeout_ms} ms)")
            return [0.0, 0.0, 0.0, 0.0]

        for ch in channels:
            if ch.current_a > self.max_current_limit_a:
                ch.fault_reason = f"Over-Current {ch.current_a:.2f}A"
                self.disarm_bench(f"CH{ch.channel_id} {ch.fault_reason}")
                return [0.0, 0.0, 0.0, 0.0]
            if ch.temp_c > self.max_temp_limit_c:
                ch.fault_reason = f"Over-Temp {ch.temp_c:.1f}C"
                self.disarm_bench(f"CH{ch.channel_id} {ch.fault_reason}")
                return [0.0, 0.0, 0.0, 0.0]
            if ch.resistance_ohms < 0.25 or ch.resistance_ohms > 1.20:
                ch.fault_reason = f"Out-of-Spec Rm {ch.resistance_ohms:.2f} Ohm"
                self.disarm_bench(f"CH{ch.channel_id} {ch.fault_reason}")
                return [0.0, 0.0, 0.0, 0.0]

        duty = max(0.0, min(1.0, target_voltage_v / max(supply_bus_v, 0.1)))
        self.pwm_duty_All = [round(duty, 4)] * 4
        return self.pwm_duty_All

    @staticmethod
    def bin_cockroach65_quad_set(
        tested_motors: List[MotorChannelTelemetry],
        target_kv: float = 19500.0,
        max_kv_spread_pct: float = 1.5,
        max_no_load_current_a: float = 0.125,
    ) -> Tuple[bool, Dict[str, float]]:
        if len(tested_motors) != 4:
            return False, {"error": -1.0}

        kvs = [m.measured_kv for m in tested_motors]
        currents = [m.current_a for m in tested_motors]
        resistances = [m.resistance_ohms for m in tested_motors]

        mean_kv = sum(kvs) / 4.0
        kv_spread_pct = ((max(kvs) - min(kvs)) / max(mean_kv, 1.0)) * 100.0
        kv_error_pct = abs(mean_kv - target_kv) / target_kv * 100.0

        passed = (
            kv_spread_pct <= max_kv_spread_pct
            and kv_error_pct <= 3.0
            and max(currents) <= max_no_load_current_a
            and all(0.42 <= r <= 0.58 for r in resistances)
        )
        return passed, {
            "mean_kv": round(mean_kv, 1),
            "kv_spread_pct": round(kv_spread_pct, 3),
            "max_no_load_current_a": round(max(currents), 4),
            "mean_resistance_ohms": round(sum(resistances) / 4.0, 3),
        }


@dataclass
class SFWarehouse7StationFlowModel:
    """
    7-Station Cellular Manufacturing Flow & Little's Law Line Balancer (Stations 1..7).
    Solves the Station 6 (840s/quad = 720s break-in + 120s KV test) bottleneck via
    parallel 4-Channel PETG-CF Break-In Racks (R1..R6) staggered at 140s intervals.
    """
    station6_flow_time_quad_s: float = 840.0  # 720s 1.80V break-in + 120s load/KV sweep
    station7_pack_time_quad_s: float = 40.0   # 10s/motor (audit + clamshell + QR label + scan)

    def calculate_littles_law_racks(self, target_takt_quad_s: float = 140.0) -> Dict[str, float]:
        """
        Little's Law: WIP_quads = Throughput * FlowTime = FlowTime / TaktTime.
        For target_takt_quad_s = 140.0s (35.0s/motor -> 25.71 quads/hr = 102.86 motors/hr),
        WIP_quads = 840 / 140 = 6.00 parallel 4-channel racks (24 motor channels).
        """
        exact_wip_quads = self.station6_flow_time_quad_s / max(target_takt_quad_s, 1.0)
        racks_required = int(math.ceil(exact_wip_quads - 1e-9))
        effective_st6_takt_s = self.station6_flow_time_quad_s / racks_required
        quads_per_hr = 3600.0 / max(target_takt_quad_s, effective_st6_takt_s)
        return {
            "target_takt_quad_s": round(target_takt_quad_s, 2),
            "racks_required": float(racks_required),
            "active_motors_in_st6_wip": float(racks_required * 4),
            "effective_st6_takt_quad_s": round(effective_st6_takt_s, 2),
            "throughput_quads_per_hr": round(quads_per_hr, 2),
            "throughput_motors_per_hr": round(quads_per_hr * 4.0, 2),
        }

    def simulate_shift_production(
        self,
        shift_hours: float = 8.0,
        mode: str = "SKD",
        num_st6_racks: int = 6,
    ) -> Dict[str, Any]:
        """
        Simulates end-to-end 7-station production across an SF warehouse shift,
        tracking warmup time to first finished quad and steady-state output.
        """
        # Upstream cycle time per 4-motor quad before Station 6
        if mode == "SKD":
            # Stations 4 (100s) + Station 5 (120s)
            upstream_bottleneck_quad_s = 120.0
            pre_st6_lead_time_s = 100.0 + 120.0
        elif mode == "SCRATCH":
            # Dual-spindle Station 1 (84s), Station 2 (90s), Station 3 (140s), Station 4 (100s), Station 5 (120s)
            upstream_bottleneck_quad_s = 140.0
            pre_st6_lead_time_s = 84.0 + 90.0 + 140.0 + 100.0 + 120.0
        else:  # REBUILD
            # Station 3 (100s) + Station 4 (100s)
            upstream_bottleneck_quad_s = 100.0
            pre_st6_lead_time_s = 100.0 + 100.0

        st6_effective_quad_s = self.station6_flow_time_quad_s / max(num_st6_racks, 1)
        line_takt_quad_s = max(upstream_bottleneck_quad_s, st6_effective_quad_s, self.station7_pack_time_quad_s)

        first_quad_packaged_s = pre_st6_lead_time_s + self.station6_flow_time_quad_s + self.station7_pack_time_quad_s
        total_shift_s = shift_hours * 3600.0
        if total_shift_s < first_quad_packaged_s:
            completed_quads = 0
        else:
            completed_quads = 1 + int((total_shift_s - first_quad_packaged_s) // line_takt_quad_s)

        return {
            "mode": mode,
            "num_st6_racks": num_st6_racks,
            "line_takt_quad_s": round(line_takt_quad_s, 2),
            "line_takt_motor_s": round(line_takt_quad_s / 4.0, 2),
            "first_quad_complete_min": round(first_quad_packaged_s / 60.0, 2),
            "completed_quads_per_shift": completed_quads,
            "completed_motors_per_shift": completed_quads * 4,
            "conwip_max_trays": 12 if mode != "SCRATCH" else 16,
        }


@dataclass
class QuadPackPackagingAndSerializer:
    """
    Station 7 Packaging Physics Verifier & Automated 70x45mm QR Serialization Label Builder
    for 7_PLAPlus_0615_Quad_Retail_Clamshell_Tray.stl & 8_PLAPlus_0615_Quad_Retail_Clamshell_SnapLid.stl.
    """
    pocket_pitch_mm: float = 18.00
    can_od_mm: float = 6.00
    shaft_air_vault_axial_gap_mm: float = 2.00
    shaft_air_vault_radial_gap_mm: float = 2.50

    def compute_dipole_attraction_force_n(self, pitch_mm: float = None) -> Dict[str, float]:
        """
        Calculates transverse magnetic dipole-dipole force between adjacent 0615 motors
        (3.5x10.5mm N52H magnet inside 0.25mm SPCC steel flux-return can).
        Must remain < 0.050 N so motors never jump out of tray pockets during kitting.
        """
        r_m = (pitch_mm or self.pocket_pitch_mm) / 1000.0
        mu_0 = 4.0 * math.pi * 1e-7
        m_bare = 0.0900     # Unshielded N52H dipole moment (A*m^2)
        m_shielded = 0.0237 # SPCC steel-can-shielded effective dipole moment (A*m^2)

        f_unshielded = (3.0 * mu_0 * (m_bare ** 2)) / (2.0 * math.pi * (r_m ** 4))
        f_shielded = (3.0 * mu_0 * (m_shielded ** 2)) / (2.0 * math.pi * (r_m ** 4))
        return {
            "pitch_mm": round(r_m * 1000.0, 2),
            "edge_gap_mm": round(r_m * 1000.0 - self.can_od_mm, 2),
            "f_unshielded_max_n": round(f_unshielded, 4),
            "f_shielded_nominal_n": round(f_shielded, 4),
            "safe_for_open_tray_kitting": f_unshielded < 0.050,
        }

    @staticmethod
    def generate_station7_qr_label(
        lot_id: str,
        serial_number: str,
        tested_motors: List[MotorChannelTelemetry],
        target_kv: float = 19500.0,
        sf_line_id: str = "SF-SOMA-0615-L1",
    ) -> Dict[str, Any]:
        """
        Generates the Station 6 -> Station 7 70x45mm Thermal QR Label & JSON Telemetry Record.
        Raises ValueError if the 4 motors do not pass bin_cockroach65_quad_set() QC gates.
        """
        passed, stats = SFWarehouse0615TestBenchController.bin_cockroach65_quad_set(
            tested_motors, target_kv=target_kv
        )
        if not passed:
            raise ValueError(f"Cannot serialize failed quad set: {stats}")

        tier_code = "19500KV-GOLD" if abs(target_kv - 19500.0) < 1000 else "22500KV-PLAID"
        grade = "A+" if stats["kv_spread_pct"] <= 0.50 else "A"
        positions = [
            ("M1_RR_CCW", "BLU/RED"),
            ("M2_FR_CW", "RED/BLK"),
            ("M3_RL_CW", "RED/BLK"),
            ("M4_FL_CCW", "BLU/RED"),
        ]
        motor_records = {}
        for idx, (pos_code, wire_color) in enumerate(positions):
            m = tested_motors[idx]
            motor_records[pos_code] = {
                "wire": wire_color,
                "rpm_3v8": int(round(m.rpm)),
                "kv": m.measured_kv,
                "i0_a": round(m.current_a, 3),
                "rm_ohm": round(m.resistance_ohms, 3),
            }

        qr_payload = {
            "sn": serial_number,
            "lot": lot_id,
            "sku": f"OSITO-0615-{tier_code}-Q4",
            "grade": grade,
            "mean_kv": stats["mean_kv"],
            "spread_pct": stats["kv_spread_pct"],
            "mean_rm_ohm": stats["mean_resistance_ohms"],
            "max_i0_a": stats["max_no_load_current_a"],
            "line": sf_line_id,
        }
        return {
            "label_dimensions_mm": "70.0 x 45.0",
            "sku": qr_payload["sku"],
            "lot_id": lot_id,
            "serial_number": serial_number,
            "grade": grade,
            "quad_summary": stats,
            "motors": motor_records,
            "qr_json_string": json.dumps(qr_payload, separators=(",", ":")),
        }


@dataclass
class BrushlessOutrunnerSpec:
    """
    Multi-Class Brushless Outrunner Electromagnetic & Winding Specification
    for Classes 2, 3, and 4 on the SF Warehouse 7-Station Line:
      - Class 2 (0802 9N12P):  CUB-75 (19,500KV 1S) & SHARD-75 (14,000KV 2S)
      - Class 3 (1404 9N12P):  THERMO-95 Attic (3,800KV 4S) & Titan-85 (4,600KV 3S)
      - Class 4 (2207 12N14P): AI Security / Commercial 5-Inch (1,850KV 6S & 2,450KV 4S)
    """
    motor_class: str = "2207"
    variant_name: str = "2207_1850KV_6S"
    stator_od_mm: float = 22.0
    stator_id_mm: float = 8.0
    stator_stack_mm: float = 7.0
    num_slots: int = 12
    num_poles: int = 14
    target_kv: float = 1850.0
    turns_per_tooth: int = 9
    wire_awg: float = 22.0
    bare_wire_d_mm: float = 0.644
    termination: str = "WYE"      # "WYE" (Star Y) or "DELTA" (D)
    parallel_paths: int = 2       # 1 (series) or 2 (2P opposite tooth pairs)
    mean_turn_len_mm: float = 21.0
    copper_resistivity_ohm_mm2_m: float = 0.01724

    @classmethod
    def from_preset(cls, preset_code: str) -> "BrushlessOutrunnerSpec":
        presets = {
            "0802_19500KV": cls(
                motor_class="0802",
                variant_name="0802_19500KV_1S_CUB75",
                stator_od_mm=8.0,
                stator_id_mm=3.8,
                stator_stack_mm=2.0,
                num_slots=9,
                num_poles=12,
                target_kv=19500.0,
                turns_per_tooth=9,
                wire_awg=31.0,
                bare_wire_d_mm=0.226,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=7.10,
            ),
            "0802_14000KV": cls(
                motor_class="0802",
                variant_name="0802_14000KV_2S_SHARD75",
                stator_od_mm=8.0,
                stator_id_mm=3.8,
                stator_stack_mm=2.0,
                num_slots=9,
                num_poles=12,
                target_kv=14000.0,
                turns_per_tooth=13,
                wire_awg=33.0,
                bare_wire_d_mm=0.180,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=7.10,
            ),
            "1404_3800KV": cls(
                motor_class="1404",
                variant_name="1404_3800KV_4S_THERMO95",
                stator_od_mm=14.0,
                stator_id_mm=6.0,
                stator_stack_mm=4.0,
                num_slots=9,
                num_poles=12,
                target_kv=3800.0,
                turns_per_tooth=18,
                wire_awg=30.0,
                bare_wire_d_mm=0.255,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=13.00,
            ),
            "1404_4600KV": cls(
                motor_class="1404",
                variant_name="1404_4600KV_3S_TITAN85",
                stator_od_mm=14.0,
                stator_id_mm=6.0,
                stator_stack_mm=4.0,
                num_slots=9,
                num_poles=12,
                target_kv=4600.0,
                turns_per_tooth=15,
                wire_awg=29.0,
                bare_wire_d_mm=0.286,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=13.00,
            ),
            "2207_1850KV": cls(
                motor_class="2207",
                variant_name="2207_1850KV_6S_SECURITY",
                stator_od_mm=22.0,
                stator_id_mm=8.0,
                stator_stack_mm=7.0,
                num_slots=12,
                num_poles=14,
                target_kv=1850.0,
                turns_per_tooth=9,
                wire_awg=22.0,
                bare_wire_d_mm=0.644,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=15.50,
            ),
            "2207_2450KV": cls(
                motor_class="2207",
                variant_name="2207_2450KV_4S_INTERCEPTOR",
                stator_od_mm=22.0,
                stator_id_mm=8.0,
                stator_stack_mm=7.0,
                num_slots=12,
                num_poles=14,
                target_kv=2450.0,
                turns_per_tooth=7,
                wire_awg=22.0,
                bare_wire_d_mm=0.644,
                termination="WYE",
                parallel_paths=1,
                mean_turn_len_mm=15.50,
            ),
        }
        if preset_code not in presets:
            raise ValueError(f"Unknown brushless preset: {preset_code}")
        return presets[preset_code]

    @property
    def winding_scheme_table(self) -> str:
        """Returns 'ABCABCABC' for 9N12P or 'AaBbCcAaBbCc' (dLRK) for 12N14P."""
        if self.num_slots == 9 and self.num_poles == 12:
            return "ABCABCABC"
        return "AaBbCcAaBbCc"

    def estimate_line_to_line_resistance_ohms(self) -> float:
        """
        Calculates 4-wire Kelvin line-to-line terminal resistance (Rm) at 20C.
        Accounts for series teeth per phase, parallel paths (1P vs 2P), and Wye (2*R_ph) vs Delta (2/3*R_ph).
        """
        teeth_per_phase = self.num_slots // 3
        series_teeth_per_branch = teeth_per_phase / max(self.parallel_paths, 1)
        branch_wire_len_m = (series_teeth_per_branch * self.turns_per_tooth * self.mean_turn_len_mm) / 1000.0
        wire_area_mm2 = math.pi * ((self.bare_wire_d_mm * 0.5) ** 2)
        r_branch = self.copper_resistivity_ohm_mm2_m * (branch_wire_len_m / wire_area_mm2)
        r_phase = r_branch / max(self.parallel_paths, 1)
        lead_and_solder_ohm = 0.008 if self.motor_class == "2207" else 0.015
        if self.termination.upper() == "WYE":
            return round(2.0 * r_phase + lead_and_solder_ohm, 4)
        return round((2.0 / 3.0) * r_phase + lead_and_solder_ohm, 4)

    def generate_stator_indexing_waypoints(self) -> List[Dict[str, Any]]:
        """
        Generates Station 1 ER16 radial tooth-indexing CNC waypoints for 9N12P or 12N14P stators.
        """
        pattern = self.winding_scheme_table
        slot_pitch_deg = 360.0 / self.num_slots
        waypoints: List[Dict[str, Any]] = []
        for idx, code in enumerate(pattern):
            waypoints.append({
                "tooth_index": idx + 1,
                "phase": code.upper(),
                "winding_direction": "CW" if code.isupper() else "CCW",
                "er16_index_angle_deg": round(idx * slot_pitch_deg, 2),
                "turns": self.turns_per_tooth,
            })
        return waypoints

    @staticmethod
    def verify_500v_hipot_and_kelvin_balance(
        hipot_insulation_mohm: float,
        hipot_leakage_ua: float,
        phase_resistances_ohm: List[float],
    ) -> Tuple[bool, Dict[str, float]]:
        """
        Station 3 Mandatory Brushless Stator Gate:
          1. 500V DC Hi-Pot test between U-V-W star point and silicon-steel stator core:
             R_ins >= 100.0 MOhm and leakage < 5.0 uA.
          2. 4-Wire Kelvin phase balance: (R_max - R_min) / R_mean <= 2.0%.
        """
        if len(phase_resistances_ohm) != 3:
            return False, {"error": -1.0}
        r_mean = sum(phase_resistances_ohm) / 3.0
        delta_pct = ((max(phase_resistances_ohm) - min(phase_resistances_ohm)) / max(r_mean, 1e-6)) * 100.0
        passed = (
            hipot_insulation_mohm >= 100.0
            and hipot_leakage_ua < 5.0
            and delta_pct <= 2.0
        )
        return passed, {
            "hipot_insulation_mohm": round(hipot_insulation_mohm, 1),
            "hipot_leakage_ua": round(hipot_leakage_ua, 3),
            "mean_rm_ohm": round(r_mean, 4),
            "phase_imbalance_pct": round(delta_pct, 3),
        }

    @staticmethod
    def bin_brushless_quad_set(
        kvs: List[float],
        vibration_g_rms: List[float],
        dynamic_unbalance_g_mm: List[float],
        hipot_passed_all: bool,
        target_kv: float,
        max_kv_spread_pct: float = 1.5,
        max_vibration_g_rms: float = 0.12,
        max_unbalance_g_mm: float = 0.05,
    ) -> Tuple[bool, Dict[str, float]]:
        """
        Station 6 Multi-Class Brushless Dyno & BMI270 Vibration Acceptance Gate.
        """
        if len(kvs) != 4 or len(vibration_g_rms) != 4 or len(dynamic_unbalance_g_mm) != 4:
            return False, {"error": -1.0}
        mean_kv = sum(kvs) / 4.0
        kv_spread_pct = ((max(kvs) - min(kvs)) / max(mean_kv, 1.0)) * 100.0
        kv_error_pct = abs(mean_kv - target_kv) / max(target_kv, 1.0) * 100.0
        max_vib = max(vibration_g_rms)
        max_unbal = max(dynamic_unbalance_g_mm)

        passed = (
            hipot_passed_all
            and kv_spread_pct <= max_kv_spread_pct
            and kv_error_pct <= 3.0
            and max_vib <= max_vibration_g_rms
            and max_unbal <= max_unbalance_g_mm
        )
        return passed, {
            "mean_kv": round(mean_kv, 1),
            "kv_spread_pct": round(kv_spread_pct, 3),
            "max_vibration_g_rms": round(max_vib, 4),
            "max_unbalance_g_mm": round(max_unbal, 4),
        }

    @staticmethod
    def verify_lcr_inductance_and_q_turn_short_gate(
        phase_inductances_uh: List[float],
        phase_q_factors: List[float],
        max_inductance_imbalance_pct: float = 3.0,
        max_q_imbalance_pct: float = 5.0,
        min_healthy_q: float = 4.0,
    ) -> Tuple[bool, Dict[str, float]]:
        """
        Gate 3 (10 kHz / 100 kHz LCR Single Turn-to-Turn Short Detector):
        A single shorted turn inside a 96-turn stator coil changes DC resistance (Rm) by only ~1.0%,
        passing standard Kelvin DC checks, but acts as a shorted secondary transformer loop at 10-100 kHz,
        collapsing series inductance Ls by 25%-48% and Quality Factor Q by 55%-78%.
        """
        if len(phase_inductances_uh) != 3 or len(phase_q_factors) != 3:
            return False, {"error": -1.0}
        l_mean = sum(phase_inductances_uh) / 3.0
        q_mean = sum(phase_q_factors) / 3.0
        l_imbalance_pct = ((max(phase_inductances_uh) - min(phase_inductances_uh)) / max(l_mean, 1e-6)) * 100.0
        q_imbalance_pct = ((max(phase_q_factors) - min(phase_q_factors)) / max(q_mean, 1e-6)) * 100.0
        passed = (
            l_imbalance_pct <= max_inductance_imbalance_pct
            and q_imbalance_pct <= max_q_imbalance_pct
            and min(phase_q_factors) >= min_healthy_q
        )
        return passed, {
            "mean_inductance_uh": round(l_mean, 2),
            "inductance_imbalance_pct": round(l_imbalance_pct, 3),
            "mean_q_factor": round(q_mean, 2),
            "q_imbalance_pct": round(q_imbalance_pct, 3),
            "min_phase_q": round(min(phase_q_factors), 2),
        }

    @staticmethod
    def verify_3phase_bemf_and_pole_envelope_gate(
        bemf_line_rms_v: List[float],
        pole_peak_voltages_v: List[float],
        max_phase_bemf_imbalance_pct: float = 1.5,
        max_pole_to_pole_modulation_pct: float = 1.8,
    ) -> Tuple[bool, Dict[str, float]]:
        """
        Gate 4 (Driven / Coast-Down 3-Phase BEMF & Pole-to-Pole Flux Envelope Check):
          1. 3-Phase RMS BEMF symmetry (U-V, V-W, W-U <= 1.5%) catches +/-1 turn count errors.
          2. Pole-to-pole peak envelope across all 12 or 14 rotor poles (<= 1.8%) catches any
             reversed, cracked, or partially demagnetized N52SH magnet or >0.008mm shaft TIR.
        """
        if len(bemf_line_rms_v) != 3 or len(pole_peak_voltages_v) not in (12, 14):
            return False, {"error": -1.0}
        v_mean = sum(bemf_line_rms_v) / 3.0
        p_mean = sum(pole_peak_voltages_v) / len(pole_peak_voltages_v)
        bemf_imbalance_pct = ((max(bemf_line_rms_v) - min(bemf_line_rms_v)) / max(v_mean, 1e-6)) * 100.0
        pole_mod_pct = ((max(pole_peak_voltages_v) - min(pole_peak_voltages_v)) / max(p_mean, 1e-6)) * 100.0
        passed = (
            bemf_imbalance_pct <= max_phase_bemf_imbalance_pct
            and pole_mod_pct <= max_pole_to_pole_modulation_pct
        )
        return passed, {
            "mean_bemf_rms_v": round(v_mean, 4),
            "bemf_phase_imbalance_pct": round(bemf_imbalance_pct, 3),
            "pole_count_verified": float(len(pole_peak_voltages_v)),
            "pole_to_pole_modulation_pct": round(pole_mod_pct, 3),
        }


def simulate_3engine_us_factory_pnl(
    site_profile: str = "SF_FLAGSHIP",
    internal_quads_mo: int = 110,
    stem_lab_kits_mo: int = 300,
    stem_spare_quads_mo: int = 250,
    ndaa_0802_quads_mo: int = 40,
    ndaa_1404_quads_mo: int = 60,
    ndaa_2207_quads_mo: int = 120,
) -> Dict[str, float]:
    """
    Simulates the 3-Engine Dual-Track US Motor Micro-Factory Monthly P&L across:
      - Site Profile A ('SF_FLAGSHIP'): San Francisco PDR-1-G/PDR-2 ($1,100/mo 400 sq ft share, $32/hr tech, $0 SF GRT <$5M)
      - Site Profile B ('US_LOW_COST_HUB'): TX / NV / AZ / OH / AL ($460/mo 400 sq ft share, $24.50/hr tech, 0% state tax)
    """
    # Engine A: Internal Fleet BOM Savings (40x 0615, 35x 0802, 15x 1404, 20x 2207 baseline = $40.46/quad avg saved)
    engine_a_savings = internal_quads_mo * 40.46

    # Engine B: STEM "Build-Your-Own-Motor" Lab Kits ($45 price vs $6.80 BOM) + Spare Quad Packs ($31.39 avg price vs $5.82 BOM)
    engine_b_rev = (stem_lab_kits_mo * 45.00) + (stem_spare_quads_mo * 31.392)
    engine_b_bom = (stem_lab_kits_mo * 6.80) + (stem_spare_quads_mo * 5.824)

    # Engine C: 100% Non-Chinese NDAA Sec. 848 / 10 U.S.C. 4872 B2B Quad Sets (0802 @ $185, 1404 @ $295, 2207 @ $480)
    engine_c_rev = (
        ndaa_0802_quads_mo * 185.00
        + ndaa_1404_quads_mo * 295.00
        + ndaa_2207_quads_mo * 480.00
    )
    engine_c_raw_bom = (
        ndaa_0802_quads_mo * 29.80
        + ndaa_1404_quads_mo * 48.20
        + ndaa_2207_quads_mo * 77.64
    )

    is_sf = site_profile.upper() == "SF_FLAGSHIP"
    tech_labor_1p5_fte = 7680.0 if is_sf else 5880.0
    bay_rent_400sqft = 1100.0 if is_sf else 460.0
    utilities_and_consumables = 420.0 if is_sf else 290.0

    total_value = engine_a_savings + engine_b_rev + engine_c_rev
    total_bom = engine_b_bom + engine_c_raw_bom
    gross_margin = total_value - total_bom - tech_labor_1p5_fte
    monthly_ebitda = gross_margin - bay_rent_400sqft - utilities_and_consumables

    fixed_overhead_1fte = (5120.0 + 1100.0 + 171.0) if is_sf else (3920.0 + 460.0 + 54.0)
    ndaa_2207_quad_contribution = 480.00 - 91.44
    breakeven_ndaa_2207_quads = math.ceil(fixed_overhead_1fte / ndaa_2207_quad_contribution)

    return {
        "engine_a_internal_savings_usd": round(engine_a_savings, 2),
        "engine_b_stem_revenue_usd": round(engine_b_rev, 2),
        "engine_c_ndaa_b2b_revenue_usd": round(engine_c_rev, 2),
        "total_monthly_revenue_and_savings_usd": round(total_value, 2),
        "gross_margin_usd": round(gross_margin, 2),
        "monthly_ebitda_usd": round(monthly_ebitda, 2),
        "annual_ebitda_usd": round(monthly_ebitda * 12.0, 2),
        "breakeven_ndaa_2207_quads_per_mo": float(breakeven_ndaa_2207_quads),
    }


def calculate_multiclass_fleet_savings(
    quads_0615: int = 40,
    quads_0802: int = 35,
    quads_1404: int = 15,
    quads_2207: int = 20,
    total_capex_usd: float = 4480.0,
) -> Dict[str, float]:
    """
    Calculates monthly & annual cash savings across all 4 Osito Drone LLC motor classes
    (0615 6mm Brushed, 0802 Whoop BLDC, 1404 Sub-250g BLDC, and 2207 5-Inch Heavy BLDC).
    """
    # Per-quad (4-motor set) Retail vs. SF In-House Packaged BOM
    savings_per_quad = {
        "0615": 17.00 - 3.44,   # $13.56/quad saved
        "0802": 51.96 - 9.40,   # $42.56/quad saved
        "1404": 71.96 - 15.20,  # $56.76/quad saved
        "2207": 99.96 - 21.60,  # $78.36/quad saved
    }
    total_quads = quads_0615 + quads_0802 + quads_1404 + quads_2207
    monthly_savings = (
        quads_0615 * savings_per_quad["0615"]
        + quads_0802 * savings_per_quad["0802"]
        + quads_1404 * savings_per_quad["1404"]
        + quads_2207 * savings_per_quad["2207"]
    )
    payback_months = total_capex_usd / max(monthly_savings, 1.0)
    return {
        "total_quads_per_month": float(total_quads),
        "total_motors_per_month": float(total_quads * 4),
        "monthly_savings_usd": round(monthly_savings, 2),
        "annual_savings_usd": round(monthly_savings * 12.0, 2),
        "blended_savings_per_quad_usd": round(monthly_savings / max(total_quads, 1), 2),
        "capex_payback_months": round(payback_months, 2),
    }


if __name__ == "__main__":
    flow = SFWarehouse7StationFlowModel()
    print("[Little's Law 140s Takt]:", flow.calculate_littles_law_racks(140.0))
    print("[8-Hr Shift Sim SKD 6-Racks]:", flow.simulate_shift_production(8.0, "SKD", 6))
    pkg = QuadPackPackagingAndSerializer()
    print("[Packaging Dipole Check @ 18mm Pitch]:", pkg.compute_dipole_attraction_force_n(18.0))
    spec_2207 = BrushlessOutrunnerSpec.from_preset("2207_1850KV")
    print("[2207 1850KV 6S Rm (Ohms)]:", spec_2207.estimate_line_to_line_resistance_ohms())
    print("[Multi-Class 110 Quads/Mo Savings]:", calculate_multiclass_fleet_savings())
