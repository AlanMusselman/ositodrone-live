"""
OSITO DRONE LLC — SF Warehouse 0615 (6mm) Coreless Motor Micro-Factory, Flow & Packaging SOP Builder (.docx)
Strictly formatted to ositodrone.com visual design system (Fjalla One + Roboto, #232A68, #7077CF, #EEF0FA).
"""
import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.abspath(os.path.join(BASE_DIR, "..", "..", ".."))
LOGO_PATH = os.path.join(ROOT_DIR, "00_Brand_Assets", "Logos", "ositologo blak.jpg")
OUT_DOCX = os.path.join(BASE_DIR, "OSITO_SF_Warehouse_0615_6mm_Motor_Manufacturing_SOP.docx")

COLOR_ROYAL_INDIGO = RGBColor(0x23, 0x2A, 0x68)
COLOR_PERIWINKLE = RGBColor(0x70, 0x77, 0xCF)
COLOR_CHARCOAL = RGBColor(0x16, 0x16, 0x16)
COLOR_MUTED = RGBColor(0x5E, 0x5E, 0x5E)


def set_cell_bg(cell, hex_str: str):
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_str}"/>')
    cell._tc.get_or_add_tcPr().append(shading)


def add_heading_styled(doc, text: str, level: int = 1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14 if level == 1 else 10)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text.upper())
    run.font.name = "Fjalla One"
    run.font.bold = True
    run.font.size = Pt(15 if level == 1 else 12)
    run.font.color.rgb = COLOR_ROYAL_INDIGO if level == 1 else COLOR_PERIWINKLE
    return p


def add_callout_box(doc, title: str, body: str):
    tbl = doc.add_table(rows=1, cols=1)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    cell = tbl.cell(0, 0)
    set_cell_bg(cell, "EEF0FA")
    p = cell.paragraphs[0]
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    r_title = p.add_run(f"{title.upper()}\n")
    r_title.font.name = "Fjalla One"
    r_title.font.bold = True
    r_title.font.size = Pt(10.5)
    r_title.font.color.rgb = COLOR_ROYAL_INDIGO
    r_body = p.add_run(body)
    r_body.font.name = "Roboto"
    r_body.font.size = Pt(9.5)
    r_body.font.color.rgb = COLOR_CHARCOAL
    doc.add_paragraph()


def add_styled_table(doc, headers, rows):
    tbl = doc.add_table(rows=1 + len(rows), cols=len(headers))
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = tbl.rows[0].cells
    for idx, h_text in enumerate(headers):
        hdr_cells[idx].text = ""
        set_cell_bg(hdr_cells[idx], "232A68")
        p = hdr_cells[idx].paragraphs[0]
        r = p.add_run(h_text.upper())
        r.font.name = "Fjalla One"
        r.font.bold = True
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)

    for r_idx, row_data in enumerate(rows):
        row_cells = tbl.rows[r_idx + 1].cells
        bg_hex = "F6F6F6" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(row_data):
            row_cells[c_idx].text = ""
            set_cell_bg(row_cells[c_idx], bg_hex)
            p = row_cells[c_idx].paragraphs[0]
            r = p.add_run(str(val))
            r.font.name = "Roboto"
            r.font.size = Pt(9.0)
            r.font.color.rgb = COLOR_CHARCOAL
            if c_idx == 0:
                r.font.bold = True
    doc.add_paragraph()


def build_docx():
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(0.60)
        section.bottom_margin = Inches(0.60)
        section.left_margin = Inches(0.60)
        section.right_margin = Inches(0.60)

    if os.path.exists(LOGO_PATH):
        p_logo = doc.add_paragraph()
        p_logo.alignment = WD_ALIGN_PARAGRAPH.LEFT
        p_logo.add_run().add_picture(LOGO_PATH, width=Inches(1.65))

    p_title = doc.add_paragraph()
    r_t = p_title.add_run("SAN FRANCISCO WAREHOUSE MULTI-CLASS MOTOR FACTORY (6MM TO 5-INCH), FLOW & PACKAGING SOP")
    r_t.font.name = "Fjalla One"
    r_t.font.bold = True
    r_t.font.size = Pt(17)
    r_t.font.color.rgb = COLOR_ROYAL_INDIGO

    p_sub = doc.add_paragraph()
    r_s = p_sub.add_run(
        "Document ID: SOP-OSITO-SF-MULTICLASS-003 (Rev 3.0 — 4-Class 0615 / 0802 / 1404 / 2207 5-Inch Line, Flow & Clamshell Packaging)\n"
        "Facility Footprint: 400 Sq Ft Bay in San Francisco PDR-1-G / PDR-2 Warehouse (SOMA / Dogpatch / Bayview)\n"
        "Owners: Alan Musselman (COO), Miguel Flores (CEO), Jesus Aceves (CTO)"
    )
    r_s.font.name = "Roboto"
    r_s.font.size = Pt(9.5)
    r_s.font.color.rgb = COLOR_MUTED

    add_callout_box(
        doc,
        "Executive 4-Class Motor Factory Economics (0615 6mm to 2207 5-Inch)",
        "By adding +$720 of quick-change brushless tooling (ER16 radial stator indexing chuck, 500V DC Hi-Pot tester, 2-plane dynamic "
        "bell balancer, and 6S 55A AM32 dyno + 5kg thrust cell, bringing total 7-station CapEx to $4,480), the exact same 400 sq ft "
        "San Francisco cellular line builds 100% of Osito Drone LLC's motors from 6mm to 5-Inch with a <90-second changeover:\n"
        "• Class 1 (0615 6x15mm Coreless Brushed, 1S Cockroach 65 / Osito 65): $3.44/quad in-house vs $17.00 retail (Saves $13.56/quad)\n"
        "• Class 2 (0802 9N12P Micro BLDC, 1S/2S CUB-75 & SHARD-75): $9.40/quad in-house vs $51.96 retail (Saves $42.56/quad)\n"
        "• Class 3 (1404 9N12P/12N14P Sub-250g BLDC, 3S/4S THERMO-95 Attic & Titan-85): $15.20/quad vs $71.96 retail (Saves $56.76/quad)\n"
        "• Class 4 (2207 12N14P dLRK 5-Inch Heavy BLDC, 4S/6S AI Security & Commercial): $21.60/quad vs $99.96 retail (Saves $78.36/quad)\n"
        "At a blended fleet volume of 110 quads/month (40x 0615, 35x 0802, 15x 1404, 20x 2207), the SF line saves $4,450.60/month "
        "($53,407/year) and pays back the entire $4,480 7-station factory CapEx in 1.0 month!",
    )

    # Section 0: Master 4-Class Electromagnetic & Mechanical Specification Matrix
    add_heading_styled(doc, "0. Master 4-Class Motor Specification Matrix (6mm Brushed to 5-Inch Brushless)", level=1)
    add_styled_table(
        doc,
        ["Motor Class & Fleet", "Topology & Stator/Can", "KV, Wire & Turns (Rm)", "Shaft, Bearings & Harness", "In-House vs Retail Quad"],
        [
            [
                "Class 1: 0615 (6x15mm)\nCockroach 65 / Osito 65",
                "Coreless 5-Lobe Skewed Rhombic (36°), SPCC Can + N52H Core",
                "19,500KV Gold: 34 AWG, 13T/lobe (65T Delta, 0.50 Ohm)\n22,500KV Plaid: 11T/lobe (55T, 0.43 Ohm)",
                "1.00mm SUS420J2 Shaft, 2x CuSn8 Bushings, 38mm 30 AWG + 2P JST-1.25mm + TPU Boot (#6)",
                "$3.44 / quad vs $17.00\n(Saves $13.56 / quad)",
            ],
            [
                "Class 2: 0802 (8x2mm)\nCUB-75 (39.5g) & SHARD-75",
                "9N12P Outrunner (ABCABCABC), 10x 0.20mm JFE Lams + 12x N52SH",
                "19,500KV (1S): 31 AWG, 9T/tooth Wye (0.185 Ohm)\n14,000KV (2S): 33 AWG, 13T/tooth Wye (0.345 Ohm)",
                "1.50mm Shaft + C-Clip, 2x MR52ZZ (2x5x2.5mm), 45mm 28 AWG + 3P JST-1.25mm Plug",
                "$9.40 / quad vs $51.96\n(Saves $42.56 / quad)",
            ],
            [
                "Class 3: 1404 (14x4mm)\nTHERMO-95 Attic & Titan-85",
                "9N12P / 12N14P Outrunner, 20x 0.20mm JFE Lams + 12x N52SH (150C)",
                "3,800KV (4S): 30 AWG Class-220, 18T/tooth Wye (0.49 Ohm)\n4,600KV (3S): 29 AWG, 15T/tooth Wye (0.33 Ohm)",
                "1.50mm Ti-6Al-4V T-Mount Shaft, 2x MR52ZZ ABEC-7, 100mm 24 AWG 200C Silicone Leads",
                "$15.20 / quad vs $71.96\n(Saves $56.76 / quad)",
            ],
            [
                "Class 4: 2207 (22x7mm 5\")\nAI Security & Commercial",
                "12N14P dLRK Outrunner (AaBbCcAaBbCc), 35x 0.20mm JFE Lams + 14x N52SH",
                "1,850KV (6S): 22 AWG Class-220, 9T/tooth Wye (0.064 Ohm)\n2,450KV (4S): 22 AWG, 7T/tooth Wye (0.048 Ohm)",
                "4.0mm Hollow Ti Shaft + M5 Prop Stud + T10 Screw, 2x 684ZZ EZO, 150mm 20 AWG Leads (1,680g Thrust)",
                "$21.60 / quad vs $99.96\n(Saves $78.36 / quad)",
            ],
        ],
    )

    # Section 1: SF Warehouse Zoning, Power & Environmental Compliance
    add_heading_styled(doc, "1. San Francisco Warehouse Facility, Zoning & BAAQMD Compliance", level=1)
    add_styled_table(
        doc,
        ["Requirement", "San Francisco Warehouse Specification", "Compliance & Engineering Implementation"],
        [
            [
                "SF Planning Zoning",
                "PDR-1-G / PDR-2 (Production, Distribution & Repair)",
                "Permitted by right in SOMA, Dogpatch, Potrero Hill, and Bayview/Hunters Point light-industrial spaces.",
            ],
            [
                "Floor Space & Power",
                "400 sq ft Cellular U-Line (7 Stations) | 2x 120V/20A Circuits",
                "Peak line draw is 1.55 kW (Quick 861DW hot-air curer + Hakko FX-951 + FA-430 extractor + 6-Rack Rigol DP832 tower).",
            ],
            [
                "Air Quality (BAAQMD)",
                "Zero Solvent Dip-Varnish Tanks (Dry 155°C Self-Bonding Wire)",
                "Uses NEMA MW 130-C butyral heat-activated magnet wire + Hakko FA-430 HEPA/Activated Carbon filtration (no roof ducting).",
            ],
            [
                "CONWIP Material Flow",
                "2-Tray FIFO Kanban Chutes + 20-Motor PETG-CF Totes (#9)",
                "Strict 12-Tray CONWIP limit prevents magnetic clumping and mixed-KV batches across all 7 stations.",
            ],
        ],
    )

    # Section 2: 7-Station Little's Law Balanced Workflow
    add_heading_styled(doc, "2. Seven-Station Little's Law Balanced Workflow (140s/Quad Takt = 102.9 Motors/Hr)", level=1)
    add_styled_table(
        doc,
        ["Station", "Equipment & Bambu P2S Tooling", "Quad Cycle / Touch", "Step-by-Step Shop Floor & Poka-Yoke Operation"],
        [
            [
                "Station 1:\nCNC Rhombic Winder",
                "2-Axis CNC Flyer Winder + 1_PAHTCF_0615_5Lobe_Rhombic_Coil_Winding_Mandrel.stl",
                "84s / quad (2 Spindles)\nTouch: 40s / quad",
                "Wind 34 AWG (0.160mm bare Cu) self-bonding wire onto the 3.85mm PAHT-CF 5-pin mandrel at 36° skew: "
                "13T/lobe (65T = 19,500KV Gold, Rm=0.50 Ohm) or 11T/lobe (55T = 22,500KV Plaid, Rm=0.43 Ohm).",
            ],
            [
                "Station 2:\n155°C Thermo-Fusion",
                "Quick 861DW Hot-Air Curer + Loctite 480 Dispenser",
                "90s / quad (Batch of 4)\nTouch: 30s / quad",
                "Heat the wound basket on the PAHT-CF mandrel at 155°C for 90s to fuse the butyral outer coat into a rigid hollow cylinder "
                "(4.85mm OD). Bond Delrin carrier disk onto the 1.00mm SUS420J2 hardened shaft.",
            ],
            [
                "Station 3:\nMicro-Solder & Ultrasonic",
                "AmScope 45x Stereo Scope + Hakko FX-951 + FA-430 + IPA Bath",
                "140s / quad (35s/motor)\nTouch: 140s / quad",
                "Micro-solder the 5 Delta coil taps to the 1.80mm 5-segment AgPd commutator (with integrated ZnO EMI varistor ring) at 360°C. "
                "Verify phase resistance (0.42–0.58 Ohm).",
            ],
            [
                "Station 4:\n4-Up Arbor Press",
                "0.5T Arbor Press + 2_PLAPlus...Press_Fixture.stl + 3_PLAPlus...Fork.stl",
                "100s / quad (25s/motor)\nTouch: 100s / quad",
                "Load 4x 6.0x15.0mm steel cans (18.0mm pitch) with 3.5x10.5mm N52H magnet & dual CuSn8 bushings. Insert rotor + PTFE washer. "
                "Spread AgPd leaf brushes with the 0.20mm feeler fork while pressing the LCP endbell flush, then crimp tabs.",
            ],
            [
                "Station 5:\nCockroach 65 Harness",
                "Engineer PA-09 Crimper + 6_TPU95AHF...Boots_x8.stl",
                "120s / quad (30s/motor)\nTouch: 120s / quad",
                "Solder 38mm 30 AWG silicone leads at 340°C (<1.5s dwell: Red/Black CW M2/M3, Blue/Red CCW M1/M4). Slide on the in-house printed "
                "TPU 95A HF strain-relief boot with B-7000 and crimp the 2-pin JST-1.25mm (Molex PicoBlade) plug.",
            ],
            [
                "Station 6:\n6-Rack Break-In & KV Bank",
                "6x 5_PETGCF...Test_Stand.stl (24 Pods) + Rigol DP832 + PCA9548A Mux",
                "Effective Takt: 140s/quad\n(840s / 6 Racks)\nTouch: 30s / quad",
                "Little's Law 6-Rack Tower (R1–R6 staggered every 140s). Dose 0.5 uL DeoxIT Shield S100L; run 720s @ 1.80V unloaded brush seating "
                "+ automated 90s @ 3.80V optical laser KV sweep. Passes only if KV spread <= 1.5%, I0 <= 125mA, and Rm in 0.42–0.58 Ohm.",
            ],
            [
                "Station 7:\nQuad Clamshell & QR Label",
                "7_PLAPlus...Tray.stl + 8_PLAPlus...SnapLid.stl + 9_PETGCF...Tote.stl + Zebra ZD421",
                "40s / quad (10s/motor)\nTouch: 40s / quad",
                "Transfer all 4 matched motors at 18.0mm gang pitch into the Suspended Can-Shoulder Clamshell (#7+#8), apply the auto-printed "
                "70x45mm thermal QR telemetry label, and slot into the 18pt retail sleeve or 20-motor PETG-CF Kanban Tote (#9).",
            ],
        ],
    )

    # Section 3: Station 7 Packaging Physics & Serialization Spec
    add_heading_styled(doc, "3. Station 7 Motor Packaging Physics & QR Serialization Model", level=1)
    add_styled_table(
        doc,
        ["Packaging Subsystem", "Engineering Specification", "Avionics & Mechanical Protection Function"],
        [
            [
                "18.00 mm Pocket Pitch\n(Magnetic Dipole Isolation)",
                "X-Centers at -27.0, -9.0, +9.0, +27.0 mm (12.0mm edge gap)",
                "Reduces SPCC steel-can-shielded N52H dipole attraction force to 0.0032 N (0.33 gf) and worst-case unshielded pull to "
                "0.0463 N (<0.050 N limit), preventing magnetic clumping and matches Station 4 press pitch 1:1.",
            ],
            [
                "Suspended Can-Shoulder Cradle\n(Zero-Contact Shaft Vault)",
                "Clamps middle 11.5mm of 6.0mm steel can; +6.5mm top & -5.5mm bottom air vaults",
                "Provides +2.0mm axial and +2.5mm radial air clearance around the 1.00mm mirror shaft so 1.5m drop impacts never push "
                "the commutator into the 3-finger AgPd leaf brushes.",
            ],
            [
                "38mm S-Curve Troughs &\nJST-1.25mm Parking Clips",
                "4x R6.0mm strain-relief wire channels + 4.35x3.35mm PicoBlade pockets",
                "Prevents sharp wire bends at the TPU 95A HF boot and parks the 2-pin JST-1.25mm plugs pins-down.",
            ],
            [
                "70 x 45 mm Thermal QR Label\n(Recessed on SnapLid #8)",
                "Auto-printed by generate_station7_qr_label() upon Station 6 QC pass",
                "Records SKU, Lot/Serial, M1..M4 RPM/KV/Rm/I0 at 3.80V, Quad KV Spread % (Grade A+ <=0.5%, Grade A <=1.5%), and 2D QR JSON.",
            ],
        ],
    )

    # Section 4: Master 4-Tier Bambu Lab P2S 9-STL Tooling & Packaging Schedule
    add_heading_styled(doc, "4. Master 4-Tier Bambu Lab P2S Tooling & Packaging Print Schedule (All 9 STLs)", level=1)
    add_styled_table(
        doc,
        ["STL File (cad/)", "Filament & P2S AMS Slot", "Dimensions / Mass", "Station & Purpose"],
        [
            [
                "1_PAHTCF_0615_5Lobe_Rhombic_Coil_Winding_Mandrel.stl",
                "Bambu PAHT-CF (P2S #1 AMS Slot 2, <12% RH)",
                "3.85mm ID core | 0.12mm layer",
                "ST-1/ST-2: High-temp (160°C+) 5-pin mandrel for 155°C hot-air coil fusion.",
            ],
            [
                "2_PLAPlus_0615_4Up_Can_and_Endbell_Press_Fixture.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "80 x 32 x 20 mm (18mm pitch)",
                "ST-4: 4-cavity 6.10mm arbor press block matching clamshell tray pitch.",
            ],
            [
                "3_PLAPlus_0615_Brush_Spreader_Fork_and_Shaft_Gauge.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "50 x 16 x 8 mm",
                "ST-4: Guides 0.20mm brush-spreader shim + checks 4.50mm shaft protrusion.",
            ],
            [
                "4_PLAPlus_N52H_Magnet_Polarity_and_Cockroach65_Pod_Press.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "24mm OD x 65mm H",
                "ST-4/ST-7: Verifies N52H diametric polarity & presses cans/31mm props.",
            ],
            [
                "5_PETGCF_4Channel_BreakIn_and_Laser_KV_Test_Stand.stl",
                "Bambu PETG-CF (P2S #1 AMS Slot 1 — Print 6x)",
                "110 x 44 x 34.5 mm (x6 Racks)",
                "ST-6: 6-Rack Little's Law bank (24 channels) w/ optical IR tach slots.",
            ],
            [
                "6_TPU95AHF_Cockroach65_0615_StrainRelief_Endbell_Boots_x8.stl",
                "Bambu TPU 95A HF (P2S #2 External Dryer Port)",
                "7.4mm OD x 8.0mm H (8-Pack)",
                "ST-5: Anti-rip endbell boots (2 walls + 15% gyroid; never load in AMS).",
            ],
            [
                "7_PLAPlus_0615_Quad_Retail_Clamshell_Tray.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "96.0 x 84.0 x 11.0 mm (18.4g)",
                "ST-7: 4-motor 18mm-pitch Suspended Can-Shoulder Tray + spare prop bay.",
            ],
            [
                "8_PLAPlus_0615_Quad_Retail_Clamshell_SnapLid.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "96.0 x 84.0 x 7.5 mm (14.8g)",
                "ST-7: Snap-lid w/ 4x shaft windows & 70x45mm recessed QR label bay.",
            ],
            [
                "9_PETGCF_20Quad_SF_Warehouse_WIP_Kanban_Tote.stl",
                "Bambu PETG-CF (P2S #1 AMS Slot 1)",
                "112.0 x 118.0 x 96.0 mm (118g)",
                "ST-4..7 CONWIP: Stackable tote holding 5x closed Quad Clamshells (20 motors).",
            ],
            [
                "10_PAHTCF_MultiClass_0802_1404_2207_Stator_Winding_Arbors.stl",
                "Bambu PAHT-CF (P2S #1 AMS Slot 2, <12% RH)",
                "ER16 10mm shanks | 3.5/5.0/8.0mm pilots",
                "ST-1: Quick-change 9N (40° index) & 12N (30° index) radial stator winding arbors.",
            ],
            [
                "11_PAHTCF_12P_14P_N52SH_Magnet_Bell_Gluing_Spiders.stl",
                "Bambu PAHT-CF (P2S #1 AMS Slot 2, <12% RH)",
                "12-fin (30°) & 14-fin (25.71°) spiders",
                "ST-2: 155°C epoxy curing fixtures for 0802/1404 (12P) & 2207 (14P) N52SH arc magnets.",
            ],
            [
                "12_PLAPlus_1404_2207_5Inch_Quad_Retail_Clamshell_Tray.stl",
                "eSUN PLA+ (P2S #1 AMS Slot 3)",
                "148.0 x 136.0 x 26.0 mm (54mm 2x2 pitch)",
                "ST-7: Stepped 1404/2207 (5-Inch) Quad Clamshell w/ zero-contact M5 shaft air vault & M5 nut bay.",
            ],
        ],
    )

    # Section 5: Realistic 3-Phase Bootstrap & SF Facility Rollout ($378 Pilot Launch)
    add_heading_styled(doc, "5. Realistic 3-Phase Bootstrap & SF Facility Rollout (Start for $378 Out-of-Pocket)", level=1)
    add_callout_box(
        doc,
        "The 85/15 Engineering Rule & Avoiding the Day-1 SF Lease Trap",
        "1. Do NOT start with Stations 1–3 (scratch-winding 34 AWG copper baskets) in Week 1: factory-wound bare-tab 0615 cores cost "
        "$0.55/motor at 200 pcs vs $0.48–$0.55 in raw wire/magnets/cans, meaning scratch-winding saves only ~$0.10/motor while carrying "
        "90% of the scrap risk and $2,170 of CapEx. Instead, 85% of the savings ($4.25 -> $0.78/motor) and 100% of the STEM durability "
        "upgrade come from Station 5 (38mm silicone harness + TPU 95A HF anti-rip boot), Station 6 (12-min 1.80V DeoxIT break-in & KV "
        "matching), and Station 7 (Suspended Can-Shoulder Quad Clamshell).\n"
        "2. Do NOT sign a standalone $4,000/mo SF warehouse lease on Day 1: launch Phase 1 on a 6-ft bench next to the 2x Bambu P2S farm "
        "(or a $125–$250/mo pod at Humanmade 655 Bryant St in SF SOMA), where Batch #1 (50 Quads / 200 Motors) costs $378 total including "
        "tools and immediately saves +$472 vs buying 50 retail quad packs ($850)!",
    )
    add_styled_table(
        doc,
        ["Rollout Phase & Timeline", "SF Facility Strategy & Overhead", "Active Stations & Technical Scope", "Out-of-Pocket Cash & ROI"],
        [
            [
                "Phase 1 (Weeks 1–2):\nPilot 50 Quads (200 Motors)",
                "6-ft ESD Bench next to 2x Bambu P2S Farm ($0/mo) OR Humanmade SOMA (655 Bryant St, $125–$250/mo) / Circuit Launch.",
                "Print STLs #2–#9 on P2S ($18 filament). Buy 200 bare-tab 0615 19,500KV cores ($110) + 100 spare AgPd brush caps ($18) + "
                "200 pre-crimped JST-1.25 silicone leads ($22) + DeoxIT S100L ($29) + 4-ch INA226/IR tach ($38) + 30V supply ($68) + USB QR printer ($75).",
                "$378 Total Cash Outlay\n(Saves $472 vs $850 retail on Batch #1 alone — 100% self-funding!)",
            ],
            [
                "Phase 2 (Days 31–90):\n4-Piece SKD & 90s Rebuild Line",
                "Shared 350 sq ft lockable cage in SOMA / Dogpatch / Bayview PDR warehouse via SFMade (150 Hooper St) co-tenancy ($650–$1,100/mo, no 3-yr lease).",
                "Add 0.5T Arbor Press ($195), expand to full 6-Rack PETG-CF Break-In Bank (24 pods -> 25.7 Quads/hr = 102.9 Motors/hr), "
                "PA-09 crimper ($290) & Ultrasonic IPA bath ($100). Assemble from $0.42 SKD kits + rebuild classroom motors for $0.18/cap.",
                "+$745 Incremental CapEx\n(Funded by first 2 STEM camps / 50 retail Quad Pack sales)",
            ],
            [
                "Phase 3 (Month 4+):\nDedicated SF Warehouse & CNC Winder",
                "Dedicated 1,200–1,800 sq ft SF PDR-1-G / PDR-2 Warehouse housing: (1) 400 sq ft Motor/PCB Line, (2) 10x10 ft Netted Weekend STEM Camp Arena, (3) Fleet Ops.",
                "Triggered once revenue >= $18k/mo and motor volume >= 250 Quads/mo (1,000 motors/mo = $3,390/mo BOM savings). Add Stations 1–3 "
                "(2-Axis CNC Rhombic Winder + 155°C Thermo-Fusion + 45x Scope) for custom KV winding.",
                "+$2,170 Winder CapEx\n(Motor savings alone cover 85–100% of SF warehouse rent)",
            ],
        ],
    )

    # Section 6: Making It Work in SF or Anywhere in USA (3-Engine Revenue + NDAA Supply Chain)
    add_heading_styled(doc, "6. Nationwide Blueprint: 3-Engine Revenue Model, NDAA Supply Chain & 4-Bench Factory-in-a-Box", level=1)
    add_callout_box(
        doc,
        "Escaping the 'Internal Cost-Center Trap' via the 3-Engine Revenue Model",
        "Building only Osito's internal 110 quads/month saves $4,451/month but uses only 4.3 hours/month of machine time (2.7% utilization). "
        "To thrive in San Francisco or any US city, the 400 sq ft line runs 3 synergistic engines on 4 caster-mounted 60x30-inch ESD benches:\n"
        "• Engine A (Internal Fleet — 110 Quads/mo): Saves $4,451/month across Cockroach 65, CUB-75, SHARD-75, THERMO-95, and AI Security Drone.\n"
        "• Engine B (STEM 'Build-Your-Own-Motor' Lab Kits & Spares — 300 Kits + 250 Quads/mo): Students wind & test their own motors using "
        "our P2S arbors (#1/#10) at $45/student ($6.80 BOM -> $21,348/mo revenue, negative assembly labor cost!).\n"
        "• Engine C (100% Non-Chinese NDAA Sec. 848 & 10 U.S.C. § 4872 B2B/Defense Motors — 220 Quads/mo): Sells serialized US-wound 0802 "
        "($185/quad), 1404 ($295/quad), and 2207 ($480/quad) sets to Police DFR, DIU Blue UAS integrators, and universities ($82,700/mo revenue).\n"
        "• Breakeven Volume: Just 17 NDAA 2207 Quad Sets/month in San Francisco ($0 SF Gross Receipts Tax up to $5.0M under Prop M + CA "
        "CDTFA-230-M sales tax exemption) or 12 NDAA Quad Sets/month in a low-cost US hub (TX/NV/AZ/OH/AL) covers 100% of rent, utilities, and 1 FTE tech!",
    )
    add_styled_table(
        doc,
        ["Sub-Component", "Track 1 (Commercial / STEM SKD)", "Track 2 (100% NDAA / 10 U.S.C. § 4872 / TAA Non-Chinese)", "Engineering & Yield Discipline (>=98.5% FPY)"],
        [
            [
                "1. N52H / N52SH Magnets",
                "Stanford Magnets (CA) / K&J Magnetics ($0.11–$0.84/motor @ 1k)",
                "Noveon Magnetics (San Marcos TX), MP Materials (Fort Worth TX), e-VAC (SC), or Hitachi NEOMAX (Japan)",
                "Ni-Cu-Ni + 12 um Black Epoxy topcoat bonded w/ Loctite E-120HP / 3M DP420 + 0.06mm glass microbeads & 85°C post-cure.",
            ],
            [
                "2. 0.20mm Stator Stacks",
                "JFE 20JNEH1200 Asian/Taiwan SKD ($0.28–$0.72/motor @ 1k)",
                "Proto Lam LLC (Rancho Cucamonga CA) or Tempel Steel (Chicago IL) using JFE/Nippon Japan or Cleveland-Cliffs US steel",
                "Wound via External Orbital Flyer w/ Snap-On PAHT-CF / Polished ZrO2 Tooth-Tip Shroud Wings (zero corner scraping).",
            ],
            [
                "3. ABEC-7 Bearings",
                "Bunting CuSn8 / NMB Commercial ($0.04–$0.52/pair @ 1k)",
                "Sapporo Precision EZO (Japan via AST Bearings Irvine CA) or MinebeaMitsumi NMB (Japan/Thailand/NH)",
                "Pressed w/ Outer-Race-Only Stepped Pilot Punch (housing) & Hollow Inner-Race Anvil (shaft) + 0.05–0.10mm wave-spring preload.",
            ],
            [
                "4. Class-220 Magnet Wire",
                "MWS Wire Industries (Westlake Village CA) / Elektrisola (NH USA)",
                "100% US-Made NEMA MW 35-C (220°C Polyamide-Imide) from MWS Wire (CA) / Rea Magnet Wire (IN) ($0.05–$0.42/motor)",
                "5x28 AWG multi-strand on 2207 cuts radial winding force by 67%; stripped via 470°C Grade-2 Titanium Pot SN100C dip-tinning.",
            ],
            [
                "5. 6-Gate EOL Automated QC",
                "Station 6 6-Rack Break-In & Laser KV + Station 7 QR Clamshell",
                "Full 6-Gate Traceability encoded in 70x45mm 2D QR Label + Lot Certificate of Conformance (CoC)",
                "Gate 1: Kelvin Rm | Gate 2: 500V Hi-Pot | Gate 3: 10kHz LCR Ls/Q (1-turn short check) | Gate 4: 14-Pole BEMF Envelope | Gate 5: BMI270 FFT.",
            ],
        ],
    )

    doc.save(OUT_DOCX)
    print(f"[OK] Saved Updated Word SOP: {OUT_DOCX} ({os.path.getsize(OUT_DOCX):,} bytes)")


if __name__ == "__main__":
    build_docx()
