"""
OSITO DRONE LLC — SF Warehouse 2207 (5-Inch Class) 12N14P BLDC Motor Line
CNC Flyer Winder Path Generator, 12N14P LRK Electromagnetic Solver,
500V DC Hi-Pot & Milliohm Phase-Balance Inspector, Laser/Piezo Dynamic Balancer,
and 6S/4S 5kg Thrust Dyno Controller with NDAA Section 848 Lot Serializer.

Safety & Avionics Discipline (Rule 3):
  - Explicit Disarmed Safety Interlock (zero DShot/PWM throttle & zero Hi-Pot HV unless
    armed + polycarbonate blast shield closed + E-stop clear)
  - 16-bit unsigned millisecond rollover-safe watchdog & timing arithmetic:
      elapsed_ms = (now_ms - last_ms) & 0xFFFF
  - Instant thermal (>110.0 C), over-current (>48.0 A), phase-imbalance (>3.5%),
    Hi-Pot dielectric (<100 MOhm @ 500V DC), and vibration (>0.050 G) hardware trips
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple
import json
import math


UINT16_MASK = 0xFFFF

# Standard 12N14P DLRK (Distributed LRK) Winding Pattern: AaBbCcAaBbCc
# Uppercase = CW (+1), Lowercase = CCW (-1)
LRK_12N14P_PATTERN: List[Tuple[int, str, str, int]] = [
    (1,  "U", "A", +1),
    (2,  "U", "a", -1),
    (3,  "V", "B", +1),
    (4,  "V", "b", -1),
    (5,  "W", "C", +1),
    (6,  "W", "c", -1),
    (7,  "U", "A", +1),
    (8,  "U", "a", -1),
    (9,  "V", "B", +1),
    (10, "V", "b", -1),
    (11, "W", "C", +1),
    (12, "W", "c", -1),
]


def elapsed_u16_ms(now_ms: int, last_ms: int) -> int:
    """16-bit unsigned millisecond wrap-around safe delta calculation."""
    return (int(now_ms) - int(last_ms)) & UINT16_MASK


@dataclass
class Stator2207WindingSpec:
    """
    12N14P 2207 (22mm OD x 7mm stack) Brushless Outrunner Stator Specification.
      - 6S Tactical/Freestyle Spec: 9 turns/tooth, 0.55mm (23.5 AWG) MW35-C wire, Wye -> ~1850 KV
      - 4S Race/High-RPM Spec:      7 turns/tooth, 0.62mm (22.5 AWG) MW35-C wire, Wye -> ~2420 KV
    """
    stator_od_mm: float = 22.0
    stator_id_mm: float = 8.0
    stack_height_mm: float = 7.0
    tooth_stem_width_mm: float = 2.10
    slot_area_mm2: float = 8.40
    turns_per_tooth: int = 9
    parallel_strands: int = 1
    bare_strand_d_mm: float = 0.55
    coated_strand_d_mm: float = 0.59
    termination: str = "WYE"  # "WYE" (Star) or "DELTA"
    airgap_flux_density_t: float = 0.92  # N52SH 1.2mm curved arc magnet @ 0.14mm gap
    winding_factor_kw: float = 0.933     # 12N14P fundamental winding factor
    copper_resistivity_ohm_mm2_m: float = 0.01724

    @property
    def slot_fill_percent(self) -> float:
        """Calculates copper + enamel slot fill percentage inside a 2207 stator slot."""
        single_coated_area = math.pi * ((self.coated_strand_d_mm * 0.5) ** 2)
        conductors_in_slot = 2 * self.turns_per_tooth * self.parallel_strands
        total_wire_area = conductors_in_slot * single_coated_area
        return round((total_wire_area / self.slot_area_mm2) * 100.0, 1)

    def estimate_line_to_line_resistance_mohms(self) -> float:
        """
        Calculates line-to-line terminal resistance (mOhm) across two phase leads (U-V, V-W, W-U).
        In a high-thrust 2207 12N14P stator, each phase connects its two opposite tooth-pairs
        ((1,2) and (7,8)) in parallel (2P) or equivalent multi-strand bundle, plus 150mm 20AWG leads.
        """
        mean_turn_perimeter_mm = 2.0 * (self.stack_height_mm + 0.70) + 2.0 * (self.tooth_stem_width_mm + 0.70)
        branch_wire_length_m = (2 * self.turns_per_tooth * mean_turn_perimeter_mm) / 1000.0
        copper_area_mm2 = self.parallel_strands * math.pi * ((self.bare_strand_d_mm * 0.5) ** 2)
        r_branch_ohm = self.copper_resistivity_ohm_mm2_m * (branch_wire_length_m / copper_area_mm2)
        # Two opposite tooth-pair branches in parallel (2P) + 150mm 20AWG silicone lead (0.518 mm2)
        r_lead_ohm = self.copper_resistivity_ohm_mm2_m * (0.150 / 0.518)
        r_phase_ohm = 0.5 * r_branch_ohm + r_lead_ohm
        if self.termination.upper() == "WYE":
            r_line_ohm = 2.0 * r_phase_ohm
        else:
            r_line_ohm = (2.0 / 3.0) * r_phase_ohm
        return round(r_line_ohm * 1000.0, 2)

    def estimate_motor_kv(self) -> float:
        """
        Estimates unloaded motor KV (RPM/Volt) from 12N14P electromagnetic back-EMF constant.
        Calibrated to empirical SF-2207 N52SH curved-magnet geometry (9T Wye @ 7.0mm stack = 1850 KV).
        """
        base_kv_9t_wye = 1850.0
        kv = base_kv_9t_wye * (9.0 / max(self.turns_per_tooth, 1)) * (7.0 / max(self.stack_height_mm, 1.0)) * (0.92 / max(self.airgap_flux_density_t, 0.2))
        if self.termination.upper() == "DELTA":
            kv *= math.sqrt(3.0)
        return round(kv, 0)

    def generate_cnc_flyer_waypoints(self) -> List[Dict[str, Any]]:
        """Generates deterministic 12-tooth CNC flyer winder trajectory waypoints."""
        waypoints: List[Dict[str, Any]] = []
        for tooth_idx, phase_name, sub_coil, direction in LRK_12N14P_PATTERN:
            stator_angle_deg = (tooth_idx - 1) * 30.0
            for turn in range(1, self.turns_per_tooth + 1):
                z_layer_mm = round(0.55 + ((turn - 1) % 5) * 1.15, 2)
                waypoints.append({
                    "tooth": tooth_idx,
                    "phase": phase_name,
                    "coil_code": sub_coil,
                    "direction": "CW" if direction > 0 else "CCW",
                    "turn": turn,
                    "stator_index_deg": stator_angle_deg,
                    "flyer_delta_deg": round(360.0 * direction * turn, 1),
                    "z_layer_mm": z_layer_mm,
                })
        return waypoints


@dataclass
class DynamicRotorBalancerSolver:
    """
    Computes ISO 1940 G1.0 dynamic unbalance (g*mm) and exact UV-cure putty correction mass (mg)
    and target pole index (#1..#14) from optical laser RPM and piezo vibration telemetry.
    """
    rotor_mass_g: float = 16.8
    correction_radius_mm: float = 11.15
    num_poles: int = 14
    g_Per_gmm_at_18k_rpm: float = 10.0  # Calibration constant: 0.050 G @ 18,000 RPM = 0.0050 g*mm

    def solve_correction(self, rpm: float, peak_vib_g: float, heavy_spot_angle_deg: float) -> Dict[str, Any]:
        if rpm <= 100.0 or peak_vib_g <= 0.0:
            return {
                "unbalance_g_mm": 0.0,
                "iso_g1_pass": True,
                "putty_mass_mg": 0.0,
                "correction_angle_deg": 0.0,
                "nearest_pole_number": 1,
            }
        rpm_scale = (18000.0 / max(rpm, 1000.0)) ** 2
        unbalance_g_mm = (peak_vib_g / self.g_Per_gmm_at_18k_rpm) * rpm_scale
        putty_mass_mg = (unbalance_g_mm / self.correction_radius_mm) * 1000.0
        correction_angle_deg = (heavy_spot_angle_deg + 180.0) % 360.0
        pole_pitch_deg = 360.0 / self.num_poles
        nearest_pole = int(round(correction_angle_deg / pole_pitch_deg)) % self.num_poles + 1
        return {
            "unbalance_g_mm": round(unbalance_g_mm, 5),
            "iso_g1_pass": unbalance_g_mm <= 0.0050,
            "putty_mass_mg": round(putty_mass_mg, 2),
            "correction_angle_deg": round(correction_angle_deg, 1),
            "nearest_pole_number": nearest_pole,
        }


@dataclass
class Motor2207Telemetry:
    serial_id: str
    voltage_v: float = 0.0
    current_a: float = 0.0
    stator_temp_c: float = 25.0
    rpm: float = 0.0
    thrust_g: float = 0.0
    vib_g: float = 0.012
    vib_phase_deg: float = 45.0
    hipot_500v_mohms: float = 550.0
    r_uv_mohms: float = 46.2
    r_vw_mohms: float = 46.5
    r_wu_mohms: float = 46.1
    fault_reason: str = ""

    @property
    def measured_kv(self) -> float:
        if self.voltage_v <= 1.0:
            return 0.0
        return round(self.rpm / self.voltage_v, 0)

    @property
    def phase_imbalance_pct(self) -> float:
        vals = [self.r_uv_mohms, self.r_vw_mohms, self.r_wu_mohms]
        mean_r = sum(vals) / 3.0
        if mean_r <= 0.1:
            return 100.0
        return round(((max(vals) - min(vals)) / mean_r) * 100.0, 2)


@dataclass
class SFWarehouse2207DynoAndHiPotController:
    """
    Avionics-grade SF Warehouse 2207 QC Controller:
      - Enforces disarmed safety interlock, polycarbonate blast-shield switch, and E-Stop
      - Enforces 16-bit rollover-safe watchdog timer (250 ms timeout)
      - Executes 500V DC Hi-Pot dielectric test (>= 100 MOhm) & phase milliohm balance (<= 3.5%)
      - Controls DShot throttle & logs NDAA Section 848 compliance certificates
    """
    armed: bool = False
    blast_shield_closed: bool = False
    emergency_stop_clear: bool = True
    last_heartbeat_u16_ms: int = 0
    watchdog_timeout_ms: int = 250
    max_current_a: float = 48.0
    max_temp_c: float = 110.0
    min_hipot_mohms: float = 100.0
    max_phase_imbalance_pct: float = 3.5
    max_vibration_g: float = 0.050
    target_kv: float = 1850.0
    kv_tolerance_pct: float = 3.0

    def arm_dyno(self, shield_closed: bool, estop_clear: bool, now_u16_ms: int) -> bool:
        self.blast_shield_closed = bool(shield_closed)
        self.emergency_stop_clear = bool(estop_clear)
        if not self.blast_shield_closed or not self.emergency_stop_clear:
            self.armed = False
            return False
        self.armed = True
        self.last_heartbeat_u16_ms = now_u16_ms & UINT16_MASK
        return True

    def disarm_dyno(self) -> None:
        self.armed = False

    def feed_watchdog(self, now_u16_ms: int) -> None:
        self.last_heartbeat_u16_ms = now_u16_ms & UINT16_MASK

    def step_safety_and_qc(
        self,
        now_u16_ms: int,
        requested_throttle_pct: float,
        telemetry: Motor2207Telemetry,
    ) -> Dict[str, Any]:
        # 1. Check physical interlocks first
        if not self.armed or not self.blast_shield_closed or not self.emergency_stop_clear:
            self.armed = False
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": "DISARMED_OR_BLAST_SHIELD_OPEN",
            }

        # 2. 16-bit rollover-safe watchdog evaluation
        dt_ms = elapsed_u16_ms(now_u16_ms, self.last_heartbeat_u16_ms)
        if dt_ms > self.watchdog_timeout_ms:
            self.armed = False
            telemetry.fault_reason = f"WATCHDOG_TIMEOUT_{dt_ms}MS"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        # 3. Pre-spin electrical QC checks (500V Hi-Pot & 3-Phase Milliohm Symmetry)
        if telemetry.hipot_500v_mohms < self.min_hipot_mohms:
            self.armed = False
            telemetry.fault_reason = f"HIPOT_DIELECTRIC_FAIL_{telemetry.hipot_500v_mohms:.1f}MOHM"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        if telemetry.phase_imbalance_pct > self.max_phase_imbalance_pct:
            self.armed = False
            telemetry.fault_reason = f"PHASE_IMBALANCE_{telemetry.phase_imbalance_pct:.2f}PCT"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        # 4. Dynamic spin thermal, over-current, and vibration trips
        if telemetry.current_a > self.max_current_a:
            self.armed = False
            telemetry.fault_reason = f"OVER_CURRENT_{telemetry.current_a:.1f}A"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        if telemetry.stator_temp_c > self.max_temp_c:
            self.armed = False
            telemetry.fault_reason = f"STATOR_OVER_TEMP_{telemetry.stator_temp_c:.1f}C"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        if telemetry.vib_g > self.max_vibration_g:
            self.armed = False
            telemetry.fault_reason = f"ROTOR_UNBALANCE_{telemetry.vib_g:.3f}G"
            return {
                "safe": False,
                "dshot_throttle_pct": 0.0,
                "reason": telemetry.fault_reason,
            }

        clamped_throttle = max(0.0, min(100.0, float(requested_throttle_pct)))
        return {
            "safe": True,
            "dshot_throttle_pct": clamped_throttle,
            "reason": "OK",
        }

    def generate_ndaa_certificate(
        self,
        telemetry: Motor2207Telemetry,
        magnet_lot: str = "US-MP-NOVEON-N52SH-2026-11",
        wire_lot: str = "US-MWS-CA-MW35C-055MM-2026-11",
        stator_lot: str = "US-PROTOLAM-CA-M19-015MM-2026-11",
    ) -> Dict[str, Any]:
        balancer = DynamicRotorBalancerSolver()
        bal_res = balancer.solve_correction(telemetry.rpm, telemetry.vib_g, telemetry.vib_phase_deg)
        kv_err_pct = abs(telemetry.measured_kv - self.target_kv) / max(self.target_kv, 1.0) * 100.0
        qc_pass = (
            telemetry.fault_reason == ""
            and telemetry.hipot_500v_mohms >= self.min_hipot_mohms
            and telemetry.phase_imbalance_pct <= self.max_phase_imbalance_pct
            and bal_res["iso_g1_pass"]
            and kv_err_pct <= self.kv_tolerance_pct
        )
        return {
            "serial_id": telemetry.serial_id,
            "model": "OSITO-SF-2207-1850KV-NDAA",
            "origin": "San Francisco, CA, USA",
            "ndaa_section_848_compliant": True,
            "traceability": {
                "magnet_lot": magnet_lot,
                "magnet_wire_lot": wire_lot,
                "stator_steel_lot": stator_lot,
            },
            "electrical_qc": {
                "measured_kv": telemetry.measured_kv,
                "kv_error_pct": round(kv_err_pct, 2),
                "hipot_500v_mohms": telemetry.hipot_500v_mohms,
                "phase_imbalance_pct": telemetry.phase_imbalance_pct,
            },
            "mechanical_qc": {
                "peak_thrust_g": telemetry.thrust_g,
                "vibration_g": telemetry.vib_g,
                "residual_unbalance_g_mm": bal_res["unbalance_g_mm"],
                "iso_1940_g1_pass": bal_res["iso_g1_pass"],
            },
            "qc_status": "PASS_NDAA_GRADE_A" if qc_pass else "REJECT_REWORK",
        }


if __name__ == "__main__":
    spec_6s = Stator2207WindingSpec(turns_per_tooth=9, bare_strand_d_mm=0.55, coated_strand_d_mm=0.59, termination="WYE")
    spec_4s = Stator2207WindingSpec(turns_per_tooth=7, bare_strand_d_mm=0.62, coated_strand_d_mm=0.66, termination="WYE")
    print(f"SF-2207 6S Spec (9T Wye): KV={spec_6s.estimate_motor_kv()} | R_line={spec_6s.estimate_line_to_line_resistance_mohms()} mOhm | Slot Fill={spec_6s.slot_fill_percent}%")
    print(f"SF-2207 4S Spec (7T Wye): KV={spec_4s.estimate_motor_kv()} | R_line={spec_4s.estimate_line_to_line_resistance_mohms()} mOhm | Slot Fill={spec_4s.slot_fill_percent}%")
