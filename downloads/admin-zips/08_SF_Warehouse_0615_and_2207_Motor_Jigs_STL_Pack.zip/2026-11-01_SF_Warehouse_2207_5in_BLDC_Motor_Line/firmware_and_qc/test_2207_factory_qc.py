"""
Unit Tests for OSITO SF-2207 (5-Inch Class) BLDC Motor Line Firmware & QC Suite.
Verifies Rule 3 Safety & Avionics Discipline:
  1. Disarmed & Blast-Shield safety interlocks
  2. 16-bit unsigned millisecond rollover-safe watchdog timer
  3. 12N14P (AaBbCcAaBbCc) CNC flyer winding trajectory & KV/slot-fill physics
  4. 500V DC Hi-Pot dielectric breakdown & 3-phase milliohm imbalance trips
  5. ISO 1940 G1.0 dynamic rotor balancing vector solver & NDAA Section 848 serializer
"""
from osito_2207_winder_balancer_and_kv_tester import (
    DynamicRotorBalancerSolver,
    Motor2207Telemetry,
    SFWarehouse2207DynoAndHiPotController,
    Stator2207WindingSpec,
    elapsed_u16_ms,
)


def test_u16_millisecond_rollover_safety():
    # Standard non-wrapped delta
    assert elapsed_u16_ms(1250, 1000) == 250
    # Across 16-bit rollover boundary (65500 -> 65535 -> 0 -> 164 = 200 ms)
    assert elapsed_u16_ms(164, 65500) == 200


def test_12n14p_stator_winding_physics_and_waypoints():
    spec_6s = Stator2207WindingSpec(turns_per_tooth=9, bare_strand_d_mm=0.55, coated_strand_d_mm=0.59, termination="WYE")
    assert spec_6s.estimate_motor_kv() == 1850.0
    assert 35.0 <= spec_6s.estimate_line_to_line_resistance_mohms() <= 55.0
    assert 50.0 <= spec_6s.slot_fill_percent <= 65.0

    waypoints = spec_6s.generate_cnc_flyer_waypoints()
    # 12 teeth * 9 turns = 108 total turn waypoints
    assert len(waypoints) == 108
    # Tooth 1 is Phase U ('A', CW), Tooth 2 is Phase U ('a', CCW)
    assert waypoints[0]["tooth"] == 1 and waypoints[0]["direction"] == "CW"
    assert waypoints[9]["tooth"] == 2 and waypoints[9]["direction"] == "CCW"


def test_disarmed_and_blast_shield_interlock():
    ctrl = SFWarehouse2207DynoAndHiPotController()
    telem = Motor2207Telemetry(serial_id="OSITO-2207-0001")

    # Attempting to command 80% throttle while disarmed MUST output 0.0%
    res = ctrl.step_safety_and_qc(now_u16_ms=100, requested_throttle_pct=80.0, telemetry=telem)
    assert res["safe"] is False
    assert res["dshot_throttle_pct"] == 0.0

    # Attempting to arm with blast shield open MUST fail
    assert ctrl.arm_dyno(shield_closed=False, estop_clear=True, now_u16_ms=100) is False
    assert ctrl.armed is False

    # Arming with shield closed and E-stop clear succeeds
    assert ctrl.arm_dyno(shield_closed=True, estop_clear=True, now_u16_ms=100) is True
    res_armed = ctrl.step_safety_and_qc(now_u16_ms=200, requested_throttle_pct=75.0, telemetry=telem)
    assert res_armed["safe"] is True
    assert res_armed["dshot_throttle_pct"] == 75.0


def test_watchdog_rollover_and_hardware_trips():
    ctrl = SFWarehouse2207DynoAndHiPotController()
    telem = Motor2207Telemetry(serial_id="OSITO-2207-0002", voltage_v=22.2, rpm=41070.0)
    ctrl.arm_dyno(shield_closed=True, estop_clear=True, now_u16_ms=65450)

    # 180 ms across 65535 wrap-around -> within 250 ms timeout -> SAFE
    res_ok = ctrl.step_safety_and_qc(now_u16_ms=94, requested_throttle_pct=50.0, telemetry=telem)
    assert res_ok["safe"] is True
    assert res_ok["dshot_throttle_pct"] == 50.0

    # 300 ms across wrap-around -> exceeds 250 ms timeout -> TRIPS & DISARMS
    res_wd = ctrl.step_safety_and_qc(now_u16_ms=214, requested_throttle_pct=50.0, telemetry=telem)
    assert res_wd["safe"] is False
    assert res_wd["dshot_throttle_pct"] == 0.0
    assert "WATCHDOG_TIMEOUT" in res_wd["reason"]

    # Re-arm and test 500V Hi-Pot dielectric failure (< 100 MOhm)
    telem_bad_hipot = Motor2207Telemetry(serial_id="OSITO-2207-0003", hipot_500v_mohms=42.0)
    ctrl.arm_dyno(shield_closed=True, estop_clear=True, now_u16_ms=1000)
    res_hipot = ctrl.step_safety_and_qc(now_u16_ms=1050, requested_throttle_pct=30.0, telemetry=telem_bad_hipot)
    assert res_hipot["safe"] is False
    assert "HIPOT_DIELECTRIC_FAIL" in res_hipot["reason"]


def test_dynamic_balancer_and_ndaa_certificate():
    solver = DynamicRotorBalancerSolver()
    # Unbalanced bell: 0.12 G @ 18,000 RPM, heavy spot at 30 deg -> needs counterweight at 210 deg (Pole #9)
    unbal = solver.solve_correction(rpm=18000.0, peak_vib_g=0.12, heavy_spot_angle_deg=30.0)
    assert unbal["iso_g1_pass"] is False
    assert unbal["correction_angle_deg"] == 210.0
    assert unbal["putty_mass_mg"] > 0.8

    # Balanced bell: 0.015 G @ 18,000 RPM -> ISO G1.0 PASS
    ctrl = SFWarehouse2207DynoAndHiPotController(target_kv=1850.0)
    telem_good = Motor2207Telemetry(
        serial_id="OSITO-SF2207-NDAA-0101",
        voltage_v=22.2,
        rpm=41070.0,
        thrust_g=1940.0,
        vib_g=0.015,
        hipot_500v_mohms=620.0,
    )
    cert = ctrl.generate_ndaa_certificate(telem_good)
    assert cert["ndaa_section_848_compliant"] is True
    assert cert["qc_status"] == "PASS_NDAA_GRADE_A"
    assert cert["electrical_qc"]["measured_kv"] == 1850.0
