// ============================================================================
// OSITO DRONE LLC — SF Warehouse 2207 (5-Inch Class) 12N14P BLDC Motor Factory
// Master Parametric OpenSCAD Tooling, Insulator, Balancer & NDAA Packaging Pack
// Target Farm: 2x Bambu Lab P2S Combo (0.4mm Hardened Steel Nozzle)
//
// Master 4-Tier Filament Discipline (Rule 3):
//   Part 1: Bambu PAHT-CF (P2S #1 AMS Slot 2, <12% RH) -> 2207 12-Slot Stator End-Insulator Caps (x8)
//   Part 2: eSUN PLA+ (P2S #1 AMS Slot 3) -> 12-Tooth LRK Stator Winding Indexing Turret
//   Part 3: eSUN PLA+ (P2S #1 AMS Slot 3) -> 14-Pole N52SH Curved Arc Magnet Spacing & Polarity Jig
//   Part 4: eSUN PLA+ (P2S #1 AMS Slot 3) -> MR94ZZ Dual Bearing & 4mm TC4 Shaft Arbor Press
//   Part 5: Bambu PETG-CF (P2S #1 AMS Slot 1) -> Laser + Piezo Dynamic Balancer & 5kg Thrust Dyno Stand
//   Part 6: Bambu TPU 95A HF (P2S #2 External Dryer Port, 2 walls + 15% gyroid) -> Balancer Flexures & Boots
//   Part 7: eSUN PLA+ (P2S #1 AMS Slot 3) -> NDAA 2207 Quad-Set Retail Clamshell Tray
//   Part 8: eSUN PLA+ (P2S #1 AMS Slot 3) -> NDAA 2207 Quad-Set Clamshell Snap-Lid
//   Part 9: Bambu PETG-CF (P2S #1 AMS Slot 1) -> 16-Motor SF Warehouse WIP Kanban Curing Tote
// ============================================================================

$fn = 72;

// Core SF-2207 Motor Geometry Constants
stator_od = 22.0;
stator_id = 8.0;
stator_h  = 7.0;
num_teeth = 12;
num_poles = 14;
bell_od   = 27.5;
bell_id   = 22.3;
shaft_d   = 4.0;
bearing_od = 9.0;
bearing_id = 4.0;
bearing_h  = 4.0;

// 1. PAHT-CF 2207 12-Slot Stator End-Insulator Cap
module stator_end_insulator_cap() {
    difference() {
        union() {
            cylinder(d=stator_id + 1.6, h=1.8);
            for (i = [0 : num_teeth - 1]) {
                rotate([0, 0, i * (360 / num_teeth)])
                translate([0, -1.3, 0])
                cube([stator_od / 2 - 0.5, 2.6, 1.4]);
            }
        }
        translate([0, 0, -0.1])
        cylinder(d=stator_id + 0.05, h=2.2);
    }
}

// 2. PLA+ 12-Tooth LRK Stator Winding Indexing Turret
module stator_winding_turret() {
    difference() {
        union() {
            cylinder(d=68, h=8);
            cylinder(d=26, h=22);
            cylinder(d=stator_id - 0.08, h=31);
        }
        // Central M4 tie-down screw bore
        translate([0, 0, -0.1])
        cylinder(d=4.2, h=35);
        // 12 indexing detents around base perimeter (AaBbCcAaBbCc)
        for (i = [0 : 11]) {
            rotate([0, 0, i * 30])
            translate([34, 0, -0.1])
            cylinder(d=5.0, h=8.2);
        }
    }
}

// 3. PLA+ 14-Pole N52SH Arc Magnet Spacing & Polarity Jig
module magnet_spacing_jig() {
    difference() {
        union() {
            cylinder(d=44, h=6);
            cylinder(d=bell_id - 0.15, h=18);
        }
        // 14 precision radial magnet guide slots (7.0 x 3.5 x 1.2mm arc)
        for (p = [0 : num_poles - 1]) {
            rotate([0, 0, p * (360 / num_poles)])
            translate([bell_id / 2 - 1.35, -1.82, 6.0])
            cube([1.6, 3.64, 12.5]);
        }
        translate([0, 0, -0.1])
        cylinder(d=8.0, h=20);
    }
}

// 4. PLA+ MR94ZZ Bearing & 4mm TC4 Shaft Arbor Press
module bearing_arbor_press() {
    difference() {
        cylinder(d=48, h=18);
        translate([0, 0, 10])
        cylinder(d=28.2, h=9);
        translate([0, 0, 4])
        cylinder(d=bearing_od + 0.15, h=7);
        translate([0, 0, -0.1])
        cylinder(d=shaft_d + 0.25, h=20);
    }
}

// 5. PETG-CF Dynamic Balancer & 5kg Thrust Dyno Stand
module dynamic_balancer_dyno_stand() {
    difference() {
        union() {
            translate([-55, -35, 0]) cube([110, 70, 8]);
            translate([-18, -18, 8]) cube([36, 36, 52]);
        }
        // 16x16mm M3 motor mounting pattern + 9mm shaft relief
        translate([0, 0, 45]) cylinder(d=9.5, h=16);
        for (a = [0, 90, 180, 270]) {
            rotate([0, 0, a + 45])
            translate([8.0, 0, 45])
            cylinder(d=3.2, h=16);
        }
    }
}

// Layout preview of all shop tools
translate([-80,  60, 0]) stator_end_insulator_cap();
translate([  0,  60, 0]) stator_winding_turret();
translate([ 80,  60, 0]) magnet_spacing_jig();
translate([-80, -40, 0]) bearing_arbor_press();
translate([ 20, -40, 0]) dynamic_balancer_dyno_stand();
