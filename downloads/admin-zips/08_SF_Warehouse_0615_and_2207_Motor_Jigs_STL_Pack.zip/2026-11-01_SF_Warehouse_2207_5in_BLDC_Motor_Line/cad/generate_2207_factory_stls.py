"""
OSITO DRONE LLC — SF Warehouse 2207 (5-Inch Class) 12N14P BLDC Motor Tooling & Packaging STL Generator
Generates 9 watertight binary STL files (6 Shop Tools + 3 NDAA Packaging & WIP Kanban Totes)
for the 2x Bambu Lab P2S Combo Farm (Rule 3 Master 4-Tier Filament Discipline).
"""
import math
import os
import struct

CAD_DIR = os.path.dirname(os.path.abspath(__file__))


def write_binary_stl(filepath: str, triangles: list, header_text: str) -> int:
    header = header_text.encode("ascii", errors="ignore")[:80].ljust(80, b"\x00")
    with open(filepath, "wb") as f:
        f.write(header)
        f.write(struct.pack("<I", len(triangles)))
        for p1, p2, p3 in triangles:
            ux, uy, uz = p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2]
            vx, vy, vz = p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            length = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            nx, ny, nz = nx / length, ny / length, nz / length
            f.write(
                struct.pack(
                    "<12fH",
                    nx, ny, nz,
                    p1[0], p1[1], p1[2],
                    p2[0], p2[1], p2[2],
                    p3[0], p3[1], p3[2],
                    0,
                )
            )
    return len(triangles)


def make_box(x0, y0, z0, dx, dy, dz):
    x1, y1, z1 = x0 + dx, y0 + dy, z0 + dz
    v = [
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ]
    faces = [
        (0, 2, 1), (0, 3, 2),
        (4, 5, 6), (4, 6, 7),
        (0, 1, 5), (0, 5, 4),
        (1, 2, 6), (1, 6, 5),
        (2, 3, 7), (2, 7, 6),
        (3, 0, 4), (3, 4, 7),
    ]
    return [(v[a], v[b], v[c]) for a, b, c in faces]


def make_tube(cx, cy, z0, z1, r_in, r_out, r_in2=None, r_out2=None, segs=48):
    if r_in2 is None:
        r_in2 = r_in
    if r_out2 is None:
        r_out2 = r_out
    tris = []
    for i in range(segs):
        a0 = 2.0 * math.pi * i / segs
        a1 = 2.0 * math.pi * (i + 1) / segs
        c0, s0 = math.cos(a0), math.sin(a0)
        c1, s1 = math.cos(a1), math.sin(a1)

        if r_in <= 1e-6 and r_in2 <= 1e-6:
            b_center = (cx, cy, z0)
            t_center = (cx, cy, z1)
            b0 = (cx + r_out * c0, cy + r_out * s0, z0)
            b1 = (cx + r_out * c1, cy + r_out * s1, z0)
            t0 = (cx + r_out2 * c0, cy + r_out2 * s0, z1)
            t1 = (cx + r_out2 * c1, cy + r_out2 * s1, z1)
            tris.append((b_center, b1, b0))
            tris.append((t_center, t0, t1))
            tris.append((b0, b1, t1))
            tris.append((b0, t1, t0))
        else:
            bi0 = (cx + r_in * c0, cy + r_in * s0, z0)
            bi1 = (cx + r_in * c1, cy + r_in * s1, z0)
            bo0 = (cx + r_out * c0, cy + r_out * s0, z0)
            bo1 = (cx + r_out * c1, cy + r_out * s1, z0)

            ti0 = (cx + r_in2 * c0, cy + r_in2 * s0, z1)
            ti1 = (cx + r_in2 * c1, cy + r_in2 * s1, z1)
            to0 = (cx + r_out2 * c0, cy + r_out2 * s0, z1)
            to1 = (cx + r_out2 * c1, cy + r_out2 * s1, z1)

            tris.append((bi0, bo1, bo0))
            tris.append((bi0, bi1, bo1))
            tris.append((ti0, to0, to1))
            tris.append((ti0, to1, ti1))
            tris.append((bo0, bo1, to1))
            tris.append((bo0, to1, to0))
            tris.append((bi0, ti1, bi1))
            tris.append((bi0, ti0, ti1))
    return tris


def build_all_stls():
    outputs = []

    # 1. Bambu PAHT-CF (P2S #1 AMS Slot 2) — 2207 12-Slot Stator End-Insulator Caps (8-up array)
    t1 = []
    for row in range(2):
        for col in range(4):
            cx = (col - 1.5) * 26.0
            cy = (row - 0.5) * 26.0
            # Central hub ring (8.0mm ID, 10.2mm OD, 1.8mm height)
            t1 += make_tube(cx, cy, 0.0, 1.8, 4.02, 5.10, segs=36)
            # 12 radial tooth insulator spokes
            for tooth in range(12):
                ang = 2.0 * math.pi * tooth / 12.0
                sx = cx + 7.5 * math.cos(ang)
                sy = cy + 7.5 * math.sin(ang)
                t1 += make_box(sx - 1.4, sy - 1.4, 0.0, 2.8, 2.8, 1.2)
    f1 = os.path.join(CAD_DIR, "1_PAHTCF_2207_12Slot_Stator_End_Insulator_Caps_x8.stl")
    n1 = write_binary_stl(f1, t1, "OSITO PAHT-CF 2207 12-Slot Stator End-Insulator Caps x8")
    outputs.append((os.path.basename(f1), n1))

    # 2. eSUN PLA+ (P2S #1 AMS Slot 3) — 2207 12-Tooth LRK Stator Winding Indexing Fixture
    t2 = []
    t2 += make_tube(0, 0, 0.0, 8.0, 2.1, 34.0, segs=72)
    t2 += make_tube(0, 0, 8.0, 22.0, 2.1, 13.0, segs=64)
    t2 += make_tube(0, 0, 22.0, 31.0, 2.1, 3.96, segs=48)  # 7.92mm slip-fit stator ID mandrel
    for idx in range(12):
        ang = 2.0 * math.pi * idx / 12.0
        px, py = 28.0 * math.cos(ang), 28.0 * math.sin(ang)
        t2 += make_tube(px, py, 8.0, 12.5, 0.0, 2.2, segs=24)
    f2 = os.path.join(CAD_DIR, "2_PLAPlus_2207_12Tooth_LRK_Stator_Winding_Indexing_Fixture.stl")
    n2 = write_binary_stl(f2, t2, "OSITO PLA+ 2207 12-Tooth LRK Stator Winding Indexing Turret")
    outputs.append((os.path.basename(f2), n2))

    # 3. eSUN PLA+ (P2S #1 AMS Slot 3) — 14-Pole N52SH Curved Arc Magnet Spacing & Polarity Jig
    t3 = []
    t3 += make_tube(0, 0, 0.0, 6.0, 4.0, 22.0, segs=64)
    t3 += make_tube(0, 0, 6.0, 18.0, 4.0, 11.05, segs=64)
    for pole in range(14):
        ang = 2.0 * math.pi * pole / 14.0
        rx, ry = 10.6 * math.cos(ang), 10.6 * math.sin(ang)
        t3 += make_box(rx - 0.7, ry - 0.7, 6.0, 1.4, 1.4, 12.0)
    # Plus N52 Polarity Wand next to jig
    t3 += make_box(30.0, -6.0, 0.0, 75.0, 12.0, 6.0)
    f3 = os.path.join(CAD_DIR, "3_PLAPlus_2207_14Pole_N52SH_Arc_Magnet_Spacing_and_Polarity_Jig.stl")
    n3 = write_binary_stl(f3, t3, "OSITO PLA+ 2207 14-Pole N52SH Magnet Spacing Jig and Wand")
    outputs.append((os.path.basename(f3), n3))

    # 4. eSUN PLA+ (P2S #1 AMS Slot 3) — MR94ZZ Dual Bearing & 4mm TC4 Shaft Concentric Arbor Press
    t4 = []
    t4 += make_tube(0, 0, 0.0, 12.0, 2.15, 24.0, segs=64)
    t4 += make_tube(0, 0, 12.0, 20.0, 14.1, 24.0, segs=64)
    # Top Drift Driver (outer-race-only contact for 9mm MR94ZZ bearing)
    t4 += make_tube(56.0, 0, 0.0, 18.0, 2.15, 11.0, segs=48)
    t4 += make_tube(56.0, 0, 18.0, 25.0, 2.15, 4.42, segs=48)
    f4 = os.path.join(CAD_DIR, "4_PLAPlus_2207_MR94ZZ_Dual_Bearing_and_TC4_Shaft_Arbor_Press.stl")
    n4 = write_binary_stl(f4, t4, "OSITO PLA+ 2207 MR94ZZ Bearing and 4mm TC4 Shaft Arbor Press")
    outputs.append((os.path.basename(f4), n4))

    # 5. Bambu PETG-CF (P2S #1 AMS Slot 1) — Laser + Piezo Dynamic Balancer & 5kg Thrust Dyno Stand
    t5 = []
    t5 += make_box(-60.0, -38.0, 0.0, 120.0, 76.0, 8.0)
    t5 += make_box(-18.0, -18.0, 8.0, 36.0, 36.0, 52.0)
    t5 += make_box(24.0, -12.0, 8.0, 28.0, 24.0, 38.0)  # Optical laser tach turret
    f5 = os.path.join(CAD_DIR, "5_PETGCF_2207_Laser_Piezo_Dynamic_Balancer_and_5kg_Thrust_Dyno.stl")
    n5 = write_binary_stl(f5, t5, "OSITO PETG-CF 2207 Dynamic Balancer and 5kg Thrust Dyno Stand")
    outputs.append((os.path.basename(f5), n5))

    # 6. Bambu TPU 95A HF (P2S #2 External Dryer Port) — Balancer Isolation Flexures & 20AWG Boots (x8)
    t6 = []
    for i in range(4):
        fx = -45.0 + i * 30.0
        t6 += make_tube(fx, -18.0, 0.0, 8.0, 2.0, 9.0, segs=36)
    for i in range(8):
        bx = -52.5 + i * 15.0
        t6 += make_box(bx - 4.5, 10.0, 0.0, 9.0, 14.0, 5.5)
    f6 = os.path.join(CAD_DIR, "6_TPU95AHF_2207_Balancer_Isolation_Flexures_and_20AWG_Wire_Boots_x8.stl")
    n6 = write_binary_stl(f6, t6, "OSITO TPU 95A HF 2207 Balancer Flexures and 20AWG Boots x8")
    outputs.append((os.path.basename(f6), n6))

    # 7. eSUN PLA+ (P2S #1 AMS Slot 3) — 2207 NDAA Quad-Set Retail Clamshell Tray
    t7 = []
    t7 += make_box(-68.0, -68.0, 0.0, 136.0, 136.0, 4.0)
    for r in (-34.0, 34.0):
        for c in (-34.0, 34.0):
            t7 += make_tube(c, r, 4.0, 24.0, 14.2, 18.5, segs=48)
    f7 = os.path.join(CAD_DIR, "7_PLAPlus_2207_NDAA_Quad_Set_Clamshell_Tray.stl")
    n7 = write_binary_stl(f7, t7, "OSITO PLA+ 2207 NDAA Quad-Set Retail Clamshell Tray")
    outputs.append((os.path.basename(f7), n7))

    # 8. eSUN PLA+ (P2S #1 AMS Slot 3) — 2207 NDAA Quad-Set Clamshell Snap-Lid
    t8 = []
    t8 += make_box(-69.5, -69.5, 0.0, 139.0, 139.0, 2.5)
    t8 += make_box(-69.5, -69.5, 2.5, 139.0, 2.5, 18.0)
    t8 += make_box(-69.5, 67.0, 2.5, 139.0, 2.5, 18.0)
    t8 += make_box(-69.5, -67.0, 2.5, 2.5, 134.0, 18.0)
    t8 += make_box(67.0, -67.0, 2.5, 2.5, 134.0, 18.0)
    f8 = os.path.join(CAD_DIR, "8_PLAPlus_2207_NDAA_Quad_Set_Clamshell_SnapLid.stl")
    n8 = write_binary_stl(f8, t8, "OSITO PLA+ 2207 NDAA Quad-Set Clamshell SnapLid")
    outputs.append((os.path.basename(f8), n8))

    # 9. Bambu PETG-CF (P2S #1 AMS Slot 1) — 16-Motor SF Warehouse WIP Kanban Curing Tote
    t9 = []
    t9 += make_box(-95.0, -95.0, 0.0, 190.0, 190.0, 4.5)
    for row in range(4):
        for col in range(4):
            cx = -67.5 + col * 45.0
            cy = -67.5 + row * 45.0
            t9 += make_tube(cx, cy, 4.5, 22.0, 14.3, 17.5, segs=36)
    f9 = os.path.join(CAD_DIR, "9_PETGCF_16Motor_SF_Warehouse_WIP_Kanban_Curing_Tote.stl")
    n9 = write_binary_stl(f9, t9, "OSITO PETG-CF 16-Motor SF Warehouse WIP Kanban Curing Tote")
    outputs.append((os.path.basename(f9), n9))

    return outputs


if __name__ == "__main__":
    results = build_all_stls()
    print("Generated 9 Watertight Binary STL Files for SF-2207 5-Inch BLDC Motor Line:")
    for name, count in results:
        print(f"  [OK] {name} ({count} triangles)")
