"""
Builds OSITO_SF_Warehouse_2207_5in_BLDC_Motor_Manufacturing_SOP.docx
in ositodrone.com visual parity (Rule 4 & Rule 5: Fjalla One + Roboto, #232A68, #7077CF, #EEF0FA).
"""
import os
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DOCX_PATH = os.path.join(OUT_DIR, "OSITO_SF_Warehouse_2207_5in_BLDC_Motor_Manufacturing_SOP.docx")

ROYAL_INDIGO = RGBColor(35, 42, 104)     # #232A68
BRAND_INDIGO = RGBColor(112, 119, 207)   # #7077CF
CHARCOAL = RGBColor(22, 22, 22)          # #161616
MUTED_GRAY = RGBColor(94, 94, 94)        # #5E5E5E
WHITE = RGBColor(255, 255, 255)


def set_cell_shading(cell, hex_color: str):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def add_heading_styled(doc, text: str, level: int = 1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14 if level == 1 else 10)
    p.paragraph_format.space_after = Pt(4)
    run = p.add_run(text.upper())
    run.font.name = "Fjalla One"
    run.font.size = Pt(15 if level == 1 else 12)
    run.font.bold = True
    run.font.color.rgb = ROYAL_INDIGO if level == 1 else BRAND_INDIGO
    return p


def add_styled_table(doc, headers, rows):
    table = doc.add_table(rows=1 + len(rows), cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = table.rows[0].cells
    for idx, h_text in enumerate(headers):
        set_cell_shading(hdr_cells[idx], "232A68")
        p = hdr_cells[idx].paragraphs[0]
        r = p.add_run(h_text.upper())
        r.font.name = "Fjalla One"
        r.font.size = Pt(9.5)
        r.font.bold = True
        r.font.color.rgb = WHITE

    for r_idx, row_data in enumerate(rows):
        cells = table.rows[r_idx + 1].cells
        bg = "EEF0FA" if r_idx == len(rows) - 1 and "TOTAL" in str(row_data[0]).upper() else ("F6F6F6" if r_idx % 2 == 1 else "FFFFFF")
        for c_idx, val in enumerate(row_data):
            set_cell_shading(cells[c_idx], bg)
            p = cells[c_idx].paragraphs[0]
            r = p.add_run(str(val))
            r.font.name = "Roboto"
            r.font.size = Pt(9.0)
            if c_idx == 0 or "TOTAL" in str(row_data[0]).upper():
                r.font.bold = True
            r.font.color.rgb = CHARCOAL
    doc.add_paragraph()


def build_docx():
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(0.65)
        section.bottom_margin = Inches(0.65)
        section.left_margin = Inches(0.65)
        section.right_margin = Inches(0.65)

    # Banner Header Table
    banner = doc.add_table(rows=1, cols=1)
    b_cell = banner.rows[0].cells[0]
    set_cell_shading(b_cell, "161616")
    bp = b_cell.paragraphs[0]
    bp.alignment = WD_ALIGN_PARAGRAPH.LEFT
    r1 = bp.add_run("OSITO DRONE LLC — SAN FRANCISCO IN-HOUSE PROPULSION DIVISION\n")
    r1.font.name = "Fjalla One"
    r1.font.size = Pt(11)
    r1.font.color.rgb = BRAND_INDIGO
    r2 = bp.add_run("SF-2207 (5-INCH CLASS) 12N14P BLDC MOTOR MANUFACTURING SOP, CAD & NDAA BLUEPRINT\n")
    r2.font.name = "Fjalla One"
    r2.font.size = Pt(16)
    r2.font.bold = True
    r2.font.color.rgb = WHITE
    r3 = bp.add_run("Prepared for: Alan Musselman (COO), Miguel Flores (CEO), Jesus Aceves (CTO) | Date: November 1, 2026")
    r3.font.name = "Roboto"
    r3.font.size = Pt(9.5)
    r3.font.color.rgb = RGBColor(200, 204, 238)

    doc.add_paragraph()

    # Section 1: Executive Summary & Target Spec
    add_heading_styled(doc, "1. Executive Summary & SF-2207 Baseline Engineering Spec", level=1)
    p = doc.add_paragraph()
    r = p.add_run(
        "This Standard Operating Procedure (SOP) establishes a complete 120 sq ft San Francisco micro-factory cell "
        "capable of manufacturing 500+ NDAA Section 848 compliant 5-inch class brushless outrunner motors (OSITO SF-2207) per month, "
        "plus powering the Osito STEM Academy 'Build a Brushless Motor' Electromagnetism Lab."
    )
    r.font.name = "Roboto"
    r.font.size = Pt(10)

    spec_headers = ["Parameter", "SF-2207-1850KV (6S Tactical/Commercial)", "SF-2207-2420KV (4S High-RPM/STEM)", "QC Acceptance Limit"]
    spec_rows = [
        ["Electromagnetic Topology", "12N14P DLRK (AaBbCcAaBbCc), Wye (Star)", "12N14P DLRK (AaBbCcAaBbCc), Wye (Star)", "100% Polarity Verified"],
        ["Stator Core Geometry", "22.0mm OD x 8.0mm ID x 7.0mm Stack (35x 0.20mm M19)", "22.0mm OD x 8.0mm ID x 7.0mm Stack", "+/- 0.05mm Stack Height"],
        ["Copper Winding Spec", "9 Turns/Tooth, 0.55mm (23.5 AWG) NEMA MW35-C (240C)", "7 Turns/Tooth, 0.62mm (22.5 AWG) NEMA MW35-C", "Slot Fill 58.6% - 61.2%"],
        ["Line-to-Line Resistance", "44.8 mOhm (2P Opposite Tooth-Pairs + 150mm 20AWG)", "28.9 mOhm (2P Opposite Tooth-Pairs + 150mm 20AWG)", "<= 3.5% Phase Imbalance"],
        ["Rotor Magnet Array", "14x N52SH Curved Arc (7.0 x 3.5 x 1.2mm, 150C)", "14x N52SH Curved Arc (7.0 x 3.5 x 1.2mm, 150C)", "0.14mm Radial Air Gap"],
        ["Shaft & Bearings", "4.00mm Hollow Ti-6Al-4V (M5 Thread) + 2x EZO MR94ZZ", "4.00mm Hollow Ti-6Al-4V + 2x EZO MR94ZZ", "< 0.008mm Shaft TIR"],
        ["Peak Thrust (5.1x3.6x3 Prop)", "1,980 g @ 22.2V (6S) / 41.5A", "1,860 g @ 16.8V (4S HV) / 46.0A", "KV within +/- 3.0%"],
        ["Dielectric & Balance QC", "500V DC Hi-Pot & Laser/Piezo Dynamic Balance", "500V DC Hi-Pot & Laser/Piezo Dynamic Balance", ">= 100 MOhm & <= 0.005 g*mm"],
    ]
    add_styled_table(doc, spec_headers, spec_rows)

    # Section 2: 7-Station SF Warehouse Manufacturing & Winding Workflow
    add_heading_styled(doc, "2. 7-Station San Francisco Shop Assembly & Winding Workflow", level=1)
    station_headers = ["Station", "Operation Name", "Bambu P2S Tooling / Shop Equipment", "Cycle Time", "Critical Safety & Quality Gate"]
    station_rows = [
        ["Station 1", "CNC Bell, Flux Ring & Base Prep", "Humanmade SF (Haas VF-2SS/Lathe) or Peninsula Swiss CNC", "Batch Prep", "Verify 9.00mm H7 bearing seats & 22.30mm ID ring"],
        ["Station 2", "14-Pole N52SH Arc Magnet Bonding", "STL #3: PLA+ 14-Pole Magnet Jig + Polarity Wand + Loctite 326", "90 sec", "Alternate N-S-N-S poles; 80C oven cure for 30 min"],
        ["Station 3", "12-Slot Stator Insulation & Winding", "STL #1 (PAHT-CF Caps) + STL #2 (PLA+ Turret) / CNC Flyer Winder", "45 sec (CNC)", "AaBbCcAaBbCc sequence; 9T Wye (6S) or 7T Wye (4S)"],
        ["Station 4", "20AWG Lead Solder & Vacuum Varnish", "3-Gal Vacuum Pot + Dolph's CC-1105 Varnish + STL #9 Tote", "60 sec active", "Cure at 110C for 45 min; install STL #6 TPU boot"],
        ["Station 5", "500V DC Hi-Pot & Milliohm Audit", "BK Precision 500V Insulation Tester + 4-Wire Micro-Ohmmeter", "25 sec", "Must read >= 100 MOhm core-to-phase & <= 3.5% delta"],
        ["Station 6", "MR94ZZ Bearing & Rotor Bell Press", "STL #4: PLA+ Outer-Race Bearing Arbor + 1-Ton Manual Press", "35 sec", "Press outer race only; install M2x4 Ti bottom screw"],
        ["Station 7", "Laser/Piezo Balance, Dyno & QR Pack", "STL #5 (PETG-CF Dyno) + STL #6 (TPU Flexures) + STL #7/#8 Tray", "65 sec", "Balance to <= 0.005 g*mm; print NDAA Sec. 848 QR label"],
    ]
    add_styled_table(doc, station_headers, station_rows)

    # Section 3: Master 4-Tier Bambu Lab P2S Tooling Assignment
    add_heading_styled(doc, "3. 3D-Printed Tooling Pack (2x Bambu Lab P2S Combo Farm — Rule 3)", level=1)
    cad_headers = ["STL #", "CAD File in ./cad/", "Standardized Filament & P2S Slot", "Purpose"]
    cad_rows = [
        ["1", "1_PAHTCF_2207_12Slot_Stator_End_Insulator_Caps_x8.stl", "Bambu PAHT-CF (P2S #1 AMS Slot 2, <12% RH)", "190C HDT snap-on tooth insulators for uncoated EDM stacks"],
        ["2", "2_PLAPlus_2207_12Tooth_LRK_Stator_Winding_Indexing_Fixture.stl", "eSUN PLA+ (P2S #1 AMS Slot 3)", "12-position rotary indexing turret (AaBbCcAaBbCc)"],
        ["3", "3_PLAPlus_2207_14Pole_N52SH_Arc_Magnet_Spacing_and_Polarity_Jig.stl", "eSUN PLA+ (P2S #1 AMS Slot 3)", "14-slot N52SH curved magnet insertion mandrel + N/S wand"],
        ["4", "4_PLAPlus_2207_MR94ZZ_Dual_Bearing_and_TC4_Shaft_Arbor_Press.stl", "eSUN PLA+ (P2S #1 AMS Slot 3)", "Concentric outer-race MR94ZZ bearing & 4mm Ti shaft arbor"],
        ["5", "5_PETGCF_2207_Laser_Piezo_Dynamic_Balancer_and_5kg_Thrust_Dyno.stl", "Bambu PETG-CF (P2S #1 AMS Slot 1)", "16x16mm M3 test stand with laser tach & 5kg load-cell arm"],
        ["6", "6_TPU95AHF_2207_Balancer_Isolation_Flexures_and_20AWG_Wire_Boots_x8.stl", "Bambu TPU 95A HF (P2S #2 External Dryer Port)", "2 walls + 15% gyroid vibration isolators + 20AWG wire boots"],
        ["7-8", "7_PLAPlus_Tray.stl & 8_PLAPlus_SnapLid.stl", "eSUN PLA+ (P2S #1 AMS Slot 3)", "4-motor matched-KV NDAA clamshell tray and snap lid"],
        ["9", "9_PETGCF_16Motor_SF_Warehouse_WIP_Kanban_Curing_Tote.stl", "Bambu PETG-CF (P2S #1 AMS Slot 1)", "16-motor stackable shop floor WIP Kanban tote"],
    ]
    add_styled_table(doc, cad_headers, cad_rows)

    # Section 4: Unit Economics & CapEx Summary
    add_heading_styled(doc, "4. US/CA NDAA Bill of Materials, Unit Economics & $6,950 Micro-Factory CapEx", level=1)
    bom_headers = ["Cost / Revenue Metric", "Prototype Batch (25 Motors)", "SF Pilot Run (250 Motors)", "Production Run (1,000 Motors)"]
    bom_rows = [
        ["Mechanical (7075-T6 Bell, 1018 Ring, Base, Ti Shaft)", "$37.30", "$16.70", "$10.30"],
        ["Electromagnetic (CA Silicon Steel Stack, 14x US N52SH, MWS Wire)", "$19.87", "$10.96", "$7.21"],
        ["Bearings, 20AWG Leads, Loctite 326 & Dolph's Varnish", "$6.60", "$4.30", "$3.05"],
        ["SF Warehouse Direct Winding, Balance & QC Labor ($32/hr)", "$13.32 (Hand-Wound)", "$2.52 (CNC Flyer Winder)", "$2.30 (CNC Flyer Winder)"],
        ["TOTAL LANDED UNIT COST PER SF-2207 MOTOR", "$77.09 / motor", "$34.48 / motor", "$22.86 / motor"],
        ["NDAA Defense / Municipal Sale Price ($500 / Quad Set)", "$125.00 / motor (38.3% GM)", "$125.00 / motor (72.4% GM)", "$125.00 / motor (81.7% GM)"],
    ]
    add_styled_table(doc, bom_headers, bom_rows)

    doc.save(DOCX_PATH)
    print(f"Saved Word SOP: {DOCX_PATH}")


if __name__ == "__main__":
    build_docx()
