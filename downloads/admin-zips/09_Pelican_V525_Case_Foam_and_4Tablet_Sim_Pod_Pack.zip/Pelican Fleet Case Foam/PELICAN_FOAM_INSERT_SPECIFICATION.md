# Pelican Fleet Case & Custom Foam Insert Engineering Specification (Inches)
**Fleet Payload:** 12 × NewBeeDrone AcroBee65 (`2.56"` / 65mm Class Tiny Whoops) + 8 × RadioMaster T8L (ELRS Controllers)

---

## 1. Executive Summary & Case Selection Matrix

Because **8 × RadioMaster T8L controllers** (`6.50" × 4.72" × 2.76"` each) and **12 × AcroBee65 drones** (`3.23" × 3.23" × 1.50"` each) require a combined footprint with protective closed-cell foam webbing (`0.55"–0.63"`) between every unit, standard carry-on cases (`Pelican 1510` / `1535 Air`) cannot fit all 20 items on a single top-access layer.

Below are the **three optimal Pelican case options** in **inches**:

| Case Model | Interior Dimensions (`L × W × D`) | Base / Lid Split | Layout Architecture | Best For |
| :--- | :--- | :--- | :--- | :--- |
| **Pelican 1560 Roller** *(Recommended)* | **`19.92" × 14.98" × 9.00"`** | `7.00"` Base <br>`2.00"` Lid | **Single-Layer Top Access** for all 12 Drones + 8 Controllers, **plus** a `2.95"` deep lower utility bay under the drones for chargers & 48× 1S batteries. | **Best overall balance:** Compact wheeled roller, single-glance inventory check, zero tray removal required to grab drones or radios. |
| **Pelican 1600 / 1610** *(Spacious Fleet)* | **`21.51" × 16.54" × 7.99"`** | `6.12"` Base <br>`1.75"` Lid | **Single-Layer Top Access** with generous `1.00"` perimeter walls and a **Top-Access Battery & Charger Trench** (`7.40" × 1.81"`). | **Heavy classroom/event use:** Thicker foam walls between slots and top-facing 1S charger bay. |
| **Pelican 1510 / 1535 Air** *(Carry-On)* | **`19.75" × 11.00" × 7.60"`** | `5.79"` Base <br>`1.79"` Lid | **Dual-Layer Removable Tray:**<br>• **Top Tray (`2.05"`):** 12 × AcroBee65 (`4 × 3` grid)<br>• **Bottom Bay (`3.62"`):** 8 × RadioMaster T8L (5 vertical + 3 horizontal) | **Airline overhead bin travel:** Meets FAA domestic carry-on size limits. |

> **Budget Hardware Alternative:** The **Harbor Freight Apache 5800** (`20.25" × 11.40" × 7.50"`) matches the 2-layer carry-on layout, while the **SKB iSeries 3i-2015-10** (`20.50" × 15.50" × 10.00"`) matches the single-layer Pelican 1560 layout.

---

## 2. Component & Cutout Pocket Specifications (Inches)

### A. NewBeeDrone AcroBee65 (12 Units — Vertical Fleet Slots)
* **Physical Drone Envelope:** `2.56"` (65mm) diagonal wheelbase; `1.22"` (31mm) props; **`3.23" × 3.23"` overall duct-to-duct width**; **`1.42"–1.50"` overall height** (from 1S battery cradle to top of Goober canopy/antenna).
* **Why Vertical Slots Beat Flat Pockets:** Standing each AcroBee65 vertically on its two lower motor ducts holds the frame securely by its durable polypropylene ring while suspending the canopy and props in an unstressed relief zone.
* **Cutout Dimensions (Per Drone Slot):**
  * **Main Frame Slot:** **`3.31" (W) × 1.50" (Thick) × 2.83" (Depth)`**
  * **Canopy & Antenna Relief Channel:** **`1.26" (W) × 1.81" (Thick) × 2.83" (Depth)`** centered along the slot so the Goober canopy and dipole VTX antenna experience zero foam compression.
  * **Finger Pull Notches:** Dual `R = 0.31"` (`5/16"`) semi-circular finger reliefs (`1.00"` deep) on left and right edges, plus the top `0.40"` of the upper motor ducts sit proud of the pocket floor for two-finger pinch extraction.

### B. RadioMaster T8L / T8 Lite ELRS Controllers (8 Units — Vertical Slots)
* **Physical Controller Envelope:** **`6.50" (W) × 4.72" (H) × 1.77" (Grip Body Thickness)`**, expanding to **`2.76"` total thickness across the dual gimbal sticks**.
* **Cutout Dimensions (Per Controller Slot):**
  * **Main Body Cavity:** **`6.54" (L) × 1.81" (W) × 4.13" (Depth)`** (leaves top `0.59"` of the controller shoulder exposed above the foam deck for effortless one-hand grab).
  * **Dedicated Gimbal Stick Relief Pocket:** **`3.78" (L) × 0.67" (Protrusion) × 2.36" (Depth)`** along the front face of each slot. **Crucial design feature:** Prevents the potentiometers/Hall gimbals from side-loading or bending during transit!
  * **Finger Pull Notch:** `R = 0.35"` (`3/8"`) semi-circular notch (`1.00"` deep) on the rear spine of each controller slot.

---

## 3. Pelican 1560 Single-Layer Coordinate Blueprint (1:1 Inches)

* **Origin `(0.00", 0.00")`:** Top-Left corner of the **`19.92" × 14.96"`** foam block (Corner Radius `R = 1.26"`).

### Left Zone: 8 × RadioMaster T8L (`4 Columns × 2 Rows`)
* **Column X-Origins (Main Body `1.81"` + Gimbal Relief `0.67"` + Structural Web between bodies):**
  * **Col 1:** `X = 0.87"` (Body: `0.87"–2.68"`, Gimbal Relief: `2.68"–3.31"`)
  * **Col 2:** `X = 3.46"` (Body: `3.46"–5.28"`, Gimbal Relief: `5.28"–5.91"`)
  * **Col 3:** `X = 6.06"` (Body: `6.06"–7.87"`, Gimbal Relief: `7.87"–8.50"`)
  * **Col 4:** `X = 8.66"` (Body: `8.66"–10.47"`, Gimbal Relief: `10.47"–11.10"`)
* **Row Y-Origins (`6.54"` Slot Length, `0.55"` Center Structural Rib):**
  * **Row A (T8L #1–#4):** `Y = 0.67"` to `7.20"`
  * **Row B (T8L #5–#8):** `Y = 7.76"` to `14.29"`

### Right Zone: 12 × AcroBee65 (`2 Columns × 6 Rows`)
* **Column X-Origins (`3.31"` Slot Width, `0.63"` Center Structural Rib):**
  * **Drone Col 1 (#01–#06):** `X = 11.57"` to `14.88"`
  * **Drone Col 2 (#07–#12):** `X = 15.51"` to `18.82"` (leaves `1.10"` right border to clear wheel housings)
* **Row Y-Origins (`1.50"` Slot Thickness, `0.59"` Inter-Slot Webs, `2.09"` Pitch):**
  * **Row 1 (#01, #07):** `Y = 1.54"` to `3.03"`
  * **Row 2 (#02, #08):** `Y = 3.62"` to `5.12"`
  * **Row 3 (#03, #09):** `Y = 5.71"` to `7.20"`
  * **Row 4 (#04, #10):** `Y = 7.80"` to `9.29"`
  * **Row 5 (#05, #11):** `Y = 9.88"` to `11.38"`
  * **Row 6 (#06, #12):** `Y = 11.97"` to `13.46"`

---

## 4. Vertical Depth & Multi-Layer Foam Stackup (`7.00"` Base + `2.00"` Lid)

To fabricate this insert cleanly using standard waterjet, CNC router, or laser-cut foam sheets, use **2.2 lb Closed-Cell Cross-Linked Polyethylene (XLPE) Foam** (Charcoal Black with a `0.25"` Red or Blue contrast top cap so missing drones/controllers are immediately visible):

1. **Lid Foam (`2.00"` thick):** Standard convoluted (egg-crate) polyurethane lid foam, glued or friction-fit into the Pelican 1560 lid. Gently holds the top `0.40"–0.60"` of the controllers and drones in place when the case is inverted.
2. **Top Fleet Tray — Layer 2 (`3.35"` thick XLPE + `0.39"` bonded floor under Drone Zone):**
   * All 12 AcroBee65 pockets are cut **`2.83"` deep**, leaving a solid `0.51"` floor under the drones so the entire right half of the top layer lifts up like a hinged/removable deck!
   * All 8 RadioMaster T8L main body pockets cut **through** the `3.35"` top layer and extend `0.78"` into the lower layer (total depth = **`4.13"`**).
3. **Lower Charger & Battery Vault — Layer 1 (`3.15"` thick XLPE):**
   * Directly underneath the 12 AcroBee65 drones lies a **`7.24" × 12.28" × 2.95"` Utility Vault** holding:
     * **2 × ViFly WhoopStor V3** 6-Port 1S LiPo Chargers
     * **48 × 1S 300mAh BT2.0 / Nitro Nectar Gold Batteries** in a flame-retardant LiPo safe bag
     * **2 × 65W GaN USB-C Power Supplies** + spare 31mm (`1.22"`) propellers & frames
4. **Bottom Base Pad — Layer 0 (`0.50"` solid XLPE):**
   * Continuous shock-isolation base pad across the entire `19.92" × 14.96"` floor.

---

## 5. How to Order or Cut This Insert Today

### Option A: Turnkey Custom Waterjet Foam (No Tools Required)
1. **MyCaseBuilder.com** *(Official Pelican Custom Foam Partner)*:
   * Select **Pelican 1560** (or **Pelican 1600**).
   * Upload the included [`Pelican_1560_Fleet_Foam_1to1.dxf`](./Pelican_1560_Fleet_Foam_1to1.dxf) file (set to **Inches**) directly into their CAD importer, or enter the exact inch dimensions from Section 3.
   * Choose **2lb Polyethylene (PE) Foam** with a **Red or Blue Contrasting Base Layer**.
2. **GunFoam.com / CaseClub.com / CarolinaCustomFoam.com**:
   * Upload [`Pelican_1560_Fleet_Foam_1to1.dxf`](./Pelican_1560_Fleet_Foam_1to1.dxf) or [`Pelican_1560_Fleet_Foam_1to1.svg`](./Pelican_1560_Fleet_Foam_1to1.svg) and specify pocket depths in inches:
     * `CUT_CONTROLLER_4_13IN_DEEP` = `4.13"`
     * `RELIEF_GIMBAL_STICKS_2_36IN_DEEP` = `2.36"`
     * `CUT_ACROBEE65_2_83IN_DEEP` = `2.83"`
     * `RELIEF_CANOPY_2_83IN_DEEP` = `2.83"`

### Option B: DIY In-House Cut (Kaizen Foam + CO2 Laser or Router)
1. Purchase two sheets of **FastCap Kaizen Foam (`2.25"` + `3.50"`)** or **Pelican 1562 Solid PE Foam Set**.
2. Print [`Pelican_1560_Fleet_Foam_1to1.svg`](./Pelican_1560_Fleet_Foam_1to1.svg) at **100% scale**, trace/cut the pockets, and peel out to the specified depths (`2.83"` for AcroBee65s, `4.13"` for T8L bodies, `2.36"` for T8L gimbal reliefs).
