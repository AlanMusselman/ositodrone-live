// ============================================================================
// OSITO DRONE LLC — "AERO-CUB K-5" 10-PART 3D-PRINTABLE AERONAUTICS & SQUAD KIT
// Target Farm: 2x Bambu Lab P2S Combo (P2S #1 AMS Slot 3: eSUN PLA+ / Bambu PLA Tough)
// Parametric OpenSCAD Master Source (100% Synchronized with Verified STL Geometry)
//
// CLI Usage:
//   openscad -o 07_AeroCub_Complete_6Piece_Student_Kit_Plate.stl -D "PART_ID=0" AeroCub_K5_Parametric_Master.scad
//   PART_ID = 0  : Complete 6-Piece Student Kit Plate
//   PART_ID = 1  : Clip-On Nose Bearing Block (X-axis bore, hollow bumper, z_min=0)
//   PART_ID = 2  : High-Thrust 80mm Youth-Safe Propeller + Snap Shaft Hook
//   PART_ID = 3  : Modular 175mm Fuselage Tension Spine (open Warren truss)
//   PART_ID = 4  : Rear Tail Anchor & Indexed Elevon/Rudder Gauge (-10/0/+10/+20 deg)
//   PART_ID = 5  : Protractor Catapult Launcher w/ Finger Shield & 0/15/30/45 deg Sights
//   PART_ID = 6  : Windowed Crease Ruler, NACA Camber Rib & CG Balance Fulcrum
//   PART_ID = 8  : 5:1 Spur-Gear Rubber-Band Winder (Real 50T + 10T m=0.8mm Meshing Teeth!)
//   PART_ID = 9  : Open-Lattice Stackable 6-Student Squadron Pit-Crew Caddy Tray
//   PART_ID = 10 : Box-Fan Wind Tunnel Pivot Gimbal Test Stand + 0.5g/1.0g/1.5g CG Clips
// ============================================================================

$fn = 48;
PART_ID = 0;

// Parametric Involute/Trapezoidal Spur Gear Module (used by Part 8 5:1 Winder)
module spur_gear(teeth=50, mod=0.8, thickness=4.0, bore_r=3.6) {
    pitch_r = mod * teeth / 2.0;
    tip_r   = pitch_r + mod;
    root_r  = pitch_r - 1.25 * mod;
    tooth_w = (3.14159 * mod) / 2.0;
    difference() {
        union() {
            cylinder(r=root_r, h=thickness);
            for (i = [0 : teeth - 1]) {
                rotate([0, 0, i * 360.0 / teeth])
                translate([root_r - 0.2, -tooth_w / 2.0, 0])
                cube([tip_r - root_r + 0.2, tooth_w, thickness]);
            }
        }
        translate([0, 0, -0.5]) cylinder(r=bore_r, h=thickness + 1.0);
    }
}

module part1_nose_bearing_block() {
    color("#7077CF")
    union() {
        translate([0, 0, 6]) rotate([0, 90, 0]) difference() { cylinder(r=6.0, h=6.0); translate([0,0,-1]) cylinder(r=4.8, h=8.0); }
        translate([6, -1.8, 0]) cube([20, 1.4, 8.8]);
        translate([6, 0.4, 0]) cube([20, 1.4, 8.8]);
        translate([6, -1.8, 8.8]) cube([20, 3.6, 1.2]);
        translate([6, 0, 12.6]) rotate([0, 90, 0]) difference() { cylinder(r=2.6, h=20); translate([0,0,-1]) cylinder(r=1.2, h=22); }
        translate([19, -3.0, 2.0]) cube([7, 1.2, 4.5]);
        translate([19, 1.8, 2.0]) cube([7, 1.2, 4.5]);
        translate([2, -1.2, 0]) cube([4, 2.4, 2.5]);
    }
}

module part2_high_thrust_propeller() {
    color("#303885")
    union() {
        difference() { cylinder(r=4.5, h=6); translate([0, 0, -1]) cylinder(r=1.1, h=8); }
        for (side = [-1, 1]) hull() {
            translate([side * 4.5, -2.5, 0]) cube([2, 5, 1.1]);
            translate([side * 37, 0, 0]) cylinder(r=4.2, h=1.1);
        }
        translate([-12, 9, 0]) cube([24, 1.8, 1.8]);
        translate([12, 9, 0]) cube([1.8, 5.0, 1.8]);
        translate([8, 14, 0]) cube([5.8, 1.8, 1.8]);
    }
}

module part3_modular_fuselage_spine() {
    color("#232A68")
    union() {
        translate([0, -3.6, 0]) cube([175, 1.0, 4.2]);
        translate([0, 2.6, 0]) cube([175, 1.0, 4.2]);
        for (x = [0 : 15 : 174]) translate([x, -2.6, 0]) cube([1.2, 5.2, 3.2]);
        for (sx = [20, 80, 140]) {
            translate([sx, -2.6, 3.2]) cube([12, 5.2, 1.0]);
            translate([sx, -1.6, 4.2]) cube([12, 1.2, 3.3]);
            translate([sx, 0.4, 4.2]) cube([12, 1.2, 3.3]);
        }
    }
}

module part4_tail_anchor_and_elevon_gauge() {
    color("#7077CF")
    union() {
        translate([0, -4.8, 0]) cube([20, 9.6, 1.2]);
        translate([0, -4.8, 1.2]) cube([20, 1.2, 4.8]);
        translate([0, 3.6, 1.2]) cube([20, 1.2, 4.8]);
        translate([20, -1.5, 0]) cube([8, 3.0, 2.4]);
        translate([25, -1.5, 2.4]) cube([3, 3.0, 7.6]);
        translate([21, -1.5, 10.0]) cube([7, 3.0, 2.2]);
        translate([0, -13, 0]) cube([14, 8.2, 1.2]);
        translate([0, 4.8, 0]) cube([14, 8.2, 1.2]);
        for (y = [-12.0, -9.2, -6.4, 5.4, 8.2, 11.0]) translate([1, y, 1.2]) cube([12, 1.0, 4.2]);
        translate([2, -1.4, 1.2]) cube([10, 1.0, 9.0]);
        translate([2, 0.4, 1.2]) cube([10, 1.0, 9.0]);
    }
}

module part5_protractor_catapult_launcher() {
    color("#444FB6")
    union() {
        translate([0, -6.0, 0]) cube([68, 2.4, 4.2]);
        translate([0, 3.6, 0]) cube([68, 2.4, 4.2]);
        for (gx = [0, 22, 44, 65]) translate([gx, -3.6, 0]) cube([2.4, 7.2, 4.2]);
        translate([40, -18, 0]) cube([2.4, 12, 7.5]);
        translate([40, 6, 0]) cube([2.4, 12, 7.5]);
        translate([68, -18, 0]) cube([34, 3.2, 4.8]);
        translate([68, 14.8, 0]) cube([34, 3.2, 4.8]);
        translate([68, -14.8, 0]) cube([3.2, 29.6, 4.8]);
        translate([102, -16.4, 0]) difference() { cylinder(r=3.5, h=9.5); translate([0,0,-1]) cylinder(r=1.5, h=11.5); }
        translate([102, 16.4, 0]) difference() { cylinder(r=3.5, h=9.5); translate([0,0,-1]) cylinder(r=1.5, h=11.5); }
        for (deg = [0, 15, 30, 45]) translate([14 + 22*cos(deg), 7 + 22*sin(deg), 0]) cylinder(r=1.4, h=6);
    }
}

module part6_crease_ruler_and_airfoil_jig() {
    color("#6068C4")
    union() {
        cube([150, 5.0, 1.4]);
        translate([0, 13.0, 0]) cube([150, 5.0, 1.4]);
        for (rx = [0 : 30 : 146]) translate([rx, 5.0, 0]) cube([4.0, 8.0, 1.4]);
        translate([0, -2.5, 0]) cube([150, 2.5, 0.8]);
        for (x = [10 : 10 : 140]) translate([x, 0, 1.4]) cube([0.8, 4.5, 0.6]);
        translate([72, 5.0, 1.4]) cube([6.0, 8.0, 4.2]);
    }
}

module part8_5to1_gear_winder() {
    color("#7077CF")
    union() {
        translate([0, -22, 0]) cube([88, 3, 6]);
        translate([0, 19, 0]) cube([88, 3, 6]);
        translate([0, -19, 0]) cube([6, 38, 2]);
        translate([22, -19, 0]) cube([40, 38, 2]);
        translate([82, -19, 0]) cube([6, 38, 2]);
        // Real meshing 50T Drive Gear + 10T Pinion Gear (module 0.8mm, C = 24.0mm)
        translate([30, 0, 2]) spur_gear(teeth=50, mod=0.8, thickness=4.0, bore_r=3.6);
        translate([54, 0, 2]) spur_gear(teeth=10, mod=0.8, thickness=4.0, bore_r=1.9);
        translate([30, 0, 2]) difference() { cylinder(r=3.3, h=7); translate([0,0,-1]) cylinder(r=1.8, h=9); }
        translate([54, 0, 2]) cylinder(r=1.6, h=7);
        translate([44, 0, 6]) difference() { cylinder(r=3.8, h=7); translate([0,0,-1]) cylinder(r=1.6, h=9); }
        translate([24, 17.8, 2]) cube([14, 1.2, 4]);
        translate([58, -1.8, 2]) cube([34, 3.6, 3]);
        translate([89, -1.8, 5]) cube([3, 3.6, 6]);
        translate([84, -1.8, 11]) cube([8, 3.6, 2.4]);
    }
}

module part9_modular_6slot_squad_caddy() {
    color("#232A68")
    union() {
        cube([210, 1.4, 20]);
        translate([0, 138.6, 0]) cube([210, 1.4, 20]);
        translate([0, 1.4, 0]) cube([1.4, 137.2, 20]);
        translate([208.6, 1.4, 0]) cube([1.4, 137.2, 20]);
        for (fy = [20, 52, 86, 118]) translate([1.4, fy, 0]) cube([207.2, 4.0, 1.4]);
        translate([1.4, 70, 0]) cube([207.2, 1.2, 16]);
        for (i = [1 : 5]) translate([i * 34.5, 1.4, 0]) cube([1.2, 68.6, 14]);
        for (i = [1 : 5]) translate([i * 27.0, 71.2, 0]) cube([1.2, 67.4, 14]);
        translate([162, 71.2, 0]) cube([1.2, 67.4, 14]);
    }
}

module part10_boxfan_windtunnel_stand() {
    color("#444FB6")
    union() {
        // 1. H-Base with mortise sockets
        cube([135, 8, 3.6]);
        translate([0, 42, 0]) cube([135, 8, 3.6]);
        translate([55, 8, 0]) cube([25, 34, 2.4]);
        translate([58, 8, 2.4]) cube([16, 2.4, 4.0]);
        translate([58, 39.6, 2.4]) cube([16, 2.4, 4.0]);
        // 2. Twin A-frame towers with cylindrical 4.4mm ID pivot bearings
        for (ty = [56, 70]) {
            translate([0, ty, 0]) cube([94, 8, 3.2]);
            translate([98, ty + 4, 0]) difference() { cylinder(r=4.8, h=4.0); translate([0,0,-1]) cylinder(r=2.2, h=6.0); }
        }
        // 3. Counterbalanced Pitch/Lift Gimbal Arm with 4.0mm OD pivot axle & dorsal spine saddle
        translate([0, 88, 0]) cube([125, 6, 3]);
        translate([60, 82, 3]) rotate([-90, 0, 0]) cylinder(r=2.0, h=18);
        translate([54, 88, 3]) cube([1.4, 6, 5]);
        translate([64.6, 88, 3]) cube([1.4, 6, 5]);
        translate([98, 60, 0]) difference() { cylinder(r=11.0, h=2.4); translate([0,0,-1]) cylinder(r=9.2, h=4.4); }
        // 4. Three Snap-On Nose CG Ballast U-Clips (0.5g, 1.0g, 1.5g)
        translate([10, 104, 0]) cube([8, 10.2, 1.4]);
        translate([10, 104, 1.4]) cube([8, 1.4, 4.0]);
        translate([10, 112.8, 1.4]) cube([8, 1.4, 4.0]);
        translate([32, 104, 0]) cube([14, 10.2, 1.4]);
        translate([32, 104, 1.4]) cube([14, 1.4, 5.5]);
        translate([32, 112.8, 1.4]) cube([14, 1.4, 5.5]);
        translate([58, 104, 0]) cube([20, 10.2, 1.4]);
        translate([58, 104, 1.4]) cube([20, 1.4, 6.8]);
        translate([58, 112.8, 1.4]) cube([20, 1.4, 6.8]);
    }
}

module complete_student_kit_plate() {
    translate([10, 15, 0]) part1_nose_bearing_block();
    translate([95, 22, 0]) part2_high_thrust_propeller();
    translate([5, 48, 0]) part3_modular_fuselage_spine();
    translate([145, 15, 0]) part4_tail_anchor_and_elevon_gauge();
    translate([15, 92, 0]) part5_protractor_catapult_launcher();
    translate([15, 132, 0]) part6_crease_ruler_and_airfoil_jig();
}

if (PART_ID == 1) { part1_nose_bearing_block(); }
else if (PART_ID == 2) { part2_high_thrust_propeller(); }
else if (PART_ID == 3) { part3_modular_fuselage_spine(); }
else if (PART_ID == 4) { part4_tail_anchor_and_elevon_gauge(); }
else if (PART_ID == 5) { part5_protractor_catapult_launcher(); }
else if (PART_ID == 6) { part6_crease_ruler_and_airfoil_jig(); }
else if (PART_ID == 8) { part8_5to1_gear_winder(); }
else if (PART_ID == 9) { part9_modular_6slot_squad_caddy(); }
else if (PART_ID == 10) { part10_boxfan_windtunnel_stand(); }
else { complete_student_kit_plate(); }
