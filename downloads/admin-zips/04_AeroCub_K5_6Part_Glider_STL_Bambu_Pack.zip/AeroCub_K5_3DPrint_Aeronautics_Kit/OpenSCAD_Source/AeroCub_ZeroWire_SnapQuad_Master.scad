// ============================================================================
// OSITO DRONE LLC — ZERO-WIRE 6-PIECE SNAP-TOGETHER QUADCOPTER MASTER CAD (.SCAD)
// Bambu Lab P2S Farm: PETG-CF Frame (Slot 1) + TPU 95A Bumper (P2S #2 Ext) + TPU 68D Canopy (Slot 4)
// Asymmetric Dovetail Keying: Key A = 5.0mm (M4/M1 CCW) | Key B = 3.6mm (M2/M3 CW)
// ============================================================================

$fn = 48;
wheelbase_mm = 75.0;
prop_duct_id = 42.4;
prop_duct_od = 46.8;
duct_height  = 11.0;
pogo_pitch   = 2.54;
key_a_width  = 5.0; // M4 Front-Left & M1 Rear-Right (CCW)
key_b_width  = 3.6; // M2 Front-Right & M3 Rear-Left (CW)

module center_xframe_core() {
    union() {
        translate([-17, -17, 0]) cube([34, 34, 4.2]);
        for (sx = [-1, 1]) for (sy = [-1, 1]) {
            translate([sx*19 - 5.5, sy*19 - 5.5, 0]) cube([11, 11, 5.6]);
            key_w = (sx * sy < 0) ? key_a_width : key_b_width;
            translate([sx*21 - key_w/2, sy*21 - 1.5, 5.6]) cube([key_w, 3.0, 1.4]);
        }
    }
}

module snap_duct_pod(key_w = 5.0) {
    union() {
        difference() {
            cylinder(h = duct_height, d = prop_duct_od);
            translate([0, 0, -0.1]) cylinder(h = duct_height + 0.2, d = prop_duct_id);
        }
        cylinder(h = 3.2, d = 11.0);
        translate([-21.5, -1.6, 0]) cube([43, 3.2, 2.6]);
        translate([-1.6, -21.5, 0]) cube([3.2, 43, 2.6]);
        translate([-21.5, -1.1, 9.4]) cube([43, 2.2, 1.6]);
        translate([-1.1, -21.5, 9.4]) cube([2.2, 43, 1.6]);
        translate([23.0, -4.5, 0]) cube([10.5, 9.0, 4.4]);
        translate([24.0, -key_w/2, 4.4]) cube([9.5, key_w, 1.4]);
    }
}

center_xframe_core();
translate([-55,  45, 0]) snap_duct_pod(key_a_width);
translate([ 45,  45, 0]) snap_duct_pod(key_b_width);
translate([-55, -45, 0]) snap_duct_pod(key_b_width);
translate([ 45, -45, 0]) snap_duct_pod(key_a_width);
