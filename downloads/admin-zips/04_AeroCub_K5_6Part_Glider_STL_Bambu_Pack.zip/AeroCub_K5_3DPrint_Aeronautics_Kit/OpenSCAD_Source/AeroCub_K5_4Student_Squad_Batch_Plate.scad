// ============================================================================
// OSITO DRONE LLC — TRUE 1:1 4-STUDENT SQUAD BATCH PLATE (256 x 256 mm Bambu P2S)
// Prints 4 sets of Flying Airframes (Parts 1, 2, 3, 4) at exact 1:1 scale
// ============================================================================
use <AeroCub_K5_Parametric_Master.scad>

for (i = [0 : 3]) {
    translate([10, i * 62, 0]) {
        translate([0, 8, 0]) part1_nose_bearing_block();
        translate([82, 16, 0]) part2_high_thrust_propeller();
        translate([0, 34, 0]) part3_modular_fuselage_spine();
        translate([145, 8, 0]) part4_tail_anchor_and_elevon_gauge();
    }
}
