# OSITO-65-1S-ELRS-AIO (REV 2.0): Complete Pin-to-Pin Electrical Schematic, Netlist & 4-Layer PCB Specification

**Board Part Number:** `OSITO-65-1S-ELRS-AIO REV 2.0`  
**Form Factor & Mechanical Parity:** Exact **65mm Whoop Standard / BeeBrain BLV4** dimensions: **$29.0 \times 29.0 \times 7.6\text{ mm}$** ($1.0\text{ mm}$ 4-Layer FR4 TG170, $2\text{ oz}$ Outer / $1\text{ oz}$ Inner Cu, ENIG, Glossy LPI Mask) with **$25.5 \times 25.5\text{ mm}$ Whoop M2 Mounting Holes** ($\varnothing 2.1\text{ mm}$ NPTH with $\varnothing 4.2\text{ mm}$ silicone grommet keepout).  
**Target Battery:** **NewBeeDrone Nitro Nectar Gold 300mAh 1S 3.8V/4.35V 80C LiHV** (`PH2.0 / JST-PH 2.0mm` solid-pin high-current connector on `PAD_BAT+` / `PAD_BAT-`).  
**Target Radio Transmitter:** **RadioMaster T8L 2.4GHz ExpressLRS** (`ELRS 3.x`, $250\text{ Hz}$ LoRa packet rate, `AETR1234` channel map, bound to onboard `SPI3` `SX1280IMLTRT` transceiver).  
**Flight Control Software:** **Betaflight 4.5.x** via onboard **USB Type-C (`J1`)** (`STM32F411CEU6` MCU + `BMI270` Gyro + `AT7456E` OSD + `RTC6705` $25\text{–}200\text{ mW}$ 5.8GHz VTX + 4-ch $12\text{A}$ `EFM8BB21` Bluejay DShot300 H-Bridge Brushed ESCs with Bidirectional Turtle Mode).

---

## 1. 4-Layer PCB Stackup, Impedance Control & DFM Rules (REV 2.0)

| Layer | Name | Copper Weight | Dielectric Thickness | Primary Routing & Plane Allocation |
| :---: | :--- | :---: | :---: | :--- |
| **L1 (Top)** | `TOP_SIGNAL_RF` | **$2.0\text{ oz}$ ($70\,\mu\text{m}$)** | — | `STM32F411CEU6`, `BMI270`, `SX1280` $50\,\Omega$ RF microstrip, `AT7456E` OSD, USB-C, Top H-Bridge FETs (`M1/M2`), UART1/2/3 Pads |
| **Prepreg** | `7628 Prepreg` | — | $0.20\text{ mm}$ ($\varepsilon_r = 4.6$) | High-isolation prepreg for $50\,\Omega$ RF trace reference to `L2_GND` |
| **L2 (Inner 1)** | `INNER_GND` | **$1.0\text{ oz}$ ($35\,\mu\text{m}$)** | — | **Unbroken Solid `GND` Reference Plane** under MCU, BMI270, SX1280, and RTC6705 |
| **Core** | `FR4 TG170 Core` | — | $0.46\text{ mm}$ ($\varepsilon_r = 4.6$) | Structural high-$T_g$ core |
| **L3 (Inner 2)** | `INNER_PWR` | **$1.0\text{ oz}$ ($35\,\mu\text{m}$)** | — | Split Power Planes: Heavy `VBAT_ESC` polygon (outer perimeter), `+5V_CLEAN` (video), `+3V3_DIG`, and `+3V3_GYRO` |
| **Prepreg** | `7628 Prepreg` | — | $0.20\text{ mm}$ ($\varepsilon_r = 4.6$) | Dielectric separation to Bottom layer |
| **L4 (Bottom)** | `BOT_ESC_VTX` | **$2.0\text{ oz}$ ($70\,\mu\text{m}$)** | — | 4× `EFM8BB21` ESC MCUs, Bottom H-Bridge FETs (`M3/M4`), `TPS63020` 5V Buck-Boost, `RTC6705` (`QFN-40`) + `RTC6659E` (`QFN-16`) VTX, 4× `JST-1.25` Motor Headers |

---

## 2. System Architecture Block Diagram

```mermaid
flowchart TD
    subgraph PWR["NewBeeDrone 1S 300mAh LiHV (PH2.0) & USB-C Power Stage"]
        BAT["NewBeeDrone Nitro Nectar Gold\n1S 300mAh LiHV (3.8V / 4.35V Max)\nvia PH2.0 Solid-Pin Pigtail"]
        USBC["J1 USB Type-C (Betaflight Configurator)\n+ D1 USBLC6 ESD + R10/R11 5.1k CC1/CC2"]
        CAP["C_BULK 220uF 10V 105C/125C Polymer\n+ R_SHUNT 5mOhm + U9 INA199A1 (PB1 Current)"]
        VDIV["R1/R2 10k/10k (2:1)\n-> PB0 (ADC1_IN8 VBAT)"]
        BEC["U10 TPS63020DSJR 5V 2A Buck-Boost\n(Holds 5.0V down to 1.8V VBAT) + L_LC Video Filter"]
        LDO_DIG["U11 AP2112K-3.3 (600mA)\n-> +3V3_DIG (MCU + SX1280 ELRS)"]
        LDO_GYRO["U12 LP5907MFX-3.3 (250mA)\nUltra-Low-Noise -> +3V3_GYRO (BMI270)"]

        BAT --> CAP
        BAT --> VDIV
        BAT --> BEC
        USBC -->|"D2 MBR0520"| BEC
        BEC --> LDO_DIG
        BEC --> LDO_GYRO
    end

    subgraph CORE["STM32F411CEU6 Betaflight 4.5 Core (100MHz)"]
        MCU["U1 STM32F411CEU6 (UFQFPN-48)\n+ C1 2.2uF VCAP1 + Y1 8.000MHz HSE"]
        USBC <-->|"PA11/PA12 USB VCP/DFU"| MCU
    end

    subgraph RF_IMU_OSD["RadioMaster T8L ELRS 2.4GHz, BMI270 Gyro & FPV OSD/VTX"]
        BMI["U2 Bosch BMI270 IMU\n(SPI1: PA4-PA7, EXTI: PC14)"]
        SX1280["U3 Semtech SX1280 + Y2 52MHz\n(SPI3: PA15/PB3-PB7/PC13)\n+ 50-Ohm Pi-Match -> ANT1 Ceramic + U.FL"]
        OSD["U4 AT7456E Betaflight OSD (SPI2)\n+ J_CAM 3-Pin BeeEye Camera Plug"]
        VTX["U13 RTC6705 + U14 RTC6659E PA\n25/100/200mW 5.8GHz VTX (UART2 SmartAudio)"]

        MCU <-->|"SPI1"| BMI
        MCU <-->|"SPI3 (ELRS 3.x)"| SX1280
        MCU <-->|"SPI2"| OSD
        OSD -->|"75-Ohm CVBS"| VTX
        MCU -->|"PA2 SmartAudio"| VTX
    end

    subgraph ESC["4-Ch 12A Bidirectional DShot300 Brushed H-Bridge ESC Stage"]
        ESC_MCU["4x U5-U8 EFM8BB21F16G (QFN-20)\nBluejay v0.21 DShot300 + AUX3 Turtle Mode"]
        FET["8x Q1A-Q4B AO4614B 12A Dual N+P MOSFETs\n+ 4x Q_DRV1-4 BC847BS Pre-Drivers\n+ 4x D_M1-4 BAT54S Flyback Arrays"]
        MOT["4x NewBeeDrone 0615/0716 Brushed Motors\n(J_M1-J_M4 Bottom JST-1.25 2-Pin Plugs)"]

        CAP --> FET
        MCU -->|"DShot300 (PA0, PA1, PB9, PB8)"| ESC_MCU
        ESC_MCU --> FET
        FET <--> MOT
    end
```

---

## 3. Subsystem Pin-to-Pin Schematics & Netlists

### 3.1 Sheet 1: NewBeeDrone 1S 300mAh LiHV Power Stage, Buck-Boost BEC & USB Type-C

```text
[PAD_BAT+] (NewBeeDrone Nitro Nectar Gold 300mAh 1S PH2.0+)
  |
  +----> [R_SHUNT 5mOhm 1% 1W 1206 (Yageo PA1206FRM470R005L)] ----> Net: VBAT_ESC
  +----> [C_BULK 220uF 6.3V Polymer CASE-B (Positive '+' Stripe to VBAT)] ----> GND
  +----> [U9 INA199A1DCKR (50V/V)] ----> Net: ADC_CURR ----> STM32 Pin 19 (PB1 / ADC1_IN9)
  +----> [R1 10k 1% 0402] --+-- [R2 10k 1% 0402] --> GND
                            +--> Net: ADC_VBAT (2:1 Divider) ----> STM32 Pin 18 (PB0 / ADC1_IN8)

USB Type-C Betaflight Configurator Port (J1 TYPE-C-31-M-12 + D1 USBLC6-2SC6):
  - J1 Pin A5 (CC1)  ----> [R10 5.1k 1% 0402] ----> GND (Mandatory USB-C Sink Negotiation)
  - J1 Pin B5 (CC2)  ----> [R11 5.1k 1% 0402] ----> GND (Mandatory USB-C Sink Negotiation)
  - J1 VBUS (A4/B4)  ----> [D2 MBR0520LT1G SOD-123 Schottky] ----> Net: +5V_RAW (Powers FC/ELRS on USB without battery)
  - J1 D-/D+         ----> [D1 USBLC6-2SC6 ESD Array] ----> STM32 PA11 (USB_DM) / PA12 (USB_DP)

Net: VBAT_RAW ----> U10 (TPS63020DSJR Synchronous Buck-Boost VSON-14):
  - Maintains rock-solid 5.0V 2A output even if the 1S 300mAh battery sags to 2.5V during full-throttle punch-outs!
  - Pins 6,7 (VIN)   : VBAT_RAW (Decoupled by C10 22uF 10V 0603 X5R)
  - Pin 5 (VINA)     : VBAT_RAW (via R5 10R 0402 + C14 100nF 0402 to GND)
  - Pins 3,4 (L1) & Pins 1,2 (L2) : L_BB (1.5uH 4.5A Shielded Inductor, 3x3mm)
  - Pins 10,11 (VOUT): +5V_RAW (Set to 5.045V via FB divider R3=1.0M 1% / R4=110k 1% to Pin 12 FB)
  - Dual Ceramic Output Bank [C11A 22uF 10V 0603 X5R] || [C11B 22uF 10V 0603 X5R] to PGND

Active Video LC Pi-Filter:
  +5V_RAW ---+--- [L_LC 2.2uH 2A 2016] ---+---> Net: +5V_CLEAN (To AT7456E OSD, RTC6705 VTX, BeeEye Camera)
             |                            |
     [C11A + C11B]                 [C12 22uF 0603] + [C13 100uF 10V Tantalum CASE-A]
             |                            |
            GND                          GND

Dual Isolated 3.3V LDO Regulators:
  1. Digital & ELRS RF LDO (`U11 AP2112K-3.3TRG1` SOT-23-5, 600mA) -> +3V3_DIG (Powers STM32F411CEU6 + SX1280 ELRS)
  2. Ultra-Low-Noise Gyro LDO (`U12 LP5907MFX-3.3/NOPB` SOT-23-5, 250mA, <10uVrms) -> +3V3_GYRO (Powers Bosch BMI270)
```

---

### 3.2 Sheet 2: 4-Channel Bidirectional Brushed Full H-Bridge ESC (`AO4614B` + Turtle Mode)

Unlike legacy 1S brushed boards that use a single unidirectional MOSFET (which cannot reverse motor spin), each of the 4 brushed motor channels (`M1` Rear-Right, `M2` Front-Right, `M3` Rear-Left, `M4` Front-Left) uses an **`EFM8BB21F16G` (`QFN-20`)** running **Bluejay v0.21 DShot300** driving a pair of **`AO4614B` (`SOIC-8`, $12\text{A}$ continuous)** complementary N+P MOSFETs in a full H-Bridge. This gives your brushed Osito 65 **Bidirectional Crash-Flip (Turtle Mode)** on RadioMaster T8L switch `AUX3 (SC)`!

| Channel | Osito 65 Position | MCU DShot Pin | ESC MCU (`EFM8BB21`) | H-Bridge FET Pair | Gate R / Base R / Flyback | Motor Header (`JST-1.25`) |
| :---: | :--- | :---: | :---: | :---: | :--- | :---: |
| **Motor 1** | Rear Right (CW) | `PA0` (`TIM2_CH1`) | `U5` (`C38` $100\text{ nF}$) | `Q1A`, `Q1B` (`AO4614B`) | `R13/14` $4.7\text{k}$, `R21/22` $10\text{k}$, `R29/30` $2.2\text{k}$, `D_M1` `BAT54S` | `J_M1` (Bottom RR) |
| **Motor 2** | Front Right (CCW) | `PA1` (`TIM2_CH2`) | `U6` (`C39` $100\text{ nF}$) | `Q2A`, `Q2B` (`AO4614B`) | `R15/16` $4.7\text{k}$, `R23/24` $10\text{k}$, `R31/32` $2.2\text{k}$, `D_M2` `BAT54S` | `J_M2` (Bottom FR) |
| **Motor 3** | Rear Left (CCW) | `PB9` (`TIM4_CH4`) | `U7` (`C40` $100\text{ nF}$) | `Q3A`, `Q3B` (`AO4614B`) | `R17/18` $4.7\text{k}$, `R25/26` $10\text{k}$, `R33/34` $2.2\text{k}$, `D_M3` `BAT54S` | `J_M3` (Bottom RL) |
| **Motor 4** | Front Left (CW) | `PB8` (`TIM4_CH3`) | `U8` (`C41` $100\text{ nF}$) | `Q4A`, `Q4B` (`AO4614B`) | `R19/20` $4.7\text{k}$, `R27/28` $10\text{k}$, `R35/36` $2.2\text{k}$, `D_M4` `BAT54S` | `J_M4` (Bottom FL) |

---

### 3.3 Sheet 3: SPI ExpressLRS 2.4GHz (`SX1280` for RadioMaster T8L) & Bosch BMI270 IMU (`SPI1`)

#### Semtech SX1280IMLTRT SPI ELRS 2.4GHz (`U3`, QFN-24 $4 \times 4\text{ mm}$ on `SPI3`)
* **Pin Mapping to `STM32F411CEU6`:**
  * `Pin 9 (NSS)` $\rightarrow$ `PA15` (`RX_SPI_CS`)
  * `Pin 10 (SCK)` $\rightarrow$ `PB3` (`SPI3_SCK`)
  * `Pin 12 (MISO)` $\rightarrow$ `PB4` (`SPI3_MISO`)
  * `Pin 11 (MOSI)` $\rightarrow$ `PB5` (`SPI3_MOSI`)
  * `Pin 7 (DIO1)` $\rightarrow$ `PB6` (`RX_SPI_EXTI`)
  * `Pin 6 (BUSY)` $\rightarrow$ `PB7` (`RX_SPI_EXPRESSLRS_BUSY`)
  * `Pin 8 (NRESET)` $\rightarrow$ `PC13` (`RX_SPI_EXPRESSLRS_RESET`)
* **Frequency Reference:** `Y2` = **$52.000\text{ MHz}$ $\pm 10\text{ ppm}$ SMD Crystal (`NX2016SA-52.000M`)** on `XTA` (Pin 17) / `XTB` (Pin 18) with load capacitors `C26, C27` ($10\text{ pF}$ `0402` C0G).
* **Single-Ended $50\,\Omega$ RF $\pi$-Matching Network (Pin 22 `RFIO`):**
  $$\text{Pin 22 (RFIO)} \xrightarrow{\text{Shunt } C_{23}=1.0\text{ pF}} \text{Series } L_{1\text{RF}}=1.5\text{ nH (`LQG15HS1N5S02D`)} \xrightarrow{\text{Shunt } C_{24}=1.5\text{ pF}} \text{Series } C_{25}=100\text{ pF DC Block} \rightarrow \text{ANT1 (`2450AT18B100E`) / J\_ANT\_ELRS}$$

#### Bosch BMI270 (`U2`, LGA-14 $2.5 \times 3.0\text{ mm}$ on `SPI1`)
* **`Pin 8 (VDD)` & `Pin 5 (VDDIO)`:** Connected to isolated `+3V3_GYRO` (`LP5907MFX-3.3`) with `C19` and `C20` ($100\text{ nF}$ `0402`).
* **`Pin 12 (CSB)`** $\rightarrow$ `PA4` (`GYRO_CS`), **`Pin 13 (SCx)`** $\rightarrow$ `PA5` (`SPI1_SCK`), **`Pin 1 (SDO)`** $\rightarrow$ `PA6` (`SPI1_MISO`), **`Pin 14 (SDx)`** $\rightarrow$ `PA7` (`SPI1_MOSI`), **`Pin 4 (INT1)`** $\rightarrow$ `PC14` (`GYRO_EXTI`).

---

### 3.4 Sheet 4: AT7456E Analog Betaflight OSD (`SPI2`) & 25–200mW 5.8GHz VTX (`RTC6705 + RTC6659E`)

* **Camera Connector (`J_CAM`):** 3-Pin **`JST-SH-1.0mm` (`BM03B-SRSS-TB`)** + Parallel Solder Pads (`PAD_CAM_5V`, `PAD_CAM_GND`, `PAD_CAM_VIN`) for the NewBeeDrone BeeEye FPV camera.
* **OSD Overlay (`U4 AT7456E` TSSOP-28 on `SPI2` `PB12/PB13/PB14/PB15`):** Overlaid with real-time 1S battery voltage (`3.8V / 4.35V`), mAh drawn from the 300mAh Nitro Nectar Gold pack, LQ/RSSI dBm from the RadioMaster T8L, and flight timer.
* **5.8GHz 25–200mW VTX (`U13 RTC6705` QFN-40 + `U14 RTC6659E` QFN-16 + `U15 EFM8BB10F8G` QFN-20):** Controlled via **SmartAudio v2.1** on `PA2` (`UART2_TX`) across Pit Mode / $25\text{ mW}$ / $100\text{ mW}$ / $200\text{ mW}$ to `J_VTX_ANT` (`U.FL`).
