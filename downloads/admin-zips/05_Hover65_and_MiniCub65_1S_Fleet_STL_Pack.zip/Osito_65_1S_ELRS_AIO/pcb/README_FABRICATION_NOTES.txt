================================================================================
PCB MANUFACTURING & TURNKEY PCBA FABRICATION NOTES
Project: OSITO 65 1S ELRS AIO REV 2.0 FLIGHT CONTROLLER
Target Board Model: OSITO-65-1S-ELRS-AIO (REV 2.0 High-Heat & Zero-DRC Verified)
Platform: 1S 65mm Brushed Whoop (65mm Whoop Standard Drop-In Form Factor)
Date of Release: November 05, 2026
Authorizing Authority: Osito Drone LLC Engineering & Fabrication Operations
================================================================================

1. GENERAL BOARD PARAMETERS:
--------------------------------------------------------------------------------
- Outer Dimensions      : 29.00 mm x 29.00 mm (+/- 0.10 mm)
- Corner Fillet Radius  : 2.00 mm symmetric corner radius on all 4 corners
- Mounting Hole Pattern : 25.50 mm x 25.50 mm square span centered at (0.0, 0.0) mm
- Mounting Hole Details : 4x Non-Plated Through Holes (NPTH), diameter 2.10 mm
                          Drill centers at (+/-12.75 mm, +/-12.75 mm)
                          Keepout zone: 4.20 mm diameter circular collar around each hole
- Battery Pigtail Pads  : 2x Plated Through Holes (PTH), 1.00 mm drill, 1.60 x 1.80 mm pad
                          PAD_BAT+ at (+6.40 mm, -9.00 mm), PAD_BAT- at (-6.40 mm, -9.00 mm)
- Total Board Thickness : 1.00 mm nominal (+/- 10% tolerance: 0.90 mm to 1.10 mm)
- Layer Count           : 4 Layers (Symmetric core & prepreg stackup)

2. 4-LAYER STACKUP PARAMETERS (JLCPCB JLC04101H-7628 / SIERRA CIRCUITS 4L QUICK-TURN):
--------------------------------------------------------------------------------
- Layer 1 (Top Copper)  : 2.0 oz Finished (70 um) [Option: 1.0 oz / 35 um finished]
                          Function: High-Speed Signals, 50-Ohm RF Microstrip, Top FETs
- Dielectric 1-2        : 0.200 mm (7.87 mil) 7628 Prepreg (Dielectric Er = 4.6 +/- 0.2)
- Layer 2 (Inner 1)     : 1.0 oz Copper (35 um)
                          Function: Chamfered Solid Ground (GND) Reference & Heat-Spreader Plane
- Core Dielectric       : 0.460 mm (18.1 mil) FR4 TG170 High-Heat Core (Er = 4.6 +/- 0.2)
- Layer 3 (Inner 2)     : 1.0 oz Copper (35 um)
                          Function: Chamfered Split Power Planes (VBAT_ESC, +5V_CLEAN, +3V3_DIG)
- Dielectric 3-4        : 0.200 mm (7.87 mil) 7628 Prepreg (Dielectric Er = 4.6 +/- 0.2)
- Layer 4 (Bottom Copper): 2.0 oz Finished (70 um) [Option: 1.0 oz / 35 um finished]
                          Function: Bottom ESC FETs, BEC, 5.8GHz VTX, Motor Connectors
- Laminate Material     : High-Tg FR4 (Glass transition temp Tg >= 170 deg C, Td >= 340 deg C)
                          Must withstand 2-pass lead-free reflow thermal shock (peak 245 deg C)
                          and continuous high-heat operation up to 105-125 deg C ambient/junction.

3. SURFACE FINISH, THERMAL VIAS & SOLDER MASK:
--------------------------------------------------------------------------------
- Surface Plating       : Chemical ENIG (Electroless Nickel Immersion Gold) per IPC-4552
                          Gold thickness: 1 - 2 micro-inches (0.025 - 0.05 um)
                          Nickel thickness: 120 - 240 micro-inches (3.0 - 6.0 um)
- Thermal Via-in-Pad    : 29x 0.20 mm drill / 0.45 mm pad thermal/RF vias
                          under U1, U3, U5-U8, U10, U13, U14, U15 center thermal pads (VIPPO /
                          tenting on opposite side per standard turnkey QFN reflow practice).
- Solder Mask Type      : High-Resolution Liquid Photoimageable (LPI) Solder Mask
- Solder Mask Color     : Glossy Green or Glossy Black (Both sides)
- Minimum Solder Mask Dam: 0.080 mm (3.15 mil)
- Mask Expansion        : 0.050 mm (2.0 mil) per pad perimeter edge
- Silkscreen Legend     : High-Resolution White LPI, Double-Sided (Top & Bottom)

4. TURNKEY PCBA ASSEMBLY FILES INCLUDED IN ZIP:
--------------------------------------------------------------------------------
- Turnkey SMT BOM (130 SMT parts): OSITO_65_1S_ELRS_AIO_BOM_Turnkey_PCBA.csv
- Full System & Box-Build BOM    : OSITO_65_1S_ELRS_AIO_BOM.csv
- Pick-and-Place Centroid (CPL)  : OSITO_65_1S_ELRS_AIO_CPL_PickAndPlace.csv

================================================================================
END OF FABRICATION NOTES
================================================================================
