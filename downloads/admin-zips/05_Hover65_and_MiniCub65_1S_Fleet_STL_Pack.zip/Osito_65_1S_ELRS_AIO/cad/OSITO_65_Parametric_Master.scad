// ============================================================================
// OSITO-65-1S-ELRS-AIO (REV 2.0): High-Heat & Crash-Durable OpenSCAD Suite
// ============================================================================
// Parts generated via PART_SELECT:
//   "ALL"          - Complete assembled Osito 65 1S ELRS drone + FC + jigs preview
//   "FC_PCB"       - 29.0 x 29.0 x 7.6mm Flight Controller Mechanical Mockup (Rev 2.0)
//   "FRAME_65"     - 65mm Wheelbase 6mm (0615) Brushed Frame w/ VTX Vents & PH2.0 Strain Relief
//   "CANOPY_FPV"   - Osito 65 Goober-Replacement Micro FPV Canopy w/ High-Heat Exhaust Louvers
//   "CANOPY_LOS"   - Lightweight Line-of-Sight & UART1/2 Expansion Canopy
//   "SMT_JIG"      - Double-Sided In-House SMT Stencil & Reflow Carrier Fixture
//   "POGO_JIG"     - Production Pogo-Pin SWD/DFU & H-Bridge ESC Test Fixture
// ============================================================================

PART_SELECT = "ALL";
PART_ID = 0; // 0=ALL, 1=FC_PCB, 2=FRAME_65, 3=CANOPY_FPV, 4=CANOPY_LOS, 5=SMT_JIG, 6=POGO_JIG
$fn = 64;

// --- Core Flight Controller Parameters (Exact 65mm Whoop Standard Spec) ---
fc_width        = 29.0;     // 29.0 x 29.0 mm outer envelope
fc_length       = 29.0;
fc_total_h      = 7.6;      // 7.6 mm total Z envelope (-3.0mm bottom to +4.6mm top)
fc_pcb_thick    = 1.0;      // 4-Layer 1.0mm FR4 TG170 (2oz Outer / 1oz Inner Cu)
fc_mount_span   = 25.5;     // 25.5 x 25.5 mm Whoop M2 mounting pattern
fc_hole_d       = 2.1;      // M2 silicone grommet mounting hole

// --- 65mm Brushed Frame Parameters (65mm Whoop Standard Cockroach Parity) ---
wheelbase       = 65.0;                     // 65mm motor-to-motor diagonal
motor_r         = wheelbase / 2.0;          // 32.5 mm radial distance
motor_xy        = motor_r * cos(45);        // 22.981 mm X/Y motor center
motor_id        = 6.10;                     // 6mm (0615) brushed motor slip-fit ID
motor_od        = 8.60;                     // Reinforced motor pod outer diameter
motor_pod_h     = 12.5;                     // Supports 15mm tall 0615 motor can
prop_d          = 31.0;                     // 31mm Azi Whoop propeller
duct_id         = 32.6;                     // 32.6mm duct inner diameter
duct_od         = 35.2;                     // 35.2mm reinforced duct outer diameter
duct_h          = 7.5;                      // Aerodynamic prop shroud height

// --- NewBeeDrone Nitro Nectar Gold 1S 300mAh LiHV Battery Bay Parameters ---
bat_w           = 11.8;                     // 1S 300mAh width (11.2mm + thermal airflow clearance)
bat_h           = 6.8;                      // 1S 300mAh thickness (6.4mm + clearance)
bat_l           = 42.0;                     // Battery cradle length

// ============================================================================
// 1. OSITO-65-1S-ELRS-AIO FLIGHT CONTROLLER MOCKUP (29x29x7.6mm REV 2.0)
// ============================================================================
module fc_pcb_mockup() {
    union() {
        difference() {
            union() {
                // 1.0mm 4-Layer PCB Substrate (Z = 0 to 1.0mm) with 2.0mm corner fillets
                linear_extrude(height = fc_pcb_thick)
                    offset(r = 2.0) offset(delta = -2.0)
                        square([fc_width, fc_length], center = true);

                // Top Side Components (+Z from 1.0mm up to 4.6mm -> +3.6mm height)
                // U1: STM32F411CEU6 (UFQFPN-48 7x7x0.8mm at 0,0, 0 deg orientation)
                translate([-3.5, -3.5, fc_pcb_thick])
                    cube([7.0, 7.0, 0.9]);

                // U2: Bosch BMI270 Gyro (2.5x3.0x0.8mm at 0,-5.8)
                translate([-1.25, -5.8 - 1.5, fc_pcb_thick])
                    cube([2.5, 3.0, 0.9]);

                // U3: Semtech SX1280 SPI ELRS 2.4GHz (4x4x0.9mm at 0,7.6)
                translate([-2.0, 7.6 - 2.0, fc_pcb_thick])
                    cube([4.0, 4.0, 0.9]);

                // ANT1: 2.4GHz SMD Ceramic Antenna (Top Front at 0,13.1)
                translate([-1.6, 12.3, fc_pcb_thick])
                    cube([3.2, 1.6, 3.2]);

                // U4: AT7456E Analog OSD (TSSOP-28 at -10.0,0.0)
                translate([-12.2, -4.5, fc_pcb_thick])
                    cube([4.4, 9.0, 1.1]);

                // Top H-Bridge MOSFETs Q1A, Q1B, Q2A, Q2B (SOIC-8 at X=10.6)
                for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                    translate([10.6 - 2.45, yp - 1.95, fc_pcb_thick])
                        cube([4.9, 3.9, 1.2]);
                }

                // J1: USB Type-C Receptacle (Rear Edge at 0,-12.1, +3.6mm top profile)
                translate([-4.5, -14.1, fc_pcb_thick])
                    cube([9.0, 6.5, 3.6]);

                // J_CAM: 3-Pin JST-SH FPV Camera Header (at -5.8,12.1)
                translate([-8.0, 10.6, fc_pcb_thick])
                    cube([4.5, 2.8, 2.2]);

                // 2x Reinforced PTH Battery Pigtail Pads (PAD_BAT+ / PAD_BAT- at +/-6.4, -9.0)
                for (sx = [-1, 1]) {
                    translate([sx * 6.4 - 0.8, -9.0 - 0.9, -0.2])
                        cube([1.6, 1.8, 1.4]);
                }

                // 4x M2 Anti-Vibration Grommet Collars at 25.5 x 25.5mm (+3.6mm top)
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -1.0])
                        cylinder(d = 3.8, h = 5.6);
                }

                // Bottom Side Components (-Z from 0 down to -3.0mm -> Total H = 7.6mm)
                // 4x JST-1.25mm 2-Pin Brushed Motor Headers (M1..M4 at +/-8.0, +/-12.2)
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 8.0 - 2.2, sy * 12.2 - 1.5, -3.0])
                        cube([4.4, 3.0, 3.0]);
                }

                // Bottom H-Bridge MOSFETs Q3A, Q3B, Q4A, Q4B & 4x EFM8BB21 ESC MCUs
                for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                    translate([-10.6 - 2.45, yp - 1.95, -1.2])
                        cube([4.9, 3.9, 1.2]);
                }
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 5.6 - 1.5, sy * 5.6 - 1.5, -0.9])
                        cube([3.0, 3.0, 0.9]);
                }

                // U13 RTC6705 VTX (6x6mm) + U14 RTC6659E PA (3x3mm) + U10 TPS63020 BEC + C_BULK 220uF
                translate([-3.0, 3.6 - 3.0, -0.9]) cube([6.0, 6.0, 0.9]);
                translate([-1.5, 9.0 - 1.5, -0.9]) cube([3.0, 3.0, 0.9]);
                translate([-1.5, -5.2 - 2.0, -1.0]) cube([3.0, 4.0, 1.0]);
                translate([12.2 - 1.4, -4.8 - 1.75, -1.9]) cube([2.8, 3.5, 1.9]);
            }

            // 4x 25.5 x 25.5mm Mounting Through-Holes (d = 2.1mm) + 2x PTH Battery Drills (d = 1.0mm)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -5.0])
                    cylinder(d = fc_hole_d, h = 15.0);
            }
            for (sx = [-1, 1]) {
                translate([sx * 6.4, -9.0, -5.0])
                    cylinder(d = 1.0, h = 15.0);
            }
        }
    }
}

// ============================================================================
// 2. OSITO-65 65MM BRUSHED DRONE FRAME (HIGH-HEAT VENTS & CRASH BUMPERS)
// ============================================================================
module frame_65mm() {
    difference() {
        union() {
            // A. 4x 31mm Propeller Ducts at (+/-22.981, +/-22.981)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    // Outer aerodynamic shroud wall
                    difference() {
                        cylinder(d = duct_od, h = duct_h);
                        translate([0, 0, -0.5])
                            cylinder(d = duct_id, h = duct_h + 1.0);
                    }
                    // Bottom & Mid-Height Crash Bumper Rings
                    for (zp = [0.0, duct_h - 1.4]) {
                        translate([0, 0, zp])
                            difference() {
                                cylinder(d = duct_od + 0.9, h = 1.4);
                                translate([0, 0, -0.2])
                                    cylinder(d = duct_id, h = 1.8);
                            }
                    }
                    // 6mm (0615) Brushed Motor Pod (Z = -3.0 to +9.5mm)
                    translate([0, 0, -3.0])
                        cylinder(d = motor_od, h = motor_pod_h);

                    // 3x Heavy-Duty 2.6mm Radial Motor Struts connecting Motor Pod to Duct Wall
                    for (ang = [45 + (sx*sy > 0 ? 0 : 90), 165 + (sx*sy > 0 ? 0 : 90), 285 + (sx*sy > 0 ? 0 : 90)]) {
                        rotate([0, 0, ang])
                            translate([motor_id/2 - 0.2, -1.3, 0])
                                cube([(duct_id - motor_id)/2 + 0.6, 2.6, 2.4]);
                    }
                }
            }

            // B. Perimeter Inter-Duct Gusset Bridges (Recessed to h=2.4mm for USB-C Cable Access)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * motor_xy, -6.5, 0]) cylinder(d = 3.0, h = 2.4);
                    translate([sx * motor_xy,  6.5, 0]) cylinder(d = 3.0, h = 2.4);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-6.5, sy * motor_xy, 0]) cylinder(d = 3.0, h = 2.4);
                    translate([ 6.5, sy * motor_xy, 0]) cylinder(d = 3.0, h = 2.4);
                }
            }

            // C. Central X-Chassis Plate & True Cockroach 65 Diamond 25.5x25.5mm FC Standoffs
            // Diamond post radius: 25.5 / sqrt(2) = 18.031mm at (0, +/-18.031) and (+/-18.031, 0)
            // -> 23.51mm from motor shafts (100% outside the 35.2mm propeller ducts!)
            for (sx = [-1, 1], sy = [-1, 1]) {
                hull() {
                    translate([sx * 7.0, sy * 7.0, 0]) cylinder(d = 3.8, h = 2.4);
                    translate([sx * motor_xy, sy * motor_xy, 0]) cylinder(d = 4.4, h = 2.4);
                }
            }
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang]) {
                    hull() {
                        translate([fc_mount_span / sqrt(2), 0, 0])
                            cylinder(d = 5.2, h = 5.5);
                        translate([11.5, 0, 0])
                            cylinder(d = 3.8, h = 2.4);
                    }
                    translate([fc_mount_span / sqrt(2), 0, 5.5])
                        cylinder(d = 3.8, h = 2.0);
                }
            }

            // Central Perimeter Frame Ring (Leaves center open for VTX/BEC airflow)
            difference() {
                linear_extrude(height = 2.4)
                    offset(r = 2.0)
                        square([24.0, 24.0], center = true);
                translate([0, 0, -0.5])
                    linear_extrude(height = 3.4)
                        offset(r = 1.5)
                            square([18.5, 18.5], center = true);
            }

            // D. Under-Slung 1S 300mAh LiHV Battery Cradle, VTX Vent Chimneys & PH2.0 Strain Relief
            translate([0, 0, -bat_h - 1.4]) {
                difference() {
                    union() {
                        translate([-(bat_w + 3.2)/2, -bat_l/2, 0])
                            cube([bat_w + 3.2, bat_l, bat_h + 1.6]);
                        // Bottom Twin Landing Skid Runners
                        for (sx = [-1, 1]) {
                            translate([sx * (bat_w/2 + 0.8) - 1.0, -bat_l/2, -1.2])
                                cube([2.0, bat_l, 1.4]);
                        }
                        // Rear PH2.0 Solid-Pin Pigtail Strain-Relief Bridge (at Y = -bat_l/2 - 2.8)
                        translate([-5.0, -bat_l/2 - 2.8, bat_h - 0.8])
                            cube([10.0, 3.0, 2.4]);
                    }
                    // Inner 1S 300mAh Battery Tunnel (11.8mm wide x 6.8mm tall)
                    translate([-bat_w/2, -bat_l/2 - 1.0, 1.4])
                        cube([bat_w, bat_l + 2.0, bat_h + 0.5]);
                    // Side Weight-Saving & Cooling Grip Windows
                    for (yp = [-12, 0, 12]) {
                        translate([-(bat_w + 6)/2, yp - 3.5, 2.6])
                            cube([bat_w + 6, 7.0, bat_h - 2.0]);
                    }
                    // HIGH-HEAT UPGRADE: Top Roof Ventilation Chimney Slots under VTX & BEC
                    for (yp = [-10, -3, 4, 11]) {
                        translate([-4.5, yp - 2.0, bat_h + 0.2])
                            cube([9.0, 4.0, 3.0]);
                    }
                    // Rear PH2.0 Pigtail Zip-Tie / Cable Retention Slot
                    translate([-2.2, -bat_l/2 - 3.2, bat_h - 1.2])
                        cube([4.4, 4.0, 3.2]);
                }
            }
        }

        // --- Subtractive Bores & Clearances ---
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 0]) {
                translate([0, 0, -1.8])
                    cylinder(d = motor_id, h = 15.0);
                translate([0, 0, -4.0])
                    cylinder(d = 4.6, h = 4.0);
                rotate([0, 0, atan2(sy, sx)])
                    translate([0, -0.6, 0.5])
                        cube([6.0, 1.2, 10.0]);
            }
        }

        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 2.4])
                difference() {
                    cylinder(d = duct_id, h = duct_h + 2.0);
                    translate([0, 0, -0.5])
                        cylinder(d = motor_od, h = duct_h + 3.0);
                }
        }

        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_mount_span / sqrt(2), 0, -1.0])
                    cylinder(d = 1.75, h = 10.0);
        }
    }
}

// ============================================================================
// 3. OSITO65 MICRO FPV CAMERA CANOPY WITH HIGH-HEAT EXHAUST LOUVERS
// ============================================================================
module canopy_fpv() {
    difference() {
        union() {
            difference() {
                hull() {
                    translate([0, 0, 0]) cylinder(d = 26.0, h = 1.5);
                    translate([0, 2.0, 9.0]) sphere(d = 17.0);
                    translate([0, 8.5, 6.5]) rotate([-15, 0, 0]) cylinder(d = 13.6, h = 4.0);
                }
                hull() {
                    translate([0, 0, -0.5]) cylinder(d = 22.8, h = 1.5);
                    translate([0, 2.0, 8.6]) sphere(d = 13.8);
                    translate([0, 8.0, 6.2]) rotate([-15, 0, 0]) cylinder(d = 10.6, h = 4.5);
                }
                translate([-30, -30, -20]) cube([60, 60, 20]);
            }

            // 4x Cockroach 65 Diamond 25.5 x 25.5mm Mounting Ears at (0, +/-18.031) & (+/-18.031, 0)
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang])
                    hull() {
                        translate([fc_mount_span / sqrt(2), 0, 0])
                            cylinder(d = 5.2, h = 2.0);
                        translate([11.0, 0, 0])
                            cylinder(d = 4.0, h = 2.0);
                    }
            }

            // Rear-Left Offset 5.8GHz Whip Dipole Antenna Guard Tube (Clears Rear-Right USB-C Access)
            translate([-5.0, -9.5, 4.0])
                rotate([25, 0, 0])
                    cylinder(d = 4.2, h = 10.0);
        }

        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_mount_span / sqrt(2), 0, -1.0])
                    cylinder(d = 2.2, h = 5.0);
        }

        // Front 15-Deg Uptilt Micro FPV Camera Lens Bore (d = 10.2mm)
        translate([0, 6.0, 6.0])
            rotate([-75, 0, 0])
                cylinder(d = 10.2, h = 12.0);

        // Rear-Right 45-Deg USB-C Overmold Access Arch Cutout (Matches CW45 Diamond FC Mount)
        rotate([0, 0, -45])
            translate([-6.25, -15.0, -0.5])
                cube([12.5, 6.5, 5.2]);

        // HIGH-HEAT UPGRADE: 3 Pairs of Side VTX/ESC Louvers + Top-Rear Exhaust Chimney
        for (yp = [-5.0, -1.0, 3.0]) {
            translate([-15, yp, 3.8])
                cube([30, 2.2, 5.2]);
        }
        translate([-4.0, -5.5, 8.2])
            cube([8.0, 6.0, 4.0]);

        translate([-5.0, -9.5, 3.0])
            rotate([25, 0, 0])
                cylinder(d = 2.0, h = 14.0);
    }
}

// ============================================================================
// 4. LINE-OF-SIGHT (LOS) & UART1/2 EXPANSION CANOPY
// ============================================================================
module canopy_los() {
    difference() {
        union() {
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang])
                    hull() {
                        translate([fc_mount_span / sqrt(2), 0, 0])
                            cylinder(d = 5.2, h = 2.0);
                        translate([7.5, 0, 7.0])
                            cylinder(d = 3.6, h = 2.0);
                    }
            }
            hull() {
                translate([-8.0, 0, 7.0]) cylinder(d = 3.8, h = 2.0);
                translate([ 8.0, 0, 7.0]) cylinder(d = 3.8, h = 2.0);
                translate([ 0.0, 9.5, 7.0]) cylinder(d = 2.4, h = 2.0);
            }
        }
        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_mount_span / sqrt(2), 0, -1.0])
                    cylinder(d = 2.2, h = 5.0);
        }
    }
}

// ============================================================================
// 5. IN-HOUSE DOUBLE-SIDED SMT STENCIL & REFLOW CARRIER JIG (FOR 29x29mm PCB)
// ============================================================================
module smt_stencil_jig() {
    difference() {
        translate([-27.5, -27.5, 0])
            cube([55.0, 55.0, 9.0]);

        translate([-14.625, -14.625, 8.0])
            cube([29.25, 29.25, 1.5]);

        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 14.6, sy * 14.6, 6.5])
                cylinder(d = 5.0, h = 4.0);
        }

        translate([-12.0, -12.0, 3.0])
            cube([24.0, 24.0, 5.5]);

        translate([-6.0, -16.5, 3.0])
            cube([12.0, 5.0, 6.5]);

        translate([0, 0, -1.0])
            cylinder(d = 14.0, h = 6.0);

        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 22.0, sy * 22.0, -1.0])
                cylinder(d = 3.0, h = 12.0);
        }
    }
}

// ============================================================================
// 6. IN-HOUSE POGO-PIN SWD/DFU & H-BRIDGE ESC PRODUCTION TEST JIG
// ============================================================================
module pogo_test_jig() {
    difference() {
        union() {
            translate([-22.0, -22.0, 0])
                cube([44.0, 44.0, 12.0]);

            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, 12.0]) {
                    cylinder(d = 5.0, h = 4.5);
                    translate([0, 0, 4.5])
                        cylinder(d1 = 2.0, d2 = 1.5, h = 3.0);
                }
            }
        }

        for (i = [-2.5 : 1 : 2.5]) {
            translate([i * 2.54, -2.5, -1.0])
                cylinder(d = 1.40, h = 15.0);
        }

        translate([-12.0, -6.0, -0.5])
            cube([24.0, 8.0, 5.5]);
    }
}

// ============================================================================
// MASTER DISPATCHER
// ============================================================================
if (PART_ID == 1 || PART_SELECT == "FC_PCB") {
    fc_pcb_mockup();
} else if (PART_ID == 2 || PART_SELECT == "FRAME_65") {
    frame_65mm();
} else if (PART_ID == 3 || PART_SELECT == "CANOPY_FPV") {
    canopy_fpv();
} else if (PART_ID == 4 || PART_SELECT == "CANOPY_LOS") {
    canopy_los();
} else if (PART_ID == 5 || PART_SELECT == "SMT_JIG") {
    smt_stencil_jig();
} else if (PART_ID == 6 || PART_SELECT == "POGO_JIG") {
    pogo_test_jig();
} else {
    frame_65mm();
    // Mounted in 45-Deg Cockroach 65 Diamond Orientation (matches align_board_yaw = 450)
    translate([0, 0, 5.5]) rotate([0, 0, -45]) fc_pcb_mockup();
    translate([0, 0, 7.5]) canopy_fpv();
}
