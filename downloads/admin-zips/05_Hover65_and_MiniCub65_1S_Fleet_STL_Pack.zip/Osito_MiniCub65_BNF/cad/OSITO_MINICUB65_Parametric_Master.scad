// ============================================================================
// OSITO MINICUB-65 BNF (REV 2.0): Proprietary Parametric 65mm 1S CAD Suite
// ============================================================================
// Proprietary Osito Drone LLC Industrial Design & Structural Architecture:
//   1. Grizzly-Ring 65 Airframe : 8-Sided Octa-Facet Chamfered Impact Ducts
//   2. Anti-Resonance Struts    : 3-Spoke Tangential Swirl Tri-Truss Motor Mounts
//   3. Osito CubCap Canopy      : Faceted Bear-Ear Impact Shell w/ Dual Exhaust Louvers,
//                                 15/25/35 deg Indexed Camera Tilt & Whip Antenna Guard
//   4. Tail Pigtail Retention   : Cantilevered BT2.0/PH2.0 Strain-Relief Bridge
//   5. Core Mechanical Envelope :
//      - 65.0 mm Diagonal Motor-to-Motor Wheelbase
//      - 25.5 x 25.5 mm M2 Diamond FC Mounting Pattern (29x29x7.6mm CubBrain-65 AIO)
//      - 31.0 mm 3-Blade / 4-Blade Propeller Clearance (32.6mm Duct ID = 0.80mm Tip Clearance)
//      - CubCell 1S 300mAh 80C LiHV Battery Cradle (11.8 x 6.8 x 42.0 mm)
//
// Bambu Lab P2S Combo 4-Tier Filament Assignment:
//   - Airframe (FRAME_BRUSHED / FRAME_BRUSHLESS) : Tier 1 Bambu PETG-CF (P2S #1 AMS Slot 1)
//   - Canopy (CANOPY_CUBCAP)                     : Tier 4 Bambu TPU for AMS 68D (Slot 4)
//                                                  or Bambu TPU 95A HF (P2S #2 External Port)
// ============================================================================

PART_SELECT  = "ALL"; // "ALL", "FRAME_BRUSHED", "FRAME_BRUSHLESS", "CANOPY_CUBCAP", "FC_CUBBRAIN"
PART_ID      = 0;     // 0=ALL, 1=FRAME_BRUSHED, 2=FRAME_BRUSHLESS, 3=CANOPY_CUBCAP, 4=FC_CUBBRAIN
CAM_TILT_DEG = 25;    // Indexed at 15 (STEM Beginner), 25 (Indoor Acro), or 35 (Race) degrees
$fn = 48;

// --- Core 65mm Micro-Drone Functional Dimensions ---
wheelbase       = 65.0;                     // 65.0mm diagonal motor-to-motor wheelbase
motor_r         = wheelbase / 2.0;          // 32.5mm radial distance from center
motor_xy        = motor_r * cos(45);        // 22.981mm X/Y coordinate
fc_width        = 29.0;                     // 29.0 x 29.0mm CubBrain-65 AIO envelope
fc_length       = 29.0;
fc_pcb_thick    = 1.0;                      // 1.0mm 4-Layer TG170 FR4 (2oz Outer / 1oz Inner Cu)
fc_mount_span   = 25.5;                     // 25.5 x 25.5mm M2 diamond pattern
fc_post_r       = fc_mount_span / sqrt(2);  // 18.031mm diamond post radius
fc_hole_d       = 2.1;                      // M2 silicone grommet mounting hole
prop_d          = 31.0;                     // 31mm micro ducted propeller
duct_id         = 32.6;                     // 0.80mm radial prop tip clearance
duct_od         = 35.4;                     // Structural wall outer diameter
duct_h          = 7.6;                      // Full sub-50g youth-safe prop shroud height

// --- Motor Mount Parameters (Trim A: CubCore 0615 Brushed vs Trim B: CubSpin 0702SE Brushless) ---
brushed_id      = 6.10;                     // 6x15mm coreless brushed motor slip-fit ID
brushed_od      = 8.60;                     // Brushed motor pod OD
brushed_pod_h   = 12.2;                     // Supports 15mm tall 0615 motor can
brushless_bcd   = 6.60;                     // 3-hole 0702SE 6.60mm bolt circle diameter
brushless_screw = 1.45;                     // M1.4 motor screw clearance hole
brushless_c_hole= 2.15;                     // Center shaft/c-clip clearance hole

// --- CubCell 1S 300mAh LiHV Battery Bay Parameters ---
bat_w           = 11.8;                     // Fits CubCell 1S 300mAh LiHV (BT2.0 or PH2.0)
bat_h           = 6.8;
bat_l           = 42.0;

// ============================================================================
// HELPER: OCTA-FACET CHAMFERED DUCT PROFILE (Grizzly-Ring 65 Outer Rim)
// ============================================================================
module octa_duct_shell(id, od, h) {
    difference() {
        union() {
            cylinder(d = od, h = h);
            rotate([0, 0, 22.5])
                cylinder(d = od + 1.4, h = h, $fn = 8);
            // Bottom chamfered Octa-Facet bumper band (flush on Z=0 plane)
            rotate([0, 0, 22.5])
                cylinder(d = od + 2.0, h = 1.5, $fn = 8);
            // Top chamfered Octa-Facet bumper band (45-deg lower transition eliminates 90-deg mid-air overhang)
            translate([0, 0, h - 1.8])
                rotate([0, 0, 22.5])
                    cylinder(d1 = od + 1.4, d2 = od + 2.0, h = 0.4, $fn = 8);
            translate([0, 0, h - 1.4])
                rotate([0, 0, 22.5])
                    cylinder(d = od + 2.0, h = 1.4, $fn = 8);
        }
        translate([0, 0, -0.5])
            cylinder(d1 = id, d2 = id + 0.2, h = h + 1.0); // 1.5-deg draft angle
    }
}

// ============================================================================
// 1. OSITO CUBBRAIN-65 AIO FLIGHT CONTROLLER MOCKUP (29.0 x 29.0 x 7.6mm)
// ============================================================================
module fc_cubbrain_mockup() {
    difference() {
        union() {
            // 1.0mm 4-Layer TG170 FR4 Substrate with R=2.0mm corner fillets
            linear_extrude(height = fc_pcb_thick)
                offset(r = 2.0) offset(delta = -2.0)
                    square([fc_width, fc_length], center = true);

            // Top-Side Components (+Z from 1.0mm to +4.6mm)
            // U1: STM32F411CEU6 (UFQFPN-48 7x7x0.8mm at 0,0)
            translate([-3.5, -3.5, fc_pcb_thick]) cube([7.0, 7.0, 0.9]);
            // U2: Bosch BMI270 Gyro (2.5x3.0x0.8mm at 0,-5.8)
            translate([-1.25, -7.3, fc_pcb_thick]) cube([2.5, 3.0, 0.9]);
            // U3: Semtech SX1280 SPI3 ELRS 2.4GHz (4x4x0.9mm at 0,7.6)
            translate([-2.0, 5.6, fc_pcb_thick]) cube([4.0, 4.0, 0.9]);
            // ANT1: 2.4GHz SMD Ceramic Chip Antenna (at 0,13.1)
            translate([-1.6, 12.3, fc_pcb_thick]) cube([3.2, 1.6, 3.2]);
            // U4: AT7456E Analog OSD (HTSSOP-28-EP at -10.0,0.0)
            translate([-12.2, -4.5, fc_pcb_thick]) cube([4.4, 9.0, 1.1]);
            // Top H-Bridge MOSFETs Q1A, Q1B, Q2A, Q2B (SOIC-8 at X=10.6)
            for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                translate([8.15, yp - 1.95, fc_pcb_thick]) cube([4.9, 3.9, 1.2]);
            }
            // J1: 16-Pin USB Type-C Receptacle (Rear Edge at 0,-12.1)
            translate([-4.5, -14.1, fc_pcb_thick]) cube([9.0, 6.5, 3.6]);
            // J_CAM: 3-Pin JST-SH FPV Camera Header (at -5.8,12.1)
            translate([-8.0, 10.6, fc_pcb_thick]) cube([4.5, 2.8, 2.2]);
            // 2x Reinforced 4-Layer PTH Battery Pads (PAD_BAT+ / PAD_BAT- at +/-6.4, -9.0)
            for (sx = [-1, 1]) {
                translate([sx * 6.4 - 0.8, -9.9, -0.2]) cube([1.6, 1.8, 1.4]);
            }
            // 4x M2 Silicone Anti-Vibration Grommet Collars at 25.5x25.5mm (Full -3.0..+4.6mm height so all 4 corners sit flush on build plate)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -3.0])
                    cylinder(d = 3.8, h = 7.6);
            }

            // Bottom-Side Components (-Z from 0 down to -3.0mm)
            // 4x JST-1.25mm Motor Headers (J_M1..J_M4 at +/-5.20, +/-12.20 matching Pick-and-Place CPL)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.2 - 2.2, sy * 12.2 - 1.5, -3.0])
                    cube([4.4, 3.0, 3.0]);
            }
            // Bottom H-Bridge MOSFETs Q3A..Q4B & 4x EFM8BB21 ESC MCUs (U5..U8)
            for (yp = [-7.2, -2.4, 2.4, 7.2]) {
                translate([-13.05, yp - 1.95, -1.2]) cube([4.9, 3.9, 1.2]);
            }
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.6 - 1.5, sy * 5.6 - 1.5, -0.9])
                    cube([3.0, 3.0, 0.9]);
            }
            // U13 RTC6705 VTX + U14 RTC6659E PA + U10 TPS63020 BEC + C_BULK 220uF POSCAP
            translate([-3.0, 0.6, -0.9]) cube([6.0, 6.0, 0.9]);
            translate([-1.5, 7.5, -0.9]) cube([3.0, 3.0, 0.9]);
            translate([-1.5, -7.2, -1.0]) cube([3.0, 4.0, 1.0]);
            translate([10.8, -6.55, -1.9]) cube([2.8, 3.5, 1.9]);
        }

        // 4x 25.5x25.5mm M2 Mounting Holes (d=2.1mm) + 2x PTH Battery Drills (d=1.0mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -5.0])
                cylinder(d = fc_hole_d, h = 15.0);
        }
        for (sx = [-1, 1]) {
            translate([sx * 6.4, -9.0, -5.0])
                cylinder(d = 1.0, h = 15.0);
        }
    }
}

module cubbrain65_fc_mockup() {
    fc_cubbrain_mockup();
}

// ============================================================================
// 2. MINICUB-65 GRIZZLY-RING 65 AIRFRAME (BRUSHED 0615 OR BRUSHLESS 0702SE)
// ============================================================================
module minicub65_frame(is_brushless = false) {
    difference() {
        union() {
            // A. 4x Octa-Facet Propeller Ducts at (+/-22.981, +/-22.981)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    octa_duct_shell(duct_id, duct_od, duct_h);

                    if (!is_brushless) {
                        translate([0, 0, -2.8])
                            cylinder(d = brushed_od, h = brushed_pod_h);
                    } else {
                        cylinder(d = 10.2, h = 2.6);
                    }

                    // Proprietary 3-Spoke Tangential Swirl Tri-Truss Struts (Oriented to inward_ang = atan2(sy,sx)+180)
                    // Spoke 1 (0 deg = Radially Inward toward FC): 4.0mm wide Wire-Carrier Spine w/ Protected Under-Trough
                    rotate([0, 0, atan2(sy, sx) + 180])
                        translate([2.6, -2.0, 0])
                            cube([(duct_id / 2) - 1.5, 4.0, 2.4]);
                    // Spokes 2 & 3 (+120 deg & +240 deg): Tangential Swirl Anti-Resonance Chords (clear 60/180/300 M1.4 screws)
                    for (ang_off = [120, 240]) {
                        rotate([0, 0, atan2(sy, sx) + 180 + ang_off])
                            translate([2.2, -1.25, 0])
                                rotate([0, 0, -14])
                                    cube([(duct_id / 2) - 1.4, 2.5, 2.4]);
                    }
                }
            }

            // B. Perimeter Tri-Truss Box Beams (Terminated at +/-5.2mm inside duct wall annulus)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * motor_xy, -5.2, 0]) cylinder(d = 3.2, h = 2.4);
                    translate([sx * motor_xy,  5.2, 0]) cylinder(d = 3.2, h = 2.4);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-5.2, sy * motor_xy, 0]) cylinder(d = 3.2, h = 2.4);
                    translate([ 5.2, sy * motor_xy, 0]) cylinder(d = 3.2, h = 2.4);
                }
            }

            // C. Central Octagonal Torque Ring, Twin-Beam Wire-Channel Diagonal Arms & 25.5x25.5mm Diamond FC Standoffs
            // Diagonal chassis arms & twin-beam structural rails framing the unobstructed 3.30x6.50mm JST-1.25mm Pass-Through Windows
            for (sx = [-1, 1], sy = [-1, 1]) {
                hull() {
                    translate([sx * 7.2, sy * 7.2, 0]) cylinder(d = 3.8, h = 2.4);
                    translate([sx * (motor_xy - 11.8), sy * (motor_xy - 11.8), 0]) cylinder(d = 3.6, h = 2.4);
                }
                // Flanking Twin-Beam Diagonal Rails (+/-2.55mm offset) keeping full 2.40mm height
                for (off_s = [-1, 1]) {
                    hull() {
                        translate([sx * 6.8 + off_s * sy * 1.8, sy * 6.8 - off_s * sx * 1.8, 0]) cylinder(d = 2.5, h = 2.4);
                        translate([sx * (motor_xy - 12.2) + off_s * sy * 1.8, sy * (motor_xy - 12.2) - off_s * sx * 1.8, 0]) cylinder(d = 2.5, h = 2.4);
                    }
                }
                // Outboard & Inboard 2.40mm Structural Box-Beams framing the [|x|=7.55..10.85, |y|=3.60..10.10] Vertical JST Pass-Through Window
                hull() {
                    translate([sx * 12.0, sy * 3.0, 0]) cylinder(d = 2.6, h = 2.4);
                    translate([sx * 12.0, sy * 9.6, 0]) cylinder(d = 2.6, h = 2.4);
                }
                hull() {
                    translate([sx * 7.2, sy * 11.2, 0]) cylinder(d = 2.4, h = 2.4);
                    translate([sx * 10.2, sy * 11.2, 0]) cylinder(d = 2.4, h = 2.4);
                }
            }
            // Flat 2.4mm Cardinal Standoff Gussets + Vertical 5.5mm M2 Pillars (eliminates sloped ramp under FC edges)
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang]) {
                    hull() {
                        translate([fc_post_r, 0, 0]) cylinder(d = 5.2, h = 2.4);
                        translate([11.2, 0, 0]) cylinder(d = 3.8, h = 2.4);
                    }
                    translate([fc_post_r, 0, 0]) cylinder(d = 5.2, h = 5.5);
                    translate([fc_post_r, 0, 5.5]) cylinder(d = 3.8, h = 2.0);
                }
            }

            // Central Octagonal Chassis Plate (Open center for VTX & BEC airflow)
            difference() {
                rotate([0, 0, 22.5]) cylinder(d = 26.5, h = 2.4, $fn = 8);
                translate([0, 0, -0.5])
                    rotate([0, 0, 22.5]) cylinder(d = 19.5, h = 3.4, $fn = 8);
            }

            // D. Under-Slung CubCell 1S 300mAh LiHV Battery Bay + Cantilevered BT2.0 Strain Gate
            // Outer box height bat_h + 2.8 = 9.60mm reaches world Z = +1.40mm for deep 1.40mm structural fusion
            translate([0, 0, -bat_h - 1.4]) {
                difference() {
                    union() {
                        translate([-(bat_w + 3.2)/2, -bat_l/2, 0])
                            cube([bat_w + 3.2, bat_l, bat_h + 2.8]);
                        // Flush Bottom Skid Runners at local Z = 0.0 (entire 15.2x42.0mm bottom sits 100% flat on PEI build plate)
                        for (sx = [-1, 1]) {
                            translate([sx * (bat_w/2 + 0.8) - 1.0, -bat_l/2, 0.0])
                                cube([2.0, bat_l, 1.2]);
                        }
                        // Continuous Full-Width Rear BT2.0 Strain-Relief Bridge (fuses into side walls & rear beam)
                        translate([-(bat_w + 3.2)/2, -bat_l/2 - 3.2, bat_h - 0.8])
                            cube([bat_w + 3.2, 4.2, 3.6]);
                    }
                    // Inner battery tunnel (height = bat_h = 6.80mm at local Z = 1.20..8.00mm, so roof straddles global Z = 0.00mm cleanly)
                    translate([-bat_w/2, -bat_l/2 - 0.2, 1.2])
                        cube([bat_w, bat_l + 1.4, bat_h]);
                    // Side weight-saving & grip windows
                    for (yp = [-12, 0, 12]) {
                        translate([-(bat_w + 6)/2, yp - 3.5, 2.6])
                            cube([bat_w + 6, 7.0, bat_h - 2.0]);
                    }
                    // 4x True Under-VTX Cooling Chimneys cut cleanly through the 1.40mm top roof
                    for (yp = [-10, -3, 4, 11]) {
                        translate([-4.5, yp - 2.0, bat_h + 1.0])
                            cube([9.0, 4.0, 2.4]);
                    }
                    // Top-entry U-Channel Wire Slot in Rear Strain-Relief Bridge (preserves continuous bottom crossbar)
                    translate([-2.2, -bat_l/2 - 3.6, bat_h + 0.4])
                        cube([4.4, 4.8, 3.0]);
                }
            }
        }

        // --- Subtractive Motor Bores, 5-Stage Motor Wire Routing Channels & Standoff Screw Holes ---
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 0]) {
                if (!is_brushless) {
                    translate([0, 0, -1.6]) cylinder(d = brushed_id, h = 15.0);
                    translate([0, 0, -4.0]) cylinder(d = 4.6, h = 4.0);
                    // Stage 1A: Full-Height Inward C-Clamp Wire Slot (X=0..4.35mm cuts 100% of r=4.30mm pod wall without gashing Spoke 1 roof)
                    // + Bottom Endbell Relief Arch & 3.10mm wide Bottom-Lip JST-1.25mm 2-Pin Plug Pass-Through
                    rotate([0, 0, atan2(sy, sx) + 180]) {
                        translate([0, -0.75, -3.5]) cube([4.35, 1.5, 14.0]);
                        translate([0, -1.1, -3.5]) cube([5.2, 2.2, 4.75]);
                        translate([0, -1.55, -3.5]) cube([4.2, 3.1, 1.95]);
                    }
                } else {
                    translate([0, 0, -1.0]) cylinder(d = brushless_c_hole, h = 5.0);
                    // Stage 1B: Inward-Aligned 60/180/300 deg 6.60mm BCD Screw Pattern (leaves 0 deg inward wire exit clear)
                    for (ma = [60, 180, 300]) {
                        rotate([0, 0, atan2(sy, sx) + 180 + ma])
                            translate([brushless_bcd / 2, 0, -1.0])
                                cylinder(d = brushless_screw, h = 5.0);
                    }
                    // Inward 0702 Stator Wire Bevel (connects down to Z=0.80mm into under-strut trough = zero blind floor!)
                    // + 4.0x3.8mm Side-Entry Wire Gate extending 2.3mm clear past r=5.1mm motor pad perimeter
                    rotate([0, 0, atan2(sy, sx) + 180]) {
                        translate([3.4, -1.1, 0.80])
                            cube([2.2, 2.2, 2.2]);
                        translate([3.4, 0.0, -0.5])
                            cube([4.0, 3.8, 1.75]);
                    }
                }

                // Stage 2 & 3: Protected Under-Strut & Through-Duct-Wall Wire U-Channel (2.20mm wide + 45-deg self-supporting crown to Z=1.45mm)
                rotate([0, 0, atan2(sy, sx) + 180]) {
                    translate([3.2, -1.1, -0.5])
                        cube([15.6, 2.2, 1.75]);
                    hull() {
                        translate([3.2, -1.1, 1.10]) cube([15.6, 2.2, 0.15]);
                        translate([3.2, -0.6, 1.10]) cube([15.6, 1.2, 0.35]);
                    }
                }
            }
        }

        // Stage 4: Unobstructed 3.30x6.50mm Vertical JST-1.25mm Pass-Through Windows (100% outside |x|<=7.50mm Battery Bay)
        // + Diagonal Wire Channels & Localized Bottom-JST Header Relief Pockets (preserving full 2.40mm twin-beam rail height)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx > 0 ? 7.55 : -10.85, sy > 0 ? 3.60 : -10.10, -0.5])
                cube([3.30, 6.50, 3.5]);
        }
        difference() {
            for (ang = [45, 135, 225, 315]) {
                rotate([0, 0, ang])
                    translate([8.4, -1.6, -0.5])
                        cube([6.4, 3.2, 3.5]);
            }
            // Preserve 100% of the Battery Bay outer walls & 1.40mm roof (Z <= 1.40mm within X = +/-7.5mm)
            translate([-(bat_w + 3.2)/2, -bat_l/2 - 4.0, -1.0])
                cube([bat_w + 3.2, bat_l + 8.0, 2.42]);
        }
        // 4B. Under-FC Wire Channel (between twin beams) & Outboard Bottom-JST Header Relief Pockets (Z = 1.40..3.0mm)
        // Keeps the flanking twin-beam diagonal rails (|Y_45| = 1.6..3.8mm) at their full 2.40mm structural thickness!
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang]) {
                translate([8.0, -1.6, 1.40])
                    cube([6.8, 3.2, 1.6]);
                for (side_s = [-1, 1]) {
                    hull() {
                        translate([10.4, side_s * 4.5, 1.40]) cylinder(d = 2.0, h = 1.6);
                        translate([13.4, side_s * 5.2, 1.40]) cylinder(d = 2.4, h = 1.6);
                    }
                }
            }
        }

        // Stage 5: Localized Outer Duct Inward FC-Edge & Top-Wire Clearance Flats (r = 13.0..15.1mm on 4 diagonals, Z = 2.40..8.5mm)
        // Flush with Z = 2.40mm arm top (eliminates 0.05mm step) and leaves 32.6mm inner duct bores 100% intact
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang])
                translate([13.0, -2.6, 2.40])
                    cube([2.1, 5.2, 6.0]);
        }

        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 2.4])
                difference() {
                    cylinder(d = duct_id, h = duct_h + 2.0);
                    if (!is_brushless) {
                        translate([0, 0, -0.5]) cylinder(d = brushed_od, h = duct_h + 3.0);
                    }
                }
        }

        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_post_r, 0, -1.0])
                    cylinder(d = 1.75, h = 10.0);
        }
    }
}

module grizzly_ring65_frame(is_brushless = false) {
    minicub65_frame(is_brushless);
}

// ============================================================================
// 3. OSITO "CUBCAP" FACETED BEAR-EAR CANOPY (Proprietary Osito Silhouette)
// ============================================================================
module canopy_cubcap_fpv() {
    difference() {
        union() {
            // Faceted Stealth Shell + Osito Bear-Ear Impact Roll Bars
            difference() {
                hull() {
                    rotate([0, 0, 22.5]) cylinder(d = 26.5, h = 1.6, $fn = 8);
                    translate([0, 1.5, 8.8]) rotate([0, 0, 22.5]) cylinder(d1 = 18.0, d2 = 12.8, h = 3.5, $fn = 8);
                    // Shared camera tilt pivot [0, 8.0, 6.2] sized for 14x14mm micro / 10x10mm nano cameras
                    translate([0, 8.0, 6.2]) rotate([-CAM_TILT_DEG, 0, 0]) cylinder(d = 17.6, h = 4.2, $fn = 8);
                    // Signature Osito Bear-Ear Side Impact Lobes
                    for (sx = [-1, 1]) {
                        translate([sx * 7.4, -1.0, 11.2])
                            rotate([15, sx * 20, 0])
                                cylinder(d = 5.8, h = 2.4, $fn = 16);
                    }
                }
                hull() {
                    translate([0, 0, -0.5]) rotate([0, 0, 22.5]) cylinder(d = 23.3, h = 2.0, $fn = 8);
                    translate([0, 1.5, 8.2]) rotate([0, 0, 22.5]) cylinder(d1 = 14.8, d2 = 10.0, h = 2.8, $fn = 8);
                    // Coaxial inner cavity around shared pivot [0, 8.0, 6.2]
                    translate([0, 8.0, 6.2]) rotate([-CAM_TILT_DEG, 0, 0]) translate([0, 0, -0.4]) cylinder(d = 14.4, h = 4.8, $fn = 8);
                }
            }

            // 4x Diamond Mounting Tabs at 25.5x25.5mm
            for (ang = [0, 90, 180, 270]) {
                rotate([0, 0, ang])
                    hull() {
                        translate([fc_post_r, 0, 0]) cylinder(d = 5.4, h = 1.8);
                        translate([11.0, 0, 0]) cylinder(d = 4.2, h = 1.8);
                    }
            }

            // Rear-Left 5.8GHz Whip Dipole Guard Tube
            translate([-5.0, -9.5, 4.0])
                rotate([25, 0, 0])
                    cylinder(d = 4.2, h = 9.5);
        }

        // Coaxial Micro FPV Camera Lens Bore around shared pivot [0, 8.0, 6.2] + 15/25/35 deg Indexed Detents
        translate([0, 8.0, 6.2])
            rotate([-CAM_TILT_DEG, 0, 0])
                translate([0, 0, -2.0])
                    cylinder(d = 10.8, h = 10.0);
        for (tilt_idx = [15, 25, 35]) {
            for (sx = [-1, 1]) {
                translate([sx * 7.2, 8.0, 6.2])
                    rotate([-tilt_idx, 0, 0])
                        cube([1.8, 4.5, 1.0], center = true);
            }
        }

        // Top & Side VTX Heat-Extraction Louvers + Top-Rear VTX Chimney
        for (zp = [3.5, 6.0, 8.5]) {
            translate([-15.0, -3.5, zp]) cube([30.0, 2.0, 1.3]);
        }
        translate([-4.0, -5.5, 8.2]) cube([8.0, 6.0, 4.5]);

        // Rear-Right 45-Deg USB-C Access Arch (Matches CW45 Diamond FC Mount)
        rotate([0, 0, -45])
            translate([-6.25, -15.0, -0.5])
                cube([12.5, 6.5, 5.2]);

        // Coaxial Whip Antenna Through-Bore (shares exact origin & rotation of guard tube)
        translate([-5.0, -9.5, 4.0])
            rotate([25, 0, 0])
                translate([0, 0, -1.5])
                    cylinder(d = 2.0, h = 13.0);

        // 4x M2 Mounting Holes
        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang])
                translate([fc_post_r, 0, -1.0])
                    cylinder(d = 2.2, h = 5.0);
        }
    }
}

module cubcap_canopy() {
    canopy_cubcap_fpv();
}

// ============================================================================
// MASTER ASSEMBLY / PART SELECTOR
// ============================================================================
if (PART_ID == 1 || PART_SELECT == "FRAME_BRUSHED") {
    minicub65_frame(is_brushless = false);
} else if (PART_ID == 2 || PART_SELECT == "FRAME_BRUSHLESS") {
    minicub65_frame(is_brushless = true);
} else if (PART_ID == 3 || PART_SELECT == "CANOPY_CUBCAP") {
    canopy_cubcap_fpv();
} else if (PART_ID == 4 || PART_SELECT == "FC_CUBBRAIN") {
    fc_cubbrain_mockup();
} else {
    color("#1B1B1B") minicub65_frame(is_brushless = false);
    translate([0, 0, 5.5]) rotate([0, 0, -45]) color("#232A68") fc_cubbrain_mockup();
    translate([0, 0, 9.1]) color("#7077CF") canopy_cubcap_fpv();
}
