#!/usr/bin/env python3
r"""
Osito Drone LLC — MiniCub65 BNF Real-Time Automatic Bambu Studio (.3mf) File Watcher Daemon
===========================================================================================
Runs silently in the background and watches:
  - `cad/OSITO_MINICUB65_Parametric_Master.scad`
  - `cad/OSITO_MINICUB65_GrizzlyRing65_Frame_Brushed0615.stl`
  - `cad/OSITO_MINICUB65_GrizzlyRing65_Frame_Brushless0702.stl`
  - `cad/OSITO_MINICUB65_CubCap_BearEar_Canopy.stl`
  - `cad/OSITO_MINICUB65_CubBrain65_AIO_Mockup.stl`

Behavior:
  1. When `OSITO_MINICUB65_Parametric_Master.scad` is modified/saved:
     -> Automatically runs full OpenSCAD compilation + Z=0.000mm normalization + rebuilds
        all 5 Bambu Studio (.3mf) project files (`00` through `04`).
  2. When any `.stl` file in `cad/` is modified/replaced directly:
     -> Automatically runs fast `--skip-openscad` Z=0.000mm normalization + rebuilds
        all 5 Bambu Studio (.3mf) project files in < 2 seconds.
  3. Snapshot hashes are updated immediately after each sync so self-writes never loop.
"""

import os
import sys
import time
import hashlib
import subprocess
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
HW_DIR = os.path.dirname(SCRIPT_DIR)
CAD_DIR = os.path.join(HW_DIR, "cad")
SYNC_SCRIPT = os.path.join(SCRIPT_DIR, "sync_minicub65_bambu_3mf.py")
LOG_FILE = os.path.join(SCRIPT_DIR, "auto_sync.log")
PID_FILE = os.path.join(SCRIPT_DIR, "auto_sync_watcher.pid")

SCAD_FILE = os.path.join(CAD_DIR, "OSITO_MINICUB65_Parametric_Master.scad")
STL_FILES = [
    os.path.join(CAD_DIR, "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushed0615.stl"),
    os.path.join(CAD_DIR, "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushless0702.stl"),
    os.path.join(CAD_DIR, "OSITO_MINICUB65_CubCap_BearEar_Canopy.stl"),
    os.path.join(CAD_DIR, "OSITO_MINICUB65_CubBrain65_AIO_Mockup.stl"),
]


def log(msg: str):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except OSError:
        pass


def file_sha256(path: str) -> str:
    if not os.path.exists(path):
        return ""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(65536):
                h.update(chunk)
        return h.hexdigest()
    except OSError:
        return ""


def snapshot_hashes():
    scad_hash = file_sha256(SCAD_FILE)
    stl_hashes = {p: file_sha256(p) for p in STL_FILES}
    return scad_hash, stl_hashes


def run_sync(skip_openscad: bool, reason: str):
    mode_label = "FAST STL -> .3MF SYNC (--skip-openscad)" if skip_openscad else "FULL OPENSCAD -> STL -> .3MF REBUILD"
    log(f"Change detected ({reason}) -> Starting {mode_label}...")
    cmd = [sys.executable, SYNC_SCRIPT]
    if skip_openscad:
        cmd.append("--skip-openscad")
    t0 = time.time()
    res = subprocess.run(cmd, capture_output=True, text=True)
    dt = time.time() - t0
    if res.returncode == 0:
        log(f"SUCCESS ({dt:.1f}s): All 5 Bambu Studio (.3mf) projects & normalized STLs updated.")
    else:
        log(f"ERROR (exit {res.returncode}): {res.stderr.strip() or res.stdout.strip()}")


def main():
    poll_interval = 1.5
    with open(PID_FILE, "w", encoding="utf-8") as f:
        f.write(str(os.getpid()))

    scad_hash, stl_hashes = snapshot_hashes()
    log(f"Osito MiniCub65 Bambu Studio Auto-Sync Watcher ACTIVE (PID {os.getpid()}). Watching CAD directory: {CAD_DIR}")

    try:
        while True:
            time.sleep(poll_interval)
            new_scad_hash, new_stl_hashes = snapshot_hashes()

            if new_scad_hash and new_scad_hash != scad_hash:
                # Wait briefly in case editor is still flushing file write
                time.sleep(0.4)
                run_sync(skip_openscad=False, reason="OSITO_MINICUB65_Parametric_Master.scad modified")
                scad_hash, stl_hashes = snapshot_hashes()
                continue

            changed_stls = [
                os.path.basename(p)
                for p in STL_FILES
                if new_stl_hashes.get(p) and new_stl_hashes.get(p) != stl_hashes.get(p)
            ]
            if changed_stls:
                time.sleep(0.4)
                run_sync(skip_openscad=True, reason=f"STL modified ({', '.join(changed_stls)})")
                scad_hash, stl_hashes = snapshot_hashes()

    except KeyboardInterrupt:
        log("Auto-Sync Watcher stopped by user.")


if __name__ == "__main__":
    main()
