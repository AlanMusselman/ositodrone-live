#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
Osito Drone LLC — True-Geometry 3D Perspective STL-on-Bambu-Lab-P2S-Bed Renderer
================================================================================
Pure Python + Pillow (2x Supersampled Anti-Aliased 3D Perspective Engine)
Loads the 4 actual compiled Binary `.stl` meshes from `bambu_studio_project/stls/`
(27,566 total triangles) and renders:
  1. `OSITO_MINICUB65_All_4_STLs_on_P2S_Bed_3D_Render.png`:
     - Left panel: Full 256x256mm Bambu Lab P2S Textured PEI Build Plate in 3D
       perspective with all 4 STL meshes at their exact `.3mf` coordinates
       ((78,178), (178,178), (78,78), (178,78)), cast drop shadows, textured PEI
       speckle grain, 16mm coordinate grid, front tab notch, and L-shaped purge line.
     - Right 2x2 grid: High-resolution zoomed-in 3D perspective renders of each
       individual STL sitting on its section of the P2S Textured PEI bed.
  2. 4 standalone high-res 3D renders of each individual STL on the P2S bed:
     - `STL_1_GrizzlyRing65_Brushed0615_on_P2S_Bed.png`
     - `STL_2_GrizzlyRing65_Brushless0702_on_P2S_Bed.png`
     - `STL_3_CubCap_BearEar_Canopy_on_P2S_Bed.png`
     - `STL_4_CubBrain65_AIO_Mockup_on_P2S_Bed.png`
"""

import os
import math
import struct
import random
from PIL import Image, ImageDraw, ImageFont

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
STL_DIR = os.path.join(SCRIPT_DIR, "stls")


def load_binary_stl(filepath: str):
    """Loads a Binary STL file and returns normalized triangles: list of ((x0,y0,z0),(x1,y1,z1),(x2,y2,z2)) and bbox."""
    tris = []
    min_x = min_y = min_z = 1e9
    max_x = max_y = max_z = -1e9
    with open(filepath, "rb") as f:
        f.read(80)
        count = struct.unpack("<I", f.read(4))[0]
        for _ in range(count):
            data = struct.unpack("<12fH", f.read(50))
            v0 = (data[3], data[4], data[5])
            v1 = (data[6], data[7], data[8])
            v2 = (data[9], data[10], data[11])
            tris.append((v0, v1, v2))
            for vx, vy, vz in (v0, v1, v2):
                if vx < min_x: min_x = vx
                if vx > max_x: max_x = vx
                if vy < min_y: min_y = vy
                if vy > max_y: max_y = vy
                if vz < min_z: min_z = vz
                if vz > max_z: max_z = vz

    cx = 0.5 * (min_x + max_x)
    cy = 0.5 * (min_y + max_y)
    norm_tris = []
    for (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) in tris:
        norm_tris.append((
            (x0 - cx, y0 - cy, z0 - min_z),
            (x1 - cx, y1 - cy, z1 - min_z),
            (x2 - cx, y2 - cy, z2 - min_z),
        ))
    bbox = (max_x - min_x, max_y - min_y, max_z - min_z)
    return norm_tris, bbox


class Camera3D:
    """3D Perspective Camera looking at target (tx, ty, tz) from spherical angles (azim_deg, elev_deg, distance)."""
    def __init__(self, target, azim_deg, elev_deg, dist, fov_scale, vp_rect):
        self.tx, self.ty, self.tz = target
        az = math.radians(azim_deg)
        el = math.radians(elev_deg)
        # Camera position in world coordinates (X right/back, Y back, Z up)
        self.cx = self.tx + dist * math.cos(el) * math.sin(az)
        self.cy = self.ty - dist * math.cos(el) * math.cos(az)
        self.cz = self.tz + dist * math.sin(el)

        # Forward vector (from camera to target)
        fx = self.tx - self.cx
        fy = self.ty - self.cy
        fz = self.tz - self.cz
        fl = math.sqrt(fx*fx + fy*fy + fz*fz)
        self.fx, self.fy, self.fz = fx/fl, fy/fl, fz/fl

        # Right vector = normalize(cross(forward, world_up=(0,0,1)))
        rx = self.fy * 1.0 - self.fz * 0.0
        ry = self.fz * 0.0 - self.fx * 1.0
        rz = 0.0
        rl = math.sqrt(rx*rx + ry*ry + rz*rz)
        self.rx, self.ry, self.rz = rx/rl, ry/rl, rz/rl

        # True Up vector = cross(right, forward)
        self.ux = self.ry * self.fz - self.rz * self.fy
        self.uy = self.rz * self.fx - self.rx * self.fz
        self.uz = self.rx * self.fy - self.ry * self.fx

        self.fov_scale = fov_scale
        self.vx0, self.vy0, self.vw, self.vh = vp_rect
        self.vcx = self.vx0 + 0.5 * self.vw
        self.vcy = self.vy0 + 0.52 * self.vh

    def project(self, x, y, z):
        dx = x - self.cx
        dy = y - self.cy
        dz = z - self.cz
        depth = dx * self.fx + dy * self.fy + dz * self.fz
        if depth < 1.0:
            depth = 1.0
        px = dx * self.rx + dy * self.ry + dz * self.rz
        py = dx * self.ux + dy * self.uy + dz * self.uz
        s = self.fov_scale / depth
        sx = self.vcx + px * s
        sy = self.vcy - py * s
        return sx, sy, depth


def shade_triangle(v0, v1, v2, base_rgb, z_max, spec_strength=0.42, shininess=22.0):
    """Computes Blinn-Phong shaded RGB tuple (0..255) for a 3D triangle."""
    ux, uy, uz = v1[0] - v0[0], v1[1] - v0[1], v1[2] - v0[2]
    vx, vy, vz = v2[0] - v0[0], v2[1] - v0[1], v2[2] - v0[2]
    nx = uy * vz - uz * vy
    ny = uz * vx - ux * vz
    nz = ux * vy - uy * vx
    nl = math.sqrt(nx*nx + ny*ny + nz*nz)
    if nl < 1e-9:
        return (int(base_rgb[0]*120), int(base_rgb[1]*120), int(base_rgb[2]*120))
    nx, ny, nz = nx/nl, ny/nl, nz/nl

    # Key light from front-left-top (-0.42, -0.58, 0.70)
    lkx, lky, lkz = -0.42, -0.58, 0.70
    # Fill light from right-top (0.62, -0.25, 0.74)
    lfx, lfy, lfz = 0.62, -0.25, 0.74
    # Rim/back light (0.15, 0.78, 0.60)
    lrx, lry, lrz = 0.15, 0.78, 0.60
    # Halfway vector for key light + view (-0.28, -0.68, 0.68)
    hkx, hky, hkz = -0.35, -0.63, 0.69

    diff_k = max(0.0, nx*lkx + ny*lky + nz*lkz)
    diff_f = max(0.0, nx*lfx + ny*lfy + nz*lfz)
    diff_r = max(0.0, nx*lrx + ny*lry + nz*lrz)
    spec = math.pow(max(0.0, nx*hkx + ny*hky + nz*hkz), shininess)

    avg_z = (v0[2] + v1[2] + v2[2]) / 3.0
    ao = 0.76 + 0.24 * min(1.0, max(0.0, avg_z / max(z_max, 1.0)))

    intensity = (0.28 + 0.56 * diff_k + 0.24 * diff_f + 0.14 * diff_r) * ao
    r = min(1.0, base_rgb[0] * intensity + spec_strength * spec * 0.92)
    g = min(1.0, base_rgb[1] * intensity + spec_strength * spec * 0.95)
    b = min(1.0, base_rgb[2] * intensity + spec_strength * spec * 1.00)
    return (int(r * 255), int(g * 255), int(b * 255))


def draw_bed_and_meshes(
    draw: ImageDraw.ImageDraw,
    cam: Camera3D,
    bed_bounds: tuple,
    mesh_instances: list,
    full_bed_decorations: bool = True,
):
    """Draws the Bambu Lab P2S Textured PEI bed surface, grid, purge line, cast shadows, and depth-sorted 3D STL meshes."""
    x0, x1, y0, y1 = bed_bounds

    # 1. Outer PEI plate base with chamfered corners
    c = 8.0 if full_bed_decorations else 3.0
    plate_pts_3d = [
        (x0 + c, y0, -0.4), (x1 - c, y0, -0.4), (x1, y0 + c, -0.4),
        (x1, y1 - c, -0.4), (x1 - c, y1, -0.4), (x0 + c, y1, -0.4),
        (x0, y1 - c, -0.4), (x0, y0 + c, -0.4),
    ]
    plate_2d = [(cam.project(px, py, pz)[0], cam.project(px, py, pz)[1]) for px, py, pz in plate_pts_3d]
    draw.polygon(plate_2d, fill=(32, 34, 40), outline=(206, 160, 62), width=3)

    # Front Bambu PEI grip tab
    if full_bed_decorations:
        tab_3d = [(96, y0 - 11, -0.4), (160, y0 - 11, -0.4), (168, y0, -0.4), (88, y0, -0.4)]
        tab_2d = [(cam.project(px, py, pz)[0], cam.project(px, py, pz)[1]) for px, py, pz in tab_3d]
        draw.polygon(tab_2d, fill=(36, 38, 45), outline=(206, 160, 62), width=3)

        # Back alignment notch
        notch_3d = [(114, y1, -0.3), (142, y1, -0.3), (140, y1 - 5, -0.3), (116, y1 - 5, -0.3)]
        notch_2d = [(cam.project(px, py, pz)[0], cam.project(px, py, pz)[1]) for px, py, pz in notch_3d]
        draw.polygon(notch_2d, fill=(22, 24, 28), outline=(206, 160, 62), width=2)

    # 2. Textured PEI speckle grain (deterministic seed)
    rng = random.Random(42)
    num_speckles = 1800 if full_bed_decorations else 650
    for _ in range(num_speckles):
        sx_w = rng.uniform(x0 + 4, x1 - 4)
        sy_w = rng.uniform(y0 + 4, y1 - 4)
        px, py, _ = cam.project(sx_w, sy_w, -0.1)
        col = (54, 52, 46) if rng.random() > 0.35 else (76, 68, 50)
        draw.rectangle([px, py, px + 2, py + 2], fill=col)

    # 3. Bambu Studio PEI coordinate grid lines
    step = 16 if full_bed_decorations else 10
    gx_start = int(math.ceil((x0 + 4) / step) * step)
    gy_start = int(math.ceil((y0 + 4) / step) * step)
    for gx in range(gx_start, int(x1 - 3), step):
        p_a = cam.project(gx, y0 + 4, -0.05)
        p_b = cam.project(gx, y1 - 4, -0.05)
        is_major = (gx % 64 == 0)
        draw.line([(p_a[0], p_a[1]), (p_b[0], p_b[1])], fill=(78, 82, 94) if is_major else (50, 54, 64), width=2 if is_major else 1)

    for gy in range(gy_start, int(y1 - 3), step):
        p_a = cam.project(x0 + 4, gy, -0.05)
        p_b = cam.project(x1 - 4, gy, -0.05)
        is_major = (gy % 64 == 0)
        draw.line([(p_a[0], p_a[1]), (p_b[0], p_b[1])], fill=(78, 82, 94) if is_major else (50, 54, 64), width=2 if is_major else 1)

    # 4. Front nozzle prime / calibration lines on full bed
    if full_bed_decorations:
        purge_a = [cam.project(12, 32, 0.1)[:2], cam.project(12, 6, 0.1)[:2], cam.project(92, 6, 0.1)[:2]]
        draw.line(purge_a, fill=(16, 185, 129), width=5)
        purge_b = [cam.project(164, 6, 0.1)[:2], cam.project(244, 6, 0.1)[:2], cam.project(244, 24, 0.1)[:2]]
        draw.line(purge_b, fill=(112, 119, 207), width=5)

    # 5. Cast drop shadows onto Z = 0.000 mm bed surface (shifted +2.0mm X, +2.2mm Y away from key light)
    for inst in mesh_instances:
        ox, oy = inst["pos"]
        tris = inst["tris"]
        # Draw shadow using every 2nd triangle projected onto Z = 0.0
        for i in range(0, len(tris), 2):
            v0, v1, v2 = tris[i]
            s0 = cam.project(v0[0] + ox + 2.0, v0[1] + oy + 2.2, 0.0)
            s1 = cam.project(v1[0] + ox + 2.0, v1[1] + oy + 2.2, 0.0)
            s2 = cam.project(v2[0] + ox + 2.0, v2[1] + oy + 2.2, 0.0)
            draw.polygon([(s0[0], s0[1]), (s1[0], s1[1]), (s2[0], s2[1])], fill=(16, 17, 21))

    # 6. Collect all 3D triangles across all instances, subdivide long triangles for accurate depth sorting, and shade
    def subdivide_tri(a, b, c, max_len_sq=10.24, depth=0):
        if depth >= 3:
            return [(a, b, c)]
        dab = (a[0]-b[0])**2 + (a[1]-b[1])**2 + (a[2]-b[2])**2
        dbc = (b[0]-c[0])**2 + (b[1]-c[1])**2 + (b[2]-c[2])**2
        dca = (c[0]-a[0])**2 + (c[1]-a[1])**2 + (c[2]-a[2])**2
        m_sq = max(dab, dbc, dca)
        if m_sq <= max_len_sq:
            return [(a, b, c)]
        if dab >= dbc and dab >= dca:
            mid = ((a[0]+b[0])*0.5, (a[1]+b[1])*0.5, (a[2]+b[2])*0.5)
            return subdivide_tri(a, mid, c, max_len_sq, depth+1) + subdivide_tri(mid, b, c, max_len_sq, depth+1)
        elif dbc >= dab and dbc >= dca:
            mid = ((b[0]+c[0])*0.5, (b[1]+c[1])*0.5, (b[2]+c[2])*0.5)
            return subdivide_tri(a, b, mid, max_len_sq, depth+1) + subdivide_tri(a, mid, c, max_len_sq, depth+1)
        else:
            mid = ((c[0]+a[0])*0.5, (c[1]+a[1])*0.5, (c[2]+a[2])*0.5)
            return subdivide_tri(a, b, mid, max_len_sq, depth+1) + subdivide_tri(mid, b, c, max_len_sq, depth+1)

    render_queue = []
    for inst in mesh_instances:
        ox, oy = inst["pos"]
        tris = inst["tris"]
        base_rgb = inst["rgb"]
        z_max = inst["bbox"][2]
        spec_s = inst.get("spec", 0.42)
        shiny = inst.get("shininess", 22.0)

        for v0, v1, v2 in tris:
            w0 = (v0[0] + ox, v0[1] + oy, v0[2])
            w1 = (v1[0] + ox, v1[1] + oy, v1[2])
            w2 = (v2[0] + ox, v2[1] + oy, v2[2])
            col = shade_triangle(w0, w1, w2, base_rgb, z_max, spec_strength=spec_s, shininess=shiny)
            for s0, s1, s2 in subdivide_tri(w0, w1, w2):
                p0 = cam.project(*s0)
                p1 = cam.project(*s1)
                p2 = cam.project(*s2)
                avg_depth = (p0[2] + p1[2] + p2[2]) * 0.333333
                render_queue.append((avg_depth, [(p0[0], p0[1]), (p1[0], p1[1]), (p2[0], p2[1])], col))

    # Painter's algorithm: sort back-to-front (largest depth first)
    render_queue.sort(key=lambda item: item[0], reverse=True)

    for _, poly_2d, col in render_queue:
        draw.polygon(poly_2d, fill=col)


def load_fonts(scale=1):
    try:
        f_title = ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf", 28 * scale)
        f_sub = ImageFont.truetype("C:/Windows/Fonts/segoeui.ttf", 16 * scale)
        f_card = ImageFont.truetype("C:/Windows/Fonts/segoeuib.ttf", 18 * scale)
        f_body = ImageFont.truetype("C:/Windows/Fonts/consolab.ttf", 14 * scale)
        f_small = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 13 * scale)
    except OSError:
        f_title = f_sub = f_card = f_body = f_small = ImageFont.load_default()
    return f_title, f_sub, f_card, f_body, f_small


def render_individual_stl_image(p: dict, out_path: str):
    """Renders a 2x supersampled (1600x1200 final) 3D showcase of a single STL on the Bambu Lab P2S bed."""
    S = 2
    W, H = 1600 * S, 1200 * S
    img = Image.new("RGB", (W, H), (18, 19, 24))
    draw = ImageDraw.Draw(img)
    f_title, f_sub, f_card, f_body, f_small = load_fonts(S)

    # Top banner
    draw.rectangle([0, 0, W, 118 * S], fill=(28, 34, 82))
    draw.rectangle([0, 114 * S, W, 118 * S], fill=(112, 119, 207))
    draw.text((28 * S, 16 * S), f"OSITO MINICUB-65 BNF — {p['title']}", fill=(255, 255, 255), font=f_title)
    bx, by, bz = p["bbox"]
    draw.text(
        (28 * S, 56 * S),
        f"STL File: {p['stl']}   •   Watertight 2-Manifold ({len(p['tris']):,} Triangles)   •   Dimensions: {bx:.2f} × {by:.2f} × {bz:.2f} mm (Z_min = 0.000 mm)",
        fill=(202, 208, 246),
        font=f_sub,
    )
    draw.text(
        (28 * S, 84 * S),
        f"Bambu Lab P2S Assignment: {p['slot']}   •   Filament: {p['filament']}   •   Plate Pos: ({p['pos'][0]:.0f}, {p['pos'][1]:.0f}) mm",
        fill=(84, 232, 168),
        font=f_body,
    )

    # 3D Viewport
    cx, cy = p["pos"]
    span = max(bx, by)
    half = max(span * 0.68, 28.0)
    dist = span * 2.15
    fov_scale = 1750.0 * S

    cam = Camera3D(
        target=(cx, cy, bz * 0.35),
        azim_deg=p.get("azim", -38.0),
        elev_deg=p.get("elev", 34.0),
        dist=dist,
        fov_scale=fov_scale,
        vp_rect=(40 * S, 130 * S, W - 80 * S, H - 220 * S),
    )

    draw_bed_and_meshes(
        draw,
        cam,
        bed_bounds=(cx - half, cx + half, cy - half, cy + half),
        mesh_instances=[p],
        full_bed_decorations=False,
    )

    # Bottom Engineering Spec Bar
    draw.rectangle([24 * S, H - 74 * S, W - 24 * S, H - 18 * S], fill=(26, 28, 36), outline=(112, 119, 207), width=2 * S)
    draw.text((40 * S, H - 64 * S), f"STL Geometry & Slicer Verification: {p['highlights']}", fill=(235, 238, 250), font=f_sub)
    draw.text(
        (40 * S, H - 40 * S),
        "Bambu Studio Settings: 0.4mm Hardened Steel Nozzle  |  0.16mm Optimal Layer Height  |  3 Wall Loops  |  25% Gyroid Infill  |  Build-Plate Tree Support (bridge_no_support=1)",
        fill=(160, 170, 210),
        font=f_small,
    )

    final_img = img.resize((1600, 1200), Image.Resampling.LANCZOS)
    final_img.save(out_path, quality=95)
    print(f"  [OK] Rendered {os.path.basename(out_path)} (1600x1200, {len(p['tris']):,} triangles)")


def main():
    print("Loading 4 compiled Binary STL files and rendering 3D perspective views on Bambu Lab P2S bed...")
    parts = [
        {
            "key": "brushed",
            "title": "STL #1: GRIZZLY-RING 65 AIRFRAME (0615 BRUSHED TRIM)",
            "short_title": "1. GrizzlyRing65_Frame_Brushed0615.stl",
            "stl": "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushed0615.stl",
            "pos": (78.0, 178.0),
            "rgb": (0.34, 0.38, 0.45),
            "spec": 0.48,
            "shininess": 24.0,
            "slot": "P2S #1 AMS Slot 1 (Extruder 1)",
            "filament": "Bambu PETG-CF (265°C / 70°C PEI • 4.1g • $0.28)",
            "highlights": "Full-height inward 0615 C-clamp slot (unbroken Spoke 1 roof) • 45°-crowned wire trough • Unobstructed 3.30×6.50mm JST pass-through windows",
            "out_png": "STL_1_GrizzlyRing65_Brushed0615_on_P2S_Bed.png",
            "azim": -36.0,
            "elev": 36.0,
        },
        {
            "key": "brushless",
            "title": "STL #2: GRIZZLY-RING 65 AIRFRAME (0702SE BRUSHLESS TRIM)",
            "short_title": "2. GrizzlyRing65_Frame_Brushless0702.stl",
            "stl": "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushless0702.stl",
            "pos": (178.0, 178.0),
            "rgb": (0.38, 0.43, 0.52),
            "spec": 0.50,
            "shininess": 26.0,
            "slot": "P2S #1 AMS Slot 1 (Extruder 1)",
            "filament": "Bambu PETG-CF (265°C / 70°C PEI • 3.8g • $0.28)",
            "highlights": "Inward-aligned 60°/180°/300° Ø6.6mm BCD • Continuous 0702 wire bevel + 4.0×3.8mm side gate • Unobstructed 3.30×6.50mm 3-pin JST pass-through",
            "out_png": "STL_2_GrizzlyRing65_Brushless0702_on_P2S_Bed.png",
            "azim": -36.0,
            "elev": 36.0,
        },
        {
            "key": "canopy",
            "title": "STL #3: OSITO CUBCAP BEAR-EAR MICRO-FPV CANOPY",
            "short_title": "3. CubCap_BearEar_Canopy.stl",
            "stl": "OSITO_MINICUB65_CubCap_BearEar_Canopy.stl",
            "pos": (78.0, 78.0),
            "rgb": (0.46, 0.50, 0.86),
            "spec": 0.55,
            "shininess": 30.0,
            "slot": "P2S #1 AMS Slot 4 (TPU 68D) / P2S #2 Ext (TPU 95A HF)",
            "filament": "Bambu TPU for AMS 68D / TPU 95A HF (230°C / 45°C • 1.6g • $0.15)",
            "highlights": "Sculpted Bear-Ear upper impact lobes • Coaxial 15°/25°/35° camera tilt detents • 3 top VTX cooling louvers • Coaxial 5.8GHz whip guard",
            "out_png": "STL_3_CubCap_BearEar_Canopy_on_P2S_Bed.png",
            "azim": -42.0,
            "elev": 30.0,
        },
        {
            "key": "fc",
            "title": "STL #4: CUBBRAIN-65 AIO (REV 2.0) FIT-CHECK MOCKUP",
            "short_title": "4. CubBrain65_AIO_Mockup.stl",
            "stl": "OSITO_MINICUB65_CubBrain65_AIO_Mockup.stl",
            "pos": (178.0, 78.0),
            "rgb": (0.12, 0.72, 0.50),
            "spec": 0.42,
            "shininess": 22.0,
            "slot": "P2S #1 AMS Slot 3 (Extruder 3)",
            "filament": "eSUN PLA+ / Bambu PLA Tough (220°C / 60°C PEI • 2.2g • $0.04)",
            "highlights": "29×29mm diamond PCB outline • 25.5×25.5mm M2 mounting holes • STM32F411, BMI270, SX1280 & AT7456E IC bosses • CPL-synced (±5.2, ±12.2) JST headers",
            "out_png": "STL_4_CubBrain65_AIO_Mockup_on_P2S_Bed.png",
            "azim": -38.0,
            "elev": 34.0,
        },
    ]

    for p in parts:
        tris, bbox = load_binary_stl(os.path.join(STL_DIR, p["stl"]))
        p["tris"] = tris
        p["bbox"] = bbox
        render_individual_stl_image(p, os.path.join(SCRIPT_DIR, p["out_png"]))

    # Render Master Composite Image (2400x1350 final, 2x supersampled from 4800x2700):
    # Left Half: Full 256x256mm Bambu Lab P2S Textured PEI Bed with all 4 STLs in 3D perspective
    # Right Half: 2x2 grid of the 4 individual STL close-up cards
    print("Building Master Composite 3D Showcase: OSITO_MINICUB65_All_4_STLs_on_P2S_Bed_3D_Render.png...")
    S = 2
    MW, MH = 2400 * S, 1350 * S
    master = Image.new("RGB", (MW, MH), (18, 19, 24))
    mdraw = ImageDraw.Draw(master)
    f_title, f_sub, f_card, f_body, f_small = load_fonts(S)

    # Header bar
    mdraw.rectangle([0, 0, MW, 102 * S], fill=(28, 34, 82))
    mdraw.rectangle([0, 98 * S, MW, 102 * S], fill=(112, 119, 207))
    mdraw.text(
        (28 * S, 14 * S),
        "OSITO MINICUB-65 BNF (REV 2.0) — ALL 4 STL MESHES ON BAMBU LAB P2S (256×256mm TEXTURED PEI BED)",
        fill=(255, 255, 255),
        font=f_title,
    )
    total_tris = sum(len(p["tris"]) for p in parts)
    mdraw.text(
        (28 * S, 56 * S),
        f"3D Perspective Shaded Directly from the 4 Watertight 2-Manifold Binary STL Files ({total_tris:,} Triangles)  •  Floor Normalized to Z = 0.000 mm  •  P2S AMS Slots 1, 3 & 4",
        fill=(202, 208, 246),
        font=f_sub,
    )

    # Left panel container (Full 256x256mm P2S Bed)
    lx0, ly0, lw, lh = 22 * S, 118 * S, 1150 * S, 1208 * S
    mdraw.rounded_rectangle([lx0, ly0, lx0 + lw, ly0 + lh], radius=10 * S, fill=(22, 24, 30), outline=(112, 119, 207), width=2 * S)
    mdraw.text((lx0 + 22 * S, ly0 + 16 * S), "00_OSITO_MINICUB65_Master_All_Parts_BambuProject.3mf — FULL 256×256mm P2S BED", fill=(255, 255, 255), font=f_card)
    mdraw.text(
        (lx0 + 22 * S, ly0 + 44 * S),
        "Bambu Lab P2S Combo (Textured PEI Plate) • Total Mass: 11.7 g ($0.65) • Est. Print Time: 52 min",
        fill=(84, 232, 168),
        font=f_body,
    )

    full_cam = Camera3D(
        target=(128.0, 128.0, 6.0),
        azim_deg=-32.0,
        elev_deg=38.0,
        dist=460.0,
        fov_scale=1480.0 * S,
        vp_rect=(lx0 + 16 * S, ly0 + 55 * S, lw - 32 * S, lh - 125 * S),
    )
    draw_bed_and_meshes(mdraw, full_cam, bed_bounds=(0.0, 256.0, 0.0, 256.0), mesh_instances=parts, full_bed_decorations=True)

    # Callout labels on the full bed for each STL
    for p in parts:
        cx, cy = p["pos"]
        bz = p["bbox"][2]
        px, py, _ = full_cam.project(cx, cy, bz + 5.5)
        label_txt = f"{p['short_title']} ({cx:.0f},{cy:.0f})"
        # Pill background
        tw = len(label_txt) * 7.8 * S
        th = 20 * S
        mdraw.rounded_rectangle([px - tw/2 - 6*S, py - th, px + tw/2 + 6*S, py + 4*S], radius=5*S, fill=(20, 22, 30), outline=(112, 119, 207), width=2*S)
        mdraw.text((px - tw/2, py - th + 2*S), label_txt, fill=(255, 255, 255), font=f_small)

    mdraw.text((lx0 + 380 * S, ly0 + lh - 46 * S), "FRONT OF BAMBU LAB P2S TEXTURED PEI BUILD PLATE (256 × 256 mm)", fill=(218, 174, 78), font=f_body)

    # Right 2x2 Grid: Paste the 4 individual high-res STL renders
    rx0, ry0 = 1192 * S, 118 * S
    card_w, card_h = 582 * S, 594 * S
    gap_x, gap_y = 20 * S, 20 * S

    for idx, p in enumerate(parts):
        col_i = idx % 2
        row_i = idx // 2
        cx0 = rx0 + col_i * (card_w + gap_x)
        cy0 = ry0 + row_i * (card_h + gap_y)

        sub_img = Image.open(os.path.join(SCRIPT_DIR, p["out_png"])).resize((card_w, card_h), Image.Resampling.LANCZOS)
        master.paste(sub_img, (cx0, cy0))
        mdraw.rounded_rectangle([cx0, cy0, cx0 + card_w, cy0 + card_h], radius=8 * S, outline=(112, 119, 207), width=2 * S)

    master_final = master.resize((2400, 1350), Image.Resampling.LANCZOS)
    master_path = os.path.join(SCRIPT_DIR, "OSITO_MINICUB65_All_4_STLs_on_P2S_Bed_3D_Render.png")
    master_final.save(master_path, quality=95)
    print(f"  [OK] Saved Master 3D STL-on-P2S-Bed Render: {master_path}")


if __name__ == "__main__":
    main()
