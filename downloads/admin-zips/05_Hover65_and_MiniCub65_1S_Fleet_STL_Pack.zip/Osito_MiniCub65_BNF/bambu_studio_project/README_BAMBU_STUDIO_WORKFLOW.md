# Osito MiniCub65 BNF (`REV 2.0`) — Bambu Studio `.3mf` Project & Auto-Update Guide

![Osito MiniCub65 BNF Bambu Studio Build Plates](./OSITO_MINICUB65_Bambu_Studio_Plates_Preview.png)

## 1. Zero-Click Automatic Rebuild Pipeline (3-Layer Auto-Sync)

All printable `.stl` meshes and all 5 Bambu Studio `.3mf` project files now update **100% automatically** whenever any CAD file changes:

1. **Real-Time Background File Watcher Daemon (`Active Now` — [`watch_and_sync_minicub65_bambu.py`](./watch_and_sync_minicub65_bambu.py))**:
   - Continuously monitors [`../cad/OSITO_MINICUB65_Parametric_Master.scad`](../cad/OSITO_MINICUB65_Parametric_Master.scad) and the 4 `.stl` files in [`../cad/`](../cad/) via SHA-256 content hashes (`1.5s` poll interval, `< 0.1%` CPU).
   - **Save `.scad` $\rightarrow$ Full Auto-Rebuild**: The instant you save `OSITO_MINICUB65_Parametric_Master.scad` in OpenSCAD or your editor, the daemon automatically invokes `openscad.exe`, recompiles all 4 manifold `.stl` files, normalizes their bottom faces to `Z = 0.000 mm`, and regenerates all 5 `.3mf` Bambu Studio projects.
   - **Save/Replace any `.stl` $\rightarrow$ `< 2s` Instant `.3mf` Rebuild**: If any `.stl` in `../cad/` is updated directly without changing the `.scad` file, the daemon automatically runs `--skip-openscad` to normalize `Z = 0.000 mm` and repackage all 5 `.3mf` projects in under 2 seconds.
   - All automatic sync events are logged with timestamps to [`auto_sync.log`](./auto_sync.log).
   - To launch the watcher silently in the background with zero console window after a reboot, double-click [`Start_AutoSync_Watcher_Background.vbs`](./Start_AutoSync_Watcher_Background.vbs).
2. **Git Pre-Commit Auto-Sync Hook (`.git/hooks/pre-commit`)**:
   - Whenever a Git commit includes changes to `OSITO_MINICUB65_Parametric_Master.scad` or `cad/*.stl`, Git automatically runs `sync_minicub65_bambu_3mf.py` and stages the updated `.stl` and `.3mf` files so your repo is never out of sync.
3. **Manual 1-Click Fallback ([`Rebuild_MiniCub65_Bambu_Project.bat`](./Rebuild_MiniCub65_Bambu_Project.bat))**:
   - You can also trigger an on-demand rebuild at any time by double-clicking [`Rebuild_MiniCub65_Bambu_Project.bat`](./Rebuild_MiniCub65_Bambu_Project.bat) or running `python sync_minicub65_bambu_3mf.py`.

---

## 2. Ready-to-Load Bambu Studio `.3mf` Project Files (`2× Bambu Lab P2S Combo`)

| `.3mf` Project File | Objects on `256×256mm` PEI Plate | Printer & AMS Slot (`GEMINI.md` 4-Tier Standard) | Filament & Temps | Total Mass & Cost | Est. Print Time |
| :--- | :--- | :--- | :--- | :---: | :---: |
| **[`00_OSITO_MINICUB65_Master_All_Parts_BambuProject.3mf`](./00_OSITO_MINICUB65_Master_All_Parts_BambuProject.3mf)** | `1×` Brushed Frame + `1×` Brushless Frame + `1×` `CubCap` Canopy + `1×` `CubBrain-65` Mockup | **P2S #1 AMS Slots 1, 3 & 4** | `Bambu PETG-CF` (S1) + `eSUN PLA+` (S3) + `Bambu TPU 68D` (S4) | `11.7 g` (`$0.65`) | `52 min` |
| **[`01_Plate1_Single_Drone_Kit_Frame_and_Canopy.3mf`](./01_Plate1_Single_Drone_Kit_Frame_and_Canopy.3mf)** | `1×` Brushed Frame + `1×` Brushless Frame + `1×` `CubCap` Canopy | **P2S #1 AMS Slot 1 & Slot 4** | `Bambu PETG-CF` (`265°C/70°C`) + `Bambu TPU 68D` (`230°C/45°C`) | `9.5 g` (`$0.58`) | `44 min` |
| **[`02_Plate2_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushed0615.3mf`](./02_Plate2_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushed0615.3mf)** | **`4×` `Grizzly-Ring 65` Brushed (`0615`) Airframes** (`2×2` Grid) | **P2S #1 AMS Slot 1** | **Tier 1 `Bambu PETG-CF`** (`265°C` Nozzle / `70°C` Bed) | `16.4 g` (`$1.12` / `$0.28` ea) | `1h 28m` (`22m`/frame) |
| **[`03_Plate3_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushless0702.3mf`](./03_Plate3_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushless0702.3mf)** | **`4×` `Grizzly-Ring 65` Brushless (`0702SE`) Airframes** (`2×2` Grid) | **P2S #1 AMS Slot 1** | **Tier 1 `Bambu PETG-CF`** (`265°C` Nozzle / `70°C` Bed) | `15.2 g` (`$1.12` / `$0.28` ea) | `1h 22m` (`20.5m`/frame) |
| **[`04_Plate4_P2S_TPU_9x_CubCap_BearEar_Canopy.3mf`](./04_Plate4_P2S_TPU_9x_CubCap_BearEar_Canopy.3mf)** | **`9×` `Osito CubCap` Bear-Ear Canopies** (`3×3` Grid) | **P2S #1 AMS Slot 4** *(or P2S #2 External Dryer Port)* | **Tier 4 `Bambu TPU for AMS 68D`** *(or `Bambu TPU 95A HF` on P2S #2 Ext)* | `14.4 g` (`$1.35` / `$0.15` ea) | `1h 45m` (`11.6m`/canopy) |

> **Shop Safety Reminder (`GEMINI.md` Section 3)**: Never load soft `TPU 95A HF` inside the AMS. Use **`Bambu TPU for AMS (68D)`** in **P2S #1 AMS Slot 4**, or feed **`Bambu TPU 95A HF`** from **P2S #2's External Dryer Port**.
