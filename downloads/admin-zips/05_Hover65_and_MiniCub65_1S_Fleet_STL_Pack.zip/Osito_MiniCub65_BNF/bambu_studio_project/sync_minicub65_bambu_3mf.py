#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
OSITO MINICUB-65 BNF (REV 2.0) — AUTOMATED OPENSCAD -> STL -> BAMBU STUDIO (.3MF) PIPELINE
==========================================================================================
Run this script (or double-click `Rebuild_MiniCub65_Bambu_Project.bat`) any time
`cad/OSITO_MINICUB65_Parametric_Master.scad` is modified.

What it does automatically:
1. Invokes OpenSCAD (`C:\Program Files\OpenSCAD\openscad.exe`) to recompile all 4 manifold
   printable `.stl` files in `cad/` (or reads the existing `.stl` files if `--skip-openscad` is passed).
2. Normalizes each `.stl` mesh so its bottom face sits flush at `Z = 0.000 mm` on the build plate
   and converts the `.stl` files into fast, compact Binary STL format.
3. Packages the exact OpenSCAD triangle meshes into 5 native **Bambu Studio `.3mf` Project Files**
   inside `bambu_studio_project/` with `256 x 256 x 256 mm` Bambu Lab P2S Combo bed coordinates,
   embedded `Metadata/model_settings.config` object names & AMS slot assignments, and
   `Metadata/project_settings.config` print profile settings:
     - `00_OSITO_MINICUB65_Master_All_Parts_BambuProject.3mf` (All 4 parts arranged on 1 plate w/ AMS slots)
     - `01_Plate1_Single_Drone_Kit_Frame_and_Canopy.3mf` (1x Brushed Frame + 1x Brushless Frame + 1x Canopy)
     - `02_Plate2_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushed0615.3mf` (2x2 Batch = 4x Brushed 0615 Frames)
     - `03_Plate3_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushless0702.3mf` (2x2 Batch = 4x Brushless 0702SE Frames)
     - `04_Plate4_P2S_TPU_9x_CubCap_BearEar_Canopy.3mf` (3x3 Batch = 9x CubCap Bear-Ear Canopies)
4. Exports Bambu Studio Filament & Process Preset `.json` profiles into `bambu_studio_project/profiles/`
   and renders a high-resolution visual plate map (`OSITO_MINICUB65_Bambu_Studio_Plates_Preview.png`).
"""

import os
import sys
import math
import json
import struct
import zipfile
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

WORKSPACE = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone")
MINICUB_DIR = WORKSPACE / "03_Hardware_and_Drones" / "Core_Fleet" / "Osito_MiniCub65_BNF"
CAD_DIR = MINICUB_DIR / "cad"
BAMBU_DIR = MINICUB_DIR / "bambu_studio_project"
PROFILES_DIR = BAMBU_DIR / "profiles"
WEB_ASSETS_DIR = WORKSPACE / "02_Web_Apps_and_Tools" / "osito-minicub65-bnf-studio" / "assets"
ARTIFACT_DIR = Path(r"C:\Users\Alan Musselman\.gemini\antigravity\brain\a85d7d25-6ada-42c7-b97e-834622b4d44c")

OPENSCAD_EXE = Path(r"C:\Program Files\OpenSCAD\openscad.exe")
SCAD_MASTER = CAD_DIR / "OSITO_MINICUB65_Parametric_Master.scad"

PARTS_CONFIG = [
    {
        "part_id": 1,
        "key": "frame_brushed",
        "name": "GrizzlyRing65_Frame_Brushed0615",
        "stl_name": "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushed0615.stl",
        "extruder": 1,  # P2S #1 AMS Slot 1: Bambu PETG-CF
        "filament": "Bambu PETG-CF (P2S #1 AMS Slot 1)",
        "color_hex": "#1B1B1B",
        "mass_g": 4.1,
    },
    {
        "part_id": 2,
        "key": "frame_brushless",
        "name": "GrizzlyRing65_Frame_Brushless0702",
        "stl_name": "OSITO_MINICUB65_GrizzlyRing65_Frame_Brushless0702.stl",
        "extruder": 1,  # P2S #1 AMS Slot 1: Bambu PETG-CF
        "filament": "Bambu PETG-CF (P2S #1 AMS Slot 1)",
        "color_hex": "#232A68",
        "mass_g": 3.8,
    },
    {
        "part_id": 3,
        "key": "canopy_cubcap",
        "name": "CubCap_BearEar_Canopy",
        "stl_name": "OSITO_MINICUB65_CubCap_BearEar_Canopy.stl",
        "extruder": 4,  # P2S #1 AMS Slot 4: Bambu TPU 68D (or P2S #2 Ext TPU 95A HF)
        "filament": "Bambu TPU for AMS 68D (Slot 4) / TPU 95A HF (P2S #2 Ext)",
        "color_hex": "#7077CF",
        "mass_g": 1.6,
    },
    {
        "part_id": 4,
        "key": "fc_mockup",
        "name": "CubBrain65_AIO_FitCheck_Mockup",
        "stl_name": "OSITO_MINICUB65_CubBrain65_AIO_Mockup.stl",
        "extruder": 3,  # P2S #1 AMS Slot 3: eSUN PLA+ / Bambu PLA Tough
        "filament": "eSUN PLA+ / Bambu PLA Tough (P2S #1 AMS Slot 3)",
        "color_hex": "#15803D",
        "mass_g": 2.2,
    },
]


def compile_scad_to_stls(force_compile=True):
    """Runs OpenSCAD CLI to regenerate all 4 STL files from OSITO_MINICUB65_Parametric_Master.scad."""
    if not force_compile:
        print("[1/4] Skipping OpenSCAD compilation (--skip-openscad); reading existing STLs...")
        return

    if not OPENSCAD_EXE.exists():
        print(f"[WARN] OpenSCAD not found at {OPENSCAD_EXE}; using existing STLs in {CAD_DIR}")
        return

    print(f"[1/4] Recompiling 4 printable STLs from {SCAD_MASTER.name} via OpenSCAD...")
    for p in PARTS_CONFIG:
        out_stl = CAD_DIR / p["stl_name"]
        tmp_stl = CAD_DIR / f".tmp_{os.getpid()}_{p['stl_name']}"
        cmd = [
            str(OPENSCAD_EXE),
            "-o", str(tmp_stl),
            "-D", f"PART_ID={p['part_id']}",
            str(SCAD_MASTER),
        ]
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0 or not tmp_stl.exists():
            if tmp_stl.exists():
                tmp_stl.unlink(missing_ok=True)
            raise RuntimeError(f"OpenSCAD failed on {p['stl_name']}:\n{res.stderr}")
        os.replace(tmp_stl, out_stl)
        print(f"  [OK] Compiled {p['stl_name']} ({out_stl.stat().st_size / 1024:.1f} KB)")


def parse_stl_triangles(stl_path: Path):
    """Parses either ASCII or Binary STL into a list of ((x0,y0,z0), (x1,y1,z1), (x2,y2,z2)) triangles."""
    data = stl_path.read_bytes()
    if data[:5] == b"solid" and b"facet normal" in data[:512]:
        text = data.decode("utf-8", errors="ignore")
        verts = []
        for line in text.splitlines():
            s = line.strip()
            if s.startswith("vertex "):
                parts = s.split()
                verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
        tris = [(verts[i], verts[i + 1], verts[i + 2]) for i in range(0, len(verts) - 2, 3)]
        return tris
    else:
        tri_count = struct.unpack("<I", data[80:84])[0]
        tris = []
        offset = 84
        for _ in range(tri_count):
            vals = struct.unpack("<12fH", data[offset:offset + 50])
            p0 = (vals[3], vals[4], vals[5])
            p1 = (vals[6], vals[7], vals[8])
            p2 = (vals[9], vals[10], vals[11])
            tris.append((p0, p1, p2))
            offset += 50
        return tris


def normalize_mesh_to_buildplate(tris):
    """Shifts mesh so X/Y are centered at (0,0) and Z_min sits flush at Z = 0.000 mm."""
    xs = [pt[0] for tri in tris for pt in tri]
    ys = [pt[1] for tri in tris for pt in tri]
    zs = [pt[2] for tri in tris for pt in tri]
    cx = 0.5 * (min(xs) + max(xs))
    cy = 0.5 * (min(ys) + max(ys))
    z_min = min(zs)
    norm_tris = []
    for (p0, p1, p2) in tris:
        norm_tris.append((
            (round(p0[0] - cx, 4), round(p0[1] - cy, 4), round(p0[2] - z_min, 4)),
            (round(p1[0] - cx, 4), round(p1[1] - cy, 4), round(p1[2] - z_min, 4)),
            (round(p2[0] - cx, 4), round(p2[1] - cy, 4), round(p2[2] - z_min, 4)),
        ))
    bbox = (max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs))
    return norm_tris, bbox


def write_binary_stl(filepath: Path, tris, header_str="Osito MiniCub65 BNF Printable Mesh"):
    """Writes a compact binary STL with Z_min = 0.000 mm."""
    hdr = header_str.encode("ascii", errors="ignore")[:80].ljust(80, b"\x00")
    with open(filepath, "wb") as f:
        f.write(hdr)
        f.write(struct.pack("<I", len(tris)))
        for (p0, p1, p2) in tris:
            ux, uy, uz = p1[0] - p0[0], p1[1] - p0[1], p1[2] - p0[2]
            vx, vy, vz = p2[0] - p0[0], p2[1] - p0[1], p2[2] - p0[2]
            nx = uy * vz - uz * vy
            ny = uz * vx - ux * vz
            nz = ux * vy - uy * vx
            nl = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
            f.write(struct.pack(
                "<12fH",
                nx / nl, ny / nl, nz / nl,
                p0[0], p0[1], p0[2],
                p1[0], p1[1], p1[2],
                p2[0], p2[1], p2[2],
                0
            ))


def build_bambu_3mf_project(filepath: Path, title: str, instances: list):
    """
    Writes a multi-object Bambu Studio `.3mf` project file with:
      - `3D/3dmodel.model` (separate <object> per instance with exact 256x256mm bed transform)
      - `Metadata/model_settings.config` (Bambu Studio object names & AMS extruder slot bindings)
      - `Metadata/project_settings.config` (Bambu Lab P2S Combo 0.4mm nozzle + 4-Tier Filament profile)
    """
    objects_xml = []
    build_items_xml = []
    model_settings_objs = []

    for idx, inst in enumerate(instances, start=1):
        tris = inst["tris"]
        obj_name = inst["instance_name"]
        extruder_id = inst["extruder"]
        tx, ty, tz = inst["pos"]

        # Deduplicate vertices for compact 3MF XML
        v_map = {}
        verts = []
        idx_tris = []
        for tri in tris:
            t_idx = []
            for pt in tri:
                if pt not in v_map:
                    v_map[pt] = len(verts)
                    verts.append(pt)
                t_idx.append(v_map[pt])
            idx_tris.append(t_idx)

        v_lines = "\n".join(f'          <vertex x="{x:.4f}" y="{y:.4f}" z="{z:.4f}" />' for (x, y, z) in verts)
        t_lines = "\n".join(f'          <triangle v1="{a}" v2="{b}" v3="{c}" />' for (a, b, c) in idx_tris)

        objects_xml.append(f"""    <object id="{idx}" name="{obj_name}" type="model">
      <mesh>
        <vertices>
{v_lines}
        </vertices>
        <triangles>
{t_lines}
        </triangles>
      </mesh>
    </object>""")

        build_items_xml.append(
            f'    <item objectid="{idx}" transform="1 0 0 0 1 0 0 0 1 {tx:.3f} {ty:.3f} {tz:.3f}" printable="1" />'
        )

        model_settings_objs.append(f"""  <object id="{idx}">
    <metadata key="name" value="{obj_name}"/>
    <metadata key="extruder" value="{extruder_id}"/>
    <part id="1" subtype="normal_part">
      <metadata key="name" value="{obj_name}"/>
      <metadata key="matrix" value="1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1"/>
    </part>
  </object>""")

    model_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02" xmlns:BambuStudio="http://schemas.bambulab.com/package/2021">
  <metadata name="Application">BambuStudio-01.09.05.51</metadata>
  <metadata name="Title">{title}</metadata>
  <metadata name="Designer">Osito Drone LLC (Alan Musselman, Miguel Flores, Jesus Aceves)</metadata>
  <metadata name="Description">Osito MiniCub65 BNF (REV 2.0) | 2x Bambu Lab P2S Combo 256x256mm Build Plate</metadata>
  <resources>
{chr(10).join(objects_xml)}
  </resources>
  <build>
{chr(10).join(build_items_xml)}
  </build>
</model>"""

    model_settings_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<config>
{chr(10).join(model_settings_objs)}
  <plate>
    <metadata key="plater_id" value="1"/>
    <metadata key="plater_name" value="{title[:48]}"/>
    <metadata key="locked" value="false"/>
  </plate>
</config>"""

    project_settings = {
        "printer_model": "Bambu Lab P2S",
        "nozzle_diameter": ["0.4"],
        "bed_type": "Textured PEI Plate",
        "layer_height": "0.16",
        "initial_layer_print_height": "0.20",
        "wall_loops": "3",
        "top_shell_layers": "4",
        "bottom_shell_layers": "3",
        "sparse_infill_density": "25%",
        "sparse_infill_pattern": "gyroid",
        "enable_support": "1",
        "support_type": "tree(auto)",
        "support_on_build_plate_only": "1",
        "bridge_no_support": "1",
        "brim_type": "no_brim",
        "filament_settings_id": [
            "Bambu PETG-CF @Bambu P2S 0.4 nozzle (Slot 1)",
            "Bambu PAHT-CF @Bambu P2S 0.4 nozzle (Slot 2)",
            "Bambu PLA Tough @Bambu P2S 0.4 nozzle (Slot 3)",
            "Bambu TPU for AMS 68D @Bambu P2S 0.4 nozzle (Slot 4)"
        ],
        "filament_type": ["PETG-CF", "PA-CF", "PLA", "TPU"],
        "filament_colour": ["#1B1B1B", "#232A68", "#15803D", "#7077CF"],
        "nozzle_temperature": ["265", "290", "220", "230"],
        "textured_plate_temp": ["70", "100", "60", "45"]
    }

    content_types = """<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml" />
  <Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml" />
  <Default Extension="config" ContentType="text/xml" />
</Types>"""

    rels_xml = """<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel" />
</Relationships>"""

    with zipfile.ZipFile(filepath, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", content_types)
        zf.writestr("_rels/.rels", rels_xml)
        zf.writestr("3D/3dmodel.model", model_xml)
        zf.writestr("Metadata/model_settings.config", model_settings_xml)
        zf.writestr("Metadata/project_settings.config", json.dumps(project_settings, indent=2))


def export_bambu_profiles():
    """Writes standalone Bambu Studio preset JSON files into bambu_studio_project/profiles/."""
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)
    petgcf_profile = {
        "type": "process",
        "name": "Osito MiniCub65 — Grizzly-Ring 65 (Bambu PETG-CF 0.16mm Structural)",
        "from": "User",
        "inherits": "0.16mm Optimal @BBL X1C",
        "layer_height": "0.16",
        "initial_layer_print_height": "0.20",
        "wall_loops": "3",
        "top_shell_layers": "4",
        "bottom_shell_layers": "3",
        "sparse_infill_density": "25%",
        "sparse_infill_pattern": "gyroid",
        "nozzle_temperature": ["265"],
        "textured_plate_temp": ["70"],
        "outer_wall_speed": "120",
        "inner_wall_speed": "180",
        "enable_support": "1",
        "support_type": "tree(auto)",
        "support_on_build_plate_only": "1",
        "bridge_no_support": "1",
        "brim_type": "no_brim",
        "notes": "P2S #1 AMS Slot 1 (Bambu PETG-CF). Flush battery cradle base on Textured PEI Plate with build-plate-only tree support under Z=8.2mm outer ducts and bridge_no_support=1 keeping 45-deg crowned wire channels 100% support-free."
    }
    tpu_profile = {
        "type": "process",
        "name": "Osito MiniCub65 — CubCap Bear-Ear Canopy (Bambu TPU 68D / 95A HF 0.16mm)",
        "from": "User",
        "inherits": "0.16mm Optimal @BBL X1C",
        "layer_height": "0.16",
        "initial_layer_print_height": "0.20",
        "wall_loops": "3",
        "top_shell_layers": "4",
        "bottom_shell_layers": "3",
        "sparse_infill_density": "20%",
        "sparse_infill_pattern": "gyroid",
        "nozzle_temperature": ["230"],
        "textured_plate_temp": ["45"],
        "outer_wall_speed": "80",
        "inner_wall_speed": "100",
        "enable_support": "0",
        "brim_type": "no_brim",
        "notes": "Use Bambu TPU for AMS 68D in P2S #1 AMS Slot 4, or feed Bambu TPU 95A HF from P2S #2 External Dryer Port (never put soft 95A TPU inside the AMS)."
    }
    (PROFILES_DIR / "Bambu_PETG_CF_GrizzlyRing65_0.16mm.json").write_text(json.dumps(petgcf_profile, indent=2), encoding="utf-8")
    (PROFILES_DIR / "Bambu_TPU_CubCap_Canopy_0.16mm.json").write_text(json.dumps(tpu_profile, indent=2), encoding="utf-8")


def render_bambu_plates_preview(projects_summary, out_png: Path):
    """Renders a 2400x1350 visual layout guide of all 5 MiniCub65 Bambu Studio .3mf projects."""
    W, H = 2400, 1350
    img = Image.new("RGB", (W, H), (22, 22, 22))
    draw = ImageDraw.Draw(img)

    try:
        f_title = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 36)
        f_sub = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 22)
        f_card = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 20)
        f_body = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 17)
        f_mono = ImageFont.truetype("C:/Windows/Fonts/consola.ttf", 15)
    except Exception:
        f_title = f_sub = f_card = f_body = f_mono = ImageFont.load_default()

    # Top Header
    draw.rectangle([0, 0, W, 125], fill=(35, 42, 104))
    draw.rectangle([0, 120, W, 126], fill=(112, 119, 207))
    draw.text((40, 22), "OSITO MINICUB-65 BNF — BAMBU STUDIO (.3MF) AUTO-SYNC PROJECT SUITE", fill=(255, 255, 255), font=f_title)
    draw.text((40, 74), "2x Bambu Lab P2S Combo (256x256mm Textured PEI) • 1-Click Rebuild via Rebuild_MiniCub65_Bambu_Project.bat", fill=(214, 217, 245), font=f_sub)

    # 5 Plate Cards
    card_w = 440
    card_h = 1140
    for idx, proj in enumerate(projects_summary):
        x0 = 32 + idx * 468
        y0 = 158
        draw.rounded_rectangle([x0, y0, x0 + card_w, y0 + card_h], radius=12, fill=(30, 32, 42), outline=(112, 119, 207), width=3)

        # Draw 256x256 PEI Plate
        bed_sz = 380
        bx0 = x0 + (card_w - bed_sz) // 2
        by0 = y0 + 24
        draw.rounded_rectangle([bx0, by0, bx0 + bed_sz, by0 + bed_sz], radius=14, fill=(40, 42, 50), outline=(215, 175, 65), width=2)
        for g in range(1, 8):
            gx = bx0 + g * (bed_sz // 8)
            gy = by0 + g * (bed_sz // 8)
            draw.line([gx, by0, gx, by0 + bed_sz], fill=(54, 57, 68), width=1)
            draw.line([bx0, gy, bx0 + bed_sz, gy], fill=(54, 57, 68), width=1)
        draw.text((bx0 + 12, by0 + bed_sz - 24), "P2S 256x256mm PEI PLATE", fill=(215, 175, 65), font=f_mono)

        # Plot parts on the 256x256 plate
        for inst in proj["instances"]:
            px_mm, py_mm, _ = inst["pos"]
            cx = bx0 + int((px_mm / 256.0) * bed_sz)
            cy = by0 + bed_sz - int((py_mm / 256.0) * bed_sz)
            key = inst["key"]
            if "frame" in key:
                col = (112, 119, 207) if "brushless" in key else (80, 220, 160)
                r_px = int((40.7 / 256.0) * bed_sz)
                for ang_d in [45, 135, 225, 315]:
                    a = math.radians(ang_d)
                    mx = cx + int(r_px * 0.56 * math.cos(a))
                    my = cy + int(r_px * 0.56 * math.sin(a))
                    dr = int(r_px * 0.43)
                    draw.ellipse([mx - dr, my - dr, mx + dr, my + dr], outline=col, width=3)
                draw.ellipse([cx - 12, cy - 12, cx + 12, cy + 12], outline=col, width=2)
            elif "canopy" in key:
                r_px = int((21.0 / 256.0) * bed_sz)
                draw.ellipse([cx - r_px, cy - r_px, cx + r_px, cy + r_px], fill=(112, 119, 207), outline=(255, 255, 255), width=2)
            else:
                r_px = int((15.0 / 256.0) * bed_sz)
                draw.rectangle([cx - r_px, cy - r_px, cx + r_px, cy + r_px], fill=(21, 128, 61), outline=(255, 255, 255), width=2)

        # Metadata text
        ty = by0 + bed_sz + 24
        draw.text((x0 + 20, ty), proj["short_title"], fill=(255, 255, 255), font=f_card)
        draw.text((x0 + 20, ty + 36), f"File: {proj['filename']}", fill=(160, 185, 255), font=f_mono)
        draw.text((x0 + 20, ty + 70), f"Parts on Plate: {len(proj['instances'])} objects", fill=(80, 255, 165), font=f_body)
        draw.text((x0 + 20, ty + 100), f"AMS / Port: {proj['ams_slot']}", fill=(230, 235, 245), font=f_body)
        draw.text((x0 + 20, ty + 130), f"Filament: {proj['filament']}", fill=(230, 235, 245), font=f_body)
        draw.text((x0 + 20, ty + 160), f"Total Mass & Cost: {proj['mass_cost']}", fill=(80, 255, 165), font=f_body)
        draw.text((x0 + 20, ty + 190), f"Est. Print Time: {proj['print_time']}", fill=(255, 210, 90), font=f_body)

        draw.text((x0 + 20, ty + 235), "Objects Included:", fill=(112, 119, 207), font=f_card)
        for o_idx, inst in enumerate(proj["instances"][:9]):
            draw.text((x0 + 24, ty + 268 + o_idx * 26), f"• {inst['instance_name']} (Ext #{inst['extruder']})", fill=(205, 212, 230), font=f_mono)

    img.save(out_png, "PNG", optimize=True)


def main():
    skip_scad = "--skip-openscad" in sys.argv
    BAMBU_DIR.mkdir(parents=True, exist_ok=True)
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)

    # 1. Recompile OpenSCAD -> STLs
    compile_scad_to_stls(force_compile=not skip_scad)

    # 2. Load & normalize all 4 STL meshes to Z_min = 0.000 mm
    print("[2/4] Normalizing STL meshes to Z = 0.000 mm build-plate floor...")
    meshes = {}
    for p in PARTS_CONFIG:
        stl_path = CAD_DIR / p["stl_name"]
        raw_tris = parse_stl_triangles(stl_path)
        norm_tris, bbox = normalize_mesh_to_buildplate(raw_tris)
        # Overwrite CAD STL with clean, floor-normalized binary STL + copy into bambu_studio_project/stls/
        stls_subdir = BAMBU_DIR / "stls"
        stls_subdir.mkdir(parents=True, exist_ok=True)
        write_binary_stl(stl_path, norm_tris, header_str=f"Osito MiniCub65 {p['name']} (Z0 Normalized)")
        write_binary_stl(stls_subdir / p["stl_name"], norm_tris, header_str=f"Osito MiniCub65 {p['name']} (Z0 Normalized)")
        meshes[p["key"]] = {
            **p,
            "tris": norm_tris,
            "bbox": bbox,
        }
        print(f"  [OK] Normalized {p['stl_name']}: {len(norm_tris)} tris | BBox: {bbox[0]:.2f} x {bbox[1]:.2f} x {bbox[2]:.2f} mm | Z_min=0.00mm")

    # 3. Build the 5 Bambu Studio .3mf Project Files
    print("[3/4] Building 5 Bambu Studio (.3mf) Project Files with AMS Slot & Print Settings...")
    fb = meshes["frame_brushed"]
    fbl = meshes["frame_brushless"]
    cap = meshes["canopy_cubcap"]
    fc = meshes["fc_mockup"]

    projects_spec = [
        {
            "filename": "00_OSITO_MINICUB65_Master_All_Parts_BambuProject.3mf",
            "title": "Osito MiniCub65 BNF — Master All-Parts Bambu Studio Project",
            "short_title": "00. Master All-Parts Project",
            "ams_slot": "P2S #1 AMS Slots 1, 3 & 4",
            "filament": "PETG-CF (S1) + PLA+ (S3) + TPU 68D (S4)",
            "mass_cost": "11.7 g ($0.65 complete engineering set)",
            "print_time": "52 min (By-Object or Multi-Slot)",
            "instances": [
                {"key": "frame_brushed", "instance_name": "GrizzlyRing65_Frame_Brushed0615", "tris": fb["tris"], "extruder": 1, "pos": (76.0, 172.0, 0.0)},
                {"key": "frame_brushless", "instance_name": "GrizzlyRing65_Frame_Brushless0702", "tris": fbl["tris"], "extruder": 1, "pos": (180.0, 172.0, 0.0)},
                {"key": "canopy_cubcap", "instance_name": "CubCap_BearEar_Canopy", "tris": cap["tris"], "extruder": 4, "pos": (88.0, 78.0, 0.0)},
                {"key": "fc_mockup", "instance_name": "CubBrain65_AIO_FitCheck_Mockup", "tris": fc["tris"], "extruder": 3, "pos": (168.0, 78.0, 0.0)},
            ],
        },
        {
            "filename": "01_Plate1_Single_Drone_Kit_Frame_and_Canopy.3mf",
            "title": "Osito MiniCub65 BNF — Single Drone Kit (Brushed + Brushless Frames + Canopy)",
            "short_title": "01. Single-Drone Kit Plate",
            "ams_slot": "P2S #1 AMS Slot 1 & Slot 4",
            "filament": "Bambu PETG-CF + Bambu TPU 68D",
            "mass_cost": "9.5 g ($0.58 total plate filament)",
            "print_time": "44 min (0.16mm Optimal)",
            "instances": [
                {"key": "frame_brushed", "instance_name": "GrizzlyRing65_Frame_Brushed0615", "tris": fb["tris"], "extruder": 1, "pos": (78.0, 165.0, 0.0)},
                {"key": "frame_brushless", "instance_name": "GrizzlyRing65_Frame_Brushless0702", "tris": fbl["tris"], "extruder": 1, "pos": (178.0, 165.0, 0.0)},
                {"key": "canopy_cubcap", "instance_name": "CubCap_BearEar_Canopy", "tris": cap["tris"], "extruder": 4, "pos": (128.0, 78.0, 0.0)},
            ],
        },
        {
            "filename": "02_Plate2_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushed0615.3mf",
            "title": "Osito MiniCub65 BNF — 4x Grizzly-Ring 65 Brushed (0615) Batch Plate",
            "short_title": "02. 4x Brushed 0615 Frames",
            "ams_slot": "P2S #1 AMS Slot 1",
            "filament": "Bambu PETG-CF (265C / 70C PEI)",
            "mass_cost": "16.4 g ($1.12 / $0.28 per frame)",
            "print_time": "1h 28m (22 min/frame)",
            "instances": [
                {"key": "frame_brushed", "instance_name": f"GrizzlyRing65_Brushed0615_#{i+1}", "tris": fb["tris"], "extruder": 1, "pos": (76.0 + (i % 2) * 104.0, 76.0 + (i // 2) * 104.0, 0.0)}
                for i in range(4)
            ],
        },
        {
            "filename": "03_Plate3_P2S1_Slot1_PETGCF_4x_GrizzlyRing65_Brushless0702.3mf",
            "title": "Osito MiniCub65 BNF — 4x Grizzly-Ring 65 Brushless (0702SE) Batch Plate",
            "short_title": "03. 4x Brushless 0702 Frames",
            "ams_slot": "P2S #1 AMS Slot 1",
            "filament": "Bambu PETG-CF (265C / 70C PEI)",
            "mass_cost": "15.2 g ($1.12 / $0.28 per frame)",
            "print_time": "1h 22m (20.5 min/frame)",
            "instances": [
                {"key": "frame_brushless", "instance_name": f"GrizzlyRing65_Brushless0702_#{i+1}", "tris": fbl["tris"], "extruder": 1, "pos": (76.0 + (i % 2) * 104.0, 76.0 + (i // 2) * 104.0, 0.0)}
                for i in range(4)
            ],
        },
        {
            "filename": "04_Plate4_P2S_TPU_9x_CubCap_BearEar_Canopy.3mf",
            "title": "Osito MiniCub65 BNF — 9x Osito CubCap Bear-Ear Canopy Batch Plate",
            "short_title": "04. 9x CubCap TPU Canopies",
            "ams_slot": "P2S #1 Slot 4 (68D) / P2S #2 Ext (95A)",
            "filament": "Bambu TPU 68D or TPU 95A HF (230C/45C)",
            "mass_cost": "14.4 g ($1.35 / $0.15 per canopy)",
            "print_time": "1h 45m (11.6 min/canopy)",
            "instances": [
                {"key": "canopy_cubcap", "instance_name": f"CubCap_BearEar_Canopy_#{i+1}", "tris": cap["tris"], "extruder": 4, "pos": (64.0 + (i % 3) * 64.0, 64.0 + (i // 3) * 64.0, 0.0)}
                for i in range(9)
            ],
        },
    ]

    for proj in projects_spec:
        out_3mf = BAMBU_DIR / proj["filename"]
        build_bambu_3mf_project(out_3mf, proj["title"], proj["instances"])
        print(f"  [OK] Built Bambu Studio Project: {proj['filename']} ({out_3mf.stat().st_size / 1024:.1f} KB, {len(proj['instances'])} objects)")

    # 4. Export Bambu Studio JSON profiles & render preview image
    print("[4/4] Exporting Bambu Studio Process Profiles & Visual Build Plate Map...")
    export_bambu_profiles()
    preview_png = BAMBU_DIR / "OSITO_MINICUB65_Bambu_Studio_Plates_Preview.png"
    render_bambu_plates_preview(projects_spec, preview_png)
    if WEB_ASSETS_DIR.exists():
        (WEB_ASSETS_DIR / "OSITO_MINICUB65_Bambu_Studio_Plates_Preview.png").write_bytes(preview_png.read_bytes())
    if ARTIFACT_DIR.exists():
        (ARTIFACT_DIR / "OSITO_MINICUB65_Bambu_Studio_Plates_Preview.png").write_bytes(preview_png.read_bytes())
    print(f"  [OK] Rendered Build Plate Map: {preview_png}")

    # Also regenerate the 3D perspective STL-on-P2S-bed renders
    try:
        import render_realistic_stl_on_p2s_bed
        render_realistic_stl_on_p2s_bed.main()
    except Exception as exc:
        print(f"  [WARN] 3D STL-on-P2S-Bed render skipped: {exc}")

    print("\n=== ALL MINICUB-65 BAMBU STUDIO (.3MF) PROJECTS UPDATED & READY TO OPEN! ===")


if __name__ == "__main__":
    main()
