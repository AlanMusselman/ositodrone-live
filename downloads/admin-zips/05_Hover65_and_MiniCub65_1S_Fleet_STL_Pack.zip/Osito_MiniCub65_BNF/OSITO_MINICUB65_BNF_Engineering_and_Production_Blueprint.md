# OSITO MINICUB-65 BNF (`REV 2.0`): Flagship 65mm 1S ELRS Hardware Architecture, Avionics, CAD, Firmware & Production Blueprint

**Platform Designation:** `Osito MiniCub65 BNF` (`Trim A: CubCore 0615 Brushed H-Bridge` & `Trim B: CubSpin 0702SE 25,000KV Brushless`)  
**Product Positioning:** Osito Drone LLC Flagship Sub-50g 65mm 1S ELRS Classroom STEM Trainer, Indoor FPV Racer & Arena Micro-Drone  
**Flight Controller Core:** `CubBrain-65 AIO` (`OSITO-65-1S-ELRS-AIO REV 2.0` — $29.0 \times 29.0 \times 7.6\text{ mm}$, $25.5 \times 25.5\text{ mm}$ Diamond M2 Mount)  
**Proprietary Airframe & Canopy:** `Grizzly-Ring 65` (`Bambu PETG-CF`, `4.1g` Brushed / `3.8g` BL) + `Osito CubCap` Bear-Ear Canopy (`Bambu TPU 68D / 95A HF`, `1.6g`)  
**Verified Mass Envelope:** **`Trim A (0615 Brushed)`: `18.2g` Dry / `26.4g` AUW (`5:30–6:15 min` Flight)** $\cdot$ **`Trim B (0702SE Brushless)`: `17.4g` Dry / `25.6g` AUW (`4:30–5:15 min` Flight)** (with `8.2g` `CubCell 300mAh 1S 80C LiHV`)  
**Audit Status:** **PASSED ALL 5 VISIONARY GATES (`88%` Core Fleet Reuse | `<50g` Youth STEM & FAA Part 89 Exempt | `68/68` Firmware & FCC Part 15.249 Lock | `67.7%–70.1%` Gross Margin)**

---

## 0. Studio Product Photography & `CubBrain-65 AIO` Hardware Visuals

| Assembled `Osito MiniCub65 BNF` (`Grizzly-Ring 65` + `CubCap`) | `CubBrain-65 AIO` (`29×29mm` 4-Layer `TG170` Flight Controller) | Complete `MiniCub65 BNF` Modular Kit Flat-Lay |
| :---: | :---: | :---: |
| ![Osito MiniCub65 BNF Drone](./images/OSITO_MINICUB65_BNF_Hero_Drone.jpg) | ![Osito CubBrain-65 AIO PCB Closeup](./images/OSITO_CUBBRAIN65_AIO_PCB_Closeup.jpg) | ![Osito MiniCub65 BNF Kit Flat-Lay](./images/OSITO_MINICUB65_BNF_Kit_Knolling.jpg) |
| *8-Sided `Octa-Facet` `PETG-CF` ducts, tangential `Tri-Truss` motor struts, and Periwinkle Indigo (`#7077CF`) Bear-Ear `CubCap` canopy.* | *Matte black 4L `TG170` FR4, `ENIG` gold pads, center `STM32F411CEU6`, `BMI270` + `LP5907` LDO, `SX1280` ELRS ceramic antenna, and 4L `PTH` `BAT+`/`BAT-` anchors.* | *Complete solder-free modular BNF architecture: `Grizzly-Ring 65` frame, `CubBrain-65 AIO`, `CubCap` TPU hood, `800TVL` cam, plug-in motors, `31mm` props, and `CubCell` 1S packs.* |

---

## 1. Executive Summary: Proprietary `Osito MiniCub65 BNF` System Architecture

The **`Osito MiniCub65 BNF`** is Osito Drone LLC's in-house engineered 65mm 1S ExpressLRS micro-drone platform, purpose-built in San Francisco for K–12 STEM Youth Drone Academy classrooms, indoor FPV racing arenas, and direct-to-consumer (`ositodrone.com`) pilots.

```mermaid
flowchart LR
    subgraph AIRFRAME["1. Proprietary Airframe & Hood"]
        GR["Grizzly-Ring 65 Airframe\n(Octa-Facet PETG-CF + Tri-Truss Struts)"]
        CC["Osito CubCap Canopy\n(Bear-Ear TPU 68D + VTX Louvers)"]
        TG["Cantilevered BT2.0 Tail Gate\n(Zero PCB Solder Pad Tension)"]
    end

    subgraph AVIONICS["2. CubBrain-65 4-Layer TG170 AIO"]
        HB["True Full H-Bridge Brushed ESC\n(4x EFM8BB21 + 8x AO4614B Turtle Mode)"]
        PTH["4-Layer PTH Battery Pads + BT2.0\n(TPS63020 5V 2A Buck-Boost BEC)"]
        THERM["High-Heat TG170 + 125°C X7R/X7S\n(Disarmed 25mW VTX + 0.4s Stage-2 DROP)"]
    end

    subgraph ECON["3. Unit Economics & STEM GTM"]
        SKU1["SKU 1: Brushed BNF ($99.99)\n$29.85 BOM -> 70.1% Margin"]
        SKU2["SKU 2: Brushless BNF ($119.99)\n$36.40 BOM -> 69.7% Margin"]
        SKU3["SKU 3: 10-Pack STEM Pod ($1,995)\n$645 BOM -> +$1,350 Profit/School"]
    end

    AIRFRAME --> AVIONICS --> ECON
```

---

## 2. Proprietary Subsystem Taxonomy & Industrial Design Features

| Subsystem | Proprietary `Osito MiniCub65` Component Name | Part / Firmware ID | Core Engineering & Industrial Design Innovation |
| :--- | :--- | :--- | :--- |
| **Complete 65mm BNF Drone** | **`Osito MiniCub65 BNF`** (`MiniCub65-BR` Brushed / `MiniCub65-BL` Brushless) | `OSITO-MC65-BR` / `OSITO-MC65-BL` | Sub-30g (`26.4g` / `25.6g` AUW) ducted micro-drone in signature **Periwinkle Indigo (`#7077CF`)**, **Deep Royal (`#232A68`)**, and **Stealth Matte Black (`#161616`)**. |
| **29×29mm AIO Flight Controller** | **`CubBrain-65 AIO`** (`OSITO-65-1S-ELRS-AIO REV 2.0`) | `CUBBRAIN-65 REV 2.0` (`OSITO_MINICUB65`) | 4-Layer `TG170` FR4 (`2oz` Outer / `1oz` Inner Cu), `STM32F411CEU6`, isolated `LP5907` LDO + `BMI270` gyro, `SX1280` SPI3 ELRS, `AT7456E` OSD, and `25–200mW` SmartAudio VTX. |
| **65mm Ducted Airframe** | **`Grizzly-Ring 65` Airframe** (`Bambu PETG-CF` Slot 1) | `GRIZZLY-RING-65` | **8-Sided `Octa-Facet` Chamfered Outer Bumper** deflects glancing wall impacts; **3-Spoke `Tangential Swirl Tri-Truss` Motor Struts** isolate $280\text{–}420\text{ Hz}$ prop-pass resonance from the FC. |
| **FPV Camera Canopy** | **`Osito CubCap` Bear-Ear Louvered Canopy** (`Bambu TPU 68D` Slot 4 / `TPU 95A HF`) | `CUBCAP-65` | Angular stealth hood featuring twin **Osito Bear-Ear side impact lobes**, 3-position (`15°/25°/35°`) ratcheting camera tilt detents, top VTX heat louvers, and a rear whip antenna guard tube. |
| **Micro Analog FPV Camera** | **`CubVision 800TVL` Global-WDR Micro Cam** (`1.1g`) | `OSITO-CUBVISION` | $1/4''$ Global-WDR CMOS sensor, $150^\circ$ diagonal FOV, plug-and-play 3-pin `JST-SH 1.0mm` connector for 60-second solder-free classroom servicing. |
| **Propulsion Motors** | **`CubCore 0615` (`19,500KV` Brushed)** / **`CubSpin 0702SE` (`25,000KV` BLDC)** | `OSITO-0615` / `OSITO-0702SE` | Pre-crimped `JST-1.25mm` 2-pin (Brushed) and 3-pin (Brushless) motor plugs for zero-solder plug-and-play maintenance. |
| **1S 300mAh LiHV Battery** | **`CubCell 300mAh 1S 80C LiHV`** (`BT2.0` + `PH2.0` Solid-Pin Adapter) | `CUBCELL-1S-300HV` | Ultra-low-resistance `BT2.0` connector (`<4 mΩ`, `9A` continuous / `15A` burst) routed through the frame's **Cantilevered Strain-Relief Tail Gate**. |

---

## 3. Five Signature Hardware & Reliability Breakthroughs

| # | Core Subsystem | `Osito MiniCub65 BNF` Engineering Breakthrough |
| :---: | :--- | :--- |
| **1** | **Bidirectional Brushed Turtle Mode (`Trim A`)** | **True 4-Channel Full H-Bridge Brushed ESC:** 4× `EFM8BB21F16G` (`U5–U8`, `Bluejay v0.21`) + 8× `AO4614B` (`Q1A–Q4B`, `12A` Complementary N+P MOSFETs) + 4× `BC847BS` (`Q_DRV1–Q_DRV4`) enable **DShot300 Bidirectional Crash-Flip (Turtle Mode at `70%` thermal cap)** on brushed `0615` motors (`J_M1–J_M4`) so students flip inverted drones upright remotely via `Switch SC`. *(Trim B swaps the output stage to 3-phase BLDC half-bridges + 3-pin `A1257WV-S-3P` headers).* |
| **2** | **Sag-Proof 1S Power Architecture** | **Unified `BT2.0` (`<4 mΩ`) + `TPS63020` Buck-Boost BEC + `220µF 105°C` POSCAP (`C_BULK`):** Holds rock-solid `5.0V` regulation for the MCU, OSD, and VTX all the way down to `1.8V` battery sag. |
| **3** | **Tear-Proof Battery Lead Retention** | **4-Layer Plated Through-Hole (`PTH`) Battery Pads (`PAD_BAT+`/`PAD_BAT-`) + Rear Frame Strain Gate:** `Ø1.00mm` drills anchored across `F.Cu`, `In1.Cu`, `In2.Cu`, and `B.Cu` provide $>5\times$ peel strength while the frame's rear bridge absorbs all battery pull forces. |
| **4** | **High-Heat ($85\,^\circ\text{C}\text{–}105\,^\circ\text{C}$) Thermal Guard** | **`TG170` 4L `2oz` PCB + `125°C X7R/X7S` Caps + `vtx_low_power_disarm = ON`:** Automatically throttles the VTX (`U13` `RTC6705` + `U14` `RTC6659E`) to `25mW` while disarmed, vents heat through 4 under-VTX battery tray chimneys and top `CubCap` louvers, and displays live MCU junction temp on the OSD (`osd_core_temp_alarm = 85`). |
| **5** | **On-Demand San Francisco Print Farm Manufacturing** | **In-House `Bambu PETG-CF` Frame (`$0.28`, `4.1g`) + `Bambu TPU 68D` Bear-Ear Canopy (`$0.15`, `1.6g`):** Printed in batches of 24 units in 6.5 hours on Osito's 2× Bambu Lab P2S Combo farm (`8 frames/plate` in Slot 1, `12 canopies/plate` in Slot 4). |

---

## 4. Dual-Drivetrain Mass Budget & `CubBrain-65 AIO` Pinout Matrix

### 4.1 Verified Component-by-Component Mass Budget (`0.1g` Precision)

| Subsystem Component | **Trim A: `MiniCub65 Brushed BNF` (`0615`)** | **Trim B: `MiniCub65 Pro Brushless BNF` (`0702SE`)** | Filament / Material Spec |
| :--- | :---: | :---: | :--- |
| **`CubBrain-65 AIO` 4L `TG170` PCBA (`29×29×7.6mm`) + `BT2.0` Lead** | `4.2 g` | `4.1 g` | $29.0 \times 29.0 \times 1.0\text{ mm}$ 4-Layer `2oz/1oz` Cu, `ENIG`, `130` SMT parts |
| **`Grizzly-Ring 65` Octa-Facet Airframe** | `4.1 g` | `3.8 g` | **Tier 1 `Bambu PETG-CF`** (P2S #1 AMS Slot 1, `265°C` / `70°C`) |
| **4× Propulsion Motors (`JST-1.25mm` Plug-and-Play)** | `6.4 g` *(4× `CubCore 0615 19,500KV` @ `1.60g`)* | `6.0 g` *(4× `CubSpin 0702SE 25,000KV` @ `1.50g`)* | Solder-free bottom `JST-1.25mm` 2-pin (Brushed) / 3-pin (Brushless) |
| **`Osito CubCap` Bear-Ear Louvered Canopy** | `1.6 g` | `1.6 g` | **Tier 4 `Bambu TPU for AMS 68D`** (Slot 4) or `TPU 95A HF` (P2S #2 Ext) |
| **`CubVision 800TVL` Micro FPV Cam + `5.8GHz` Dipole Whip** | `1.1 g` | `1.1 g` | `1.1g` Global-WDR CMOS cam (`JST-SH` 3-pin) + brass whip |
| **4× `31mm` PC Ducted Props + 4× M2 Silicone Grommets + Screws** | `0.8 g` | `0.8 g` | `4 × 0.12g` props + `0.32g` M2 hardware |
| **TOTAL DRY BNF MASS (Without Battery)** | **`18.2 g`** | **`17.4 g`** | **Exact Sum of Rows 1–6** |
| **`CubCell 300mAh 1S 80C LiHV` Pack (`BT2.0`)** | `+8.2 g` | `+8.2 g` | `3.8V / 4.35V LiHV` (`1.14 Wh`, UL 1642 / UN 38.3 certified) |
| **TOTAL ALL-UP FLYING WEIGHT (`AUW`)** | **`26.4 g`** | **`25.6 g`** | **100% `<50g` Youth STEM Safe & `<250g` FAA Part 89 Exempt** |

---

### 4.2 Complete `CubBrain-65 AIO` (`STM32F411CEU6`) Pinout, Timer & Conflict-Free DMA Matrix

| MCU Pin | GPIO | Function | Peripheral / Timer / DMA Stream | Connected Component / Net (`CubBrain-65 REV 2.0`) |
| :---: | :---: | :--- | :--- | :--- |
| **10** | `PA0` | `MOTOR 1` (Rear Right) | `TIM2_CH1` (`DMA1 Stream 5 Ch 3`) | `U5` `EFM8BB21` M1 DShot300 Input |
| **11** | `PA1` | `MOTOR 2` (Front Right) | `TIM2_CH2` (`DMA1 Stream 6 Ch 3`) | `U6` `EFM8BB21` M2 DShot300 Input |
| **46** | `PB9` | `MOTOR 3` (Rear Left) | `TIM4_CH4` (`TIM4_UP` Burst DMA) | `U7` `EFM8BB21` M3 DShot300 Input |
| **45** | `PB8` | `MOTOR 4` (Front Left) | `TIM4_CH3` (`DMA1 Stream 7 Ch 2`) | `U8` `EFM8BB21` M4 DShot300 Input |
| **18** | `PB0` | `ADC_BATT` (`VBAT`) | `ADC1_IN8` (**`DMA2 Stream 4 Ch 0`**) | `R1/R2` ($10\text{ k}\Omega / 10\text{ k}\Omega$, $2:1$ Divider, `vbat_scale=20 / vbat_divider=10`) |
| **19** | `PB1` | `ADC_CURR` (`IBAT`) | `ADC1_IN9` (**`DMA2 Stream 4 Ch 0`**) | `U9` `INA199A1` ($50\text{ V/V}$) + $5\text{ m}\Omega$ `1206` Shunt (`ibata_scale=2500`) |
| **14–17, 3** | `PA4–PA7, PC14` | `SPI1` Gyro + `EXTI14` | `SPI1` (`DMA2 Stream 0 RX / Stream 3 TX`) | `U2` Bosch `BMI270` (`CW90` + `align_board_yaw = 450` Diamond Mount) |
| **25–28** | `PB12–PB15` | `SPI2` Analog OSD | `SPI2` Hardware Bus | `U4` `AT7456E` OSD $\rightarrow$ `R9` ($75\,\Omega$) $\rightarrow$ `U13` `RTC6705` + `U14` `RTC6659E` |
| **38–43, 2** | `PA15, PB3–PB7, PC13` | `SPI3` ExpressLRS 2.4GHz | `SPI3` Hardware Bus + `EXTI6` (`DIO1`) | `U3` Semtech `SX1280IMLTRT` + $52\text{ MHz}$ TCXO + `ANT1` Ceramic Chip Antenna |
| **12 / 13** | `PA2 / PA3` | `UART2 TX / RX` | Hardware `USART2` | `UART2 TX` (`PA2`) drives onboard SmartAudio v2.1 VTX control |
| **31 / 32** | `PA9 / PA10` | `UART1 TX / RX` | Hardware `USART1` | Perimeter Expansion Pads (`+5V / +3.3V / GND / TX1 / RX1`) |
| **30 / 4** | `PA8 / PC15` | `LED_STRIP / BEEPER` | `TIM1_CH1` (`DMA2 Stream 1`) / GPIO | Addressable RGB LED Pad (`PA8`) + Piezo Buzzer Driver (`PC15`) |

---

## 5. Complete Landed BOM, Unit Economics & Turnkey Fab Package

### 5.1 Unified Landed Unit BOM (`Trim A: Brushed BNF` vs. `Trim B: Pro Brushless BNF`)

| # | Subsystem / Component | Batch of 25 (Pilot) | Batch of 100 (Standard) | Batch of 500 (Scale) |
| :-: | :--- | :-: | :-: | :-: |
| **1** | **Turnkey 4-Layer `TG170` PCBA (`CubBrain-65 AIO` — 130 SMT Parts)** | `$21.40` (BR) / `$22.35` (BL) | **`$16.85` (BR) / `$17.60` (BL)** | `$13.90` (BR) / `$14.50` (BL) |
| **2** | **4× Propulsion Motors (`CubCore 0615 19,500KV` vs. `CubSpin 0702SE 25,000KV`)** | `$4.60` (BR) / `$11.60` (BL) | **`$3.60` (BR) / `$9.40` (BL)** | `$2.80` (BR) / `$7.60` (BL) |
| **3** | **`CubVision 800TVL 1.1g` Micro FPV Camera + `5.8GHz` Dipole Whip** | `$5.80` | **`$4.65`** | `$3.90` |
| **4** | **In-House 2× Bambu P2S Print (`Grizzly-Ring 65 PETG-CF` + `CubCap TPU 68D`)** | `$0.50` (`$0.32 + $0.18`) | **`$0.43` (`$0.28 + $0.15`)** | `$0.37` (`$0.24 + $0.13`) |
| **5** | **31mm 4-Blade Props (4+2), M2 Silicone Grommets, `BT2.0` + `PH2.0` Adapter** | `$2.05` | **`$1.57`** | `$1.23` |
| **6** | **Retail BNF Box, Die-Cut EVA Foam, QR Card, Freight & Pogo-Jig QA** | `$3.55` | **`$2.75`** | `$2.00` |
| — | **TOTAL LANDED BNF COST (`Trim A: Classroom Brushed BNF`)** | **`$37.90`** | **`$29.85`** | **`$24.20`** |
| — | **TOTAL LANDED BNF COST (`Trim B: Pro Brushless BNF`)** | **`$45.85`** | **`$36.40`** | **`$29.60`** |

### 5.2 Retail D2C & STEM Classroom SKU Margin Matrix (Gate 4: `>= 60%` Gross Margin)

| SKU Code & Product Name | Target Channel | Landed BOM (`@ Qty 100`) | Selling Price | Gross Profit | Gross Margin % |
| :--- | :--- | :-: | :-: | :-: | :-: |
| **SKU 1A: `MiniCub65 Classroom Brushed BNF` (D2C)** | `ositodrone.com` & Camp Parents | `$29.85` | **`$99.99`** | **`+$70.14`** | **`70.1%`** ✅ |
| **SKU 1B: `MiniCub65 Classroom Brushed BNF` (EDU Fleet)** | Schools & Makerspaces (10+ Units) | `$29.85` | **`$89.00`** | **`+$59.15`** | **`66.5%`** ✅ |
| **SKU 2A: `MiniCub65 Pro Brushless BNF` (D2C)** | FPV Racers & Advanced Youth Pilots | `$36.40` | **`$119.99`** | **`+$83.59`** | **`69.7%`** ✅ |
| **SKU 2B: `MiniCub65 Pro Brushless BNF` (EDU Fleet)** | High School CTE & Racing Clubs | `$36.40` | **`$105.00`** | **`+$68.60`** | **`65.3%`** ✅ |
| **SKU 3: `MiniCub65 RTF Classroom 10-Pack Pod`** | **CA ELO-P / SF DCYF Object Code 4300** *(10× MiniCub65 + 10× T8L Radios + 30× 300mAh LiHV + 2× 6-Port Chargers)* | **`$645.00`** | **`$1,995.00`** | **`+$1,350.00`** *(+$340/Founder)* | **`67.7%`** ✅ |

### 5.3 Self-Contained Turnkey PCBA Fabrication Package (`pcb/`)
- [`pcb/1_Gerber_OSITO_65_1S_ELRS_AIO_FAB_PACKAGE.zip`](./pcb/1_Gerber_OSITO_65_1S_ELRS_AIO_FAB_PACKAGE.zip) — 13-file 4-Layer `TG170` Gerber (11 copper/mask/silk/paste/edge layers) + 2 Excellon drill (`.drl`) archive (`0` DRC errors).
- [`pcb/2_BOM_OSITO_65_1S_ELRS_AIO_Turnkey_PCBA.csv`](./pcb/2_BOM_OSITO_65_1S_ELRS_AIO_Turnkey_PCBA.csv) — 53-line (`53` component rows / `130` SMT parts) turnkey BOM with exact LCSC part numbers (`U1–U15`, `Q1A–Q4B`, `Q_DRV1–Q_DRV4`, `J_M1–J_M4`).
- [`pcb/3_CPL_OSITO_65_1S_ELRS_AIO_PickAndPlace.csv`](./pcb/3_CPL_OSITO_65_1S_ELRS_AIO_PickAndPlace.csv) — Top (`67` parts) + Bottom (`63` parts) = `130` SMT parts pick-and-place centroid file.
