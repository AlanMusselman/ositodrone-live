# OSITO HOVER-65 (AcroBee65-Inspired Camera-Less LOS) & OSITO-HOVER-FC29-1S-AIO (REV 3.1 "4-Corner Quick-Swap Motor Pad" $5.50 Edition): Complete Turnkey Manufacturing Handoff, Box-Build & 10×10 ft Popup Tent Operations Guide

**Prepared For:** Alan Musselman, Miguel Flores (CEO, `miguel@ositodrone.com`), & Jesus Aceves (CTO, `jesus@ositodrone.com`)  
**System Designation:** `OSITO HOVER-65 (AcroBee65-LOS Edition)` (*65mm Camera-Less 1S 300mAh LiHV Ducted Hover Training Drone + 2-Layer Single-Sided SMT AIO Flight Controller w/ Onboard 4-in-1 5.7A 32kHz N-FET ESC & 4-Corner Quick-Swap Motor Pads*)  
**Flight Controller Part Number:** `OSITO-HOVER-FC29-1S-AIO REV 3.1 ("AcroBee65 Bread-and-Butter + 4-Corner Quick-Swap Motor Pad" $5.50 Spec — Audited & Cleared for Turnkey PCBA)`  
**Primary Handoff Directory:** [`Osito_Hover65_1S_300mAh_Turnkey_Handoff/`](./)  
**Executive Word Document Edition:** [`OSITO_HOVER65_AcroBee65_NoCam_10x10_Tent_Handoff_Guide.docx`](./OSITO_HOVER65_AcroBee65_NoCam_10x10_Tent_Handoff_Guide.docx)

---

## 1. Executive Summary: What You Are Handing Off to Get Made

This package contains **100% of the production files** required to manufacture **Osito Drone Academy's bread-and-butter fleet drone** — the **AcroBee65-Inspired Camera-Less 1S 300mAh Hover Training Drone (`OSITO HOVER-65`)** and its **`$5.50` 2-Layer Single-Sided SMT AIO Flight Controller + Integrated 4-in-1 5.7A 32kHz N-FET ESC (`OSITO-HOVER-FC29-1S-AIO REV 3.1`)** via external contract manufacturers (**JLCPCB / PCBWay Turnkey PCBA** and **JLC3DP HP MJF Nylon 3D Printing**), specifically engineered for youth Line-of-Sight (LOS) training inside the **Osito Drone Academy 10×10 ft (`3.0m × 3.0m`) Netted Popup Tent Arena**:

| Manufacturing Deliverable | Handoff ZIP / File | Target Vendor | Unit Cost (10 Qty) | Unit Cost (100 Qty) |
| :--- | :--- | :--- | :---: | :---: |
| **1. Assembled 2-Layer Single-Sided SMT AIO FC + Onboard 4-in-1 5.7A ESC (`OSITO-HOVER-FC29-1S-AIO REV 3.1`)** | [`pcb_turnkey/OSITO_HOVER_FC29_1S_TURNKEY_PCBA_PACKAGE.zip`](./pcb_turnkey/OSITO_HOVER_FC29_1S_TURNKEY_PCBA_PACKAGE.zip) | **JLCPCB / PCBWay Turnkey PCBA** ($3 \times 3$ Panel = `$0.22` Bare PCB!) | **`$6.45`** | **`$5.50`** |
| **2. AcroBee65-LOS 3-Rib Guard Airframe & Camera-Less Canopy** | [`cad_turnkey/OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip`](./cad_turnkey/OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip) | **JLC3DP (HP MJF PA12 Nylon)** or In-House Print Farm | **`$2.10`** | **`$1.55`** |
| **3. Propulsion + 1S 300mAh LiHV Battery (`BT2.0`) + Hardware** | [`OSITO_HOVER65_COMPLETE_DRONE_BOM.csv`](./OSITO_HOVER65_COMPLETE_DRONE_BOM.csv) | **GNB / Gemfan / Wholesale** | **`$11.70`** | **`$8.95`** |
| **COMPLETE STANDARD ACROBEE65-LOS HOVER DRONE (w/ Onboard 5.7A ESC + Baro)** | **[`OSITO_HOVER65_MASTER_VENDOR_HANDOFF_BUNDLE.zip`](./OSITO_HOVER65_MASTER_VENDOR_HANDOFF_BUNDLE.zip)** | **Complete Box-Build** | **`$20.25`** | **`$16.00`** |
| **COMPLETE PRO AUTO-HOVER DRONE (+ `MTF-01` Optical-Flow & ToF LiDAR)** | + `MICOAIR-MTF01-UART` & Underbelly Pod | **Complete Pro Box-Build** | **`$29.15`** | **`$23.20`** |
| **OPTIONAL TABLETOP VERTICAL-ROD HOVER RIG (+ 4× 300mAh Dock)** | Included in `OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip` | **JLC3DP / In-House Print** | **`$2.96`** | **`$2.35`** |
| **8th CAD PART: 10×10 Tent Floor Bullseye Target Pad (`160mm`)** | `OSITO_HOVER65_Tent_Hover_Target_Pad_Marker.stl` | **JLC3DP / Dual-Color PLA+** | **`$1.25`** | **`$0.85`** |
| **COMPLETE STATION 2 10×10 TENT FLEET KIT (6 Drones + 24 Packs + 2 Chargers + Bat-Safe)** | Line 13 of `OSITO_HOVER65_COMPLETE_DRONE_BOM.csv` | **Turnkey Academy Pod Kit** | **`$309.50`** | **`$248.00`** |

---

## 2. How `REV 3.1` Cuts Your Assembled PCB Cost from `$10.80` to `$5.50` (`$0.22` Bare PCB!) & Enables 15-Second 4-Corner Quick-Swap Motor Replacement

1. **2-Layer $1.0\text{ mm}$ FR4 Lead-Free HASL in a $3 \times 3$ Panel (`$0.22` per Bare PCB):**
   * Because a $3 \times 3$ panel of $29 \times 29\text{ mm}$ boards measures $95 \times 95\text{ mm}$ (under the $100 \times 100\text{ mm}$ JLCPCB promo threshold), ordering 5 panels (`45 bare PCBs`) on 2-layer $1\text{ oz}$ FR4 costs `$2–$10` total (**`$0.22` per bare PCB** vs. `$1.10` for a 4-layer ENIG single board).
2. **100% Single-Sided Top SMT Assembly (`Zero Bottom Active Silicon`):**
   * All 68 active silicon chips, ESC MOSFETs, diodes, crystals, LEDs, and passives are placed on the **Top Layer (`F.Cu`)**. Only the 4 symmetrical corner motor headers (`J_M1–J_M4`) and optional sensor header (`J_HOVER`) sit on the bottom—eliminating double-sided reflow fees and stencil surcharges.
3. **4-Corner Quick-Swap Motor Termination Architecture (`M1±..M4±` PTH Solder Pads + Parallel `J_M1–J_M4` Corner Plugs + Rear `BAT+/BAT-` PTH Pads):**
   * At each of the **4 frame arm junctions**, `REV 3.1` places **oversized $2.0 \times 1.6\text{ mm}$ dual-sided HASL Plated Through-Hole (PTH) Quick-Solder Motor Pads (`M1+/M1-`, `M2+/M2-`, `M3+/M3-`, `M4+/M4-`)** with **$\varnothing 0.85\text{ mm}$ wire strain-relief drills** right at the outer PCB corners (`X = ±12.80mm, Y = ±9.20mm / ±7.10mm`), wired in parallel with **4 symmetrical corner bottom `JST-1.25mm` 2-pin plugs (`J_M1–J_M4` at `X = ±11.80mm, Y = ±8.15mm`)**, plus **rear `BT2.0` battery PTH solder pads (`BAT+/BAT-`, $2.6 \times 2.0\text{ mm}$ with $\varnothing 1.20\text{ mm}$ drills at `X = ±5.20mm, Y = -12.60mm`)**.
   * **Why this matters for Academy Fleet Maintenance:** Whether you plug in pre-terminated `JST-1.25mm` motors from the bottom **or** direct-solder motor leads from the top in 15 seconds without removing the flight controller from the frame, motor wires exit cleanly straight down each of the 4 frame arms with zero excess wire slack and zero pad-lifting risk.
4. **Symmetrical 4-Corner AcroBee65 Direct $32\text{ kHz}$ Hardware PWM N-FET ESC (`$0.20` Total ESC Cost, Zero ESC MCUs to Flash):**
   * Just like the real **NewBeeDrone AcroBee65 (BeeBrain Lite)**, `REV 3.1` places 4× **`AO3400A` ($30\text{V}, 5.7\text{A}$ continuous, $19\text{ m}\Omega$) Low-Side N-Channel MOSFETs (`Q1–Q4` at `±9.60mm, ±7.80mm`)** and 4× **`B5819WS` ($40\text{V}, 1\text{A}$) Schottky flyback diodes (`D_M1–D_M4` at `±9.60mm, ±4.80mm`)** symmetrically at the 4 corners, driven directly from the `AT32F435` hardware timers (`TMR2` & `TMR4`) at **`32 kHz` (`set motor_pwm_protocol = BRUSHED`, `set motor_pwm_rate = 32000`)**, paired with 4× $100\,\Omega$ gate damping resistors and 4× $10\text{ k}\Omega$ safety gate pull-downs.
   * **Why this guarantees it works out of the box:** There are **zero separate ESC MCUs (`EFM8BB21`) to flash with Bluejay or desync**. As soon as you flash Betaflight 4.5 over USB-C, all 4 motors spin smoothly, and each `AO3400A` dissipates only **$6.39\text{ mW}$** at hover ($\Delta T < +0.8^\circ\text{C}$).
5. **Pro-Grade `ICM-42688-P` SPI Gyro (`$0.65` vs. `$1.35` `BMI270`):**
   * Uses the industry-standard TDK InvenSense **`ICM-42688-P`** (`LCSC C2848105`, `$0.65`) on its own isolated ultra-low-noise **`LP5907MFX-3.3` LDO (`U5`)**, saving `$0.70/board` while improving vibration immunity.

| Engineering & Academy Metric | Stock FPV AcroBee65 (Retail COTS) | **OSITO HOVER-65 (`REV 3.1` 4-Corner Quick-Swap)** | STEM Academy Advantage in 10×10 ft Tent |
| :--- | :---: | :---: | :--- |
| **Unit Hardware Cost** | `$119.99` retail | **`$16.00`** (`100-unit BOM`) / **`$23.20`** (`w/ OptFlow`) | **86.7% lower unit cost**; enables full 6-drone tent pods for **`$248.00`** |
| **Assembled AIO FC + 4-in-1 ESC Cost** | `$49.99` replacement BeeBrain | **`$5.50`** (`$0.22` bare PCB + 73 SMD parts + `BT2.0`) | **90% lower board cost**; single-sided SMT assembly |
| **Field Motor Replacement** | Bottom-only micro plugs (requires unmounting FC if plug is damaged) | **Dual-Option 4-Corner PTH Quick-Solder Pads (`M1±..M4±`) + Parallel Corner `JST-1.25` Plugs (`J_M1–J_M4`)** | **15-second top-side field motor swap** without removing canopy/FC screws |
| **Camera & 5.8GHz VTX Stack** | Analog CMOS Cam + 25–100mW VTX (`+3.2g`, `$28`) | **Camera-Less BeeBrain-Lite LOS Dome (`0g` cam, `0mW` VTX)** | **Zero VTX thermal throttling/burnout** during low-airflow indoor tent hovering |
| **All-Up Flight Weight (w/ 1S 300mAh)** | `~28.8g` | **`24.9g`** (Baro) / **`27.0g`** (w/ `MTF-01` OptFlow+ToF) | Ultra-low kinetic energy (`<0.07 J` at tent speeds); 10× under FAA `250g` limit |
| **Continuous Hover Time (`1S 300mAh LiHV`)** | `2 min 30 sec` (heavy VTX + cam draw) | **`6 min 05 sec`** (`105mA` FC idle + `2.26A` hover draw) | **2.4× longer hover flight time**; covers an entire student squad rotation per pack |
| **Top & Perimeter Prop / Net Protection** | Open top prop ducts (can snag tent mesh or fingers from above) | **Top 3-Rib Finger/Net Guards + Smooth `94.6mm` Anti-Snag Perimeter Ring** | **Zero mesh snags** when bumping 10×10 popup tent netting; 100% finger-safe top & bottom |

---

## 3. Osito Drone Academy 10×10 ft Popup Tent Curriculum & Station 2 Operations Blueprint

### 3.1 Station 2 Netted Hover Pod Layout (`10×10 ft` / `3.0m × 3.0m` Tent)
In accordance with **Miguel Flores's (CEO) 4-Station Youth STEM Academy Rotation Blueprint**, **Station 2 (The 10×10 ft Netted Hover Pod)** is the primary live-flight arena where students transition from simulator/guide-rod practice to real free-flight hovering:
* **Physical Footprint:** Standard **`10 ft × 10 ft × 8.5 ft peak` (`3.0m × 3.0m`) Commercial Popup Canopy Tent** enclosed on all 4 sides with high-visibility, flame-retardant micro-mesh drone netting (`zippered pit-crew entry door`).
* **Floor Target Layout:** Four **`160mm` High-Contrast Bullseye Target Pads** ([`OSITO_HOVER65_Tent_Hover_Target_Pad_Marker.stl`](./cad_turnkey/OSITO_HOVER65_Tent_Hover_Target_Pad_Marker.stl)) are placed either in a single center bullseye or in four `1.5m × 1.5m` quadrants (allowing up to **4 students** to hover simultaneously in `TENT_CUB` mode).
* **Pilot Viewing Line:** Students and the Station 2 Coach stand **outside the zipped mesh wall**, holding their ELRS 2.4GHz controllers while watching the drone's **Front Green LEDs**, **Rear Orange LEDs**, and **Canopy `+Y` Nose Arrow**.

### 3.2 4-Step Kids Hover Progression Inside the 10×10 Tent
Each `OSITO-HOVER-FC29-1S-AIO REV 3.1` board comes pre-provisioned with [`OSITO_HOVER_FC29_1S_Betaflight45_HoverTrainer_CLI.txt`](./pcb_turnkey/OSITO_HOVER_FC29_1S_Betaflight45_HoverTrainer_CLI.txt):
1. **Step 1 — Center Bullseye Lift-Off & `90 cm` Altitude Lock (`Minutes 0–3`):**
   * Switch set to **`AUX2 LOW = TENT_CUB Mode`** (`18.0°` max bank angle cap, `HEADFREE` orientation lock, `70%` ceiling throttle scale, `42%` flattened throttle hover midpoint).
   * Student smoothly raises throttle to the center detent; the `SPL06-001` barometer and `MTF-01` ToF LiDAR lock hover altitude at chest height (**`90 cm` / `3 ft`**) directly over the bullseye pad.
2. **Step 2 — Headfree Right-Stick Micro-Corrections & Net-Bump Confidence (`Minutes 3–6`):**
   * With `HEADFREE` active, pulling the right stick back *always* brings the drone toward the student regardless of yaw spin.
   * Students intentionally drift gently to kiss the 10×10 tent mesh wall — demonstrating how the **smooth perimeter ring, top 3-rib guards, and low-slung 1S 300mAh belly battery** bounce softly off the netting and stay upright without flipping or catching a thread.
3. **Step 3 — `TENT_SCOUT` (`25°`) Nose-Out Box Pattern & Precision Landing (`Minutes 6–10`):**
   * Coach flips **`AUX2 MID/HIGH`** (`TENT_SCOUT` `25.0°` angle limit, standard nose-forward coordinates).
   * Using the **Canopy `+Y` Arrow** and **Green/Orange LEDs**, the student flies a slow `1.8m × 1.8m` square perimeter inside the tent and lands squarely on the center bullseye pad.
4. **Step 4 — `TENT_PRO_LOS` (`35°`) Tent Slalom & Figure-8 Relay (`Minutes 10–12`):**
   * Advanced students weave Figure-8 patterns between two floor target pads inside the tent before disarming on the bullseye.

### 3.3 Jesus's (CTO) Station 4 Pit-Crew `1S 300mAh LiHV` Battery Rotation Math
* **Hover Endurance per `1S 300mAh LiHV` Pack:** **`6 min 05 sec`** (`2.365A` average hover draw; low-voltage red LED warning triggers at `3.50V/cell`, leaving a safe 20% reserve).
* **24-Pack + Dual `VIFLY WhoopStor V3` Continuous Loop:**
  * **Batch A (8 Packs):** Actively flying in the 10×10 tent (`Minutes 0–15`).
  * **Batch B (8 Packs):** Fully charged at `4.35V LiHV` staged in the Tabletop Base 4-slot docks for the next squad (`Minutes 15–30`).
  * **Batch C (8 Packs):** Charging at `0.6A (2C)` on **2× 6-port `VIFLY WhoopStor V3` chargers** inside a fireproof **Bat-Safe** at Station 4 (`~22 minutes` recharge).

---

## 4. Step-by-Step Vendor Handoff Instructions (How to Order for `$5.50/Board`)

### Step A: Order Turnkey Assembled Flight Controllers (`JLCPCB` or `PCBWay`)
1. Go to **JLCPCB.com** $\rightarrow$ **Quote Now** $\rightarrow$ **Upload Gerber File**.
2. Upload **[`pcb_turnkey/OSITO_HOVER_FC29_1S_TURNKEY_PCBA_PACKAGE.zip`](./pcb_turnkey/OSITO_HOVER_FC29_1S_TURNKEY_PCBA_PACKAGE.zip)**.
3. Select the **2-Layer $3 \times 3$ Panelized PCB parameters**:
   * **Base Material:** `FR-4` | **Layers:** `2` | **Dimensions:** `29.0 mm × 29.0 mm` (**Panel by JLCPCB = `3 × 3`** $\rightarrow$ 9 boards per $95 \times 95\text{ mm}$ panel = **`$0.22/bare PCB`**!)
   * **PCB Thickness:** `1.0 mm` | **Copper Weight:** `1 oz` | **Surface Finish:** `LeadFree HASL`
4. Toggle **"PCB Assembly (PCBA)" = ON**:
   * **Assembly Side:** Select **`Top Side Only`** (all 68 active silicon, symmetrical corner `AO3400A` ESC FETs, RF, Baro & passives are on Top `F.Cu` for lowest-cost single-pass reflow; you can either direct-solder the 4 motor leads into the **8 oversized 4-Corner Quick-Solder PTH Pads (`M1±..M4±` at `±12.80mm, ±9.20/±7.10mm`)**, hand-tack the 4 corner bottom motor plugs `J_M1–J_M4` (`±11.80mm, ±8.15mm`) in 30 seconds, or select `Both Sides` if you want the factory to solder the plugs).
   * **Upload BOM File:** Select **[`pcb_turnkey/OSITO_HOVER_FC29_1S_BOM_JLCPCB.csv`](./pcb_turnkey/OSITO_HOVER_FC29_1S_BOM_JLCPCB.csv)**.
   * **Upload CPL (Pick & Place) File:** Select **[`pcb_turnkey/OSITO_HOVER_FC29_1S_CPL_PickAndPlace.csv`](./pcb_turnkey/OSITO_HOVER_FC29_1S_CPL_PickAndPlace.csv)**.

### Step B: Order Turnkey MJF Nylon Airframes, Canopies & 10×10 Tent Target Pads (`JLC3DP`)
1. Upload the 8 STL files from **[`cad_turnkey/OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip`](./cad_turnkey/OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip)** to **JLC3DP.com** (**HP MJF `PA12` Nylon** at `~$1.10/frame` or print in-house on Osito's `2× Bambu Lab P2S Combo` farm using `Bambu PETG-CF` & `TPU 95A HF`).
