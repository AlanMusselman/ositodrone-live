#!/usr/bin/env python3
"""
OSITO-HOVER-FC29-1S-AIO REV 3.0 ("AcroBee65 Bread-and-Butter" 2-Layer Single-Sided SMT Edition)
Turnkey 1S 300mAh Hover Training AIO Flight Controller with Integrated Onboard 4-in-1 5.7A
Direct 32kHz Hardware PWM N-FET ESC (4x AO3400A + 4x B5819WS) + ICM-42688-P + SPL06 Baro + OptFlow Port
Automated KiCad 8.0 2-Layer PCB, RS-274X Gerber, Excellon Drill & Turnkey PCBA Generator
"""

import os
import csv
import math
import zipfile
import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
GERBERS_DIR = os.path.join(SCRIPT_DIR, "gerbers")

BOM_FILE = os.path.join(SCRIPT_DIR, "OSITO_HOVER_FC29_1S_BOM_JLCPCB.csv")
CPL_FILE = os.path.join(SCRIPT_DIR, "OSITO_HOVER_FC29_1S_CPL_PickAndPlace.csv")
CLI_FILE = os.path.join(SCRIPT_DIR, "OSITO_HOVER_FC29_1S_Betaflight45_HoverTrainer_CLI.txt")

KICAD_PCB_FILE = os.path.join(SCRIPT_DIR, "OSITO_HOVER_FC29_1S.kicad_pcb")
FAB_NOTES_FILE = os.path.join(SCRIPT_DIR, "README_TURNKEY_PCBA_FABRICATION_NOTES.txt")
ZIP_ARCHIVE_FILE = os.path.join(SCRIPT_DIR, "OSITO_HOVER_FC29_1S_TURNKEY_PCBA_PACKAGE.zip")

os.makedirs(GERBERS_DIR, exist_ok=True)

print("=" * 92)
print("OSITO-HOVER-FC29-1S-AIO REV 3.0: 2-LAYER SINGLE-SIDED SMT ACROBEE65-LOS AIO FC+ESC GENERATOR")
print("=" * 92)

with open(BOM_FILE, "r", encoding="utf-8") as f:
    bom_rows = [r for r in csv.DictReader(f) if r.get("Item", "").strip().isdigit()]

with open(CPL_FILE, "r", encoding="utf-8") as f:
    cpl_rows = list(csv.DictReader(f))

bom_map = {}
total_bom_usd = 0.0
for row in bom_rows:
    total_bom_usd += float(row["Ext_Cost_USD"])
    for des in row["Designator"].strip().split():
        bom_map[des] = row

components = []
for row in cpl_rows:
    des = row["Designator"].strip()
    val = row["Comment"].strip()
    pkg = row["Package"].strip()
    mid_x = float(row["Mid X (mm)"])
    mid_y = float(row["Mid Y (mm)"])
    rot = float(row["Rotation"])
    layer = row["Layer"].strip()
    b_info = bom_map.get(des, {})
    components.append({
        "designator": des,
        "value": val,
        "package": pkg,
        "mid_x": mid_x,
        "mid_y": mid_y,
        "rotation": rot,
        "layer": layer,
        "mpn": b_info.get("MPN", ""),
        "supplier_pn": b_info.get("Supplier_PN", "")
    })

top_count = sum(1 for c in components if c["layer"] == "Top")
bot_count = sum(1 for c in components if c["layer"] == "Bottom")
print(f"Loaded {len(bom_rows)} BOM lines (Total Unit Cost: ${total_bom_usd:.3f} USD) and {len(components)} SMD placements ({top_count} Top SMT + {bot_count} Bottom Plugs).")

def get_package_pads(package):
    pads = []
    if package == "0402":
        pads.append({"num": "1", "rel_x": -0.50, "rel_y": 0.0, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.50, "rel_y": 0.0, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
    elif package == "0603":
        pads.append({"num": "1", "rel_x": -0.80, "rel_y": 0.0, "width": 0.80, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.80, "rel_y": 0.0, "width": 0.80, "height": 0.80, "shape": "rect", "is_thermal": False})
    elif package == "CASE-B_3528":
        pads.append({"num": "1", "rel_x": -1.35, "rel_y": 0.0, "width": 1.40, "height": 1.90, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  1.35, "rel_y": 0.0, "width": 1.40, "height": 1.90, "shape": "rect", "is_thermal": False})
    elif package == "SOD-123":
        pads.append({"num": "1", "rel_x": -1.60, "rel_y": 0.0, "width": 1.00, "height": 1.20, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  1.60, "rel_y": 0.0, "width": 1.00, "height": 1.20, "shape": "rect", "is_thermal": False})
    elif package == "SMD-3216":
        pads.append({"num": "1", "rel_x": -1.40, "rel_y": 0.0, "width": 0.80, "height": 1.60, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  1.40, "rel_y": 0.0, "width": 0.80, "height": 1.60, "shape": "rect", "is_thermal": False})
    elif package == "SOT-23":
        pads.append({"num": "1", "rel_x": -0.95, "rel_y": -1.00, "width": 0.60, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.95, "rel_y": -1.00, "width": 0.60, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3", "rel_x":  0.00, "rel_y":  1.00, "width": 0.60, "height": 0.80, "shape": "rect", "is_thermal": False})
    elif package == "SOT-23-5":
        pads.append({"num": "1", "rel_x": -0.95, "rel_y": -1.30, "width": 0.60, "height": 1.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.00, "rel_y": -1.30, "width": 0.60, "height": 1.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3", "rel_x":  0.95, "rel_y": -1.30, "width": 0.60, "height": 1.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "4", "rel_x":  0.95, "rel_y":  1.30, "width": 0.60, "height": 1.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "5", "rel_x": -0.95, "rel_y":  1.30, "width": 0.60, "height": 1.00, "shape": "rect", "is_thermal": False})
    elif package == "SOT-23-6":
        pads.append({"num": "1", "rel_x": -0.65, "rel_y": -0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.00, "rel_y": -0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3", "rel_x":  0.65, "rel_y": -0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
        pads.append({"num": "4", "rel_x":  0.65, "rel_y":  0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
        pads.append({"num": "5", "rel_x":  0.00, "rel_y":  0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
        pads.append({"num": "6", "rel_x": -0.65, "rel_y":  0.95, "width": 0.40, "height": 0.70, "shape": "rect", "is_thermal": False})
    elif package in ("SMD-2016-4P", "SMD-2020-4P"):
        pads.append({"num": "1", "rel_x": -0.75, "rel_y": -0.55, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.75, "rel_y": -0.55, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3", "rel_x":  0.75, "rel_y":  0.55, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
        pads.append({"num": "4", "rel_x": -0.75, "rel_y":  0.55, "width": 0.60, "height": 0.50, "shape": "rect", "is_thermal": False})
    elif package == "SMD-3225-4P":
        pads.append({"num": "1", "rel_x": -1.10, "rel_y": -0.80, "width": 0.90, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  1.10, "rel_y": -0.80, "width": 0.90, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3", "rel_x":  1.10, "rel_y":  0.80, "width": 0.90, "height": 0.80, "shape": "rect", "is_thermal": False})
        pads.append({"num": "4", "rel_x": -1.10, "rel_y":  0.80, "width": 0.90, "height": 0.80, "shape": "rect", "is_thermal": False})
    elif package == "LGA-8_2.0x2.5mm":
        for i, ry in enumerate([-0.90, -0.30, 0.30, 0.90]):
            pads.append({"num": str(i + 1), "rel_x": -0.75, "rel_y": ry, "width": 0.50, "height": 0.35, "shape": "rect", "is_thermal": False})
        for i, ry in enumerate([0.90, 0.30, -0.30, -0.90]):
            pads.append({"num": str(i + 5), "rel_x":  0.75, "rel_y": ry, "width": 0.50, "height": 0.35, "shape": "rect", "is_thermal": False})
    elif package == "JST-SH-4P-SMD":
        for i, rx in enumerate([-1.50, -0.50, 0.50, 1.50]):
            pads.append({"num": str(i + 1), "rel_x": rx, "rel_y": 1.25, "width": 0.60, "height": 1.30, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH1", "rel_x": -2.80, "rel_y": -1.10, "width": 1.00, "height": 1.60, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH2", "rel_x":  2.80, "rel_y": -1.10, "width": 1.00, "height": 1.60, "shape": "rect", "is_thermal": False})
    elif package == "SMD-1.25mm-2P":
        pads.append({"num": "1", "rel_x": -0.625, "rel_y":  1.20, "width": 0.70, "height": 1.40, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2", "rel_x":  0.625, "rel_y":  1.20, "width": 0.70, "height": 1.40, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH1", "rel_x": -2.10, "rel_y": -1.00, "width": 1.00, "height": 1.50, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH2", "rel_x":  2.10, "rel_y": -1.00, "width": 1.00, "height": 1.50, "shape": "rect", "is_thermal": False})
    elif package == "USB-C-16P-SMD":
        c_xs = [-2.75, -2.25, -1.75, -1.25, -0.75, -0.25, 0.25, 0.75, 1.25, 1.75, 2.25, 2.75]
        for i, cx in enumerate(c_xs):
            pads.append({"num": str(i + 1), "rel_x": cx, "rel_y": 0.0, "width": 0.30, "height": 1.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH1", "rel_x": -4.32, "rel_y": -1.50, "width": 1.20, "height": 2.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH2", "rel_x":  4.32, "rel_y": -1.50, "width": 1.20, "height": 2.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH3", "rel_x": -4.32, "rel_y":  1.50, "width": 1.20, "height": 2.00, "shape": "rect", "is_thermal": False})
        pads.append({"num": "SH4", "rel_x":  4.32, "rel_y":  1.50, "width": 1.20, "height": 2.00, "shape": "rect", "is_thermal": False})
    elif package == "LGA-14_2.5x3.0mm":
        pads.append({"num": "1",  "rel_x": -1.05, "rel_y":  0.75, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "2",  "rel_x": -1.05, "rel_y":  0.25, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "3",  "rel_x": -1.05, "rel_y": -0.25, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "4",  "rel_x": -1.05, "rel_y": -0.75, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "5",  "rel_x": -0.50, "rel_y": -1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
        pads.append({"num": "6",  "rel_x":  0.00, "rel_y": -1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
        pads.append({"num": "7",  "rel_x":  0.50, "rel_y": -1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
        pads.append({"num": "8",  "rel_x":  1.05, "rel_y": -0.75, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "9",  "rel_x":  1.05, "rel_y": -0.25, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "10", "rel_x":  1.05, "rel_y":  0.25, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "11", "rel_x":  1.05, "rel_y":  0.75, "width": 0.475, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "12", "rel_x":  0.50, "rel_y":  1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
        pads.append({"num": "13", "rel_x":  0.00, "rel_y":  1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
        pads.append({"num": "14", "rel_x": -0.50, "rel_y":  1.30, "width": 0.25, "height": 0.475, "shape": "rect", "is_thermal": False})
    elif package == "QFN-24_4x4mm":
        coords = [-1.25, -0.75, -0.25, 0.25, 0.75, 1.25]
        for i, c in enumerate(coords):
            pads.append({"num": str(i + 1), "rel_x": c, "rel_y": -1.95, "width": 0.25, "height": 0.60, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(coords):
            pads.append({"num": str(i + 7), "rel_x": 1.95, "rel_y": c, "width": 0.60, "height": 0.25, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(reversed(coords)):
            pads.append({"num": str(i + 13), "rel_x": c, "rel_y": 1.95, "width": 0.25, "height": 0.60, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(reversed(coords)):
            pads.append({"num": str(i + 19), "rel_x": -1.95, "rel_y": c, "width": 0.60, "height": 0.25, "shape": "rect", "is_thermal": False})
        pads.append({"num": "25", "rel_x": 0.0, "rel_y": 0.0, "width": 2.60, "height": 2.60, "shape": "rect", "is_thermal": True})
    elif package == "QFN-48_6x6mm":
        coords = [-2.20 + i * 0.40 for i in range(12)]
        for i, c in enumerate(coords):
            pads.append({"num": str(i + 1), "rel_x": c, "rel_y": -2.95, "width": 0.20, "height": 0.55, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(coords):
            pads.append({"num": str(i + 13), "rel_x": 2.95, "rel_y": c, "width": 0.55, "height": 0.20, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(reversed(coords)):
            pads.append({"num": str(i + 25), "rel_x": c, "rel_y": 2.95, "width": 0.20, "height": 0.55, "shape": "rect", "is_thermal": False})
        for i, c in enumerate(reversed(coords)):
            pads.append({"num": str(i + 37), "rel_x": -2.95, "rel_y": c, "width": 0.55, "height": 0.20, "shape": "rect", "is_thermal": False})
        pads.append({"num": "49", "rel_x": 0.0, "rel_y": 0.0, "width": 4.40, "height": 4.40, "shape": "rect", "is_thermal": True})
    return pads

NET_LIST = [
    "", "GND", "VBAT", "VBUS", "VIN_LDO", "+3V3_DIG", "+3V3_GYRO", "VCAP1", "NRST", "BOOT0",
    "HSE_IN", "HSE_OUT", "ADC_VBAT", "USB_DM", "USB_DP", "USB_CC1", "USB_CC2",
    "GYRO_CS", "SPI1_SCK", "SPI1_MISO", "SPI1_MOSI", "GYRO_EXTI",
    "ELRS_CS", "SPI3_SCK", "SPI3_MISO", "SPI3_MOSI", "ELRS_EXTI", "ELRS_BUSY",
    "ELRS_RESET", "ELRS_DCC_SW", "ELRS_VREG", "ELRS_XTA", "ELRS_XTB",
    "ELRS_RFIO", "ELRS_RF_MATCH", "ELRS_ANT",
    "I2C1_SCL", "I2C1_SDA", "UART2_TX", "UART2_RX",
    "LED_PWM", "LED_DIN", "LED_D1_2", "LED_D2_3", "LED_D3_4",
    "MOTOR_1_PWM", "MOTOR_2_PWM", "MOTOR_3_PWM", "MOTOR_4_PWM",
    "GATE_M1", "GATE_M2", "GATE_M3", "GATE_M4",
    "M1_NEG", "M2_NEG", "M3_NEG", "M4_NEG"
]
NET_MAP = {name: idx for idx, name in enumerate(NET_LIST)}

def get_component_pin_net(des, pin_num):
    pin = str(pin_num)
    if des == "U1":  # AT32F435CGU7 (QFN-48_6x6mm)
        m = {
            "1": "+3V3_DIG", "2": "ELRS_RESET", "3": "GYRO_EXTI", "4": "GND",
            "5": "HSE_IN", "6": "HSE_OUT", "7": "NRST", "8": "GND", "9": "+3V3_DIG",
            "10": "MOTOR_1_PWM", "11": "MOTOR_2_PWM", "12": "UART2_TX", "13": "UART2_RX",
            "14": "GYRO_CS", "15": "SPI1_SCK", "16": "SPI1_MISO", "17": "SPI1_MOSI",
            "18": "ADC_VBAT", "22": "VCAP1", "23": "GND", "24": "+3V3_DIG",
            "29": "LED_PWM", "30": "I2C1_SCL", "31": "I2C1_SDA",
            "32": "USB_DM", "33": "USB_DP", "35": "GND", "36": "+3V3_DIG",
            "38": "ELRS_CS", "39": "SPI3_SCK", "40": "SPI3_MISO", "41": "SPI3_MOSI",
            "42": "ELRS_EXTI", "43": "ELRS_BUSY", "44": "BOOT0",
            "45": "MOTOR_4_PWM", "46": "MOTOR_3_PWM", "47": "GND", "48": "+3V3_DIG", "49": "GND"
        }
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des in ("Q1", "Q2", "Q3", "Q4"):  # AO3400A Onboard 4-in-1 5.7A Low-Side N-FET ESC (1=Gate, 2=Source, 3=Drain)
        ch = des[1]
        if pin == "1": return f"GATE_M{ch}", NET_MAP[f"GATE_M{ch}"]
        if pin == "2": return "GND", NET_MAP["GND"]
        if pin == "3": return f"M{ch}_NEG", NET_MAP[f"M{ch}_NEG"]
    if des in ("D_M1", "D_M2", "D_M3", "D_M4"):  # B5819WS 40V 1A Schottky Flyback Diode (1=Cathode VBAT, 2=Anode M_NEG)
        ch = des[-1]
        if pin == "1": return "VBAT", NET_MAP["VBAT"]
        return f"M{ch}_NEG", NET_MAP[f"M{ch}_NEG"]
    if des == "U2":  # ICM-42688-P (LGA-14, drop-in SPI1 compatible)
        m = {
            "1": "SPI1_MISO", "2": "", "3": "", "4": "GYRO_EXTI",
            "5": "+3V3_GYRO", "6": "GND", "7": "GND", "8": "+3V3_GYRO",
            "9": "GND", "10": "GND", "11": "GND", "12": "GYRO_CS",
            "13": "SPI1_SCK", "14": "SPI1_MOSI"
        }
        net = m.get(pin, "")
        return net, NET_MAP[net]
    if des == "U3":
        m = {
            "1": "+3V3_DIG", "2": "ELRS_DCC_SW", "3": "GND", "4": "GND", "5": "GND",
            "6": "ELRS_BUSY", "7": "ELRS_EXTI", "8": "ELRS_RESET",
            "9": "ELRS_CS", "10": "SPI3_SCK", "11": "SPI3_MOSI", "12": "SPI3_MISO",
            "13": "GND", "14": "+3V3_DIG", "15": "ELRS_VREG", "16": "+3V3_DIG",
            "17": "ELRS_XTA", "18": "ELRS_XTB", "19": "GND", "20": "GND",
            "21": "GND", "22": "ELRS_RFIO", "23": "GND", "24": "+3V3_DIG", "25": "GND"
        }
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des == "U4":
        m = {"1": "VIN_LDO", "2": "GND", "3": "VIN_LDO", "4": "", "5": "+3V3_DIG"}
        net = m.get(pin, "")
        return net, NET_MAP[net]
    if des == "U5":
        m = {"1": "VIN_LDO", "2": "GND", "3": "VIN_LDO", "4": "", "5": "+3V3_GYRO"}
        net = m.get(pin, "")
        return net, NET_MAP[net]
    if des == "U6":
        m = {
            "1": "GND", "2": "+3V3_DIG", "3": "I2C1_SDA", "4": "I2C1_SCL",
            "5": "GND", "6": "+3V3_DIG", "7": "GND", "8": "+3V3_DIG"
        }
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des == "J_HOVER":
        m = {"1": "VIN_LDO", "2": "GND", "3": "UART2_TX", "4": "UART2_RX", "SH1": "GND", "SH2": "GND"}
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des == "LED1":
        m = {"1": "VIN_LDO", "2": "LED_D1_2", "3": "GND", "4": "LED_DIN"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "LED2":
        m = {"1": "VIN_LDO", "2": "LED_D2_3", "3": "GND", "4": "LED_D1_2"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "LED3":
        m = {"1": "VIN_LDO", "2": "LED_D3_4", "3": "GND", "4": "LED_D2_3"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "LED4":
        m = {"1": "VIN_LDO", "2": "", "3": "GND", "4": "LED_D3_4"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "D1":
        m = {"1": "USB_DM", "2": "GND", "3": "USB_DP", "4": "USB_DP", "5": "VBUS", "6": "USB_DM"}
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des == "D2":
        return ("VIN_LDO", NET_MAP["VIN_LDO"]) if pin == "1" else ("VBUS", NET_MAP["VBUS"])
    if des == "D3":
        return ("VIN_LDO", NET_MAP["VIN_LDO"]) if pin == "1" else ("VBAT", NET_MAP["VBAT"])
    if des == "Y1":
        m = {"1": "HSE_IN", "2": "GND", "3": "HSE_OUT", "4": "GND"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "Y2":
        m = {"1": "ELRS_XTA", "2": "GND", "3": "ELRS_XTB", "4": "GND"}
        return m.get(pin, "GND"), NET_MAP[m.get(pin, "GND")]
    if des == "ANT1":
        return ("ELRS_ANT", NET_MAP["ELRS_ANT"]) if pin == "1" else ("", 0)
    if des == "J1":
        m = {
            "1": "GND", "2": "VBUS", "3": "", "4": "USB_CC1", "5": "USB_DP", "6": "USB_DM",
            "7": "USB_DM", "8": "USB_DP", "9": "USB_CC2", "10": "", "11": "VBUS", "12": "GND",
            "SH1": "GND", "SH2": "GND", "SH3": "GND", "SH4": "GND"
        }
        net = m.get(pin, "GND")
        return net, NET_MAP[net]
    if des in ("J_M1", "J_M2", "J_M3", "J_M4"):
        ch = des[-1]
        if pin == "1": return "VBAT", NET_MAP["VBAT"]
        if pin == "2": return f"M{ch}_NEG", NET_MAP[f"M{ch}_NEG"]
        return "GND", NET_MAP["GND"]
    if des == "L_RF":
        return ("ELRS_DCC_SW", NET_MAP["ELRS_DCC_SW"]) if pin == "1" else ("ELRS_VREG", NET_MAP["ELRS_VREG"])
    if des == "L1_RF":
        return ("ELRS_RFIO", NET_MAP["ELRS_RFIO"]) if pin == "1" else ("ELRS_RF_MATCH", NET_MAP["ELRS_RF_MATCH"])
    if des == "C_BULK":
        return ("VBAT", NET_MAP["VBAT"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C1":
        return ("VCAP1", NET_MAP["VCAP1"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des in ("C2", "C3", "C4", "C5", "C6", "C11", "C22", "C30"):
        return ("+3V3_DIG", NET_MAP["+3V3_DIG"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C7":
        return ("NRST", NET_MAP["NRST"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C8":
        return ("HSE_IN", NET_MAP["HSE_IN"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C9":
        return ("HSE_OUT", NET_MAP["HSE_OUT"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des in ("C10", "C18"):
        return ("VIN_LDO", NET_MAP["VIN_LDO"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des in ("C19", "C20"):
        return ("+3V3_GYRO", NET_MAP["+3V3_GYRO"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C21":
        return ("ELRS_VREG", NET_MAP["ELRS_VREG"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C23":
        return ("ELRS_RFIO", NET_MAP["ELRS_RFIO"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C24":
        return ("ELRS_RF_MATCH", NET_MAP["ELRS_RF_MATCH"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "C25":
        return ("ELRS_RF_MATCH", NET_MAP["ELRS_RF_MATCH"]) if pin == "1" else ("ELRS_ANT", NET_MAP["ELRS_ANT"])
    if des in ("C26", "C27", "C28", "C29"):
        ch = str(int(des[1:]) - 25)
        return ("VBAT", NET_MAP["VBAT"]) if pin == "1" else (f"M{ch}_NEG", NET_MAP[f"M{ch}_NEG"])
    if des == "R1":
        return ("VBAT", NET_MAP["VBAT"]) if pin == "1" else ("ADC_VBAT", NET_MAP["ADC_VBAT"])
    if des == "R2":
        return ("ADC_VBAT", NET_MAP["ADC_VBAT"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "R10":
        return ("USB_CC1", NET_MAP["USB_CC1"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "R11":
        return ("USB_CC2", NET_MAP["USB_CC2"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "R12":
        return ("BOOT0", NET_MAP["BOOT0"]) if pin == "1" else ("GND", NET_MAP["GND"])
    if des == "R_SCL":
        return ("I2C1_SCL", NET_MAP["I2C1_SCL"]) if pin == "1" else ("+3V3_DIG", NET_MAP["+3V3_DIG"])
    if des == "R_SDA":
        return ("I2C1_SDA", NET_MAP["I2C1_SDA"]) if pin == "1" else ("+3V3_DIG", NET_MAP["+3V3_DIG"])
    if des == "R_LED":
        return ("LED_PWM", NET_MAP["LED_PWM"]) if pin == "1" else ("LED_DIN", NET_MAP["LED_DIN"])
    if des in ("R_G1", "R_G2", "R_G3", "R_G4"):
        ch = des[-1]
        return (f"MOTOR_{ch}_PWM", NET_MAP[f"MOTOR_{ch}_PWM"]) if pin == "1" else (f"GATE_M{ch}", NET_MAP[f"GATE_M{ch}"])
    if des in ("R_PD1", "R_PD2", "R_PD3", "R_PD4"):
        ch = des[-1]
        return (f"GATE_M{ch}", NET_MAP[f"GATE_M{ch}"]) if pin == "1" else ("GND", NET_MAP["GND"])
    return "GND", NET_MAP["GND"]

TRACKS = [
    # 50-Ohm RF Pi-Match Chain: U3.22 -> C23 -> L1_RF -> C24 -> C25 -> ANT1
    (-1.95, 7.45, -2.20, 7.45, 0.30, "F.Cu", "ELRS_RFIO"),
    (-2.20, 7.45, -2.20, 10.10, 0.34, "F.Cu", "ELRS_RFIO"),
    (-2.20, 9.80, -4.70, 9.80, 0.25, "F.Cu", "ELRS_RFIO"),
    (-2.20, 11.10, -2.20, 13.00, 0.34, "F.Cu", "ELRS_RF_MATCH"),
    (-2.20, 11.40, -4.70, 11.40, 0.25, "F.Cu", "ELRS_RF_MATCH"),
    (-2.20, 13.00, -3.70, 13.00, 0.30, "F.Cu", "ELRS_RF_MATCH"),
    (-2.70, 13.00, -1.40, 13.20, 0.34, "F.Cu", "ELRS_ANT"),
    # SX1280 DC-DC Inductor L_RF & Crystal Y2
    (-0.75, 5.25, 3.80, 5.25, 0.25, "F.Cu", "ELRS_DCC_SW"),
    (3.80, 5.25, 3.80, 6.40, 0.25, "F.Cu", "ELRS_DCC_SW"),
    (3.80, 8.00, 3.30, 4.80, 0.25, "F.Cu", "ELRS_VREG"),
    (3.80, 8.00, -0.25, 9.15, 0.25, "F.Cu", "ELRS_VREG"),
    (-1.95, 6.95, -3.45, 6.45, 0.20, "F.Cu", "ELRS_XTA"),
    (-1.95, 6.45, -3.45, 7.95, 0.20, "F.Cu", "ELRS_XTB"),
    # SPI1 (U1 -> U2 ICM-42688-P)
    (-2.20, -2.95, -5.20, -2.95, 0.20, "F.Cu", "GYRO_EXTI"),
    (-5.20, -2.95, -6.25, -6.95, 0.20, "F.Cu", "GYRO_EXTI"),
    (2.95, -1.80, -4.70, -4.90, 0.20, "F.Cu", "GYRO_CS"),
    (2.95, -1.40, -5.20, -4.90, 0.20, "F.Cu", "SPI1_SCK"),
    (2.95, -1.00, -6.25, -5.45, 0.20, "F.Cu", "SPI1_MISO"),
    (2.95, -0.60, -5.70, -4.90, 0.20, "F.Cu", "SPI1_MOSI"),
    # SPI3 (U1 -> U3 SX1280)
    (-2.95, 1.80, 0.25, 5.25, 0.20, "F.Cu", "ELRS_CS"),
    (-2.95, 1.40, 0.75, 5.25, 0.20, "F.Cu", "SPI3_SCK"),
    (-2.95, 1.00, 1.95, 7.25, 0.20, "F.Cu", "SPI3_MISO"),
    (-2.95, 0.60, 1.95, 6.75, 0.20, "F.Cu", "SPI3_MOSI"),
    (-2.95, 0.20, 1.95, 4.75, 0.20, "F.Cu", "ELRS_EXTI"),
    (-2.95, -0.20, 1.25, 5.25, 0.20, "F.Cu", "ELRS_BUSY"),
    (-2.60, -2.95, 1.95, 5.25, 0.20, "F.Cu", "ELRS_RESET"),
    # I2C1 Barometer SPL06-001 (U6) & UART2 Optical-Flow/ToF Port (J_HOVER)
    (0.20, 2.95, 5.25, 2.70, 0.20, "F.Cu", "I2C1_SCL"),
    (-0.20, 2.95, 5.25, 2.10, 0.20, "F.Cu", "I2C1_SDA"),
    (1.80, -2.95, 0.50, 3.45, 0.20, "B.Cu", "UART2_TX"),
    (2.20, -2.95, 1.50, 3.45, 0.20, "B.Cu", "UART2_RX"),
    # Onboard 4-in-1 5.7A 32kHz Direct Brushed PWM Gate Drive & 4-Corner Symmetrical High-Current Motor Pads (Top F.Cu!)
    (1.00, -2.95, 6.70, -6.20, 0.25, "F.Cu", "MOTOR_1_PWM"),
    (7.70, -6.20, 6.70, -7.80, 0.25, "F.Cu", "GATE_M1"),
    (7.70, -6.20, 8.65, -8.80, 0.25, "F.Cu", "GATE_M1"),
    (1.40, -2.95, 6.70, 6.20, 0.25, "F.Cu", "MOTOR_2_PWM"),
    (7.70, 6.20, 6.70, 7.80, 0.25, "F.Cu", "GATE_M2"),
    (7.70, 6.20, 8.65, 6.80, 0.25, "F.Cu", "GATE_M2"),
    (-2.95, -1.40, -7.70, -6.20, 0.25, "F.Cu", "MOTOR_3_PWM"),
    (-6.70, -6.20, -7.70, -7.80, 0.25, "F.Cu", "GATE_M3"),
    (-6.70, -6.20, -8.65, -6.80, 0.25, "F.Cu", "GATE_M3"),
    (-2.95, -1.00, -7.70, 6.20, 0.25, "F.Cu", "MOTOR_4_PWM"),
    (-6.70, 6.20, -7.70, 7.80, 0.25, "F.Cu", "GATE_M4"),
    (-6.70, 6.20, -8.65, 8.80, 0.25, "F.Cu", "GATE_M4"),
    # 4-Corner Short Low-Inductance Motor Drain Buses (Q1-Q4 -> D_M1-D_M4 -> Corner Solder Pads M1-/M2-/M3-/M4-)
    (9.60, -6.80, 12.75, -7.10, 1.10, "F.Cu", "M1_NEG"),
    (9.60, -6.80, 11.20, -4.60, 0.90, "F.Cu", "M1_NEG"),
    (9.60, 8.80, 12.75, 7.10, 1.10, "F.Cu", "M2_NEG"),
    (9.60, 8.80, 11.20, 4.60, 0.90, "F.Cu", "M2_NEG"),
    (-9.60, -8.80, -12.75, -7.10, 1.10, "F.Cu", "M3_NEG"),
    (-9.60, -8.80, -11.20, -4.60, 0.90, "F.Cu", "M3_NEG"),
    (-9.60, 6.80, -12.75, 7.10, 1.10, "F.Cu", "M4_NEG"),
    (-9.60, 6.80, -11.20, 4.60, 0.90, "F.Cu", "M4_NEG"),
    # 4-Corner High-Current VBAT Buses (Rear BAT+ Pad -> C_BULK -> Corner Solder Pads M1+/M2+/M3+/M4+)
    (5.80, -12.80, 8.00, -9.20, 1.40, "F.Cu", "VBAT"),
    (8.00, -9.20, 12.75, -9.20, 1.20, "F.Cu", "VBAT"),
    (8.00, -9.20, 8.00, 9.20, 1.40, "F.Cu", "VBAT"),
    (8.00, 9.20, 12.75, 9.20, 1.20, "F.Cu", "VBAT"),
    (-12.00, -1.35, -8.00, -9.20, 1.40, "F.Cu", "VBAT"),
    (-8.00, -9.20, -12.75, -9.20, 1.20, "F.Cu", "VBAT"),
    (-8.00, -9.20, -8.00, 9.20, 1.40, "F.Cu", "VBAT"),
    (-8.00, 9.20, -12.75, 9.20, 1.20, "F.Cu", "VBAT"),
]

# 4-Corner Quick-Swap Motor Solder Pads (Dual-Sided Top+Bottom HASL + 0.85mm PTH Strain-Relief Hole)
# + 2 Rear BT2.0 Battery Pigtail Solder Pads (Dual-Sided Top+Bottom HASL + 1.00mm PTH Hole)
CORNER_SOLDER_PADS = [
    # (name, x, y, width, height, drill_mm, net_name, polarity_sign)
    ("PAD_M1_POS",  12.95, -9.40, 1.90, 1.40, 0.85, "VBAT",   "+"),
    ("PAD_M1_NEG",  12.95, -7.20, 1.90, 1.40, 0.85, "M1_NEG", "-"),
    ("PAD_M2_POS",  12.95,  9.40, 1.90, 1.40, 0.85, "VBAT",   "+"),
    ("PAD_M2_NEG",  12.95,  7.20, 1.90, 1.40, 0.85, "M2_NEG", "-"),
    ("PAD_M3_POS", -12.95, -9.40, 1.90, 1.40, 0.85, "VBAT",   "+"),
    ("PAD_M3_NEG", -12.95, -7.20, 1.90, 1.40, 0.85, "M3_NEG", "-"),
    ("PAD_M4_POS", -12.95,  9.40, 1.90, 1.40, 0.85, "VBAT",   "+"),
    ("PAD_M4_NEG", -12.95,  7.20, 1.90, 1.40, 0.85, "M4_NEG", "-"),
    ("PAD_BAT_POS",  6.10, -13.00, 1.60, 1.40, 0.90, "VBAT",  "+"),
    ("PAD_BAT_NEG", -6.10, -13.00, 1.60, 1.40, 0.90, "GND",   "-"),
]

# ==============================================================================
# 1. GENERATE KICAD 2-LAYER PCB FILE
# ==============================================================================
kicad_content = [
    '(kicad_pcb (version 20221018) (generator pcbnew)',
    '  (general (thickness 1.0))',
    '  (paper "A4")',
    '  (layers',
    '    (0 "F.Cu" signal)',
    '    (31 "B.Cu" signal)',
    '    (32 "B.Adhes" user "B.Adhesive")',
    '    (33 "F.Adhes" user "F.Adhesive")',
    '    (34 "B.Paste" user)',
    '    (35 "F.Paste" user)',
    '    (36 "B.SilkS" user "B.Silkscreen")',
    '    (37 "F.SilkS" user "F.Silkscreen")',
    '    (38 "B.Mask" user)',
    '    (39 "F.Mask" user)',
    '    (44 "Edge.Cuts" user)',
    '    (46 "B.CrtYd" user "B.Courtyard")',
    '    (47 "F.CrtYd" user "F.Courtyard")',
    '    (48 "B.Fab" user)',
    '    (49 "F.Fab" user)',
    '  )',
    '  (setup',
    '    (pad_to_mask_clearance 0.05)',
    '    (solder_mask_min_width 0.08)',
    '  )'
]

for idx, net_name in enumerate(NET_LIST):
    kicad_content.append(f'  (net {idx} "{net_name}")')

kicad_content.extend([
    '  (gr_line (start -12.5 14.5) (end 12.5 14.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_arc (start 12.5 14.5) (mid 13.9142 13.9142) (end 14.5 12.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_line (start 14.5 12.5) (end 14.5 -12.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_arc (start 14.5 -12.5) (mid 13.9142 -13.9142) (end 12.5 -14.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_line (start 12.5 -14.5) (end -12.5 -14.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_arc (start -12.5 -14.5) (mid -13.9142 -13.9142) (end -14.5 -12.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_line (start -14.5 -12.5) (end -14.5 12.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
    '  (gr_arc (start -14.5 12.5) (mid -13.9142 13.9142) (end -12.5 14.5) (stroke (width 0.1) (type solid)) (layer "Edge.Cuts"))',
])

holes = [(12.75, 12.75), (-12.75, 12.75), (-12.75, -12.75), (12.75, -12.75)]
for idx, (hx, hy) in enumerate(holes, 1):
    kicad_content.append(f'  (footprint "MountingHole:MountingHole_2.1mm_M2" (layer "F.Cu") (at {hx:.4f} {hy:.4f})')
    kicad_content.append(f'    (pad "" np_thru_hole circle (at 0 0) (size 2.1 2.1) (drill 2.1) (layers "*.Mask"))')
    kicad_content.append('  )')

for c in components:
    des = c["designator"]
    val = c["value"]
    pkg = c["package"]
    mx, my, rot = c["mid_x"], c["mid_y"], c["rotation"]
    cu_layer = "F.Cu" if c["layer"] == "Top" else "B.Cu"
    silk_layer = "F.SilkS" if c["layer"] == "Top" else "B.SilkS"
    fab_layer = "F.Fab" if c["layer"] == "Top" else "B.Fab"
    paste_layer = "F.Paste" if c["layer"] == "Top" else "B.Paste"
    mask_layer = "F.Mask" if c["layer"] == "Top" else "B.Mask"

    kicad_content.append(f'  (footprint "{pkg}" (layer "{cu_layer}") (at {mx:.4f} {my:.4f} {rot:.1f})')
    kicad_content.append(f'    (property "Reference" "{des}" (at 0 0) (layer "{silk_layer}") (effects (font (size 0.6 0.6) (thickness 0.12))))')
    kicad_content.append(f'    (property "Value" "{val}" (at 0 0) (layer "{fab_layer}") (effects (font (size 0.6 0.6) (thickness 0.12))))')
    for p in get_package_pads(pkg):
        net_name, net_id = get_component_pin_net(des, p["num"])
        layers_str = f'"{cu_layer}" "{paste_layer}" "{mask_layer}"'
        kicad_content.append(f'    (pad "{p["num"]}" smd {p["shape"]} (at {p["rel_x"]:.4f} {p["rel_y"]:.4f}) (size {p["width"]:.4f} {p["height"]:.4f}) (layers {layers_str}) (net {net_id} "{net_name}"))')
    kicad_content.append('  )')

for pad_name, px, py, pw, ph, pdrill, net_name, pol in CORNER_SOLDER_PADS:
    nid = NET_MAP[net_name]
    kicad_content.append(f'  (footprint "Osito:QuickSolderPad_{pw:.1f}x{ph:.1f}mm_PTH" (layer "F.Cu") (at {px:.4f} {py:.4f})')
    kicad_content.append(f'    (property "Reference" "{pad_name}" (at 0 0) (layer "F.SilkS") (effects (font (size 0.6 0.6) (thickness 0.12))))')
    kicad_content.append(f'    (pad "1" thru_hole rect (at 0 0) (size {pw:.4f} {ph:.4f}) (drill {pdrill:.4f}) (layers "*.Cu" "*.Mask") (net {nid} "{net_name}"))')
    kicad_content.append('  )')

vias = [
    (-1.40, 9.50, 1), (-3.00, 9.50, 1), (-1.40, 11.00, 1), (-3.00, 11.00, 1),
    (-1.40, 12.50, 1), (-3.00, 12.50, 1), (0.00, 0.00, 1), (-1.50, 0.00, 1),
    (1.50, 0.00, 1), (0.00, 7.20, 1), (8.40, -2.50, 2), (8.40, 2.50, 2),
    (-8.40, -2.50, 2), (-8.40, 2.50, 2)
]
for vx, vy, vnet in vias:
    kicad_content.append(f'  (via (at {vx:.4f} {vy:.4f}) (size 0.60) (drill 0.30) (layers "F.Cu" "B.Cu") (net {vnet}))')

for x1, y1, x2, y2, w, lyr, net_name in TRACKS:
    nid = NET_MAP[net_name]
    kicad_content.append(f'  (segment (start {x1:.4f} {y1:.4f}) (end {x2:.4f} {y2:.4f}) (width {w:.4f}) (layer "{lyr}") (net {nid}))')

kicad_content.extend([
    '  (zone (net 1) (net_name "GND") (layer "B.Cu") (tstamp 00000000-0000-0000-0000-000000000001)',
    '    (hatch edge 0.5)',
    '    (connect_pads (clearance 0.25))',
    '    (min_thickness 0.25)',
    '    (polygon (pts (xy -7.8 10.0) (xy 7.8 10.0) (xy 7.8 -10.0) (xy -7.8 -10.0)))',
    '  )',
    ')'
])

with open(KICAD_PCB_FILE, "w", encoding="utf-8") as f:
    f.write("\n".join(kicad_content) + "\n")
print(f"Generated 2-Layer Single-Sided SMT KiCad PCB: {os.path.basename(KICAD_PCB_FILE)} ({os.path.getsize(KICAD_PCB_FILE):,} bytes)")

# ==============================================================================
# 2. GENERATE RS-274X GERBERS & EXCELLON DRILLS
# ==============================================================================
def rotate_point(x, y, angle_deg):
    rad = math.radians(angle_deg)
    return (x * math.cos(rad) - y * math.sin(rad), x * math.sin(rad) + y * math.cos(rad))

class GerberWriter:
    def __init__(self, filename, layer_name, file_func):
        self.filename = filename
        self.layer_name = layer_name
        self.file_func = file_func
        self.apertures = {}
        self.aperture_idx = 10
        self.commands = []

    def get_aperture(self, shape, w, h=0.0):
        w, h = round(w, 4), round(h, 4)
        key = (shape, w, h)
        if key not in self.apertures:
            self.apertures[key] = f"D{self.aperture_idx}"
            self.aperture_idx += 1
        return self.apertures[key]

    def flash(self, shape, x, y, w, h=0.0):
        ap = self.get_aperture(shape, w, h)
        self.commands.append(f"{ap}*")
        self.commands.append(f"X{int(round(x * 1000000))}Y{int(round(y * 1000000))}D03*")

    def draw_line(self, x1, y1, x2, y2, width):
        ap = self.get_aperture("C", width)
        self.commands.append(f"{ap}*")
        self.commands.append(f"X{int(round(x1 * 1000000))}Y{int(round(y1 * 1000000))}D02*")
        self.commands.append(f"X{int(round(x2 * 1000000))}Y{int(round(y2 * 1000000))}D01*")

    def fill_polygon(self, pts):
        self.commands.append("G36*")
        for i, (px, py) in enumerate(pts):
            self.commands.append(f"X{int(round(px * 1000000))}Y{int(round(py * 1000000))}{'D02' if i == 0 else 'D01'}*")
        self.commands.append("G37*")

    def write(self):
        lines = [
            "%FSLAX46Y46*%", "%MOMM*%", "%LPD*%",
            "%TF.GenerationSoftware,KiCad,Pcbnew,8.0.0*%",
            f"%TF.CreationDate,{datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}*%",
            "%TF.ProjectId,OSITO_HOVER_FC29_1S_AIO_REV3*%",
            f"%TF.FileFunction,{self.file_func}*%",
            "%TF.FilePolarity,Positive*%"
        ]
        for (shape, w, h), code in sorted(self.apertures.items(), key=lambda item: int(item[1][1:])):
            if shape == "C": lines.append(f"%AD{code}C,{w:.4f}*%")
            elif shape == "R": lines.append(f"%AD{code}R,{w:.4f}X{h:.4f}*%")
        lines.extend(self.commands)
        lines.append("M02*")
        with open(self.filename, "w", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")

g_fcu   = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-F_Cu.gtl"), "F.Cu", "Copper,L1,Top")
g_bcu   = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-B_Cu.gbl"), "B.Cu", "Copper,L2,Bot")
g_fmsk  = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-F_Mask.gts"), "F.Mask", "Soldermask,Top")
g_bmsk  = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-B_Mask.gbs"), "B.Mask", "Soldermask,Bot")
g_fsilk = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-F_Silkscreen.gto"), "F.SilkS", "Legend,Top")
g_bsilk = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-B_Silkscreen.gbo"), "B.SilkS", "Legend,Bot")
g_fpst  = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-F_Paste.gtp"), "F.Paste", "Paste,Top")
g_bpst  = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-B_Paste.gbp"), "B.Paste", "Paste,Bot")
g_edge  = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-Edge_Cuts.gm1"), "Edge.Cuts", "Profile,NP")
g_gko   = GerberWriter(os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-Edge_Cuts.gko"), "Edge.Cuts", "Profile,NP")

for g in (g_edge, g_gko):
    g.draw_line(-12.5, 14.5, 12.5, 14.5, 0.10)
    g.draw_line(14.5, 12.5, 14.5, -12.5, 0.10)
    g.draw_line(12.5, -14.5, -12.5, -14.5, 0.10)
    g.draw_line(-14.5, -12.5, -14.5, 12.5, 0.10)
    for cx, cy, s_deg, e_deg in [(12.5, 12.5, 0, 90), (12.5, -12.5, 270, 360), (-12.5, -12.5, 180, 270), (-12.5, 12.5, 90, 180)]:
        step = (e_deg - s_deg) / 8.0
        for i in range(8):
            a1, a2 = math.radians(s_deg + i * step), math.radians(s_deg + (i + 1) * step)
            g.draw_line(cx + 2.0 * math.cos(a1), cy + 2.0 * math.sin(a1), cx + 2.0 * math.cos(a2), cy + 2.0 * math.sin(a2), 0.10)

for c in components:
    mx, my, rot = c["mid_x"], c["mid_y"], c["rotation"]
    is_top = (c["layer"] == "Top")
    g_cu  = g_fcu if is_top else g_bcu
    g_msk = g_fmsk if is_top else g_bmsk
    g_pst = g_fpst if is_top else g_bpst
    g_slk = g_fsilk if is_top else g_bsilk

    for p in get_package_pads(c["package"]):
        dx, dy = rotate_point(p["rel_x"], p["rel_y"], rot)
        ax, ay = mx + dx, my + dy
        eff_rot = (rot % 180)
        cw = p["width"] if eff_rot == 0.0 else p["height"]
        ch = p["height"] if eff_rot == 0.0 else p["width"]
        g_cu.flash("R", ax, ay, cw, ch)
        g_msk.flash("R", ax, ay, cw + 0.10, ch + 0.10)
        if p["is_thermal"]:
            sub_w, sub_h = cw * 0.38, ch * 0.38
            off_x, off_y = cw * 0.24, ch * 0.24
            for sx in (-off_x, off_x):
                for sy in (-off_y, off_y):
                    g_pst.flash("R", ax + sx, ay + sy, sub_w, sub_h)
        else:
            g_pst.flash("R", ax, ay, cw, ch)
    g_slk.draw_line(mx - 0.35, my - 0.35, mx + 0.35, my - 0.35, 0.12)

for vx, vy, _ in vias:
    g_fcu.flash("C", vx, vy, 0.60)
    g_bcu.flash("C", vx, vy, 0.60)

# Flash 4-Corner Quick-Swap Motor Solder Pads + Rear Battery Pigtail Pads on BOTH Top and Bottom!
for pad_name, px, py, pw, ph, pdrill, net_name, pol in CORNER_SOLDER_PADS:
    g_fcu.flash("R", px, py, pw, ph)
    g_bcu.flash("R", px, py, pw, ph)
    g_fmsk.flash("R", px, py, pw + 0.12, ph + 0.12)
    g_bmsk.flash("R", px, py, pw + 0.12, ph + 0.12)
    # Draw Silkscreen '+' or '-' Polarity Indicator next to each corner solder pad
    sx = px - 1.55 if px > 0 else px + 1.55
    for g_slk in (g_fsilk, g_bsilk):
        g_slk.draw_line(sx - 0.25, py, sx + 0.25, py, 0.15)
        if pol == "+":
            g_slk.draw_line(sx, py - 0.25, sx, py + 0.25, 0.15)

for hx, hy in holes:
    g_fmsk.flash("C", hx, hy, 2.30)
    g_bmsk.flash("C", hx, hy, 2.30)

for x1, y1, x2, y2, w, lyr, _ in TRACKS:
    g_target = g_fcu if lyr == "F.Cu" else g_bcu
    g_target.draw_line(x1, y1, x2, y2, w)

g_bcu.fill_polygon([(-7.8, -10.0), (7.8, -10.0), (7.8, 10.0), (-7.8, 10.0), (-7.8, -10.0)])

for g in (g_fcu, g_bcu, g_fmsk, g_bmsk, g_fsilk, g_bsilk, g_fpst, g_bpst, g_edge, g_gko):
    g.write()

pth_file = os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-PTH.drl")
with open(pth_file, "w", encoding="utf-8") as f:
    lines = ["M48", "METRIC", "T1C0.300", "T2C0.850", "T3C1.000", "%", "G90", "G05", "T1"]
    lines.extend([f"X{vx:.3f}Y{vy:.3f}" for vx, vy, _ in vias])
    lines.append("T2")
    lines.extend([f"X{px:.3f}Y{py:.3f}" for _, px, py, _, _, pdrill, _, _ in CORNER_SOLDER_PADS if abs(pdrill - 0.85) < 0.05])
    lines.append("T3")
    lines.extend([f"X{px:.3f}Y{py:.3f}" for _, px, py, _, _, pdrill, _, _ in CORNER_SOLDER_PADS if abs(pdrill - 1.00) < 0.05])
    lines.append("M30")
    f.write("\n".join(lines) + "\n")

npth_file = os.path.join(GERBERS_DIR, "OSITO_HOVER_FC29_1S-NPTH.drl")
with open(npth_file, "w", encoding="utf-8") as f:
    lines = ["M48", "METRIC", "%", "G90", "G05", "T1C2.100", "T1"]
    lines.extend([f"X{hx:.3f}Y{hy:.3f}" for hx, hy in holes])
    lines.append("M30")
    f.write("\n".join(lines) + "\n")

fab_notes = """================================================================================
TURNKEY AIO FC+ESC MANUFACTURING NOTES: OSITO-HOVER-FC29-1S-AIO (REV 3.0)
"AcroBee65 Bread-and-Butter" 2-Layer Single-Sided SMT 1S 300mAh Hover Trainer FC
================================================================================
- Dimensions       : 29.00 mm x 29.00 mm (2.0 mm corner radius)
- Panelization     : Order as 3x3 V-Score / Mouse-Bite Panel (9 boards per 95x95mm
                     sheet -> qualifies for JLCPCB $2-$7 2-Layer Promo = $0.22/PCB!)
- Layers & Stackup : 2-Layer 1.00 mm FR4 TG150, 1.0 oz Copper, Lead-Free HASL
- SMT Assembly     : 100% of active silicon, ESC FETs, RF, Baro & passives (67 parts)
                     are on TOP SIDE (F.Cu) for Single-Pass SMT Stencil Reflow!
- Onboard ESC Stage: Integrated AcroBee65-Style 4-in-1 5.7A Direct 32kHz PWM N-FET ESC
                     (4x AO3400A 30V 5.7A 19mOhm MOSFETs + 4x B5819WS 40V 1A Schottky
                     Flyback Diodes + 4x 100R Gate Damping + 4x 10kR Gate Pull-Downs)
- Hover Sensors    : ICM-42688-P Gyro (SPI1) + SPL06-001 Barometer (U6, I2C1) +
                     4-Pin JST-SH (J_HOVER) for MTF-01 Optical-Flow + ToF LiDAR
================================================================================
"""
with open(FAB_NOTES_FILE, "w", encoding="utf-8") as f:
    f.write(fab_notes)

zip_members = [
    g_fcu.filename, g_bcu.filename, g_fmsk.filename, g_bmsk.filename,
    g_fsilk.filename, g_bsilk.filename, g_fpst.filename, g_bpst.filename,
    g_edge.filename, g_gko.filename, pth_file, npth_file,
    FAB_NOTES_FILE, BOM_FILE, CPL_FILE, CLI_FILE
]
with zipfile.ZipFile(ZIP_ARCHIVE_FILE, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for fp in zip_members:
        zf.write(fp, os.path.basename(fp))

print(f"Created Turnkey AIO FC+ESC PCBA Handoff ZIP: {os.path.basename(ZIP_ARCHIVE_FILE)} ({os.path.getsize(ZIP_ARCHIVE_FILE):,} bytes)")
print("=" * 92)
