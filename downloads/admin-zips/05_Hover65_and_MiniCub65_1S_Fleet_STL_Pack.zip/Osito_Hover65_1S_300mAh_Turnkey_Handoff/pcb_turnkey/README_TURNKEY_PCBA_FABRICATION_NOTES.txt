================================================================================
TURNKEY AIO FC+ESC MANUFACTURING NOTES: OSITO-HOVER-FC29-1S-AIO (REV 3.0)
"AcroBee65 Bread-and-Butter" 2-Layer Single-Sided SMT 1S 300mAh Hover Trainer FC
================================================================================
- Dimensions       : 29.00 mm x 29.00 mm (2.0 mm corner radius)
- Panelization     : Order as 3x3 V-Score / Mouse-Bite Panel (9 boards per 95x95mm
                     sheet -> qualifies for JLCPCB $2-$7 2-Layer Promo = $0.22/PCB!)
- Layers & Stackup : 2-Layer 1.00 mm FR4 TG150, 1.0 oz Copper, Lead-Free HASL
- SMT Assembly     : 100% of active silicon, ESC FETs, RF, Baro & passives (67 parts)
                     are on TOP SIDE (F.Cu) for Single-Pass SMT Stencil Reflow!
- Onboard ESC Stage: Integrated AcroBee65-Style 4-in-1 5.7A Direct 32kHz PWM N-FET ESC
                     (4x AO3400A 30V 5.7A 19mOhm MOSFETs + 4x B5819WS 40V 1A Schottky
                     Flyback Diodes + 4x 100R Gate Damping + 4x 10kR Gate Pull-Downs)
- Hover Sensors    : ICM-42688-P Gyro (SPI1) + SPL06-001 Barometer (U6, I2C1) +
                     4-Pin JST-SH (J_HOVER) for MTF-01 Optical-Flow + ToF LiDAR
================================================================================
