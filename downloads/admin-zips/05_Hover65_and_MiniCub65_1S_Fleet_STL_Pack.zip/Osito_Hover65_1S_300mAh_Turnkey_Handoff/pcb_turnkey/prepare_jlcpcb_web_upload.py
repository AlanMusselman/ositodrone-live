"""
Generates the 3 exact JLCPCB Web Quote Upload files in JLCPCB_WEB_UPLOAD_READY/:
1. 1_UPLOAD_FIRST_Gerbers_JLCPCB.zip (Pure RS-274X Gerbers + Excellon Drill only)
2. 2_UPLOAD_SECOND_BOM_JLCPCB.csv (Exact JLCPCB 4-column header: Comment,Designator,Footprint,LCSC Part #)
3. 3_UPLOAD_THIRD_CPL_JLCPCB.csv (Exact JLCPCB 5-column header: Designator,Mid X,Mid Y,Layer,Rotation)
"""
import os
import csv
import zipfile

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
pcb_dir = os.path.join(base_dir, "pcb_turnkey")
gerber_dir = os.path.join(pcb_dir, "gerbers")
upload_dir = os.path.join(base_dir, "JLCPCB_WEB_UPLOAD_READY")
os.makedirs(upload_dir, exist_ok=True)

# 1. Pure Gerber + Drill ZIP for JLCPCB Step 1 ('Add Gerber File')
gerber_zip = os.path.join(upload_dir, "1_UPLOAD_FIRST_Gerbers_JLCPCB.zip")
with zipfile.ZipFile(gerber_zip, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in sorted(os.listdir(gerber_dir)):
        if f.lower().endswith((".gtl", ".gbl", ".gts", ".gbs", ".gto", ".gbo", ".gtp", ".gbp", ".gm1", ".drl")):
            zf.write(os.path.join(gerber_dir, f), f)

# 2. Pure JLCPCB 4-Column SMT BOM CSV for Step 2 ('Add BOM File')
src_bom = os.path.join(pcb_dir, "OSITO_HOVER_FC29_1S_BOM_JLCPCB.csv")
jlc_bom = os.path.join(upload_dir, "2_UPLOAD_SECOND_BOM_JLCPCB.csv")
bom_rows = []
with open(src_bom, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row.get("Supplier") == "LCSC" and row.get("Supplier_PN", "").startswith("C"):
            des_comma = ",".join(row["Designator"].split())
            bom_rows.append({
                "Comment": row["MPN"],
                "Designator": des_comma,
                "Footprint": row["Package"],
                "LCSC Part #": row["Supplier_PN"]
            })

with open(jlc_bom, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["Comment", "Designator", "Footprint", "LCSC Part #"])
    writer.writeheader()
    writer.writerows(bom_rows)

# 3. Pure JLCPCB 5-Column CPL Pick-and-Place CSV for Step 3 ('Add CPL File')
src_cpl = os.path.join(pcb_dir, "OSITO_HOVER_FC29_1S_CPL_PickAndPlace.csv")
jlc_cpl = os.path.join(upload_dir, "3_UPLOAD_THIRD_CPL_JLCPCB.csv")
cpl_rows = []
with open(src_cpl, "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        cpl_rows.append({
            "Designator": row["Designator"],
            "Mid X": f"{row['Mid X (mm)']}mm",
            "Mid Y": f"{row['Mid Y (mm)']}mm",
            "Layer": row["Layer"],
            "Rotation": row["Rotation"]
        })

with open(jlc_cpl, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["Designator", "Mid X", "Mid Y", "Layer", "Rotation"])
    writer.writeheader()
    writer.writerows(cpl_rows)

print("SUCCESS:")
print("  1.", gerber_zip, f"({os.path.getsize(gerber_zip)} bytes)")
print("  2.", jlc_bom, f"({len(bom_rows)} LCSC BOM lines)")
print("  3.", jlc_cpl, f"({len(cpl_rows)} CPL placements)")
