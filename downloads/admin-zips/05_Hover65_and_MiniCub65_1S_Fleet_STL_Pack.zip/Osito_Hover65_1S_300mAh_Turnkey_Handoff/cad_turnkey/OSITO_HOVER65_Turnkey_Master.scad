// ============================================================================
// OSITO HOVER-65 & OSITO-HOVER-FC29-1S: Turnkey 1S 300mAh Hover Trainer CAD Suite
// AcroBee65 / Cockroach-65 Inspired Camera-Less (No-Cam) 10x10 ft Popup Tent Edition
// ============================================================================
// PART_ID Selection:
//   1 = OSITO_HOVER65_Frame_65mm_1S_300mAh.stl          (AcroBee65-Inspired Camera-Less Tent-Safe 65mm Frame)
//   2 = OSITO_HOVER65_Canopy_HoverDome_LED.stl          (BeeBrain-Lite Inspired No-Cam LOS Hover Shell + Arrow)
//   3 = OSITO_HOVER65_OpticalFlow_ToF_Underbelly_Pod.stl(Snap-On MTF-01 OptFlow + ToF Carrier)
//   4 = OSITO_HOVER65_GuideRod_Gimbal_Collar.stl        (Stage-1 Twin-Rod Gimbal Slider Collar)
//   5 = OSITO_HOVER65_Tabletop_Base_4x300mAh_Dock.stl   (Tabletop Hover Rig Base + 4x 300mAh Dock)
//   6 = OSITO_HOVER65_Tabletop_Top_Stopper_Bridge.stl   (Top Rod Stopper Bridge + Altitude Clips)
//   7 = OSITO_HOVER65_FC29_1S_Mechanical_Mockup.stl     (29x29mm 1S Hover FC+12A ESC 3D Mechanical Check)
//   8 = OSITO_HOVER65_Tent_Hover_Target_Pad_Marker.stl  (10x10 Tent Floor Optical-Flow Bullseye & Gate Anchor Pad)
// ============================================================================

PART_ID = 1;
$fn = 64;

// --- Core 65mm 1S 300mAh Hover Drone Parameters ---
wheelbase       = 65.0;                     // 65mm diagonal motor-to-motor (AcroBee65 class)
motor_r         = wheelbase / 2.0;          // 32.5mm radial distance
motor_xy        = motor_r * cos(45);        // 22.981mm X/Y motor center
motor_id        = 6.10;                     // 6mm (0615) brushed motor slip-fit ID
motor_od        = 8.60;                     // Reinforced motor pod OD
motor_pod_h     = 12.5;                     // Supports 15mm tall 0615 brushed motor can
duct_id         = 32.6;                     // 31mm 4-blade prop + 0.8mm radial tip clearance
duct_od         = 35.0;                     // 1.2mm primary duct wall thickness
duct_h          = 7.5;                      // Full prop-plane shroud height
fc_mount_span   = 25.5;                     // Standard Whoop 25.5 x 25.5mm M2 pattern
fc_hole_d       = 2.1;                      // M2 screw/grommet hole

// --- 1S 300mAh LiHV Battery Bay Parameters (BT2.0 Pack: 38 x 11.2 x 6.4mm) ---
bat_w           = 11.8;                     // 11.2mm cell width + 0.6mm slip clearance
bat_h           = 6.8;                      // 6.4mm cell thickness + 0.4mm slip clearance
bat_l           = 40.0;                     // 40mm longitudinal cradle length

// --- Hover Station Rod Parameters ---
rod_span        = 96.0;                     // X = -48mm, +48mm twin carbon rods
rod_d           = 4.20;                     // 4.0mm OD carbon rod socket
rod_y           = -12.0;                    // Forward-shifted rod/drone center

// ============================================================================
// PART 1: ACROBEE65 / COCKROACH-65 INSPIRED CAMERA-LESS TENT-SAFE 65MM AIRFRAME
//   - 360-Deg Smooth Anti-Snag Tent-Net Deflection Perimeter Bumper Ring
//   - Upper & Lower Chamfered Rim (zero sharp exterior hooks against 10x10 tent mesh)
//   - AcroBee65-Style 3-Rib Top Finger & Tent-Net Guard Arches over each 31mm prop
//   - 3x Bottom Aerodynamic Stator Struts + 4x Wide Landing Feet + 1S 300mAh Cradle
// ============================================================================
module hover65_frame_1s_300mah() {
    union() {
        difference() {
            union() {
                // 1. 4x Aerodynamic Prop Guard Ducts with Upper/Lower Chamfered Anti-Snag Tent-Net Rims
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * motor_xy, sy * motor_xy, 0]) {
                        cylinder(d = duct_od, h = duct_h);
                        // Bottom chamfered anti-snag bumper ring (no 90-deg catch step on tent net!)
                        cylinder(d1 = duct_od, d2 = duct_od + 1.6, h = 0.8);
                        translate([0, 0, 0.8])
                            cylinder(d1 = duct_od + 1.6, d2 = duct_od, h = 0.9);
                        // Top chamfered anti-snag bumper ring
                        translate([0, 0, duct_h - 1.7])
                            cylinder(d1 = duct_od, d2 = duct_od + 1.6, h = 0.9);
                        translate([0, 0, duct_h - 0.8])
                            cylinder(d1 = duct_od + 1.6, d2 = duct_od, h = 0.8);
                    }
                }

                // 2. 360-Deg Smooth Anti-Snag Tent-Net Deflection Perimeter Bumper Bridges
                //    (Kept at Z = 0 to 5.2mm so Stage-1 Slider Collar outriggers clear above!)
                for (sx = [-1, 1]) {
                    // Outer tangent anti-snag deflection rail (Left & Right sides)
                    hull() {
                        translate([sx * (motor_xy + 15.8), -motor_xy * 0.48, 0.6]) cylinder(d = 2.6, h = 4.0);
                        translate([sx * (motor_xy + 15.8),  motor_xy * 0.48, 0.6]) cylinder(d = 2.6, h = 4.0);
                        translate([sx * (motor_xy + 8.0),  -8.5, 0]) cylinder(d = 3.2, h = 5.2);
                        translate([sx * (motor_xy + 8.0),   8.5, 0]) cylinder(d = 3.2, h = 5.2);
                    }
                }
                for (sy = [-1, 1]) {
                    // Outer tangent anti-snag deflection rail (Front & Rear sides)
                    hull() {
                        translate([-motor_xy * 0.48, sy * (motor_xy + 15.8), 0.6]) cylinder(d = 2.6, h = 4.0);
                        translate([ motor_xy * 0.48, sy * (motor_xy + 15.8), 0.6]) cylinder(d = 2.6, h = 4.0);
                        translate([-8.5, sy * (motor_xy + 8.0), 0]) cylinder(d = 3.2, h = 5.2);
                        translate([ 8.5, sy * (motor_xy + 8.0), 0]) cylinder(d = 3.2, h = 5.2);
                    }
                }

                // 3. 4x Motor Pods (6.10mm ID, Z = -5.0mm to +7.5mm) + 4x Landing Skid Feet (Z = -6.8mm)
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * motor_xy, sy * motor_xy, -5.0]) {
                        cylinder(d = motor_od, h = motor_pod_h);
                        // Wide stable landing foot at bottom of each motor pod (flush with Z = -6.8mm battery floor)
                        translate([0, 0, -1.8])
                            cylinder(d1 = 10.0, d2 = motor_od, h = 2.0);
                    }
                    // 3x Bottom Aerodynamic Stator-Struts per Duct
                    for (ang = [45, 165, 285]) {
                        translate([sx * motor_xy, sy * motor_xy, 0])
                            rotate([0, 0, ang])
                                translate([0, -1.1, 0])
                                    cube([duct_id / 2.0 + 0.5, 2.2, 3.2]);
                    }
                }

                // 4. Diagonal X-Frame Carbon-Profile Beams + 25.5x25.5mm FC Standoffs
                //    + REV 3.1 Diagonal Wire-Guide Channels & Corner Solder-Pad Strain-Relief Arms
                for (sx = [-1, 1], sy = [-1, 1]) {
                    // Primary diagonal structural beam (Center to Motor Pod)
                    hull() {
                        translate([0, 0, 0]) cylinder(d = 5.6, h = 3.6);
                        translate([sx * motor_xy, sy * motor_xy, 0]) cylinder(d = 4.8, h = 3.6);
                    }
                    // Dedicated motor-wire guide arm branch from Motor Pod (±22.98, ±22.98) directly to FC Corner Pad Bay (±12.8, ±8.15)
                    hull() {
                        translate([sx * motor_xy, sy * motor_xy, 0]) cylinder(d = 4.6, h = 3.4);
                        translate([sx * 14.2, sy * 8.15, 0]) cylinder(d = 4.2, h = 3.4);
                    }
                    // 25.5 x 25.5mm FC Standoff Bosses (Z = 0 to 7.5mm) + Alignment Pin Boss (Z = 7.5 to 9.0mm)
                    // Tapered to 5.0mm OD so Y = ±9.2mm solder pads have 100% unobstructed iron access
                    translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), 0]) {
                        cylinder(d = 5.0, h = 7.5);
                        cylinder(d = 3.6, h = 9.0);
                    }
                }

                // 5. Central 1S 300mAh LiHV Underbelly Battery Cradle (Z = -6.8mm to +3.6mm)
                translate([-(bat_w + 3.6) / 2.0, -bat_l / 2.0, -bat_h])
                    cube([bat_w + 3.6, bat_l, bat_h + 3.6]);
            }

            // --- Subtractions ---
            // A. 4x Duct Bores (32.6mm ID) — preserving central motor pod & bottom struts
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    difference() {
                        translate([0, 0, 3.0]) cylinder(d = duct_id, h = duct_h + 2.0);
                        cylinder(d = motor_od + 0.2, h = duct_h + 3.0);
                    }
                    difference() {
                        translate([0, 0, -0.5]) cylinder(d = duct_id, h = 3.7);
                        cylinder(d = motor_od + 0.2, h = 4.0);
                        for (ang = [45, 165, 285]) {
                            rotate([0, 0, ang])
                                translate([0, -1.2, -1.0])
                                    cube([duct_id / 2.0 + 1.0, 2.4, 5.0]);
                        }
                    }
                }
            }

            // B. 4x 6.10mm Brushed Motor Bores + Bottom Retention Lip (5.2mm ID) + Expansion Slit
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    translate([0, 0, -4.0]) cylinder(d = motor_id, h = 15.0);
                    translate([0, 0, -7.5]) cylinder(d = 5.2, h = 4.5);
                    rotate([0, 0, (sx * sy > 0) ? 45 : -45])
                        translate([-0.6, 0, -4.0])
                            cube([1.2, 6.0, 13.0]);
                }
            }

            // C. 4x 25.5 x 25.5mm M2 FC Mounting Screw Holes
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -2.0])
                    cylinder(d = fc_hole_d, h = 14.0);
            }

            // D. 1S 300mAh LiHV Battery Tunnel (11.8mm wide x 6.8mm high, Z = -5.2mm to +1.6mm)
            translate([-bat_w / 2.0, -bat_l / 2.0 - 1.0, -5.2])
                cube([bat_w, bat_l + 2.0, bat_h]);

            // E. Side Weight-Reduction & Battery Grip Windows in Cradle Walls
            for (sy = [-11.0, 11.0]) {
                translate([-12.0, sy - 5.0, -4.2])
                    cube([24.0, 10.0, 4.8]);
            }

            // F. Bottom Central Optical-Flow / Battery Push-Out Window (8.0 x 16.0mm)
            translate([-4.0, -8.0, -8.0])
                cube([8.0, 16.0, 4.0]);

            // G. REV 3.1: 4x Diagonal Arm Wire-Retention Channels & Strain-Relief Slots
            //    Routes twisted 28AWG motor leads from motor mounts (±22.98, ±22.98) directly to FC corner bays (±12.8, ±8.15)
            for (sx = [-1, 1], sy = [-1, 1]) {
                // Snap-in wire retention channel along the motor-to-corner-bay arm (Z = 1.6mm to +4.2mm)
                hull() {
                    translate([sx * (motor_xy - 2.6), sy * (motor_xy - 2.6), 1.6])
                        cylinder(d = 1.5, h = 2.6);
                    translate([sx * 14.2, sy * 8.15, 1.6])
                        cylinder(d = 1.5, h = 2.6);
                }
                // Secondary diagonal arm wire trough (from motor pod toward inner corner bay)
                hull() {
                    translate([sx * (motor_xy - 2.6), sy * (motor_xy - 2.6), -1.2])
                        cylinder(d = 1.5, h = 2.4);
                    translate([sx * 14.2, sy * 8.15, -1.2])
                        cylinder(d = 1.5, h = 2.4);
                }
                // Strain-relief vertical wire feed slot at the arm-to-PCB corner exit (±14.2, ±8.15)
                translate([sx * 14.2, sy * 8.15, -1.0])
                    cylinder(d = 2.0, h = 5.5);

                // H. REV 3.1: Top & Bottom Corner Solder-Iron Access Bays at (±12.8mm, ±7.1mm..±9.2mm)
                //    Unobstructed 360-deg iron tip clearance around M1±, M2±, M3±, M4± corner motor pads
                hull() {
                    translate([sx * 12.8, sy * 6.6, -2.0])
                        cylinder(d = 4.6, h = 11.5);
                    translate([sx * 12.8, sy * 9.5, -2.0])
                        cylinder(d = 4.6, h = 11.5);
                }
            }
        }

        // 6. AcroBee65-Inspired Top Finger-Guard & Tent-Net Safety Arches (3 radial arches + central hub ring per duct)
        //    Positioned above the Z = 3.2..6.8mm propeller plane so 31mm 4-blade props spin freely below
        //    while fingers and 10x10 popup tent netting can NEVER enter the blades from above!
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 0]) {
                // Top central finger-guard ring (Z = 7.4mm to 8.8mm, above motor shaft tip)
                difference() {
                    translate([0, 0, duct_h - 0.1])
                        cylinder(d1 = 8.4, d2 = 7.2, h = 1.5);
                    translate([0, 0, duct_h - 0.5])
                        cylinder(d = 4.2, h = 2.5);
                }
                // 3x Radial Top Safety Ribs arching from outer duct rim (Z = 6.3..7.5mm) to top central ring (Z = 7.4..8.8mm)
                // Oriented at 105, 225, 345 deg so they never block the inner 25.5x25.5mm FC mounting posts!
                for (ang = [105, 225, 345]) {
                    rotate([0, 0, ang]) {
                        hull() {
                            translate([3.2, -0.9, duct_h - 0.1])
                                cube([1.4, 1.8, 1.5]);
                            translate([duct_id / 2.0 - 0.2, -1.0, duct_h - 1.2])
                                cube([1.4, 2.0, 1.2]);
                        }
                    }
                }
            }
        }
    }
}

// ============================================================================
// PART 2: ACROBEE65 BEEBRAIN-LITE INSPIRED CAMERA-LESS (NO-CAM) LOS HOVER SHELL
//   - Zero Camera Hole / Zero VTX Antenna Hole (100% Camera-Less Tent Trainer!)
//   - Smooth Anti-Snag Tent-Net Roll-Over Dome (Supports AUX3 Turtle Mode on tent floor)
//   - Oversized High-Visibility Student Forward Orientation Arrow (+Y Nose Pointer)
//   - 4x Corner WS2812B LED Light-Pipe Windows + SPL06-001 Baro Port + ESC Louvers
// ============================================================================
module hover65_canopy_dome_led() {
    difference() {
        union() {
            // 1. 4x M2 Mounting Ears at 25.5 x 25.5mm Whoop Pattern
            for (sx = [-1, 1], sy = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), 0])
                        cylinder(d = 6.4, h = 2.2);
                    translate([sx * 9.0, sy * 9.0, 0])
                        cylinder(d = 5.4, h = 2.2);
                }
            }
            // 2. Sleek AcroBee65 BeeBrain-Lite Inspired Camera-Less Roll-Over Dome
            hull() {
                translate([0, 0, 0]) cylinder(d = 28.4, h = 2.2);
                translate([0, -1.0, 9.2]) sphere(d = 15.2);
                translate([0,  3.5, 7.0]) sphere(d = 12.0);
            }
            // 3. Smooth Anti-Snag Longitudinal Turtle-Mode Roll Spine
            hull() {
                translate([0, -9.5, 4.2]) sphere(d = 4.4);
                translate([0, -1.0, 10.6]) sphere(d = 5.0);
                translate([0,  8.5, 4.8]) sphere(d = 4.0);
            }
            // 4. Oversized High-Visibility Student Forward Orientation Arrow (+Y Nose Pointer)
            //    Allows kids outside the 10x10 popup tent net to read heading instantly
            translate([0, 9.2, 1.4])
                linear_extrude(height = 3.2)
                    polygon(points = [[0, 7.6], [-5.2, -1.2], [-2.2, -1.2], [-2.2, -4.5], [2.2, -4.5], [2.2, -1.2], [5.2, -1.2]]);
        }

        // A. Hollow Interior Cavity over 29x29mm AIO FC+ESC (1.8mm wall thickness)
        hull() {
            translate([0, 0, -0.5]) cylinder(d = 24.8, h = 2.4);
            translate([0, -1.0, 8.4]) sphere(d = 11.6);
            translate([0,  3.5, 6.2]) sphere(d = 8.6);
        }

        // B. 4x M2 Mounting Holes (25.5 x 25.5mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -1.0])
                cylinder(d = 2.3, h = 6.0);
        }

        // C. 4x Corner WS2812B Orientation LED Light-Pipe Windows (Front Green, Rear Orange)
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang])
                translate([8.0, -2.4, 2.8])
                    cube([10.0, 4.8, 5.2]);
        }

        // D. Side Cooling Louvers for Onboard 4-in-1 12A H-Bridge ESC MOSFETs (AO4614B at X = +-10.6mm)
        for (sx = [-1, 1], wy = [-3.5, 0.0, 3.5]) {
            translate([sx * 11.5 - 3.5, wy - 0.9, 2.4])
                cube([7.0, 1.8, 4.8]);
        }

        // E. Top Barometer (SPL06-001) Static Pressure Equalization Port (Protected from prop wash)
        translate([0, -1.0, 10.5])
            cylinder(d = 3.0, h = 9.0);

        // F. REV 3.1: 4x Corner Quick-Swap Motor Solder-Iron Access Scallops at (±12.8mm, ±7.1..±9.2mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            hull() {
                translate([sx * 12.8, sy * 6.8, -0.5]) cylinder(d = 4.4, h = 4.0);
                translate([sx * 12.8, sy * 9.4, -0.5]) cylinder(d = 4.4, h = 4.0);
            }
        }
    }
}

// ============================================================================
// PART 3: SNAP-ON UNDERBELLY OPTICAL-FLOW + TOF LIDAR POD (MTF-01 / VL53L1X)
// ============================================================================
module hover65_optflow_tof_pod() {
    difference() {
        union() {
            // Main Underbelly Sensor Housing (18 x 22 x 5.5mm)
            translate([-9.0, -11.0, 0])
                cube([18.0, 22.0, 5.5]);
            // Twin Snap-Fit Clips that grip the 15.4mm OD 1S 300mAh Battery Cradle
            for (sx = [-1, 1]) {
                translate([sx * 8.6 - 1.2, -9.0, 5.0])
                    cube([2.4, 18.0, 6.2]);
                translate([sx * 7.6 - 0.8, -9.0, 10.2])
                    cube([1.6, 18.0, 1.4]);
            }
        }
        // Internal Pocket for MTF-01 / PMW3901+VL53L1X Sensor PCB (14.4 x 18.4 x 4.2mm)
        translate([-7.2, -9.2, 1.6])
            cube([14.4, 18.4, 5.0]);
        // Optical Flow Camera Lens Aperture (d = 5.5mm at Y = -3.5mm)
        translate([0, -3.5, -1.0])
            cylinder(d = 5.5, h = 4.0);
        // ToF Laser Ranger Window (6.0 x 4.5mm at Y = +4.0mm)
        translate([-3.0, 1.8, -1.0])
            cube([6.0, 4.5, 4.0]);
        // Rear Wire Exit Slot for 4-Pin JST-SH Cable to J_HOVER
        translate([-3.5, -12.0, 2.0])
            cube([7.0, 4.0, 4.5]);
    }
}

// ============================================================================
// PART 4: STAGE-1 TWIN-ROD GIMBAL SLIDER COLLAR (25.5x25.5mm Mount)
// ============================================================================
module hover65_guiderod_gimbal_collar() {
    difference() {
        union() {
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), 0])
                    cylinder(d = 6.0, h = 4.4);
            }
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), -fc_mount_span / 2.0, 1.8]) cylinder(d = 4.2, h = 2.6);
                    translate([sx * (fc_mount_span / 2.0),  fc_mount_span / 2.0, 1.8]) cylinder(d = 4.2, h = 2.6);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-fc_mount_span / 2.0, sy * (fc_mount_span / 2.0), 1.8]) cylinder(d = 4.2, h = 2.6);
                    translate([ fc_mount_span / 2.0, sy * (fc_mount_span / 2.0), 1.8]) cylinder(d = 4.2, h = 2.6);
                }
            }
            // Peaked Roll-Arch
            hull() {
                translate([-fc_mount_span / 2.0, -3.0, 3.6]) cube([3.2, 6.0, 1.2]);
                translate([-1.6, -3.0, 12.0]) cube([3.2, 6.0, 2.2]);
            }
            hull() {
                translate([fc_mount_span / 2.0 - 3.2, -3.0, 3.6]) cube([3.2, 6.0, 1.2]);
                translate([-1.6, -3.0, 12.0]) cube([3.2, 6.0, 2.2]);
            }
            // Twin Outrigger Arms to X = +-48.0mm
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), 0, 1.8]) cylinder(d = 6.0, h = 2.8);
                    translate([sx * 36.0, 0, 1.8]) cylinder(d = 6.0, h = 2.8);
                }
                hull() {
                    translate([sx * 36.0, 0, 1.8]) cylinder(d = 6.0, h = 2.8);
                    translate([sx * (rod_span / 2.0), 0, 1.8]) cylinder(d = 12.4, h = 3.2);
                }
                translate([sx * (rod_span / 2.0), 0, 0])
                    cylinder(d = 12.8, h = 10.0);
            }
        }
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -1.0])
                cylinder(d = 2.2, h = 8.0);
            translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -0.2])
                cylinder(d = 4.1, h = 1.6);
        }
        // Flared Bell-Mouth Gimbal Bushings (+/-18 deg Pitch/Roll Freedom)
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), 0, 0]) {
                translate([0, 0, -0.5]) cylinder(d = 6.8, h = 11.0);
                translate([0, 0, -0.2]) cylinder(d1 = 9.0, d2 = 6.8, h = 3.6);
                translate([0, 0, 6.6])  cylinder(d1 = 6.8, d2 = 9.0, h = 3.6);
            }
        }
    }
}

// ============================================================================
// PART 5: TABLETOP HOVER BASE PAD + 4-SLOT 1S 300mAh BATTERY DOCK
// ============================================================================
module hover65_tabletop_base() {
    difference() {
        union() {
            hull() {
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 64.0, sy * 52.0, 0])
                        cylinder(r = 14.0, h = 8.0);
                }
            }
            translate([0, rod_y, 7.8]) {
                difference() {
                    cylinder(d = 76.0, h = 1.8);
                    translate([0, 0, -0.2]) cylinder(d = 68.0, h = 2.4);
                }
                difference() {
                    cylinder(d = 46.0, h = 1.8);
                    translate([0, 0, -0.2]) cylinder(d = 38.0, h = 2.4);
                }
                cylinder(d = 14.0, h = 1.8);
            }
            for (sx = [-1, 1]) {
                translate([sx * (rod_span / 2.0), rod_y, 0]) {
                    cylinder(d1 = 22.0, d2 = 14.0, h = 26.0);
                    for (ang = [0, 90, 180, 270]) {
                        rotate([0, 0, ang])
                            translate([-1.5, 0, 0])
                                cube([3.0, 12.0, 18.0]);
                    }
                }
            }
            translate([-46.0, 38.0, 0])
                cube([92.0, 20.0, 22.0]);
        }
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), rod_y, 4.0])
                cylinder(d = rod_d, h = 23.0);
            translate([sx * (rod_span / 2.0), rod_y, 24.5])
                cylinder(d1 = rod_d, d2 = 5.8, h = 1.7);
        }
        for (i = [-1.5, -0.5, 0.5, 1.5]) {
            translate([i * 21.0 - 6.2, 42.3, 4.0])
                cube([12.4, 7.4, 20.0]);
        }
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 64.0, sy * 52.0, -1.0])
                cylinder(d = 4.5, h = 12.0);
        }
    }
}

// ============================================================================
// PART 6: TOP CARBON-ROD STOPPER BRIDGE
// ============================================================================
module hover65_top_stopper_bridge() {
    difference() {
        union() {
            for (sx = [-1, 1]) {
                translate([sx * (rod_span / 2.0), 0, 0])
                    cylinder(d = 13.0, h = 18.0);
            }
            hull() {
                for (sx = [-1, 1]) {
                    translate([sx * (rod_span / 2.0), 0, 11.0])
                        cylinder(d = 10.0, h = 7.0);
                }
            }
            translate([0, 0, 11.0])
                cylinder(d = 16.0, h = 7.0);
        }
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), 0, -1.0])
                cylinder(d = rod_d, h = 15.0);
            translate([sx * (rod_span / 2.0), 0, -0.2])
                cylinder(d1 = 5.8, d2 = rod_d, h = 1.7);
        }
        translate([0, 0, 10.0])
            cylinder(d = 6.0, h = 10.0);
    }
}

// ============================================================================
// PART 7: OSITO-HOVER-FC29-1S-AIO (29x29mm) 3D MECHANICAL CHECK MODEL (FC + 4-IN-1 12A ESC)
// ============================================================================
module hover_fc29_1s_mockup() {
    difference() {
        union() {
            // 1.0mm 4-Layer FR4 Substrate
            linear_extrude(height = 1.0)
                offset(r = 2.0) offset(delta = -2.0)
                    square([29.0, 29.0], center = true);
            // U1: AT32F435CGU7 Flight Controller MCU (6x6x0.8mm)
            translate([-3.0, -3.0, 1.0]) cube([6.0, 6.0, 0.8]);
            // U2: Bosch BMI270 Gyro (2.5x3.0x0.8mm)
            translate([-5.2 - 1.25, -6.2 - 1.5, 1.0]) cube([2.5, 3.0, 0.8]);
            // U3: Semtech SX1280 (4x4x0.8mm) + ANT1 Ceramic Antenna
            translate([-2.0, 7.2 - 2.0, 1.0]) cube([4.0, 4.0, 0.8]);
            translate([-1.6, 13.2 - 0.8, 1.0]) cube([3.2, 1.6, 1.6]);
            // U6: SPL06-001 Barometer (2.0x2.5x0.8mm)
            translate([6.4 - 1.0, 1.8 - 1.25, 1.0]) cube([2.0, 2.5, 0.8]);
            // ONBOARD 4-IN-1 12A H-BRIDGE ESC STAGE:
            // Top 4x AO4614B Dual N+P Power MOSFETs (Q1A, Q1B, Q2A, Q2B at X = +10.6mm)
            for (yp = [-7.6, -2.5, 2.5, 7.6]) {
                translate([10.6 - 2.0, yp - 2.45, 1.0])
                    cube([4.0, 4.9, 1.4]);
            }
            // Bottom 4x AO4614B Dual N+P Power MOSFETs (Q3A, Q3B, Q4A, Q4B at X = -10.6mm)
            for (yp = [-7.6, -2.5, 2.5, 7.6]) {
                translate([-10.6 - 2.0, yp - 2.45, -1.4])
                    cube([4.0, 4.9, 1.4]);
            }
            // Bottom 4x EFM8BB21F16G-C-QFN20 DShot300 ESC MCUs (U_ESC1..U_ESC4 at +-5.2, +-6.5mm)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.2 - 1.5, sy * 6.5 - 1.5, -0.9])
                    cube([3.0, 3.0, 0.9]);
            }
            // Bottom 4x BC847BS Pre-Drivers (Q_DRV1..Q_DRV4) + R_SHUNT (5mOhm 1206) + U_CURR (INA199A1)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * 5.2 - 1.0, sy * 2.2 - 1.0, -0.9])
                    cube([2.0, 2.0, 0.9]);
            }
            translate([2.5 - 1.6, -12.0 - 0.8, -0.8]) cube([3.2, 1.6, 0.8]);
            translate([-1.0, -9.0 - 1.0, -0.9]) cube([2.0, 2.0, 0.9]);
            // J1: USB Type-C
            translate([-4.5, -13.5, 1.0]) cube([9.0, 6.0, 3.2]);
            // C_BULK: 220uF Polymer Cap
            translate([-12.0 - 1.4, 3.2 - 1.75, 1.0]) cube([2.8, 3.5, 1.9]);
            // REV 3.1: 4-Corner Quick-Swap Top & Bottom Castellated Motor Solder Pads (M1±, M2±, M3±, M4±)
            // Located at X = ±12.8mm, Y = ±7.1mm and Y = ±9.2mm (2.2 x 1.5mm heavy copper pads)
            for (sx = [-1, 1], sy = [-1, 1], yp = [7.1, 9.2]) {
                translate([sx * 12.8 - 1.1, sy * yp - 0.75, -0.15])
                    cube([2.2, 1.5, 1.30]);
            }
            // Bottom J_HOVER 4-Pin JST-SH (Optical Flow + ToF Header)
            translate([-3.0, 12.2 - 1.5, -2.5]) cube([6.0, 3.0, 2.5]);
        }
        // 4x M2 Corner Mounting Holes (±12.75, ±12.75mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 12.75, sy * 12.75, -1.0])
                cylinder(d = 2.1, h = 4.0);
        }
        // 8x Through-Board Strain-Relief Solder Holes (0.9mm ID) at Corner Motor Pads (±12.8, ±7.1 & ±9.2mm)
        for (sx = [-1, 1], sy = [-1, 1], yp = [7.1, 9.2]) {
            translate([sx * 12.8, sy * yp, -1.0])
                cylinder(d = 0.9, h = 4.0);
        }
    }
}

// ============================================================================
// PART 8: 10x10 FT POPUP TENT FLOOR OPTICAL-FLOW TARGET PAD & GATE ANCHOR DISC
//   - High-Contrast Geometric Texture Pattern for MTF-01 (PMW3901) Optical-Flow Lock
//   - Modular Interlocking Tabs + LED Gate Arch Sockets + Turf/Floor Anchor Grommets
// ============================================================================
module hover65_tent_hover_target_pad_marker() {
    pad_d = 160.0;
    pad_h = 4.5;
    difference() {
        union() {
            // 1. Beveled Low-Profile Floor Disc (160mm OD, 4.5mm base height)
            cylinder(d1 = pad_d, d2 = pad_d - 4.0, h = pad_h);

            // 2. 2x Male Interlocking Dovetail Tabs (+X and +Y) for modular multi-tile array
            for (ang = [0, 90]) {
                rotate([0, 0, ang])
                    translate([pad_d / 2.0 - 2.0, 0, 0])
                        hull() {
                            translate([0, -9.0, 0]) cylinder(d = 4.0, h = pad_h);
                            translate([10.0, -12.0, 0]) cylinder(d = 4.0, h = pad_h);
                            translate([10.0,  12.0, 0]) cylinder(d = 4.0, h = pad_h);
                            translate([0,  9.0, 0]) cylinder(d = 4.0, h = pad_h);
                        }
            }

            // 3. Raised High-Contrast PMW3901 Optical-Flow Bullseye Rings & Radial Checker Sectors (Z = 4.5 to 6.2mm)
            translate([0, 0, pad_h - 0.1]) {
                // Outer & Mid Bullseye Rings
                for (rd = [136.0, 98.0, 60.0]) {
                    difference() {
                        cylinder(d = rd, h = 1.8);
                        translate([0, 0, -0.2]) cylinder(d = rd - 7.0, h = 2.4);
                    }
                }
                // 8x Radial High-Spatial-Frequency Optical-Flow Spokes
                for (ang = [0 : 45 : 315]) {
                    rotate([0, 0, ang])
                        translate([16.0, -1.8, 0])
                            cube([56.0, 3.6, 1.8]);
                }
                // High-Contrast Central Student Forward (+Y) Heading Chevron
                linear_extrude(height = 2.0)
                    polygon(points = [[0, 22.0], [-14.0, -10.0], [-5.0, -10.0], [-5.0, -18.0], [5.0, -18.0], [5.0, -10.0], [14.0, -10.0]]);
            }

            // 4. Twin 10x10 Tent LED Hover-Gate Arch Bosses (at X = +-64mm, Y = 0)
            for (sx = [-1, 1]) {
                translate([sx * 64.0, 0, 0])
                    cylinder(d1 = 22.0, d2 = 18.0, h = 14.0);
            }
        }

        // A. 2x Female Interlocking Dovetail Sockets (-X and -Y) with 0.4mm clearance
        for (ang = [180, 270]) {
            rotate([0, 0, ang])
                translate([pad_d / 2.0 + 2.0, 0, -0.5])
                    hull() {
                        translate([0, -9.4, 0]) cylinder(d = 4.4, h = pad_h + 2.0);
                        translate([-10.4, -12.4, 0]) cylinder(d = 4.4, h = pad_h + 2.0);
                        translate([-10.4,  12.4, 0]) cylinder(d = 4.4, h = pad_h + 2.0);
                        translate([0,  9.4, 0]) cylinder(d = 4.4, h = pad_h + 2.0);
                    }
        }

        // B. Twin 10.2mm ID Sockets for 10mm Fiberglass/PVC LED Hover-Gate Hoop Poles
        for (sx = [-1, 1]) {
            translate([sx * 64.0, 0, 2.0])
                cylinder(d = 10.2, h = 15.0);
        }

        // C. 4x Tent-Floor / Turf Peg Grommet Holes (6.5mm ID at 45/135/225/315 deg)
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang])
                translate([56.0, 0, -1.0])
                    cylinder(d = 6.5, h = 10.0);
        }
    }
}

// ============================================================================
// PART 9: COMPLETE SHOWCASE ASSEMBLY (Frame + FC29 REV 3.1 + HoverDome + OptFlow Pod)
// ============================================================================
module hover65_complete_showcase_assembly() {
    union() {
        hover65_frame_1s_300mah();
        translate([0, 0, 7.5]) hover_fc29_1s_mockup();
        translate([0, 0, 8.6]) hover65_canopy_dome_led();
        translate([0, 0, -12.3]) hover65_optflow_tof_pod();
    }
}

if (PART_ID == 1) hover65_frame_1s_300mah();
else if (PART_ID == 2) hover65_canopy_dome_led();
else if (PART_ID == 3) hover65_optflow_tof_pod();
else if (PART_ID == 4) hover65_guiderod_gimbal_collar();
else if (PART_ID == 5) hover65_tabletop_base();
else if (PART_ID == 6) hover65_top_stopper_bridge();
else if (PART_ID == 7) hover_fc29_1s_mockup();
else if (PART_ID == 8) hover65_tent_hover_target_pad_marker();
else if (PART_ID == 9) hover65_complete_showcase_assembly();
