"""
OSITO HOVER-65 & OSITO-HOVER-FC29-1S (REV 3.1: 4-Corner Quick-Swap Motor Pad Edition)
Master OpenSCAD STL Compiler, Mesh Volume/Mass Analyzer & Print Package Builder
"""
import os
import shutil
import struct
import subprocess
import time
import zipfile

CAD_DIR = os.path.dirname(os.path.abspath(__file__))
OPENSCAD_EXE = r"C:\Program Files\OpenSCAD\openscad.exe"
MASTER_SCAD = os.path.join(CAD_DIR, "OSITO_HOVER65_Turnkey_Master.scad")

PARTS = [
    (1, "OSITO_HOVER65_Frame_65mm_1S_300mAh.stl", "Bambu PETG-CF (Slot 1)", 1.29, 0.52),
    (2, "OSITO_HOVER65_Canopy_HoverDome_LED.stl", "Bambu TPU for AMS 68D (Slot 4)", 1.21, 0.55),
    (3, "OSITO_HOVER65_OpticalFlow_ToF_Underbelly_Pod.stl", "Bambu PETG-CF (Slot 1)", 1.29, 0.55),
    (4, "OSITO_HOVER65_GuideRod_Gimbal_Collar.stl", "Bambu PETG-CF (Slot 1)", 1.29, 0.45),
    (5, "OSITO_HOVER65_Tabletop_Base_4x300mAh_Dock.stl", "eSUN PLA+ / Bambu PLA Tough (Slot 3)", 1.24, 0.28),
    (6, "OSITO_HOVER65_Tabletop_Top_Stopper_Bridge.stl", "eSUN PLA+ / Bambu PLA Tough (Slot 3)", 1.24, 0.35),
    (7, "OSITO_HOVER65_FC29_1S_Mechanical_Mockup.stl", "4-Layer FR4 + Copper + Components", 1.85, 0.72),
    (8, "OSITO_HOVER65_Tent_Hover_Target_Pad_Marker.stl", "eSUN PLA+ / Bambu PLA Tough (Slot 3)", 1.24, 0.25),
    (9, "OSITO_HOVER65_COMPLETE_SHOWCASE_ASSEMBLY.stl", "Full Hover-65 Assembly Check", 1.32, 0.55),
]


def analyze_stl(filepath: str):
    """Count triangles and compute exact signed mesh volume (mm^3 -> cm^3) for ASCII or binary STL."""
    with open(filepath, "rb") as f:
        data = f.read()

    # Check if ASCII STL
    if data[:5].lower() == b"solid" and b"facet normal" in data[:1024]:
        text = data.decode("utf-8", errors="ignore")
        tri_count = 0
        vol_mm3 = 0.0
        verts = []
        for line in text.splitlines():
            s = line.strip()
            if s.startswith("vertex "):
                parts = s.split()
                verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                if len(verts) == 3:
                    (x1, y1, z1), (x2, y2, z2), (x3, y3, z3) = verts
                    vol_mm3 += (
                        x1 * (y2 * z3 - y3 * z2)
                        - y1 * (x2 * z3 - x3 * z2)
                        + z1 * (x2 * y3 - x3 * y2)
                    ) / 6.0
                    tri_count += 1
                    verts = []
        return tri_count, abs(vol_mm3) / 1000.0
    else:
        tri_count = struct.unpack("<I", data[80:84])[0]
        vol_mm3 = 0.0
        offset = 84
        for _ in range(tri_count):
            vals = struct.unpack("<12fH", data[offset : offset + 50])
            x1, y1, z1, x2, y2, z2, x3, y3, z3 = vals[3:12]
            vol_mm3 += (
                x1 * (y2 * z3 - y3 * z2)
                - y1 * (x2 * z3 - x3 * z2)
                + z1 * (x2 * y3 - x3 * y2)
            ) / 6.0
            offset += 50
        return tri_count, abs(vol_mm3) / 1000.0


def main():
    print("=" * 88)
    print("OSITO HOVER-65 REV 3.1 CAD SUITE (4-CORNER QUICK-SWAP MOTOR PAD EDITION)")
    print("=" * 88)

    results = []
    for part_id, filename, material, density, eff_fill in PARTS:
        out_path = os.path.join(CAD_DIR, filename)
        t0 = time.time()
        cmd = [
            OPENSCAD_EXE,
            "--export-format",
            "binstl",
            "-o",
            out_path,
            "-D",
            f"PART_ID={part_id}",
            MASTER_SCAD,
        ]
        subprocess.run(cmd, check=True)
        dt = time.time() - t0
        tris, vol_cm3 = analyze_stl(out_path)
        est_mass_g = vol_cm3 * density * eff_fill
        size_kb = os.path.getsize(out_path) / 1024.0
        results.append((part_id, filename, tris, vol_cm3, est_mass_g, size_kb, material, dt))
        print(
            f"[PART {part_id}] {filename:<48} | {tris:>6,} tris | {vol_cm3:>6.2f} cm3 | ~{est_mass_g:>5.2f}g | {size_kb:>6.1f} KB ({dt:.1f}s)"
        )

    # Also copy Frame to OSITO_HOVER65_Ducted_65mm_Frame_1S_300mAh.stl for alias compatibility
    frame_src = os.path.join(CAD_DIR, "OSITO_HOVER65_Frame_65mm_1S_300mAh.stl")
    frame_alias = os.path.join(CAD_DIR, "OSITO_HOVER65_Ducted_65mm_Frame_1S_300mAh.stl")
    shutil.copy2(frame_src, frame_alias)

    # Rebuild OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip
    zip_path = os.path.join(CAD_DIR, "OSITO_HOVER65_3D_CAD_PRINT_PACKAGE.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(MASTER_SCAD, os.path.basename(MASTER_SCAD))
        for _, filename, *_ in PARTS:
            p = os.path.join(CAD_DIR, filename)
            if os.path.exists(p):
                zf.write(p, filename)
        if os.path.exists(frame_alias):
            zf.write(frame_alias, os.path.basename(frame_alias))

    print("=" * 88)
    print(f"Updated ZIP package: {zip_path} ({os.path.getsize(zip_path)/1024.0:.1f} KB)")


if __name__ == "__main__":
    main()
