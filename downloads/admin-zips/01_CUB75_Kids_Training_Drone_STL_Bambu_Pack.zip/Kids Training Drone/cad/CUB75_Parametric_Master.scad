// ============================================================================
// OSITO CUB-75: 75mm 1S 550mAh ELRS Kids Training Drone (OpenSCAD CSG Master)
// 100% In-Office 3D-Printable Airframe, Finger-Safe Prop Cage & Training System
// ============================================================================
// ENGINEERING VERIFICATION:
// 1. Wheelbase: 75.0mm diagonal motor-to-motor (R_motor = 37.5mm at 45/135/225/315 deg).
// 2. Prop Clearance: 42.0mm ID / 45.2mm OD 360-deg ducts for 40mm (Gemfan 1610/1630)
//    props. Inboard duct edge sits at R = 37.5 - 22.6 = 14.9mm from center,
//    clearing the 25.5x25.5mm Whoop AIO FC PCB (14.2mm half-width) completely.
// 3. Kid-Safe Finger Guard Cage: Bottom 4-strut motor guard + raised 10.0mm duct
//    walls + arched top finger-guard ribs prevent small fingers from touching blades.
// 4. Power Bay: Unobstructed 70.0 x 18.5 x 7.5mm 1S 550mAh LiHV battery bay with
//    integrated wide-stance shock-absorbing training landing skids.
// 5. AIO Stack: Standard 25.5 x 25.5mm Whoop AIO cardinal diamond (R = 18.031mm).
// ============================================================================

$fn = 40;

// Overridden via CLI: openscad -D PART_ID=1 ...
// 0 = Exploded Full Assembly Preview
// 1 = CUB75_Frame_KidSafe_75mm.stl    (Main 75mm Frame + 360 Ducts + Top Finger Guards)
// 2 = CUB75_TPU_Bumper_Ring.stl       (Slip-On TPU 95A Outer Wall-Bounce Bumper Belt)
// 3 = CUB75_550mAh_Trainer_Skids.stl  (1S 550mAh Battery Cradle + Wide Training Skids)
// 4 = CUB75_Canopy_LOS_CubDome.stl    (Directional Arrow + Bear-Ear Roll Cage LOS Canopy)
// 5 = CUB75_Canopy_FPV_Pod.stl        (14x14mm Nano FPV Camera Pod - 10 deg Beginner Tilt)
// 6 = CUB75_Motor_Prop_Press_Jig.stl  (In-Office Bench Tool for Safe Prop Installation)
PART_ID = 0;

// --- Core Airframe Dimensions (mm) ---
wheelbase_diag      = 75.0;
m_rad               = wheelbase_diag / 2.0; // 37.5 mm
arm_width           = 4.8;
arm_height          = 2.6;

// Duct & Finger-Safe Guard Parameters (for 40mm Props)
hoop_id             = 42.0;
hoop_wall           = 1.6;
hoop_od             = hoop_id + 2 * hoop_wall; // 45.2 mm
duct_height         = 10.0; // Full-height encloses prop plane completely
bridge_r            = m_rad / sqrt(2); // 26.5165 mm X/Y motor center coordinate

// Motor Mounts (0802 / 0803 / 1002: 3-hole 6.6mm bolt circle, M1.4 screws)
motor_boss_dia      = 8.8;
motor_hole_circle   = 6.6;
motor_screw_dia     = 1.45;
motor_shaft_dia     = 2.3;

// Flight Controller Mount (25.5 x 25.5mm Whoop AIO Cardinal Diamond)
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm at 0, 90, 180, 270 deg
fc_hole_dia         = 2.05;
fc_air_gap          = 3.0;

// 1S 550mAh LiHV Battery Cradle (70.0 x 18.5 x 7.5mm internal slot)
batt_len            = 70.0;
batt_width          = 18.5;
batt_height         = 7.5;
cradle_wall         = 1.8;

// ============================================================================
// HELPER MODULES
// ============================================================================
module fc_hole_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0, 0])
                children();
    }
}

module fc_diamond_hub(thickness) {
    hull() {
        cylinder(d=24.0, h=thickness);
        fc_hole_positions() {
            cylinder(d=6.2, h=thickness);
        }
    }
}

// ============================================================================
// 1. CUB75_Frame_KidSafe_75mm.stl — 75mm Kid-Safe Ducted Frame + Finger Cage
// ============================================================================
module cub75_frame_kidsafe() {
    difference() {
        union() {
            // 1. Central Whoop AIO Diamond Hub
            fc_diamond_hub(arm_height);

            // 2. 4x Raised 3.0mm FC Standoffs (0, 90, 180, 270 deg)
            fc_hole_positions() {
                cylinder(d=5.2, h=arm_height + fc_air_gap);
            }

            // 3. 4x Diagonal Arms + Motor Bosses + Full-Height 360 Ducts + Finger Cage
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Main Diagonal Arm
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);

                    // Motor Mount Boss
                    translate([m_rad, 0, 0])
                        cylinder(d=motor_boss_dia, h=arm_height);

                    // Duct Assembly centered on Motor
                    translate([m_rad, 0, 0]) {
                        // Full 360° Base Ring (3.2mm tall for inboard FC clearance)
                        difference() {
                            cylinder(d=hoop_od, h=3.2);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_id, h=3.4);
                        }
                        // Raised 10.0mm Outer 250° Kid-Safe Duct Wall
                        intersection() {
                            difference() {
                                cylinder(d=hoop_od, h=duct_height);
                                translate([0, 0, -0.1])
                                    cylinder(d=hoop_id, h=duct_height + 0.2);
                            }
                            translate([-4.0, -hoop_od/2 - 1, 0])
                                cube([hoop_od, hoop_od + 2, duct_height + 0.2]);
                        }
                        // 4x Bottom Radial Finger-Guard Struts
                        for (s_ang = [-65, -20, 20, 65]) {
                            rotate([0, 0, s_ang])
                                translate([motor_boss_dia/2 - 0.4, -1.3, 0])
                                    cube([hoop_id/2 - motor_boss_dia/2 + 1.0, 2.6, arm_height - 0.4]);
                        }
                        // 3x Upper Arched Kid-Safe Finger Guard Ribs (at Z = duct_height - 1.6)
                        // Prevents small fingers from reaching down into the 40mm prop disc!
                        for (t_ang = [-45, 0, 45]) {
                            rotate([0, 0, t_ang])
                                translate([4.0, -1.1, duct_height - 1.6])
                                    cube([hoop_id/2 - 3.2, 2.2, 1.6]);
                        }
                        // Upper Central Finger-Guard Ring above Motor Nut (OD 10mm, ID 6mm)
                        translate([0, 0, duct_height - 1.6])
                            difference() {
                                cylinder(d=10.4, h=1.6);
                                translate([0, 0, -0.1])
                                    cylinder(d=6.4, h=1.8);
                            }
                    }
                }
            }

            // 4. 4x Cardinal Tangential Truss Bridges + Bumper Latch Tabs (0, 90, 180, 270 deg)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([fc_radius, 0, 0])
                            cylinder(d=5.4, h=3.2);
                        translate([bridge_r, -5.5, 0])
                            cube([4.0, 11.0, 3.2]);
                    }
                    // Outer Bridge Wall uniting adjacent ducts
                    translate([bridge_r - 0.8, -6.5, 0])
                        cube([4.8, 13.0, duct_height]);
                }
            }
        }

        // --- BOOLEAN SUBTRACTIONS ---
        // A. Subtract Swept Interior of All 4 Propellers (Z = arm_height to duct_height - 1.6)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, arm_height])
                    cylinder(d=hoop_id, h=duct_height - arm_height - 1.55);
        }

        // B. Center Weight-Reduction & Cooling Cutout
        translate([0, 0, -0.1])
            cylinder(d=14.0, h=arm_height + 0.2);

        // C. 4x Cardinal Diamond M2 Flight Controller Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=duct_height + 2.0);
        }

        // D. Motor Center Shaft Relief (2.3mm) + 3x M1.4 Screw Holes (6.6mm circle)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d=motor_shaft_dia, h=arm_height + 0.2);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_hole_circle/2, 0, 0])
                                cylinder(d=motor_screw_dia, h=arm_height + 0.2);
                    }
                }
        }
    }
}

// ============================================================================
// 2. CUB75_TPU_Bumper_Ring.stl — Slip-On 360° TPU 95A Classroom Wall Bumper
// ============================================================================
module cub75_tpu_bumper_ring() {
    bumper_thick = 2.4;
    bumper_h     = 6.0;
    lip_w        = 1.2;

    union() {
        // 4x Outer Arc Cushions wrapping around the 45.2mm OD ducts
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, 0]) {
                    intersection() {
                        difference() {
                            cylinder(d=hoop_od + 2*bumper_thick, h=bumper_h);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 0.2, h=bumper_h + 0.2);
                        }
                        translate([-14.5, -hoop_od, 0])
                            cube([hoop_od + 14.5, 2*hoop_od, bumper_h]);
                    }
                    // Inner Top/Bottom Retaining Lips that snap over the duct rim
                    intersection() {
                        difference() {
                            cylinder(d=hoop_od + 0.2, h=bumper_h);
                            translate([0, 0, 1.2])
                                cylinder(d=hoop_od + 0.6, h=bumper_h - 2.4);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 2*lip_w, h=bumper_h + 0.2);
                        }
                        translate([2.0, -hoop_od, 0])
                            cube([hoop_od, 2*hoop_od, bumper_h]);
                    }
                }
        }
        // 4x Cardinal Flex Straps uniting the 4 corner bumpers into a 1-piece belt
        for (c_ang = [0, 90, 180, 270]) {
            rotate([0, 0, c_ang])
                translate([bridge_r + 3.0, -7.5, 0])
                    cube([3.2, 15.0, bumper_h]);
        }
    }
}

// ============================================================================
// 3. CUB75_550mAh_Trainer_Skids.stl — 1S 550mAh Cradle + Wide Training Skids
// ============================================================================
module cub75_550_trainer_skids() {
    outer_l = batt_len + 2*cradle_wall;   // 73.6 mm
    outer_w = batt_width + 2*cradle_wall; // 22.1 mm
    outer_h = batt_height + 2*cradle_wall;// 11.1 mm
    skid_span_y = 26.0;                   // 52mm total stance width for stable landings!

    difference() {
        union() {
            // Central 1S 550mAh Battery Sleeve
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);

            // Outboard Left & Right M2 Stack Mounting Wings at (0, +/-18.031mm)
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0, y_sign * (outer_w/2 - 1.0), -3.0])
                        cylinder(d=9.0, h=3.0);
                    translate([0, y_sign * fc_radius, -3.0])
                        cylinder(d=6.8, h=3.0);
                }
                // Wide-Stance Angled Training Skid Legs (Front & Rear)
                for (x_leg = [-20.0, 20.0]) {
                    hull() {
                        translate([x_leg, y_sign * (outer_w/2 - 1.0), -outer_h + 2.5])
                            sphere(d=3.6);
                        translate([x_leg, y_sign * skid_span_y, -outer_h - 3.5])
                            sphere(d=3.6);
                    }
                }
                // Left & Right Parallel Floor Runner Skids (52mm long)
                hull() {
                    translate([-24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=3.8);
                    translate([24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=3.8);
                }
            }
        }

        // Unobstructed 70.0 x 18.5 x 7.5mm 1S 550mAh Battery Tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);

        // Side Finger-Push & Cooling Windows
        for (x_win = [-22, 0, 22]) {
            translate([x_win - 5.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 1.5])
                cube([11.0, outer_w + 0.2, batt_height - 3.0]);
        }

        // Bottom Weight-Saving Window
        translate([-24.0, -6.0, -outer_h - 0.1])
            cube([48.0, 12.0, cradle_wall + 0.2]);

        // Left & Right M2 Stack Mounting Holes
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * fc_radius, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
    }
}

// ============================================================================
// 4. CUB75_Canopy_LOS_CubDome.stl — Directional Arrow + Bear-Ear LOS Canopy
// ============================================================================
module cub75_canopy_los() {
    difference() {
        union() {
            // Base Diamond Mounting Ring
            fc_diamond_hub(1.8);

            // Protective LED Diffuser Dome
            translate([0, 0, 1.8])
                scale([1, 1, 0.65])
                    sphere(d=23.5);

            // High-Visibility Forward Pointer Nose Arrow (+X = Front of Drone)
            hull() {
                translate([6.0, -5.0, 0]) cube([2.0, 10.0, 2.4]);
                translate([21.5, 0, 0])   cylinder(d=2.8, h=2.4);
            }

            // "Osito Cub" Round Bear-Ear Roll Cage Hoops (Protects top & shows orientation)
            for (y_sign = [-1, 1]) {
                translate([-2.0, y_sign * 7.2, 5.8])
                    rotate([0, 20, 0])
                        cylinder(d=9.0, h=2.6, center=true);
            }
        }
        // Hollow Electronics & LED Cavity Inside Dome
        translate([0, 0, -0.1])
            scale([1, 1, 0.65])
                sphere(d=19.5);
        translate([0, 0, -5.0])
            cylinder(d=22.0, h=5.0);

        // 4x M2 Mounting Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=4.5);
        }
    }
}

// ============================================================================
// 5. CUB75_Canopy_FPV_Pod.stl — 14x14mm Nano FPV Camera Pod (10° Kid Tilt)
// ============================================================================
module cub75_canopy_fpv() {
    difference() {
        union() {
            fc_diamond_hub(1.8);
            hull() {
                translate([0, 0, 1.8]) cylinder(d=23.5, h=1.0);
                translate([1.5, 0, 12.5]) cylinder(d=17.5, h=2.0);
            }
            // Rear Whip Antenna Protection Tube
            translate([-13.0, 0, 1.8])
                rotate([0, -25, 0])
                    cylinder(d=3.6, h=16.0);
        }
        // 14x14mm Nano Camera Bay
        translate([0, -7.1, -0.1])
            cube([15.0, 14.2, 13.8]);
        translate([0, 0, -0.1])
            cylinder(d=19.0, h=8.5);
        // 10-Degree Beginner Camera Lens Bore (Gentle horizon angle for kids)
        translate([3.5, 0, 8.8])
            rotate([0, 80, 0])
                cylinder(d=11.5, h=15.0);
        // Antenna Whip Bore
        translate([-13.0, 0, 1.5])
            rotate([0, -25, 0])
                cylinder(d=1.8, h=18.0);
        // 4x M2 Stack Mounting Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=4.5);
        }
    }
}

// ============================================================================
// 6. CUB75_Motor_Prop_Press_Jig.stl — Bench Tool for Safe Prop Installation
// ============================================================================
module cub75_prop_jig() {
    difference() {
        union() {
            // Ergonomic Bench Base
            cylinder(d=28.0, h=4.0);
            // Motor Bell Cradle Tower (Supports 0802/1002 motor base while pressing prop)
            cylinder(d=16.0, h=14.0);
        }
        // Top Recess for 10.5mm-12.0mm Motor Bell (12.4mm ID)
        translate([0, 0, 6.0])
            cylinder(d=12.4, h=9.0);
        // Center Relief for Motor C-Clip & Bottom Shaft (4.5mm ID)
        translate([0, 0, -0.1])
            cylinder(d=4.5, h=15.0);
        // Side Slot for Motor Phase Wires
        translate([0, -2.5, 2.0])
            cube([16.0, 5.0, 13.0]);
    }
}

// ============================================================================
// RENDER DISPATCHER
// ============================================================================
if (PART_ID == 1) {
    cub75_frame_kidsafe();
} else if (PART_ID == 2) {
    cub75_tpu_bumper_ring();
} else if (PART_ID == 3) {
    rotate([180, 0, 0]) cub75_550_trainer_skids();
} else if (PART_ID == 4) {
    cub75_canopy_los();
} else if (PART_ID == 5) {
    cub75_canopy_fpv();
} else if (PART_ID == 6) {
    cub75_prop_jig();
} else {
    color("DarkSlateGray") cub75_frame_kidsafe();
    color("DarkOrange")    translate([0, 0, 2.0]) cub75_tpu_bumper_ring();
    color("DodgerBlue")    translate([0, 0, -2.0]) cub75_550_trainer_skids();
    color("Gold")          translate([0, 0, 10.0]) cub75_canopy_los();
}
