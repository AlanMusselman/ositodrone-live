# OSITO CUB-75: Bill of Materials (BOM) & Classroom Fleet Pricing

**Project:** 75mm 1S 550mAh ELRS Kids Training Drone (100% In-Office 3D-Printed Airframe & Safety Cage)

> **Spreadsheet Export:** Open [`CUB75_BOM_and_Sourcing.csv`](./CUB75_BOM_and_Sourcing.csv) directly in Excel or Google Sheets.

---

## 1. Per-Drone Unit Cost (In-Office Manufactured Airframe + COTS Avionics)

By memilih a **plug-and-play 1S 5-in-1 ELRS AIO** (with pre-soldered BT2.0 battery lead and 3-pin motor plugs) and printing all 5 structural/protective airframe modules in-office, a single **OSITO CUB-75** costs under **\$100** and can be assembled in **15 minutes with zero soldering required** (only 3 solder pads if you add the optional RGB LED strip).

| Category | Component | Recommended Part / Specification | Qty | Unit Cost | Extended |
| :--- | :--- | :--- | :---: | :---: | :---: |
| **Avionics** | 1S 5-in-1 ELRS AIO FC | BetaFPV `Matrix 1S 5-in-1` or `Air 5-in-1` (`ELRS 2.4G`, `12A Bluejay`, `BT2.0` pre-soldered, Motor Plugs) | 1 | \$44.99 | **\$44.99** |
| **Propulsion** | Plug-In Brushless Motors | `0802 19,500KV` or `1002 22,000KV` (`1.5mm` shaft, `JST-1.25` 3-pin plugs, `M1.4` 3-hole mount) | 1 set | \$39.99 | **\$39.99** |
| **Propulsion** | 40mm PC Propellers | Gemfan `1610` Bi-Blade or `1630` 3-Blade (`40mm`, High-Vis Green Front / Orange Rear) | 1 set | \$2.99 | **\$2.99** |
| **Power** | 1S 550mAh LiHV Battery | BetaFPV `Lava 1S 550mAh 75C BT2.0` (`13.8g`, $68 \times 16 \times 6.5\text{ mm}$) | 1 | \$4.80 | **\$4.80** |
| **Orientation** | Optional RGB LED Strip | `5V WS2812B` Micro COB Strip (Green Nose / Orange Tail) | 1 | \$3.50 | **\$3.50** |
| **In-Office Print** | 75mm Kid-Safe Frame | [`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl) (`PETG-CF` / `Tough PLA+` / `ePA-CF`, ~$6.8\text{g}$) | 1 | \$0.22 | **\$0.22** |
| **In-Office Print** | 360° TPU Wall Bumper | [`CUB75_TPU_Bumper_Ring.stl`](./cad/CUB75_TPU_Bumper_Ring.stl) (`TPU 95A`, ~$2.8\text{g}$) | 1 | \$0.10 | **\$0.10** |
| **In-Office Print** | 550mAh Cradle & Skids | [`CUB75_550mAh_Trainer_Skids.stl`](./cad/CUB75_550mAh_Trainer_Skids.stl) (`TPU 95A`, ~$3.4\text{g}$) | 1 | \$0.12 | **\$0.12** |
| **In-Office Print** | LOS & FPV Canopies | [`CUB75_Canopy_LOS_CubDome.stl`](./cad/CUB75_Canopy_LOS_CubDome.stl) + [`CUB75_Canopy_FPV_Pod.stl`](./cad/CUB75_Canopy_FPV_Pod.stl) (`TPU 95A`, ~$2.2\text{g}$) | 1 set | \$0.08 | **\$0.08** |
| **Hardware** | Fasteners & Grommets | `4x M2x12mm` Nylon Screws + `4x M2` Nylon Locknuts + `4x` Silicone Grommets + `12x M1.4x3mm` Screws | 1 set | \$1.25 | **\$1.25** |
| **SUBTOTAL** | **OSITO CUB-75 (LOS)** | **Ready-to-Fly Kid-Safe Classroom Trainer (`39.5g` AUW with 550mAh Battery)** | — | — | **\$98.04** |
| **FPV Add-On** | Plug-In Nano Camera | BetaFPV `C03` (`14x14mm`, plugs directly into AIO board—zero soldering) | 1 | \$19.99 | **+\$19.99** |
| **TOTAL** | **OSITO CUB-75 Dual** | **Complete LOS + FPV Convertible Kids Trainer (`41.1g` AUW)** | — | — | **\$118.03** |

---

## 2. Recommended Student Radio & Classroom Accessories

| Item | Unit Price | Why It Is Ideal for Kids Training |
| :--- | :---: | :--- |
| **RadioMaster T8L (ELRS 2.4GHz — Fleet Standard for Pelican/Apache Foam Cases) / Radiomaster Pocket (ELRS 2.4GHz Built-In)** | **\$44.99 – \$64.99** | Compact gamepad ergonomics sized specifically for kids' hands (ages 6–14), Hall-effect gimbals, exact fit for Osito Pelican/Apache fleet foam inserts (`T8L`), and supports **ELRS Wireless Buddy-Box Trainer** mode with an instructor radio. |
| **VIFLY WhoopStor V3 6-Port 1S Charger** | **\$42.99** | Charges 6x `1S 550mAh` packs simultaneously at $1.3\text{A}$ (~22 mins) and automatically storage-discharges packs to $3.80\text{V}$ after class so batteries never puff. |
| **1kg Spool PETG-CF / Tough PLA+ & 1kg Spool Neon TPU 95A** | **~\$49.00** | Enough filament to print **120+ replacement frames, bumpers, skids, and canopies** right in your office at ~\$0.52 per complete airframe set. |
