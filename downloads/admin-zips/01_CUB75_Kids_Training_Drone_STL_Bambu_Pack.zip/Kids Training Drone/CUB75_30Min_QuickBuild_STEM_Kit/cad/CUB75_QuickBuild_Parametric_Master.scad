// ============================================================================
// OSITO CUB-75 "SNAP-30": 30-Min Quick-Build + 30-Min Tent Flight STEM Kit
// OpenSCAD Parametric CSG Master File (11-Part Complete Classroom & Arena Suite)
// ============================================================================
// ENGINEERING & SAFETY VERIFICATION:
// 1. Wheelbase: 75.0mm diagonal motor-to-motor (R_motor = 37.5mm at 45/135/225/315 deg).
// 2. Ducts & Prop Clearance: 42.0mm ID / 45.2mm OD 360-deg ducts for 40mm 3-blade/4-blade
//    props. Inboard duct edge sits at R = 14.9mm, clearing the 25.5x25.5mm Whoop AIO FC.
// 3. Snap-In Keyed Motor Pods: Each motor station features a dual-flexure snap collar
//    (10.2mm ID / 13.2mm OD) with wire exit slot, integral arm cable channel, embossed
//    motor number (1-4) & CW/CCW markers, AND standard 3-hole 6.6mm M1.4 compatibility.
// 4. Quarter-Turn Bayonet FC & Canopy Posts: Cardinal diamond (R = 18.031mm) posts with
//    captive M2 core + quarter-turn bayonet ears for tool-free thumb-lock retention.
// 5. Self-Tightening Screw-Off Prop System: 2x CW (LH thread) & 2x CCW (RH thread)
//    knurled spinner collet caps + ergonomic Kid-Safe Finger Prop Wrench.
// 6. Net-Safe 360° TPU Bumper: Chamfered anti-snag outer profile with interlocking
//    duct groove ridge so the drone bounces cleanly off popup net mesh and walls.
// 7. 60-Minute Program Tent Arena & Pit-Stop Suite (Parts 9, 10, 11):
//    - Part 9: Universal Popup Tent Pole & Mesh Hoop Gate Clip (16mm PEX / 22.5mm Hula Hoop)
//    - Part 10: 150x150x35mm Elevated Octagonal "Osito Helipad" Spot-Landing Target
//    - Part 11: 6-Slot 1S 550mAh LiHV Battery Pit-Swap Caddy (3x FRESH 4.35V / 3x USED 3.50V)
// ============================================================================

$fn = 44;

// Overridden via CLI: openscad -D PART_ID=1 ...
// 0  = Exploded Full Assembly Preview
// 1  = CUB75_QB_Frame_75mm_SnapMotor.stl          (Tool-Free 75mm Ducted Frame + Snap Motor Pods)
// 2  = CUB75_QB_Threaded_Prop_Nut_Set_CW_CCW.stl  (2x CW + 2x CCW Threaded Spinner Caps + 4x Snap Collars)
// 3  = CUB75_QB_Prop_Finger_Wrench.stl            (Kid-Safe Bell-Holding Finger Prop Wrench)
// 4  = CUB75_QB_TPU_Bumper_Ring.stl               (Net-Safe 360° TPU 95A Interlocking Bumper Ring)
// 5  = CUB75_QB_550mAh_Trainer_Skids.stl          (Snap-In 1S 550mAh Battery Cradle + 52mm Skids)
// 6  = CUB75_QB_Canopy_LOS_CubDome.stl            (Quarter-Turn Directional Bear-Ear LOS Canopy)
// 7  = CUB75_QB_Thumb_Lock_Nuts.stl               (6x Quarter-Turn Winged Thumb-Lock Fasteners)
// 8  = CUB75_QB_Student_Build_Tray.stl            (180x140mm Classroom Student Desk Assembly Tray)
// 9  = CUB75_QB_Tent_Hoop_Gate_Clip.stl           (2x Popup Tent Pole/Mesh Clips for 16mm PEX & Hula Hoops)
// 10 = CUB75_QB_Elevated_Helipad_Target.stl       (150x150x35mm Octagonal Elevated Spot-Landing Helipad)
// 11 = CUB75_QB_Battery_Pit_Swap_Caddy.stl        (6-Slot 1S 550mAh FRESH vs USED Pit-Stop Battery Caddy)
PART_ID = 0;

// --- Core Airframe Dimensions (mm) ---
wheelbase_diag      = 75.0;
m_rad               = wheelbase_diag / 2.0; // 37.5 mm
arm_width           = 5.4;
arm_height          = 3.0;

// Duct & Finger-Safe Guard Parameters (for 40mm Props)
hoop_id             = 42.0;
hoop_wall           = 1.6;
hoop_od             = hoop_id + 2 * hoop_wall; // 45.2 mm
duct_height         = 10.0; // Full-height encloses prop plane completely
bridge_r            = m_rad / sqrt(2); // 26.5165 mm X/Y motor center coordinate

// Motor Mounts (Snap-In 10.0mm Cartridge + 0802/1002 3-hole 6.6mm bolt circle, M1.4 screws)
motor_boss_dia      = 13.2;
motor_snap_id       = 10.2; // Fits 10.0mm stator base / snap cartridge collar
motor_snap_h        = 3.2;
motor_hole_circle   = 6.6;
motor_screw_dia     = 1.45;
motor_shaft_dia     = 2.4;

// Flight Controller Mount (25.5 x 25.5mm Whoop AIO Cardinal Diamond)
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm at 0, 90, 180, 270 deg
fc_hole_dia         = 2.05;
fc_air_gap          = 3.2;

// 1S 550mAh LiHV Battery Cradle (70.0 x 18.5 x 7.5mm internal slot)
batt_len            = 70.0;
batt_width          = 18.5;
batt_height         = 7.5;
cradle_wall         = 1.8;

// ============================================================================
// HELPER MODULES
// ============================================================================
module fc_hole_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0, 0])
                children();
    }
}

module fc_diamond_hub(thickness) {
    hull() {
        cylinder(d=24.5, h=thickness);
        fc_hole_positions() {
            cylinder(d=6.8, h=thickness);
        }
    }
}

// Quarter-turn bayonet post for tool-free FC & Canopy thumb-lock retention
module quarter_turn_post() {
    union() {
        // Lower FC standoff shoulder
        cylinder(d=5.6, h=arm_height + fc_air_gap);
        // Upper alignment pin passing through FC & Canopy (OD 3.4mm)
        cylinder(d=3.4, h=arm_height + fc_air_gap + 5.8);
        // Top bayonet locking ears (engages thumb-lock nut & keyhole slot)
        translate([0, 0, arm_height + fc_air_gap + 4.4])
            hull() {
                translate([-2.3, 0, 0]) cylinder(d=1.4, h=1.4);
                translate([ 2.3, 0, 0]) cylinder(d=1.4, h=1.4);
            }
    }
}

// ============================================================================
// 1. CUB75_QB_Frame_75mm_SnapMotor.stl — Tool-Free 75mm Ducted Frame
// ============================================================================
module cub75_qb_frame() {
    difference() {
        union() {
            // 1. Central Whoop AIO Diamond Hub
            fc_diamond_hub(arm_height);

            // 2. 4x Quarter-Turn Bayonet FC & Canopy Posts (0, 90, 180, 270 deg)
            fc_hole_positions() {
                quarter_turn_post();
            }

            // 3. 4x Diagonal Arms + Snap-In Keyed Motor Pods + 360 Ducts + Finger Cage
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Main Diagonal Arm with U-channel walls for plug-in motor wires
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);

                    // Snap-In Keyed Motor Pod Boss + Retention Collar
                    translate([m_rad, 0, 0]) {
                        cylinder(d=motor_boss_dia, h=arm_height + motor_snap_h);
                        // Top snap-in retention lip (0.45mm inward chamfered detent)
                        translate([0, 0, arm_height + motor_snap_h - 0.9])
                            cylinder(d1=motor_boss_dia, d2=motor_boss_dia - 0.6, h=0.9);
                    }

                    // Duct Assembly centered on Motor
                    translate([m_rad, 0, 0]) {
                        // Full 360° Base Ring (3.2mm tall for inboard FC clearance)
                        difference() {
                            cylinder(d=hoop_od, h=3.2);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_id, h=3.4);
                        }
                        // Raised 10.0mm Outer 250° Kid-Safe Duct Wall
                        intersection() {
                            difference() {
                                cylinder(d=hoop_od, h=duct_height);
                                translate([0, 0, -0.1])
                                    cylinder(d=hoop_id, h=duct_height + 0.2);
                            }
                            translate([-4.0, -hoop_od/2 - 1, 0])
                                cube([hoop_od, hoop_od + 2, duct_height + 0.2]);
                        }
                        // 4x Bottom Radial Finger-Guard Struts
                        for (s_ang = [-65, -20, 20, 65]) {
                            rotate([0, 0, s_ang])
                                translate([motor_boss_dia/2 - 0.5, -1.4, 0])
                                    cube([hoop_id/2 - motor_boss_dia/2 + 1.1, 2.8, arm_height - 0.4]);
                        }
                        // 3x Upper Arched Kid-Safe Finger Guard Ribs (at Z = duct_height - 1.6)
                        for (t_ang = [-45, 0, 45]) {
                            rotate([0, 0, t_ang])
                                translate([4.2, -1.1, duct_height - 1.6])
                                    cube([hoop_id/2 - 3.4, 2.2, 1.6]);
                        }
                        // Upper Central Finger-Guard Ring above Prop Spinner (OD 10.8mm, ID 6.8mm)
                        translate([0, 0, duct_height - 1.6])
                            difference() {
                                cylinder(d=10.8, h=1.6);
                                translate([0, 0, -0.1])
                                    cylinder(d=6.8, h=1.8);
                            }
                    }
                }
            }

            // 4. 4x Cardinal Tangential Truss Bridges + Orientation & Motor ID Markers
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([fc_radius, 0, 0])
                            cylinder(d=5.8, h=3.2);
                        translate([bridge_r, -5.5, 0])
                            cube([4.0, 11.0, 3.2]);
                    }
                    // Outer Bridge Wall uniting adjacent ducts
                    translate([bridge_r - 0.8, -6.5, 0])
                        cube([4.8, 13.0, duct_height]);
                }
            }

            // 5. Raised Tactile Motor Number Dots (1, 2, 3, 4 dots) on the 4 Arm Roots
            // M1 = Rear-Right (315 deg, 1 dot), M2 = Front-Right (45 deg, 2 dots),
            // M3 = Rear-Left (225 deg, 3 dots), M4 = Front-Left (135 deg, 4 dots)
            rotate([0, 0, 315]) translate([15.5, 0, arm_height]) cylinder(d=1.8, h=0.8);
            rotate([0, 0, 45])  for (dx=[-1.2, 1.2]) translate([15.5+dx, 0, arm_height]) cylinder(d=1.6, h=0.8);
            rotate([0, 0, 225]) for (dx=[-2.0, 0, 2.0]) translate([15.5+dx, 0, arm_height]) cylinder(d=1.5, h=0.8);
            rotate([0, 0, 135]) for (dx=[-2.4, -0.8, 0.8, 2.4]) translate([15.5+dx, 0, arm_height]) cylinder(d=1.4, h=0.8);

            // Forward "+X" Tactile Nose Pointer on Front Bridge (0 deg)
            translate([bridge_r + 3.8, 0, duct_height - 2.0])
                rotate([0, 90, 0])
                    cylinder(d1=3.6, d2=0.8, h=2.2);
        }

        // --- BOOLEAN SUBTRACTIONS ---
        // A. Subtract Swept Interior of All 4 Propellers (Z = arm_height + motor_snap_h to duct_height - 1.6)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle]) {
                translate([m_rad, 0, arm_height]) {
                    difference() {
                        cylinder(d=hoop_id, h=duct_height - arm_height - 1.55);
                        // Preserve the Snap-In Motor Pod Collar up to arm_height + motor_snap_h
                        translate([0, 0, -0.1])
                            cylinder(d=motor_boss_dia + 0.4, h=motor_snap_h + 0.2);
                    }
                }
            }
        }

        // B. Snap-In Keyed Motor Pod Pocket + Flexure Relief Slots + Arm Cable Channel
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle]) {
                translate([m_rad, 0, 0]) {
                    // Upper 10.2mm Snap-In Stator/Cartridge Pocket
                    translate([0, 0, arm_height - 0.8])
                        cylinder(d=motor_snap_id, h=motor_snap_h + 1.2);
                    // Dual Flexure Expansion Slots in Snap Collar + Inboard Wire Exit Slot
                    translate([-motor_boss_dia, -1.1, arm_height - 0.8])
                        cube([motor_boss_dia, 2.2, motor_snap_h + 1.5]);
                    translate([-1.0, -motor_boss_dia/2 - 0.5, arm_height - 0.5])
                        cube([2.0, motor_boss_dia + 1.0, motor_snap_h + 1.0]);
                    // Standard Motor Shaft Relief (2.4mm) + 3x M1.4 Screw Holes (6.6mm circle)
                    translate([0, 0, -0.1]) {
                        cylinder(d=motor_shaft_dia, h=arm_height + 0.5);
                        for (m_ang = [0, 120, 240]) {
                            rotate([0, 0, m_ang])
                                translate([motor_hole_circle/2, 0, 0])
                                    cylinder(d=motor_screw_dia, h=arm_height + 0.5);
                        }
                    }
                }
                // Arm Cable Routing Channel (1.8mm wide x 1.2mm deep along bottom/inboard of arm)
                translate([11.0, -0.9, -0.1])
                    cube([m_rad - 14.5, 1.8, 1.3]);
            }
        }

        // C. Exterior Interlocking Groove around Duct Walls for Net-Safe TPU Bumper
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, 4.2])
                    difference() {
                        cylinder(d=hoop_od + 1.0, h=1.8);
                        translate([0, 0, -0.1])
                            cylinder(d=hoop_od - 0.9, h=2.0);
                    }
        }

        // D. Center Weight-Reduction & JST Motor Plug Access Cutout
        translate([0, 0, -0.1])
            cylinder(d=14.0, h=arm_height + 0.2);

        // E. 4x Cardinal Diamond M2 Core Holes through Bayonet Posts
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=duct_height + 4.0);
        }
    }
}

// ============================================================================
// 2. CUB75_QB_Threaded_Prop_Nut_Set_CW_CCW.stl — Self-Tightening Prop Hub Caps
//    + 4x Snap-In Motor Cartridge Collars (2x CW LH, 2x CCW RH)
// ============================================================================
module single_prop_spinner_nut(is_cw) {
    difference() {
        union() {
            // Flanged Base Washer (presses 40mm prop hub cleanly)
            cylinder(d=8.6, h=1.2);
            // Knurled Acorn Spinner Body
            translate([0, 0, 1.2])
                cylinder(d1=7.6, d2=5.8, h=4.2);
            // Rounded Safe Top Dome
            translate([0, 0, 5.4])
                sphere(d=5.8);
            // 6x Finger-Grip Knurl Ribs (also mates with Finger Wrench socket)
            for (k_ang = [0:60:300]) {
                rotate([0, 0, k_ang])
                    translate([3.2, -0.55, 1.2])
                        cube([0.9, 1.1, 3.8]);
            }
            // Directional Indicator Ring (CW has double collar ring, CCW has smooth base)
            if (is_cw) {
                translate([0, 0, 2.2])
                    cylinder(d=8.2, h=0.7);
            }
        }
        // Internal Collet Bore + Helical Thread Ribs for 1.5mm/2.0mm Threaded Prop Shaft
        translate([0, 0, -0.1])
            cylinder(d=2.1, h=5.2);
        // Bottom Collet Slit for Self-Locking Grip on Prop Hub Boss
        translate([-4.5, -0.35, -0.1])
            cube([9.0, 0.7, 2.6]);
    }
}

module snap_motor_adapter_collar() {
    difference() {
        union() {
            // Outer 10.0mm Snap Cartridge Body with retention groove
            cylinder(d=10.0, h=2.8);
            // Bottom Anti-Rotation Keyed Flange
            cylinder(d=11.2, h=0.8);
            translate([-5.6, -1.0, 0])
                cube([11.2, 2.0, 2.8]);
        }
        // Inner Pocket for 0802/1002 Motor Base (8.6mm ID + 3x M1.4 holes)
        translate([0, 0, 0.8])
            cylinder(d=8.6, h=2.5);
        translate([0, 0, -0.1]) {
            cylinder(d=2.6, h=1.5);
            for (m_ang = [0, 120, 240]) {
                rotate([0, 0, m_ang])
                    translate([motor_hole_circle/2, 0, 0])
                        cylinder(d=motor_screw_dia, h=1.5);
            }
        }
        // Wire Exit Slot
        translate([0, -1.2, -0.1])
            cube([6.5, 2.4, 3.2]);
    }
}

module cub75_qb_prop_nut_set() {
    // Row 1: 2x CW Spinner Nuts (Y = -8) & 2x CCW Spinner Nuts (Y = +8)
    for (x_pos = [-8, 8]) {
        translate([x_pos, -8, 0]) single_prop_spinner_nut(true);  // CW (Ringed)
        translate([x_pos,  8, 0]) single_prop_spinner_nut(false); // CCW (Smooth)
    }
    // Row 2 & 3: 4x Snap-In Motor Cartridge Adapter Collars
    for (x_pos = [-22, 22]) {
        for (y_pos = [-8, 8]) {
            translate([x_pos, y_pos, 0]) snap_motor_adapter_collar();
        }
    }
}

// ============================================================================
// 3. CUB75_QB_Prop_Finger_Wrench.stl — Kid-Safe Bell Holder & Spinner Wrench
// ============================================================================
module cub75_qb_prop_finger_wrench() {
    difference() {
        union() {
            // Ergonomic Double-Ended Kid-Safe Paddle Handle (60mm long)
            hull() {
                translate([-20, 0, 0]) cylinder(d=22.0, h=5.0);
                translate([ 20, 0, 0]) cylinder(d=18.0, h=5.0);
            }
            // End A (-X): Motor Bell Grip Tower (slips up under duct to hold 0802/1002 bell)
            translate([-20, 0, 5.0])
                cylinder(d=14.8, h=8.5);
            // End B (+X): Prop Spinner Cap Socket Tower (fits 6-rib spinner nuts)
            translate([20, 0, 5.0])
                cylinder(d=13.5, h=6.5);
            // Non-Slip Finger Grip Ridges along sides
            for (x_rib = [-8, -2, 4, 10]) {
                translate([x_rib, -10.5, 0])
                    cube([2.2, 21.0, 5.6]);
            }
        }
        // End A Recess: 11.6mm ID with 3 inward soft-grip ribs to hold motor bell without scratching
        translate([-20, 0, 6.5]) {
            difference() {
                cylinder(d=11.6, h=7.5);
                for (b_ang = [0, 120, 240]) {
                    rotate([0, 0, b_ang])
                        translate([5.2, -0.8, 0])
                            cube([1.2, 1.6, 7.5]);
                }
            }
        }
        // End A Bottom C-Clip & Wire Slot Relief
        translate([-20, 0, -0.1])
            cylinder(d=4.5, h=8.0);
        translate([-32, -2.2, 3.0])
            cube([12.0, 4.4, 11.0]);

        // End B Recess: 6-Flute Spinner Nut Socket (8.4mm ID)
        translate([20, 0, 6.5])
            cylinder(d=8.4, h=5.5, $fn=6);
        translate([20, 0, -0.1])
            cylinder(d=4.0, h=7.0);

        // Lanyard / Keyring Hole in Center
        translate([0, 0, -0.1])
            cylinder(d=4.2, h=6.0);
    }
}

// ============================================================================
// 4. CUB75_QB_TPU_Bumper_Ring.stl — Net-Safe 360° TPU 95A Interlocking Bumper
// ============================================================================
module cub75_qb_tpu_bumper_ring() {
    bumper_thick = 2.6;
    bumper_h     = 6.4;
    lip_w        = 1.2;

    union() {
        // 4x Outer Arc Cushions wrapping around the 45.2mm OD ducts
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, 0]) {
                    intersection() {
                        difference() {
                            // Chamfered anti-snag outer profile (zero sharp edges for net mesh!)
                            hull() {
                                translate([0, 0, 0.8])
                                    cylinder(d=hoop_od + 2*bumper_thick, h=bumper_h - 1.6);
                                cylinder(d=hoop_od + 2*bumper_thick - 1.4, h=bumper_h);
                            }
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 0.2, h=bumper_h + 0.2);
                        }
                        translate([-14.5, -hoop_od, 0])
                            cube([hoop_od + 14.5, 2*hoop_od, bumper_h]);
                    }
                    // Inner Top/Bottom Retaining Lips + Center Interlock Ridge (mates with duct groove)
                    intersection() {
                        difference() {
                            cylinder(d=hoop_od + 0.2, h=bumper_h);
                            translate([0, 0, 1.1])
                                cylinder(d=hoop_od + 0.6, h=1.3);
                            translate([0, 0, 4.0])
                                cylinder(d=hoop_od + 0.6, h=1.3);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_od - 2*lip_w, h=bumper_h + 0.2);
                        }
                        translate([2.0, -hoop_od, 0])
                            cube([hoop_od, 2*hoop_od, bumper_h]);
                    }
                }
        }
        // 4x Cardinal Flex Straps uniting the 4 corner bumpers into a 1-piece anti-snag belt
        for (c_ang = [0, 90, 180, 270]) {
            rotate([0, 0, c_ang])
                translate([bridge_r + 3.0, -7.8, 0])
                    cube([3.4, 15.6, bumper_h]);
        }
    }
}

// ============================================================================
// 5. CUB75_QB_550mAh_Trainer_Skids.stl — Snap-In 1S 550mAh Cradle + 52mm Skids
// ============================================================================
module cub75_qb_550_trainer_skids() {
    outer_l = batt_len + 2*cradle_wall;   // 73.6 mm
    outer_w = batt_width + 2*cradle_wall; // 22.1 mm
    outer_h = batt_height + 2*cradle_wall;// 11.1 mm
    skid_span_y = 26.0;                   // 52mm total stance width for stable landings!

    difference() {
        union() {
            // Central 1S 550mAh Battery Sleeve
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);

            // Outboard Left & Right Snap-In Mounting Ears at (0, +/-18.031mm)
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0, y_sign * (outer_w/2 - 1.0), -3.2])
                        cylinder(d=9.6, h=3.2);
                    translate([0, y_sign * fc_radius, -3.2])
                        cylinder(d=7.4, h=3.2);
                }
                // Snap-Fit Upward C-Clip Bosses that grip the Frame Standoff bases
                translate([0, y_sign * fc_radius, 0])
                    cylinder(d=6.8, h=2.4);

                // Wide-Stance Angled Training Skid Legs (Front & Rear)
                for (x_leg = [-20.0, 20.0]) {
                    hull() {
                        translate([x_leg, y_sign * (outer_w/2 - 1.0), -outer_h + 2.5])
                            sphere(d=3.8);
                        translate([x_leg, y_sign * skid_span_y, -outer_h - 3.5])
                            sphere(d=3.8);
                    }
                }
                // Left & Right Parallel Floor Runner Skids (52mm long)
                hull() {
                    translate([-24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=4.0);
                    translate([24.0, y_sign * skid_span_y, -outer_h - 3.5])
                        sphere(d=4.0);
                }
            }
        }

        // Unobstructed 70.0 x 18.5 x 7.5mm 1S 550mAh Battery Tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);

        // Side Finger-Push & Cooling Windows
        for (x_win = [-22, 0, 22]) {
            translate([x_win - 5.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 1.5])
                cube([11.0, outer_w + 0.2, batt_height - 3.0]);
        }

        // Bottom Weight-Saving Window
        translate([-24.0, -6.0, -outer_h - 0.1])
            cube([48.0, 12.0, cradle_wall + 0.2]);

        // Left & Right M2 Through-Holes + Snap-In C-Clip Side Entry Slots
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * fc_radius, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 3.0);
            // Upper Snap-Clip Pocket for 3.4mm/5.6mm Post
            translate([0, y_sign * fc_radius, -0.1])
                cylinder(d=3.5, h=2.7);
            translate([-1.4, y_sign * (fc_radius + 1.5) - 1.5, -0.1])
                cube([2.8, 3.0, 2.7]);
        }
    }
}

// ============================================================================
// 6. CUB75_QB_Canopy_LOS_CubDome.stl — Quarter-Turn Directional LOS Canopy
// ============================================================================
module cub75_qb_canopy_los() {
    difference() {
        union() {
            // Base Diamond Mounting Ring with reinforced Quarter-Turn Lock Pads
            fc_diamond_hub(2.2);

            // Protective LED Diffuser Dome
            translate([0, 0, 2.0])
                scale([1, 1, 0.65])
                    sphere(d=23.5);

            // High-Visibility Oversized Forward Pointer Nose Arrow (+X = Front of Drone)
            hull() {
                translate([6.0, -5.5, 0]) cube([2.2, 11.0, 2.6]);
                translate([22.5, 0, 0])   cylinder(d=3.0, h=2.6);
            }

            // "Osito Cub" Round Bear-Ear Roll Cage Hoops (Protects top & shows orientation)
            for (y_sign = [-1, 1]) {
                translate([-2.0, y_sign * 7.2, 6.0])
                    rotate([0, 20, 0])
                        cylinder(d=9.2, h=2.8, center=true);
            }
        }
        // Hollow Electronics & LED Cavity Inside Dome
        translate([0, 0, -0.1])
            scale([1, 1, 0.65])
                sphere(d=19.5);
        translate([0, 0, -5.0])
            cylinder(d=22.0, h=5.0);

        // 4x Quarter-Turn Keyhole Bayonet Mounting Slots at R = 18.031mm
        fc_hole_positions() {
            translate([0, 0, -0.1]) {
                // Center 3.6mm bore for bayonet post
                cylinder(d=3.6, h=5.0);
                // Bayonet ear pass-through slot
                hull() {
                    translate([-2.5, 0, 0]) cylinder(d=1.6, h=5.0);
                    translate([ 2.5, 0, 0]) cylinder(d=1.6, h=5.0);
                }
            }
        }
    }
}

// ============================================================================
// 7. CUB75_QB_Thumb_Lock_Nuts.stl — 6x Quarter-Turn Winged Thumb-Lock Fasteners
// ============================================================================
module single_thumb_lock_nut() {
    difference() {
        union() {
            // Knurled Base Collar
            cylinder(d=7.2, h=3.2);
            // Ergonomic Kid-Friendly Finger Wings (12.4mm span)
            hull() {
                translate([-5.2, 0, 0.8]) cylinder(d=2.4, h=2.4);
                translate([ 5.2, 0, 0.8]) cylinder(d=2.4, h=2.4);
            }
        }
        // Center Bore for 3.4mm Bayonet Post / M2 Screw
        translate([0, 0, -0.1])
            cylinder(d=3.55, h=3.6);
        // Bottom Entry Slot for Bayonet Ears
        translate([0, 0, -0.1])
            hull() {
                translate([-2.5, 0, 0]) cylinder(d=1.6, h=1.8);
                translate([ 2.5, 0, 0]) cylinder(d=1.6, h=1.8);
            }
        // 90-Degree Quarter-Turn Detent Seat (locks bayonet ears at 90 deg)
        translate([0, 0, 1.4])
            rotate([0, 0, 90])
                hull() {
                    translate([-2.5, 0, 0]) cylinder(d=1.6, h=1.2);
                    translate([ 2.5, 0, 0]) cylinder(d=1.6, h=1.2);
                }
    }
}

module cub75_qb_thumb_lock_nuts() {
    // 6x Thumb-Lock Nuts (4 required + 2 classroom spares)
    for (x_pos = [-12, 0, 12]) {
        for (y_pos = [-6, 6]) {
            translate([x_pos, y_pos, 0])
                single_thumb_lock_nut();
        }
    }
}

// ============================================================================
// 8. CUB75_QB_Student_Build_Tray.stl — 180x140mm Student Desk Assembly Tray
// ============================================================================
module cub75_qb_student_build_tray() {
    tray_w = 180.0;
    tray_d = 140.0;
    tray_h = 7.0;
    floor_t = 1.8;

    difference() {
        // Main Rounded Tray Body
        hull() {
            for (x_c = [-tray_w/2 + 6, tray_w/2 - 6]) {
                for (y_c = [-tray_d/2 + 6, tray_d/2 - 6]) {
                    translate([x_c, y_c, 0])
                        cylinder(r=6.0, h=tray_h);
                }
            }
        }

        // 1. Center-Left Main 75mm Frame Assembly Dock (X = -28, Y = 8)
        translate([-28, 8, floor_t]) {
            cylinder(d=34.0, h=tray_h);
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle])
                    translate([m_rad, 0, 0])
                        cylinder(d=hoop_od + 2.5, h=tray_h);
            }
        }

        // 2. Right Column: 4x Color-Coded Motor + Prop Compartments (M1, M2, M3, M4)
        for (i = [0:3]) {
            translate([58, 44 - i*29, floor_t]) {
                // 40mm Prop & Motor Pocket
                cylinder(d=25.0, h=tray_h);
                // Adjacent Spinner Cap & Collar Recess
                translate([-20, 0, 0])
                    cylinder(d=13.0, h=tray_h);
            }
        }

        // 3. Bottom-Left Compartment: Custom Whoop AIO Flight Controller (32x32mm)
        translate([-78, -62, floor_t])
            cube([34.0, 34.0, tray_h]);

        // 4. Bottom-Center Compartment: 1S 550mAh Battery + Skids (78x26mm)
        translate([-38, -58, floor_t])
            cube([76.0, 26.0, tray_h]);

        // 5. Top-Left Compartment: Thumb-Lock Nuts & Finger Prop Wrench Slot
        translate([-80, 48, floor_t])
            cube([68.0, 16.0, tray_h]);
    }
}

// ============================================================================
// 9. CUB75_QB_Tent_Hoop_Gate_Clip.stl — Universal Tent Pole & Mesh Hoop Clip
//    (Pair of 2 clips on plate: holds 16mm PEX LED rings or 22.5mm Hula-Hoops
//     onto 9.5mm-11.5mm popup tent poles & mesh sleeve without tearing netting)
// ============================================================================
module single_tent_hoop_gate_clip() {
    clip_h = 16.0;
    difference() {
        union() {
            // End A (-X): Popup Tent Pole + Mesh-Safe Saddle C-Clamp (OD 19mm, ID 11.2mm)
            translate([-16, 0, 0])
                cylinder(d=19.2, h=clip_h);

            // Central Reinforced Spine Bridge with Zip-Tie / Velcro Anchor Slot
            translate([-10, -6.5, 0])
                cube([22.0, 13.0, clip_h]);

            // End B (+X): Dual-Stage Hoop Cradle (Inner 16.2mm PEX Snap + Outer 22.5mm Hula-Hoop)
            translate([16, 0, 0])
                cylinder(d=29.6, h=clip_h);
        }

        // End A Bore: 11.2mm Tent Pole Pocket + Rounded Anti-Tear Mesh Entry Throat (8.2mm opening)
        translate([-16, 0, -0.1])
            cylinder(d=11.2, h=clip_h + 0.2);
        translate([-28, -4.1, -0.1])
            cube([12.0, 8.2, clip_h + 0.2]);

        // Central Velcro / Zip-Tie Pass-Through Slot (for hanging banners or LED strips)
        translate([-2.5, -8.0, 3.5])
            cube([5.0, 16.0, clip_h - 7.0]);

        // End B Dual-Stage Bore:
        // Lower/Inner 16.2mm Snap Bore for 1/2" PEX/PVC LED Gate Tubing
        translate([16, 0, -0.1])
            cylinder(d=16.2, h=clip_h + 0.2);
        // Upper Stepped 22.6mm Cradle for Standard Youth Hula-Hoop Tube
        translate([16, 0, 5.0])
            cylinder(d=22.6, h=clip_h);
        // Smooth Entry Throat (+X side, 18.0mm wide opening)
        translate([16, -9.0, -0.1])
            cube([16.0, 18.0, clip_h + 0.2]);
    }
}

module cub75_qb_tent_hoop_gate_clip() {
    // Print a matched pair (2x clips) per gate
    for (y_pos = [-18, 18]) {
        translate([0, y_pos, 0])
            single_tent_hoop_gate_clip();
    }
}

// ============================================================================
// 10. CUB75_QB_Elevated_Helipad_Target.stl — 150x150x35mm Octagonal Helipad
//     (For Minutes 30-60 "Spot Landing & Emergency Supply Drop" Tent Drills)
// ============================================================================
module regular_octagon_prism(across_flats, height) {
    // Circumradius R = across_flats / (2 * cos(22.5 deg))
    r_oct = across_flats / (2.0 * cos(22.5));
    rotate([0, 0, 22.5])
        cylinder(r=r_oct, h=height, $fn=8);
}

module cub75_qb_elevated_helipad_target() {
    pad_base_w = 150.0;
    pad_top_w  = 118.0;
    pad_h      = 33.5;
    ring_h     = 1.5; // Total height = 35.0 mm
    wall_t     = 2.6;

    difference() {
        union() {
            // Frustum Octagonal Body with Beveled Anti-Snag Skid Ramps (150mm base -> 118mm deck)
            hull() {
                regular_octagon_prism(pad_base_w, 2.0);
                translate([0, 0, pad_h - 2.0])
                    regular_octagon_prism(pad_top_w, 2.0);
            }

            // Raised Outer Bullseye Target Ring on Top Deck (OD 104mm, ID 96mm, +1.5mm raised)
            translate([0, 0, pad_h])
                difference() {
                    cylinder(d=104.0, h=ring_h);
                    translate([0, 0, -0.1])
                        cylinder(d=96.0, h=ring_h + 0.2);
                }

            // Raised Inner Bullseye Ring (OD 68mm, ID 62mm)
            translate([0, 0, pad_h])
                difference() {
                    cylinder(d=68.0, h=ring_h);
                    translate([0, 0, -0.1])
                        cylinder(d=62.0, h=ring_h + 0.2);
                }

            // Raised Central "H" Helipad Emblem (36mm tall x 28mm wide x 1.5mm raised)
            translate([0, 0, pad_h]) {
                translate([-14.0, -18.0, 0]) cube([6.0, 36.0, ring_h]);
                translate([  8.0, -18.0, 0]) cube([6.0, 36.0, ring_h]);
                translate([ -9.0,  -3.5, 0]) cube([18.0, 7.0, ring_h]);
            }
        }

        // Hollow Weight-Saving Underside Cavity (leaves 3.0mm top deck & 4x cross ribs)
        difference() {
            hull() {
                translate([0, 0, -0.1])
                    regular_octagon_prism(pad_base_w - 2*wall_t - 4.0, 2.0);
                translate([0, 0, pad_h - 5.0])
                    regular_octagon_prism(pad_top_w - 2*wall_t - 4.0, 2.0);
            }
            // Internal Cross Stiffener Ribs so the top deck never sags during bridging
            for (r_ang = [0, 45, 90, 135]) {
                rotate([0, 0, r_ang])
                    translate([-pad_base_w, -1.4, -0.1])
                        cube([2*pad_base_w, 2.8, pad_h]);
            }
        }
    }
}

// ============================================================================
// 11. CUB75_QB_Battery_Pit_Swap_Caddy.stl — 6-Slot 1S 550mAh LiHV Pit Caddy
//     (3x "FRESH 4.35V" Slots + 3x "USED 3.50V" Slots for 60-Min Flight Rotation)
// ============================================================================
module cub75_qb_battery_pit_swap_caddy() {
    caddy_w = 114.0;
    caddy_d = 64.0;
    caddy_h = 30.0;
    slot_w  = 20.4; // Fits 18.5mm wide 1S 550mAh pack with smooth classroom clearance
    slot_t  = 9.4;  // Fits 7.5mm thick 1S 550mAh pack + label sticker

    difference() {
        union() {
            // Wide Anti-Tip Base Flange (114 x 64 x 4mm)
            hull() {
                for (xc = [-caddy_w/2 + 5, caddy_w/2 - 5]) {
                    for (yc = [-caddy_d/2 + 5, caddy_d/2 - 5]) {
                        translate([xc, yc, 0])
                            cylinder(r=5.0, h=4.0);
                    }
                }
            }
            // Main Dual-Bank Tower Body (104 x 54 x 28mm)
            translate([-52.0, -27.0, 0])
                cube([104.0, 54.0, 28.0]);

            // Raised Center Divider Wall separating Bank A (FRESH +Y) & Bank B (USED -Y)
            translate([-52.0, -2.5, 0])
                cube([104.0, 5.0, caddy_h + 4.0]);

            // Tactile "+" Symbols on Front of FRESH Bank (+Y side)
            for (x_p = [-32, 0, 32]) {
                translate([x_p - 4.0, 26.5, 14.0]) cube([8.0, 1.8, 2.4]);
                translate([x_p - 1.2, 26.5, 11.2]) cube([2.4, 1.8, 8.0]);
            }
            // Tactile "-" Symbols on Front of USED Bank (-Y side)
            for (x_p = [-32, 0, 32]) {
                translate([x_p - 4.5, -28.3, 14.0]) cube([9.0, 1.8, 2.4]);
            }
        }

        // 3x "FRESH (4.35V)" Vertical Battery Slots on +Y Bank & 3x "USED (3.50V)" Slots on -Y Bank
        for (x_slot = [-32, 0, 32]) {
            // FRESH Bank Slot (+Y)
            translate([x_slot - slot_w/2, 6.0, 3.0])
                cube([slot_w, slot_t, 30.0]);
            // Finger Grip Cutout for easy pack grab (+Y outer wall)
            translate([x_slot - 6.5, 12.0, 14.0])
                cube([13.0, 18.0, 20.0]);

            // USED Bank Slot (-Y)
            translate([x_slot - slot_w/2, -6.0 - slot_t, 3.0])
                cube([slot_w, slot_t, 30.0]);
            // Finger Grip Cutout for easy pack grab (-Y outer wall)
            translate([x_slot - 6.5, -30.0, 14.0])
                cube([13.0, 18.0, 20.0]);
        }
    }
}

// ============================================================================
// RENDER DISPATCHER
// ============================================================================
if (PART_ID == 1) {
    cub75_qb_frame();
} else if (PART_ID == 2) {
    cub75_qb_prop_nut_set();
} else if (PART_ID == 3) {
    cub75_qb_prop_finger_wrench();
} else if (PART_ID == 4) {
    cub75_qb_tpu_bumper_ring();
} else if (PART_ID == 5) {
    rotate([180, 0, 0]) cub75_qb_550_trainer_skids();
} else if (PART_ID == 6) {
    cub75_qb_canopy_los();
} else if (PART_ID == 7) {
    cub75_qb_thumb_lock_nuts();
} else if (PART_ID == 8) {
    cub75_qb_student_build_tray();
} else if (PART_ID == 9) {
    cub75_qb_tent_hoop_gate_clip();
} else if (PART_ID == 10) {
    cub75_qb_elevated_helipad_target();
} else if (PART_ID == 11) {
    cub75_qb_battery_pit_swap_caddy();
} else {
    color("DarkSlateGray") cub75_qb_frame();
    color("DarkOrange")    translate([0, 0, 2.0]) cub75_qb_tpu_bumper_ring();
    color("DodgerBlue")    translate([0, 0, -2.0]) cub75_qb_550_trainer_skids();
    color("Gold")          translate([0, 0, 9.5]) cub75_qb_canopy_los();
}
