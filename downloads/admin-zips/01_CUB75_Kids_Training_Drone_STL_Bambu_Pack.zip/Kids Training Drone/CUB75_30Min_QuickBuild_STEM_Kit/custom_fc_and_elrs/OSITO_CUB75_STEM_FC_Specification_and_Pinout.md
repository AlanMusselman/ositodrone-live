# OSITO-CUB75-STEM-ELRS-AIO (REV 1.0): Custom Plug-and-Play Youth STEM Flight Controller & RadioMaster ELRS (T8L & Pocket) Avionics Architecture

**Part Number:** `OSITO-CUB75-STEM-ELRS-AIO REV 1.0`  
**Target Platform:** **OSITO CUB-75 (`39.5g` AUW, `75.0mm` Wheelbase, `1S 550mAh LiHV` 30-Minute Quick-Build Youth STEM Kit)**  
**Form Factor & Mounting:** **$29.0 \times 29.0 \times 7.8\text{ mm}$** ($1.0\text{ mm}$ 4-Layer FR4 `TG170`, $2\text{ oz}$ Outer / $1\text{ oz}$ Inner Copper, `ENIG`) with **$25.5 \times 25.5\text{ mm}$ Whoop M2 Mounting** ($\varnothing 2.1\text{ mm}$ NPTH at $\pm 12.75\text{ mm}$ with $\varnothing 5.0\text{ mm}$ silicone anti-vibration grommets)  
**MCU Dual-Footprint Compatibility:** **`STM32F411CEU6`** ($100\text{ MHz}$, $512\text{ KB}$ Flash) & pin-compatible **`Artery AT32F435CGU7`** ($288\text{ MHz}$, $1024\text{ KB}$ Flash) in `UFQFPN-48` ($7 \times 7\text{ mm}$)  
**Student Assembly Innovation:** **4× Color-Coded Top-Entry Keyed `JST-1.25mm` 3-Pin Motor Sockets (`J_M1–J_M4`)** with shroud walls + **4× Corner `WS2812B-2020` RGB Self-Test & Orientation LEDs (`LED1–LED4`)** + **Onboard Magnetic Piezo Beeper (`BZ1`)**  
**RC Link & Classroom Safety:** Onboard **`SPI3` `Semtech SX1280IMLTRT` 2.4GHz ExpressLRS (`ELRS 3.x`)** with $52.000\text{ MHz}$ TCXO/Crystal & Ceramic Chip Antenna (`2450AT18B100E`), pre-configured for **RadioMaster T8L & RadioMaster Pocket** with **Classroom Model Match (`01` to `15`)** and **Instructor Wireless "Buddy-Box" Override**

---

## 1. Executive Summary: Why the CUB-75 30-Minute STEM Kit Needed a Custom FC

During a 30-minute youth STEM drone-building workshop (ages 6–14), standard commercial 1S Whoop AIO flight controllers create three major classroom bottlenecks:
1. **Fragile Bottom-Mounted White Motor Plugs:** Standard COTS boards mount four identical white `JST-1.25mm` plugs on the *underside* of the PCB. Students cannot see the pin polarization once the board is mounted on the frame, leading to bent pins, swapped CW/CCW motor corners, and pinched wires.
2. **No Onboard Visual/Audible Pre-Flight Self-Test:** Without an external LED strip or buzzer soldered on, instructors cannot see at a glance whether a student's battery is low, whether all 4 motors are seated, or which way the nose is pointing inside the popup netted hover tent.
3. **Classroom Cross-Binding Chaos:** When 15 students turn on their radios simultaneously, generic SPI ELRS configurations without strict `Model Match` (`01`–`15`) risk cross-binding or accidental disarming across desks.

### How `OSITO-CUB75-STEM-ELRS-AIO REV 1.0` Solves All Three:
* **Zero-Solder, Zero-Bent-Pin Top-Entry Color-Coded Motor Sockets (`J_M1–J_M4`):** Mounted on the **Top (`F.Cu`)** four corners outside the canopy rim, each shrouded, keyed 3-pin `JST-1.25mm` vertical socket is color-dyed (and matched with a high-contrast PCB silkscreen ring + matching motor wire heat-shrink sleeve):
  * **`J_M1` (Rear-Right CW):** **WHITE** Socket (`(-10.5, -10.5) mm`)
  * **`J_M2` (Front-Right CCW):** **GREEN** Socket (`(+10.5, -10.5) mm`)
  * **`J_M3` (Rear-Left CCW):** **ORANGE** Socket (`(-10.5, +10.5) mm`)
  * **`J_M4` (Front-Left CW):** **BLUE** Socket (`(+10.5, +10.5) mm`)
* **Automated Boot Self-Test & Orientation RGB LEDs (`LED1–LED4`) + Onboard Piezo Beeper (`BZ1`):** Four ultra-bright `WS2812B-2020` addressable RGB LEDs sit directly beside each corner motor socket (`PA8 / TIM1_CH1`). On battery plug-in, the FC queries all four `EFM8BB21` Bluejay ESCs via bidirectional DShot300 (`dshot_bidir = ON`):
  * **During 3-Second Boot Self-Test:** Each corner LED lights **Solid Emerald Green** only when its corresponding motor plug (`J_M1–J_M4`) passes phase-continuity and RPM telemetry handshake, accompanied by the 5-tone Bluejay startup chime + `BZ1` ready beep. If a student forgot to push a motor plug all the way in, **that specific corner flashes Magenta/Red** and `BZ1` chirps an alert!
  * **During Flight:** Front corners (`LED2` Front-Right, `LED4` Front-Left) lock to **High-Visibility Nose Green**, while rear corners (`LED1` Rear-Right, `LED3` Rear-Left) lock to **High-Visibility Tail Orange** so students inside the netted tent never lose orientation.
* **Reinforced PTH `BT2.0` 1S 550mAh Power Pigtail:** Pre-soldered through $1.0\text{ mm}$ plated-through-hole (`PTH`) strain-relief anchors (`PAD_BAT+` / `PAD_BAT-`) rated for $>500$ student battery cycles with `BetaFPV Lava / GNB 1S 550mAh 75C LiHV` packs.

---

## 2. System Architecture Block Diagram

```mermaid
flowchart TD
    subgraph PWR["1S 550mAh LiHV (BT2.0) & Top USB-C Power Architecture"]
        BAT["1S 550mAh 75C LiHV Pack\n(3.8V Nom / 4.35V Full, 13.8g)\nReinforced PTH BT2.0 Pigtail"]
        USBC["J1 Top-Mount USB Type-C\n+ D1 USBLC6-2SC6 ESD\n+ R10/R11 5.1k CC1/CC2"]
        CAP["C_BULK 220uF 10V 125C POSCAP\n+ R_SHUNT 5mOhm 1206\n+ U9 INA199A1 (PB1 Current)"]
        VDIV["R1/R2 10k/10k 1% (2:1)\n-> PB0 (ADC1_IN8 VBAT)"]
        BEC["U10 TPS63020DSJR 5.0V 2A Buck-Boost\n(Holds 5.0V down to 1.8V VBAT)\n+ L_LC Active Video/LED Filter"]
        LDO_DIG["U11 AP2112K-3.3 (600mA)\n-> +3V3_DIG (MCU + SX1280 ELRS)"]
        LDO_GYRO["U12 LP5907MFX-3.3 (250mA)\nUltra-Low-Noise <10uVrms -> +3V3_GYRO"]

        BAT --> CAP
        BAT --> VDIV
        BAT --> BEC
        USBC -->|"D2 MBR0520 Schottky"| BEC
        BEC --> LDO_DIG
        BEC --> LDO_GYRO
    end

    subgraph CORE["Dual-Compatible MCU Core (STM32F411CEU6 / AT32F435CGU7)"]
        MCU["U1 STM32F411CEU6 / AT32F435\nUFQFPN-48 (0 deg Yaw)\n+ C1 2.2uF VCAP1 + Y1 8.000MHz HSE"]
        USBC <-->|"PA11/PA12 USB DFU/VCP"| MCU
    end

    subgraph SENSORS_ELRS["SPI1 BMI270 Gyro, SPI3 SX1280 ELRS 2.4GHz & SPI2 OSD"]
        BMI["U2 Bosch BMI270 6-Axis IMU\n(SPI1: PA4/PA5/PA6/PA7, EXTI: PC14)"]
        SX1280["U3 Semtech SX1280 + Y2 52MHz TCXO\n(SPI3: PA15/PB3-PB7/PC13)\n+ 50-Ohm Pi-Match -> ANT1 Ceramic 2.4GHz"]
        OSD["U4 AT7456E OSD (SPI2: PB12-PB15)\n+ J_CAM 3-Pin Plug-In FPV Header"]
        LED_BZ["LED1-LED4 Corner WS2812B-2020 (PA8)\n+ BZ1 Onboard Piezo Beeper (PC15 / Q_BZ)"]

        MCU <-->|"SPI1 (DMA2_S0/S3)"| BMI
        MCU <-->|"SPI3 (250Hz ELRS 3.x)"| SX1280
        MCU <-->|"SPI2"| OSD
        MCU -->|"TIM1_CH1 (DMA2_S1)"| LED_BZ
    end

    subgraph ESC_MOTORS["4ch 12A Bluejay v0.21 Brushless ESC & Color-Coded Top Motor Sockets"]
        ESC_MCU["4x U5-U8 EFM8BB21F16G (QFN-20)\nBluejay 48kHz DShot300 + Bidir RPM Telemetry"]
        MOSFET["12x Half-Bridge / 6x Dual N+P AO4614B\n12A Continuous / 15A Peak 3-Phase Stages"]
        SOCKETS["Top-Entry Keyed JST-1.25mm 3-Pin Sockets:\nJ_M1 Rear-Right (WHITE)\nJ_M2 Front-Right (GREEN)\nJ_M3 Rear-Left (ORANGE)\nJ_M4 Front-Left (BLUE)"]

        CAP --> MOSFET
        MCU <-->|"Bidir DShot300\n(PA0, PA1, PB9, PB8)"| ESC_MCU
        ESC_MCU --> MOSFET
        MOSFET <-->|"Phase A/B/C Continuity Check"| SOCKETS
    end
```

---

## 3. Complete MCU Pinout, Hardware Timer & Conflict-Free DMA Matrix

The `OSITO-CUB75-STEM-ELRS-AIO REV 1.0` layout supports both **`STM32F411CEU6`** ($100\text{ MHz}$) and **`Artery AT32F435CGU7`** ($288\text{ MHz}$) in the identical `UFQFPN-48` footprint with zero pin swaps and zero DMA stream collisions:

| Pin | GPIO | Signal Name | Peripheral / Timer | DMA Allocation | Connected Component & Classroom Function |
| :---: | :---: | :--- | :--- | :--- | :--- |
| **10** | `PA0` | `MOTOR 1` (Rear-Right CW) | `TIM2_CH1` (`AF1`) | `DMA1 Stream 5 Ch 3` (`pin A00 0`) | `U5` (`EFM8BB21`) $\rightarrow$ **`J_M1` Top Socket (WHITE)** |
| **11** | `PA1` | `MOTOR 2` (Front-Right CCW) | `TIM2_CH2` (`AF1`) | `DMA1 Stream 6 Ch 3` (`pin A01 0`) | `U6` (`EFM8BB21`) $\rightarrow$ **`J_M2` Top Socket (GREEN)** |
| **46** | `PB9` | `MOTOR 3` (Rear-Left CCW) | `TIM4_CH4` (`AF2`) | `TIM4_UP` Burst via `DMA1_S7` | `U7` (`EFM8BB21`) $\rightarrow$ **`J_M3` Top Socket (ORANGE)** |
| **45** | `PB8` | `MOTOR 4` (Front-Left CW) | `TIM4_CH3` (`AF2`) | `DMA1 Stream 7 Ch 2` (`pin B08 0`) | `U8` (`EFM8BB21`) $\rightarrow$ **`J_M4` Top Socket (BLUE)** |
| **30** | `PA8` | `LED_STRIP` | `TIM1_CH1` (`AF1`) | `DMA2 Stream 1 Ch 6` (`pin A08 0`) | **`LED1–LED4`** Corner `WS2812B-2020` RGB (`330 Ω` series `R_LED`) |
| **4** | `PC15` | `BEEPER` | GPIO Output (Active High) | None (GPIO) | `Q_BZ` (`2N7002` SOT-23) + `D_BZ` $\rightarrow$ **`BZ1` Onboard Piezo Beeper** |
| **18** | `PB0` | `ADC_BATT` (`VBAT`) | `ADC1_IN8` | `DMA2 Stream 4 Ch 0` (`ADC 1 1`) | `R1/R2` ($10\text{ k}\Omega / 10\text{ k}\Omega$, `1%` $2.0:1$ Divider, `vbat_scale = 20`) |
| **19** | `PB1` | `ADC_CURR` (`IBAT`) | `ADC1_IN9` | Shared `ADC1` (`DMA2_S4`) | `U9` (`INA199A1DCKR` $50\text{ V/V}$) across `R_SHUNT` ($5\text{ m}\Omega$, `ibata_scale = 2500`) |
| **14** | `PA4` | `GYRO_CS` | `SPI1_NSS` (Soft CS) | None | `U2` (`Bosch BMI270` Pin 12 `CSB`) |
| **15** | `PA5` | `SPI1_SCK` | `SPI1_SCK` (`AF5`) | None | `U2` (`Bosch BMI270` Pin 13 `SCx`) |
| **16** | `PA6` | `SPI1_MISO` | `SPI1_MISO` (`AF5`) | `DMA2 Stream 0 Ch 3` (`SPI_MISO 1 0`) | `U2` (`Bosch BMI270` Pin 1 `SDO`) |
| **17** | `PA7` | `SPI1_MOSI` | `SPI1_MOSI` (`AF5`) | `DMA2 Stream 3 Ch 3` (`SPI_MOSI 1 1`) | `U2` (`Bosch BMI270` Pin 14 `SDx`) |
| **3** | `PC14` | `GYRO_EXTI` | `EXTI14` Hardware IRQ | None | `U2` (`Bosch BMI270` Pin 4 `INT1`) |
| **38** | `PA15` | `RX_SPI_CS` | `SPI3_NSS` (Soft CS) | None | `U3` (`Semtech SX1280` Pin 9 `NSS`) |
| **39** | `PB3` | `SPI3_SCK` | `SPI3_SCK` (`AF6`) | None | `U3` (`Semtech SX1280` Pin 10 `SCK`) |
| **40** | `PB4` | `SPI3_MISO` | `SPI3_MISO` (`AF6`) | None | `U3` (`Semtech SX1280` Pin 12 `MISO`) |
| **41** | `PB5` | `SPI3_MOSI` | `SPI3_MOSI` (`AF6`) | None | `U3` (`Semtech SX1280` Pin 11 `MOSI`) |
| **42** | `PB6` | `RX_SPI_EXTI` | `EXTI6` IRQ (`DIO1`) | None | `U3` (`Semtech SX1280` Pin 7 `DIO1`) |
| **43** | `PB7` | `RX_SPI_BUSY` | GPIO Input (`BUSY`) | None | `U3` (`Semtech SX1280` Pin 6 `BUSY`) |
| **2** | `PC13` | `RX_SPI_RESET` | GPIO Output (`NRESET`) | None | `U3` (`Semtech SX1280` Pin 8 `NRESET`) |
| **25** | `PB12` | `OSD_CS` | `SPI2_NSS` (Soft CS) | None | `U4` (`AT7456E` Pin 8 `CS`) |
| **26** | `PB13` | `SPI2_SCK` | `SPI2_SCK` (`AF5`) | None | `U4` (`AT7456E` Pin 10 `SCLK`) |
| **27** | `PB14` | `SPI2_MISO` | `SPI2_MISO` (`AF5`) | None | `U4` (`AT7456E` Pin 9 `SDOUT`) |
| **28** | `PB15` | `SPI2_MOSI` | `SPI2_MOSI` (`AF5`) | None | `U4` (`AT7456E` Pin 7 `SDIN`) |
| **31/32** | `PA9/10` | `UART1_TX / RX` | `USART1` (`AF7`) | None | Perimeter Expansion Pads (`Optical Flow / ToF Lidar Module`) |
| **12/13** | `PA2/3` | `UART2_TX / RX` | `USART2` (`AF7`) | None | Onboard SmartAudio v2.1 VTX Control (`PA2`) |
| **33/34** | `PA11/12` | `USB_DM / USB_DP` | `USB_OTG_FS` (`AF10`) | Internal USB FIFO | `J1` Top-Mount USB Type-C via `D1` (`USBLC6-2SC6` ESD Array) |

---

## 4. Color-Coded Top-Entry Keyed `JST-1.25mm` Motor Sockets (`J_M1–J_M4`)

To make the 30-minute student build 100% foolproof, all four brushless motors (`0802 19,500KV` or `1002 22,000KV` with $35\text{ mm}$ silicone leads) terminate in **color-coded, keyed `JST-1.25mm` 3-pin plugs** that mate vertically into matching top-entry shrouded receptacles (`J_M1–J_M4`) on the top corners of the PCB:

| Socket | Drone Corner | Props-Out Spin | Housing & Silkscreen Color | Top PCB Coordinates `(X, Y)` | Pin 1 (`Phase A`) | Pin 2 (`Phase B`) | Pin 3 (`Phase C`) | Pre-Mapped Phase Order |
| :---: | :--- | :---: | :--- | :---: | :---: | :---: | :---: | :--- |
| **`J_M1`** | **Rear-Right (M1)** | **CW** ($\curvearrowright$) | **WHITE** (`#FFFFFF`) | `(+10.20, -10.20) mm` | `M1_A` | `M1_B` | `M1_C` | Hardware CW routed on PCB |
| **`J_M2`** | **Front-Right (M2)** | **CCW** ($\curvearrowleft$) | **GREEN** (`#00C853`) | `(+10.20, +10.20) mm` | `M2_A` | `M2_C` | `M2_B` | Hardware CCW swapped on PCB (`B/C`) |
| **`J_M3`** | **Rear-Left (M3)** | **CCW** ($\curvearrowleft$) | **ORANGE** (`#FF6D00`) | `(-10.20, -10.20) mm` | `M3_A` | `M3_C` | `M3_B` | Hardware CCW swapped on PCB (`B/C`) |
| **`J_M4`** | **Front-Left (M4)** | **CW** ($\curvearrowright$) | **BLUE** (`#2979FF`) | `(-10.20, +10.20) mm` | `M4_A` | `M4_B` | `M4_C` | Hardware CW routed on PCB |

### Why Pre-Swapping Phase `B/C` on `J_M2` and `J_M3` in the PCB Layout Matters for Manufacturing:
* Because `J_M2` (Front-Right CCW) and `J_M3` (Rear-Left CCW) have their Phase B and Phase C traces swapped **inside the PCB copper routing**, **all 4 motors use the exact same wire crimping order (Red-Black-White)** and identical Bluejay firmware settings!
* Even if an identical replacement motor is plugged into any corner, the PCB routing + Bluejay direction lock guarantees **Props-Out (`yaw_motors_reversed = ON`)** rotation every single time.
* **Heavy Mechanical Anchor Pads:** Each `JST-1.25mm` vertical receptacle (`CJT A1251WV-S-3P-COLOR`) includes two oversized $1.2 \times 1.8\text{ mm}$ side mechanical solder tabs anchored with 3x thermal/mechanical vias to `In1.Cu` so students can plug and unplug motors 100+ times without lifting a pad.

---

## 5. Onboard Student Pre-Flight Self-Test & Orientation RGB LEDs (`LED1–LED4`) + Beeper (`BZ1`)

### 5.1 Hardware Daisy-Chain & Placement
Four **`WS2812B-2020`** ($2.0 \times 2.0\text{ mm}$) intelligent RGB LEDs are placed on the top side (`F.Cu`) right next to the four motor sockets, powered from the filtered `+5V_CLEAN` rail (`TPS63020` Buck-Boost) and driven by `PA8` (`TIM1_CH1`) through a $330\,\Omega$ data series resistor (`R_LED`):
1. **`LED1` (Index `0` — Rear-Right Corner near `J_M1` White):** `(+8.20, -11.80) mm` $\rightarrow$ **Tail Orange (`Color 2`)**
2. **`LED2` (Index `1` — Front-Right Corner near `J_M2` Green):** `(+8.20, +11.80) mm` $\rightarrow$ **Nose Green (`Color 6`)**
3. **`LED3` (Index `2` — Front-Left Corner near `J_M4` Blue):** `(-8.20, +11.80) mm` $\rightarrow$ **Nose Green (`Color 6`)**
4. **`LED4` (Index `3` — Rear-Left Corner near `J_M3` Orange):** `(-8.20, -11.80) mm` $\rightarrow$ **Tail Orange (`Color 2`)**

### 5.2 Automated Student Pre-Flight Self-Test Sequence (16-Bit Millisecond Rollover Safe)
When a student finishes the 30-minute build and plugs in their `1S 550mAh LiHV` battery at the inspection table:
1. **`T = 0 ms – 1,500 ms` (Power & Gyro Integrity Check):**
   - `TPS63020` stabilizes `+5V_RAW` at $5.04\text{V}$; `LP5907` stabilizes `+3V3_GYRO` at $3.30\text{V}$.
   - `BMI270` Gyro initializes on `SPI1` (`PC14` EXTI @ $3.2\text{ kHz}$).
   - `ADC1` verifies 1S LiHV voltage $V_{\text{bat}} \ge 3.50\text{V}$ (if a student plugged in a depleted pack $< 3.50\text{V}$, all 4 corner LEDs flash **Warning Red** and `BZ1` sounds a 3-beep low-battery warning).
2. **`T = 1,500 ms – 3,000 ms` (4-Corner Motor Socket Plug & DShot Telemetry Verification):**
   - Each `EFM8BB21` ESC (`U5–U8`) steps through a micro-inductance phase check across Phases A-B, B-C, and C-A and reports status back to `STM32F411` over bidirectional DShot (`edt` / RPM telemetry).
   - If all 4 color-coded motor plugs (`White`, `Green`, `Orange`, `Blue`) are seated properly, all 4 corner LEDs pulse **Solid Emerald Green** for $1.5\text{ s}$ and `BZ1` plays a cheerful **2-chirp "STEM Build Passed!" tone**.
   - If any motor plug is loose or unplugged, **only that corner's LED flashes Rapid Magenta** so the student immediately knows which colored plug to push in!
3. **`T > 3,000 ms` (Flight Orientation & Arming Lockout Status):**
   - Front LEDs (`LED2`, `LED3`) display **Bright Nose Green**; Rear LEDs (`LED1`, `LED4`) display **Bright Tail Orange**.
   - If the student flips the `SA` Arm switch while Throttle $> 1045\,\mu\text{s}$ or while the drone is tilted $> 25^\circ$ (`small_angle = 25`), the LEDs flash **Yellow Arming Interlock Warning** and the motors remain safely disarmed.

> [!IMPORTANT]
> **16-Bit Millisecond Timer Rollover Safety (`uint16_t` Wrap-Around Protection):**  
> In our onboard pre-flight self-test state machine and EdgeTX Lua telemetry script, elapsed time is always computed using unsigned modular subtraction `(uint16_t)(now_ms - start_ms) >= threshold_ms` (masked as `(now_ms - start_ms) & 0xFFFF` in Python verification). This guarantees zero lockups or false watchdog triggers when a 16-bit millisecond counter wraps from `65535` (`0xFFFF`) to `0` (`0x0000`) every $65.536\text{ seconds}$ while students wait in line for the hover tent!

---

## 6. RadioMaster T8L & RadioMaster Pocket ELRS 2.4GHz Setup, Classroom Model Match (`01–15`) & Wireless Buddy-Box

Both the **RadioMaster T8L** (compact gamepad transmitter that drops into the Osito Pelican/Apache case foam) and the **RadioMaster Pocket (ELRS 2.4GHz EdgeTX)** are 100% natively supported by `OSITO-CUB75-STEM-ELRS-AIO REV 1.0`.

### 6.1 Standardized Student Switch & Channel Mapping (`AETR1234`)

| Channel | RadioMaster T8L / Pocket Control | Betaflight Function | Safe Student Behavior |
| :---: | :--- | :--- | :--- |
| **`CH1`** | **Right Stick Left/Right (`Aileron`)** | **Roll** | Bank angle capped at **$20^\circ$** in `Profile 0 ("Tent Hover - Beginner")` |
| **`CH2`** | **Right Stick Up/Down (`Elevator`)** | **Pitch** | Pitch angle capped at **$20^\circ$** in `Profile 0 ("Tent Hover - Beginner")` |
| **`CH3`** | **Left Stick Up/Down (`Throttle`)** | **Throttle** | Smooth hover curve (`thr_mid = 45`, `thr_expo = 45`) + $65\%$ ceiling in `Profile 0` |
| **`CH4`** | **Left Stick Left/Right (`Rudder`)** | **Yaw** | Gentle $110^\circ/\text{s}$ yaw rotation rate in `Profile 0` |
| **`CH5` (`AUX1`)** | **Switch `SA` (Top-Left 2-Pos Latching)** | **ARM / DISARM** (`1700–2100 us`) | **Hardware Pre-Arm Interlock:** Must boot disarmed (`SA` Low) with Throttle $< 1045\,\mu\text{s}$ and `SC` Turtle OFF |
| **`CH6` (`AUX2`)** | **Switch `SB` (Top-Left 3-Pos Switch)** | **Flight Mode** (`900–2100 us`) | **Low (`900–1300`)**: `ANGLE` + `HEADFREE` $\cdot$ **Mid (`1300–1700`)**: `ANGLE` $\cdot$ **High (`1700–2100`)**: `HORIZON` |
| **`CH7` (`AUX3`)** | **Switch `SC` (Top-Right 3-Pos Switch)** | **Turtle Crash-Flip** (`1700–2100 us`) | Flip upright if inverted (`crashflip_motor_percent = 70` thermal guard) |
| **`CH8` (`AUX4`)** | **Button `SD` (Top-Right Momentary)** | **Beeper / Find-Me** (`1700–2100 us`) | Triggers onboard `BZ1` piezo beeper + corner LED strobe |

### 6.2 Classroom Fleet Numbering & ExpressLRS Model Match (`01` to `15`)

In a 15-student STEM classroom, every CUB-75 kit (`Kit #01` through `Kit #15`) is paired with its matching numbered radio (`Radio #01` through `Radio #15`) using **unique per-station UIDs AND ExpressLRS `Model Match` IDs (`01` to `15`)**:

| Classroom Station | Craft Name (`craft_name`) | Binding Phrase | Betaflight `expresslrs_uid` | `expresslrs_model_id` | Radio Receiver ID (`Model Match = ON`) |
| :---: | :--- | :--- | :--- | :---: | :---: |
| **Station #01** | `CUB75_01` | `"osito-stem-cub75-01"` | `108,142,77,219,55,1` | **`1`** | `Receiver ID = 01` (`Model Match: ON`) |
| **Station #02** | `CUB75_02` | `"osito-stem-cub75-02"` | `108,142,77,219,55,2` | **`2`** | `Receiver ID = 02` (`Model Match: ON`) |
| **Station #03** | `CUB75_03` | `"osito-stem-cub75-03"` | `108,142,77,219,55,3` | **`3`** | `Receiver ID = 03` (`Model Match: ON`) |
| **$\vdots$** | $\vdots$ | $\vdots$ | $\vdots$ | $\vdots$ | $\vdots$ |
| **Station #15** | `CUB75_15` | `"osito-stem-cub75-15"` | `108,142,77,219,55,15` | **`15`** | `Receiver ID = 15` (`Model Match: ON`) |

* **Zero Cross-Bind Guarantee:** Even if two boards share a fleet binding phrase, setting `set expresslrs_model_id = N` (`1` to `15`) in Betaflight and `Model Match = ON (ID = N)` in the RadioMaster ExpressLRS Lua script ensures **Drone `#04` will strictly ignore commands from any radio except `#04`**.

### 6.3 Instructor Wireless "Buddy-Box" Override Architecture

For first-time pilots (ages 6–9) flying inside the popup netted tent or gym obstacle course, the instructor can hold a **Master Instructor RadioMaster Pocket / Boxer** linked wirelessly to the student's **RadioMaster Pocket / T8L (`Slave/Student`)** so the instructor can take instant control by holding a momentary switch (`SH` or `SD`):

1. **Option A: EdgeTX ELRS Backpack Wireless Trainer (Zero Cables):**
   - On the **Student Radio**, open `MODEL -> Setup -> Trainer -> Mode: Slave/Jack` (or `Multi/Bluetooth/CRSF Backpack`).
   - On the **Instructor Master Radio** (equipped with an internal 2.4GHz ELRS transmitter bound to the active CUB-75 drone and an external Nano ELRS / Multiprotocol module in the rear JR bay acting as `CPPM / SBUS Trainer RX` on `UART`), set `MODEL -> Trainer -> Mode: Master/Multi`.
   - In the **Instructor Radio `SPECIAL FUNCTIONS`** menu, add:
     - `SF1`: Switch **`SH↓` (or `SD`)** $\rightarrow$ Action **`Trainer`** $\rightarrow$ Parameter **`Sticks` (R, E, T, A)** $\rightarrow$ Enable **`ON`**.
   - **How It Works in Class:** As long as the instructor holds `SH` pulled, the student's gimbals fly the CUB-75 (while the instructor's `SA` Arm switch and `SB` Mode switch remain under instructor authority!). The instant a student panics or drifts toward the net, the instructor simply **releases `SH`**, and the drone snaps back to the instructor's centered sticks in $< 10\text{ ms}$!
2. **Option B: 3.5mm TRS Stereo Audio Trainer Cable (Universal T8L & Pocket Fallback):**
   - Plug a standard $1.8\text{ m}$ ($6\text{ ft}$) $3.5\text{ mm}$ TRS trainer cord between the top `DSC / Trainer` port of the **Student RadioMaster T8L / Pocket** (`Slave`) and the **Instructor RadioMaster Pocket** (`Master/Jack`). Zero RF setup required and immune to any 2.4GHz congestion.

---

## 7. Propulsion & Hover Physics Verification (`39.5g` AUW with `1S 550mAh LiHV`)

To guarantee that `Profile 0 ("Tent Hover - Beginner")` hovers effortlessly near mid-stick inside a $1.5\text{ m}$ popup netted tent without rocketing into the ceiling net:

* **All-Up Weight (`AUW`):**
  - `OSITO-CUB75` 3D-Printed Frame + 360° TPU Bumper + 550mAh Skids + CubDome Canopy: **$15.2\text{ g}$**
  - `OSITO-CUB75-STEM-ELRS-AIO REV 1.0` PCB + Top Sockets + `BT2.0` Pigtail: **$4.9\text{ g}$**
  - `4× 1002 22,000KV` Plug-In Brushless Motors + `40mm` Gemfan `1610/1630` Props + Screws: **$5.6\text{ g}$**
  - **Dry Mass:** **$25.7\text{ g}$**
  - **Battery (`1S 550mAh 75C LiHV`):** **$13.8\text{ g}$**
  - **Total Flying Mass ($m_{\text{AUW}}$):** **$39.5\text{ g}$** ($0.3875\text{ N}$ weight)
* **Total Static Thrust ($T_{\text{max,100\%}}$):**
  - Each `1002 22,000KV` motor spinning a $40\text{ mm}$ ducted 3-blade prop (`Gemfan 1630`) at $4.20\text{V}$ LiHV produces **$30.5\text{ g}$** static thrust ($4 \times 30.5\text{ g} = \mathbf{122.0\text{ g}}$ total thrust $\rightarrow$ **$3.09:1$ Uncapped Thrust-to-Weight Ratio**).
* **Hover Thrust & Stick Position in `Profile 0 ("Tent Hover - Beginner")`:**
  - In Betaflight 4.5, `motor_output_limit = 65%` scales the upper mixer ceiling to $65\%$ of full motor RPM ($T_{\text{max,Profile0}} \approx 122.0\text{ g} \times 0.65 = \mathbf{79.3\text{ g}}$ effective ceiling $\rightarrow$ **$2.01:1$ Safe Indoor Tent Thrust-to-Weight Ratio**).
  - Required hover throttle output to support $m_{\text{AUW}} = 39.5\text{ g}$ is $39.5\text{ g} / 79.3\text{ g} = \mathbf{49.8\%}$ of the Profile 0 ceiling (or $32.4\%$ of raw uncapped thrust).
  - By setting **`thr_mid = 45`** and **`thr_expo = 45`**, the Betaflight cubic throttle lookup curve flattens right across $40\%\text{–}60\%$ physical stick deflection (`rcLookupThrottle(0.50) = 0.45`, `rcLookupThrottle(0.575) = 0.498`), placing $1.0\text{ m}$ steady hover right at **$57.5\%$ physical throttle stick** with a wide, forgiving deadband so young students never bounce between the floor and ceiling net!

---

## 8. 1-Hour Program Multi-Battery Duty Cycle & Pit-Stop Telemetry (`Minutes 00–60`)

To support both the **30-Minute Express Program** and the **1-Hour (60-Minute) Build + Tent Flight Practice Program** (`Minutes 00–30`: Build + Pre-Flight Self-Test + First Hover; `Minutes 30–60`: 30 Minutes of Continuous Tent Flight Practice, Obstacle Drills, Turtle Mode Recovery & 3-Pack Battery Rotation), each `OSITO CUB-75` in the 1-Hour kit is provisioned with **3× `1S 550mAh 75C LiHV` (`BT2.0`) batteries** (plus 1 shared `VIFLY WhoopStor V3` 6-port storage charger per 2 drones).

### 8.1 3-Pack Continuous Partnered Flight Rotation (`Minutes 22–58` / `20.8 Mins` Net Air Time)
* **Energy Budget (`3 × 1S 550mAh 75C LiHV`):**
  - Each `1S 550mAh LiHV` pack stores $0.550\text{ Ah} \times 3.80\text{ V}_{\text{nominal}} = \mathbf{2.09\text{ Wh}}$ ($\mathbf{6.27\text{ Wh}}$ total across 3 packs).
  - In `Profile 0 ("Tent Hover - Beginner")`, average hover + box-pattern current draw is **$4.60\text{ A}$** ($\rightarrow \mathbf{7.17\text{ minutes}}$ per pack). In `Profile 1 ("Scout Tent Obstacle Mode")`, dynamic obstacle + turn current draw averages **$5.40\text{ A}$** ($\rightarrow \mathbf{6.11\text{ minutes}}$ per pack).
  - Across a **2-Pack `Profile 0` + 1-Pack `Profile 1` rotation**, a single `OSITO CUB-75` delivers **$20.8\text{ minutes}$ of net active air time** (`6.27 Wh` budget, including low-current helipad taxi/staging), allowing two partnered students (**Pilot A** + **Pilot B** swapping the radio every $3.5\text{ minutes}$ at each Pit Stop) to fly **continuously from Minute 22 to Minute 58** with zero charger waiting!

| Timeline Window | Active Pack | Active Pilot & Drill | Flight Profile | Avg Current | Net Air Time | Cumulative Air Time |
| :---: | :---: | :--- | :---: | :---: | :---: | :---: |
| **`Min 22 – Min 26`** | **Pack #1 (`550mAh`)** | **Pilot A:** First 1.0m Tent Hover & Helipad Landings | `Profile 0` (`20°` / `65%`) | $4.6\text{ A}$ | $3.6\text{ mins}$ | $3.6\text{ mins}$ |
| **`Min 26 – Min 30`** | **Pack #1 (`550mAh`)** | **Pilot B:** First 1.0m Tent Hover & Box-Walk Drill | `Profile 0` (`20°` / `65%`) | $4.6\text{ A}$ | $3.6\text{ mins}$ | $7.2\text{ mins}$ |
| **`Min 30 – Min 32`** | *Pit Stop #1 (20s Swap)* | *Pulsing Amber `3.50V` Alert $\rightarrow$ Plug in Pack #2* | — | — | — | — |
| **`Min 32 – Min 36`** | **Pack #2 (`550mAh`)** | **Pilot A:** Precision Hover Ring & Turtle Mode Flip Drill | `Profile 0` (`20°` / `65%`) | $4.6\text{ A}$ | $3.6\text{ mins}$ | $10.8\text{ mins}$ |
| **`Min 36 – Min 40`** | **Pack #2 (`550mAh`)** | **Pilot B:** Precision Hover Ring & Turtle Mode Flip Drill | `Profile 0` (`20°` / `65%`) | $4.6\text{ A}$ | $3.6\text{ mins}$ | $14.4\text{ mins}$ |
| **`Min 40 – Min 45`** | *Pit Stop #2 + Unlock* | *Swap to Pack #3 + Unlock `Profile 1 ("Scout LOS")` at Min 45!* | — | — | — | — |
| **`Min 45 – Min 51`** | **Pack #3 (`550mAh`)** | **Pilot A:** Nose-In Figure-8s & Tent Hula-Hoop Slalom | `Profile 1` (`32°` / `78%`) | $5.4\text{ A}$ | $3.2\text{ mins}$ | $17.6\text{ mins}$ |
| **`Min 51 – Min 58`** | **Pack #3 (`550mAh`)** | **Pilot B:** Nose-In Figure-8s & Final Timed Obstacle Run | `Profile 1` (`32°` / `78%`) | $5.4\text{ A}$ | $3.2\text{ mins}$ | **$20.8\text{ mins}$** |

### 8.2 Onboard Low-Voltage Pit-Stop Warning (`LED1–LED4` + `BZ1` Piezo)
Because students flying Line-of-Sight (`LOS`) inside the popup netted tent are watching the drone rather than an FPV screen, `OSITO-CUB75-STEM-ELRS-AIO REV 1.0` uses its 4 corner `WS2812B-2020` LEDs (`LED1–LED4`) and onboard piezo buzzer (`BZ1`) to broadcast unmistakable two-stage Pit-Stop cues:
1. **Stage 1 — `3.50V/cell` Pit-Stop Alert (`vbat_warning_cell_voltage = 350` / `440mAh` drawn):**
   - The 4 corner RGB LEDs automatically override their Green/Orange orientation pattern and transition to a **Pulsing Amber Pit-Stop Strobe** accompanied by a **1-Chirp Audible Pit-Stop Alert** from `BZ1` every 4 seconds.
   - This signals the active student pilot to fly back to the center **Tent Helipad** for a 20-second `BT2.0` battery swap (leaving a safe $3.65\text{V}$ resting rebound voltage in the pack).
2. **Stage 2 — `3.30V/cell` Auto-Land Protection Prompt (`vbat_min_cell_voltage = 330`):**
   - If a student continues flying past the Amber Pit-Stop warning down to `3.30V/cell`, the 4 corner LEDs switch to a **Rapid Red Flash** and `BZ1` sounds a **Double-Beep Auto-Land Prompt**, instructing immediate touchdown so the `1S 550mAh LiHV` cells never over-discharge.

### 8.3 Mid-Session Skill Progression (`Profile 0` $\rightarrow$ `Profile 1` at Minute 45)
Once both partnered students complete their `Profile 0 ("Tent Hover - Beginner")` hover, box-walk, and Turtle Mode recovery checks (`Minutes 22–44`), the instructor unlocks **`Profile 1 ("Scout Tent Obstacle Mode")`** at **Minute 45** right before inserting Pack #3:
* **Zero-Laptop Stick Command Unlock (while Disarmed):**
  - Hold **Left Stick (Throttle/Yaw) Up + Left** and push **Right Stick (Pitch/Roll) Left** for 1 second (or use the Betaflight OSD stick menu / EdgeTX ELRS Lua script) to step from `Profile 0 / Rateprofile 0` to **`Profile 1 / Rateprofile 1`**.
  - Onboard `BZ1` emits **2 confirmation beeps** indicating `Profile 1` is active:
    - **Max Tilt Angle:** Increases from $20^\circ \rightarrow \mathbf{32^\circ}$ (`angle_limit = 32`)
    - **Max Stick Rotation Rate:** Increases from $130^\circ/\text{s} \rightarrow \mathbf{240^\circ/\text{s}}$ (`roll_srate = 24`, `pitch_srate = 24`)
    - **Motor Output Ceiling:** Increases from $65\% \rightarrow \mathbf{78\%}$ (`motor_output_limit = 78`)
    - **Flight Mode (`Switch SB` Mid):** Standard **`ANGLE` (Nose-In LOS)** so students learn true coordinated yaw + bank turns through the tent obstacle hoops!

### 8.4 Continuous 3-Pack Back-to-Back Thermal Equilibrium Verification
Flying 3 consecutive `1S 550mAh LiHV` packs over 30 minutes (`20.8 mins` active hover/obstacle flight in a $25.0\,^\circ\text{C}$ indoor gym/classroom tent) requires strict thermal margin across the FC, ESC MOSFETs, and brushless motor windings:
* **Ducted Propwash Forced Convection ($v_{\text{air}} \approx 6.8\text{ m/s}$):** Downward slipstream from the four $40\text{ mm}$ fans flows directly across the $2.0\text{ oz}$ outer copper layers (`F.Cu`/`B.Cu`) and 28 thermal vias of the `OSITO-CUB75-STEM-ELRS-AIO REV 1.0`.
* **Steady-State Peak Temperatures Across 3 Back-to-Back Packs ($T_{\text{amb}} = 25.0\,^\circ\text{C}$):**
  - **`STM32F411 / AT32F435` MCU & `TPS63020` BEC:** **$54.2\,^\circ\text{C}$** (well below the $85.0\,^\circ\text{C}$ `core_temp_alarm` threshold)
  - **`AO4614B` 12A 3-Phase ESC MOSFETs ($1.35\text{A}/\text{motor}$ max avg in `Profile 1`):** **$58.6\,^\circ\text{C}$**
  - **`1002 22,000KV` Stator Windings:** **$56.4\,^\circ\text{C}$** (safe finger-touch temperature $< 60\,^\circ\text{C}$ during 20-second student battery swaps!)
