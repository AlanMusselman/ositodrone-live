# OSITO CUB-75: Engineering Blueprint & Product Requirements Document (PRD)

**System Designation:** `OSITO CUB-75` (*75mm 1S 550mAh ELRS Kid-Safe Classroom & Camp Training Drone*)  
**Manufacturing Model:** 100% In-Office 3D-Printed Modular Airframe + Plug-and-Play COTS Micro Avionics

---

## 1. Executive Summary & Mission Requirements

Training children (ages 6–14) to fly drones indoors requires a completely different mechanical and flight-control architecture than an open-prop racing or combat drone. Standard commercial micro-drones suffer from three fatal classroom flaws:
1. **Exposed Top/Bottom Propellers:** Standard Tiny Whoop ducts only surround the *sides* of the blades; when a child grabs a hovering or upside-down drone by hand, their fingers slip into the spinning 40mm blades.
2. **Brittle Injection-Molded Frames & Short Flight Times:** Thin polypropylene frames crack after repeated wall hits, and standard 300mAh batteries only last 2.5 minutes—forcing instructors to swap batteries before a student even masters hovering.
3. **Overwhelming Stick Sensitivity & Orientation Loss:** Factory Betaflight rates ($400\text{–}670^\circ/\text{s}$) and identical front/back symmetry cause beginners to lose nose orientation and slam into walls at full throttle.

### How the In-Office `OSITO CUB-75` Solves All Three:
* **True 75.0mm Wheelbase with Finger-Safe Top & Bottom Prop Cages:** [`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl) combines $10.0\text{ mm}$ tall $360^\circ$ ducts ($42.0\text{ mm}$ ID for $40\text{ mm}$ props) with **4 bottom radial motor guards** and **3 upper arched finger-guard ribs + center hub rings** above every propeller, blocking small fingers from contacting the blades from any angle.
* **Slip-On 360° TPU 95A Wall-Bounce Bumper Belt:** [`CUB75_TPU_Bumper_Ring.stl`](./cad/CUB75_TPU_Bumper_Ring.stl) snaps around the outer perimeter of the 75mm frame like a bumper-car tire, absorbing kinetic energy against drywall, gym floors, and classroom furniture without leaving marks.
* **1S 550mAh LiHV Power Bay + 52mm Wide-Stance Trainer Skids:** [`CUB75_550mAh_Trainer_Skids.stl`](./cad/CUB75_550mAh_Trainer_Skids.stl) holds a full-size $1\text{S } 550\text{mAh}$ LiHV battery ($70.0 \times 18.5 \times 7.5\text{ mm}$ tunnel) for **6.0 to 7.5 minutes of training flight time** while providing a wide $52\text{ mm}$ flexible landing stance that prevents tip-overs on takeoff and cushions hard vertical drops.
* **High-Visibility "Osito Cub" Directional Canopy:** [`CUB75_Canopy_LOS_CubDome.stl`](./cad/CUB75_Canopy_LOS_CubDome.stl) features an oversized forward pointer arrow (`+X` nose) and round bear-ear roll hoops so students can instantly see which way the drone is pointing across a room.
* **3-Stage Progressive ELRS Firmware ("Cub", "Scout", "Pilot"):** [`CUB75_Betaflight45_Kids_Trainer_CLI.txt`](./firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt) caps beginner motor authority at **68%**, limits maximum bank angle to **$22^\circ$**, slows rotation rates to a docile **$140^\circ/\text{s}$**, and enables **Headfree + Angle Mode** and **Automatic Wall-Bounce Crash Recovery**.

---

## 2. Mechanical & Dimensional Specifications

| Parameter | Specification | Engineering Justification |
| :--- | :--- | :--- |
| **Motor-to-Motor Wheelbase** | **$75.0\text{ mm}$ Diagonal** ($R_{\text{motor}} = 37.5\text{ mm}$) | True 75mm class; compact enough for indoor classrooms while clearing $40\text{ mm}$ props and a $68\text{ mm}$ long 550mAh battery. |
| **Propeller & Duct Clearance** | **$40\text{ mm}$ Props** inside **$42.0\text{ mm}$ ID / $45.2\text{ mm}$ OD Ducts** | Inboard duct edge sits at $R = 37.5 - 22.6 = 14.9\text{ mm}$, clearing the $25.5 \times 25.5\text{ mm}$ Whoop AIO FC PCB ($14.2\text{ mm}$ half-width) with zero interference. |
| **Finger-Safe Guard Architecture** | **$10.0\text{ mm}$ Tall Duct Wall + 3 Upper Ribs + 4 Bottom Struts** | Encloses the entire spinning blade plane ($Z = 2.6\text{ mm}$ to $8.4\text{ mm}$) below a $1.6\text{ mm}$ upper safety grille. |
| **FC Mounting Pattern** | **$25.5 \times 25.5\text{ mm}$ Cardinal Diamond** ($R = 18.031\text{ mm}$) | Standard M2 Whoop AIO mount at $0^\circ, 90^\circ, 180^\circ, 270^\circ$ with integrated $3.0\text{ mm}$ ESC cooling air-gap standoffs. |
| **Battery Bay & Trainer Skids** | **$70.0 \times 18.5 \times 7.5\text{ mm}$ Slot** + **$52.0\text{ mm}$ Wide Skids** | Fits all standard `1S 550mAh LiHV` packs (BetaFPV Lava / GNB / Tattu) with zero wire pinching and stable tabletop takeoffs. |
| **Dry Weight / All-Up Weight** | **$25.7\text{ g}$ Dry** / **$39.5\text{ g}$ AUW** (with $13.8\text{g}$ 550mAh pack) | Achieves a ~38% hover throttle with `0802 19,500KV` or `1002 22,000KV` motors and `40mm` props. |

---

## 3. Complete In-Office 3D-Printable CAD Suite (`cad/`)

All 6 parts in [`cad/`](./cad/) are generated from [`cad/CUB75_Parametric_Master.scad`](./cad/CUB75_Parametric_Master.scad) via [`cad/generate_cub75_stls.ps1`](./cad/generate_cub75_stls.ps1) and verified as 100% single-volume watertight manifold solids:

1. **[`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl):** Main 75mm structural frame with $360^\circ$ full-height ducts, upper/lower finger-guard grilles, and $25.5 \times 25.5\text{ mm}$ AIO mounts. Print in **PETG-CF**, **Tough PLA+**, or **ePA-CF**.
2. **[`CUB75_TPU_Bumper_Ring.stl`](./cad/CUB75_TPU_Bumper_Ring.stl):** 1-piece slip-on $360^\circ$ outer cushion belt with top/bottom retaining lips that snap over the 4 ducts. Print in **Neon TPU 95A**.
3. **[`CUB75_550mAh_Trainer_Skids.stl`](./cad/CUB75_550mAh_Trainer_Skids.stl):** Under-belly `1S 550mAh` battery sleeve with integrated $52\text{ mm}$ wide shock-absorbing landing skids. Print in **TPU 95A**.
4. **[`CUB75_Canopy_LOS_CubDome.stl`](./cad/CUB75_Canopy_LOS_CubDome.stl):** Line-of-Sight training canopy featuring a bold forward directional arrow (`+X` nose) and "Osito Cub" bear-ear roll hoops. Print in **Bright Green or Yellow TPU 95A**.
5. **[`CUB75_Canopy_FPV_Pod.stl`](./cad/CUB75_Canopy_FPV_Pod.stl):** Swap-in $14 \times 14\text{ mm}$ Nano FPV camera pod with a gentle $10^\circ$ beginner camera uptilt and whip antenna guard tube. Print in **TPU 95A**.
6. **[`CUB75_Motor_Prop_Press_Jig.stl`](./cad/CUB75_Motor_Prop_Press_Jig.stl):** Office bench tool that cradles the `0802`/`1002` motor bell from underneath while pressing on $40\text{ mm}$ propellers so you never bend a $1.5\text{ mm}$ motor shaft or crush a C-clip. Print in **PLA+ / PETG / PC-CF**.

---

## 4. Progressive 3-Stage Kids Flight Curriculum

Using the pre-configured [`firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt`](./firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt), instructors can advance students without reflashing the drone simply by switching PID/Rate profiles from the OSD menu (Left Stick Up + Left, Right Stick Left):

| Stage | Profile | Target Age / Skill | Max Tilt Angle | Max Stick Rate | Motor Output Cap | Flight Mode | Training Goal |
| :--- | :---: | :--- | :---: | :---: | :---: | :---: | :--- |
| **Stage 1: "Cub Mode"** | `Profile 0` | Ages 6–9 (First 30 Mins) | **$22^\circ$** | **$140^\circ/\text{s}$** | **68%** | `ANGLE` + `HEADFREE` | Hover in a $1.5\text{ m}$ box, throttle control, box-pattern walking, gentle tabletop landings. |
| **Stage 2: "Scout Mode"** | `Profile 1` | Ages 9–12 (Intermediate) | **$35^\circ$** | **$260^\circ/\text{s}$** | **80%** | `ANGLE` (Nose-In LOS) | Coordinated yaw + roll turns, flying figure-8s around cones, and flying through hula-hoops. |
| **Stage 3: "Pilot Mode"** | `Profile 2` | Advanced / FPV Goggles | **$50^\circ$** | **$420^\circ/\text{s}$** | **92%** | `ANGLE` or `HORIZON` | Swap on `CUB75_Canopy_FPV_Pod.stl`, flip `AUX 4` to enable $25\text{mW}$ VTX, and fly indoor gates via FPV goggles! |
