# OSITO CUB-75: In-Office Manufacturing, Assembly & ELRS Training Guide

**How to Print, Build, Configure, and Teach with the 75mm 1S 550mAh Kids Training Drone in Your Office**

---

## Phase 1: In-Office 3D Printing Guide (Zero Outsourcing Required)

You can manufacture 100% of the structural, protective, and mounting parts on any desktop FDM 3D printer (such as a Bambu Lab P1S, X1C, A1, Qidi Q1 Pro, or Creality K1C) in under **95 minutes per complete drone**.

### 1.1 Filament Selection for Office Production
Because the **CUB-75** uses a full-ring bridged truss and a slip-on **TPU 95A outer bumper belt**, you do **not** even need exotic high-temp filaments if you want a simple office workflow—though carbon-reinforced nylon/PETG makes the frame virtually immortal:
* **Option A — Easiest Office Workflow (No Enclosure / No Drying Hassle):** Print the frame (`CUB75_Frame_KidSafe_75mm.stl`) in **eSUN PLA+ / Polymaker Polylite PLA Pro** or **PETG-CF**, and print the bumper, skids, and canopy in **TPU 95A**.
* **Option B — Maximum Indestructibility (Shop Carbon Standard):** Print the frame in **eSUN ePA-CF (Nylon-CF)** or **CarbonX PC-CF** (dried at $70^\circ\text{C}$ for 6 hours), and print the bumper, skids, and canopy in **TPU 95A**.

### 1.2 Part-by-Part Print Orientation & Slicer Checklist

| STL File (`cad/`) | Material | Slicer Profile (`slicer/`) | Bed Orientation & Pro Tips | Print Time / Weight |
| :--- | :--- | :--- | :--- | :---: |
| **[`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl)** | `PETG-CF`, `PLA+`, or `ePA-CF` | [`CUB75_Frame_PETG_or_PACF_Profile.json`](./slicer/CUB75_Frame_PETG_or_PACF_Profile.json) | **Pro Tip:** Flip **upside-down ($180^\circ$)** on the build plate so the flat top of the ducts and the 3 upper finger-guard ribs print directly against the bed with minimal tree supports! | ~38 mins / `6.8g` |
| **[`CUB75_TPU_Bumper_Ring.stl`](./cad/CUB75_TPU_Bumper_Ring.stl)** | **Neon Orange or Yellow `TPU 95A`** | [`CUB75_TPU95A_Bumper_Skids_Profile.json`](./slicer/CUB75_TPU95A_Bumper_Skids_Profile.json) | Print flat ($Z = 0$). Use 3 walls, 25% gyroid infill so the outer bumper compresses like a rubber tire on wall impacts. | ~16 mins / `2.8g` |
| **[`CUB75_550mAh_Trainer_Skids.stl`](./cad/CUB75_550mAh_Trainer_Skids.stl)** | **Blue or Black `TPU 95A`** | [`CUB75_TPU95A_Bumper_Skids_Profile.json`](./slicer/CUB75_TPU95A_Bumper_Skids_Profile.json) | Already pre-oriented upside-down (`PART_ID=3`) so the battery roof prints flat on the bed and the 4 angled skid legs grow upward cleanly! | ~22 mins / `3.4g` |
| **[`CUB75_Canopy_LOS_CubDome.stl`](./cad/CUB75_Canopy_LOS_CubDome.stl)** | **Bright Green or White `TPU 95A`** | [`CUB75_TPU95A_Bumper_Skids_Profile.json`](./slicer/CUB75_TPU95A_Bumper_Skids_Profile.json) | Print flat on base ring with auto tree supports under the dome roof. Color the forward nose arrow with a contrasting permanent marker or filament swap! | ~12 mins / `1.9g` |
| **[`CUB75_Canopy_FPV_Pod.stl`](./cad/CUB75_Canopy_FPV_Pod.stl)** | **`TPU 95A`** | [`CUB75_TPU95A_Bumper_Skids_Profile.json`](./slicer/CUB75_TPU95A_Bumper_Skids_Profile.json) | Print flat on base ring. Used when students graduate to Stage 3 FPV goggles. | ~12 mins / `2.1g` |
| **[`CUB75_Motor_Prop_Press_Jig.stl`](./cad/CUB75_Motor_Prop_Press_Jig.stl)** | `PLA+` or `PETG` | [`CUB75_Frame_PETG_or_PACF_Profile.json`](./slicer/CUB75_Frame_PETG_or_PACF_Profile.json) | Print 1x or 2x for your office workbench. Supports the motor bell while pressing on $40\text{ mm}$ props. | ~8 mins / `3.1g` |

---

## Phase 2: 15-Minute Solder-Free Mechanical Assembly

By using the **BetaFPV Matrix 1S 5-in-1** or **Air 5-in-1 ELRS AIO** (which comes from the factory with a pre-soldered `BT2.0` battery lead and 4x `JST-1.25` 3-pin motor sockets), **you can assemble an entire CUB-75 with a single $1.5\text{ mm}$ hex driver and zero soldering!** *(Only solder 3 pads—`5V`, `GND`, `LED`—if you add the optional bottom COB LED strip).*

### Step 2.1 — Install Motors & Press On 40mm Props (Before Mounting Frame)
1. Take your 4x `0802 19,500KV` or `1002 22,000KV` motors (`1.5mm` shafts).
2. Place each motor into your 3D-printed **[`CUB75_Motor_Prop_Press_Jig.stl`](./cad/CUB75_Motor_Prop_Press_Jig.stl)** on the table so the motor bell is supported from below.
3. Press the $40\text{ mm}$ Gemfan `1610` or `1630` propellers onto the motor shafts using **Props-Out** orientation (so front-left and rear-right spin **CCW**, and front-right and rear-left spin **CW**):
   * **Pro Tip for Kids Orientation:** Install **2x Bright Green Props on the Front Motors** and **2x Bright Orange/Red Props on the Rear Motors**!
4. Insert each motor+prop assembly up from the inside/side of the duct onto the 4 motor bosses of [`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl) (or install the motor into the frame first with **3x `M1.4 x 3mm` screws**, then slide the prop in horizontally through the inboard duct opening and press it down while supporting the motor bottom against your bench jig).

### Step 2.2 — Snap On the 360° TPU Wall Bumper Belt
1. Stretch [`CUB75_TPU_Bumper_Ring.stl`](./cad/CUB75_TPU_Bumper_Ring.stl) around the outside of the 4 ducts on [`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl).
2. Seat the inner top and bottom TPU retaining lips over the outer rim of each duct so the bumper belt locks in place.

### Step 2.3 — Vertical M2 Stackup (Cradle + Frame + AIO FC + Canopy)

```text
================================================================================
                  OSITO CUB-75 VERTICAL M2 STACKUP ORDER
================================================================================
   [6] 4x M2 Nylon Locknuts — Hand-tighten until silicone grommets compress 15%
    │
   [5] Directional LOS Canopy (`CUB75_Canopy_LOS_CubDome.stl` — Arrow Pointing FRONT)
    │   (Or swap in `CUB75_Canopy_FPV_Pod.stl` for Stage 3 FPV Goggle Training)
    │
   [4] 1S 5-in-1 ELRS 2.4GHz AIO Flight Controller (Arrow Pointing FRONT / +X)
    │   └── Seated on 4x Silicone Soft-Mount Grommets; plug in 4x Motor Connectors
    │
   [3] Integral 3.0mm Cooling Air-Gap Standoffs on `CUB75_Frame_KidSafe_75mm.stl`
    │
   [2] Main 75mm Kid-Safe Ducted Frame (`CUB75_Frame_KidSafe_75mm.stl` + TPU Bumper)
    │
   [1] 1S 550mAh Battery Cradle & Wide Trainer Skids (`CUB75_550mAh_Trainer_Skids.stl`)
    ▲   └── Mounts via Left & Right Outboard M2 Wings at (0, ±18.031mm)
    │
   [0] 4x M2 x 12mm (or 14mm) Nylon Screws inserted from BOTTOM UP
================================================================================
```

1. Push **4x `M2 x 12mm` nylon screws** up from the bottom through the Left/Right mounting wings of [`CUB75_550mAh_Trainer_Skids.stl`](./cad/CUB75_550mAh_Trainer_Skids.stl) and the Front/Rear/Left/Right diamond holes of [`CUB75_Frame_KidSafe_75mm.stl`](./cad/CUB75_Frame_KidSafe_75mm.stl).
2. Slide the AIO Flight Controller (inside its 4 silicone grommets) down onto the 4 M2 screws, resting on top of the frame's $3.0\text{ mm}$ integral standoffs.
3. Plug the 4 motor cables into the corner sockets on the AIO board and tuck the slack neatly along the arms.
4. Place [`CUB75_Canopy_LOS_CubDome.stl`](./cad/CUB75_Canopy_LOS_CubDome.stl) on top with the **Nose Pointer Arrow facing FORWARD (`+X`)** and secure with **4x `M2` nylon locknuts**.

---

## Phase 3: Flashing the Kid-Safe Betaflight & ELRS Configuration

1. Plug a USB-C / Micro-USB data cable into the AIO Flight Controller and open **Betaflight Configurator** (`v10.10+` for Betaflight 4.5).
2. Click the **CLI** tab on the left menu.
3. Open [`firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt`](./firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt), copy the entire file, paste it into the CLI command bar, and press **Enter** (it will automatically save and reboot).
4. **Verify Motor Direction (Props-Out):**
   * With NO battery plugged in (or props checked safe), verify in the **Motors** tab that **Reverse Motor Direction (Props-Out)** is toggled **ON**:
     * `Motor 4` (Front-Left): **CCW**
     * `Motor 2` (Front-Right): **CW**
     * `Motor 3` (Rear-Left): **CW**
     * `Motor 1` (Rear-Right): **CCW**

---

## Phase 4: Binding Your ELRS Radio & Setting Up Wireless "Buddy-Box" Trainer Mode

### 4.1 Binding the Drone to an ELRS 2.4GHz Controller (e.g. Radiomaster Pocket)
1. **Method A (Betaflight GUI — Easiest):** Connect the drone to Betaflight Configurator over USB, go to the **Receiver** tab, and click the **[Bind Receiver]** button at the bottom. Then press **[Bind]** inside the ExpressLRS Lua script (`SYS -> ExpressLRS -> Bind`) on your radio.
2. **Method B (3-Plug Power Cycle):** Unplug and plug in the `1S 550mAh` battery **3 times quickly** (within 1.5 seconds each); the receiver LED will double-flash orange. Press **Bind** on your ELRS radio.
3. **Fleet Pro Tip — Set an ELRS Binding Phrase:** If you build 4+ training drones for your office/classes, assign each drone+controller pair a unique Model Match ID (`Model Match = 01`, `02`, `03`, `04`) so two kids can never accidentally bind to or arm the same drone!

### 4.2 Setting Up Wireless Instructor Override ("Buddy-Box") on EdgeTX + ELRS
When teaching young kids (ages 6–9), an instructor can hold a **Master Radio** while the child holds the **Student Radio**. If the child panics or flies toward an obstacle, the instructor simply releases (or flips) a switch on the Master Radio to **instantly take control of the drone in mid-air**:
1. Bind the **CUB-75 drone** to the **Instructor's Master Radio**.
2. On the **Student's Radiomaster Pocket**, open `SYS -> ExpressLRS` and set the mode or use **EdgeTX Multi-Module / Bluetooth / CRSF Trainer Input** (or plug a standard $3.5\text{ mm}$ TRS mono audio cable between the top `DSC` trainer jacks of the two Radiomaster Pocket controllers!).
3. On the **Master Radio**, press `MDL -> Special Functions` and add:
   * **Switch:** `SH↓` (Momentary Trainer Switch held by Instructor) -> **Action:** `Trainer` -> **Parameters:** `Sticks` -> **Enable:** `[x]`.
4. While the instructor holds `SH`, the child has 100% control of the sticks. The instant the instructor lets go of `SH`, control snaps back to the instructor's sticks!
