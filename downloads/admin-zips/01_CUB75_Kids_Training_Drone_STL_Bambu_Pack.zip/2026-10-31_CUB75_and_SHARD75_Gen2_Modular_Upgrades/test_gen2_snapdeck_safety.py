#!/usr/bin/env python3
"""
Automated Safety & Engineering Verification Script for Wave 8 — Track 8.1:
Core Fleet Gen-2 Modular Upgrade Suite (CUB-75 MK-II & SHARD-75 MK-II Snap-Deck)
Executes 40 deterministic checks (>=35/35 required) verifying:
  - Gate 1: >=70% Core Fleet Reuse
  - Gate 2: <50.0g Youth STEM Mass Ceiling across all base & loaded configurations
  - Gate 3: 16-bit timer rollover math at 65535 -> 0 wrap-around, disarmed safety interlocks,
            and Betaflight failsafe_procedure = DROP (failsafe_delay = 4)
  - Gate 4: >=60% Gross Margin & 1-Booking Payback
  - Gate 5: ositodrone.com Brand Parity & Deliverable File Integrity
"""

import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
HTML_FILE = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.html"
DOCX_FILE = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.docx"
CPP_FILE  = BASE_DIR / "gen2_snapdeck_firmware.cpp"
SCAD_FILE = BASE_DIR / "osito_pogo_snap_deck_mount.scad"


def u16_elapsed(now_ms: int, last_ms: int) -> int:
    """Emulates C++ (uint16_t)(now_ms - last_ms) unsigned 16-bit subtraction."""
    return (now_ms - last_ms) & 0xFFFF


def simulate_companion_tick(
    is_armed: bool,
    now_ms: int,
    last_heartbeat_ms: int,
    payload: str,
    trigger: bool = False,
    claw_load_g: float = 0.0,
    tof_min_mm: int = 1200,
):
    """Reference behavioral model matching gen2_snapdeck_firmware.cpp."""
    watchdog_timeout_ms = 400
    if u16_elapsed(now_ms, last_heartbeat_ms) >= watchdog_timeout_ms:
        return {
            "failsafe_active": True,
            "is_armed": False,
            "motor_pwm_us": 1000,
            "claw_pwm_us": 1500,
            "ir_fire_enable": False,
            "pitch_avoid_deg_x10": 0,
        }

    if not is_armed:
        return {
            "failsafe_active": False,
            "is_armed": False,
            "motor_pwm_us": 1000,
            "claw_pwm_us": 1500,
            "ir_fire_enable": False,
            "pitch_avoid_deg_x10": 0,
        }

    claw_pwm_us = 1500
    ir_fire_enable = False
    pitch_avoid = 0

    if payload == "SNAP_CODE":
        if tof_min_mm < 350:
            backoff = min(80, ((350 - tof_min_mm) * 2) // 10)
            pitch_avoid = -backoff
    elif payload == "SNAP_LASER":
        ir_fire_enable = bool(trigger)
    elif payload == "SNAP_CLAW":
        if claw_load_g > 12.0:
            claw_pwm_us = 1150
        elif trigger:
            claw_pwm_us = 1850
        else:
            claw_pwm_us = 1500

    return {
        "failsafe_active": False,
        "is_armed": True,
        "motor_pwm_us": 1250,
        "claw_pwm_us": claw_pwm_us,
        "ir_fire_enable": ir_fire_enable,
        "pitch_avoid_deg_x10": pitch_avoid,
    }


def run_verification():
    checks = []

    def check(name: str, condition: bool, detail: str = ""):
        checks.append((name, bool(condition), detail))

    # --- 1. Deliverable File Existence & Non-Empty Checks ---
    check("HTML engineering spec exists", HTML_FILE.is_file() and HTML_FILE.stat().st_size > 5000, str(HTML_FILE.name))
    check("DOCX engineering spec exists", DOCX_FILE.is_file() and DOCX_FILE.stat().st_size > 10000, str(DOCX_FILE.name))
    check("C++ companion firmware exists", CPP_FILE.is_file() and CPP_FILE.stat().st_size > 3000, str(CPP_FILE.name))
    check("OpenSCAD 3D CAD file exists", SCAD_FILE.is_file() and SCAD_FILE.stat().st_size > 1500, str(SCAD_FILE.name))

    html_text = HTML_FILE.read_text(encoding="utf-8")
    cpp_text  = CPP_FILE.read_text(encoding="utf-8")
    scad_text = SCAD_FILE.read_text(encoding="utf-8")

    # --- 2. Gate 2: Strict Mass Budget Verification (<50.0g Youth STEM Ceiling) ---
    cub75_base_g      = 39.5
    pogo_receptor_g   = 0.3
    cub75_mk2_base_g  = round(cub75_base_g + pogo_receptor_g, 2)
    snap_code_g       = 3.2
    snap_laser_g      = 2.6
    snap_claw_g       = 3.4
    hiker_beacon_g    = 2.0
    shard75_mk2_base  = 45.5
    shard75_heavy_mk2 = 46.8

    auw_cub_code        = round(cub75_mk2_base_g + snap_code_g, 2)
    auw_cub_claw        = round(cub75_mk2_base_g + snap_claw_g, 2)
    auw_cub_claw_beacon = round(cub75_mk2_base_g + snap_claw_g + hiker_beacon_g, 2)
    auw_shard_laser     = round(shard75_mk2_base + snap_laser_g, 2)
    auw_shard_heavy_ir  = round(shard75_heavy_mk2 + snap_laser_g, 2)

    check("CUB-75 MK-II base mass == 39.8g (<50.0g)", cub75_mk2_base_g == 39.8 and cub75_mk2_base_g < 50.0, f"{cub75_mk2_base_g}g")
    check("CUB-75 MK-II + SNAP-CODE (3.2g) == 43.0g (<50.0g)", auw_cub_code == 43.0 and auw_cub_code < 50.0, f"{auw_cub_code}g")
    check("CUB-75 MK-II + SNAP-CLAW (3.4g) == 43.2g (<50.0g)", auw_cub_claw == 43.2 and auw_cub_claw < 50.0, f"{auw_cub_claw}g")
    check("CUB-75 MK-II + SNAP-CLAW + 2.0g Beacon == 45.2g (<50.0g)", auw_cub_claw_beacon == 45.2 and auw_cub_claw_beacon < 50.0, f"{auw_cub_claw_beacon}g")
    check("SHARD-75 MK-II + SNAP-LASER (2.6g) == 48.1g (<50.0g)", auw_shard_laser == 48.1 and auw_shard_laser < 50.0, f"{auw_shard_laser}g")
    check("SHARD-75 MK-II Heavy (46.8g) + SNAP-LASER == 49.4g (<50.0g)", auw_shard_heavy_ir == 49.4 and auw_shard_heavy_ir < 50.0, f"{auw_shard_heavy_ir}g")

    # --- 3. Gate 3: 16-Bit Timer Rollover Protection at 65535 -> 0 Wrap-Around ---
    check(
        "C++ firmware enforces (uint16_t)(now_ms - last_ms) rollover pattern",
        "(uint16_t)(now_ms - last_ms) >= threshold_ms" in cpp_text
        and "(uint16_t)(now_ms - state.last_fc_heartbeat_ms) >= WATCHDOG_TIMEOUT_MS" in cpp_text,
        "Found exact unsigned 16-bit subtraction",
    )
    check(
        "16-bit rollover math across 65535 -> 0 boundary (65400 -> 100 == 236ms < 400ms nominal)",
        u16_elapsed(100, 65400) == 236 and u16_elapsed(100, 65400) < 400,
        f"elapsed={u16_elapsed(100, 65400)}ms",
    )
    check(
        "16-bit rollover math across 65535 -> 0 boundary (65300 -> 165 == 401ms >= 400ms triggers failsafe)",
        u16_elapsed(165, 65300) == 401 and u16_elapsed(165, 65300) >= 400,
        f"elapsed={u16_elapsed(165, 65300)}ms",
    )
    check(
        "16-bit rollover exact boundary (65535 -> 0 == 1ms)",
        u16_elapsed(0, 65535) == 1,
        f"elapsed={u16_elapsed(0, 65535)}ms",
    )
    check(
        "Watchdog simulation across 65535 -> 0 wrap triggers Stage-2 DROP at 400ms",
        simulate_companion_tick(True, 164, 65300, "SNAP_CLAW", trigger=True)["failsafe_active"] is True
        and simulate_companion_tick(True, 164, 65300, "SNAP_CLAW", trigger=True)["claw_pwm_us"] == 1500,
        "Failsafe locked claw=1500us, motor=1000us",
    )

    # --- 4. Gate 3: Disarmed Hardware/Software Interlocks & Overload Clutch ---
    check(
        "C++ firmware enforces disarmed actuator lock (claw_pwm_us = 1500; ir_fire_enable = false;)",
        "if (!state.is_armed)" in cpp_text
        and "state.claw_pwm_us             = 1500;" in cpp_text
        and "state.ir_fire_enable          = false;" in cpp_text,
        "Disarmed lock verified in C++ source",
    )
    disarmed_sim = simulate_companion_tick(False, 1000, 980, "SNAP_LASER", trigger=True)
    check(
        "Disarmed state blocks IR cannon firing even when pilot pulls trigger",
        disarmed_sim["ir_fire_enable"] is False and disarmed_sim["motor_pwm_us"] == 1000,
        f"ir_fire={disarmed_sim['ir_fire_enable']}, motor={disarmed_sim['motor_pwm_us']}",
    )
    disarmed_claw = simulate_companion_tick(False, 1000, 980, "SNAP_CLAW", trigger=True)
    check(
        "Disarmed state locks SNAP-CLAW at 1500us neutral even when pilot pulls trigger",
        disarmed_claw["claw_pwm_us"] == 1500,
        f"claw_pwm_us={disarmed_claw['claw_pwm_us']}",
    )
    overload_claw = simulate_companion_tick(True, 1000, 980, "SNAP_CLAW", trigger=True, claw_load_g=14.5)
    check(
        "Armed SNAP-CLAW overload clutch (>12.0g pull) auto-releases to 1150us open",
        overload_claw["claw_pwm_us"] == 1150,
        f"claw_pwm_us={overload_claw['claw_pwm_us']} at 14.5g load",
    )
    tof_avoid_sim = simulate_companion_tick(True, 1000, 980, "SNAP_CODE", tof_min_mm=200)
    check(
        "Armed SNAP-CODE VL53L5CX ToF (<350mm wall) commands repulsive pitch-back",
        tof_avoid_sim["pitch_avoid_deg_x10"] < 0,
        f"pitch_avoid_deg_x10={tof_avoid_sim['pitch_avoid_deg_x10']}",
    )

    # --- 5. Gate 3: Betaflight 4.5 CLI Failsafe & Serial Verification ---
    check("Betaflight CLI sets failsafe_procedure = DROP", "set failsafe_procedure = DROP" in html_text)
    check("Betaflight CLI sets failsafe_delay = 4 (0.4s)", "set failsafe_delay = 4" in html_text)
    check("Betaflight CLI sets min_command = 1000", "set min_command = 1000" in html_text)
    check("Betaflight CLI sets servo neutral = 1500", "servo 0 1000 2000 1500" in html_text)
    check("Betaflight CLI configures UART2 115200 baud", "serial 1 1 115200" in html_text)

    # --- 6. OpenSCAD Parametric 3D CAD Verification ---
    check("OpenSCAD specifies 25.5x25.5mm whoop mount spacing", "whoop_mount_spacing   = 25.5;" in scad_text)
    check("OpenSCAD specifies 2.54mm 4-pin pogo pitch", "pogo_pin_pitch        = 2.54;" in scad_text)
    check("OpenSCAD includes asymmetric N52 magnet polarity offsets", "n52_key_offset_y_pos" in scad_text and "n52_key_offset_y_neg" in scad_text)
    check("OpenSCAD renders osito_pogo_snap_deck_mount() module", "osito_pogo_snap_deck_mount();" in scad_text)

    # --- 7. Gate 1, Gate 4 & Gate 5: Reuse, Unit Economics & Brand Parity Checks ---
    check("Gate 1: Reuses Matrix 1S G473 / OSITO-F411 & 0802 19500KV", "Matrix 1S G473" in html_text and "OSITO-F411" in html_text and "0802 19500KV" in html_text)
    check("Gate 4: SNAP-CODE $19.50 BOM vs +$400 upsell (>=60% gross margin)", (400.0 - 19.50) / 400.0 >= 0.60 and "$19.50" in html_text and "+$400" in html_text)
    check("Gate 4: SNAP-LASER $8.40 BOM vs +$350 upsell (>=60% gross margin)", (350.0 - 8.40) / 350.0 >= 0.60 and "$8.40" in html_text and "+$350" in html_text)
    check("Gate 4: SNAP-CLAW $11.20 BOM vs +$300 upsell (>=60% gross margin)", (300.0 - 11.20) / 300.0 >= 0.60 and "$11.20" in html_text and "+$300" in html_text)
    check("Gate 4: 8-Drone fleet BOM paid back in <1.0 booking", (156.0 / 400.0) < 1.0 and (67.20 / 350.0) < 1.0)
    check("Gate 5: Uses Fjalla One + Roboto Google Fonts", "Fjalla+One" in html_text and "Roboto" in html_text)
    check("Gate 5: Uses #7077CF Periwinkle Indigo brand token", "#7077CF" in html_text)
    check("Gate 5: Uses #232A68 Deep Royal Indigo brand token", "#232A68" in html_text)
    check("Gate 5: Uses #EEF0FA Soft Lavender callout token", "#EEF0FA" in html_text)
    check("Gate 5: Uses #161616 Dark Charcoal surface token", "#161616" in html_text)
    check("C++ firmware includes DVB-S2 CRC8 packet integrity check", "compute_crc8_dvb_s2" in cpp_text)

    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)

    print("=" * 78)
    print("OSITO DRONE SERVICES — GEN-2 SNAP-DECK AUTOMATED SAFETY & ENGINEERING SUITE")
    print("=" * 78)
    for idx, (name, ok, detail) in enumerate(checks, 1):
        status = "PASS" if ok else "FAIL"
        suffix = f" [{detail}]" if detail else ""
        print(f"  [{status}] Check {idx:02d}/{total:02d}: {name}{suffix}")
    print("-" * 78)
    print(f"SUMMARY: {passed}/{total} checks passed (Required: >=35/35)")
    print("=" * 78)

    if passed < total or total < 35:
        sys.exit(1)


if __name__ == "__main__":
    run_verification()
