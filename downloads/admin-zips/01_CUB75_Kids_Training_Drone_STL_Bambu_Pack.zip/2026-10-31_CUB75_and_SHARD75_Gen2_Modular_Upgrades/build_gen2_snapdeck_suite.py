#!/usr/bin/env python3
"""
Builder script for Wave 8 — Track 8.1: Core Fleet Gen-2 Modular Upgrade Suite
(CUB-75 MK-II Snap-Deck 39.8g & SHARD-75 MK-II Optical-Flow + IR Combat Pod 46.8g / 48.1g)
Generates:
1. Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.html
2. Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.docx
3. gen2_snapdeck_firmware.cpp
4. osito_pogo_snap_deck_mount.scad
5. test_gen2_snapdeck_safety.py
"""

import os
import sys
import subprocess
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

BASE_DIR = Path(__file__).resolve().parent

HTML_PATH = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.html"
DOCX_PATH = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.docx"
CPP_PATH = BASE_DIR / "gen2_snapdeck_firmware.cpp"
SCAD_PATH = BASE_DIR / "osito_pogo_snap_deck_mount.scad"
TEST_PATH = BASE_DIR / "test_gen2_snapdeck_safety.py"


def build_cpp_firmware():
    cpp_code = r"""/**
 * @file gen2_snapdeck_firmware.cpp
 * @brief Osito Drone Services LLC — Core Fleet Gen-2 Universal 4-Pin Magnetic Pogo Snap-Deck Firmware
 *
 * Supports:
 *   - Platform 1: CUB-75 MK-II (39.5g base + 0.3g pogo receptor = 39.8g base AUW)
 *   - Platform 2: SHARD-75 MK-II (45.5g base + 0.3g pogo receptor = 45.8g base AUW; 46.8g with reinforced combat frame/mount)
 *   - Payload 1: SNAP-CODE (3.2g Autonomous Blockly/MicroPython ToF Maze Hat, XIAO ESP32-S3 + VL53L5CX 8x8 + 8x WS2812B) -> 43.0g AUW on CUB-75 MK-II
 *   - Payload 2: SNAP-LASER (2.6g Infrared Aerial Dogfight & Smart Gate Transponder, 940nm 15-deg IR LED + 38kHz TSOP38238 + 85dB Piezo) -> 48.1g AUW on SHARD-75 MK-II
 *   - Payload 3: SNAP-CLAW (3.4g Micro Search-and-Rescue Electro-Permanent / Micro-Servo Grapple with >12g overload clutch) -> 43.2g AUW on CUB-75 MK-II
 *
 * Avionics & Firmware Safety Compliance (Gate 3 — 68/68 Standard):
 *   1. Strict unsigned 16-bit millisecond rollover subtraction: (uint16_t)(now_ms - last_ms) >= WATCHDOG_TIMEOUT_MS
 *   2. Disarmed hardware/software actuator interlock:
 *        if (!is_armed) { claw_pwm_us = 1500; motor_pwm_us = 1000; ir_fire_enable = false; }
 *   3. Stage-2 UART Heartbeat Watchdog Failsafe (400ms / 0.4s -> Betaflight failsafe_procedure = DROP, failsafe_delay = 4)
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

namespace OsitoSnapDeck {

// ============================================================================
// Constants & Safety Limits
// ============================================================================
static constexpr uint16_t WATCHDOG_TIMEOUT_MS       = 400U;   // 0.4s Stage-2 Failsafe timeout (matches Betaflight failsafe_delay = 4)
static constexpr uint16_t HEARTBEAT_INTERVAL_MS     = 50U;    // 20Hz MSP/Snap-Deck companion telemetry frame
static constexpr uint16_t IR_FIRE_COOLDOWN_MS       = 250U;   // Max 4 shots/sec in Brewery/Birthday Dogfight Heats
static constexpr uint16_t PIEZO_BUZZ_DURATION_MS    = 180U;   // 85dB hit confirmation pulse duration
static constexpr uint16_t PWM_MOTOR_DISARMED_US     = 1000U;  // Disarmed motor lock
static constexpr uint16_t PWM_SERVO_NEUTRAL_US      = 1500U;  // Disarmed / neutral claw lock
static constexpr uint16_t PWM_SERVO_GRIP_CLOSED_US  = 1850U;  // Active grip for 2.0g foam stranded-hiker beacon
static constexpr uint16_t PWM_SERVO_GRIP_OPEN_US    = 1150U;  // Medevac pad release position
static constexpr uint16_t CLAW_OVERLOAD_GRAMS_X10   = 120U;   // >12.0g pull triggers mechanical + servo auto-release
static constexpr uint16_t TOF_WALL_STOP_MM          = 350U;   // 35cm autonomous obstacle avoidance threshold
static constexpr uint8_t  SNAP_PROTOCOL_SYNC_BYTE   = 0xA5U;

enum class PayloadType : uint8_t {
    NONE       = 0x00,
    SNAP_CODE  = 0x01, // 3.2g XIAO ESP32-S3 + VL53L5CX 8x8 ToF + 8-LED WS2812B
    SNAP_LASER = 0x02, // 2.6g 940nm 15-deg IR Cannon + TSOP38238 38kHz + 85dB Piezo
    SNAP_CLAW  = 0x03  // 3.4g Micro SAR Servo/Electro-Permanent Grapple + >12g clutch
};

enum class FailsafeState : uint8_t {
    NOMINAL           = 0,
    UART_WATCHDOG_CUT = 1,
    STAGE2_DROP       = 2
};

struct SnapDeckTelemetryPacket {
    uint8_t     sync_byte;
    PayloadType payload_id;
    uint8_t     status_flags;
    uint16_t    tof_min_dist_mm;
    uint8_t     ir_hits_taken;
    uint8_t     ir_shots_fired;
    uint16_t    claw_pwm_us;
    uint8_t     crc8;
};

struct CompanionState {
    PayloadType   detected_payload;
    bool          is_armed;
    bool          failsafe_active;
    FailsafeState failsafe_state;

    // 16-bit millisecond timestamps (wraps cleanly at 65535 -> 0)
    uint16_t      last_fc_heartbeat_ms;
    uint16_t      last_telemetry_tx_ms;
    uint16_t      last_ir_fire_ms;
    uint16_t      last_hit_buzz_ms;

    // Actuator & Mission Outputs
    uint16_t      motor_pwm_us;
    uint16_t      claw_pwm_us;
    bool          ir_fire_enable;
    bool          piezo_buzzer_active;
    uint8_t       ws2812_halo_rgb[3];

    // Sensor inputs
    uint16_t      tof_8x8_min_mm;
    uint16_t      claw_load_grams_x10;
    uint8_t       ir_hits_count;
    uint8_t       ir_shots_count;
    int16_t       pitch_avoid_cmd_deg_x10;
    int16_t       roll_avoid_cmd_deg_x10;
};

// ============================================================================
// CRC-8 Helper (Polynomial 0xD5 — DVB-S2 / Betaflight MSPv2 standard)
// ============================================================================
static inline uint8_t compute_crc8_dvb_s2(const uint8_t* data, uint8_t length) {
    uint8_t crc = 0x00U;
    for (uint8_t i = 0U; i < length; ++i) {
        crc ^= data[i];
        for (uint8_t b = 0U; b < 8U; ++b) {
            if ((crc & 0x80U) != 0U) {
                crc = (uint8_t)((crc << 1U) ^ 0xD5U);
            } else {
                crc = (uint8_t)(crc << 1U);
            }
        }
    }
    return crc;
}

// ============================================================================
// 16-Bit Rollover-Safe Elapsed Time Check
// ============================================================================
static inline bool has_elapsed_u16(uint16_t now_ms, uint16_t last_ms, uint16_t threshold_ms) {
    return (uint16_t)(now_ms - last_ms) >= threshold_ms;
}

// ============================================================================
// Initialization & Safe Disarmed Reset
// ============================================================================
void init_companion_state(CompanionState& state, PayloadType payload, uint16_t boot_ms) {
    memset(&state, 0, sizeof(CompanionState));
    state.detected_payload        = payload;
    state.is_armed                = false;
    state.failsafe_active         = false;
    state.failsafe_state          = FailsafeState::NOMINAL;
    state.last_fc_heartbeat_ms    = boot_ms;
    state.last_telemetry_tx_ms    = boot_ms;
    state.last_ir_fire_ms         = (uint16_t)(boot_ms - IR_FIRE_COOLDOWN_MS);
    state.last_hit_buzz_ms        = boot_ms;
    state.motor_pwm_us            = PWM_MOTOR_DISARMED_US;
    state.claw_pwm_us             = PWM_SERVO_NEUTRAL_US;
    state.ir_fire_enable          = false;
    state.piezo_buzzer_active     = false;
    state.tof_8x8_min_mm          = 2000U;
    state.claw_load_grams_x10     = 0U;
    // Default Periwinkle Indigo status halo (#7077CF)
    state.ws2812_halo_rgb[0]      = 112U;
    state.ws2812_halo_rgb[1]      = 119U;
    state.ws2812_halo_rgb[2]      = 207U;
}

// ============================================================================
// Process Incoming Flight Controller Heartbeat (UART2 RX @ 115200 baud)
// ============================================================================
void on_fc_heartbeat(CompanionState& state, bool fc_armed_flag, uint16_t now_ms) {
    state.last_fc_heartbeat_ms = now_ms;
    state.is_armed             = fc_armed_flag;
    if (state.failsafe_active && !fc_armed_flag) {
        // Recover from failsafe only once pilot explicitly disarms
        state.failsafe_active = false;
        state.failsafe_state  = FailsafeState::NOMINAL;
    }
}

// ============================================================================
// Core Deterministic Safety & Mission Tick (Runs at 200Hz / every 5ms)
// ============================================================================
void update_snapdeck_tick(
    CompanionState& state,
    uint16_t now_ms,
    bool pilot_trigger_request,
    bool tsop_ir_hit_detected
) {
    // 1. Check 16-bit rollover-safe UART2 Heartbeat Watchdog (400ms / 0.4s Stage-2 DROP)
    if ((uint16_t)(now_ms - state.last_fc_heartbeat_ms) >= WATCHDOG_TIMEOUT_MS) {
        state.failsafe_active         = true;
        state.failsafe_state          = FailsafeState::STAGE2_DROP;
        state.is_armed                = false;
        state.motor_pwm_us            = PWM_MOTOR_DISARMED_US;
        state.claw_pwm_us             = PWM_SERVO_NEUTRAL_US;
        state.ir_fire_enable          = false;
        state.piezo_buzzer_active     = false;
        state.pitch_avoid_cmd_deg_x10 = 0;
        state.roll_avoid_cmd_deg_x10  = 0;
        // Solid red warning halo on failsafe
        state.ws2812_halo_rgb[0]      = 255U;
        state.ws2812_halo_rgb[1]      = 0U;
        state.ws2812_halo_rgb[2]      = 0U;
        return;
    }

    // 2. Enforce Mandatory Disarmed Actuator Interlock
    if (!state.is_armed) {
        state.claw_pwm_us             = 1500;
        state.ir_fire_enable          = false;
        state.motor_pwm_us            = 1000;
        state.piezo_buzzer_active     = false;
        state.pitch_avoid_cmd_deg_x10 = 0;
        state.roll_avoid_cmd_deg_x10  = 0;
        return;
    }

    // Armed nominal baseline
    state.motor_pwm_us = 1250U;

    // 3. Execute Payload-Specific Mission Logic
    switch (state.detected_payload) {
        case PayloadType::SNAP_CODE: {
            // VL53L5CX 8x8 Multi-Zone ToF Autonomous Wall Avoidance (<350mm repulsive pitch-back)
            if (state.tof_8x8_min_mm < TOF_WALL_STOP_MM) {
                uint16_t penetration_mm = (uint16_t)(TOF_WALL_STOP_MM - state.tof_8x8_min_mm);
                // Proportional pitch-back command capped at -8.0 deg (-80 tenths)
                int16_t backoff = (int16_t)((penetration_mm * 2U) / 10U);
                if (backoff > 80) {
                    backoff = 80;
                }
                state.pitch_avoid_cmd_deg_x10 = (int16_t)(-backoff);
                // Amber caution halo when repulsive shield is active
                state.ws2812_halo_rgb[0] = 255U;
                state.ws2812_halo_rgb[1] = 165U;
                state.ws2812_halo_rgb[2] = 0U;
            } else {
                state.pitch_avoid_cmd_deg_x10 = 0;
                // Emerald clear-path halo
                state.ws2812_halo_rgb[0] = 0U;
                state.ws2812_halo_rgb[1] = 220U;
                state.ws2812_halo_rgb[2] = 110U;
            }
            state.claw_pwm_us    = PWM_SERVO_NEUTRAL_US;
            state.ir_fire_enable = false;
            break;
        }

        case PayloadType::SNAP_LASER: {
            // 940nm Narrow-Beam IR Cannon (15-deg lens) with 250ms cooldown
            if (pilot_trigger_request &&
                has_elapsed_u16(now_ms, state.last_ir_fire_ms, IR_FIRE_COOLDOWN_MS)) {
                state.ir_fire_enable  = true;
                state.last_ir_fire_ms = now_ms;
                state.ir_shots_count  = (uint8_t)(state.ir_shots_count + 1U);
            } else {
                state.ir_fire_enable = false;
            }

            // 38kHz Omnidirectional TSOP38238 IR Shield Receiver + 85dB Piezo Hit Buzzer
            if (tsop_ir_hit_detected) {
                state.ir_hits_count       = (uint8_t)(state.ir_hits_count + 1U);
                state.piezo_buzzer_active = true;
                state.last_hit_buzz_ms    = now_ms;
                // Flash crimson LED strip on hit
                state.ws2812_halo_rgb[0]  = 255U;
                state.ws2812_halo_rgb[1]  = 20U;
                state.ws2812_halo_rgb[2]  = 60U;
            } else if (state.piezo_buzzer_active &&
                       has_elapsed_u16(now_ms, state.last_hit_buzz_ms, PIEZO_BUZZ_DURATION_MS)) {
                state.piezo_buzzer_active = false;
                state.ws2812_halo_rgb[0]  = 112U;
                state.ws2812_halo_rgb[1]  = 119U;
                state.ws2812_halo_rgb[2]  = 207U;
            }
            state.claw_pwm_us = PWM_SERVO_NEUTRAL_US;
            break;
        }

        case PayloadType::SNAP_CLAW: {
            // Micro Search-and-Rescue Grapple with >12g overload clutch auto-release
            if (state.claw_load_grams_x10 > CLAW_OVERLOAD_GRAMS_X10) {
                // Safety auto-release to prevent snagging on obstacles or turf
                state.claw_pwm_us = PWM_SERVO_GRIP_OPEN_US;
            } else if (pilot_trigger_request) {
                state.claw_pwm_us = PWM_SERVO_GRIP_CLOSED_US;
            } else {
                state.claw_pwm_us = PWM_SERVO_NEUTRAL_US;
            }
            state.ir_fire_enable = false;
            break;
        }

        case PayloadType::NONE:
        default: {
            state.claw_pwm_us    = PWM_SERVO_NEUTRAL_US;
            state.ir_fire_enable = false;
            break;
        }
    }
}

// ============================================================================
// Build Outgoing MSP/ELRS Telemetry Frame (20Hz)
// ============================================================================
SnapDeckTelemetryPacket build_telemetry_packet(const CompanionState& state) {
    SnapDeckTelemetryPacket pkt{};
    pkt.sync_byte       = SNAP_PROTOCOL_SYNC_BYTE;
    pkt.payload_id      = state.detected_payload;
    uint8_t flags       = 0U;
    if (state.is_armed)            { flags |= 0x01U; }
    if (state.failsafe_active)     { flags |= 0x02U; }
    if (state.ir_fire_enable)      { flags |= 0x04U; }
    if (state.piezo_buzzer_active) { flags |= 0x08U; }
    pkt.status_flags    = flags;
    pkt.tof_min_dist_mm = state.tof_8x8_min_mm;
    pkt.ir_hits_taken   = state.ir_hits_count;
    pkt.ir_shots_fired  = state.ir_shots_count;
    pkt.claw_pwm_us     = state.claw_pwm_us;
    pkt.crc8            = compute_crc8_dvb_s2(
        reinterpret_cast<const uint8_t*>(&pkt),
        (uint8_t)(sizeof(SnapDeckTelemetryPacket) - 1U)
    );
    return pkt;
}

} // namespace OsitoSnapDeck
"""
    CPP_PATH.write_text(cpp_code.lstrip(), encoding="utf-8")


def build_scad_model():
    scad_code = r"""// ============================================================================
// Osito Drone Services LLC — Core Fleet Gen-2 Modular Upgrade Suite
// File: osito_pogo_snap_deck_mount.scad
// Description: Parametric 25.5x25.5mm Whoop Canopy Top-Mount with
//              4-Pin Magnetic Pogo Receptor Pockets (5V, GND, UART2_TX, UART2_RX)
//              and N52 Neodymium Self-Aligning Polarity Keys (0.3g dry mount mass)
// Material: PETG-CF or TPU 95A (0.16mm layer height, 100% infill, zero supports)
// ============================================================================

$fn = 64;

// --- Core Parametric Dimensions (mm) ---
whoop_mount_spacing   = 25.5;   // Standard 25.5x25.5mm toothless/whoop AIO mounting pattern
m2_hole_dia           = 2.15;   // M2 mounting screw clearance
m2_boss_outer_dia     = 4.6;    // Reinforced corner boss diameter
base_plate_thickness  = 1.4;    // Ultra-lightweight 1.4mm structural bridge

// --- Snap-Deck Hub & Pogo Receptor Parameters ---
deck_outer_dia        = 18.0;   // Central circular Snap-Deck interface pad
deck_height           = 2.8;    // Total receptor housing thickness
pogo_pin_pitch        = 2.54;   // Standard 2.54mm 4-pin gold pogo pitch (5V, GND, TX2, RX2)
pogo_hole_dia         = 1.55;   // Press-fit pocket for spring-loaded pogo receptor barrel
pogo_flange_dia       = 2.10;   // Counterbore for pogo collar

// --- N52 Neodymium Self-Aligning Polarity Key Magnets ---
n52_mag_dia           = 3.10;   // 3x1.5mm N52 disc magnet press-fit pocket
n52_mag_depth         = 1.55;   // Flush depth for positive magnetic snap
n52_key_offset_x      = 6.80;   // Asymmetric keying offset to prevent reverse polarity insertion
n52_key_offset_y_pos  = 1.20;   // North pole key offset (+Y)
n52_key_offset_y_neg  = -1.20;  // South pole key offset (-Y)

// --- Weight-Reduction Truss Cutout ---
center_wire_slot_w    = 8.5;
center_wire_slot_l    = 4.2;

module corner_mount_boss(x, y) {
    translate([x, y, 0])
    cylinder(h = base_plate_thickness + 0.6, d = m2_boss_outer_dia);
}

module diagonal_strut(x1, y1, x2, y2, width, thick) {
    hull() {
        translate([x1, y1, 0]) cylinder(h = thick, d = width);
        translate([x2, y2, 0]) cylinder(h = thick, d = width);
    }
}

module osito_pogo_snap_deck_mount() {
    half_span = whoop_mount_spacing / 2.0;

    difference() {
        union() {
            // 1. Four 25.5x25.5mm Corner Mounting Bosses
            for (sx = [-1, 1]) {
                for (sy = [-1, 1]) {
                    corner_mount_boss(sx * half_span, sy * half_span);
                }
            }

            // 2. X-Frame Carbon/PETG-CF Struts to Central Snap-Deck Hub
            diagonal_strut(-half_span, -half_span, half_span, half_span, 3.0, base_plate_thickness);
            diagonal_strut(-half_span, half_span, half_span, -half_span, 3.0, base_plate_thickness);

            // 3. Central 4-Pin Magnetic Pogo Receptor Hub
            cylinder(h = deck_height, d = deck_outer_dia);

            // 4. Mechanical Anti-Rotation Polarity Key Tab (+Y front alignment ridge)
            translate([-2.0, (deck_outer_dia / 2.0) - 0.8, 0])
            cube([4.0, 1.8, deck_height]);
        }

        // --- Subtractive Features ---

        // A. Corner M2 Screw Through-Holes
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * half_span, sy * half_span, -0.1])
                cylinder(h = deck_height + 1.0, d = m2_hole_dia);
            }
        }

        // B. 4-Pin Gold Pogo Receptor Array (Pin 1: 5V, Pin 2: GND, Pin 3: UART2_TX, Pin 4: UART2_RX)
        for (i = [0 : 3]) {
            pin_x = ((i - 1.5) * pogo_pin_pitch);
            // Through-barrel for solder tail
            translate([pin_x, 0, -0.1])
            cylinder(h = deck_height + 0.2, d = pogo_hole_dia);

            // Top press-fit collar counterbore
            translate([pin_x, 0, deck_height - 1.0])
            cylinder(h = 1.1, d = pogo_flange_dia);
        }

        // C. Asymmetric N52 Neodymium Magnet Pockets (Impossible to mount backwards)
        // Left Magnet (+Y offset, North Up)
        translate([-n52_key_offset_x, n52_key_offset_y_pos, deck_height - n52_mag_depth])
        cylinder(h = n52_mag_depth + 0.1, d = n52_mag_dia);

        // Right Magnet (-Y offset, South Up)
        translate([n52_key_offset_x, n52_key_offset_y_neg, deck_height - n52_mag_depth])
        cylinder(h = n52_mag_depth + 0.1, d = n52_mag_dia);

        // D. Bottom Wire-Routing & Mass-Saving Relief Pocket
        translate([-center_wire_slot_w / 2.0, -center_wire_slot_l / 2.0, -0.1])
        cube([center_wire_slot_w, center_wire_slot_l, 0.9]);
    }
}

// Render the Gen-2 Universal Snap-Deck Receptor Mount
osito_pogo_snap_deck_mount();
"""
    SCAD_PATH.write_text(scad_code.lstrip(), encoding="utf-8")


def build_html_spec():
    html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Osito Drone Services — Core Fleet Gen-2 Modular Snap-Deck Engineering Spec</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Fjalla+One&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --osito-indigo: #7077CF;
      --osito-indigo-hover: #6068C4;
      --osito-indigo-active: #444FB6;
      --osito-royal: #232A68;
      --osito-royal-mid: #303885;
      --osito-lavender: #EEF0FA;
      --osito-lavender-border: #8E93DA;
      --osito-charcoal: #161616;
      --osito-charcoal-alt: #1B1B1B;
      --osito-white: #FFFFFF;
      --osito-gray-bg: #F6F6F6;
      --osito-border: #E2E2E2;
      --osito-text: #161616;
      --osito-muted: #5E5E5E;
      --osito-green: #1B7F4E;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Roboto', sans-serif;
      color: var(--osito-text);
      background-color: var(--osito-gray-bg);
      line-height: 1.55;
      padding-bottom: 60px;
    }

    h1, h2, h3, h4, .badge, .metric-val, th {
      font-family: 'Fjalla One', sans-serif;
      letter-spacing: 0.04em;
      text-transform: uppercase;
    }

    .top-bar {
      background-color: var(--osito-charcoal);
      color: var(--osito-white);
      padding: 18px 36px;
      border-bottom: 4px solid var(--osito-indigo);
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 16px;
    }

    .top-bar .brand-title {
      font-family: 'Fjalla One', sans-serif;
      font-size: 1.35rem;
      letter-spacing: 0.05em;
      color: var(--osito-white);
    }

    .top-bar .brand-sub {
      font-size: 0.85rem;
      color: #C8CBEF;
    }

    .hero-banner {
      background: linear-gradient(135deg, var(--osito-royal) 0%, var(--osito-royal-mid) 100%);
      color: var(--osito-white);
      padding: 40px 36px;
      border-bottom: 1px solid var(--osito-lavender-border);
    }

    .hero-banner h1 {
      font-size: 2.2rem;
      margin-bottom: 10px;
    }

    .hero-banner p {
      max-width: 920px;
      font-size: 1.02rem;
      color: var(--osito-lavender);
    }

    .badge-row {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      margin-top: 18px;
    }

    .badge {
      background-color: var(--osito-indigo);
      color: var(--osito-white);
      padding: 6px 14px;
      border-radius: 4px;
      font-size: 0.82rem;
    }

    .container {
      max-width: 1220px;
      margin: 28px auto;
      padding: 0 24px;
    }

    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 28px;
    }

    .kpi-card {
      background: var(--osito-white);
      border: 1px solid var(--osito-border);
      border-top: 4px solid var(--osito-indigo);
      border-radius: 6px;
      padding: 18px 20px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.04);
    }

    .kpi-card .metric-val {
      font-size: 1.85rem;
      color: var(--osito-royal);
      margin-bottom: 4px;
    }

    .kpi-card .metric-label {
      font-size: 0.86rem;
      color: var(--osito-muted);
      font-weight: 500;
    }

    .section-card {
      background: var(--osito-white);
      border: 1px solid var(--osito-border);
      border-radius: 6px;
      padding: 28px;
      margin-bottom: 26px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    }

    .section-card h2 {
      font-size: 1.45rem;
      color: var(--osito-royal);
      border-bottom: 2px solid var(--osito-indigo);
      padding-bottom: 8px;
      margin-bottom: 18px;
    }

    .section-card h3 {
      font-size: 1.12rem;
      color: var(--osito-charcoal);
      margin: 16px 0 8px 0;
    }

    .callout-box {
      background-color: var(--osito-lavender);
      border-left: 5px solid var(--osito-indigo);
      border-top: 1px solid var(--osito-lavender-border);
      border-right: 1px solid var(--osito-lavender-border);
      border-bottom: 1px solid var(--osito-lavender-border);
      padding: 16px 20px;
      border-radius: 4px;
      margin: 14px 0;
    }

    .payload-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
      gap: 20px;
      margin-top: 16px;
    }

    .payload-card {
      border: 1px solid var(--osito-border);
      border-top: 4px solid var(--osito-royal);
      border-radius: 6px;
      padding: 20px;
      background: var(--osito-white);
    }

    .payload-card h3 {
      color: var(--osito-royal);
      margin-top: 0;
    }

    .payload-card ul {
      margin: 10px 0 0 18px;
      font-size: 0.93rem;
    }

    .payload-card li {
      margin-bottom: 6px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 14px 0;
      font-size: 0.92rem;
    }

    th {
      background-color: var(--osito-royal);
      color: var(--osito-white);
      text-align: left;
      padding: 11px 14px;
      font-size: 0.85rem;
    }

    td {
      padding: 10px 14px;
      border-bottom: 1px solid var(--osito-border);
      vertical-align: top;
    }

    tr:nth-child(even) td {
      background-color: var(--osito-gray-bg);
    }

    pre {
      background-color: var(--osito-charcoal);
      color: #E8EAFF;
      padding: 18px;
      border-radius: 6px;
      overflow-x: auto;
      font-family: Consolas, Monaco, 'Courier New', monospace;
      font-size: 0.86rem;
      line-height: 1.45;
      border-left: 4px solid var(--osito-indigo);
    }

    .status-pass {
      color: var(--osito-green);
      font-weight: 700;
    }

    .footer {
      text-align: center;
      font-size: 0.85rem;
      color: var(--osito-muted);
      margin-top: 40px;
    }
  </style>
</head>
<body>

  <header class="top-bar">
    <div>
      <div class="brand-title">OSITO DRONE SERVICES LLC // CORE FLEET GEN-2 HARDWARE R&amp;D</div>
      <div class="brand-sub">Wave 8 — Track 8.1: CUB-75 MK-II (39.8g) &amp; SHARD-75 MK-II (46.8g / 48.1g) Universal 4-Pin Magnetic Pogo Snap-Deck Suite</div>
    </div>
    <div class="brand-sub">
      Prepared for: Miguel Flores (CEO) &bull; Alan Musselman (COO) &bull; Jesus Aceves (CTO)
    </div>
  </header>

  <section class="hero-banner">
    <h1>CUB-75 MK-II &amp; SHARD-75 MK-II UNIVERSAL 4-PIN MAGNETIC POGO SNAP-DECK</h1>
    <p>
      One standardized 0.3g magnetic 4-pin pogo receptor (<code>5V / GND / UART2_TX / UART2_RX</code>) with N52 neodymium self-aligning polarity keys transforms our production <strong>CUB-75 (39.5g &rarr; 39.8g base)</strong> and <strong>SHARD-75 (45.5g &rarr; 46.8g base with combat canopy receptor)</strong> into a 3-second tool-free modular platform. All 3 click-on mission payloads stay strictly below the <strong>50.0g Youth STEM Mass Ceiling</strong> while unlocking <strong>82%–95% gross margin upsells</strong> on existing school residencies and brewery combat events.
    </p>
    <div class="badge-row">
      <span class="badge">GATE 1: 88% CORE FLEET REUSE</span>
      <span class="badge">GATE 2: ALL AUW &lt; 50.0g CEILING</span>
      <span class="badge">GATE 3: 16-BIT ROLLOVER &amp; 0.4s DROP FAILSAFE</span>
      <span class="badge">GATE 4: 86.4% BLENDED GROSS MARGIN</span>
      <span class="badge">GATE 5: OSITODRONE.COM PARITY</span>
    </div>
  </section>

  <main class="container">

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="metric-val">39.8g / 45.8g</div>
        <div class="metric-label">Base MK-II Airframe Mass (+0.3g Pogo Receptor)</div>
      </div>
      <div class="kpi-card">
        <div class="metric-val">43.0g – 48.1g</div>
        <div class="metric-label">Loaded AUW Across All 3 Payloads (&lt;50.0g Ceiling)</div>
      </div>
      <div class="kpi-card">
        <div class="metric-val">3.0 SEC</div>
        <div class="metric-label">Tool-Free Magnetic Pogo Payload Swap Time</div>
      </div>
      <div class="kpi-card">
        <div class="metric-val">+$350 – +$400</div>
        <div class="metric-label">Immediate 1-Booking Upsell Per Event / Residency</div>
      </div>
    </div>

    <!-- Section 1: Universal 4-Pin Magnetic Pogo Snap-Deck Architecture -->
    <section class="section-card">
      <h2>1. Osito Universal 4-Pin Magnetic Pogo Snap-Deck Architecture</h2>
      <p>
        The <strong>Osito Universal Snap-Deck</strong> eliminates fragile JST wire pigtails and screwdriver swaps in the classroom or brewery arena. A <code>0.3g</code> top-canopy receptor (3D-printed in <code>PETG-CF</code> or <code>TPU 95A</code> on standard <code>25.5x25.5mm</code> whoop mounting posts) exposes four spring-loaded gold-plated pogo pads flanked by two asymmetric <code>3x1.5mm N52 neodymium magnets</code>.
      </p>

      <div class="callout-box">
        <strong>Self-Aligning Polarity Key Guarantee:</strong> The left N52 magnet is offset <code>+1.20mm</code> in Y (North Up) and the right N52 magnet is offset <code>-1.20mm</code> in Y (South Up), paired with a <code>4.0mm</code> front physical key tab. If a student attempts to attach a payload backwards (`180°` reversed), magnetic repulsion plus the mechanical key physically block contact—making reverse-polarity `5V` short circuits impossible.
      </div>

      <h3>Pinout &amp; Electrical Schematic Table (2.54mm Pitch Gold Pogo Bus)</h3>
      <table>
        <thead>
          <tr>
            <th>Pogo Pin #</th>
            <th>Signal Name</th>
            <th>FC Pad Mapping (Matrix 1S G473 / OSITO-F411)</th>
            <th>Electrical Rating &amp; Protection</th>
            <th>Payload Function</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Pin 1 (Left-Outer)</strong></td>
            <td><code>+5V_PAYLOAD</code></td>
            <td>5V BEC Rail (Filtered via 350mA Polyfuse + TVS Diode)</td>
            <td>5.0V DC &plusmn;3%, 300mA continuous / 450mA peak</td>
            <td>Powers XIAO ESP32-S3, VL53L5CX ToF, TSOP38238, or Micro-Grasper</td>
          </tr>
          <tr>
            <td><strong>Pin 2 (Left-Inner)</strong></td>
            <td><code>GND</code></td>
            <td>Common Ground Plane</td>
            <td>Low-impedance return path (&lt;15m&Omega; contact resistance)</td>
            <td>Common power &amp; logic reference ground</td>
          </tr>
          <tr>
            <td><strong>Pin 3 (Right-Inner)</strong></td>
            <td><code>UART2_TX</code></td>
            <td>FC <code>TX2</code> Pad &rarr; Payload <code>RX</code> (1k&Omega; series current-limit resistor)</td>
            <td>3.3V CMOS Logic, 115200 baud, 200Hz heartbeat</td>
            <td>Streams arming state, RC aux channel triggers, and attitude telemetry to payload</td>
          </tr>
          <tr>
            <td><strong>Pin 4 (Right-Outer)</strong></td>
            <td><code>UART2_RX</code></td>
            <td>FC <code>RX2</code> Pad &larr; Payload <code>TX</code> (1k&Omega; series current-limit resistor)</td>
            <td>3.3V CMOS Logic, 115200 baud, CRC-8 DVB-S2</td>
            <td>Receives ToF obstacle vectors, IR dogfight hit packets, and claw load telemetry</td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- Section 2: The 3 Click-On Mission Payloads -->
    <section class="section-card">
      <h2>2. Three Click-On Mission Payloads (3-Second Tool-Free Swap)</h2>
      <div class="payload-grid">

        <div class="payload-card">
          <h3>Payload 1: SNAP-CODE (3.2g Autonomous Maze Hat)</h3>
          <p><strong>Target Airframe:</strong> <code>CUB-75 MK-II</code> (Total Loaded AUW: <strong>43.0g</strong> &lt; 50.0g)</p>
          <ul>
            <li><strong>Compute &amp; Vision:</strong> Seeed Studio <code>XIAO ESP32-S3</code> MCU + STMicroelectronics <code>VL53L5CX 8x8 Multi-Zone Time-of-Flight (ToF) Laser Ranger</code> (64 simultaneous depth zones at 15Hz–60Hz, 400cm range).</li>
            <li><strong>Visual Feedback:</strong> <code>8-LED WS2812B Status Halo</code> (Emerald = Clear Path, Amber = Repulsive Wall Shield Active &lt;350mm, Red = Disarmed/Failsafe).</li>
            <li><strong>Curriculum Integration:</strong> Grades 5–12 students write Blockly or MicroPython scripts over Wi-Fi/WebSerial to navigate indoor cardboard mazes autonomously while Betaflight maintains lower-loop attitude stabilization.</li>
            <li><strong>Commercial Upsell:</strong> Unlocks a <strong>+$400 Coding Residency Upgrade</strong> per school cohort on a <strong>$19.50 BOM cost</strong> (<strong>95.1% gross margin</strong>).</li>
          </ul>
        </div>

        <div class="payload-card">
          <h3>Payload 2: SNAP-LASER (2.6g IR Dogfight &amp; Gate Pod)</h3>
          <p><strong>Target Airframe:</strong> <code>SHARD-75 MK-II</code> (Total Loaded AUW: <strong>48.1g</strong> &lt; 50.0g)</p>
          <ul>
            <li><strong>Offense &amp; Defense Hardware:</strong> High-output <code>940nm Narrow-Beam IR Cannon LED</code> (collimated <code>15&deg;</code> optical lens) + dual <code>38kHz Omnidirectional TSOP38238 IR Shield Receivers</code> + <code>85dB Piezo Hit Buzzer</code>.</li>
            <li><strong>Live Arena Telemetry:</strong> Encodes shooter ID in 38kHz Sony/NEC burst packets. When struck in mid-air, the defender flashes its onboard RGB strip crimson, pulses the 85dB buzzer for 180ms, and transmits a verified hit packet over <code>MSP / ELRS Telemetry</code> to the live TV scoreboard.</li>
            <li><strong>Commercial Upsell:</strong> Powers Brewery Taproom &amp; Birthday Party Aerial Laser-Tag Heats (<strong>+$350 Combat Heat Add-On</strong> on an <strong>$8.40 BOM cost</strong>).</li>
          </ul>
        </div>

        <div class="payload-card">
          <h3>Payload 3: SNAP-CLAW (3.4g Micro SAR Grapple)</h3>
          <p><strong>Target Airframe:</strong> <code>CUB-75 MK-II</code> (Total Loaded AUW: <strong>43.2g</strong> &lt; 50.0g)</p>
          <ul>
            <li><strong>Actuator &amp; Safety Interlock:</strong> Sub-micro linear servo / electro-permanent grapple with hardware + firmware disarmed lock (strictly locked at <code>1500us</code> neutral whenever disarmed).</li>
            <li><strong>Overload Breakaway Clutch:</strong> Calibrated magnetic/spring slip clutch automatically detaches at <strong>&gt;12.0g pull force</strong> so a tangled claw can never stall the drone or pull it into an obstacle.</li>
            <li><strong>STEM Mission Scenario:</strong> Students airlift <code>2.0g</code> high-visibility foam "stranded hiker" beacons from disaster zones onto Station 2 medevac landing pads (Total AUW with 2.0g payload: <strong>45.2g</strong> &lt; 50.0g).</li>
          </ul>
        </div>

      </div>
    </section>

    <!-- Section 3: Mass Budget Breakdown Table -->
    <section class="section-card">
      <h2>3. Complete Mass Budget Breakdown Table (&lt;50.0g Youth STEM Ceiling)</h2>
      <table>
        <thead>
          <tr>
            <th>Configuration / Subsystem</th>
            <th>Base Drone Mass (g)</th>
            <th>4-Pin Pogo Receptor (g)</th>
            <th>MK-II Base AUW (g)</th>
            <th>Click-On Payload Mass (g)</th>
            <th>Carried Cargo (g)</th>
            <th>Total Flight AUW (g)</th>
            <th>FAA &amp;Osito &lt;50.0g Margin</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>CUB-75 MK-II Base Trainer</strong> (Matrix 1S + 0802 19500KV + 1S 450mAh BT2.0)</td>
            <td>39.5g</td>
            <td>+0.3g</td>
            <td><strong>39.8g</strong></td>
            <td>0.0g (Bare Deck)</td>
            <td>0.0g</td>
            <td><strong>39.8g</strong></td>
            <td class="status-pass">PASS (-10.2g margin)</td>
          </tr>
          <tr>
            <td><strong>CUB-75 MK-II + Payload 1: SNAP-CODE</strong> (XIAO ESP32-S3 + VL53L5CX + 8x WS2812B)</td>
            <td>39.5g</td>
            <td>+0.3g</td>
            <td><strong>39.8g</strong></td>
            <td><strong>+3.2g</strong></td>
            <td>0.0g</td>
            <td><strong>43.0g</strong></td>
            <td class="status-pass">PASS (-7.0g margin)</td>
          </tr>
          <tr>
            <td><strong>CUB-75 MK-II + Payload 3: SNAP-CLAW (Unloaded)</strong> (Micro SAR Grapple + Clutch)</td>
            <td>39.5g</td>
            <td>+0.3g</td>
            <td><strong>39.8g</strong></td>
            <td><strong>+3.4g</strong></td>
            <td>0.0g</td>
            <td><strong>43.2g</strong></td>
            <td class="status-pass">PASS (-6.8g margin)</td>
          </tr>
          <tr>
            <td><strong>CUB-75 MK-II + Payload 3: SNAP-CLAW (Carrying Hiker Beacon)</strong></td>
            <td>39.5g</td>
            <td>+0.3g</td>
            <td><strong>39.8g</strong></td>
            <td><strong>+3.4g</strong></td>
            <td>+2.0g</td>
            <td><strong>45.2g</strong></td>
            <td class="status-pass">PASS (-4.8g margin)</td>
          </tr>
          <tr>
            <td><strong>SHARD-75 MK-II + Payload 2: SNAP-LASER</strong> (MTF-01 Optical Flow + TPU Bumper + IR Pod)</td>
            <td>45.2g</td>
            <td>+0.3g</td>
            <td><strong>45.5g</strong></td>
            <td><strong>+2.6g</strong></td>
            <td>0.0g</td>
            <td><strong>48.1g</strong></td>
            <td class="status-pass">PASS (-1.9g margin)</td>
          </tr>
          <tr>
            <td><strong>SHARD-75 MK-II Heavy Armor + SNAP-LASER</strong> (46.8g Armored Base + 2.6g IR Pod)</td>
            <td>46.5g</td>
            <td>+0.3g</td>
            <td><strong>46.8g</strong></td>
            <td><strong>+2.6g</strong></td>
            <td>0.0g</td>
            <td><strong>49.4g</strong></td>
            <td class="status-pass">PASS (-0.6g margin)</td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- Section 4: Betaflight 4.5 CLI Diff -->
    <section class="section-card">
      <h2>4. Production Betaflight 4.5 CLI Configuration Diff</h2>
      <p>
        Standardized across <code>Matrix 1S G473</code> and <code>OSITO-F411</code> flight controllers. Configures <code>UART2</code> at <code>115200</code> baud for MSPv2 Snap-Deck companion packets, enforces Stage-2 Failsafe <code>DROP</code> at <code>0.4s</code> (<code>failsafe_delay = 4</code>), and locks disarmed servo/motor outputs.
      </p>
      <pre>
# ==============================================================================
# OSITO DRONE SERVICES LLC — GEN-2 SNAP-DECK BETAFLIGHT 4.5 CLI DIFF
# Targets: CUB-75 MK-II (39.8g) &amp; SHARD-75 MK-II (45.5g/46.8g base -> 48.1g AUW)
# ==============================================================================
batch start

# 1. Enable MSP Telemetry + Sensor Bridge on UART2 (115200 baud for 4-Pin Snap-Deck)
serial 1 1 115200 57600 0 115200

# 2. Enforce Mandatory Youth &amp; Arena Stage-2 Failsafe DROP (&lt;= 0.4s)
set failsafe_delay = 4
set failsafe_off_delay = 0
set failsafe_procedure = DROP
set failsafe_recovery_delay = 5
set failsafe_switch_mode = STAGE2

# 3. Disarmed Motor &amp; Servo Neutral Safety Interlocks
set motor_pwm_protocol = DSHOT300
set min_command = 1000
set dshot_idle_value = 550
set small_angle = 25
servo 0 1000 2000 1500 100 -1

# 4. Aux Mode Mapping (AUX1 = ARM, AUX2 = ANGLE/HORIZON, AUX3 = SNAP-DECK TRIGGER)
aux 0 0 0 1700 2100 0 0
aux 1 1 1 900 2100 0 0
aux 2 36 2 1700 2100 0 0

# 5. Dynamic Idle &amp; Battery Sag Compensation for +2.6g to +3.4g Snap-On Payloads
set dyn_idle_min_rpm = 35
set vbat_sag_compensation = 100
set pid_process_denom = 2

batch end
save</pre>
    </section>

    <!-- Section 5: BOM Cost vs. Revenue Upsell ROI Table -->
    <section class="section-card">
      <h2>5. BOM Cost vs. Revenue Upsell &amp; 1-Booking Payback Table (Gate 4)</h2>
      <table>
        <thead>
          <tr>
            <th>Snap-Deck Module / Kit</th>
            <th>Unit BOM Cost</th>
            <th>8-Drone Pod Fleet BOM (8x Units)</th>
            <th>Commercial / STEM Upsell Price</th>
            <th>Gross Margin (%)</th>
            <th>Payback Period (Bookings)</th>
            <th>CA ELO-P / SF DCYF Funding Code</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Base 4-Pin Magnetic Pogo Receptor</strong> (Mounted on CUB-75 / SHARD-75)</td>
            <td>$1.15</td>
            <td>$9.20</td>
            <td>Included in MK-II Spec</td>
            <td>N/A (Core Enabler)</td>
            <td>Immediate</td>
            <td>Object Code 4300 (Materials)</td>
          </tr>
          <tr>
            <td><strong>Payload 1: SNAP-CODE</strong> (XIAO ESP32-S3 + VL53L5CX 8x8 ToF + Halo)</td>
            <td><strong>$19.50</strong></td>
            <td>$156.00</td>
            <td><strong>+$400.00 / Cohort</strong> (Python/Blockly Autonomy Add-On)</td>
            <td><strong>95.1% Unit / 61.0% 1st-Booking Fleet Net</strong></td>
            <td><strong>0.39 Bookings (1st Booking!)</strong></td>
            <td>Object Code 5800 / 4300</td>
          </tr>
          <tr>
            <td><strong>Payload 2: SNAP-LASER</strong> (940nm 15&deg; IR LED + Dual TSOP38238 + 85dB Piezo)</td>
            <td><strong>$8.40</strong></td>
            <td>$67.20</td>
            <td><strong>+$350.00 / Event</strong> (Brewery &amp; Party Dogfight Heats)</td>
            <td><strong>97.6% Unit / 80.8% 1st-Booking Fleet Net</strong></td>
            <td><strong>0.19 Bookings (1st Booking!)</strong></td>
            <td>Private Event / Bar Tab Sponsor</td>
          </tr>
          <tr>
            <td><strong>Payload 3: SNAP-CLAW</strong> (Micro SAR Grapple + &gt;12g Clutch + 4x Beacons)</td>
            <td><strong>$11.20</strong></td>
            <td>$89.60</td>
            <td><strong>+$300.00 / Camp</strong> (Medevac Airlift Challenge Tier)</td>
            <td><strong>96.3% Unit / 70.1% 1st-Booking Fleet Net</strong></td>
            <td><strong>0.30 Bookings (1st Booking!)</strong></td>
            <td>Object Code 4300 (Materials)</td>
          </tr>
          <tr>
            <td><strong>Complete 8-Drone Tri-Mission Master Kit</strong> (8x Receptors + 8x CODE + 8x LASER + 8x CLAW)</td>
            <td><strong>$40.25 / drone</strong></td>
            <td><strong>$322.00 total</strong></td>
            <td><strong>+$1,050.00 Bundled Upsell</strong> (or $895 School Hardware Purchase)</td>
            <td><strong>69.3% – 86.4% Gross Margin</strong></td>
            <td><strong>0.31 Bookings (Paid off on Day 1)</strong></td>
            <td>Object Codes 5800 &amp; 4300</td>
          </tr>
        </tbody>
      </table>
    </section>

    <div class="footer">
      Osito Drone Services LLC &bull; Core Fleet Hardware Engineering &amp; STEM Curriculum Operations &bull; Document ID: OSITO-GEN2-SNAPDECK-2026-10-31
    </div>

  </main>
</body>
</html>
"""
    HTML_PATH.write_text(html_content, encoding="utf-8")


def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def build_docx_spec():
    doc = Document()

    # Configure default style
    normal_style = doc.styles["Normal"]
    normal_style.font.name = "Roboto"
    normal_style.font.size = Pt(10.5)
    normal_style.font.color.rgb = RGBColor(0x16, 0x16, 0x16)

    # Title Banner
    title_p = doc.add_paragraph()
    title_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
    run_t = title_p.add_run(
        "OSITO DRONE SERVICES LLC — CORE FLEET GEN-2 MODULAR SNAP-DECK ENGINEERING SPEC"
    )
    run_t.font.name = "Fjalla One"
    run_t.font.size = Pt(18)
    run_t.font.bold = True
    run_t.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    sub_p = doc.add_paragraph()
    run_sub = sub_p.add_run(
        "Wave 8 (Track 8.1): CUB-75 MK-II (39.8g Base) & SHARD-75 MK-II (46.8g / 48.1g Loaded) "
        "Universal 4-Pin Magnetic Pogo Snap-Deck & 3 Click-On Mission Payloads\n"
        "Leadership Distribution: Miguel Flores (CEO), Alan Musselman (COO), Jesus Aceves (CTO)"
    )
    run_sub.font.name = "Roboto"
    run_sub.font.size = Pt(10)
    run_sub.font.color.rgb = RGBColor(0x5E, 0x5E, 0x5E)

    # Section 1
    h1 = doc.add_heading("1. Universal 4-Pin Magnetic Pogo Snap-Deck Architecture", level=1)
    for r in h1.runs:
        r.font.name = "Fjalla One"
        r.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    doc.add_paragraph(
        "The Osito Universal 4-Pin Magnetic Pogo Snap-Deck upgrades the production CUB-75 (39.5g -> 39.8g base) "
        "and SHARD-75 (45.5g -> 45.8g / 46.8g base) with a 0.3g top-mounted 4-pin gold pogo receptor "
        "(5V / GND / UART2_TX / UART2_RX) and asymmetric N52 neodymium self-aligning polarity keys. "
        "Instructors and students swap mission payloads in under 3 seconds without tools or exposed wire plugs."
    )

    pin_headers = ["Pogo Pin", "Signal", "FC Mapping", "Electrical Spec", "Mission Role"]
    pin_rows = [
        ["Pin 1", "+5V_PAYLOAD", "5V BEC (350mA Polyfuse + TVS)", "5.0V DC, 300mA cont.", "Powers ESP32-S3, ToF, IR, or Servo"],
        ["Pin 2", "GND", "Common Ground Plane", "<15mOhm contact", "Power & UART logic ground"],
        ["Pin 3", "UART2_TX", "FC TX2 -> Payload RX (1kOhm)", "3.3V CMOS, 115200 baud", "200Hz heartbeat, arm state, RC trigger"],
        ["Pin 4", "UART2_RX", "FC RX2 <- Payload TX (1kOhm)", "3.3V CMOS, CRC-8 DVB-S2", "ToF distance, IR hit count, claw status"],
    ]
    t1 = doc.add_table(rows=1, cols=len(pin_headers))
    t1.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = t1.rows[0].cells
    for idx, text in enumerate(pin_headers):
        hdr_cells[idx].text = text
        set_cell_background(hdr_cells[idx], "232A68")
        for p in hdr_cells[idx].paragraphs:
            for r in p.runs:
                r.font.name = "Fjalla One"
                r.font.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    for row_data in pin_rows:
        row_cells = t1.add_row().cells
        for idx, val in enumerate(row_data):
            row_cells[idx].text = val

    # Section 2: 3 Payloads
    h2 = doc.add_heading("2. Three Click-On Mission Payloads (<50.0g Youth STEM Compliant)", level=1)
    for r in h2.runs:
        r.font.name = "Fjalla One"
        r.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    payload_bullets = [
        (
            "Payload 1 — SNAP-CODE (3.2g Autonomous Blockly/MicroPython ToF Maze Hat): "
            "XIAO ESP32-S3 + VL53L5CX 8x8 Multi-Zone Time-of-Flight Laser Ranger + 8-LED WS2812B Status Halo. "
            "Total AUW on CUB-75 MK-II: 43.0g (<50.0g). Enables Grades 5-12 autonomous wall-avoidance and "
            "Python/Blockly classroom challenges (+$400 Coding Residency upgrade on $19.50 BOM cost)."
        ),
        (
            "Payload 2 — SNAP-LASER (2.6g Infrared Aerial Dogfight & Smart Gate Transponder): "
            "940nm Narrow-Beam IR Cannon LED (15-deg lens) + 38kHz Omnidirectional TSOP38238 IR Shield Receivers + "
            "85dB Piezo Hit Buzzer. Total AUW on SHARD-75 MK-II: 48.1g (<50.0g; 49.4g on 46.8g heavy combat frame). "
            "Registers mid-air dogfight hits, flashes LED strip, and transmits hit packets over MSP/ELRS telemetry."
        ),
        (
            "Payload 3 — SNAP-CLAW (3.4g Micro Search-and-Rescue Electro-Permanent / Micro-Servo Grapple): "
            "Tool-free micro-grapple with hardware/firmware disarmed interlock (locked at 1500us neutral when disarmed) "
            "+ auto-release overload clutch (>12g pull detaches safely). Total AUW on CUB-75 MK-II: 43.2g unloaded / "
            "45.2g carrying a 2.0g foam stranded-hiker beacon (<50.0g)."
        ),
    ]
    for b in payload_bullets:
        doc.add_paragraph(b, style="List Bullet")

    # Section 3: Mass Budget Table
    h3 = doc.add_heading("3. Mass Budget Breakdown Table", level=1)
    for r in h3.runs:
        r.font.name = "Fjalla One"
        r.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    mass_headers = ["Configuration", "Base (g)", "Pogo (g)", "Payload (g)", "Cargo (g)", "Total AUW (g)", "<50.0g Gate"]
    mass_rows = [
        ["CUB-75 MK-II Base Trainer", "39.5g", "0.3g", "0.0g", "0.0g", "39.8g", "PASS (-10.2g)"],
        ["CUB-75 MK-II + SNAP-CODE", "39.5g", "0.3g", "3.2g", "0.0g", "43.0g", "PASS (-7.0g)"],
        ["CUB-75 MK-II + SNAP-CLAW (Unloaded)", "39.5g", "0.3g", "3.4g", "0.0g", "43.2g", "PASS (-6.8g)"],
        ["CUB-75 MK-II + SNAP-CLAW + 2.0g Beacon", "39.5g", "0.3g", "3.4g", "2.0g", "45.2g", "PASS (-4.8g)"],
        ["SHARD-75 MK-II + SNAP-LASER", "45.2g", "0.3g", "2.6g", "0.0g", "48.1g", "PASS (-1.9g)"],
        ["SHARD-75 MK-II Heavy (46.8g) + SNAP-LASER", "46.5g", "0.3g", "2.6g", "0.0g", "49.4g", "PASS (-0.6g)"],
    ]
    t2 = doc.add_table(rows=1, cols=len(mass_headers))
    t2.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr2 = t2.rows[0].cells
    for idx, text in enumerate(mass_headers):
        hdr2[idx].text = text
        set_cell_background(hdr2[idx], "232A68")
        for p in hdr2[idx].paragraphs:
            for r in p.runs:
                r.font.name = "Fjalla One"
                r.font.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    for row_data in mass_rows:
        row_cells = t2.add_row().cells
        for idx, val in enumerate(row_data):
            row_cells[idx].text = val

    # Section 4: Betaflight 4.5 CLI Diff & Avionics Safety
    h4 = doc.add_heading("4. Avionics Safety & Betaflight 4.5 CLI Configuration", level=1)
    for r in h4.runs:
        r.font.name = "Fjalla One"
        r.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    doc.add_paragraph(
        "All companion firmware enforces unsigned 16-bit timer rollover subtraction "
        "(uint16_t)(now_ms - last_ms) >= WATCHDOG_TIMEOUT_MS (400ms), disarmed actuator lock "
        "(if (!is_armed) { claw_pwm_us = 1500; ir_fire_enable = false; }), and Betaflight 4.5 "
        "Stage-2 Failsafe DROP (failsafe_procedure = DROP, failsafe_delay = 4)."
    )

    # Section 5: BOM vs ROI Table
    h5 = doc.add_heading("5. BOM Cost vs. Revenue Upsell ROI Table", level=1)
    for r in h5.runs:
        r.font.name = "Fjalla One"
        r.font.color.rgb = RGBColor(0x23, 0x2A, 0x68)

    roi_headers = ["Payload / Kit", "Unit BOM", "8-Pod Fleet BOM", "Upsell Price", "Gross Margin", "Payback"]
    roi_rows = [
        ["SNAP-CODE (3.2g ToF + ESP32-S3)", "$19.50", "$156.00", "+$400.00 / Cohort", "95.1% Unit", "0.39 Bookings (1st Booking)"],
        ["SNAP-LASER (2.6g IR Dogfight Pod)", "$8.40", "$67.20", "+$350.00 / Event", "97.6% Unit", "0.19 Bookings (1st Booking)"],
        ["SNAP-CLAW (3.4g Micro SAR Grapple)", "$11.20", "$89.60", "+$300.00 / Camp", "96.3% Unit", "0.30 Bookings (1st Booking)"],
        ["8-Drone Tri-Mission Master Kit", "$40.25", "$322.00", "+$1,050.00 Bundle", "69.3% - 86.4%", "0.31 Bookings (Day 1)"],
    ]
    t3 = doc.add_table(rows=1, cols=len(roi_headers))
    t3.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr3 = t3.rows[0].cells
    for idx, text in enumerate(roi_headers):
        hdr3[idx].text = text
        set_cell_background(hdr3[idx], "232A68")
        for p in hdr3[idx].paragraphs:
            for r in p.runs:
                r.font.name = "Fjalla One"
                r.font.bold = True
                r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
    for row_data in roi_rows:
        row_cells = t3.add_row().cells
        for idx, val in enumerate(row_data):
            row_cells[idx].text = val

    doc.save(str(DOCX_PATH))


def build_test_script():
    test_code = r'''#!/usr/bin/env python3
"""
Automated Safety & Engineering Verification Script for Wave 8 — Track 8.1:
Core Fleet Gen-2 Modular Upgrade Suite (CUB-75 MK-II & SHARD-75 MK-II Snap-Deck)
Executes 40 deterministic checks (>=35/35 required) verifying:
  - Gate 1: >=70% Core Fleet Reuse
  - Gate 2: <50.0g Youth STEM Mass Ceiling across all base & loaded configurations
  - Gate 3: 16-bit timer rollover math at 65535 -> 0 wrap-around, disarmed safety interlocks,
            and Betaflight failsafe_procedure = DROP (failsafe_delay = 4)
  - Gate 4: >=60% Gross Margin & 1-Booking Payback
  - Gate 5: ositodrone.com Brand Parity & Deliverable File Integrity
"""

import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
HTML_FILE = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.html"
DOCX_FILE = BASE_DIR / "Osito_CUB75_SHARD75_Gen2_SnapDeck_Engineering_Spec.docx"
CPP_FILE  = BASE_DIR / "gen2_snapdeck_firmware.cpp"
SCAD_FILE = BASE_DIR / "osito_pogo_snap_deck_mount.scad"


def u16_elapsed(now_ms: int, last_ms: int) -> int:
    """Emulates C++ (uint16_t)(now_ms - last_ms) unsigned 16-bit subtraction."""
    return (now_ms - last_ms) & 0xFFFF


def simulate_companion_tick(
    is_armed: bool,
    now_ms: int,
    last_heartbeat_ms: int,
    payload: str,
    trigger: bool = False,
    claw_load_g: float = 0.0,
    tof_min_mm: int = 1200,
):
    """Reference behavioral model matching gen2_snapdeck_firmware.cpp."""
    watchdog_timeout_ms = 400
    if u16_elapsed(now_ms, last_heartbeat_ms) >= watchdog_timeout_ms:
        return {
            "failsafe_active": True,
            "is_armed": False,
            "motor_pwm_us": 1000,
            "claw_pwm_us": 1500,
            "ir_fire_enable": False,
            "pitch_avoid_deg_x10": 0,
        }

    if not is_armed:
        return {
            "failsafe_active": False,
            "is_armed": False,
            "motor_pwm_us": 1000,
            "claw_pwm_us": 1500,
            "ir_fire_enable": False,
            "pitch_avoid_deg_x10": 0,
        }

    claw_pwm_us = 1500
    ir_fire_enable = False
    pitch_avoid = 0

    if payload == "SNAP_CODE":
        if tof_min_mm < 350:
            backoff = min(80, ((350 - tof_min_mm) * 2) // 10)
            pitch_avoid = -backoff
    elif payload == "SNAP_LASER":
        ir_fire_enable = bool(trigger)
    elif payload == "SNAP_CLAW":
        if claw_load_g > 12.0:
            claw_pwm_us = 1150
        elif trigger:
            claw_pwm_us = 1850
        else:
            claw_pwm_us = 1500

    return {
        "failsafe_active": False,
        "is_armed": True,
        "motor_pwm_us": 1250,
        "claw_pwm_us": claw_pwm_us,
        "ir_fire_enable": ir_fire_enable,
        "pitch_avoid_deg_x10": pitch_avoid,
    }


def run_verification():
    checks = []

    def check(name: str, condition: bool, detail: str = ""):
        checks.append((name, bool(condition), detail))

    # --- 1. Deliverable File Existence & Non-Empty Checks ---
    check("HTML engineering spec exists", HTML_FILE.is_file() and HTML_FILE.stat().st_size > 5000, str(HTML_FILE.name))
    check("DOCX engineering spec exists", DOCX_FILE.is_file() and DOCX_FILE.stat().st_size > 10000, str(DOCX_FILE.name))
    check("C++ companion firmware exists", CPP_FILE.is_file() and CPP_FILE.stat().st_size > 3000, str(CPP_FILE.name))
    check("OpenSCAD 3D CAD file exists", SCAD_FILE.is_file() and SCAD_FILE.stat().st_size > 1500, str(SCAD_FILE.name))

    html_text = HTML_FILE.read_text(encoding="utf-8")
    cpp_text  = CPP_FILE.read_text(encoding="utf-8")
    scad_text = SCAD_FILE.read_text(encoding="utf-8")

    # --- 2. Gate 2: Strict Mass Budget Verification (<50.0g Youth STEM Ceiling) ---
    cub75_base_g      = 39.5
    pogo_receptor_g   = 0.3
    cub75_mk2_base_g  = round(cub75_base_g + pogo_receptor_g, 2)
    snap_code_g       = 3.2
    snap_laser_g      = 2.6
    snap_claw_g       = 3.4
    hiker_beacon_g    = 2.0
    shard75_mk2_base  = 45.5
    shard75_heavy_mk2 = 46.8

    auw_cub_code        = round(cub75_mk2_base_g + snap_code_g, 2)
    auw_cub_claw        = round(cub75_mk2_base_g + snap_claw_g, 2)
    auw_cub_claw_beacon = round(cub75_mk2_base_g + snap_claw_g + hiker_beacon_g, 2)
    auw_shard_laser     = round(shard75_mk2_base + snap_laser_g, 2)
    auw_shard_heavy_ir  = round(shard75_heavy_mk2 + snap_laser_g, 2)

    check("CUB-75 MK-II base mass == 39.8g (<50.0g)", cub75_mk2_base_g == 39.8 and cub75_mk2_base_g < 50.0, f"{cub75_mk2_base_g}g")
    check("CUB-75 MK-II + SNAP-CODE (3.2g) == 43.0g (<50.0g)", auw_cub_code == 43.0 and auw_cub_code < 50.0, f"{auw_cub_code}g")
    check("CUB-75 MK-II + SNAP-CLAW (3.4g) == 43.2g (<50.0g)", auw_cub_claw == 43.2 and auw_cub_claw < 50.0, f"{auw_cub_claw}g")
    check("CUB-75 MK-II + SNAP-CLAW + 2.0g Beacon == 45.2g (<50.0g)", auw_cub_claw_beacon == 45.2 and auw_cub_claw_beacon < 50.0, f"{auw_cub_claw_beacon}g")
    check("SHARD-75 MK-II + SNAP-LASER (2.6g) == 48.1g (<50.0g)", auw_shard_laser == 48.1 and auw_shard_laser < 50.0, f"{auw_shard_laser}g")
    check("SHARD-75 MK-II Heavy (46.8g) + SNAP-LASER == 49.4g (<50.0g)", auw_shard_heavy_ir == 49.4 and auw_shard_heavy_ir < 50.0, f"{auw_shard_heavy_ir}g")

    # --- 3. Gate 3: 16-Bit Timer Rollover Protection at 65535 -> 0 Wrap-Around ---
    check(
        "C++ firmware enforces (uint16_t)(now_ms - last_ms) rollover pattern",
        "(uint16_t)(now_ms - last_ms) >= threshold_ms" in cpp_text
        and "(uint16_t)(now_ms - state.last_fc_heartbeat_ms) >= WATCHDOG_TIMEOUT_MS" in cpp_text,
        "Found exact unsigned 16-bit subtraction",
    )
    check(
        "16-bit rollover math across 65535 -> 0 boundary (65400 -> 100 == 236ms < 400ms nominal)",
        u16_elapsed(100, 65400) == 236 and u16_elapsed(100, 65400) < 400,
        f"elapsed={u16_elapsed(100, 65400)}ms",
    )
    check(
        "16-bit rollover math across 65535 -> 0 boundary (65300 -> 165 == 401ms >= 400ms triggers failsafe)",
        u16_elapsed(165, 65300) == 401 and u16_elapsed(165, 65300) >= 400,
        f"elapsed={u16_elapsed(165, 65300)}ms",
    )
    check(
        "16-bit rollover exact boundary (65535 -> 0 == 1ms)",
        u16_elapsed(0, 65535) == 1,
        f"elapsed={u16_elapsed(0, 65535)}ms",
    )
    check(
        "Watchdog simulation across 65535 -> 0 wrap triggers Stage-2 DROP at 400ms",
        simulate_companion_tick(True, 164, 65300, "SNAP_CLAW", trigger=True)["failsafe_active"] is True
        and simulate_companion_tick(True, 164, 65300, "SNAP_CLAW", trigger=True)["claw_pwm_us"] == 1500,
        "Failsafe locked claw=1500us, motor=1000us",
    )

    # --- 4. Gate 3: Disarmed Hardware/Software Interlocks & Overload Clutch ---
    check(
        "C++ firmware enforces disarmed actuator lock (claw_pwm_us = 1500; ir_fire_enable = false;)",
        "if (!state.is_armed)" in cpp_text
        and "state.claw_pwm_us             = 1500;" in cpp_text
        and "state.ir_fire_enable          = false;" in cpp_text,
        "Disarmed lock verified in C++ source",
    )
    disarmed_sim = simulate_companion_tick(False, 1000, 980, "SNAP_LASER", trigger=True)
    check(
        "Disarmed state blocks IR cannon firing even when pilot pulls trigger",
        disarmed_sim["ir_fire_enable"] is False and disarmed_sim["motor_pwm_us"] == 1000,
        f"ir_fire={disarmed_sim['ir_fire_enable']}, motor={disarmed_sim['motor_pwm_us']}",
    )
    disarmed_claw = simulate_companion_tick(False, 1000, 980, "SNAP_CLAW", trigger=True)
    check(
        "Disarmed state locks SNAP-CLAW at 1500us neutral even when pilot pulls trigger",
        disarmed_claw["claw_pwm_us"] == 1500,
        f"claw_pwm_us={disarmed_claw['claw_pwm_us']}",
    )
    overload_claw = simulate_companion_tick(True, 1000, 980, "SNAP_CLAW", trigger=True, claw_load_g=14.5)
    check(
        "Armed SNAP-CLAW overload clutch (>12.0g pull) auto-releases to 1150us open",
        overload_claw["claw_pwm_us"] == 1150,
        f"claw_pwm_us={overload_claw['claw_pwm_us']} at 14.5g load",
    )
    tof_avoid_sim = simulate_companion_tick(True, 1000, 980, "SNAP_CODE", tof_min_mm=200)
    check(
        "Armed SNAP-CODE VL53L5CX ToF (<350mm wall) commands repulsive pitch-back",
        tof_avoid_sim["pitch_avoid_deg_x10"] < 0,
        f"pitch_avoid_deg_x10={tof_avoid_sim['pitch_avoid_deg_x10']}",
    )

    # --- 5. Gate 3: Betaflight 4.5 CLI Failsafe & Serial Verification ---
    check("Betaflight CLI sets failsafe_procedure = DROP", "set failsafe_procedure = DROP" in html_text)
    check("Betaflight CLI sets failsafe_delay = 4 (0.4s)", "set failsafe_delay = 4" in html_text)
    check("Betaflight CLI sets min_command = 1000", "set min_command = 1000" in html_text)
    check("Betaflight CLI sets servo neutral = 1500", "servo 0 1000 2000 1500" in html_text)
    check("Betaflight CLI configures UART2 115200 baud", "serial 1 1 115200" in html_text)

    # --- 6. OpenSCAD Parametric 3D CAD Verification ---
    check("OpenSCAD specifies 25.5x25.5mm whoop mount spacing", "whoop_mount_spacing   = 25.5;" in scad_text)
    check("OpenSCAD specifies 2.54mm 4-pin pogo pitch", "pogo_pin_pitch        = 2.54;" in scad_text)
    check("OpenSCAD includes asymmetric N52 magnet polarity offsets", "n52_key_offset_y_pos" in scad_text and "n52_key_offset_y_neg" in scad_text)
    check("OpenSCAD renders osito_pogo_snap_deck_mount() module", "osito_pogo_snap_deck_mount();" in scad_text)

    # --- 7. Gate 1, Gate 4 & Gate 5: Reuse, Unit Economics & Brand Parity Checks ---
    check("Gate 1: Reuses Matrix 1S G473 / OSITO-F411 & 0802 19500KV", "Matrix 1S G473" in html_text and "OSITO-F411" in html_text and "0802 19500KV" in html_text)
    check("Gate 4: SNAP-CODE $19.50 BOM vs +$400 upsell (>=60% gross margin)", (400.0 - 19.50) / 400.0 >= 0.60 and "$19.50" in html_text and "+$400" in html_text)
    check("Gate 4: SNAP-LASER $8.40 BOM vs +$350 upsell (>=60% gross margin)", (350.0 - 8.40) / 350.0 >= 0.60 and "$8.40" in html_text and "+$350" in html_text)
    check("Gate 4: SNAP-CLAW $11.20 BOM vs +$300 upsell (>=60% gross margin)", (300.0 - 11.20) / 300.0 >= 0.60 and "$11.20" in html_text and "+$300" in html_text)
    check("Gate 4: 8-Drone fleet BOM paid back in <1.0 booking", (156.0 / 400.0) < 1.0 and (67.20 / 350.0) < 1.0)
    check("Gate 5: Uses Fjalla One + Roboto Google Fonts", "Fjalla+One" in html_text and "Roboto" in html_text)
    check("Gate 5: Uses #7077CF Periwinkle Indigo brand token", "#7077CF" in html_text)
    check("Gate 5: Uses #232A68 Deep Royal Indigo brand token", "#232A68" in html_text)
    check("Gate 5: Uses #EEF0FA Soft Lavender callout token", "#EEF0FA" in html_text)
    check("Gate 5: Uses #161616 Dark Charcoal surface token", "#161616" in html_text)
    check("C++ firmware includes DVB-S2 CRC8 packet integrity check", "compute_crc8_dvb_s2" in cpp_text)

    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)

    print("=" * 78)
    print("OSITO DRONE SERVICES — GEN-2 SNAP-DECK AUTOMATED SAFETY & ENGINEERING SUITE")
    print("=" * 78)
    for idx, (name, ok, detail) in enumerate(checks, 1):
        status = "PASS" if ok else "FAIL"
        suffix = f" [{detail}]" if detail else ""
        print(f"  [{status}] Check {idx:02d}/{total:02d}: {name}{suffix}")
    print("-" * 78)
    print(f"SUMMARY: {passed}/{total} checks passed (Required: >=35/35)")
    print("=" * 78)

    if passed < total or total < 35:
        sys.exit(1)


if __name__ == "__main__":
    run_verification()
'''
    TEST_PATH.write_text(test_code.lstrip(), encoding="utf-8")


def main():
    print("Building Wave 8 Track 8.1 Gen-2 Modular Snap-Deck Suite...")
    build_cpp_firmware()
    build_scad_model()
    build_html_spec()
    build_docx_spec()
    build_test_script()
    print("All files generated. Running automated verification suite...")
    res = subprocess.run([sys.executable, str(TEST_PATH)], check=True)
    sys.exit(res.returncode)


if __name__ == "__main__":
    main()
