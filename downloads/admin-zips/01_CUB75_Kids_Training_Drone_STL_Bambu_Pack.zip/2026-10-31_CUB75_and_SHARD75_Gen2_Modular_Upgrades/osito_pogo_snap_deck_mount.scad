// ============================================================================
// Osito Drone Services LLC — Core Fleet Gen-2 Modular Upgrade Suite
// File: osito_pogo_snap_deck_mount.scad
// Description: Parametric 25.5x25.5mm Whoop Canopy Top-Mount with
//              4-Pin Magnetic Pogo Receptor Pockets (5V, GND, UART2_TX, UART2_RX)
//              and N52 Neodymium Self-Aligning Polarity Keys (0.3g dry mount mass)
// Material: PETG-CF or TPU 95A (0.16mm layer height, 100% infill, zero supports)
// ============================================================================

$fn = 64;

// --- Core Parametric Dimensions (mm) ---
whoop_mount_spacing   = 25.5;   // Standard 25.5x25.5mm toothless/whoop AIO mounting pattern
m2_hole_dia           = 2.15;   // M2 mounting screw clearance
m2_boss_outer_dia     = 4.6;    // Reinforced corner boss diameter
base_plate_thickness  = 1.4;    // Ultra-lightweight 1.4mm structural bridge

// --- Snap-Deck Hub & Pogo Receptor Parameters ---
deck_outer_dia        = 18.0;   // Central circular Snap-Deck interface pad
deck_height           = 2.8;    // Total receptor housing thickness
pogo_pin_pitch        = 2.54;   // Standard 2.54mm 4-pin gold pogo pitch (5V, GND, TX2, RX2)
pogo_hole_dia         = 1.55;   // Press-fit pocket for spring-loaded pogo receptor barrel
pogo_flange_dia       = 2.10;   // Counterbore for pogo collar

// --- N52 Neodymium Self-Aligning Polarity Key Magnets ---
n52_mag_dia           = 3.10;   // 3x1.5mm N52 disc magnet press-fit pocket
n52_mag_depth         = 1.55;   // Flush depth for positive magnetic snap
n52_key_offset_x      = 6.80;   // Asymmetric keying offset to prevent reverse polarity insertion
n52_key_offset_y_pos  = 1.20;   // North pole key offset (+Y)
n52_key_offset_y_neg  = -1.20;  // South pole key offset (-Y)

// --- Weight-Reduction Truss Cutout ---
center_wire_slot_w    = 8.5;
center_wire_slot_l    = 4.2;

module corner_mount_boss(x, y) {
    translate([x, y, 0])
    cylinder(h = base_plate_thickness + 0.6, d = m2_boss_outer_dia);
}

module diagonal_strut(x1, y1, x2, y2, width, thick) {
    hull() {
        translate([x1, y1, 0]) cylinder(h = thick, d = width);
        translate([x2, y2, 0]) cylinder(h = thick, d = width);
    }
}

module osito_pogo_snap_deck_mount() {
    half_span = whoop_mount_spacing / 2.0;

    difference() {
        union() {
            // 1. Four 25.5x25.5mm Corner Mounting Bosses
            for (sx = [-1, 1]) {
                for (sy = [-1, 1]) {
                    corner_mount_boss(sx * half_span, sy * half_span);
                }
            }

            // 2. X-Frame Carbon/PETG-CF Struts to Central Snap-Deck Hub
            diagonal_strut(-half_span, -half_span, half_span, half_span, 3.0, base_plate_thickness);
            diagonal_strut(-half_span, half_span, half_span, -half_span, 3.0, base_plate_thickness);

            // 3. Central 4-Pin Magnetic Pogo Receptor Hub
            cylinder(h = deck_height, d = deck_outer_dia);

            // 4. Mechanical Anti-Rotation Polarity Key Tab (+Y front alignment ridge)
            translate([-2.0, (deck_outer_dia / 2.0) - 0.8, 0])
            cube([4.0, 1.8, deck_height]);
        }

        // --- Subtractive Features ---

        // A. Corner M2 Screw Through-Holes
        for (sx = [-1, 1]) {
            for (sy = [-1, 1]) {
                translate([sx * half_span, sy * half_span, -0.1])
                cylinder(h = deck_height + 1.0, d = m2_hole_dia);
            }
        }

        // B. 4-Pin Gold Pogo Receptor Array (Pin 1: 5V, Pin 2: GND, Pin 3: UART2_TX, Pin 4: UART2_RX)
        for (i = [0 : 3]) {
            pin_x = ((i - 1.5) * pogo_pin_pitch);
            // Through-barrel for solder tail
            translate([pin_x, 0, -0.1])
            cylinder(h = deck_height + 0.2, d = pogo_hole_dia);

            // Top press-fit collar counterbore
            translate([pin_x, 0, deck_height - 1.0])
            cylinder(h = 1.1, d = pogo_flange_dia);
        }

        // C. Asymmetric N52 Neodymium Magnet Pockets (Impossible to mount backwards)
        // Left Magnet (+Y offset, North Up)
        translate([-n52_key_offset_x, n52_key_offset_y_pos, deck_height - n52_mag_depth])
        cylinder(h = n52_mag_depth + 0.1, d = n52_mag_dia);

        // Right Magnet (-Y offset, South Up)
        translate([n52_key_offset_x, n52_key_offset_y_neg, deck_height - n52_mag_depth])
        cylinder(h = n52_mag_depth + 0.1, d = n52_mag_dia);

        // D. Bottom Wire-Routing & Mass-Saving Relief Pocket
        translate([-center_wire_slot_w / 2.0, -center_wire_slot_l / 2.0, -0.1])
        cube([center_wire_slot_w, center_wire_slot_l, 0.9]);
    }
}

// Render the Gen-2 Universal Snap-Deck Receptor Mount
osito_pogo_snap_deck_mount();
