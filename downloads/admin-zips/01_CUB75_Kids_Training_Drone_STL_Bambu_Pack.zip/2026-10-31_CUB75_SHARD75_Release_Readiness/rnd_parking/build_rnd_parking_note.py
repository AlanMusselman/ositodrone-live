﻿#!/usr/bin/env python3
"""Builds R&D_Parking_Note.docx - which speculative concepts stay parked so they cannot block CUB-75 / SHARD-75 / revenue work.
Facts used: folder names / file counts / first headings read from the workspace on 2026-10-31. Recommendations are advisory; NO folders were moved."""
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import docx_kit as K  # noqa: E402

ROOT = HERE.parents[3]
HW = ROOT / "03_Hardware_and_Drones"

# (concept, where, files, verdict, why, re-entry trigger)
KEEP_ACTIVE = [
    ("CUB-75 / SHARD-75 (KODIAK-75)", "Core_Fleet/Kids Training Drone; Active_Subprojects/Bumper Drones", "Revenue core (STEM Academy + arena events). This release."),
    ("CUB-75 / SHARD-75 Gen-2 Snap-Deck", "Core_Fleet/2026-10-31_CUB75_and_SHARD75_Gen2_Modular_Upgrades", "Active only after the patched firmware (C3) and bench gates close; payload sales ($300-$400 upsells in its spec) depend on that."),
    ("Firefly-65 / Titan-85, Aero-Cub K-5, Hover65, OSITO-65", "Core_Fleet", "Named core-fleet / classroom products in GEMINI.md."),
    ("THERMO-95 HVAC inspection drone", "Active_Subprojects/HVAC Inspection Drone", "Supports the commercial roof/HVAC inspection revenue track."),
    ("AI Security Drone, smart_disc_golf, TurboPaw race track", "AI Security Drone/, Active_Subprojects", "Named active subprojects in GEMINI.md; keep, but outside this release's gates."),
]
PARKED = [
    ("APEXJET-1800 turbine VTOL UAV", "RnD_Concepts_Archive/Osito_ApexJet_1800_Turbine_UAV", "5", "STAY PARKED",
     "Blueprint states 1,850 lb nominal MTOW - a different regulatory/capital class from the sub-250 g fleet; no near-term revenue path.", "Funded customer + aviation counsel [VERIFY]."),
    ("SmartFlyer W451 eVTOL car-roof carrier", "RnD_Concepts_Archive/Osito_SmartFlyer_W451_eVTOL", "15", "STAY PARKED",
     "Passenger-vehicle eVTOL module: certification and liability scale far beyond a STEM/inspection company.", "Funded partner + certification path [VERIFY]."),
    ("URSUS-250 BattleBot + PORCUPINE-X flechette swarm", "RnD_Concepts_Archive/Osito_Ursus250_*, Osito_PorcupineX_*", "20 + 18", "STAY PARKED (hard stop for youth)",
     "Weapon-like fire-control concepts conflict with the youth-STEM brand and safety rules; detected firmware has no failsafe watchdog (scanner REVIEW). Do not demo near youth programs.", "Legal/insurance review [VERIFY] + explicit CEO decision."),
    ("Arachne counter-UAS swarm interceptor", "RnD_Concepts_Archive/anti_drone_swarm_system", "18", "STAY PARKED",
     "Counter-UAS capability is likely legally restricted; needs counsel before any build or marketing [VERIFY].", "Legal review + named critical-infrastructure customer."),
    ("HIVE-MIND 24/7 swarm dock", "RnD_Concepts_Archive/Osito_HiveMind_24_7_Swarm_Dock", "33", "STAY PARKED",
     "Depends on mature Scout-85 / Grizzly-85 / security drones and on BVLOS-style operations; STM32 dock FSM has no watchdog/rollover idiom detected.", "Scout-85 flight-proven + paying pilot."),
    ("BERRYBEAR-247 berry harvest UGV (Laubacher Farms)", "RnD_Concepts_Archive/Laubacher_Osito_BerryBot_24_7", "16", "STAY PARKED",
     "Single-client agriculture robot concept; hardware not in the sub-250 g fleet.", "Signed pilot or LOI from the client [VERIFY]."),
    ("GRIZZLY-85 sky-rover, SCOUT-85 autonomous, Baseball security drone, GECKO-110 surface-cling, MORPHO-450",
     "RnD_Concepts_Archive/*", "20 / 14 / 63 / 21 / 16", "STAY PARKED (reuse parts only)",
     "Interesting but each needs its own flight proof; none is needed to close CUB-75 / SHARD-75 or the revenue tracks.", "Core-fleet checklist all green + a customer ask."),
]
NEXTGEN = [
    "Barnacle-125, Tether-105, Hydro-145, PipeBug-85, Mole-95, Courier-160, Nautilus-120, Orb-85, Perch-110, Soccer-80, Polaris-100, BeaconPad, "
    "Seeder-140, Acoustic-90, Sniffer-90, Glider-180, Spelunker-220, Vineyard-130, Cleanroom-80, WallCling-95, Swarm-55, LumenOrb 6S",
]


def main():
    doc = K.new_doc(landscape=True)
    K.banner(doc, "R&D Parking Note - Keep Speculative Concepts From Blocking Revenue",
             "Which concepts stay parked while CUB-75 / SHARD-75 release gates and the Miguel 5-day action orders are worked",
             "Osito Drone LLC - 2026-10-31 - advisory; no folders were moved or edited")
    K.callout(doc, "RECOMMENDATION IN ONE PARAGRAPH",
              "Until the CUB-75 / SHARD-75 release checklist has zero FAIL items and its hardware gates (weigh, bench failsafe pull-test, youth guard decision) are run, "
              "no new platform work should start. The 12 RnD_Concepts_Archive concepts stay parked. The 22 platforms in the 2026-10-31 'NextGen' / commercial folders under Active_Subprojects are "
              "concept packs (a spec, a simulator and a test each - no hardware evidence was found) and should be treated as PARKED even though they sit in Active_Subprojects. "
              "Do not move them yet: audit and sales scripts reference those paths, so relabel first and move later with Alan's approval.")
    K.h1(doc, "1. Keep active (revenue-linked)")
    K.table(doc, ["Platform", "Where", "Why it stays active"], [list(r) for r in KEEP_ACTIVE], widths=[2.6, 3.6, 4], size=8)
    K.h1(doc, "2. Stay parked in RnD_Concepts_Archive")
    K.table(doc, ["Concept", "Location", "Files", "Verdict", "Why", "Re-entry trigger"], [list(r) for r in PARKED], widths=[2.1, 2.6, 0.6, 1.1, 3.4, 1.7], size=7.5)
    K.h1(doc, "3. 'NextGen' concept packs sitting in Active_Subprojects (treat as parked)")
    K.para(doc, NEXTGEN[0] + ".", size=8.5)
    K.bullets(doc, [
        "Each folder holds ~8 files (builder, spec/docx/html, avionics sim, safety test); the exception is Spelunker-220 (24 files). File-level review only: the folders contain specs, simulators and tests; no flight logs, bench photos or measured data files were seen.",
        "Sales risk [VERIFY]: several sales kits are named after these platforms (e.g. Construction_Progress_and_Perch110_B2B_Kit, Maritime_ShipHull_UT_and_Tethered_Overwatch_B2B_Kit, "
        "Subterranean_LiDAR_and_Hospital_Campus_B2B_Kit, NextGen_Fleet_Commercial_and_STEM_Showcase). Their contents were not reviewed here - Miguel should confirm every un-built platform is labelled "
        "'concept / not yet available' and that no delivery date or price is promised.",
        "Promote a platform back to active only when a named paying customer or signed pilot exists for it.",
    ], size=9)
    K.h1(doc, "4. Re-entry gate for any parked concept")
    K.bullets(doc, [
        "CUB-75 / SHARD-75 release checklist: 0 FAIL and the hardware gates (A8, A9, C9, C10, D1/D2) executed with recorded values.",
        "A named paying customer, signed pilot or LOI for that concept (not an internal idea).",
        "Firmware passes the same compiled, mutation-checked safety tests used for the Snap-Deck (watchdog, disarmed interlock, 16-bit rollover) - firmware_safety/test_snapdeck_patched.py is the template.",
        "Material list uses only the 4-tier filament standard (PETG-CF / PAHT-CF / PLA+ / TPU 95A HF + TPU 68D).",
        "Anything weapon-like, counter-UAS or passenger-carrying needs legal/insurance review first [VERIFY] and is never shown to youth programs.",
    ], size=9)
    K.footer(doc, "Osito Drone LLC - internal - generated by build_rnd_parking_note.py - 2026-10-31")
    out = HERE / "RnD_Parking_Note.docx"
    doc.save(out)
    print("wrote", out)


if __name__ == "__main__":
    main()

