# REPORT - Track 6: CUB-75 / SHARD-75 Release Readiness (2026-10-31)

**Verdict: NOT READY for youth release.** Paper and host-side checks are done; no weighing, bench, print or flight test was performed by this sprint. Checklist score: 9 PASS / 8 FAIL / 20 VERIFY / 1 OPEN.

## What I audited
- `03_Hardware_and_Drones/2026-10-31_Fleet_Avionics_and_Safety_Audit` (re-ran it: 68/68 pass - see side-effect note below)
- `Core_Fleet/2026-10-31_CUB75_and_SHARD75_Gen2_Modular_Upgrades` (firmware, 40-check test, spec)
- `2026-10-31_InHouse_Manufacturing_and_3D_Print_Farm_SOP` (generator + Master Filament Control)
- CUB-75 and KODIAK-75 (= SHARD-75) BOM CSVs, PRDs, slicer JSONs, Betaflight CLIs
- 49 firmware-like files (C/C++/INO/Lua/avionics .py) + 1,406 text files for banned filament terms

## What I built (open the `.docx` files first)
| Deliverable | File |
|---|---|
| (a) BOM + 4-tier print-profile sheet | [CUB75_SHARD75_BOM_and_Print_Profile_Sheet.docx](bom_and_print/CUB75_SHARD75_BOM_and_Print_Profile_Sheet.docx), CSVs: [CUB75](bom_and_print/CUB75_BOM_4tier.csv), [SHARD75](bom_and_print/SHARD75_BOM_4tier.csv), [profiles](bom_and_print/print_profiles_4tier.csv) |
| (a) Filament-violation scan | [filament_standard_scan.py](bom_and_print/filament_standard_scan.py), [hits CSV](bom_and_print/filament_violation_hits.csv), [summary](bom_and_print/filament_violation_summary.json) |
| (b) Firmware safety audit | [Firmware_Safety_Audit_CUB75_SHARD75.docx](firmware_safety/Firmware_Safety_Audit_CUB75_SHARD75.docx) |
| (b) **Patched copy** (original untouched) | [gen2_snapdeck_firmware_patched.cpp](firmware_safety/gen2_snapdeck_firmware_patched.cpp) |
| (b) Unit tests + mutation check | [test_snapdeck_patched.py](firmware_safety/test_snapdeck_patched.py), [snapdeck_capi.inc](firmware_safety/snapdeck_capi.inc), [mutation_check.py](firmware_safety/mutation_check.py) |
| (b) Static triage | [firmware_static_audit.py](firmware_safety/firmware_static_audit.py), [CSV](firmware_safety/firmware_static_audit_results.csv), [JSON](firmware_safety/firmware_static_audit_results.json) |
| (c) Release checklist for Jesus | [CUB75_SHARD75_Release_Readiness_Checklist.docx](checklist/CUB75_SHARD75_Release_Readiness_Checklist.docx) |
| (d) R&D parking note | [RnD_Parking_Note.docx](rnd_parking/RnD_Parking_Note.docx) |

## What I verified (all re-run at build time)
- `python firmware_safety/test_snapdeck_patched.py` -> 29 tests OK (1 expected failure that reproduces an original defect), 0 skipped. Tests **compile and execute the real C++** (Zig 0.16 clang, host x86-64) via ctypes, original vs patched side by side.
- `python firmware_safety/mutation_check.py` -> 8/8 mutants killed (this check initially exposed a test gap in the latch layer; test added).
- Firmware findings: **F-01** failsafe latch bypass (HIGH), **F-02** 16-bit future-stamp false trip (MED, conditional on ISR stamping), **F-03** CRC over padding + its own field, **F-04** no sensor staleness, **F-05** cooldown alias, **F-06** magic numbers. The existing 40/40 suite passed with all of them present because it greps text and models logic in Python.
- Betaflight CLI (read-only parse): CUB-75 x2 and SHARD-75 'Full' pass failsafe DROP/delay 4, ARM aux, runaway ON, LVC; SHARD-75 'Arena' CLI has no `defaults`/`small_angle` -> [VERIFY].
- Lua files: all parse (lupa). BOM arithmetic recomputed: CUB $98.04 / $118.03, SHARD $101.44 / $121.43 - match.
- All 4 `.docx` reloaded with python-docx (11 / 8 / 10 / 4 tables). No Word/LibreOffice here, so page layout was not visually checked.

## Key defects found in existing work (not fixed in place)
- `KODIAK75_BOM_and_Sourcing.csv` has an unquoted comma (magnet row) -> columns shift in Excel; fleet audit only counts rows.
- SHARD-75 BOM has no optical-flow/LiDAR line though the 45.5 g headline config needs it; kit arithmetic ($112.50, $221.90) does not reconcile.
- CUB-75: BOM/PRD (550 mAh, 25.7 g dry, $98.04) vs safety-report data and Gen-2 spec (450 mAh, 28.0 g dry, $108.50).
- 122 active banned-material hits (ePA-CF, PC-CF/CarbonX, TPU 56D/90A, PC-Blend) in 22 CUB/SHARD/SOP files; SOP generator still specifies legacy materials and manual M600 sandwich swaps. No PEEK / PPS-CF / TPU 85A in core-fleet files (PEEK only in smart_disc_golf feasibility text).
- SHARD-75 is a guardless open-prop design; GEMINI.md youth rule says ducted prop guards -> needs a use-policy decision.

## Known gaps / [VERIFY]
Weigh one CUB-75 and one SHARD-75; choose the CUB-75 pack; vendor quote for optical-flow module; 68D profile and PAHT-CF/68D adhesion test; Bambu preset vs documented PAHT-CF temps/chamber; target-MCU compile of the patched firmware; UART heartbeat parser (not in repo); `motor_pwm_us=1250` meaning; 'feature AIRMODE' acceptance; bench failsafe pull-test; finger-probe on printed CUB frame; AI Security Lua SITL run. Vendor print ranges came from a web-search summary, not the spool labels.

## Side effects to know about
- Running the existing fleet audit in place regenerates PCB gerbers/zips (timestamps only). I restored the 36 affected tracked files under `Core_Fleet` with `git checkout`; `git status` shows no modified tracked files from me. Do not run it in place before a fab freeze.
- I installed `ziglang`, `lupa`, `pytest` with pip into the user Python (free, local). Only `ziglang` and `lupa` are used by my scripts.
- Nothing was sent, emailed, pushed or deployed. No originals were overwritten.

## Single next action for the team
Jesus: merge `gen2_snapdeck_firmware_patched.cpp` into the Gen-2 build, compile for the target MCU, and run checklist gates C9/C10 (bench failsafe pull-test and disarmed-interlock check, props off) while weighing one CUB-75 and one SHARD-75 (A8/A9).

## Re-run
```
python firmware_safety/test_snapdeck_patched.py && python firmware_safety/mutation_check.py
python firmware_safety/firmware_static_audit.py && python bom_and_print/filament_standard_scan.py
python bom_and_print/build_bom_and_print_sheet.py && python firmware_safety/build_firmware_audit_docx.py
python checklist/build_release_checklist.py && python rnd_parking/build_rnd_parking_note.py
```
Requires `pip install ziglang lupa python-docx`.
