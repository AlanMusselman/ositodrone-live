#!/usr/bin/env python3
"""
Small shared python-docx kit for the CUB-75 / SHARD-75 release-readiness deliverables.
Brand tokens per GEMINI.md: Fjalla One headings, Roboto body, #7077CF / #232A68 / #EEF0FA / #161616 / #F6F6F6.
(Fonts are referenced by name; Word substitutes if they are not installed on the viewing machine.)
"""
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parents[3]
LOGO_WHITE = ROOT / "00_Brand_Assets" / "Logos" / "ositologo white.png"

INDIGO, ROYAL, LAV, CHAR, GREY, BORDER, MUTED = "7077CF", "232A68", "EEF0FA", "161616", "F6F6F6", "E2E2E2", "5E5E5E"
STATUS_FILL = {"PASS": "E8F5E9", "FAIL": "FDECEA", "VERIFY": LAV, "WARN": "FFF4E0", "OPEN": "FFF4E0", "FIXED": "E8F5E9", "INFO": GREY}


def rgb(hexstr):
    return RGBColor(int(hexstr[0:2], 16), int(hexstr[2:4], 16), int(hexstr[4:6], 16))


def shade(cell, fill):
    tcPr = cell._tc.get_or_add_tcPr()
    for old in tcPr.findall(qn("w:shd")):
        tcPr.remove(old)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def cell_borders(cell, color=BORDER, sz=4):
    tcPr = cell._tc.get_or_add_tcPr()
    b = OxmlElement("w:tcBorders")
    for edge in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{edge}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(sz))
        el.set(qn("w:color"), color)
        b.append(el)
    tcPr.append(b)


def set_font(run, name="Roboto", size=9, bold=False, color=CHAR, italic=False):
    run.font.name = name
    rPr = run._element.get_or_add_rPr()
    rf = rPr.find(qn("w:rFonts"))
    if rf is None:
        rf = OxmlElement("w:rFonts")
        rPr.append(rf)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rf.set(qn(a), name)
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.color.rgb = rgb(color)


def new_doc(landscape=True, margins=0.55):
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Roboto"
    st.font.size = Pt(9.5)
    sec = doc.sections[0]
    if landscape:
        sec.orientation = WD_ORIENT.LANDSCAPE
        sec.page_width, sec.page_height = Inches(11), Inches(8.5)
    for side in ("left_margin", "right_margin", "top_margin", "bottom_margin"):
        setattr(sec, side, Inches(margins))
    return doc


def usable_width_in(doc):
    s = doc.sections[0]
    return (s.page_width - s.left_margin - s.right_margin) / 914400.0


def banner(doc, title, subtitle, meta=None):
    t = doc.add_table(rows=1, cols=2)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    w = usable_width_in(doc)
    t.autofit = False
    left, right = t.cell(0, 0), t.cell(0, 1)
    left.width, right.width = Inches(w * 0.28), Inches(w * 0.72)
    for c in (left, right):
        shade(c, ROYAL)
    lp = left.paragraphs[0]
    if LOGO_WHITE.exists():
        lp.add_run().add_picture(str(LOGO_WHITE), width=Inches(1.7))
    rp = right.paragraphs[0]
    r1 = rp.add_run(title.upper() + "\n")
    set_font(r1, "Fjalla One", 17, False, "FFFFFF")
    r2 = rp.add_run(subtitle)
    set_font(r2, "Roboto", 9.5, False, "DCE1FA")
    if meta:
        r3 = rp.add_run("\n" + meta)
        set_font(r3, "Roboto", 8.5, False, "B9C0F0")
    # accent rule
    p = doc.add_paragraph()
    pPr = p._p.get_or_add_pPr()
    bd = OxmlElement("w:pBdr")
    bt = OxmlElement("w:bottom")
    bt.set(qn("w:val"), "single")
    bt.set(qn("w:sz"), "18")
    bt.set(qn("w:color"), INDIGO)
    bd.append(bt)
    pPr.append(bd)
    p.paragraph_format.space_after = Pt(4)


def h1(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(3)
    p.paragraph_format.keep_with_next = True
    set_font(p.add_run(text.upper()), "Fjalla One", 13, False, ROYAL)
    return p


def h2(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    set_font(p.add_run(text), "Fjalla One", 10.5, False, INDIGO)
    return p


def para(doc, text, size=9.5, bold=False, italic=False, color=CHAR, after=3):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    set_font(p.add_run(text), "Roboto", size, bold, color, italic)
    return p


def rich(doc, parts, size=9.5, after=3):
    """parts = [(text, bold)]"""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    for text, bold in parts:
        set_font(p.add_run(text), "Roboto", size, bold)
    return p


def bullets(doc, items, size=9.5):
    for it in items:
        p = doc.add_paragraph(style="List Bullet")
        p.paragraph_format.space_after = Pt(1)
        if isinstance(it, tuple):
            set_font(p.add_run(it[0]), "Roboto", size, True)
            set_font(p.add_run(it[1]), "Roboto", size)
        else:
            set_font(p.add_run(it), "Roboto", size)


def callout(doc, title, body, fill=LAV, edge="8E93DA"):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    c = t.cell(0, 0)
    shade(c, fill)
    cell_borders(c, edge, 8)
    p = c.paragraphs[0]
    set_font(p.add_run(title + "\n"), "Fjalla One", 10, False, ROYAL)
    set_font(p.add_run(body), "Roboto", 9, False, CHAR)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def table(doc, headers, rows, widths=None, size=8, status_col=None, bold_first=False, zebra=True):
    t = doc.add_table(rows=1, cols=len(headers))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    total = usable_width_in(doc)
    if widths is None:
        widths = [total / len(headers)] * len(headers)
    else:
        s = float(sum(widths))
        widths = [total * w / s for w in widths]
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]
        c.width = Inches(widths[i])
        shade(c, ROYAL)
        cell_borders(c, ROYAL)
        p = c.paragraphs[0]
        set_font(p.add_run(str(h)), "Roboto", size, True, "FFFFFF")
    # repeat header row
    trPr = t.rows[0]._tr.get_or_add_trPr()
    th = OxmlElement("w:tblHeader")
    th.set(qn("w:val"), "true")
    trPr.append(th)
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, val in enumerate(row):
            c = cells[i]
            c.width = Inches(widths[i])
            cell_borders(c)
            if zebra and ri % 2 == 1:
                shade(c, GREY)
            txt = str(val)
            p = c.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            is_status = status_col is not None and i == status_col
            if is_status:
                key = txt.split()[0].strip("[]:").upper() if txt else ""
                fill = STATUS_FILL.get(key)
                if fill:
                    shade(c, fill)
                set_font(p.add_run(txt), "Roboto", size, True)
            else:
                set_font(p.add_run(txt), "Roboto", size, bold_first and i == 0)
        # keep rows from splitting across pages
        trPr = t.rows[-1]._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit")
        cs.set(qn("w:val"), "true")
        trPr.append(cs)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def footer(doc, text):
    for sec in doc.sections:
        p = sec.footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_font(p.add_run(text), "Roboto", 7.5, False, MUTED)
