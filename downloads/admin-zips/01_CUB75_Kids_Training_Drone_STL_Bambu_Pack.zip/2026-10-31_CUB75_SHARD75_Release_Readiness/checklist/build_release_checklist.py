﻿#!/usr/bin/env python3
"""Builds CUB75_SHARD75_Release_Readiness_Checklist.docx (for Jesus Aceves, CTO).
PASS is used ONLY where a paper/host-side check was actually executed in this sprint. Anything needing a scale, bench,
printer, vendor quote, legal/policy decision or flight is VERIFY (or OPEN). FAIL = confirmed defect/conflict."""
import json
import sys
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import docx_kit as K  # noqa: E402

BP = HERE.parent / "bom_and_print"
FW = HERE.parent / "firmware_safety"
scan = json.loads((BP / "filament_violation_summary.json").read_text(encoding="utf-8"))
mut = json.loads((FW / "mutation_check_results.json").read_text(encoding="utf-8"))
st = json.loads((FW / "firmware_static_audit_results.json").read_text(encoding="utf-8"))
cli = {c["target"]: c for c in st["betaflight_cli"] if c.get("exists")}

focus_files = len(scan["focus_active_by_file"])
focus_hits = scan["focus_active_hits"]

R = "../"   # relative link base used in evidence text (plain text; docx links omitted for portability)

SECTIONS = [
    ("A. BOM, mass and documentation integrity", [
        ("A1", "CUB-75 BOM line items sum to the stated subtotal ($98.04; $118.03 with camera)", "bom_and_print/CUB75_BOM_4tier.csv - recomputed by script", "PASS", "-"),
        ("A2", "SHARD-75 BOM sums to $101.44 (LOS) / $121.43 (Dual)", "bom_and_print/SHARD75_BOM_4tier.csv - recomputed after repairing the malformed row in memory", "PASS", "-"),
        ("A3", "KODIAK75_BOM_and_Sourcing.csv parses cleanly", "Magnet row has an unquoted comma -> 11 fields vs 10; Excel/Sheets shift columns. Fleet audit only counts rows so it passes.", "FAIL", "Quote the spec field in a v2 CSV (originals not edited)."),
        ("A4", "SHARD-75 BOM includes the optical-flow / LiDAR module of the 45.5 g configuration", "No such line; +8.4 g over the 37.1 g LOS build is unexplained", "FAIL", "Add part, mass, price after vendor quote [VERIFY]."),
        ("A5", "CUB-75 spec is consistent across documents (pack, dry mass, price)", "BOM/PRD: 550 mAh, 25.7 g dry, $98.04. Safety-report data & Gen-2 spec: 450 mAh, 28.0 g dry + 11.5 g, $108.50.", "FAIL", "CTO picks one pack; update the others."),
        ("A6", "SHARD-75 kit arithmetic ($112.50 blended avg; $221.90 for 2 Dual drones)", "(101.44+121.43)/2 = about $111.4; 2 x $121.43 = $242.86", "FAIL", "Reconcile before quoting kit prices."),
        ("A7", "Gen-2 mass table arithmetic", "Gen-2 'SHARD-75 + SNAP-LASER = 48.1 g' omits the 0.3 g pogo (recomputed 48.4 g); all other rows reconcile; every configuration < 50 g", "FAIL", "Correct to 48.4 g (still < 50 g gate)."),
        ("A8", "Measured AUW of one built CUB-75 (LOS) = 39.5 g +/- tolerance", "Never weighed in this sprint; component sum is ~3.3 g inconsistent", "VERIFY", "Weigh on 0.01 g scale; record ____ g."),
        ("A9", "Measured AUW of one built SHARD-75 (LOS 37.1 g; optical-flow 45.5 g)", "Never weighed in this sprint", "VERIFY", "Weigh both builds; record ____ g / ____ g."),
        ("A10", "All configurations < 250 g (FAA sub-250 g class) and < 50 g Gen-2 youth ceiling", "Stated masses 39.5-49.4 g (paper)", "PASS", "Re-check with measured masses (A8/A9)."),
    ]),
    ("B. 4-tier filament standard (PETG-CF / PAHT-CF / PLA+ / TPU 95A HF + TPU 68D)", [
        ("B1", "Release print-profile sheet uses only the 4 tiers", "bom_and_print/CUB75_SHARD75_BOM_and_Print_Profile_Sheet.docx (script self-asserts no banned materials)", "PASS", "-"),
        ("B2", "Existing CUB-75 / SHARD-75 / SOP source files are free of banned materials", f"{focus_hits} ACTIVE hits in {focus_files} files (ePA-CF, PC-CF/CarbonX, TPU 56D/90A, PC-Blend); see violations table", "FAIL", "Fix generators/BOM/slicer JSON at source, then regenerate (originals not edited)."),
        ("B3", "No PEEK / PPS-CF / TPU 85A specified in CUB-75 or SHARD-75 files", "Scan: none in focus files. PEEK only in smart_disc_golf feasibility text (clevises/cage) and as a table row in the filament-control script; TPU 85A only in 'replaced by' text", "PASS", "smart_disc_golf PEEK mention: decide separately (out of release scope)."),
        ("B4", "TPU 95A HF loaded only on P2S #2 external dryer port (never in AMS)", "Policy in GEMINI.md; not physically inspected", "VERIFY", "Shop walk-through photo."),
        ("B5", "68D print profile exists and canopy / horn-skin parts print cleanly from AMS slot 4", "No workspace profile for 68D", "VERIFY", "Print coupon; save preset."),
        ("B6", "PAHT-CF core to 68D skin adhesion in 3-layer horn sandwich survives peel/impact (nozzle swap 225 vs 280 C)", "Never tested", "VERIFY", "Coupon peel test + 10 impact drops."),
        ("B7", "PAHT-CF dried <12% RH before printing; RH logged", "SOP says 80 C 8 h; no log exists", "VERIFY", "Log spool RH at load."),
        ("B8", "Documented nozzle/bed within P2S limits (300 C / 110 C)", "PAHT-CF 285-295 C / 105 C documented (within machine limits). Vendor range from web summary 260-290 C / 80-100 C; chamber 55 C setpoint may not be achievable", "VERIFY", "Compare with Bambu preset/spool label; cap nozzle at 290 C."),
        ("B9", "Printed-part mass and cost re-based on PAHT-CF / PETG-CF / 68D", "SOP costs ($0.52 / $0.68) are for legacy spools; frame 4.2 g (SOP) vs 2.1 g (PRD)", "VERIFY", "Weigh printed parts; update costs."),
    ]),
    ("C. Avionics, firmware and failsafe", [
        ("C1", "ORIGINAL gen2_snapdeck_firmware.cpp is safe to fly", "Failsafe latch bypass (F-01), 16-bit future-stamp false trip (F-02), unverifiable CRC (F-03), stale sensors (F-04), cooldown alias (F-05) reproduced by executing the real C++", "FAIL", "Do not flash the original."),
        ("C2", "PATCHED copy passes host-side tests (watchdog 400 ms, rollover 65535->0, disarmed interlock, latch, CRC)", f"firmware_safety/test_snapdeck_patched.py: all pass; mutation check {mut['killed']}/{mut['total']} caught", "PASS", "Host x86-64 only."),
        ("C3", "Patched firmware adopted into the release build and compiled for the TARGET MCU", "Patched file is a standalone copy; no build system touched", "OPEN", "CTO: merge, compile for target, compare struct/ABI, rerun tests."),
        ("C4", "Inbound FC heartbeat parser validates CRC / sequence", "Parser source not in workspace (F-08)", "VERIFY", "Locate or write parser + tests."),
        ("C5", "Armed baseline 'motor_pwm_us = 1250' is status-only (companion never drives ESCs)", "Carried over unchanged from original (F-07)", "VERIFY", "CTO decision; rename or remove."),
        ("C6", "CUB-75 Betaflight CLI: failsafe DROP / delay 4 (0.4 s), ARM on AUX1, runaway prevention ON, small_angle 25, LVC 3.25/3.45 V",
         "Parsed CUB75_Betaflight45_Kids_Trainer_CLI.txt + STEM-kit CLI (read-only)", "PASS", "Paper only - see C9/C10."),
        ("C7", "SHARD-75 / KODIAK-75 CLIs: failsafe DROP / delay 4, ARM AUX1, runaway ON, LVC 3.20/3.35 V",
         "Both parse; 'Arena' CLI has no `defaults` line and no explicit small_angle; 'Full' CLI enables then disables MOTOR_STOP", "VERIFY", "Confirm on bench FC (props off)."),
        ("C8", "'feature AIRMODE' lines accepted by Betaflight 4.5 CLI", "Present in CUB and SHARD CLIs; airmode is normally a flight mode", "VERIFY", "Paste into Configurator CLI on a bench FC."),
        ("C9", "Bench failsafe pull-test: switch TX off, props OFF, motors stop <= 0.5 s, companion enters Stage-2 within 400 ms", "NOT performed in this sprint", "VERIFY", "Record time ____ ms on 3 units each."),
        ("C10", "Disarmed interlock on hardware: claw/IR/motors locked when disarmed; arming blocked beyond small_angle", "NOT performed (host tests only)", "VERIFY", "Bench photo/log."),
        ("C11", "Existing 68-check fleet audit reproduces", "Re-run 2026-10-31: 68/68 PASS. NOTE: it regenerates PCB gerbers/zips (timestamps) - run it only in a scratch copy; artefacts changed by my run were restored with git checkout", "PASS", "Do not run in place before a fab-package freeze."),
        ("C12", "AI Security Drone Lua: explicit armed check + SITL run", "Interceptor gates on GUIDED mode only; elapsed math relies on uint32 userdata", "VERIFY", "SITL run (outside core-fleet release)."),
    ]),
    ("D. Youth safety and compliance (GEMINI.md rules)", [
        ("D1", "CUB-75 has finger-safe top/bottom prop guards (ducted)", "PRD: 10 mm ducts + 3 upper ribs + 4 lower struts (design documents only)", "VERIFY", "Finger-probe check on a printed frame."),
        ("D2", "SHARD-75 meets 'sub-250 g ducted prop guard' youth rule", "PRD defines SHARD-75 as guardless open-prop, used inside a 101 in netted tent. This conflicts with the GEMINI.md youth rule unless use is restricted.", "FAIL", "Decision (Miguel/Jesus): coach/adult-operated or netted-arena-only with waiver language, or add a guarded variant."),
        ("D3", "FAA TRUST completion recorded for every youth pilot; participant waiver signed before flight", "Waiver template: 01_Sales_and_STEM_Academy/STEM_Academy_Collateral/Osito_Participant_Safety_Waiver.html. Records process not audited", "VERIFY", "Program lead confirms before each session."),
        ("D4", "1S LiHV charging / storage procedure posted (storage charger, no unattended charge)", "Charger named in BOM; procedure not audited", "VERIFY", "Shop check."),
    ]),
    ("E. Manufacturing readiness", [
        ("E1", "First-article print of each part with dimensional check (duct ID 42.2 mm, FC pattern 25.5 x 25.5 mm, magnet sockets 2.10 x 1.20 mm)", "Specs from SOP/PRD; no measurements", "VERIFY", "Calipers; record."),
        ("E2", "Assembly/QA 12-step SOP available", "03_Hardware_and_Drones/2026-10-31_InHouse_Manufacturing_and_3D_Print_Farm_SOP/ (materials text outdated - see B2)", "PASS", "Regenerate after B2 fixes."),
        ("E3", "N52 magnet polarity jig used on all 5 SHARD-75 sockets", "Procedure documented; not observed", "VERIFY", "Spot-check 5 units."),
    ]),
]


def main():
    doc = K.new_doc(landscape=True)
    K.banner(doc, "CUB-75 / SHARD-75 Release-Readiness Checklist",
             "For Jesus Aceves (CTO, jesus@ositodrone.com) - pass / fail with [VERIFY] items", "Osito Drone LLC - 2026-10-31 - paper + host-side evidence only; NO physical weighing, bench, print or flight tests were performed")
    tally = Counter()
    for _, rows in SECTIONS:
        for r in rows:
            tally[r[3]] += 1
    K.callout(doc, "STATUS KEY AND SCORE",
              f"PASS = checked in this sprint on paper or by executing code ({tally['PASS']}).  FAIL = confirmed defect or conflict ({tally['FAIL']}).  "
              f"VERIFY = needs a scale / bench / printer / vendor / decision ({tally['VERIFY']}).  OPEN = action not yet taken ({tally['OPEN']}).  "
              "Release recommendation: NOT READY for youth release. Every PASS below is paper-only; the hardware gates (C9, C10, D1, A8, A9) have not been run.")
    K.h1(doc, "Go / no-go summary")
    K.bullets(doc, [
        ("Blockers (FAIL): ", "original Snap-Deck firmware (C1), SHARD-75 open-prop youth policy (D2), un-costed optical-flow config (A4), CUB-75 pack/mass conflict (A5), malformed SHARD BOM CSV (A3), banned materials still specified in source files (B2)."),
        ("Fastest path to green: ", "adopt the patched firmware (C3) -> bench pull-tests (C9/C10) -> weigh 1 unit each (A8/A9) -> pick the CUB-75 pack (A5) -> decide SHARD-75 youth use (D2) -> fix BOM/SOP sources (A3/A4/B2)."),
    ], size=9)
    for title, rows in SECTIONS:
        K.h1(doc, title)
        K.table(doc, ["ID", "Item", "Evidence / source", "Status", "To close / owner action"],
                [list(r) for r in rows], widths=[0.4, 3.4, 3.8, 0.7, 2.4], size=7.5, status_col=3)
    K.h1(doc, "Sign-off")
    K.table(doc, ["Role", "Name", "Decision (GO / NO-GO / CONDITIONAL)", "Signature", "Date"],
            [["CTO", "Jesus Aceves", "", "", ""], ["CEO", "Miguel Flores", "", "", ""], ["COO (youth programs)", "Alan Musselman", "", "", ""]],
            widths=[1.6, 1.6, 3.2, 2.0, 1.2], size=8.5, zebra=False)
    K.para(doc, "Evidence files live next to this checklist: ../bom_and_print/, ../firmware_safety/, ../rnd_parking/. Re-run scripts listed in REPORT.md to refresh counts.", size=8.5, color=K.MUTED)
    K.footer(doc, "Osito Drone LLC - internal - generated by build_release_checklist.py - 2026-10-31")
    out = HERE / "CUB75_SHARD75_Release_Readiness_Checklist.docx"
    doc.save(out)
    print("wrote", out, dict(tally))


if __name__ == "__main__":
    main()

