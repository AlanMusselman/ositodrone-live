﻿#!/usr/bin/env python3
"""
Builds the verified BOM + 4-tier print-profile sheet for CUB-75 (39.5 g) and SHARD-75 (45.5 g).
Outputs (this folder):
  CUB75_SHARD75_BOM_and_Print_Profile_Sheet.docx
  CUB75_BOM_4tier.csv, SHARD75_BOM_4tier.csv, print_profiles_4tier.csv
Inputs are READ-ONLY: existing BOM CSVs, PRDs (values transcribed below with source refs), slicer JSONs, SOP generator.
Nothing is physically measured here. Every number is either (a) read from an existing workspace source,
(b) arithmetic recomputed in this script, or (c) marked [VERIFY].
"""
import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import docx_kit as K  # noqa: E402

ROOT = HERE.parents[3]
HW = ROOT / "03_Hardware_and_Drones"
CUB_CSV = HW / "Core_Fleet/Kids Training Drone/CUB75_BOM_and_Sourcing.csv"
SHARD_CSV = HW / "Active_Subprojects/Bumper Drones/KODIAK75_BOM_and_Sourcing.csv"
SCAN_JSON = HERE / "filament_violation_summary.json"
SCAN_CSV = HERE / "filament_violation_hits.csv"

# ----------------------------------------------------------------------------------------------------------------------
# 4-tier standard (GEMINI.md section 3) - the ONLY materials allowed in this sheet
# ----------------------------------------------------------------------------------------------------------------------
T1 = "T1 Bambu PETG-CF (P2S #1 AMS slot 1)"
T2 = "T2 Bambu PAHT-CF (P2S #1 AMS slot 2, dried <12% RH)"
T3 = "T3 eSUN PLA+ / Bambu PLA Tough (P2S #1 AMS slot 3)"
T4A = "T4A Bambu TPU 95A HF (P2S #2 external dryer port, NEVER in AMS)"
T4B = "T4B Bambu TPU for AMS 68D (P2S #1 AMS slot 4)"
ALLOWED = (T1, T2, T3, T4A, T4B)
BANNED_WORDS = ("PEEK", "PPS-CF", "85A", "90A", "56D", "ePA-CF", "PC-CF", "PC-Blend", "CarbonX", "PA6", "PET-CF")

# ----------------------------------------------------------------------------------------------------------------------
# Source data (transcribed from workspace files; see "src" columns)
# ----------------------------------------------------------------------------------------------------------------------
CSV_DEFECTS = []


def read_csv_rows(path):
    """csv reader that REPAIRS (in memory only) rows with one extra field caused by an unquoted comma in column 3,
    and records each repaired row so it can be reported as a source-file defect."""
    with path.open(encoding="utf-8", errors="replace", newline="") as fh:
        rows = [r for r in csv.reader(fh) if any(c.strip() for c in r)]
    header, out = rows[0], []
    for n, r in enumerate(rows[1:], start=2):
        if len(r) == len(header) + 1:
            CSV_DEFECTS.append((path.name, n, r[1], f"{len(r)} fields vs {len(header)}: unquoted comma in spec text; Excel/Sheets import shifts every later column"))
            r = r[:2] + [r[2] + "," + r[3]] + r[4:]
        elif len(r) != len(header):
            CSV_DEFECTS.append((path.name, n, r[1] if len(r) > 1 else "?", f"{len(r)} fields vs {len(header)}"))
            r = (r + [""] * len(header))[:len(header)]
        out.append(dict(zip(header, r)))
    return out


cub_src = read_csv_rows(CUB_CSV)
shard_src = read_csv_rows(SHARD_CSV)

# CUB-75 printed-part masses (g): CUB75_BOM csv / SOP generator rows. Canopy: csv says ~2.2, SOP says 2.0.
CUB_PRINT = [
    # part, stl, tier, grams, minutes, cost$ , src note
    ("Kid-safe 75 mm ducted frame", "CUB75_Frame_KidSafe_75mm.stl", T1, 6.8, 38, 0.22, "BOM csv + SOP"),
    ("360 deg bumper belt", "CUB75_TPU_Bumper_Ring.stl", T4A, 2.8, 16, 0.10, "BOM csv + SOP"),
    ("550 mAh cradle + wide skids", "CUB75_550mAh_Trainer_Skids.stl", T4A, 3.4, 22, 0.12, "BOM csv + SOP"),
    ("LOS dome + FPV pod canopies", "CUB75_Canopy_LOS_CubDome.stl + CUB75_Canopy_FPV_Pod.stl", T4B, 2.0, 12, 0.08,
     "SOP says 2.0 g, BOM csv says ~2.2 g [VERIFY]; T4B per GEMINI.md (multi-colour CUB-75 canopies)"),
    ("Motor / prop press jig (shop tool, not on aircraft)", "CUB75_Motor_Prop_Press_Jig.stl", T3, None, None, None,
     "mass/time not documented [VERIFY]"),
]
SHARD_PRINT = [
    ("Guardless 75 mm X-frame", "KODIAK75_Frame_Protected_v2.stl (SOP) / KODIAK75_Frame_v1.stl (PRD)", T2, 4.2, 29, None,
     "SOP 4.2 g vs PRD target 2.1 g [VERIFY by weighing a printed frame]"),
    ("Standoff horns, 3-layer sandwich - PAHT-CF core", "KODIAK75_Horns_v1.stl", T2, 1.0, None, None,
     "split of SOP 2.4 g horn mass: master filament sheet 5.2 g PAHT-CF - 4.2 g frame = 1.0 g [derived]"),
    ("Standoff horns, 3-layer sandwich - 68D skins", "KODIAK75_Horns_v1.stl", T4B, 1.4, 18, None,
     "master filament sheet: 1.4 g T4B; SOP 18 min for the horn print"),
    ("Optical-flow 550 mAh cradle", "SHARD75_OptFlow_550Cradle_v1.stl", T4A, 4.1, 24, None, "SOP"),
    ("LOS deck + armor-plate magnet cups", "KODIAK75_Deck_LOS_v1.stl + ArmorPlates_v1.stl", T4A, 3.5, 21, None, "SOP"),
]
# SOP printed-cost subtotals (documented, legacy materials): CUB $0.52, SHARD $0.68 (re-costing under PAHT-CF/68D = [VERIFY]).

# Mass configurations (g) - PRDs, Gen-2 spec
MASS = {
    "CUB-75 LOS (25.7 dry + 13.8 pack)": (25.7 + 13.8, 39.5, "CUB-75 PRD sec.2"),
    "CUB-75 Dual LOS+FPV": (None, 41.1, "CUB75_BOM_and_Sourcing.md (+1.6 g)"),
    "CUB-75 MK-II (+0.3 pogo)": (39.5 + 0.3, 39.8, "Gen-2 spec"),
    "CUB-75 MK-II + SNAP-CODE 3.2": (39.5 + 0.3 + 3.2, 43.0, "Gen-2 spec"),
    "CUB-75 MK-II + SNAP-CLAW 3.4": (39.5 + 0.3 + 3.4, 43.2, "Gen-2 spec"),
    "CUB-75 MK-II + SNAP-CLAW + 2.0 beacon": (39.5 + 0.3 + 3.4 + 2.0, 45.2, "Gen-2 spec"),
    "SHARD-75 LOS (component sum 2.1+2.8+1.6+0.5+2.1+0.2+9.2+4.8+13.8)": (2.1 + 2.8 + 1.6 + 0.5 + 2.1 + 0.2 + 9.2 + 4.8 + 13.8, 37.1, "KODIAK PRD sec.2 table"),
    "SHARD-75 Dual LOS+FPV": (37.1 - 0.5 + 0.75 + 1.5, 38.8, "PRD: LOS deck 0.5 -> FPV deck 0.75 + cam 1.5 (=38.85, PRD rounds to 38.8)"),
    "SHARD-75 Full optical-flow + LiDAR + N52 armor": (None, 45.5, "PRD headline; NO component breakdown in workspace [VERIFY]"),
    "SHARD-75 MK-II (+0.3 pogo)": (45.5 + 0.3, 45.8, "Gen-2 spec"),
    "SHARD-75 MK-II + SNAP-LASER 2.6": (45.5 + 0.3 + 2.6, 48.1, "Gen-2 spec states 48.1 (= 45.5 + 2.6): the 0.3 g pogo receptor is omitted; recomputed 48.4 [VERIFY]"),
    "SHARD-75 MK-II Heavy 46.8 + SNAP-LASER 2.6": (46.8 + 2.6, 49.4, "Gen-2 spec"),
}
YOUTH_CEILING_G = 50.0   # Gen-2 gate in test_gen2_snapdeck_safety.py (internal ceiling, not an FAA figure)
FAA_SUB250_G = 250.0


def money(x):
    return f"${x:,.2f}"


def fnum(s):
    try:
        return float(str(s).replace("$", "").replace(",", ""))
    except Exception:
        return None


# ----------------------------------------------------------------------------------------------------------------------
# Recompute BOM arithmetic
# ----------------------------------------------------------------------------------------------------------------------
def cub_bom():
    rows, total = [], 0.0
    std_map = {
        "In-Office 3D Print|75mm Kid-Safe Ducted Frame": (T1, "Standardised: source row also allows 'Tough PLA+' and 'ePA-CF' for the frame -> not allowed (PLA = T3 tooling tier; ePA-CF banned)."),
        "In-Office 3D Print|360 TPU Wall-Bumper Belt": (T4A, "OK (TPU 95A -> T4A HF, external dryer port)."),
        "In-Office 3D Print|550mAh Cradle + Wide Skids": (T4A, "OK (T4A)."),
        "In-Office 3D Print|Modular Canopies (LOS + FPV)": (T4B, "Source says TPU 95A; GEMINI.md assigns multi-colour CUB-75 canopies to T4B 68D (AMS slot 4)."),
    }
    for r in cub_src:
        cat, comp = r["Category"].strip(), r["Component"].strip()
        if cat in ("SUBTOTAL", "Optional FPV", "Optional Radio"):
            continue
        ext = fnum(r["Extended Cost (USD)"]) or 0.0
        total += ext
        tier, note = std_map.get(f"{cat}|{comp}", ("COTS", ""))
        rows.append([cat, comp, r["Recommended Part / Specification"].strip(), r["Qty"], money(fnum(r["Unit Cost (USD)"])), money(ext), tier, note or r["Source / Notes"].strip()])
    stated = next(fnum(r["Extended Cost (USD)"]) for r in cub_src if r["Category"].strip() == "SUBTOTAL")
    optional = [(r["Component"].strip(), fnum(r["Extended Cost (USD)"])) for r in cub_src if r["Category"].strip().startswith("Optional")]
    return rows, round(total, 2), stated, optional


def shard_bom():
    rows, total_los = [], 0.0
    std_map = {
        "Main Guardless 75mm X-Frame": (T2, "Source says 'CarbonX PC-CF or eSUN ePA-CF' ($65/kg) -> replaced by T2 PAHT-CF; unit cost $0.18 is for the legacy spool - re-cost [VERIFY]."),
        "TPU 95A / 56D Flex Parts (Horns/Cradle/Decks)": (T4A + " + " + T4B, "Source says 'TPU 95A / 56D'; 56D banned -> horn skins to T4B 68D, cradle/decks T4A. Cost $0.20 [VERIFY re-cost]."),
    }
    for r in shard_src:
        cat = r["Category"].strip()
        if cat == "Arena & GSE":
            continue
        qty = fnum(r["Qty per Drone"]) or 0.0
        ext = fnum(r["1-Drone Cost (USD)"]) or 0.0
        optional = r["Category"].strip().startswith("Vision (Optional")
        if not optional:
            total_los += ext
        tier, note = std_map.get(r["Subsystem / Part Name"].strip(), ("COTS", ""))
        rows.append([cat + (" (optional)" if optional else ""), r["Subsystem / Part Name"].strip(), r["Recommended Model / Spec"].strip()[:150], r["Qty per Drone"], money(fnum(r["Unit Price (USD)"])), money(ext), tier, note or r["Engineering Notes"].strip()[:140]])
    cam = next(fnum(r["1-Drone Cost (USD)"]) for r in shard_src if r["Category"].strip().startswith("Vision (Optional"))
    kit_total = sum(fnum(r["2-Drone Kit Cost (USD)"]) or 0 for r in shard_src)
    return rows, round(total_los, 2), round(total_los + cam, 2), round(kit_total, 2)


def tier_masses(parts):
    c = Counter()
    for _, _, tier, g, *_ in parts:
        if g:
            c[tier] += g
    return c


# ----------------------------------------------------------------------------------------------------------------------
# Print-profile sheet (documented values; each row cites its source; vendor values flagged)
# ----------------------------------------------------------------------------------------------------------------------
V = "[VERIFY]"
PROFILES = [
    # platform, part, tier, layer, walls/shell, infill, nozzle/bed, fan/speed, support/brim, dry, source/status
    ("CUB-75", "Frame (CUB75_Frame_KidSafe_75mm)", T1,
     "0.16 / 0.20 first", "5 walls; 5 top / 5 bottom", "45% gyroid",
     "255 C / 80 C textured PEI (SOP range 255-265)", "fan 20-35%, 0% first 3 layers; 60/90/100 mm/s",
     "flip upside-down: zero supports; else tree(auto) build-plate-only; 3.0 mm outer brim",
     "SOP: 65 C 5 h, <18% RH. Bambu web summary: 65 C 8 h " + V,
     "CUB75_Frame_PETG_or_PACF_Profile.json + SOP. Profile NAME still lists 'Tough PLA+ / ePA-CF' - rename; print PETG-CF only."),
    ("CUB-75", "Bumper belt + skids (T4A)", T4A,
     "0.20 / 0.20", "3 walls; 4 top / 4 bottom", "25% gyroid",
     "225 C / 50 C textured PEI + glue release", "fan 40-60%; 35/45/50 mm/s (<=3.5 mm3/s)",
     "tree(auto) build-plate-only; retraction 0.8 mm @ 25 mm/s",
     "SOP: 55 C 4 h, <20% RH. Bambu web summary: 70 C 8 h " + V,
     "CUB75_TPU95A_Bumper_Skids_Profile.json. Feed from P2S #2 external dryer port; never AMS."),
    ("CUB-75", "Canopies LOS dome + FPV pod (T4B 68D)", T4B,
     "0.20 / 0.20 (start from T4A profile)", "3 walls; 4 top / 4 bottom", "25% gyroid",
     "no workspace profile for 68D " + V, "start 35/45/50 mm/s " + V,
     "tree(auto) build-plate-only under dome arch",
     "per Bambu spool label " + V,
     "NEW requirement: validate a 68D profile on P2S #1 AMS slot 4 and save it as the canopy preset " + V + "."),
    ("CUB-75", "Motor/prop press jig (shop tool)", T3,
     "Bambu Studio default PLA preset " + V, "-", "-", "-", "-", "-", "-",
     "Source says 'PLA+ / PETG / PC-CF' -> standardise on T3; no profile in workspace " + V + "."),
    ("SHARD-75", "Guardless frame", T2,
     "0.16 / 0.20 first", "5 walls; 4 top / 4 bottom", "40% gyroid, 25% infill-wall overlap",
     "285 C / 105 C documented (SOP range 285-295). Bambu web summary: 260-290 C / 80-100 C " + V,
     "fan <=20%, 0 first 3 layers; 55/85/95 mm/s (SOP) or 60/90/100 (JSON)",
     "print flat so fibres follow arms; 3-4 mm outer brim + Magigoo PA (SOP)",
     "SOP: 80 C 8 h, <12% RH (matches GEMINI.md).",
     "KODIAK75_PC-CF_Frame_OrcaProfile.json documents 285/105/chamber 55. Chamber 55 C needs an active heater - confirm P2S capability " + V + ". Cap nozzle at 290 C; machine max 300 C, bed max 110 C."),
    ("SHARD-75", "Standoff horns, 3-layer sandwich (T4B skins + T2 core)", T4B + " skins / " + T2 + " core",
     "0.20 / 0.20 (15 layers)", "4 walls; 2-3 top / 2-3 bottom", "100% rectilinear",
     "skins 225 C, core 280 C, bed 75 C constant (SOP). 68D skin temp " + V,
     "30% fan on skins / 10% on core (SOP); 45/60/60 mm/s",
     "no supports; 3.0 mm brim",
     "dry each filament to its own spec",
     "Existing profile: TPU 95A + ePA-CF with MANUAL M600 pauses at Z=0.60 / Z=2.20 -> replace with AMS slot 2 <-> slot 4 changes at layer 3 and layer 11. 225 C vs 280 C swap in one nozzle: run purge/adhesion peel test before release " + V + "."),
    ("SHARD-75", "Optical-flow cradle + LOS deck + magnet cups", T4A,
     "0.16 / 0.20", "4 walls; 4 top / 4 bottom", "100% concentric",
     "230 C / 45 C", "35/45/45 mm/s; retraction 0.8 mm @ 25 mm/s",
     "no supports; xy_hole_compensation +0.05 mm for 2.10 x 1.20 mm N52 sockets (magnet recessed 0.20 mm)",
     "SOP: 55 C 4 h " + V,
     "KODIAK75_TPU95A_Flex_OrcaProfile.json (name lists '95A/56D' -> drop 56D). Dense 100% walls kept for magnet-socket accuracy; the GEMINI '2 walls + 15% gyroid' recipe applies only to 85A/90A-mimic parts."),
]

# ----------------------------------------------------------------------------------------------------------------------
def focus_violation_rows():
    summary = json.loads(SCAN_JSON.read_text(encoding="utf-8")) if SCAN_JSON.exists() else {}
    per = defaultdict(Counter)
    if SCAN_CSV.exists():
        with SCAN_CSV.open(encoding="utf-8", newline="") as fh:
            for r in csv.DictReader(fh):
                if r["class"] == "ACTIVE" and r["file"] in summary.get("focus_active_by_file", {}):
                    per[r["file"]][r["term"]] += 1
    action = {
        ".json": "Edit slicer preset name + notes; re-export for P2S.",
        ".csv": "Edit BOM line; re-cost.",
        ".md": "Edit text.",
        ".html": "Regenerate from its builder (do not hand-edit generated HTML).",
        ".py": "Fix the generator, then regenerate outputs.",
        ".scad": "Comment-only: fix header comment.",
    }
    rows = []
    for f, terms in sorted(per.items(), key=lambda kv: -sum(kv[1].values())):
        ext = Path(f).suffix.lower()
        rows.append([f.replace("03_Hardware_and_Drones/", "03_.../").replace("01_Sales_and_STEM_Academy/Team_Playbooks_and_Operations/", "01_.../"),
                     ", ".join(f"{t} x{n}" for t, n in terms.most_common()), str(sum(terms.values())), action.get(ext, "Review")])
    return summary, rows


def check_sheet_is_compliant():
    """Self-check: nothing we publish in the BOM/profile sheet names a banned material as a CHOICE."""
    problems = []
    for row in PROFILES:
        tier = row[2]
        if not any(a.split(" ")[0] in tier for a in ("T1", "T2", "T3", "T4A", "T4B")):
            problems.append(("tier", row[1]))
        for w in BANNED_WORDS:
            if w in tier:
                problems.append((w, row[1]))
    for part in CUB_PRINT + SHARD_PRINT:
        if not any(t in part[2] for t in ("T1", "T2", "T3", "T4A", "T4B")):
            problems.append(("tier", part[0]))
    return problems


def build():
    problems = check_sheet_is_compliant()
    assert not problems, f"sheet violates 4-tier standard: {problems}"

    cub_rows, cub_total, cub_stated, cub_opt = cub_bom()
    sh_rows, sh_los, sh_dual, sh_kit = shard_bom()
    sum_scan, viol_rows = focus_violation_rows()

    # --- CSV outputs -------------------------------------------------------------------------------------------------
    hdr = ["category", "component", "spec", "qty", "unit", "extended", "material_tier_or_COTS", "note"]
    for name, rows in (("CUB75_BOM_4tier.csv", cub_rows), ("SHARD75_BOM_4tier.csv", sh_rows)):
        with (HERE / name).open("w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(hdr)
            w.writerows(rows)
    with (HERE / "print_profiles_4tier.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["platform", "part", "tier", "layer", "walls_shells", "infill", "nozzle_bed", "fan_speed", "support_brim", "drying", "source_status"])
        w.writerows(PROFILES)

    # --- DOCX ---------------------------------------------------------------------------------------------------------
    doc = K.new_doc(landscape=True)
    K.banner(doc, "CUB-75 + SHARD-75 BOM & 4-Tier Print-Profile Sheet",
             "Release-readiness evidence for Jesus Aceves (CTO) - strictly Bambu PETG-CF / PAHT-CF / PLA+ / TPU 95A HF + TPU 68D",
             "Osito Drone LLC - Core Fleet - prepared 2026-10-31 - arithmetic recomputed; NO physical weighing or print tests performed")

    K.callout(doc, "HOW TO READ THIS SHEET",
              "Every figure comes from an existing workspace file (cited) or is recomputed arithmetic. Anything that needs a scale, a printer, "
              "a bench FC or a vendor quote is tagged [VERIFY]. Status colours: PASS = arithmetic/standard check passed on paper; "
              "FAIL = conflicts with the 4-tier standard or with another workspace figure; VERIFY = requires a physical or vendor check.")

    K.h1(doc, "1. Headline findings")
    K.bullets(doc, [
        ("CUB-75 BOM arithmetic PASS: ", f"line items sum to {money(cub_total)} = stated subtotal {money(cub_stated)}; with the optional nano camera {money(cub_total + cub_opt[0][1])}."),
        ("SHARD-75 BOM arithmetic PASS: ", f"LOS {money(sh_los)} / Dual {money(sh_dual)} match KODIAK75_BOM_and_Sourcing.md ($101.44 / $121.43)."),
        ("FAIL - SHARD-75 BOM has no optical-flow/LiDAR line: ", "the 45.5 g headline configuration (Full Optical-Flow + LiDAR + N52 armor) adds +8.4 g over the 37.1 g LOS build but the BOM lists no MTF-01 (or equivalent) part, mass or price. Cost TBD [VERIFY]."),
        ("FAIL - cross-document CUB-75 conflicts: ", "the 28-drone safety report data (generate_safety_audit_reports.py) says '$108.50 ready-to-fly, 28.0 g dry + 11.5 g 1S 450 mAh'; the Gen-2 spec also uses a 450 mAh pack; the BOM/PRD say $98.04 and 25.7 g dry + 13.8 g 550 mAh. One pack must be chosen [VERIFY]."),
        ("FAIL - filament standard: ", f"{sum_scan.get('focus_active_hits', '?')} active hits of banned/redundant materials in {len(viol_rows)} CUB-75 / SHARD-75 / SOP files (ePA-CF, PC-CF/CarbonX, TPU 56D/90A, PC-Blend). No PEEK / PPS-CF / TPU 85A in the core-fleet files themselves; PEEK appears only in smart_disc_golf feasibility text and as a row in the filament-control table."),
        ("VERIFY - mass budget: ", "CUB-75 printed parts (15.0 g) + typical avionics/propulsion figures used for SHARD (14.0 g) exceed the stated 25.7 g dry weight by ~3.3 g; weigh one built airframe on a 0.01 g scale before quoting 39.5 g to a school."),
    ], size=9)

    # --- CUB BOM
    K.h1(doc, "2. CUB-75 bill of materials (LOS trainer, 1 unit) - source: CUB75_BOM_and_Sourcing.csv")
    K.table(doc, ["Category", "Component", "Spec (source wording)", "Qty", "Unit", "Ext.", "4-tier material", "Standardisation note"],
            cub_rows + [["TOTAL", "Recomputed line-item sum", "", "", "", money(cub_total), "", f"Stated subtotal {money(cub_stated)} -> {'PASS' if abs(cub_total-cub_stated)<0.005 else 'FAIL'}"],
                        ["Optional", cub_opt[0][0], "BetaFPV C03 / Runcam Nano 3", "1", money(cub_opt[0][1]), money(cub_opt[0][1]), "COTS", f"Dual LOS+FPV total {money(cub_total+cub_opt[0][1])} (BOM .md says $118.03)"],
                        ["Optional", cub_opt[1][0], "Radiomaster Pocket ELRS", "1", money(cub_opt[1][1]), money(cub_opt[1][1]), "COTS", "Student radio, not part of airframe BOM"]],
            widths=[1.0, 1.5, 2.6, 0.4, 0.6, 0.6, 1.5, 3.0], size=7)

    # --- SHARD BOM
    K.h1(doc, "3. SHARD-75 / KODIAK-75 bill of materials (1 unit) - source: KODIAK75_BOM_and_Sourcing.csv")
    K.table(doc, ["Category", "Part", "Spec (abridged)", "Qty", "Unit", "Ext.", "4-tier material", "Standardisation note"],
            sh_rows + [["TOTAL", "LOS build (excl. optional camera)", "", "", "", money(sh_los), "", "PASS vs documented $101.44"],
                       ["TOTAL", "Dual LOS+FPV (with camera)", "", "", "", money(sh_dual), "", "PASS vs documented $121.43"],
                       ["MISSING", "Optical-flow + LiDAR module (45.5 g config)", "e.g. MicoAir MTF-01 is named in the Gen-2 spec; no part/price in BOM", "-", "TBD", "TBD", "COTS", "FAIL: add line with vendor quote [VERIFY]"]],
            widths=[1.0, 1.6, 2.4, 0.4, 0.6, 0.6, 1.5, 3.1], size=7)
    blended = round((sh_los + sh_dual) / 2, 2)
    K.para(doc, f"Arithmetic cross-checks on the SHARD-75 documents: the .md quotes a '$112.50 blended fleet average' but (LOS + Dual) / 2 = {money(blended)}; "
                f"the 2-drone arena kit row shows '$221.90 for 2 Dual drones' but 2 x {money(sh_dual)} = {money(2*sh_dual)}. "
                f"The CSV 2-drone-kit column (drones + spares + GSE) sums to {money(sh_kit)}. Reconcile before quoting [VERIFY].", size=8.5, color=K.MUTED)

    # --- Mass
    K.h1(doc, "4. Mass-budget verification (paper arithmetic only)")
    mrows = []
    for name, (calc, stated, src) in MASS.items():
        if calc is None:
            status, d = "VERIFY", "no component breakdown"
        else:
            diff = round(stated - calc, 2)
            status = "PASS" if abs(diff) <= 0.06 else "FAIL"
            d = f"sum {calc:.2f} g (delta {diff:+.2f} g)"
        under50 = "yes" if stated < YOUTH_CEILING_G else "NO"
        mrows.append([name, f"{stated:.1f} g", d, under50, "yes" if stated < FAA_SUB250_G else "NO", status, src])
    K.table(doc, ["Configuration", "Stated AUW", "Recomputed", "< 50 g Gen-2 ceiling", "< 250 g", "Check", "Source / note"], mrows,
            widths=[3.2, 0.8, 1.7, 0.9, 0.6, 0.6, 3.2], size=7, status_col=5)
    K.para(doc, "The 50 g figure is Osito's internal Gen-2 youth-mass gate (test_gen2_snapdeck_safety.py), not an FAA number. "
                "Youth sessions must still follow the FAA TRUST, sub-250 g prop-guarded, signed-waiver rules in GEMINI.md. "
                "Note: the SHARD-75 + SNAP-LASER row recomputes to 48.4 g when the 0.3 g pogo receptor is included; the Gen-2 spec states 48.1 g (omits it). Both are < 50 g.", size=8.5, color=K.MUTED)

    # --- Profiles
    K.h1(doc, "5. Print-profile sheet under the 4-tier standard (P2S Combo x2, 0.4 mm hardened steel, 300 C / 110 C max)")
    K.table(doc, ["Platform", "Part", "Material tier", "Layer", "Walls / shells", "Infill", "Nozzle / bed", "Fan / speed", "Support / brim", "Drying", "Source & status"],
            [list(r) for r in PROFILES], widths=[0.7, 1.3, 1.5, 0.8, 0.9, 0.7, 1.4, 1.1, 1.2, 1.1, 2.2], size=6.5)
    K.para(doc, "Vendor ranges quoted as 'Bambu web summary' came from a web search summary and have not been checked against the Bambu Studio presets or spool labels - treat as [VERIFY]. "
                "'Documented' values are those already in the workspace slicer JSONs / SOP.", size=8.5, color=K.MUTED)

    # --- Filament load
    K.h1(doc, "6. Filament load per aircraft set and AMS map")
    cm, sm = tier_masses(CUB_PRINT), tier_masses(SHARD_PRINT)
    lrows = [["CUB-75", "T1 PETG-CF", f"{cm[T1]:.1f} g", "P2S #1 slot 1"],
             ["CUB-75", "T4A TPU 95A HF", f"{cm[T4A]:.1f} g", "P2S #2 external dryer port"],
             ["CUB-75", "T4B TPU for AMS 68D", f"{cm[T4B]:.1f} g", "P2S #1 slot 4"],
             ["CUB-75", "TOTAL printed", f"{sum(cm.values()):.1f} g", "SOP total 15.0 g -> PASS" if abs(sum(cm.values()) - 15.0) < 0.05 else "FAIL vs SOP"],
             ["SHARD-75", "T2 PAHT-CF", f"{sm[T2]:.1f} g", "P2S #1 slot 2"],
             ["SHARD-75", "T4A TPU 95A HF", f"{sm[T4A]:.1f} g", "P2S #2 external dryer port"],
             ["SHARD-75", "T4B TPU for AMS 68D", f"{sm[T4B]:.1f} g", "P2S #1 slot 4"],
             ["SHARD-75", "TOTAL printed", f"{sum(sm.values()):.1f} g", "SOP total 14.2 g -> PASS" if abs(sum(sm.values()) - 14.2) < 0.05 else "FAIL vs SOP"]]
    K.table(doc, ["Platform", "Spool", "Grams per set", "Slot / printer"], lrows, widths=[1, 2, 1, 3], size=8)
    K.para(doc, "Reconciliation: the existing Master Filament Control sheet (build_master_filament_control_all_projects.py) books CUB-75 canopies under TPU 95A (8.2 g) with 0 g of 68D; "
                "GEMINI.md says multi-colour CUB-75 canopies use 68D. Above, canopies are booked to T4B (6.2 g T4A + 2.0 g T4B). Update the control sheet on its next regeneration.", size=8.5, color=K.MUTED)
    K.para(doc, "AMS slot map (P2S #1): slot 1 PETG-CF | slot 2 PAHT-CF | slot 3 PLA+/PLA Tough | slot 4 TPU for AMS 68D.  P2S #2: TPU 95A HF on the external dryer port. "
                "Never load soft 95A inside the AMS.", size=8.5)

    # --- Violations
    K.h1(doc, "7. Filament-standard violations found (focus: CUB-75, SHARD-75/KODIAK-75, manufacturing SOP)")
    K.para(doc, f"Scan: {sum_scan.get('scanned_text_files', '?')} text files; {sum_scan.get('active_hits', '?')} ACTIVE hits workspace-wide in {sum_scan.get('active_files', '?')} files "
                f"(by term: {sum_scan.get('active_by_term', {})}). Classification is heuristic (lines that merely say a material was replaced are NEGATION). "
                "Full line-level list: filament_violation_hits.csv. Originals were not edited.", size=8.5)
    K.table(doc, ["File", "Banned terms found (count)", "Hits", "Fix path"], viol_rows, widths=[5, 2.6, 0.5, 2.8], size=7)
    K.callout(doc, "SPECIFIC CORE-FLEET DEFECTS TO FIX AT THE SOURCE",
              "1) CUB75_BOM_and_Sourcing (.csv/.md) + CUB75_Frame_PETG_or_PACF_Profile.json: frame lists 'Tough PLA+ / ePA-CF' alternatives. "
              "2) KODIAK75_BOM_and_Sourcing + KODIAK75_PC-CF_Frame_OrcaProfile.json + KODIAK75_Horns_Sandwich_OrcaProfile.json (manual M600 swaps, ePA-CF core, TPU 95A skins): replace with PAHT-CF + 68D AMS sandwich. "
              "3) 2026-10-31_InHouse_Manufacturing_and_3D_Print_Farm_SOP/generate_manufacturing_docx.py still specifies CarbonX PC-CF / ePA-CF / PC-Blend, 'Bambu P1S / X1C or Prusa' hardware and manual TPU+ePA-CF pauses, "
              "although the Master Filament Control sheet in the same folder already enforces the 4-tier standard. "
              "4) 3D_PRINTER_BUYING_GUIDE.md / KODIAK75_Developer_Handoff_PRD.* / Team_Jesus_CTO_Makerspace_and_Demo_Playbook.md carry the same legacy specs.")

    if CSV_DEFECTS:
        K.callout(doc, "SOURCE-FILE DEFECT: MALFORMED BOM CSV ROWS (repaired in memory only; originals untouched)",
                  "; ".join(f"{f} line {n} [{part}]: {why}" for f, n, part, why in CSV_DEFECTS) +
                  ". The fleet audit's BOM check only counts rows, so it passes despite this. Fix by quoting the field in a v2 BOM.")

    # --- verify list
    K.h1(doc, "8. [VERIFY] list for the CTO (needs hardware, vendor or decision)")
    K.table(doc, ["#", "Item", "Why it matters", "How to close"], [
        ["1", "Weigh one built CUB-75 (LOS) and one SHARD-75 (LOS + optical-flow) on a 0.01 g scale", "39.5 g / 45.5 g are PRD figures; component sums do not close (CUB ~3.3 g, SHARD +8.4 g unexplained)", "Record on the release checklist"],
        ["2", "Pick the CUB-75 battery: 550 mAh (BOM/PRD) vs 450 mAh (Gen-2 spec, safety-report data)", "Mass, flight time, cradle STL and cost differ", "Decide; update the losing documents"],
        ["3", "Add optical-flow/LiDAR part, mass and price to SHARD-75 BOM", "Headline 45.5 g config is un-costed", "Vendor quote"],
        ["4", "68D profile on P2S #1 AMS slot 4 (canopies, horn skins)", "No workspace profile exists", "Print coupon + peel test"],
        ["5", "PAHT-CF <-> 68D sandwich adhesion and nozzle-temp swap (225 vs 280 C)", "Horns are impact parts on a combat platform", "Peel/impact coupon test before first batch"],
        ["6", "Bambu Studio PAHT-CF preset vs documented 285-295 C / 105 C / chamber 55 C", "Documented values exceed the vendor range quoted by web summary", "Compare with spool label & preset"],
        ["7", "Re-cost printed parts for PAHT-CF / 68D / PETG-CF", "SOP costs ($0.52 / $0.68) are for legacy spools", "Spool prices"],
        ["8", "Printed-frame mass: SOP 4.2 g vs PRD 2.1 g (SHARD)", "Sets balance of the mass budget", "Weigh a printed frame"],
    ], widths=[0.3, 3.4, 3.4, 2.6], size=7.5)
    K.footer(doc, "Osito Drone LLC - internal engineering document - generated by build_bom_and_print_sheet.py - 2026-10-31 - no flight or print tests were performed")
    out = HERE / "CUB75_SHARD75_BOM_and_Print_Profile_Sheet.docx"
    doc.save(out)
    print("wrote", out)
    print(f"CUB total {cub_total} stated {cub_stated} | SHARD LOS {sh_los} dual {sh_dual} kit-col {sh_kit} | tiers CUB {dict(cm)} SHARD {dict(sm)}")


if __name__ == "__main__":
    build()


