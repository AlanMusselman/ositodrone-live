﻿#!/usr/bin/env python3
"""
Filament-standard violation scan (READ-ONLY on the workspace; writes only next to this script).

Standard (GEMINI.md section 3): only 4 tiers - Bambu PETG-CF | Bambu PAHT-CF / PA12-CF | eSUN PLA+ / Bambu PLA Tough |
Bambu TPU 95A HF (P2S #2 external dryer) + Bambu TPU for AMS 68D (P2S #1 slot 4).
Banned/redundant terms: PEEK, PPS-CF, TPU 85A, TPU 90A, TPU 56D / 55D, ePA-CF, CarbonX PC-CF / PC-CF, PC-Blend,
                        PA6-CF / PA-CF (other than PAHT-CF / PA12-CF), PET-CF, Nylon-CF (generic), ULTEM/PEI filament.
Each hit is classified:
   NEGATION  - line is clearly saying the term was replaced / eliminated / is forbidden (acceptable)
   ACTIVE    - line specifies the term as a current material choice (violation to fix in the owning generator/file)
Classification is heuristic; the CSV keeps the full line so a human can overrule.
"""
import csv
import json
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]

BANNED = [
    ("PEEK", r"\bPEEK\b"),
    ("PPS-CF", r"\bPPS[- ]?CF\b"),
    ("TPU 85A", r"(?<![\d.])\b(?:TPU|Shore)\s*85A\b|(?<![\d.])\b85A\s*(?:/\s*90A\s*)?TPU\b|(?<![\d.])\b85A\s*(?:&|and)\s*90A\b"),
    ("TPU 90A", r"\bTPU\s*90A\b"),
    ("TPU 56D/55D", r"\bTPU\s*5[56]D\b|\b56D\b"),
    ("ePA-CF", r"\bePA[- ]?CF\b"),
    ("PC-CF", r"\bPC[- ]?CF\b|\bCarbonX\b"),
    ("PC-Blend", r"\bPC[- ]?Blend\b"),
    ("PA6-CF / generic PA-CF", r"\bPA6[- ]?CF\b|\bPAHT[- ]?CF[/ ]PA6\b"),
    ("PET-CF", r"\bPET[- ]?CF\b"),
]
NEGATION = re.compile(
    r"legacy|replac|eliminat|never|outlier|standardiz|instead of|no longer|forbid|banned|unprintable|redundant|"
    r"overkill|superseded|migrat|previously|was\b|old\b|removed|deprecated|violation|do not|don't|not allowed|"
    r"audit_note|enforced_|legacy_spec", re.I)
TEXT_EXT = {".md", ".py", ".csv", ".json", ".html", ".txt", ".scad", ".ps1", ".cpp", ".c", ".h", ".lua", ".ino", ".eml"}
SKIP_PARTS = {".git", "node_modules", "__pycache__", ".agents", "gerbers", "Photography", "Logos"}


def main():
    hits = []
    scanned = 0
    for p in ROOT.rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEXT_EXT:
            continue
        if any(part in SKIP_PARTS for part in p.parts) or HERE in p.parents:
            continue
        if p.stat().st_size > 3_000_000:
            continue
        rel = str(p.relative_to(ROOT)).replace("\\", "/")
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        scanned += 1
        for i, ln in enumerate(text.splitlines(), 1):
            for label, rx in BANNED:
                if re.search(rx, ln, 0 if label in ("TPU 85A", "PEEK") else re.I):
                    ctx = "NEGATION" if NEGATION.search(ln) else "ACTIVE"
                    hits.append({"term": label, "class": ctx, "file": rel, "line": i, "text": ln.strip()[:220]})
    by_file = defaultdict(Counter)
    for h in hits:
        by_file[h["file"]][(h["term"], h["class"])] += 1
    with (HERE / "filament_violation_hits.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=["term", "class", "file", "line", "text"])
        w.writeheader()
        w.writerows(hits)
    active = [h for h in hits if h["class"] == "ACTIVE"]
    files_active = Counter(h["file"] for h in active)
    # focus set: the CUB-75 / SHARD-75 related paths + the manufacturing SOP + the Gen-2 suite
    focus_rx = re.compile(r"Kids Training Drone|Bumper Drones|CUB75|SHARD75|KODIAK|InHouse_Manufacturing|Gen2_Modular", re.I)
    focus = [h for h in active if focus_rx.search(h["file"])]
    summary = {
        "scanned_text_files": scanned,
        "total_hits": len(hits),
        "active_hits": len(active),
        "active_files": len(files_active),
        "active_by_term": dict(Counter(h["term"] for h in active)),
        "focus_active_hits": len(focus),
        "focus_active_by_file": dict(Counter(h["file"] for h in focus)),
        "focus_active_by_term": dict(Counter(h["term"] for h in focus)),
        "top_active_files": files_active.most_common(25),
    }
    (HERE / "filament_violation_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in summary.items() if k != "top_active_files"}, indent=2))
    print("\nTop ACTIVE files:")
    for f, n in files_active.most_common(25):
        print(f"  {n:4d}  {f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

