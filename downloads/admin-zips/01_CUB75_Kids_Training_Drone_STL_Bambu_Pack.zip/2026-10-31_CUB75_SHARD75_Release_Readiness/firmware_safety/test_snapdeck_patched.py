#!/usr/bin/env python3
"""
Unit tests for gen2_snapdeck_firmware_patched.cpp (rev P1) with differential checks against the ORIGINAL firmware.

HOW IT WORKS
  * Compiles BOTH the original gen2_snapdeck_firmware.cpp and the patched copy into throw-away DLLs (temp dir) using the
    Zig C++ compiler shipped by `pip install ziglang` (clang front-end), plus a small C-ABI shim (snapdeck_capi.inc),
    then drives the REAL firmware code through ctypes. No behavioural re-implementation is used for firmware logic.
  * Tests named *_original_defect_* assert that the ORIGINAL exhibits the defect (so the finding is reproducible);
    tests named *_patched_* assert the patched copy is safe.

RUN:   python test_snapdeck_patched.py            (unittest; pytest also works)
SCOPE: host-side logic only. This is NOT hardware-in-the-loop, NOT flight testing, and does not exercise UART/ISR timing.
       If no C++ compiler is available the compiled tests SKIP loudly and only static checks run.
"""
import ctypes
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
PATCHED = Path(os.environ.get("SNAPDECK_FW_UNDER_TEST", str(HERE / "gen2_snapdeck_firmware_patched.cpp"))).resolve()  # env override used by mutation_check.py
ORIGINAL = (HERE.parents[1] / "2026-10-31_CUB75_and_SHARD75_Gen2_Modular_Upgrades" / "gen2_snapdeck_firmware.cpp")
SHIM = HERE / "snapdeck_capi.inc"

NONE, CODE, LASER, CLAW = 0, 1, 2, 3
(F_ARMED, F_FAILSAFE_ACTIVE, F_FAILSAFE_STATE, F_MOTOR_PWM, F_CLAW_PWM, F_IR_FIRE, F_PIEZO, F_PITCH_CMD, F_ROLL_CMD,
 F_IR_SHOTS, F_IR_HITS, F_HALO_R, F_HALO_G, F_HALO_B, F_TOF, F_CLAW_LOAD, F_SENSOR_STALE, F_LAST_HB) = range(18)

# ----------------------------------------------------------------------------------------------------------------------
# Independent references (NOT firmware logic)
# ----------------------------------------------------------------------------------------------------------------------
def crc8_dvb_s2(data: bytes) -> int:
    crc = 0
    for b in data:
        crc ^= b
        for _ in range(8):
            crc = ((crc << 1) ^ 0xD5) & 0xFF if crc & 0x80 else (crc << 1) & 0xFF
    return crc


def find_compiler():
    try:
        import ziglang  # noqa: F401
        return [sys.executable, "-m", "ziglang", "c++"]
    except Exception:
        pass
    for exe in ("g++", "clang++"):
        p = shutil.which(exe)
        if p:
            return [p]
    return None


class Build:
    """Compile one firmware variant to a DLL and wrap it."""
    def __init__(self, name, fw_path, patched, workdir, compiler):
        shim_cpp = Path(workdir) / f"shim_{name}.cpp"
        lib = Path(workdir) / (f"fw_{name}.dll" if os.name == "nt" else f"fw_{name}.so")
        defs = ["-DPATCHED=1"] if patched else []
        shim_cpp.write_text(
            f'#include "{fw_path.as_posix()}"\n#include "{SHIM.as_posix()}"\n', encoding="utf-8")
        cmd = compiler + ["-std=c++17", "-O1", "-w", "-shared"] + defs + ["-o", str(lib), str(shim_cpp)]
        if os.name != "nt":
            cmd.insert(len(compiler), "-fPIC")
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0 or not lib.exists():
            raise RuntimeError(f"compile failed for {name}:\n{proc.stdout}\n{proc.stderr[-2000:]}")
        L = ctypes.CDLL(str(lib))
        L.h_new.restype = ctypes.c_void_p
        for fn, args in [("h_free", [ctypes.c_void_p]),
                         ("h_init", [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint16]),
                         ("h_heartbeat", [ctypes.c_void_p, ctypes.c_int, ctypes.c_uint16]),
                         ("h_tick", [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_int, ctypes.c_int]),
                         ("h_sensor", [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint16]),
                         ("h_set", [ctypes.c_void_p, ctypes.c_int, ctypes.c_int32]),
                         ("h_pkt_raw", [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]),
                         ("h_pkt_crc", [ctypes.c_void_p]),
                         ("h_wire", [ctypes.c_void_p, ctypes.c_char_p]),
                         ("h_has_elapsed", [ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint16])]:
            getattr(L, fn).argtypes = args
        L.h_get.argtypes = [ctypes.c_void_p, ctypes.c_int]
        L.h_get.restype = ctypes.c_int32
        L.h_pkt_raw.restype = ctypes.c_int
        L.h_pkt_crc.restype = ctypes.c_int
        L.h_wire.restype = ctypes.c_int
        L.h_has_elapsed.restype = ctypes.c_int
        L.h_pkt_crc_offset.restype = ctypes.c_int
        L.h_has_wire.restype = ctypes.c_int
        self.L = L

    def new(self, payload=NONE, boot=0):
        return Unit(self.L, payload, boot)


class Unit:
    def __init__(self, L, payload, boot):
        self.L = L
        self.h = L.h_new()
        L.h_init(self.h, payload, boot & 0xFFFF)

    def __del__(self):
        try:
            self.L.h_free(self.h)
        except Exception:
            pass

    def hb(self, armed, now):
        self.L.h_heartbeat(self.h, int(armed), now & 0xFFFF)

    def tick(self, now, trig=False, hit=False):
        self.L.h_tick(self.h, now & 0xFFFF, int(trig), int(hit))

    def sensor(self, tof, claw_x10, now):
        self.L.h_sensor(self.h, tof, claw_x10, now & 0xFFFF)

    def g(self, f):
        return self.L.h_get(self.h, f)

    def s(self, f, v):
        self.L.h_set(self.h, f, v)

    def safe_outputs(self):
        return (self.g(F_MOTOR_PWM) == 1000 and self.g(F_CLAW_PWM) == 1500 and self.g(F_IR_FIRE) == 0
                and self.g(F_PIEZO) == 0 and self.g(F_PITCH_CMD) == 0 and self.g(F_ROLL_CMD) == 0)


COMPILER = find_compiler()
_TMP = None
ORIG = PAT = None
_BUILD_ERR = None
if COMPILER:
    try:
        _TMP = tempfile.mkdtemp(prefix="osito_snapdeck_")
        ORIG = Build("orig", ORIGINAL, False, _TMP, COMPILER)
        PAT = Build("patched", PATCHED, True, _TMP, COMPILER)
    except Exception as exc:  # pragma: no cover
        _BUILD_ERR = str(exc)

needs_cc = unittest.skipIf(PAT is None or ORIG is None,
                           f"no C++ compiler / build failed: {_BUILD_ERR or 'ziglang not installed (pip install ziglang)'}")


# ----------------------------------------------------------------------------------------------------------------------
class StaticChecks(unittest.TestCase):
    def test_original_file_untouched_in_git(self):
        self.assertTrue(ORIGINAL.is_file(), "original firmware missing")
        git = shutil.which("git")
        if not git:
            self.skipTest("git not available")
        root = HERE.parents[3]
        out = subprocess.run([git, "-C", str(root), "status", "--porcelain", "--", str(ORIGINAL)],
                             capture_output=True, text=True)
        if "fatal" in (out.stderr or "").lower():
            self.skipTest("not a git checkout")
        self.assertEqual(out.stdout.strip(), "", "original firmware must not be modified")

    def test_patched_source_markers(self):
        t = PATCHED.read_text(encoding="utf-8")
        self.assertIn("static_assert(WATCHDOG_TIMEOUT_MS < 32768U", t)
        self.assertIn("(int16_t)(uint16_t)(now_ms - last_ms)", t)
        self.assertIn("state.failsafe_active ||", t)
        self.assertIn("TELEMETRY_WIRE_LEN", t)
        # no raw unsigned compare of an elapsed value against a timeout outside has_elapsed_u16
        self.assertNotIn("(uint16_t)(now_ms - state.last_fc_heartbeat_ms) >=", t)
        # no magic actuator numbers inside the tick body
        body = t.split("void update_snapdeck_tick(")[1].split("uint8_t status_flags_of")[0]
        for magic in ("= 1500;", "= 1000;", "= 1250;"):
            self.assertNotIn(magic, body)

    def test_reference_crc_vector(self):
        # CRC-8/DVB-S2 check value for "123456789" is 0xBC (standard catalogue value)
        self.assertEqual(crc8_dvb_s2(b"123456789"), 0xBC)


@needs_cc
class ElapsedMath(unittest.TestCase):
    def test_patched_has_elapsed_matches_signed_model(self):
        for last in (0, 1, 100, 32767, 32768, 65000, 65300, 65535):
            for d in (-5, -1, 0, 1, 399, 400, 401, 1000, 32767):
                now = (last + d) & 0xFFFF
                expect = (d >= 400)
                self.assertEqual(bool(PAT.L.h_has_elapsed(now, last, 400)), expect, (last, d))

    def test_rollover_boundaries(self):
        L = PAT.L
        self.assertFalse(L.h_has_elapsed(100, 65400, 400))   # 236 ms
        self.assertTrue(L.h_has_elapsed(165, 65300, 400))    # 401 ms
        self.assertTrue(L.h_has_elapsed(164, 65300, 400))    # exactly 400 ms
        self.assertFalse(L.h_has_elapsed(163, 65300, 400))   # 399 ms
        self.assertFalse(L.h_has_elapsed(0, 65535, 2))       # 1 ms


@needs_cc
class Watchdog(unittest.TestCase):
    def test_patched_nominal_heartbeat_across_rollover_never_trips(self):
        u = PAT.new(CLAW, boot=65000)
        u.hb(True, 65000)
        t = 65000
        for _ in range(400):                       # 2.0 s of 5 ms ticks spanning 65535 -> 0
            t += 5
            if (t - 65000) % 50 == 0:
                u.hb(True, t)
            u.sensor(1000, 0, t)
            u.tick(t)
            self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 0, f"false trip at t={t & 0xFFFF}")
            self.assertEqual(u.g(F_ARMED), 1)

    def test_patched_trip_exactly_at_400ms_including_wrap(self):
        for last in (1000, 65300, 65535):
            u = PAT.new(NONE, boot=last)
            u.hb(True, last)
            u.tick(last + 399)
            self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 0, f"early trip last={last}")
            u.tick(last + 400)
            self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 1, f"no trip last={last}")
            self.assertEqual(u.g(F_FAILSAFE_STATE), 2)
            self.assertTrue(u.safe_outputs())
            self.assertEqual((u.g(F_HALO_R), u.g(F_HALO_G), u.g(F_HALO_B)), (255, 0, 0))

    @unittest.expectedFailure
    def test_original_defect_heartbeat_stamped_after_tick_now_is_NOT_spurious_trip(self):
        # Documents ORIGINAL defect P1-2: assertion (no trip) FAILS on the original, hence expectedFailure.
        u = ORIG.new(NONE, boot=1000)
        u.hb(True, 1000)
        u.tick(1100); u.hb(True, 1101)          # ISR stamps 1 ms *after* the tick's captured now
        u.tick(1100)                            # tick still using now=1100 -> elapsed = (uint16_t)(-1) = 65535
        self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 0)

    def test_patched_future_heartbeat_stamp_does_not_trip(self):
        for ahead in (1, 2, 5, 50):
            u = PAT.new(CLAW, boot=1000)
            u.hb(True, 1000)
            u.hb(True, 1100 + ahead)
            u.tick(1100)
            self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 0, f"ahead={ahead}")

    def test_patched_failsafe_stays_latched_across_full_16bit_wrap(self):
        u = PAT.new(CLAW, boot=0)
        u.hb(True, 0)
        t = 0
        for _ in range(900):                       # 90 s of silence at 10 Hz (> 65.536 s and > 32.768 s)
            t += 100
            u.tick(t, trig=True)
            if t >= 400:
                self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 1, f"un-tripped at {t} ms")
                self.assertTrue(u.safe_outputs(), f"unsafe outputs at {t} ms")


@needs_cc
class LatchBypass(unittest.TestCase):
    def _trip(self, b, payload):
        u = b.new(payload, boot=0)
        u.hb(True, 0)
        u.sensor(1000, 0, 0)
        u.tick(500, trig=True)
        self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 1)
        return u

    def test_original_defect_armed_heartbeat_after_trip_re_enables_outputs(self):
        u = self._trip(ORIG, CLAW)
        u.hb(True, 510)                       # FC still reports armed
        u.sensor(1000, 0, 510)
        u.tick(515, trig=True)
        # Demonstrates the defect: motors/claw come back although the failsafe was never cleared by a disarm.
        self.assertEqual(u.g(F_MOTOR_PWM), 1250)
        self.assertEqual(u.g(F_CLAW_PWM), 1850)

    def test_patched_armed_heartbeat_cannot_clear_failsafe(self):
        for payload in (NONE, CODE, LASER, CLAW):
            u = self._trip(PAT, payload)
            for k in range(1, 30):
                u.hb(True, 500 + 10 * k)
                u.sensor(1000, 0, 500 + 10 * k)
                u.tick(500 + 10 * k + 5, trig=True, hit=True)
                self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 1)
                self.assertEqual(u.g(F_ARMED), 0)
                self.assertTrue(u.safe_outputs(), f"payload={payload}")

    def test_patched_heartbeat_layer_alone_keeps_is_armed_false_while_latched(self):
        # Layer 1 (on_fc_heartbeat) must hold on its own, BEFORE any tick can re-assert the failsafe (layer 2).
        for payload in (NONE, CODE, LASER, CLAW):
            u = self._trip(PAT, payload)
            u.hb(True, 520)
            self.assertEqual(u.g(F_ARMED), 0, f"payload={payload}")
            self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 1)

    def test_patched_clears_only_after_disarmed_heartbeat_then_rearm(self):
        u = self._trip(PAT, CLAW)
        u.hb(False, 600)
        self.assertEqual(u.g(F_FAILSAFE_ACTIVE), 0)
        self.assertEqual(u.g(F_ARMED), 0)
        u.tick(605)
        self.assertTrue(u.safe_outputs())
        self.assertEqual((u.g(F_HALO_R), u.g(F_HALO_G), u.g(F_HALO_B)), (112, 119, 207))
        u.hb(True, 650)
        u.sensor(1000, 0, 650)
        u.tick(655, trig=True)
        self.assertEqual(u.g(F_ARMED), 1)
        self.assertEqual(u.g(F_CLAW_PWM), 1850)


@needs_cc
class DisarmedInterlock(unittest.TestCase):
    def test_patched_init_is_safe_for_all_payloads(self):
        for payload in (NONE, CODE, LASER, CLAW):
            u = PAT.new(payload, boot=12345)
            self.assertEqual(u.g(F_ARMED), 0)
            self.assertTrue(u.safe_outputs())

    def test_patched_disarmed_blocks_every_actuator(self):
        for payload in (NONE, CODE, LASER, CLAW):
            u = PAT.new(payload, boot=0)
            t = 0
            for _ in range(100):
                t += 5
                if t % 50 == 0:
                    u.hb(False, t)
                u.sensor(100, 200, t)         # wall in face + claw overload
                u.tick(t, trig=True, hit=True)
                self.assertTrue(u.safe_outputs(), f"payload={payload} t={t}")
            self.assertEqual(u.g(F_IR_SHOTS), 0)

    def test_original_also_blocks_when_disarmed(self):   # regression: the patch must not weaken this
        for payload in (CODE, LASER, CLAW):
            u = ORIG.new(payload, boot=0)
            u.hb(False, 0)
            u.tick(5, trig=True, hit=True)
            self.assertTrue(u.safe_outputs())

    def test_patched_arm_state_follows_heartbeat_when_not_latched(self):
        u = PAT.new(CLAW, boot=0)
        u.hb(True, 0); u.sensor(1000, 0, 0); u.tick(5, trig=True)
        self.assertEqual(u.g(F_CLAW_PWM), 1850)
        u.hb(False, 10); u.tick(15, trig=True)
        self.assertTrue(u.safe_outputs())


@needs_cc
class PayloadLogic(unittest.TestCase):
    def test_claw_overload_threshold(self):
        u = PAT.new(CLAW, boot=0); u.hb(True, 0)
        u.sensor(1000, 120, 0); u.tick(5, trig=True)
        self.assertEqual(u.g(F_CLAW_PWM), 1850)             # 12.0 g is NOT > 12.0 g
        u.sensor(1000, 121, 5); u.hb(True, 5); u.tick(10, trig=True)
        self.assertEqual(u.g(F_CLAW_PWM), 1150)             # 12.1 g releases

    def test_tof_avoidance_values(self):
        u = PAT.new(CODE, boot=0); u.hb(True, 0)
        for tof, exp in ((350, 0), (349, 0), (340, -2), (200, -30), (0, -70), (1000, 0)):
            u.sensor(tof, 0, 0); u.tick(5)
            self.assertEqual(u.g(F_PITCH_CMD), exp, f"tof={tof}")

    def test_ir_cooldown_rate_limit_across_rollover(self):
        for start in (0, 65400):
            u = PAT.new(LASER, boot=start); u.hb(True, start)
            t = start
            for i in range(1, 201):                          # 1.0 s of 5 ms ticks, trigger held
                t += 5
                if i % 10 == 0:
                    u.hb(True, t)
                u.tick(t, trig=True)
            self.assertEqual(u.g(F_IR_SHOTS), 4, f"start={start}")   # at 5,255,505,755 ms (cooldown 250 ms)

    def test_original_defect_ir_cooldown_aliases_after_65s_idle(self):
        # last shot at t0; 65.636 s later the unsigned elapsed = 100 ms (<250) so the ORIGINAL wrongly blocks a shot.
        o = ORIG.new(LASER, boot=0); o.hb(True, 0)
        o.tick(300, trig=True)                                # first shot
        self.assertEqual(o.g(F_IR_SHOTS), 1)
        o.hb(True, (300 + 65536 + 100) & 0xFFFF)
        o.tick((300 + 65536 + 100) & 0xFFFF, trig=True)
        self.assertEqual(o.g(F_IR_SHOTS), 1, "original should have (wrongly) blocked the shot")

    def test_patched_ir_cooldown_does_not_alias(self):
        p = PAT.new(LASER, boot=0); p.hb(True, 0)
        p.tick(300, trig=True)
        self.assertEqual(p.g(F_IR_SHOTS), 1)
        t = 300
        while t < 300 + 65536 + 100:                          # keep heartbeats alive for the whole idle period
            t += 20
            p.hb(True, t); p.tick(t)
        p.tick(t, trig=True)
        self.assertEqual(p.g(F_IR_SHOTS), 2)

    def test_piezo_buzz_180ms_and_hit_count(self):
        u = PAT.new(LASER, boot=0); u.hb(True, 0)
        u.tick(5, hit=True)
        self.assertEqual(u.g(F_IR_HITS), 1); self.assertEqual(u.g(F_PIEZO), 1)
        u.hb(True, 100); u.tick(184)
        self.assertEqual(u.g(F_PIEZO), 1)                    # 179 ms
        u.tick(185)
        self.assertEqual(u.g(F_PIEZO), 0)                    # 180 ms

    def test_original_defect_stale_tof_sample_keeps_commanding_avoidance(self):
        o = ORIG.new(CODE, boot=0); o.hb(True, 0)
        o.sensor(100, 0, 0)
        for t in range(5, 2000, 5):
            if t % 50 == 0:
                o.hb(True, t)
            o.tick(t)
        self.assertLess(o.g(F_PITCH_CMD), 0)                 # frozen 100 mm sample still driving pitch-back at 2 s

    def test_patched_stale_sensor_zeroes_avoidance_and_holds_claw_neutral(self):
        p = PAT.new(CODE, boot=0); p.hb(True, 0)
        p.sensor(100, 0, 0)
        p.tick(100)
        self.assertLess(p.g(F_PITCH_CMD), 0)
        p.hb(True, 290); p.tick(300)                         # 300 ms since last sensor sample -> stale
        self.assertEqual(p.g(F_PITCH_CMD), 0)
        self.assertEqual(p.g(F_SENSOR_STALE), 1)
        c = PAT.new(CLAW, boot=0); c.hb(True, 0); c.sensor(1000, 0, 0)
        c.tick(100, trig=True); self.assertEqual(c.g(F_CLAW_PWM), 1850)
        c.hb(True, 290); c.tick(300, trig=True)
        self.assertEqual(c.g(F_CLAW_PWM), 1500)


@needs_cc
class Telemetry(unittest.TestCase):
    def _state(self, b):
        u = b.new(LASER, boot=0); u.hb(True, 0)
        u.sensor(321, 0, 0)
        u.tick(5, trig=True, hit=True)
        return u

    def test_original_defect_struct_crc_not_verifiable_on_documented_payload(self):
        o = self._state(ORIG)
        raw = ctypes.create_string_buffer(64)
        size = ORIG.L.h_pkt_raw(o.h, raw, 64)
        crc_off = ORIG.L.h_pkt_crc_offset()
        self.assertGreater(size, 10, "struct has padding beyond the 10 documented bytes")
        self.assertEqual(crc_off, 10)
        # documented payload = sync,payload,flags,tof(2),hits,shots,claw(2) -> 9 bytes. Original CRC is over (size-1) raw bytes.
        payload9 = bytes([raw.raw[0], raw.raw[1], raw.raw[2], raw.raw[4], raw.raw[5], raw.raw[6], raw.raw[7],
                          raw.raw[8], raw.raw[9]])
        self.assertNotEqual(ORIG.L.h_pkt_crc(o.h), crc8_dvb_s2(payload9))
        # the original's covered range (size-1 bytes) includes its own crc8 field and compiler padding:
        self.assertGreaterEqual(size - 1, crc_off + 1)

    def test_patched_wire_frame_layout_and_crc(self):
        p = self._state(PAT)
        buf = ctypes.create_string_buffer(16)
        n = PAT.L.h_wire(p.h, buf)
        self.assertEqual(n, 10)
        w = buf.raw[:10]
        self.assertEqual(w[0], 0xA5)
        self.assertEqual(w[1], LASER)
        self.assertEqual(w[3] | (w[4] << 8), 321)
        self.assertEqual(w[5], 1)                             # hit
        self.assertEqual(w[6], 1)                             # shot
        self.assertEqual(w[7] | (w[8] << 8), 1500)
        self.assertEqual(w[9], crc8_dvb_s2(w[:9]))
        self.assertEqual(PAT.L.h_pkt_crc(p.h), w[9])
        self.assertEqual(w[2] & 0x01, 0x01)                   # armed flag
        self.assertEqual(w[2] & 0x04, 0x04)                   # ir_fire flag

    def test_patched_failsafe_flag_in_wire_frame(self):
        u = PAT.new(CLAW, boot=0); u.hb(True, 0); u.tick(500)
        buf = ctypes.create_string_buffer(16); PAT.L.h_wire(u.h, buf)
        self.assertEqual(buf.raw[2] & 0x02, 0x02)
        self.assertEqual(buf.raw[2] & 0x01, 0x00)
        self.assertEqual(buf.raw[9], crc8_dvb_s2(buf.raw[:9]))


if __name__ == "__main__":
    print(f"original : {ORIGINAL}")
    print(f"patched  : {PATCHED}")
    print(f"compiler : {COMPILER}  built={'yes' if PAT and ORIG else 'NO (' + str(_BUILD_ERR) + ')'}")
    res = unittest.main(exit=False, verbosity=2)
    if _TMP:
        shutil.rmtree(_TMP, ignore_errors=True)
    sys.exit(0 if res.result.wasSuccessful() else 1)
