﻿#!/usr/bin/env python3
"""
Workspace firmware static triage (READ-ONLY on the workspace; writes only next to this script).

Scope : every .c/.h/.cpp/.ino/.lua file and every avionics-style .py under 03_Hardware_and_Drones and "AI Security Drone/"
        (build_*/generate_*/test_* generators and OpenSCAD/CAD scripts are excluded).
Method: regex heuristics - NOT a proof. Each file gets indicators for
          WD   = watchdog / failsafe / timeout / link-loss logic present
          ARM  = armed / disarmed interlock logic present
          ROLL = rollover-safe idiom present (uint16_t cast subtraction, & 0xFFFF, % 65536, ticks_diff, signed-diff)
          RISK = lines that look like absolute-deadline or unmasked elapsed compares (rollover hazard)
        and a triage verdict:
          OK       WD+ARM+ROLL present, no RISK lines
          REVIEW   something missing or RISK lines found -> a human must read it
          N/A      no actuator/failsafe logic detected (pure math / CAD / UI)
Also parses the Betaflight CLI dumps for CUB-75 and SHARD-75/KODIAK-75 (failsafe, arm switch, runaway, LVC).
Findings that were confirmed by reading code are tracked in FINDINGS (hand-curated; see firmware_safety_audit.md).
"""
import csv
import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
HW = ROOT / "03_Hardware_and_Drones"

EXCLUDE_DIR_PARTS = {"__pycache__", "node_modules", ".git", "gerbers"}
EXCLUDE_NAME = re.compile(r"^(build_|generate_|test_|compile_|render_|verify_|run_|audit_)", re.I)
PY_AVIONICS_NAME = re.compile(
    r"(avionics|firmware|controller|autopilot|state_machine|_sim\.py|fadec|fire_control|mission|suction|coordinator|tracker)", re.I)

WD = re.compile(r"watchdog|failsafe|fail_safe|link[_ ]?loss|rx[_ ]?loss|heartbeat|timeout", re.I)
ARM = re.compile(r"\bis_armed\b|\barmed\b|disarm|arming\s*:", re.I)
ROLL = re.compile(r"\(uint16_t\)\s*\(|\(uint32_t\)\s*\(|&\s*0xFFFF\b|&\s*0xFFFFFFFF|%\s*65536|%\s*\(?1\s*<<\s*16|ticks_diff|"
                  r"\(int16_t\)\s*\(|rollover|wrap-?around|wraparound", re.I)
# Hazard patterns (rollover-unsafe): absolute deadline compare, or raw elapsed compare with no mask/cast on the same line.
RISK_PATTERNS = [
    (re.compile(r"(millis\(\)|now\w*|current_time\w*|time_ms\w*|tick\w*)\s*(>=|>)\s*\w*(last|prev|start|deadline|expire)\w*\s*\+", re.I),
     "absolute-deadline compare (now >= last + X) breaks at wrap"),
    (re.compile(r"\w*(last|prev|start|deadline|expire)\w*\s*\+\s*[\w.]+\s*(<=|<)\s*(millis\(\)|now\w*|current_time\w*)", re.I),
     "absolute-deadline compare (last + X < now) breaks at wrap"),
]
PY_ELAPSED = re.compile(r"(now\w*|current\w*|t_ms|time_ms)\s*-\s*[\w.\[\]]*(last|prev)\w*[\w.\[\]]*\s*(>=|>|<=|<)", re.I)
PY_MASK = re.compile(r"&\s*0xFFFF|%\s*65536|\(1\s*<<\s*16\)|u16|wrap", re.I)


def want(path: Path) -> bool:
    if any(p in EXCLUDE_DIR_PARTS for p in path.parts) or HERE in path.parents:
        return False
    ext = path.suffix.lower()
    if ext in {".c", ".h", ".cpp", ".hpp", ".ino", ".lua"}:
        return True
    if ext == ".py":
        if EXCLUDE_NAME.match(path.name):
            return False
        return bool(PY_AVIONICS_NAME.search(path.name) or "firmware" in {p.lower() for p in path.parts})
    return False


def scan_file(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()
    wd = bool(WD.search(text))
    arm = bool(ARM.search(text))
    roll = bool(ROLL.search(text))
    risks = []
    is_py = path.suffix.lower() == ".py"
    for i, ln in enumerate(lines, 1):
        code = ln.split("//")[0] if not is_py else ln.split("#")[0]
        if path.suffix.lower() == ".lua":
            code = ln.split("--")[0]
        for rx, why in RISK_PATTERNS:
            if rx.search(code):
                risks.append((i, why, ln.strip()[:140]))
        if is_py and PY_ELAPSED.search(code) and not PY_MASK.search(code):
            risks.append((i, "unmasked elapsed compare in Python (fine for float seconds; hazard if emulating a 16-bit ms counter)", ln.strip()[:140]))
    if not (wd or arm):
        verdict = "N/A"
    elif wd and arm and roll and not risks:
        verdict = "OK"
    else:
        verdict = "REVIEW"
    lua_syntax = None
    if path.suffix.lower() == ".lua":
        try:
            import lupa
            lua = lupa.LuaRuntime()
            ok, err = lua.eval("function(s) local f, e = load(s, 'chunk'); return (f ~= nil), e end")(text)
            lua_syntax = "OK" if ok else f"ERROR: {err}"
        except ImportError:
            lua_syntax = "not checked (pip install lupa)"
    missing = [n for n, v in (("watchdog", wd), ("armed-interlock", arm), ("rollover-idiom", roll)) if not v]
    return {
        "file": str(path.relative_to(ROOT)).replace("\\", "/"),
        "lang": path.suffix.lower().lstrip("."),
        "lines": len(lines),
        "WD": wd, "ARM": arm, "ROLL": roll,
        "risk_lines": len(risks),
        "risk_detail": [{"line": a, "why": b, "text": c} for a, b, c in risks[:6]],
        "missing": missing,
        "verdict": verdict,
        "lua_syntax": lua_syntax,
    }


# ----------------------------------------------------------------------------------------------------------------------
def parse_cli(path: Path):
    cfg, aux, feats = {}, [], set()
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^set\s+(\w+)\s*=\s*(.+)$", line)
        if m:
            cfg.setdefault(m.group(1), m.group(2).strip())     # first (global) value wins
        elif line.startswith("aux "):
            aux.append(line)
        elif line.startswith("feature "):
            feats.add(line.split(None, 1)[1])
    return cfg, aux, feats


CLI_TARGETS = [
    ("CUB-75 Kids Trainer", HW / "Core_Fleet/Kids Training Drone/firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt"),
    ("CUB-75 STEM Kit (custom FC)", HW / "Core_Fleet/Kids Training Drone/CUB75_30Min_QuickBuild_STEM_Kit/custom_fc_and_elrs/CUB75_STEM_Kit_Betaflight45_CLI.txt"),
    ("SHARD-75/KODIAK-75 Full Bumper-Tag", HW / "Active_Subprojects/Bumper Drones/firmware/KODIAK75_Betaflight45_Full_BumperTag.txt"),
    ("SHARD-75/KODIAK-75 Arena", HW / "Active_Subprojects/Bumper Drones/firmware/KODIAK75_betaflight_cli.txt"),
]


def cli_checks():
    rows = []
    for label, p in CLI_TARGETS:
        if not p.exists():
            rows.append({"target": label, "file": str(p.relative_to(ROOT)), "exists": False})
            continue
        cfg, aux, feats = parse_cli(p)
        txt = p.read_text(encoding="utf-8", errors="replace")
        has_defaults = bool(re.search(r"^defaults", txt, re.M))
        arm_aux = [a for a in aux if re.match(r"aux\s+\d+\s+0\s+", a)]
        def iv(k, d=None):
            try:
                return int(cfg.get(k, d))
            except Exception:
                return d
        fd, fp = iv("failsafe_delay"), cfg.get("failsafe_procedure")
        checks = {
            "failsafe_procedure_DROP": fp == "DROP",
            "failsafe_delay_1_to_5": fd is not None and 1 <= fd <= 5,
            "arm_switch_aux_mode0": bool(arm_aux),
            "runaway_takeoff_prevention_ON": cfg.get("runaway_takeoff_prevention") == "ON",
            "small_angle_le_30_or_BF_default_25": (iv("small_angle") is None and has_defaults) or (iv("small_angle") or 999) <= 30,
            "vbat_min_cell_320_335": (iv("vbat_min_cell_voltage") or 0) in range(320, 336),
            "vbat_max_cell_le_445": (iv("vbat_max_cell_voltage") or 999) <= 445,
            "vtx_low_power_disarm_ON": cfg.get("vtx_low_power_disarm") == "ON",
        }
        notes = []
        if iv("small_angle") is None:
            notes.append("small_angle not set explicitly -> relies on Betaflight default (25 deg) [VERIFY on bench]" + ("" if has_defaults else "; file has no `defaults` line, so any prior FC value persists"))
        if re.search(r"^feature MOTOR_STOP", txt, re.M) and re.search(r"^feature -MOTOR_STOP", txt, re.M):
            notes.append("MOTOR_STOP enabled then disabled in same file (net OFF) - intentional? [VERIFY]")
        if "feature AIRMODE" in txt:
            notes.append("uses 'feature AIRMODE' - [VERIFY] accepted by Betaflight 4.5 CLI (airmode is normally a flight mode)")
        rows.append({
            "target": label, "file": str(p.relative_to(ROOT)).replace("\\", "/"), "exists": True,
            "failsafe_delay": fd, "failsafe_procedure": fp, "arm_aux": arm_aux[:1], "checks": checks,
            "all_pass": all(checks.values()), "notes": notes,
        })
    return rows


# Hand-curated findings (each confirmed by reading code and, for #1-#6, by executing original vs patched in test_snapdeck_patched.py)
FINDINGS = [
    ("F-01", "HIGH", "gen2_snapdeck_firmware.cpp::on_fc_heartbeat", "Failsafe latch bypass: armed heartbeat after Stage-2 trip re-enables motor/claw/IR outputs.", "PATCHED (P1-1); reproduced by test"),
    ("F-02", "MED", "gen2_snapdeck_firmware.cpp::update_snapdeck_tick", "(uint16_t)(now-last) turns a heartbeat stamped after the tick's 'now' into 65535 ms -> spurious Stage-2 DROP (motor kill in flight). Conditional: only if the heartbeat is stamped from an ISR/other task - the UART architecture is not in the repo.", "PATCHED (P1-2); reproduced by test"),
    ("F-03", "MED", "gen2_snapdeck_firmware.cpp::build_telemetry_packet", "CRC-8 computed over raw struct bytes incl. padding and its own crc8 field; not verifiable against the documented 9-byte payload.", "PATCHED (P1-4); reproduced by test"),
    ("F-04", "MED", "gen2_snapdeck_firmware.cpp (ToF/claw load)", "No sensor age check: a stalled feed freezes last ToF/claw value and keeps commanding pitch-back.", "PATCHED (P1-5); reproduced by test"),
    ("F-05", "LOW", "gen2_snapdeck_firmware.cpp::has_elapsed_u16 (IR cooldown)", "Unsigned elapsed aliases after 65.536 s idle and can wrongly block a shot up to 250 ms.", "PATCHED (P1-6); reproduced by test"),
    ("F-06", "LOW", "gen2_snapdeck_firmware.cpp (interlock)", "Magic numbers 1500/1000/1250 in interlock instead of named constants.", "PATCHED (P1-7)"),
    ("F-07", "VERIFY", "gen2_snapdeck_firmware.cpp (armed baseline)", "Companion sets motor_pwm_us = 1250 when armed. Betaflight FC should own motors; confirm this is status-only.", "OPEN - CTO decision"),
    ("F-08", "VERIFY", "UART2 heartbeat parser (not in repo)", "Inbound FC heartbeat frame has no CRC/sequence check in the audited file; parser source not found.", "OPEN - locate/author parser + test"),
    ("F-09", "MED", "Core_Fleet/2026-10-31_CUB75_and_SHARD75_Gen2_Modular_Upgrades/test_gen2_snapdeck_safety.py", "Existing '40-check' suite validates a Python re-implementation and greps the C++ text; it never compiles or runs the firmware, so F-01..F-05 passed unnoticed.", "Addressed by test_snapdeck_patched.py (compiles + executes)"),
    ("F-10", "LOW", "Kids Training Drone/firmware/CUB75_Betaflight45_Kids_Trainer_CLI.txt", "Header comments say 20 deg/65%/78%/90% but profiles set 22/68, 35/80, 50/92 (PRD agrees with the profiles). Documentation drift only.", "OPEN - fix comments in a v2 CLI"),
    ("F-11", "VERIFY", "CLI files", "'feature AIRMODE' appears in CUB-75 CLI; confirm Betaflight 4.5 Configurator accepts it (paste into CLI on a bench FC, no props).", "OPEN - bench check"),
]


def main():
    files = sorted(p for p in list(HW.rglob("*")) + list((ROOT / "AI Security Drone").rglob("*")) if p.is_file() and want(p))
    results = [scan_file(p) for p in files]
    # collapse byte-identical duplicates (the three AI-Security Lua copies)
    summary = {k: sum(1 for r in results if r["verdict"] == k) for k in ("OK", "REVIEW", "N/A")}
    cli = cli_checks()
    out = {"scanned_files": len(results), "summary": summary, "files": results, "betaflight_cli": cli,
           "findings": [dict(zip(("id", "severity", "where", "issue", "status"), f)) for f in FINDINGS]}
    (HERE / "firmware_static_audit_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    with (HERE / "firmware_static_audit_results.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["file", "lang", "lines", "watchdog", "armed_interlock", "rollover_idiom", "risk_lines", "missing", "verdict"])
        for r in results:
            w.writerow([r["file"], r["lang"], r["lines"], r["WD"], r["ARM"], r["ROLL"], r["risk_lines"], ";".join(r["missing"]), r["verdict"]])
    print(f"Scanned {len(results)} firmware-like files -> OK={summary['OK']} REVIEW={summary['REVIEW']} N/A={summary['N/A']}")
    print("\nBetaflight CLI (core fleet):")
    for c in cli:
        if not c.get("exists"):
            print(f"  MISSING {c['file']}")
            continue
        fails = [k for k, v in c["checks"].items() if not v]
        print(f"  {'PASS' if c['all_pass'] else 'FAIL'}  {c['target']}: failsafe_delay={c['failsafe_delay']} proc={c['failsafe_procedure']} fails={fails} {c['notes']}")
    print("\nREVIEW list (top 40):")
    for r in [r for r in results if r["verdict"] == "REVIEW"][:40]:
        print(f"  {r['file']}  missing={r['missing']} risk_lines={r['risk_lines']}" + (f" lua_syntax={r['lua_syntax']}" if r["lua_syntax"] else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())




