#!/usr/bin/env python3
"""
Mutation check: proves the unit tests can actually FAIL. Each mutation re-introduces one original defect (or removes a
safety property) in a temp copy of the patched firmware; the compiled test-suite must then report failures.
Writes mutation_check_results.json next to this file. Does not modify any firmware file.
"""
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = (HERE / "gen2_snapdeck_firmware_patched.cpp").read_text(encoding="utf-8")

MUTATIONS = [
    ("M1 latch bypass (copy armed flag while latched)",
     "        state.is_armed = false;\n        if (!fc_armed_flag) {",
     "        state.is_armed = fc_armed_flag;\n        if (!fc_armed_flag) {"),
    ("M2 unsigned elapsed (re-introduce future-stamp race)",
     "    return (delta >= 0) && ((uint16_t)delta >= threshold_ms);",
     "    return (uint16_t)(now_ms - last_ms) >= threshold_ms;"),
    ("M3 watchdog not latched in tick (layer 2 removed; layer 1 still protects, so only the static marker test kills it)",
     "    if (state.failsafe_active ||\n        has_elapsed_u16(now_ms, state.last_fc_heartbeat_ms, WATCHDOG_TIMEOUT_MS)) {",
     "    if (has_elapsed_u16(now_ms, state.last_fc_heartbeat_ms, WATCHDOG_TIMEOUT_MS)) {"),
    ("M8 BOTH latch layers removed (heartbeat copies armed flag AND tick does not re-assert)",
     None, None),
    ("M4 disarmed branch leaves IR cannon enabled",
     "    if (!state.is_armed) {\n        apply_disarmed_outputs(state);\n        return;",
     "    if (!state.is_armed) {\n        apply_disarmed_outputs(state);\n        state.ir_fire_enable = state.ir_fire_enable;\n        state.claw_pwm_us = PWM_SERVO_GRIP_CLOSED_US;\n        return;"),
    ("M5 watchdog timeout 400 -> 4000 ms",
     "WATCHDOG_TIMEOUT_MS       = 400U;", "WATCHDOG_TIMEOUT_MS       = 4000U;"),
    ("M6 CRC over struct memory again (crc byte included)",
     "    out[9] = compute_crc8_dvb_s2(out, (uint8_t)(TELEMETRY_WIRE_LEN - 1U));",
     "    out[9] = 0; out[9] = compute_crc8_dvb_s2(out, (uint8_t)(TELEMETRY_WIRE_LEN));"),
    ("M7 sensor staleness ignored",
     "(state.detected_payload == PayloadType::SNAP_CODE || state.detected_payload == PayloadType::SNAP_CLAW) &&\n        has_elapsed_u16(now_ms, state.last_sensor_ms, SENSOR_STALE_MS);",
     "false;"),
]

results = []
for name, old, new in MUTATIONS:
    if old is None:   # M8: compose M1 + M3 on the same copy
        m1, m3 = MUTATIONS[0], MUTATIONS[2]
        if m1[1] not in SRC or m3[1] not in SRC:
            results.append({"mutation": name, "status": "NOT_APPLIED (pattern missing)", "killed": False})
            continue
        mutated = SRC.replace(m1[1], m1[2], 1).replace(m3[1], m3[2], 1)
    elif old not in SRC:
        results.append({"mutation": name, "status": "NOT_APPLIED (pattern missing)", "killed": False})
        continue
    else:
        mutated = SRC.replace(old, new, 1)
    with tempfile.TemporaryDirectory() as td:
        mfile = Path(td) / "mutant.cpp"
        mfile.write_text(mutated, encoding="utf-8")
        env = dict(os.environ, SNAPDECK_FW_UNDER_TEST=str(mfile), PYTHONDONTWRITEBYTECODE="1")
        p = subprocess.run([sys.executable, str(HERE / "test_snapdeck_patched.py")], env=env, capture_output=True, text=True)
        out = p.stdout + p.stderr
        failed = sorted(set(re.findall(r"^(?:FAIL|ERROR): (\w+)", out, re.M)))
        results.append({"mutation": name, "killed": p.returncode != 0, "failing_tests": failed})

killed = sum(1 for r in results if r["killed"])
print(f"Mutants killed: {killed}/{len(results)}")
for r in results:
    print(("  KILLED   " if r["killed"] else "  SURVIVED ") + r["mutation"] + (f"  <- {', '.join(r.get('failing_tests', []))}" if r.get("failing_tests") else ""))
(HERE / "mutation_check_results.json").write_text(json.dumps({"killed": killed, "total": len(results), "results": results}, indent=2), encoding="utf-8")
sys.exit(0 if killed == len(results) else 1)
