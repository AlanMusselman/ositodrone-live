﻿#!/usr/bin/env python3
"""Builds Firmware_Safety_Audit_CUB75_SHARD75.docx from FRESH runs of the tests, mutation check and static audit."""
import json
import os
import re
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import docx_kit as K  # noqa: E402

ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(script):
    p = subprocess.run([sys.executable, str(HERE / script)], capture_output=True, text=True, env=ENV, cwd=str(HERE))
    return p.returncode, p.stdout + p.stderr


def main():
    rc_t, out_t = run("test_snapdeck_patched.py")
    m = re.search(r"Ran (\d+) tests", out_t)
    n_tests = int(m.group(1)) if m else 0
    exp_fail = re.search(r"expected failures=(\d+)", out_t)
    exp_fail = int(exp_fail.group(1)) if exp_fail else 0
    skipped = re.search(r"skipped=(\d+)", out_t)
    skipped = int(skipped.group(1)) if skipped else 0
    rc_m, out_m = run("mutation_check.py")
    mut = json.loads((HERE / "mutation_check_results.json").read_text(encoding="utf-8"))
    rc_s, out_s = run("firmware_static_audit.py")
    st = json.loads((HERE / "firmware_static_audit_results.json").read_text(encoding="utf-8"))
    assert rc_t == 0 and rc_m == 0 and rc_s == 0, "a verification run failed - fix before building the report"
    assert skipped == 0, "compiled tests were skipped - report would overstate verification"

    doc = K.new_doc(landscape=True)
    K.banner(doc, "Firmware Safety Audit - CUB-75 / SHARD-75 Companion Firmware",
             "Failsafe watchdogs - disarmed interlocks - 16-bit millisecond rollover | Patched COPY + executable tests | for Jesus Aceves (CTO)",
             "Osito Drone LLC - 2026-10-31 - host-side verification only: NO hardware-in-the-loop, NO bench, NO flight testing performed")

    K.callout(doc, "BOTTOM LINE",
              f"The Gen-2 Snap-Deck companion firmware (gen2_snapdeck_firmware.cpp) contained 1 HIGH, 3 MEDIUM and 2 LOW code-level issues (plus 4 open [VERIFY] items) that the existing 40/40 'safety suite' could not see, "
              f"because that suite re-implements the logic in Python and greps the C++ text. This audit compiles and executes the real C++ (Zig/clang, host x86-64) in {n_tests} unit tests. "
              f"A patched copy (rev P1) fixes every code-level finding; the original file is untouched. {mut['killed']}/{mut['total']} deliberately broken mutants were caught by the tests. "
              "The patched copy is NOT flight-approved: it still needs target-MCU compile, UART/ISR timing review, bench failsafe pull-tests and a flight test under the release checklist.")

    K.h1(doc, "1. Findings")
    sev_status = {"HIGH": "FAIL", "MED": "FAIL", "LOW": "WARN", "VERIFY": "VERIFY"}
    rows = []
    for f in st["findings"]:
        stat = f["status"]
        status = "FIXED" if stat.startswith("PATCHED") or stat.startswith("Addressed") else ("OPEN" if stat.startswith("OPEN") else "INFO")
        rows.append([f["id"], f["severity"], f["where"], f["issue"], f"{status}: {stat}"])
    K.table(doc, ["ID", "Severity", "Where", "Issue", "Status"], rows, widths=[0.5, 0.7, 3.0, 5.0, 2.2], size=7.5, status_col=4)

    K.h1(doc, "2. What the patch changes (gen2_snapdeck_firmware_patched.cpp, rev P1)")
    K.table(doc, ["Patch", "Before (original)", "After (patched copy)", "Proof"], [
        ["P1-1 latch", "on_fc_heartbeat copied the FC 'armed' flag into is_armed while failsafe_active was latched -> motors/claw/IR re-enabled by one armed heartbeat.", "While latched is_armed is forced false; latch clears only on a DISARMED heartbeat.", "LatchBypass tests: original shows motor 1250 / claw 1850 after trip; patched stays 1000/1500 for 29 heartbeats x 4 payloads."],
        ["P1-2 future stamp", "(uint16_t)(now - last) >= 400: heartbeat stamped 1 ms after the tick's 'now' becomes 65535 ms -> false Stage-2 DROP.", "Signed 16-bit modular difference; stamp ahead of now = 0 ms elapsed; static_assert threshold < 32768.", "Watchdog tests: original expected-failure reproduces; patched ahead = 1/2/5/50 ms never trips."],
        ["P1-3 latch in tick", "Trip state not sticky.", "Tick re-asserts failsafe outputs while latched; survives >65.5 s of silence across a full 16-bit wrap.", "test_patched_failsafe_stays_latched_across_full_16bit_wrap (90 s)."],
        ["P1-4 CRC", "CRC-8 over (sizeof(struct)-1) raw bytes incl. padding byte and the crc8 field itself (struct size 12, crc at offset 10).", "Explicit 10-byte little-endian wire frame; CRC-8/DVB-S2 over 9 payload bytes; checked against an independent Python CRC (standard check value 0xBC).", "Telemetry tests."],
        ["P1-5 stale sensors", "No age on ToF / claw-load; stalled feed froze last value (kept commanding pitch-back).", "on_sensor_update() stamps; >250 ms stale -> avoidance 0, claw neutral, status bit 0x10.", "PayloadLogic tests. NOTE bit 0x10 is new: receivers must ignore unknown bits [VERIFY]."],
        ["P1-6 IR cooldown", "Unsigned elapsed aliased after 65.5 s idle and blocked a shot for up to 250 ms.", "Explicit cooldown-active flag.", "Original reproduces; patched fires."],
        ["P1-7 constants", "Interlock used literals 1500/1000/1250.", "Named constants; one shared safe-output function.", "Static marker test."],
    ], widths=[0.9, 3.4, 3.4, 3.4], size=7.5)

    K.h1(doc, "3. Test evidence (re-run when this report was built)")
    K.table(doc, ["Check", "Result", "Command"], [
        ["Compiled unit tests (original + patched DLLs, ctypes)", f"{n_tests} tests, 0 failures, {exp_fail} expected failure (documents original defect F-02), {skipped} skipped -> PASS", "python firmware_safety/test_snapdeck_patched.py"],
        ["Mutation check (7 mutants + 1 composite)", f"{mut['killed']}/{mut['total']} killed -> PASS. M3 (layer-2 latch) is behaviourally masked by layer 1 by design and is caught by the source-marker test only.", "python firmware_safety/mutation_check.py"],
        ["Static triage of firmware-like files", f"{st['scanned_files']} files: OK={st['summary']['OK']} REVIEW={st['summary']['REVIEW']} N/A={st['summary']['N/A']} (heuristic, not proof)", "python firmware_safety/firmware_static_audit.py"],
        ["Lua syntax (lupa / Lua 5.5 parser)", "all scanned .lua files parse: " + ("PASS" if all((r.get('lua_syntax') in (None, 'OK')) for r in st['files']) else "FAIL"), "same script"],
        ["Existing suite test_gen2_snapdeck_safety.py (baseline)", "40/40 PASS - but does not execute the C++; it passed with F-01..F-05 present", "unchanged"],
    ], widths=[3.4, 5.2, 2.8], size=8)
    K.para(doc, "Tests cover: signed/unsigned elapsed maths at 65535->0 boundaries, 400 ms trip to the millisecond (incl. across the wrap), nominal 20 Hz heartbeat across the wrap, "
                "latch bypass, 90 s silence latch, disarmed interlock for all 4 payload types with trigger/hit/overload/wall inputs, claw 12.0 g vs 12.1 g threshold, ToF avoidance values, "
                "IR 4 shots/s limit across rollover, 180 ms piezo, stale sensors, wire frame layout and CRC. The compiler is the Zig 0.16 clang front-end from `pip install ziglang`; "
                "target MCU compile (ESP32-S3 / Betaflight-side) is not covered [VERIFY].", size=8.5, color=K.MUTED)

    K.h1(doc, "4. Betaflight CLI checks (core fleet)")
    crow = []
    for c in st["betaflight_cli"]:
        if not c.get("exists"):
            continue
        fails = [k for k, v in c["checks"].items() if not v]
        status = "PASS" if c["all_pass"] and not c["notes"] else ("WARN" if c["all_pass"] else "FAIL")
        crow.append([c["target"], f"DROP / {c['failsafe_delay']} (={c['failsafe_delay']*0.1:.1f} s)", "yes" if c["checks"]["arm_switch_aux_mode0"] else "NO",
                     "ON" if c["checks"]["runaway_takeoff_prevention_ON"] else "OFF", "; ".join(fails) or "-", "; ".join(c["notes"]) or "-", status])
    K.table(doc, ["Target", "failsafe_procedure / delay", "ARM aux", "runaway prevention", "Failed checks", "Notes", "Result"], crow,
            widths=[2.2, 1.4, 0.6, 0.8, 1.6, 4.0, 0.7], size=7.5, status_col=6)
    K.para(doc, "Config files were parsed only; nothing was flashed or pasted into a flight controller. 'feature AIRMODE' and the small_angle default need a bench check in Betaflight 4.5 Configurator [VERIFY].", size=8.5, color=K.MUTED)

    K.h1(doc, "5. Triage of the other firmware-like files (REVIEW list)")
    groups = {"Core fleet / release scope": [], "AI Security Drone (3 byte-identical Lua copies x 3 folders)": [], "smart_disc_golf (active subproject)": [], "RnD_Concepts_Archive (parked)": []}
    seen_lua = set()
    for r in st["files"]:
        if r["verdict"] != "REVIEW":
            continue
        f = r["file"]
        key = ("RnD_Concepts_Archive (parked)" if "RnD_Concepts_Archive" in f else
               "smart_disc_golf (active subproject)" if "smart_disc_golf" in f else
               "AI Security Drone (3 byte-identical Lua copies x 3 folders)" if ("AI_Security_Drone" in f or "AI Security Drone" in f or "OSITO_INT_95" in f) else
               "Core fleet / release scope")
        if key.startswith("AI Security"):
            name = f.split("/")[-1]
            if name in seen_lua:
                continue
            seen_lua.add(name)
        groups[key].append([f.split("/")[-1], ", ".join(r["missing"]) or "-", r["risk_lines"], r.get("lua_syntax") or "-"])
    for g, rows in groups.items():
        if g.startswith("Core fleet") and not rows:
            K.para(doc, "Core fleet / release scope: no additional REVIEW files (the Gen-2 firmware itself was reviewed manually; see sections 1-3).", size=8.5)
            continue
        K.h2(doc, g)
        K.table(doc, ["File", "Indicators not found", "Risk lines", "Lua syntax"], rows, widths=[4, 3.5, 0.8, 1.2], size=7.5)
    K.callout(doc, "MANUAL NOTES ON THE REVIEW ITEMS",
              "AI Security Drone osito_corner_intercept.lua: gates all motion on vehicle:get_mode() == 4 (GUIDED) and has a 500 ms target-telemetry hover failsafe, but no explicit arming:is_armed() check and its elapsed math "
              "(now_ms - last_target_time_ms) relies on ArduPilot's uint32 millis() userdata semantics - confirm in SITL before any flight [VERIFY]. walk_to_fly*.lua correctly refuses to record while armed. "
              "smart_disc_golf headers are declarations only (logic lives in the .c files, which the fleet audit already checks). RnD archive items (HiveMind STM32 dock FSM, Ursus250, SmartFlyer) lack a detected watchdog "
              "or rollover idiom - they are parked concepts and were deliberately NOT patched (see R&D parking note).")

    K.h1(doc, "6. Limits of this audit")
    K.bullets(doc, [
        "Host x86-64 execution of the logic only. No UART, ISR, RTOS tick jitter, EEPROM, motor, ESC or RF behaviour was exercised.",
        "The inbound FC-heartbeat parser (serial framing, CRC/sequence) is not in the workspace; F-08 stays open.",
        "Static triage is regex-based; a clean verdict is a hint, not a proof. Only the Gen-2 firmware received line-by-line review and execution.",
        "Other subproject simulators were not re-run in this audit (the existing fleet audit already runs them); running that audit regenerates PCB artefacts, so it was deliberately not re-run in place.",
        "Any claim about flight behaviour (e.g. 'DROP is safe in a classroom') requires the bench and flight checks on the release checklist.",
    ], size=9)
    K.footer(doc, "Osito Drone LLC - internal engineering document - generated by build_firmware_audit_docx.py - 2026-10-31")
    out = HERE / "Firmware_Safety_Audit_CUB75_SHARD75.docx"
    doc.save(out)
    print("wrote", out, f"tests={n_tests} exp_fail={exp_fail} mutants={mut['killed']}/{mut['total']}")


if __name__ == "__main__":
    main()

