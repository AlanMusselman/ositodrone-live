# OSITO THERMO-95: Shop Build, Cross-Polarizer Alignment & Calibration Guide

**System Designation:** `OSITO THERMO-95` (*95mm 2S Sub-250g Dual-Spectrum Radiometric Thermal & Attic/Rooftop HVAC Inspection Cinewhoop*)  
**Target Assembly Time:** `75 Minutes` (Workbench Solder, Mechanical Integration, Optical/Thermal Boresighting & QA Sign-Off)

---

## 1. Required Shop Tools, Consumables & Printed Fixtures

Before beginning assembly, print the full 8-part CAD suite in [`cad/`](./cad/) and stage these tools on an ESD-safe workbench:
* **3D-Printed Shop Fixtures:**
  * [`THERMO95_Bench_Prop_and_Gimbal_Jig.stl`](./cad/THERMO95_Bench_Prop_and_Gimbal_Jig.stl) — Supports `1204` motor bells during prop installation and provides precision `-90°`, `0°`, and `+60°` angle stops for gimbal calibration.
  * [`THERMO95_Lens_Dust_Cap_and_Cal_Target.stl`](./cad/THERMO95_Lens_Dust_Cap_and_Cal_Target.stl) — Clips onto a standard `30.0 cm` metric shop ruler (or `300 mm` carbon rod) to align thermal/visual parallax and cross-polarizer extinction.
* **Workbench Tools:** Temperature-controlled soldering iron (`370°C / 700°F` chisel tip), `63/37` rosin-core solder, no-clean flux pen, `1.5 mm` & `2.0 mm` hex drivers, ceramic tweezers, digital multimeter, `2S` smoke stopper (`1.0A` trip threshold), and a `0.01 g` precision pocket scale.
* **Environmental Protection Consumables:** `MG Chemicals 422C` Silicone Conformal Coating (with UV trace indicator), `3M VHB` double-sided foam tape, `Loctite 222` (Purple low-strength threadlocker), and `0.4 mm` adhesive silicone sheet for the `N42` perch magnets.

---

## 2. Step-by-Step Workbench Assembly & Soldering Procedure

### Step 1: FDM Print Inspection & Post-Processing (`10 Mins`)
1. Inspect [`THERMO95_Frame_95mm_Ducted.stl`](./cad/THERMO95_Frame_95mm_Ducted.stl) (`PA12-CF` or `PC-CF`) and verify that all four `53.5 mm` ID ducts are free of stringing and measure `53.50 ± 0.15 mm` across two orthogonal diameters.
2. Verify that the four `25.5 × 25.5 mm` M2 flight controller standoffs sit flush and clear. Run a `2.0 mm` hand reamer through the gimbal trunnion holes on [`THERMO95_Attic_Truss_RollCage.stl`](./cad/THERMO95_Attic_Truss_RollCage.stl) and [`THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl) so the pod pivots with zero friction.
3. If building [`THERMO95_Magnetic_RTU_Perch_Skids.stl`](./cad/THERMO95_Magnetic_RTU_Perch_Skids.stl), press four `8.0 × 2.0 mm` `N42` neodymium magnets into the bottom pockets with alternating `N-S-N-S` polarity using cyanoacrylate adhesive, then apply the `0.4 mm` high-friction silicone rubber boots over each magnet face so the skids never scratch painted HVAC sheet metal or slide vertically on galvanized ductwork.

### Step 2: AIO Flight Controller Pre-Tinning, Pigtail & Peripheral Soldering (`20 Mins`)
Mount the **`JHEMCU GHF411AIO-HD 40A`** (or `SpeedyBee F405 AIO`) in a PCB holder. Solder all leads **before** installing the board into the `95 mm` frame:

```text
====================================================================================
JHEMCU GHF411AIO-HD 40A — BENCH SOLDERING PINOUT TABLE
====================================================================================
1. POWER INPUT (Rear Edge):
   • [BAT+] ◄── Red 18AWG XT30u Pigtail (55mm) + Positive Leg of 470µF 35V Low-ESR Cap
   • [GND]  ◄── Blk 18AWG XT30u Pigtail (55mm) + Negative Leg of 470µF 35V Low-ESR Cap

2. UART1 — WALKSNAIL AVATAR HD NANO V3 VTX (6-Pin JST-SH or Direct Pads):
   • [9V / VBAT] ──► VTX Red (Power Input: 7.4V–8.7V 2S Direct)
   • [GND]       ──► VTX Black (Ground)
   • [TX1]       ──► VTX White (RX — MSP OSD DisplayPort Telemetry)
   • [RX1]       ──► VTX Yellow (TX — MSP Bidirectional Control)

3. UART2 — MICOAIR MTF-01 OPTICAL FLOW + 8m ToF LIDAR (Bottom Pads):
   • [5V]        ──► MTF-01 5V (Red, 30AWG Silicone)
   • [GND]       ──► MTF-01 GND (Black, 30AWG Silicone)
   • [RX2]       ◄── MTF-01 TX (Yellow — Sensor Transmit to FC Receive)
   • [TX2]       ──► MTF-01 RX (Green — FC Transmit to Sensor Receive)

4. I2C1 — SENSIRION SHT45 PSYCHROMETRIC PROBE (Outboard Boom):
   • [3V3]       ──► SHT45 VDD (Red, 30AWG PTFE Twisted Quad, 75mm length)
   • [GND]       ──► SHT45 GND (Black)
   • [SCL1]      ──► SHT45 SCL (Yellow — 400kHz I2C Clock)
   • [SDA1]      ◄─► SHT45 SDA (Blue — 400kHz I2C Data, Address 0x44)

5. SERVO PWM (S5 / LED_STRIP Pad B10) — EMAX ES9251 II GIMBAL SERVO:
   • [5V]        ──► Servo Red (+5.0V Regulated Rail)
   • [GND]       ──► Servo Brown (Ground)
   • [LED / B10] ──► Servo Orange (Remapped in CLI: `resource SERVO 1 B10`, 50Hz PWM)

6. PINIO1 (C14 / CAM_SW Pad) — DUAL 3W CROSS-POLARIZED FLOODLIGHTS:
   • [VBAT]      ──► 1.2A Constant-Current Buck Driver VIN+
   • [GND]       ──► AO3400 Low-Side MOSFET Source / Driver GND
   • [C14 / PINIO]─► AO3400 MOSFET Gate (10kΩ pulldown to GND; switched via `AUX4`)
====================================================================================
```

### Step 3: Conformal Coating for High-Humidity Crawlspaces & Boiler Dust (`10 Mins`)
1. Cover the `SPL06` barometer port pinhole, `USB-C` receptacle, and `JST-SH` connector pins with small dots of Kapton tape.
2. Brush a thin, uniform coat of **`MG Chemicals 422C` Silicone Conformal Coating** across both sides of the `JHEMCU GHF411AIO-HD` PCB and the `Walksnail Avatar V3` VTX board.
3. Inspect under a `365 nm` UV flashlight to verify 100% coverage of all MOSFET legs and QFN MCU pins, then allow 15 minutes to tack-dry before removing the Kapton mask from the barometer pinhole.

### Step 4: Propulsion & Propeller Press Installation (`10 Mins`)
1. Route the motor wires of the four **`RCINPOWER GTS V2 1204 5000KV`** motors through the recessed arm channels of [`THERMO95_Frame_95mm_Ducted.stl`](./cad/THERMO95_Frame_95mm_Ducted.stl) and secure each motor with four `M2 × 4 mm` screws dipped in `Loctite 222`.
2. Solder the motor phase wires to `M1` (Rear-Right), `M2` (Front-Right), `M3` (Rear-Left), and `M4` (Front-Left) on the AIO board.
3. Place the airframe onto **[`THERMO95_Bench_Prop_and_Gimbal_Jig.stl`](./cad/THERMO95_Bench_Prop_and_Gimbal_Jig.stl)** so the jig's bottom pillars support the `1204` motor shafts directly from underneath. Press on the four **`51 mm` (`2.0"`) `Gemfan D51-5` 5-blade propellers** in **Props-In** orientation (`M1` CW, `M2` CCW, `M3` CCW, `M4` CW) and secure with two `M2 × 5 mm` T-mount screws per hub. Verify uniform `1.25 mm` tip clearance inside the `53.5 mm` ID ducts.

### Step 5: Dual-Spectrum Gimbal Pod, Bumper Belt & Roll Cage Integration (`10 Mins`)
1. Install the **`Infiray Tiny1-C 256×192`** thermal core (`19×19mm` bay) and **`Walksnail Avatar Nano V3`** starlight camera (`14×14mm` bay) into [`THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl). Leave both coaxial/ribbon cables with a gentle `18 mm` service loop so the gimbal can sweep from `-90°` to `+60°` without cable drag.
2. Mount the **`EMAX ES9251 II`** digital servo into the rear gimbal bracket, attach the `0.8 mm` Z-bend spring-steel pushrod, and seat the gimbal trunnions into [`THERMO95_Attic_Truss_RollCage.stl`](./cad/THERMO95_Attic_Truss_RollCage.stl).
3. Stretch [`THERMO95_TPU_360_Bumper_Belt.stl`](./cad/THERMO95_TPU_360_Bumper_Belt.stl) around the four ducts, seating the two **`3W Cree XP-G3 5000K (92 CRI)`** emitters and aluminum heatsinks into the `30°` angled front cheek pockets.
4. Bolt the under-belly [`THERMO95_2S_Battery_ToF_Skids.stl`](./cad/THERMO95_2S_Battery_ToF_Skids.stl) (with the `MicoAir MTF-01` module seated in the recessed belly window) and the top [`THERMO95_Attic_Truss_RollCage.stl`](./cad/THERMO95_Attic_Truss_RollCage.stl) onto the main frame.

---

## 3. Optical & Thermal Calibration Procedures (`15 Mins`)

### Procedure A: `30°` Cross-Polarizer Alignment for Specular Glare Elimination
To guarantee zero specular reflection on shiny aluminum HVAC serial tags:
1. Slide the two rectangular **`0°` (Horizontal Axis) Linear Polarizer Windows** into the front slots in front of the left and right `3W Cree XP-G3` LEDs in [`THERMO95_TPU_360_Bumper_Belt.stl`](./cad/THERMO95_TPU_360_Bumper_Belt.stl).
2. Clip [`THERMO95_Lens_Dust_Cap_and_Cal_Target.stl`](./cad/THERMO95_Lens_Dust_Cap_and_Cal_Target.stl) (with a glossy stamped aluminum sample tag or chrome mirror strip taped to its target face) exactly **`30.0 cm` (`300 mm`)** ahead of the nose.
3. Power on the drone via a bench fan + `2S` battery, flip **`AUX4` (`SD` Switch)** to turn ON the dual 3W floodlights, and view the live `1080p` Walksnail video feed.
4. Slowly rotate the circular **Analyzer Polarizer Ring** on the front of the `Walksnail Avatar Nano V3` lens inside [`THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl) through `90°` until the blinding white mirror reflection from the aluminum target **turns completely dark and the stamped metal lettering pops into crisp, glare-free relief** (`90°` cross-polarized extinction minimum).
5. Lock the analyzer ring in place with a micro-drop of UV acrylic resin or `Loctite 222` on the outer bezel rim.

### Procedure B: Walksnail Macro Focus & `30 cm` Thermal/Visual Parallax Boresighting
1. With [`THERMO95_Lens_Dust_Cap_and_Cal_Target.stl`](./cad/THERMO95_Lens_Dust_Cap_and_Cal_Target.stl) positioned at **`30.0 cm`** (`OSD Rangefinder = 30 cm`), warm the center bullseye crosshair of the target for 3 seconds with your fingertip or a soldering iron tip held near the back face.
2. Adjust the threaded lens barrel of the `Walksnail Avatar Nano V3` camera until the `0.5 mm` resolution ticks on the `30 cm` target are razor-sharp (this sets the hyperfocal macro zone from **`15 cm` to `∞`**), then secure the lens lock-ring.
3. Compare the center crosshair of the `Walksnail 1080p` OSD with the radiometric center spot of the `Infiray Tiny1-C 256×192` thermal image. Thanks to the `3.15°` convergence toe-in built into [`THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl), both crosshairs should align within **`±1 pixel` (`< 1.0 mm`)** at `30.0 cm`. Use the two `M1.6` fine-trim nylon set screws on the `19×19mm` thermal carrier if any vertical or horizontal micro-trim is needed.

### Procedure C: Gimbal Servo Endpoint Calibration (`-90°` Nadir / `0°` Level / `+60°` Zenith)
1. Seat the completed drone into the angle-calibration cradle of [`THERMO95_Bench_Prop_and_Gimbal_Jig.stl`](./cad/THERMO95_Bench_Prop_and_Gimbal_Jig.stl).
2. On the RadioMaster Pocket (`THERMO95_EdgeTX_Contractor_Radio_Profile.yml`), center the rotary pot `S1` and test the 3-position Gimbal Quick-Snap Switch (`SC`):
   * **`SC↑` (Up — `+60°` Overhead Plenum/Subfloor):** Verify the gimbal pod points `+60.0° ± 1.0°` upward (`PWM = 1950 µs`) with zero frame rub against [`THERMO95_Attic_Truss_RollCage.stl`](./cad/THERMO95_Attic_Truss_RollCage.stl).
   * **`SC-` (Middle — `0°` Nameplate Level):** Verify the optical axis is `0.0° ± 0.5°` horizontal (`PWM = 1500 µs`).
   * **`SC↓` (Down — `-90°` Rooftop RTU Nadir):** Verify the gimbal points `-90.0° ± 1.0°` straight down between the front ducts (`PWM = 1050 µs`).

---

## 4. Pre-Flight Quality Assurance (QA) & Contractor Handover Protocol

Before releasing any **OSITO THERMO-95** unit to an HVAC field vehicle, complete and sign off the following 7-point inspection:

- [ ] **1. Smoke Stopper & Rail Continuity Check:** Plug in a `1.0A` current-limited Smoke Stopper on `XT30u`. Verify green indicator LED, `5.00V ± 0.08V` on the BEC rail, and `3.30V ± 0.05V` on the I2C `SHT45` rail.
- [ ] **2. Exact Mass Verification (`< 249g` Part 107 Micro Compliance):**
  - Dry Mass on calibrated scale: **`134.5 g ± 1.5 g`**
  - All-Up Weight (AUW) with `2S 850mAh LiHV`: **`192.5 g ± 2.0 g`** (Strictly `< 249.0 g`).
- [ ] **3. Motor Direction & Bi-Directional DShot300 Check:** In Betaflight Motors tab (with props verified inside ducts), confirm **Props-In** rotation (`M1` CW, `M2` CCW, `M3` CCW, `M4` CW) and `0.00%` DShot telemetry error packet rate.
- [ ] **4. `MicoAir MTF-01` Optical Flow & ToF LiDAR Range Check:** Lift the drone `30.0 cm` above the workbench; verify Betaflight OSD displays **`RNG: 30 cm`** and `FLOW QUALITY > 85%`.
- [ ] **5. `Sensirion SHT45` Psychrometric Telemetry Check:** Breathe gently across the rear-right outboard I2C boom; verify instant response in ambient temperature (`±0.1°C`) and relative humidity (`%RH`) within 2 seconds.
- [ ] **6. Cross-Polarized Nameplate Photo Test (`30 cm`):** Hover in **`Profile 1 (Nameplate Macro Lock)`** `30 cm` in front of a stamped aluminum HVAC serial plate in a dark room with **`AUX4` Floodlights ON**. Extract a `1080p` frame from the `Walksnail 32GB DVR` and confirm 100% legibility of model/serial digits with zero white-out glare.
- [ ] **7. Magnetic RTU Perch & Peel-Release Test:** Swap on [`THERMO95_Magnetic_RTU_Perch_Skids.stl`](./cad/THERMO95_Magnetic_RTU_Perch_Skids.stl), land on a horizontal `26-gauge` galvanized steel sheet-metal duct, disarm motors for 60 seconds, then re-arm in `Profile 0` and apply forward pitch (`25°`) + throttle to verify smooth front-to-back magnetic peel-off liftoff.
