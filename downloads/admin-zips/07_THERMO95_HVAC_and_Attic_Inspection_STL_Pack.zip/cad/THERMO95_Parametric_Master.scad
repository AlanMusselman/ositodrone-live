// ============================================================================
// OSITO THERMO-95: 95mm 2S Sub-250g Dual-Spectrum Radiometric Thermal &
// Attic/Rooftop HVAC Inspection Cinewhoop (OpenSCAD CSG Master)
// ============================================================================
// ENGINEERING VERIFICATION:
// 1. Wheelbase: 95.0mm diagonal motor-to-motor (R_motor = 47.5mm at 45/135/225/315 deg,
//    X/Y motor centers at +/-33.5876mm).
// 2. Aerodynamic Ducts: 53.5mm ID / 57.5mm OD (2.0mm wall) 14.0mm tall ducts for
//    51mm (2-inch 5-blade Gemfan D51 / HQProp DT51) cinewhoop propellers (1.25mm tip clearance).
//    Inboard duct edge sits at R = 47.5 - 28.75 = 18.75mm from center, clearing both
//    25.5x25.5mm Whoop AIO and 20x20mm HD VTX/Companion stacks.
// 3. Lower Fiberglass-Dust Stator Cups: Enclosed bottom cup around 1204/1303.5 motors
//    with 4-hole 9x9mm M2 mounting pattern (R = 6.364mm) to block loose-fill fiberglass
//    insulation fibers from entering motor magnets.
// 4. Attic Truss Roll Cage: Snap-on arched deflector cage with roof-nail guard ribs
//    (<= 10mm aperture spacing) and center avionics protection arch.
// 5. 360 TPU 95A Bumper Belt: 148mm x 148mm outer envelope with 30-deg off-axis
//    High-CRI LED floodlight bezels and outboard SHT45 Supply/Return dT sensor mast.
// 6. Dual-Spectrum Gimbal Pod: -90 deg (nadir rooftop scan) to +60 deg (zenith attic
//    plenum/duct inspection) housing 19x19mm 256x192 Radiometric Thermal IR core +
//    14x14mm 4K/1080p HD Macro nameplate camera + servo linkage horn.
// 7. Under-Belly 2S 850mAh LiHV Cradle + 78mm Snowshoe Skids + MTF-01 ToF/Optical Flow
//    window, plus Quick-Swap Magnetic RTU Perch Skids (4x 6x2mm N52 magnets + conical shear keys).
// ============================================================================

$fn = 44;

// Overridden via CLI: openscad -D PART_ID=1 ...
// 0 = Exploded Full Assembly Preview
// 1 = THERMO95_Frame_95mm_Ducted.stl          (Main 95mm ePA-CF/PC-CF Ducted Cinewhoop Frame)
// 2 = THERMO95_Attic_Truss_RollCage.stl       (Snap-On Upper Attic Roof-Nail & Truss Guard Cage)
// 3 = THERMO95_TPU_360_Bumper_Belt.stl        (360 TPU 95A Bumper + 30-deg LEDs + SHT45 dT Mast)
// 4 = THERMO95_DualSpectrum_Gimbal_Pod.stl    (-90 to +60 deg Thermal 19x19 + HD 14x14 Gimbal Pod)
// 5 = THERMO95_2S_Battery_ToF_Skids.stl       (2S 850mAh Cradle + 78mm Snowshoe Skids + MTF-01 Window)
// 6 = THERMO95_Magnetic_RTU_Perch_Skids.stl   (Quick-Swap N52 Magnetic RTU/Duct Perching Skids)
// 7 = THERMO95_Lens_Dust_Cap_and_Cal_Target.stl (Dual-Lens Cap + e=0.95 Flat-Field Calibration Target)
// 8 = THERMO95_Bench_Prop_and_Gimbal_Jig.stl  (1204 Motor Prop Press + -90/0/+45/+60 Gimbal Angle Jig)
PART_ID = 0;

// --- Core Airframe Dimensions (mm) ---
wheelbase_diag      = 95.0;
m_rad               = wheelbase_diag / 2.0; // 47.5 mm
motor_xy            = m_rad / sqrt(2);      // 33.5876 mm
arm_width           = 6.4;
arm_height          = 3.2;

// Aerodynamic Duct Parameters (for 51mm / 2-inch 5-blade props)
duct_id             = 53.5;
duct_wall           = 2.0;
duct_od             = duct_id + 2 * duct_wall; // 57.5 mm
duct_height         = 14.0;

// Motor Mounts (1204 / 1303.5 Brushless: 4-hole 9x9mm M2 pattern, R = 4.5*sqrt(2) = 6.364mm)
motor_cup_od        = 16.8;
motor_cup_id        = 13.8;
motor_cup_h         = 5.2;
motor_bolt_r        = 4.5 * sqrt(2); // 6.364 mm (9x9mm bolt circle)
motor_screw_dia     = 2.05;
motor_shaft_dia     = 4.2;

// Flight Controller & Companion Stack Mounts (25.5x25.5mm Whoop AIO + 20x20mm VTX/Stack)
fc_whoop_span       = 25.5;
fc_whoop_r          = fc_whoop_span / sqrt(2); // 18.0312 mm diamond
fc_stack_span       = 20.0;                    // 20x20mm square (+/-10.0mm X/Y)
fc_hole_dia         = 2.05;
fc_standoff_h       = 4.5;

// 2S 850mAh LiHV Battery Cradle (72.0 x 26.0 x 15.5 mm tunnel)
batt_len            = 72.0;
batt_width          = 26.0;
batt_height         = 15.5;
cradle_wall         = 2.0;

// ============================================================================
// HELPER MODULES
// ============================================================================
module fc_whoop_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_whoop_r, 0, 0])
                children();
    }
}

module fc_20x20_positions() {
    for (x_s = [-1, 1]) {
        for (y_s = [-1, 1]) {
            translate([x_s * (fc_stack_span/2), y_s * (fc_stack_span/2), 0])
                children();
        }
    }
}

// ============================================================================
// 1. THERMO95_Frame_95mm_Ducted.stl — 95mm Carbon-Composite Cinewhoop Frame
// ============================================================================
module thermo95_frame_95mm_ducted() {
    difference() {
        union() {
            // 1. Central Structural Hub Plate uniting 25.5x25.5mm & 20x20mm patterns
            hull() {
                cylinder(d=30.0, h=arm_height);
                fc_whoop_positions() cylinder(d=6.6, h=arm_height);
                fc_20x20_positions() cylinder(d=6.2, h=arm_height);
            }

            // 2. Raised M2 Standoffs for 25.5x25.5mm AIO & 20x20mm Stack
            fc_whoop_positions() {
                cylinder(d=5.4, h=arm_height + fc_standoff_h);
            }
            fc_20x20_positions() {
                cylinder(d=5.0, h=arm_height + fc_standoff_h);
            }

            // 3. 4x Diagonal Carbon-Composite Arms + Fiberglass-Dust Stator Cups + 14mm Ducts
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Main Diagonal Carbon-Composite Arm
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);

                    // Lower Fiberglass-Dust Stator Cup & Motor Boss at R = 47.5mm
                    translate([m_rad, 0, 0]) {
                        cylinder(d=motor_cup_od, h=motor_cup_h);

                        // 4x Bottom Aerodynamic Stator Support Struts
                        for (s_ang = [-65, -22, 22, 65]) {
                            rotate([0, 0, s_ang])
                                translate([motor_cup_od/2 - 0.8, -1.6, 0])
                                    cube([duct_id/2 - motor_cup_od/2 + 1.6, 3.2, arm_height]);
                        }

                        // Full 360-deg Base Ring (3.8mm tall for inboard stack clearance)
                        difference() {
                            cylinder(d=duct_od, h=3.8);
                            translate([0, 0, -0.1])
                                cylinder(d=duct_id, h=4.0);
                        }

                        // Full 14.0mm Tall Aerodynamic Shroud (265-deg outer arc clearing center stack)
                        intersection() {
                            difference() {
                                cylinder(d=duct_od, h=duct_height);
                                translate([0, 0, -0.1])
                                    cylinder(d=duct_id, h=duct_height + 0.2);
                            }
                            translate([-8.0, -duct_od/2 - 1.0, 0])
                                cube([duct_od + 9.0, duct_od + 2.0, duct_height + 0.2]);
                        }

                        // Upper Roll-Cage Snap-Lock Lip Rim on Outer Duct Top
                        intersection() {
                            difference() {
                                translate([0, 0, duct_height - 2.0])
                                    cylinder(d=duct_od + 1.2, h=2.0);
                                translate([0, 0, duct_height - 2.1])
                                    cylinder(d=duct_id, h=2.2);
                            }
                            translate([6.0, -duct_od/2 - 1.0, 0])
                                cube([duct_od, duct_od + 2.0, duct_height + 1.0]);
                        }
                    }
                }
            }

            // 4. 4x Cardinal Tangential Box-Truss Bridges uniting adjacent ducts
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    hull() {
                        translate([fc_whoop_r, 0, 0])
                            cylinder(d=6.0, h=3.6);
                        translate([motor_xy - 1.0, -7.5, 0])
                            cube([5.5, 15.0, 3.6]);
                    }
                    // Outer Vertical Bridge Pillar uniting adjacent 57.5mm OD ducts
                    translate([motor_xy - 1.2, -8.5, 0])
                        cube([6.2, 17.0, duct_height]);
                }
            }

            // 5. Forward Dual-Spectrum Gimbal Pivot Trunnions (+X Nose of Frame)
            // Anchored directly into the front duct walls (X = 50.5mm, Y = +/-13.5mm)
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([50.5, y_sign * 13.5 - 1.6, 2.0])
                        cube([4.0, 3.2, 10.0]);
                    translate([58.5, y_sign * 13.5, 7.0])
                        rotate([90, 0, 0])
                            cylinder(d=8.4, h=3.2, center=true);
                }
            }
        }

        // --- BOOLEAN SUBTRACTIONS ---
        // A. Swept Propeller Interior Clearance (53.5mm ID above arm_height)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, arm_height])
                    cylinder(d=duct_id, h=duct_height + 1.0);
        }

        // B. Fiberglass-Dust Stator Cup Recesses + 9x9mm M2 Bolt Pattern + Shaft Bore
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, 0]) {
                    // Upper Stator Cup Recess (leaves 2.2mm bottom plate & 1.5mm dust-shield rim)
                    translate([0, 0, 2.2])
                        cylinder(d=motor_cup_id, h=motor_cup_h);
                    // Center Motor Shaft & C-Clip Relief
                    translate([0, 0, -0.1])
                        cylinder(d=motor_shaft_dia, h=motor_cup_h + 0.2);
                    // 4x M2 Motor Mounting Holes on 9x9mm square (R = 6.364mm)
                    for (m_ang = [45, 135, 225, 315]) {
                        rotate([0, 0, m_ang])
                            translate([motor_bolt_r, 0, -0.1])
                                cylinder(d=motor_screw_dia, h=motor_cup_h + 0.2);
                    }
                }
        }

        // C. Center Avionics Cooling & Wiring Aperture
        translate([0, 0, -0.1])
            cylinder(d=14.5, h=arm_height + 0.2);

        // D. 25.5x25.5mm & 20x20mm M2 Flight Controller Through-Holes
        fc_whoop_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=duct_height + 2.0);
        }
        fc_20x20_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=duct_height + 2.0);
        }

        // E. Forward Gimbal Pivot M2 Trunnion Bearing Bore (+X Nose)
        translate([58.5, 0, 7.0])
            rotate([90, 0, 0])
                cylinder(d=2.1, h=40.0, center=true);
    }
}

// ============================================================================
// 2. THERMO95_Attic_Truss_RollCage.stl — Snap-On Upper Roof-Nail & Truss Guard
// ============================================================================
module thermo95_attic_truss_rollcage() {
    cage_ring_h = 2.4;
    rib_w       = 2.0;
    rib_h       = 2.4;

    difference() {
        union() {
            // 1. 4x Upper Duct Snap-On Perimeter Rings + Arched Roof-Nail Guard Ribs
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Radial Gusset Strut uniting Central Avionics Collar (R=13mm) to Duct Ring (R=21mm)
                    translate([12.5, -3.2, 0])
                        cube([9.0, 6.4, cage_ring_h]);

                    translate([m_rad, 0, 0]) {
                        // Outer Snap-Fit Collar Rim over Duct Wall
                        difference() {
                            cylinder(d=duct_od + 2.0, h=cage_ring_h);
                            translate([0, 0, -0.1])
                                cylinder(d=duct_id, h=cage_ring_h + 0.2);
                        }
                        // Central Motor Nut Deflector Ring (OD 14mm, ID 8mm)
                        difference() {
                            cylinder(d=14.0, h=cage_ring_h);
                            translate([0, 0, -0.1])
                                cylinder(d=8.0, h=cage_ring_h + 0.2);
                        }
                        // Mid-Span Concentric Nail-Blocker Ring (OD 34mm, ID 30.4mm -> <=10mm gap!)
                        difference() {
                            cylinder(d=34.0, h=cage_ring_h);
                            translate([0, 0, -0.1])
                                cylinder(d=30.4, h=cage_ring_h + 0.2);
                        }
                        // 6x Radial Arched Roof-Nail Deflector Spokes per Duct
                        for (r_ang = [0, 60, 120, 180, 240, 300]) {
                            rotate([0, 0, r_ang])
                                translate([4.0, -rib_w/2, 0])
                                    cube([duct_id/2 - 3.0, rib_w, rib_h]);
                        }
                    }
                }
            }

            // 4x Cardinal Bridge Clasps uniting adjacent duct rings
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang])
                    translate([motor_xy - 1.5, -8.5, 0])
                        cube([6.5, 17.0, cage_ring_h]);
            }

            // 2. Central Avionics Mounting Collar (connects to 20x20mm & 25.5x25.5mm stack)
            difference() {
                hull() {
                    fc_whoop_positions() cylinder(d=6.2, h=cage_ring_h);
                    fc_20x20_positions() cylinder(d=5.8, h=cage_ring_h);
                }
                translate([0, 0, -0.1])
                    cylinder(d=18.0, h=cage_ring_h + 0.2);
            }

            // 3. Raised Arched Attic Truss & Rafter Deflector Roll Cage over Center Stack
            for (arch_ang = [45, 135]) {
                rotate([0, 0, arch_ang])
                    difference() {
                        scale([1.0, 1.0, 0.72])
                            rotate([90, 0, 0])
                                cylinder(d=48.0, h=3.2, center=true);
                        scale([1.0, 1.0, 0.72])
                            rotate([90, 0, 0])
                                cylinder(d=41.6, h=4.0, center=true);
                        translate([-30.0, -30.0, -25.0])
                            cube([60.0, 60.0, 25.0]);
                    }
            }

            // Top Apex Boss uniting the two diagonal roll-cage arches
            translate([0, 0, 14.5])
                cylinder(d=10.0, h=3.0);
        }

        // Stack M2 Mounting Through-Holes
        fc_whoop_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=10.0);
        }
        fc_20x20_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=10.0);
        }
    }
}

// ============================================================================
// 3. THERMO95_TPU_360_Bumper_Belt.stl — 360° TPU 95A Bumper + 30° LEDs + SHT45 Mast
// ============================================================================
module thermo95_tpu_360_bumper_belt() {
    // 148mm x 148mm total outer envelope (+/-74.0mm X/Y):
    // motor_xy = 33.59mm; corner outer radius = 40.41mm (dia 80.82mm -> 33.59 + 40.41 = 74.0mm)
    bumper_h     = 8.0;
    cushion_wall = 3.2;

    difference() {
        union() {
            // 1. 4x Corner Duct Slip-On Rings + Outer Shock-Absorbing Ribbed Bumpers
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle])
                    translate([m_rad, 0, 0]) {
                        // Inner Duct-Grip Band around 57.5mm OD duct (OD = 63.9mm)
                        intersection() {
                            cylinder(d=duct_od + 2*cushion_wall, h=bumper_h);
                            translate([-12.0, -duct_od, 0])
                                cube([duct_od + 15.0, 2*duct_od, bumper_h]);
                        }

                        // Outer Crumple-Zone Arch Cushion reaching 148x148mm envelope (OD = 80.8mm)
                        intersection() {
                            difference() {
                                cylinder(d=80.8, h=bumper_h);
                                translate([0, 0, -0.1])
                                    cylinder(d=74.8, h=bumper_h + 0.2);
                            }
                            translate([14.0, -32.0, 0])
                                cube([32.0, 64.0, bumper_h]);
                        }

                        // 7x Radial Crumple-Zone Webbing Ribs connecting inner band to outer 148mm arch
                        for (w_ang = [-54, -36, -18, 0, 18, 36, 54]) {
                            rotate([0, 0, w_ang])
                                translate([duct_od/2 + 0.5, -1.3, 0])
                                    cube([40.4 - duct_od/2 - 1.5, 2.6, bumper_h]);
                        }
                    }
            }

            // 2. 4x Cardinal Flex Bridges uniting adjacent duct outer bands (at X = 54.0..58.5mm, Y = -20..+20mm)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang])
                    translate([54.0, -20.0, 0])
                        cube([4.5, 40.0, bumper_h]);
            }

            // 3. Integrated 30° Off-Axis High-CRI LED Floodlight Bezels on Front Bumper Bridge (+X)
            // Angled 30 degrees outboard from +X nose to eliminate glare on metallic HVAC nameplates
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([56.0, y_sign * 13.5 - 4.0, 0])
                        cube([3.0, 8.0, bumper_h]);
                    translate([59.5, y_sign * 13.5, bumper_h/2])
                        rotate([0, 0, y_sign * 30])
                            rotate([0, 90, 0])
                                cylinder(d=10.0, h=5.0, center=true);
                }
            }

            // 4. Outboard SHT45 Supply/Return dT Psychrometric Sensor Mast (+Y Left Side, out of prop wash)
            translate([0, 56.5, 0]) {
                // Cantilevered Sensor Boom extending to Y = 74.0mm boundary
                hull() {
                    translate([-6.0, -1.5, 0])
                        cube([12.0, 3.0, bumper_h]);
                    translate([0, 12.5, 0])
                        cylinder(d=10.0, h=bumper_h);
                }
                // Vented Aspirated Radiation/Dust Shield Hood for SHT45 Probe
                translate([0, 12.5, 0])
                    cylinder(d=11.2, h=bumper_h + 4.0);
            }
        }

        // Subtract all 4 Duct Outer Diameters (57.3mm snug slip-fit)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1])
                    cylinder(d=duct_od - 0.2, h=bumper_h + 5.0);
        }

        // High-CRI LED Emitter Bores (6.2mm ID at +/-30 deg off-axis)
        for (y_sign = [-1, 1]) {
            translate([59.5, y_sign * 13.5, bumper_h/2])
                rotate([0, 0, y_sign * 30])
                    rotate([0, 90, 0])
                        cylinder(d=6.2, h=14.0, center=true);
        }

        // SHT45 Sensor Cavity + Cross-Flow Psychrometric Sampling Bore + I2C Wire Channel
        translate([0, 69.0, -0.1])
            cylinder(d=7.0, h=bumper_h + 4.2);
        translate([0, 69.0, bumper_h/2 + 2.0])
            rotate([0, 90, 0])
                cylinder(d=4.5, h=16.0, center=true);
        translate([-1.5, 53.0, 2.5])
            cube([3.0, 16.0, 3.5]);
    }
}

// ============================================================================
// 4. THERMO95_DualSpectrum_Gimbal_Pod.stl — -90° to +60° Thermal + HD Gimbal Pod
// ============================================================================
module thermo95_dualspectrum_gimbal_pod() {
    // Houses BOTH:
    // - Lower Bay: 19.0 x 19.0 mm 256x192 Radiometric Thermal IR Core
    // - Upper Bay: 14.0 x 14.0 mm 4K/1080p HD Macro Nameplate Camera
    // Width = 23.0mm outer (fits cleanly between the Y = +/-13.5mm frame gimbal trunnions!)
    pod_w = 23.0;
    pod_l = 21.0;
    pod_h = 37.0;

    difference() {
        union() {
            // Main Rounded Dual-Spectrum Camera Pod Chassis
            hull() {
                translate([-pod_l/2, -pod_w/2, 0])
                    cube([pod_l - 3.0, pod_w, pod_h]);
                translate([pod_l/2 - 3.0, -pod_w/2 + 2.0, 2.0])
                    cube([3.0, pod_w - 4.0, pod_h - 4.0]);
            }

            // Left & Right Trunnion Pivot Bosses (at Z = 18.5mm center of gravity)
            translate([-2.0, 0, 18.5])
                rotate([90, 0, 0])
                    cylinder(d=8.0, h=pod_w + 3.2, center=true);

            // Integrated Servo Horn Linkage Arm (-Y Side, R = 11.0mm crank arm for -90 to +60 deg sweep)
            hull() {
                translate([-2.0, -pod_w/2 - 1.6, 18.5])
                    rotate([90, 0, 0])
                        cylinder(d=7.0, h=2.0);
                translate([-11.5, -pod_w/2 - 1.6, 24.0])
                    rotate([90, 0, 0])
                        cylinder(d=5.2, h=2.0);
            }
        }

        // 1. Lower 19.0 x 19.0 mm Radiometric Thermal Core Cavity
        translate([-8.5, -9.6, 2.0])
            cube([16.5, 19.2, 19.2]);
        // Thermal Germanium Lens Barrel Bore (+X Front Face, 13.5mm ID)
        translate([2.0, 0, 11.6])
            rotate([0, 90, 0])
                cylinder(d=13.5, h=15.0);

        // 2. Upper 14.0 x 14.0 mm HD Macro Nameplate Camera Cavity
        translate([-7.5, -7.1, 22.2])
            cube([15.5, 14.2, 14.2]);
        // HD Macro Lens Barrel Bore (+X Front Face, 11.5mm ID)
        translate([2.0, 0, 29.3])
            rotate([0, 90, 0])
                cylinder(d=11.5, h=15.0);

        // 3. Rear MIPI/USB Coax Ribbon Exit Window (-X Rear Face)
        translate([-pod_l/2 - 1.0, -6.5, 5.0])
            cube([6.0, 13.0, 27.0]);

        // 4. Pivot Trunnion M2 Screw Through-Holes
        translate([-2.0, 0, 18.5])
            rotate([90, 0, 0])
                cylinder(d=2.05, h=pod_w + 10.0, center=true);

        // 5. Servo Linkage Ball-Link M1.6 Hole
        translate([-11.5, -pod_w/2 - 0.5, 24.0])
            rotate([90, 0, 0])
                cylinder(d=1.7, h=6.0, center=true);
    }
}

// ============================================================================
// 5. THERMO95_2S_Battery_ToF_Skids.stl — 2S 850mAh Cradle + 78mm Snowshoe Skids + ToF
// ============================================================================
module thermo95_2s_battery_tof_skids() {
    outer_l     = batt_len + 2 * cradle_wall;   // 76.0 mm
    outer_w     = batt_width + 2 * cradle_wall; // 30.0 mm
    outer_h     = batt_height + 2 * cradle_wall;// 19.5 mm
    skid_span_y = 39.0;                         // 78.0 mm total snowshoe stance width!
    shoe_w      = 12.0;                         // Wide anti-sink fiberglass insulation snowshoe

    difference() {
        union() {
            // 1. Central 2S 850mAh LiHV Battery Tunnel Sleeve
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);

            // 2. Upper M2 Stack Mounting Wings (mates to 25.5x25.5mm & 20x20mm frame standoffs)
            hull() {
                translate([-14.0, -outer_w/2, -3.2])
                    cube([28.0, outer_w, 3.2]);
                fc_whoop_positions()
                    translate([0, 0, -3.2])
                        cylinder(d=6.8, h=3.2);
                fc_20x20_positions()
                    translate([0, 0, -3.2])
                        cylinder(d=6.4, h=3.2);
            }

            // 3. Rear MTF-01 Optical Flow + 8m ToF Rangefinder Protective Bezel Pod
            translate([-outer_l/2 - 12.0, -8.5, -outer_h])
                cube([13.0, 17.0, 9.0]);

            // 4. Wide 78mm Stance Snowshoe Anti-Sink Landing Skids (Left & Right)
            for (y_sign = [-1, 1]) {
                // Front & Rear Angled Support Struts
                for (x_leg = [-24.0, 24.0]) {
                    hull() {
                        translate([x_leg - 3.5, y_sign * (outer_w/2 - 1.0), -outer_h + 4.0])
                            cube([7.0, 2.4, 4.5], center=true);
                        translate([x_leg - 3.5, y_sign * (skid_span_y - shoe_w/2), -outer_h - 4.0])
                            cube([7.0, shoe_w, 2.4], center=true);
                    }
                }
                // Wide Snowshoe Runner Plate (68mm x 12mm each = 1,632 mm^2 bearing area)
                // Prevents sinking into loose-fill attic blown fiberglass or cellulose insulation!
                hull() {
                    translate([-30.0, y_sign * (skid_span_y - shoe_w/2) - shoe_w/2, -outer_h - 5.2])
                        cube([60.0, shoe_w, 2.4]);
                    // Turned-up Nose & Tail Ski Tips (prevents snagging attic wires/trusses)
                    translate([34.0, y_sign * (skid_span_y - shoe_w/2), -outer_h - 2.0])
                        cylinder(d=shoe_w, h=2.4);
                    translate([-34.0, y_sign * (skid_span_y - shoe_w/2), -outer_h - 2.0])
                        cylinder(d=shoe_w, h=2.4);
                }

                // Quick-Swap Conical Shear Key Sockets on Bottom of Cradle for Magnetic Perch Skids
                for (x_key = [-22.0, 22.0]) {
                    translate([x_key, y_sign * 10.5, -outer_h])
                        cylinder(d=7.0, h=3.0);
                }
            }
        }

        // A. Unobstructed 72.0 x 26.0 x 15.5 mm 2S 850mAh LiHV Battery Tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);

        // B. Side Battery Strap & Cooling Windows
        for (x_win = [-22.0, 0, 22.0]) {
            translate([x_win - 6.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 2.5])
                cube([13.0, outer_w + 0.2, batt_height - 5.0]);
        }

        // C. MTF-01 Optical Flow + 8m ToF Laser Rangefinder Bottom Cutout Window
        translate([-outer_l/2 - 10.0, -6.0, -outer_h - 0.1])
            cube([10.0, 12.0, 9.2]);

        // D. Conical Shear Keyway Recesses + M2 Bolt Holes for Quick-Swap Magnetic Perch Skids
        for (y_sign = [-1, 1]) {
            for (x_key = [-22.0, 22.0]) {
                translate([x_key, y_sign * 10.5, -outer_h - 0.1])
                    cylinder(d1=5.2, d2=3.4, h=2.6);
                translate([x_key, y_sign * 10.5, -outer_h - 0.1])
                    cylinder(d=2.05, h=cradle_wall + 1.0);
            }
        }

        // E. Stack M2 Mounting Through-Holes
        fc_whoop_positions() {
            translate([0, 0, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
        fc_20x20_positions() {
            translate([0, 0, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
    }
}

// ============================================================================
// 6. THERMO95_Magnetic_RTU_Perch_Skids.stl — Quick-Swap N52 Magnetic RTU Perch Skids
// ============================================================================
module thermo95_magnetic_rtu_perch_skids() {
    // Quick-swap perching adapter with 4x recessed 6mm x 2mm N52 neodymium magnet sockets
    // and upward-projecting Conical Shear Keys that lock into the battery cradle base.
    pad_span_x = 44.0; // +/-22.0mm
    pad_span_y = 21.0; // +/-10.5mm

    difference() {
        union() {
            // H-Frame Structural Perch Base uniting the 4 N52 magnet pods
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([-pad_span_x/2, y_sign * pad_span_y, 0])
                        cylinder(d=12.4, h=4.8);
                    translate([pad_span_x/2, y_sign * pad_span_y, 0])
                        cylinder(d=12.4, h=4.8);
                }
            }
            // Cross-Braces with MTF-01 ToF Clearance Cutout in Center
            for (x_sign = [-1, 1]) {
                hull() {
                    translate([x_sign * (pad_span_x/2), -pad_span_y, 0])
                        cylinder(d=9.0, h=4.2);
                    translate([x_sign * (pad_span_x/2), pad_span_y, 0])
                        cylinder(d=9.0, h=4.2);
                }
            }

            // 4x Upward Conical Shear Key Bosses (mate into THERMO95_2S_Battery_ToF_Skids)
            for (x_sign = [-1, 1]) {
                for (y_sign = [-1, 1]) {
                    translate([x_sign * (pad_span_x/2), y_sign * pad_span_y, 4.8])
                        cylinder(d1=5.0, d2=3.2, h=2.4);
                }
            }
        }

        // 4x Recessed 6.1mm x 2.1mm N52 Neodymium Magnet Pockets on Bottom Contact Face
        for (x_sign = [-1, 1]) {
            for (y_sign = [-1, 1]) {
                translate([x_sign * (pad_span_x/2), y_sign * pad_span_y, -0.1]) {
                    cylinder(d=6.15, h=2.15);
                    // M2 Captive Retention / Ejector Pin Through-Hole
                    cylinder(d=2.05, h=8.0);
                }
            }
        }
    }
}

// ============================================================================
// 7. THERMO95_Lens_Dust_Cap_and_Cal_Target.stl — Dual-Lens Cap + e=0.95 FFC Target
// ============================================================================
module thermo95_lens_dust_cap_and_cal_target() {
    // Fits snugly over the front of THERMO95_DualSpectrum_Gimbal_Pod (23.0 x 37.0 mm face)
    // Flat inner matte plate serves as a uniform e=0.95 Flat-Field Calibration (FFC) reference!
    cap_w = 26.6;
    cap_h = 40.6;
    cap_d = 9.0;

    difference() {
        union() {
            // Rounded Outer Protective Cap Shell
            hull() {
                for (x_s = [-1, 1]) {
                    for (y_s = [-1, 1]) {
                        translate([x_s * (cap_w/2 - 2.0), y_s * (cap_h/2 - 2.0), 0])
                            cylinder(r=2.0, h=cap_d);
                    }
                }
            }

            // Ergonomic Textured Finger Pull Ring on Front Face
            translate([0, 0, -4.0])
                cylinder(d=14.0, h=4.2);
        }

        // Inner Slip-On Cavity matching Gimbal Pod Nose (leaves 2.5mm flat FFC calibration target plate)
        translate([-(23.4)/2, -(37.4)/2, 2.5])
            cube([23.4, 37.4, cap_d]);

        // Concentric Micro-Baffled Matte Black Emissivity (e=0.95) Reference Rings on Inner Face
        for (r_baffle = [3.0, 6.0, 9.0]) {
            for (y_center = [-9.0, 9.0]) {
                translate([0, y_center, 2.0])
                    difference() {
                        cylinder(r=r_baffle + 0.5, h=0.6);
                        translate([0, 0, -0.1])
                            cylinder(r=r_baffle - 0.5, h=0.8);
                    }
            }
        }

        // Lanyard Tether Loop Bore through Front Pull Boss
        translate([0, 0, -2.0])
            rotate([0, 90, 0])
                cylinder(d=3.2, h=20.0, center=true);
    }
}

// ============================================================================
// 8. THERMO95_Bench_Prop_and_Gimbal_Jig.stl — 1204 Motor Press + Gimbal Angle Gauge
// ============================================================================
module thermo95_bench_prop_and_gimbal_jig() {
    difference() {
        union() {
            // 1. Heavy Bench Base Plate
            translate([-22.0, -18.0, 0])
                cube([44.0, 36.0, 4.0]);

            // 2. 1204/1303.5 Motor Bell Support Tower for Safe 51mm 5-Blade Prop Installation
            translate([-9.0, 0, 4.0])
                cylinder(d=20.0, h=14.0);

            // 3. Mechanical Gimbal Angle Calibration Quadrant (+X Side: -90 / 0 / +45 / +60 deg stops)
            translate([12.0, -3.0, 4.0])
                cube([9.0, 6.0, 22.0]);
            for (g_ang = [0, 45, 60]) {
                translate([16.5, 0, 12.0])
                    rotate([0, -g_ang, 0])
                        translate([0, -2.0, 0])
                            cube([14.0, 4.0, 2.2]);
            }
        }

        // 1204 Motor Bell Recess (15.6mm ID, 8.0mm deep)
        translate([-9.0, 0, 10.0])
            cylinder(d=15.6, h=9.0);

        // Motor Shaft & C-Clip Through-Bore (4.6mm ID)
        translate([-9.0, 0, -0.1])
            cylinder(d=4.6, h=19.0);

        // Motor Phase Wire Side Slot
        translate([-25.0, -2.5, 4.0])
            cube([16.0, 5.0, 15.0]);
    }
}

// ============================================================================
// 9. Assembled Prototype Module (with 1204 Motors & 5-Blade 51mm Props)
// ============================================================================
module thermo95_5blade_prop_and_motor() {
    // 1204 Brushless Motor Bell
    translate([0, 0, 2.0])
        cylinder(d=15.0, h=7.5);
    translate([0, 0, 9.5])
        cylinder(d=4.5, h=3.5);
    // 5-Blade 51mm (R=25.2mm) Cinewhoop Propeller
    for (b = [0 : 4]) {
        rotate([0, 0, b * 72])
            translate([0, 0, 7.2])
                rotate([18, 0, 0])
                    linear_extrude(height=1.1)
                        hull() {
                            translate([2.5, -1.6, 0]) circle(r=1.4);
                            translate([23.2, -0.8, 0]) circle(r=2.8);
                        }
    }
}

module motor_positions() {
    for (angle = [45, 135, 225, 315]) {
        rotate([0, 0, angle])
            translate([m_rad, 0, 0])
                children();
    }
}

module thermo95_assembled_prototype() {
    union() {
        thermo95_frame_95mm_ducted();
        thermo95_attic_truss_rollcage();
        thermo95_tpu_360_bumper_belt();
        translate([34.5, 0, -11.5]) thermo95_dualspectrum_gimbal_pod();
        thermo95_2s_battery_tof_skids();
        motor_positions() {
            thermo95_5blade_prop_and_motor();
        }
    }
}

// ============================================================================
// RENDER DISPATCHER
// ============================================================================
if (PART_ID == 1) {
    thermo95_frame_95mm_ducted();
} else if (PART_ID == 2) {
    thermo95_attic_truss_rollcage();
} else if (PART_ID == 3) {
    thermo95_tpu_360_bumper_belt();
} else if (PART_ID == 4) {
    thermo95_dualspectrum_gimbal_pod();
} else if (PART_ID == 5) {
    rotate([180, 0, 0]) thermo95_2s_battery_tof_skids();
} else if (PART_ID == 6) {
    thermo95_magnetic_rtu_perch_skids();
} else if (PART_ID == 7) {
    thermo95_lens_dust_cap_and_cal_target();
} else if (PART_ID == 8) {
    thermo95_bench_prop_and_gimbal_jig();
} else if (PART_ID == 9) {
    thermo95_assembled_prototype();
} else {
    // Colorized Assembled & Slightly Exploded Preview (PART_ID = 0)
    color([0.18, 0.20, 0.23]) thermo95_frame_95mm_ducted();
    color([0.28, 0.31, 0.36]) translate([0, 0, 4.0]) thermo95_attic_truss_rollcage();
    color([1.00, 0.42, 0.08]) thermo95_tpu_360_bumper_belt();
    color([0.95, 0.75, 0.12]) translate([38.5, 0, -11.5]) thermo95_dualspectrum_gimbal_pod();
    color([0.12, 0.65, 0.92]) thermo95_2s_battery_tof_skids();
    color([0.08, 0.85, 0.55]) motor_positions() thermo95_5blade_prop_and_motor();
}
