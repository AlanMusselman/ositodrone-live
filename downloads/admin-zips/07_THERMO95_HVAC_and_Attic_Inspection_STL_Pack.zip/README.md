# Osito HVAC Inspection Drone: `OSITO THERMO-95` Master Project Index

**Organization:** Osito Drone Services (`ositodrone.com` • Commercial & Residential Building Envelope, Attic & Rooftop HVAC Diagnostics)  
**System Designation:** **`OSITO THERMO-95`** (*95mm 2S Sub-250g Dual-Spectrum Radiometric Thermal & Attic/Rooftop HVAC Inspection Cinewhoop*)  
**Regulatory & Weight Class:** **`134.5 g` Dry / `192.5 g` AUW** with `2S 850mAh LiHV` (`58.0 g`) — **Sub-250g (`<249g`) FAA Registration-Exempt**

---

## 1. Executive Summary of the `OSITO THERMO-95` Architecture

The **`OSITO THERMO-95`** is an in-house 3D-printed (`ePA-CF` / `PA12-CF` + `TPU 95A`), dual-cell (`2S 850mAh LiHV`) diagnostic micro-cinewhoop engineered specifically for **HVAC Comfort Advisors, Commissioning Engineers, and Commercial Mechanical Contractors**:

1. **Fits Through Standard `14"×14"` Return Grilles & Attic Scuttle Holes (`148.0 × 148.0 × 68.0 mm` Envelope):**
   * Built around a **`95.0 mm` diagonal wheelbase** (`R_motor = 47.5 mm`, motors at `(±33.59, ±33.59) mm`) spinning **`51 mm` (2.0") 5-blade propellers** (`Gemfan D51-5`) inside **`53.5 mm` ID / `57.5 mm` OD full-height `14.0 mm` shrouded ducts** with bottom fiberglass-dust stator shields.
   * Surrounded by a continuous **`148.0 × 148.0 mm` `TPU 95A` 360° shock bumper belt** and an arched **`THERMO95_Attic_Truss_RollCage.stl`** that glides effortlessly off protruding roofing nails, galvanized Gang-Nail truss plates, and Romex cables.
2. **Co-Boresighted Dual-Spectrum Radiometric Thermal + 4K/1080p Macro Gimbal (`-90°` Nadir to `+60°` Zenith):**
   * Driven by a `2.5 g` `EMAX ES9251 II` digital servo, [`cad/THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl) tilts from **`-90°` straight down (nadir)** for rooftop condenser/ceiling insulation scans, to **`0°` level** for equipment serial plates, up to **`+60°` zenith** for subfloor crawlspace joists and overhead supply plenums.
   * Combines an **`Infiray Tiny1-C / Caddx Infra 256×192 @ 50Hz` Radiometric LWIR Thermal Core** (`<40mK` NETD, `-20°C to +550°C`) with a **`14×14mm` `Walksnail Avatar HD Nano V3` Starlight Macro Camera** focused at `30.0 cm` (`3.15°` convergence toe-in eliminates parallax at `30 cm`).
3. **`30°` Off-Axis Cross-Polarized High-CRI LEDs + `30 cm` LiDAR Standoff Lock:**
   * Dual **`3W Cree XP-G3 5000K (92 CRI)`** floodlights mounted at `30°` inward angles in the front bumper cheeks shine through `0°` linear polarizer windows while the macro camera views through an orthogonal `90°` analyzer filter—**eliminating >98% of specular metallic glare** on sun-bleached or oxidized aluminum RTU/furnace data plates.
   * A downward/forward **`MicoAir MTF-01` Optical Flow + `8.0 m` ToF LiDAR** module (`UART2` MSP) locks GPS-denied hover inside pitch-black attics and displays a live `30 cm` macro focus lock cue in the OSD.
4. **Outboard `SHT45` Psychrometric Probe & Quick-Swap Snowshoe / Magnetic RTU Perch Skids:**
   * An outboard **`Sensirion SHT45` (`±0.1°C` / `±1.0% RH`)** I2C mast mounted outside the propwash thermal boundary logs real-time attic ambient temperature, relative humidity, and dew-point margin.
   * Contractors can swap in 10 seconds between **[`THERMO95_2S_Battery_ToF_Skids.stl`](./cad/THERMO95_2S_Battery_ToF_Skids.stl)** (`78 mm` wide anti-sink fiberglass-insulation snowshoe skids) and **[`THERMO95_Magnetic_RTU_Perch_Skids.stl`](./cad/THERMO95_Magnetic_RTU_Perch_Skids.stl)** (4× rubber-booted neodymium magnets for landing and shutting off motors on steel RTU cabinets or sheet-metal trunk ducts for **45+ minutes of stationary compressor/plenum $\Delta T$ logging**).

---

## 2. Master Technical Specifications Summary

| Parameter | Verified Specification | Notes & HVAC Field Purpose |
| :--- | :--- | :--- |
| **System Designation** | **`OSITO THERMO-95`** | 95mm 2S Sub-250g Dual-Spectrum Thermal & Macro HVAC Inspection Cinewhoop |
| **Diagonal Wheelbase** | **`95.0 mm`** (`R_motor = 47.5 mm`) | Square-X geometry; motor centers at `X = ±33.59 mm, Y = ±33.59 mm` (`67.18 mm` adjacent) |
| **Propellers & Ducts** | **`51 mm` (2.0") 5-Blade** inside **`53.5 mm` ID / `57.5 mm` OD × `14.0 mm` Ducts** | `1.25 mm` radial tip clearance; `2.66:1` thrust-to-weight ratio even in `140°F` (`60°C`) attic air |
| **Outer Envelope** | **`148.0 × 148.0 × 68.0 mm`** | Fits through standard `14"×14"` (`355×355 mm`) ceiling return grilles & attic scuttle hatches |
| **Dry / All-Up Mass** | **`134.5 g` Dry / `192.5 g` AUW** | Includes `58.0 g` `2S 850mAh 75C LiHV` battery (`56.5 g` under the `249 g` FAA limit) |
| **Endurance** | **`8.5–10.5 min` Flight / `45+ min` Perch** | `10.9 A` hover draw in flight; `0.38 A` motor-off stationary logging on Magnetic RTU Perch Skids |
| **Avionics & Sensors** | **`JHEMCU GHF411AIO-HD 40A`** + **`Walksnail V3`** + **`Infiray 256×192`** + **`MTF-01`** + **`SHT45`** | Full `ELRS 2.4GHz` link, `32GB` 1080p DVR, `16MB` Blackbox, I2C psychrometrics, and `PinIO` LED switch |

---

## 3. Complete File Directory (`HVAC Inspection Drone/`)

### A. Engineering Blueprints, BOM, Shop Calibration & Contractor Field Playbooks
* **[`README.md`](./README.md)** — Master Project Index & Architecture Reference (this document).
* **[`THERMO-95_PRD_and_Blueprint.md`](./THERMO-95_PRD_and_Blueprint.md)** — Comprehensive Engineering Product Requirements Document (PRD), orthographic schematics, `140°F` attic density altitude math, cross-polarized Malus's Law optical physics, and avionics pinout.
* **[`THERMO95_BOM_and_Sourcing.md`](./THERMO95_BOM_and_Sourcing.md)** & **[`THERMO95_BOM_and_Sourcing.csv`](./THERMO95_BOM_and_Sourcing.csv)** — Complete Bill of Materials, part numbers, mass budget (`134.5 g` Dry / `192.5 g` AUW), and single-unit vs. 5-truck fleet sourcing breakdown.
* **[`SHOP_BUILD_AND_CALIBRATION_GUIDE.md`](./SHOP_BUILD_AND_CALIBRATION_GUIDE.md)** — 75-minute workbench assembly manual, pad-by-pad soldering guide, silicone conformal coating protocol, `30°` cross-polarizer extinction alignment, and `30 cm` thermal/visual parallax boresighting procedure.
* **[`CONTRACTOR_FIELD_PLAYBOOK.md`](./CONTRACTOR_FIELD_PLAYBOOK.md)** — Step-by-step **6-Minute Ladder-Free Residential Attic & Crawlspace Audit SOP**, **5-Minute Commercial Rooftop RTU Fleet Sweep & Magnetic Perch SOP**, **Thermal Anomaly $\Delta T$ Diagnostic Reference Table**, Homeowner Driveway Pitch Scripts, and **+\$57,050/yr per-truck ROI model**.

### B. Interactive 3D CAD Viewer & Contractor Quote Studio Web Apps
* **[`THERMO95_3D_Viewer.html`](./THERMO95_3D_Viewer.html)** — Interactive Three.js (`r128` with offline procedural 3D fallback) CAD Exploded Stackup & Live HVAC Inspection Simulator:
  * **Exploded CAD View Slider (`0%` to `100%`)** with clickable callouts and material/mass specs for all 8 printed parts.
  * **Live Gimbal Pitch Slider (`-90°` Nadir ↔ `0°` Nameplate Macro Lock ↔ `+60°` Overhead Plenum)** tilting the 3D gimbal pod and projecting the translucent thermal IR frustum cone, dual `30°` cross-polarized LED beams, and downward `MTF-01` green ToF laser.
  * **Quick-Swap Landing Gear Toggle:** Switch live between **Snowshoe Attic Fiberglass Skids (`THERMO95_2S_Battery_ToF_Skids.stl`)** and **Magnetic Commercial RTU Perch Skids (`THERMO95_Magnetic_RTU_Perch_Skids.stl`)**.
  * **Virtual Environment Backdrop Toggle:** Preview the drone hovering inside a **3D Residential Attic Truss Bay (with supply plenum & ductwork)** vs. **Commercial Rooftop RTU Condenser Unit** vs. **Clean CAD Engineering Studio Grid**, complete with a live simulated Dual-Spectrum Radiometric IR + 4K Macro PiP display.
* **[`THERMO95_Contractor_Quote_Studio.html`](./THERMO95_Contractor_Quote_Studio.html)** — Interactive HVAC Diagnostic Report & Customer Replacement Quote Generator for kitchen-table and commercial facility closes.

### C. 3D-Printable OpenSCAD Source & 8 Production `.stl` Files (`cad/`)
* **[`cad/THERMO95_Parametric_Master.scad`](./cad/THERMO95_Parametric_Master.scad)** — Master parametric OpenSCAD source defining all 8 parts (`PART_SELECT = 1..8`) and full assembly (`PART_SELECT = 0`).
* **[`cad/generate_thermo95_stls.ps1`](./cad/generate_thermo95_stls.ps1)** — Automated PowerShell batch compilation & geometry verification script for exporting all 8 `.stl` files.
* **The 8 Production 3D-Printable `.stl` Components:**
  1. **[`cad/THERMO95_Frame_95mm_Ducted.stl`](./cad/THERMO95_Frame_95mm_Ducted.stl)** — Main `95.0 mm` carbon-nylon (`ePA-CF` / `PA12-CF`) ducted frame with `53.5 mm` ID / `57.5 mm` OD × `14.0 mm` ducts and fiberglass-dust motor stator shields.
  2. **[`cad/THERMO95_Attic_Truss_RollCage.stl`](./cad/THERMO95_Attic_Truss_RollCage.stl)** — Upper arched attic truss/rafter & roof-nail deflector roll cage.
  3. **[`cad/THERMO95_TPU_360_Bumper_Belt.stl`](./cad/THERMO95_TPU_360_Bumper_Belt.stl)** — 360° `TPU 95A` shock bumper belt (`148×148 mm`) with dual `30°` angled cross-polarized High-CRI LED floodlight bezels and outboard `SHT45` $\Delta T$ psychrometric sensor mast.
  4. **[`cad/THERMO95_DualSpectrum_Gimbal_Pod.stl`](./cad/THERMO95_DualSpectrum_Gimbal_Pod.stl)** — Servo-tilted (`-90°` nadir to `+60°` zenith) dual-spectrum gimbal pod carrying the `256×192` Radiometric Thermal IR core and `14×14mm` 4K/1080p HD Macro nameplate camera.
  5. **[`cad/THERMO95_2S_Battery_ToF_Skids.stl`](./cad/THERMO95_2S_Battery_ToF_Skids.stl)** — Under-belly `2S 850mAh LiHV` battery bay with `78 mm` wide anti-sink fiberglass-insulation snowshoe skids and bottom window for the `MTF-01` Optical Flow + 8m ToF LiDAR sensor.
  6. **[`cad/THERMO95_Magnetic_RTU_Perch_Skids.stl`](./cad/THERMO95_Magnetic_RTU_Perch_Skids.stl)** — Quick-swap neodymium magnetic perch skids for landing and shutting off motors on steel commercial RTU cabinets or sheet-metal trunk ducts for 45+ minutes of stationary thermal/$\Delta T$ logging.
  7. **[`cad/THERMO95_Lens_Dust_Cap_and_Cal_Target.stl`](./cad/THERMO95_Lens_Dust_Cap_and_Cal_Target.stl)** — Dual-lens transport cover & $\varepsilon = 0.95$ thermal flat-field calibration target (`30 cm` boresight gauge).
  8. **[`cad/THERMO95_Bench_Prop_and_Gimbal_Jig.stl`](./cad/THERMO95_Bench_Prop_and_Gimbal_Jig.stl)** — Shop assembly & gimbal angle (`-90°` / `0°` / `+60°`) calibration bench jig.

### D. Bambu Studio / OrcaSlicer Production Print Profiles (`slicer/`)
* **[`slicer/THERMO95_Frame_ePACF_Profile.json`](./slicer/THERMO95_Frame_ePACF_Profile.json)** — Hardened-steel `0.4 mm` nozzle profile (`290°C` nozzle / `100°C` bed, annealed `ePA-CF` / `PA12-CF`) for the `95 mm` ducted frame, attic truss roll cage, and snowshoe skids.
* **[`slicer/THERMO95_TPU95A_Bumper_Gimbal_Profile.json`](./slicer/THERMO95_TPU95A_Bumper_Gimbal_Profile.json)** — Precision `TPU 95A` profile (`230°C` nozzle, internal crumple ribs) for the 360° bumper belt, vibration-damped gimbal mounts, magnetic perch boots, and calibration cap.

### E. Betaflight 4.5+ Optical Flow, LiDAR & Gimbal Servo Firmware (`firmware/`)
* **[`firmware/THERMO95_Betaflight45_OpticalFlow_CLI.txt`](./firmware/THERMO95_Betaflight45_OpticalFlow_CLI.txt)** — Complete Betaflight 4.5+ CLI configuration dump configuring `UART2` (`MicoAir MTF-01` Optical Flow + 8m ToF LiDAR hold), `SERVO 1` (`-90°` to `+60°` pitch-stabilized gimbal mixing on `AUX3`), `PINIO 1` (`AUX4` solid-state switch for the dual `30°` cross-polarized LEDs), `I2C1` (`SHT45` telemetry), and the 3-mode HVAC inspection rate profiles (`Profile 0: Attic Creep`, `Profile 1: 30cm Nameplate Lock`, `Profile 2: Rooftop RTU Wind Cruise`).
