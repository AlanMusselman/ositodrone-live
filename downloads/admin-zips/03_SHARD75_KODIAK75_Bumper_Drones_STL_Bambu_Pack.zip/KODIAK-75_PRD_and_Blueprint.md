# SHARD-75 / KODIAK-75: Engineering Blueprint & Product Requirements Document (PRD)

**SHARD-75 / KODIAK-75** (*Kinetic Omnidirectional Defensive Impact Arena Quad — 75mm Standard*)  
**Verified Mass Configurations:** **`37.1g` (LOS)** / **`38.8g` (Dual LOS+FPV)** / **`45.5g` (Full Optical-Flow + LiDAR + N52 Armor Spec)**

The name reflects both its aggressive open-prop "Printpick" silhouette and its signature bumper-tag mechanic: shedding high-visibility armor plates on mid-air impact while self-leveling in under half a second to stay in the fight inside a 101 x 101-inch netted arena.

---

## Part 1: KODIAK-75 Engineering Blueprint

### 1. Orthographic Mechanical Schematic & Stackup

The diagram below illustrates the top-down guardless 75mm geometry and the side-profile vertical stackup, showing how the 69.5mm-long 1S 550mAh battery, open 40mm–45mm propellers, net-deflection horns, and 4-zone magnetic breakaway Armor Plates integrate onto the 3D-printed carbon-composite chassis.

```text
================================================================================
KODIAK-75: TOP-DOWN ORTHOGRAPHIC BLUEPRINT (75mm DIAGONAL WHEELBASE)
              [NOSE / FORWARD ATTACK VECTOR]
                       ▲  ▲  ▲
                (Standoff Jousting Horn)
       \‾‾‾‾‾\          |          /‾‾‾‾‾/
      / 40-45mm\        |        /40-45mm \
     | Open Prop|       |       | Open Prop|
      \  (CCW) /  \     |     /  \  (CW)  /
       \______/     \   |   /     \______/
                      \ | /
        [MAG]=========  +  =========[MAG]
  (Horn  | |       /‾‾‾‾‾‾‾‾‾\       | |  (Horn
 Bumper)-| |------|  AIO FC   |------| |-(Bumper)
        ◄|L-PLATE|  + CROWN    |R-PLATE|►
         | |       \_________/       | |
        [MAG]=========  +  =========[MAG]
                      / | \
       /‾‾‾‾‾‾\     /   |   \     /‾‾‾‾‾‾\
      / 40-45mm\  /     |     \  / 40-45mm\
     | Open Prop|       |       | Open Prop|
      \  (CW)  /        |        \  (CCW) /
       \______/         |         \______/
               (Rear Standoff Horn)
                       ▼  ▼  ▼
             [TAIL / BT2.0 OR A30 PIGTAIL]

Key Dimensions:
• Motor-to-Motor Diagonal (Wheelbase): 75.0 mm
• Motor-to-Motor Adjacent (Square X):  53.0 mm
• Max Open Propeller Diameter:         40.0 mm (Gemfan 1610) to 45.0 mm
• Outer Standoff Horn Span:            105.0 mm (5mm clearance past prop arc)
• Under-Belly Battery Envelope:        70.0 mm (L) x 18.5 mm (W) x 7.5 mm (H)

================================================================================
KODIAK-75: SIDE-PROFILE VERTICAL STACKUP (EXPLODED)
   [ ZONE 1: TOP CANOPY CROWN ARMOR PLATE (EPP Foam + Steel Shim, 0.5g) ]
                              ║  ▲ (N52 2x1mm Vertical Magnet Socket)
                              ▼  ║
   [ MODULAR UPPER DECK: FPV Camera Pod (0.7g) OR LOS LED Dome (0.5g) ]
                              ║
   [ ZONE 2/3: L & R CHEEK ARMOR PLATES ] ◄══ [ N52 2x1mm Shear Magnets ]
                              ║
   [ 1S 12A 5-in-1 AIO FLIGHT CONTROLLER (Soft-Mounted on M2 Nylon) ]
   ===================(3.0mm Thermal Air Gap)===================
   [ MAIN CHASSIS: 2.2mm Thick CarbonX PC-CF / ePA-CF Printed X-Frame ]
   ===================(Flush Under-Belly Mount)=================
   [ TPU 56D/95A 550mAh BATTERY SLEEVE + 1S 550mAh LiHV PACK (14.0g) ]
                              ▲  ║
                              ║  ▼ (N52 2x1mm Belly Magnet Socket)
   [ ZONE 4: SACRIFICIAL BELLY SKID ARMOR PLATE (EPP Foam Plate, 0.6g) ]
================================================================================
```

### 2. CAD Dimensional & Mass Budget Specification

All structural components are designed for standard Fused Deposition Modeling (FDM) 3D printers equipped with an all-metal hotend (260°C–300°C capable), hardened steel 0.4mm nozzle, and heated enclosure.

| Component / Subsystem | Material / COTS Spec | Key CAD Dimensions & Tolerances | Target Mass |
| :--- | :--- | :--- | :--- |
| **Main Guardless X-Frame** | CarbonX PC-CF or ePA-CF | 75.0mm diagonal; 4.5mm arm width x 2.5mm I-beam height; 6mm motor mount bosses (M1.4 x 3 holes) | 2.1g |
| **Net-Deflection Standoff Horns** | Sandwich print: 2 layers TPU 95A + ePA-CF core + 2 layers TPU 95A | 4x prongs at 12, 3, 6, and 9 o'clock; 52.5mm radius from center (clears 45mm prop tip by 5.0mm) | 2.8g |
| **550mAh Belly Cradle & Case** | TPU 56D or TPU 95A | 70.0mm x 18.5mm x 7.5mm internal slot; mounts battery 3.0mm below FC PCB; integrated Velcro slot | 1.6g |
| **Modular Upper Deck (Option A: LOS)** | TPU 95A Translucent | Snap-fit over M2 nylon stack screws; houses 5V COB Red/Blue + White nose LEDs; top magnet socket | 0.5g |
| **Modular Upper Deck (Option B: FPV)** | TPU 95A | 15°–35° adjustable camera tilt for C03 / Nano 3 / Ant Lite; top magnet socket + U.FL antenna tube | 0.75g |
| **4x Breakaway Armor Plates** | CNC/Hot-wire cut EPP Foam + 3D-printed TPU magnet/shim cups | 1x Top Crown (0.5g), 2x Side Cheek Plates (0.5g each), 1x Belly Skid Plate (0.6g) | 2.1g |
| **Magnetic Retention Hardware** | 10x 2mm x 1mm N52 Neodymium Discs ($\text{Nd}_2\text{Fe}_{14}\text{B}$, 5x Drone + 5x Plates) | 2.10mm diameter x 1.20mm deep TPU press-fit pockets (recessed 0.2mm to prevent impact shattering) | 0.20g |
| **Propulsion (4x Motors + Props)** | 0803 22,000KV (or 1002/1102 22,000KV) + 40mm–45mm Bi-Blades | 1.5mm motor shafts; Gemfan 1610 (40mm) or 45mm polycarbonate bi-blades | 9.2g |
| **Avionics (AIO FC + Wiring)** | 1S 12A 5-in-1 AIO (ELRS + VTX) + 20AWG BT2.0/A30 Pigtail | 25.5mm x 25.5mm whoop mounting pattern; M2 nylon screws + silicone soft-mount grommets | 4.8g |
| **Optional FPV Camera** | BetaFPV C03 / Runcam Nano 3 / Caddx Ant Lite | 14mm x 14mm nano form factor with 3-pin JST-SH plug | 0.0g (LOS) / 1.5g (FPV) |
| **Power Pack** | 1S 550mAh LiHV (75C–100C, 3.8V nominal / 4.35V max) | ~68.0mm x 16.0mm x 6.5mm pouch cell | 13.8g |
| **Total All-Up Ready-to-Play Weight** | Complete Ready-to-Fight Aircraft | Within 101" Tent Kinetic Envelope | **37.1g (LOS) / 38.8g (Dual LOS+FPV) / 45.5g (Full Optical-Flow + LiDAR + N52 Armor Spec)** |

---

## Part 2: Product Requirements Document (PRD)

| Document Metadata | Details |
| :--- | :--- |
| **Product Name** | SHARD-75 / KODIAK-75 (1S 75mm Open-Prop Breakaway Bumper-Tag Micro-Drone) |
| **Target Arena** | 101 in x 101 in x 84–101 in ($2.56\text{ m} \times 2.56\text{ m}$) Pop-Up Netted Screen Tent |
| **Architecture Class** | 75mm Guardless 3D-Printed Carbon-Composite "Printpick" with Dual LOS/FPV Capability |
| **Primary Power** | 1S 550mAh LiHV (4.35V peak) via BT2.0 or A30 High-Current Connector |

### 1. Purpose & Product Vision

The **KODIAK-75** is an in-house manufacturable, single-cell (1S) aerial Bumper Drone engineered specifically for multi-point aerial bumper tag inside a portable 101 x 101-inch netted pop-up tent. By eliminating heavy perimeter propeller ducts in favor of a stiff, 3D-printed carbon-fiber-reinforced open-prop chassis (PC-CF / ePA-CF), the KODIAK-75 achieves the thrust efficiency needed to haul a high-capacity 1S 550mAh LiHV battery while carrying four magnetically attached sacrificial armor plates (or custom kid snap-on Mod-Pods). When players ram each other or strike opponent armor with their open bi-blade propellers, individual Armor Plates shear away cleanly while Betaflight's active crash-recovery loop re-levels the aircraft mid-air within 500 milliseconds.

### 2. Core Functional & Performance Requirements

* **P0 — 75mm Standard Open-Prop Footprint:** The airframe MUST standardize on a 75.0mm diagonal motor-to-motor wheelbase without circumferential propeller ducts, accommodating 40mm (Gemfan 1610) to 45mm polycarbonate bi-blade propellers with at least 4.0mm of clearance between blades and the central fuselage.
* **P0 — 1S 550mAh Match Endurance:** The propulsion and battery subsystem MUST accept standard 1S 550mAh LiHV packs (65mm–70mm length, 13.5g–15.0g mass) and deliver a minimum of 4.5 minutes (FPV mode) to 6.0 minutes (LOS mode) of aggressive bumper match flight per charge, landing at 3.30V cell voltage.
* **P0 — Multi-Hit Magnetic Breakaway Armor:** Each aircraft MUST carry four independent, color-coded sacrificial armor plates (1x Top Crown, 2x Side Cheek Shields, 1x Belly Skid Plate) that remain securely attached during 15G acrobatic maneuvers (>600 deg/s roll/pitch) but detach cleanly upon direct drone-on-drone impact.
* **P0 — Asymmetric Mass-Loss Stability:** Total combined mass of all four breakaway Armor Plates MUST NOT exceed 10% of the aircraft's All-Up Weight ($\le 3.5\text{g}$ total, $\le 0.8\text{g}$ per Armor Plate) so that shedding any combination of Armor Plates shifts the Center of Gravity by less than 1.5mm, requiring zero manual trim adjustments mid-flight.
* **P0 — Tent-Net Anti-Entanglement Protection:** Because open propellers will shred and tangle in fine polyester no-see-um tent mesh, the frame MUST integrate four non-ducted perimeter standoff horns extending 5.0mm beyond the propeller arc to deflect the flexible net wall before blades can make contact.
* **P1 — 60-Second Optional Camera / LOS Conversion:** The upper deck MUST allow tool-less or 3-screw conversion between an FPV Camera Pod and a camera-less Line-of-Sight (LOS) LED Orientation Dome in under 60 seconds.

### 3. In-House 3D-Printing & Mechanical Manufacturing Requirements

#### 3.1 Structural Frame Slicing Protocol (`KODIAK75_Frame_v1.stl`)
* **Material:** CarbonX Polycarbonate Carbon Fiber (PC-CF) or Nylon Carbon Fiber (ePA-CF) dried at 70°C for 6 hours prior to printing.
* **Orientation & Layer Geometry:** Printed flat on the build plate so continuous carbon-polymer strands run parallel to the 75mm arm axes, maximizing tensile resistance against bending fractures.
* **Perimeters & Infill:** 5 wall perimeters (0.4mm nozzle = 2.0mm shell thickness), 4 top/bottom solid layers, 40% Gyroid infill, 0.16mm layer height.
* **Thermal & Vibration Isolation:** The 25.5mm x 25.5mm flight controller mounting pattern MUST utilize M2 nylon/plastic screws with silicone damping grommets, maintaining a 3.0mm air gap beneath the AIO PCB to prevent ESC/VTX heat buildup and gyro saturation.

#### 3.2 Composite Standoff Horns (`KODIAK75_Horns_v1.stl`)
* **Multi-Material Sandwich Construction:** Following the Chris1x4 impact bumper standard, print the standoff ring/horns with 2 bottom layers of TPU 95A, switch filament to ePA-CF for the structural middle core, and finish with 2 top layers of TPU 95A. This prevents brittle carbon delamination while maintaining sufficient rigidity to push back the pop-up tent mesh.

#### 3.3 Flush 550mAh Battery Cradle (`KODIAK75_550Cradle_v1.stl`)
* **Material:** Printed in TPU 56D or TPU 95A at 100% infill.
* **CoG & Puncture Protection:** Positions the 1S 550mAh cell lengthwise along the belly within 3.0mm of the flight controller PCB. The AIO flight controller MUST be oriented or selected so no metal USB port protrudes downward against the top surface of the LiHV pouch cell.

#### 3.4 Magnetic Socket & Breakaway Armor Plate Fabrication
* **Magnet Specification:** 2mm x 1mm Grade N52 Neodymium disc magnets (`JC-D0201-N52`, 0.02g mass, 68g–113g axial pull force, triple-layer Ni-Cu-Ni coating).
* **Anti-Shatter Pocket Geometry:** Because thin N52 sintered discs are brittle and will shatter if allowed to snap directly together face-to-face, every magnet socket on the TPU harness MUST recess the magnet 0.20mm below the TPU mating surface or pair a single N52 magnet on the drone frame against a 0.15mm ferromagnetic steel shim glued to the EPP foam Armor Plate.
* **Shear Keyway:** Incorporate a 0.5mm shallow conical dimple on the mating face to prevent lateral G-force sliding during snap-rolls while allowing angled bumper-tag rams to shear the Armor Plate free.

### 4. Avionics, Propulsion & Vision Subsystem Requirements

| Subsystem | Mandatory Specification | Operational Requirement |
| :--- | :--- | :--- |
| **Flight Controller (LOCKED)** | **BetaFPV Matrix 1S Brushless `5-in-1` AIO** (`STM32G473CEU6` 170MHz MCU, `ICM42688P` gyro, onboard Serial ELRS 2.4GHz RX on `UART2`, 5.8GHz 25–400mW OpenVTX on `UART1`, and `12A` continuous / `18A` peak 4-in-1 ESCs with `JST-1.25` motor sockets, flat-bottom PCB with side `SH1.0` USB-C dongle, pre-soldered `BT2.0` pigtail, `3.9g`) | `12A` MOSFET rating prevents ESC burnout during bumper stalls; built-in `JST-1.25` motor plugs and `3-pin JST-SH` camera header allow zero-solder field maintenance; flat underside protects the under-belly `1S 550mAh` pouch cell. |
| **ESC Firmware** | Bluejay 48kHz with Bidirectional DShot enabled | Enables active RPM gyro notch filtering (suppressing 50,000+ RPM motor noise) and instantaneous motor reversal for Turtle Mode. |
| **Motors** | 0803 22,000KV (for 40mm props) or 1002 / 1102 19,500KV–22,000KV (for 45mm props) with 1.5mm shafts | Must use 2 to 3 M1.4 screws per motor; 1.5mm titanium/steel shafts prevent bent bells during open-prop mid-air collisions. |
| **Power Lead** | BT2.0 or A30 connector on 20AWG silicone wire, zip-tied to rear strut | Eliminates PH2.0 voltage sag under 550mAh burst loads and prevents wire snap at the AIO solder pads during rapid battery swaps. |
| **FPV Pod (Optional)** | Plug-in nano camera (C03 / Nano 3 / Ant Lite) + 25mW VTX output + heat-shrunk U.FL dipole antenna | Connects via 3-pin JST-SH header; antenna must be captive inside rear TPU horn so opponent props cannot sever it. |
| **LOS Dome (Default)** | 5V addressable RGB/COB LED strip on front/rear arms + top TPU dome | Front arms lit High-Intensity White/Green (nose direction); rear arms switchable between Team Red and Team Blue. |

### 5. Firmware Configuration & Arena Safety Requirements

Every KODIAK-75 unit must be flashed with the standardized Betaflight 4.5+ BUMPER-TAG PROFILE prior to entering the 101 x 101-inch tent (see [`firmware/KODIAK75_betaflight_cli.txt`](./firmware/KODIAK75_betaflight_cli.txt)).

* **LOS Mode VTX Protection:** When operating without the optional FPV camera pod installed, operators MUST enable VTX Pit Mode (0mW output) via a Betaflight AUX mode tab or SmartAudio switch so the onboard video transmitter does not thermally overload without an antenna or high-speed airflow.
* **Flight Modes Matrix:**
  * **AUX 1:** Arm / Disarm (instant manual kill switch for net entanglement).
  * **AUX 2:** Flight Mode (Angle Mode self-leveling for LOS bumper-tag; Acro Mode for FPV aerial bumper tag; optional Headless Mode for novice LOS pilots).
  * **AUX 3 (Momentary Button):** Flip Over After Crash (Turtle Mode) for self-righting off the tent floor.

### 6. Ground Support, Tournament Rules & Acceptance Testing

#### 6.1 Fleet Charging & Turnaround Pipeline
* **Battery Pool:** Minimum of 6x 1S 550mAh LiHV (BT2.0/A30) packs per active KODIAK-75 aircraft.
* **Charging Station:** VIFLY WhoopStor V3 6-port 1S storage charger/discharger configured to 4.35V (LiHV) at 1.1A–1.3A per port (~2C charge rate, ~25-minute full recharge). All packs must be returned to 3.80V storage voltage immediately after each event.

#### 6.2 KODIAK-75 Arena Scoring Protocol (3-Minute Heats, First to 10 Points)

| Scoring Play | Points Awarded | Match Continuation Rule |
| :--- | :--- | :--- |
| **Cheek or Belly Armor Plate Strip** | 1 Point | Opponent recovers mid-air via `crash_recovery` and continues fighting. |
| **Top Crown Plate Ejection** | 2 Points | Awarded for top-down diving attacks that knock off the upper canopy/dome Armor Plate. |
| **Direct Grounding Takedown** | 3 Points | Opponent is knocked to the tent floor and cannot take off or Turtle-flip within 5 seconds. |
| **Unforced Net / Floor Error** | 1 Point (to Opponent) | Pilot contacts the tent floor, ceiling, or snags the mesh wall without prior contact from an opponent drone. |

#### 6.3 Engineering Quality & Acceptance Tests (QA Gate)
Before a printed KODIAK-75 airframe is cleared for tournament bumper-tag, it must pass four verification tests:
1. **Propeller-Free Runaway Test:** Arm the drone with no props installed and blip throttle to 30% for 2 seconds; the flight controller MUST automatically disarm within 0.5 seconds and display `RUNAWAY` in the OSD.
2. **15G Acro Retention Test:** Fly 60 seconds of continuous snap-rolls, flips, and full-throttle punches inside the tent with all four Armor Plates attached; zero Armor Plates may detach from aerodynamic or inertial forces alone.
3. **Net Deflection Glancing Test:** Fly the drone horizontally into the 101-inch tent mesh wall at 50% throttle at a 45-degree angle; the TPU/ePA-CF standoff horns MUST deflect the aircraft back into the arena without the 40mm–45mm open blades biting into the mesh fabric.
4. **10-Drop Concrete Fatigue Inspection:** Drop a weighted dummy frame (38g) from a height of 2.5 meters onto a hard floor 10 times; inspect the PC-CF motor bosses and arm roots under magnification for interlayer delamination prior to fleet sign-off.
