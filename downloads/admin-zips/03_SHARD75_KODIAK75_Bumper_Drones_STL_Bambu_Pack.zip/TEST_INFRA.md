# KODIAK-75 Wave 4 Sacrificial Customization Parts — Test Infrastructure & Quality Assurance Specification

**Document Version:** 1.0.0  
**Target Milestone:** Wave 4 Production Sacrificial Customization Expansion (`PART_ID = 2001..3000`, 1,000 parts)  
**Fleet Target:** Cumulative 2,240-Part Armor & Personalization Ecosystem (392,875,520 Loadout Combinations)  
**Authoritative Request:** `.agents/teamwork/ORIGINAL_REQUEST.md`  
**Test Suite Script:** `Bumper Drones/cad/test_wave4_e2e_suite.ps1`  
**Target Systems:** Windows PowerShell 5.1+ / OpenSCAD CLI (`openscad.com` 2021.01+) / In-Memory .NET CLR  

---

## 1. Executive Summary & Test Philosophy

The KODIAK-75 Bumper Drone ecosystem relies on modular, sacrificial TPU 95A components that absorb collision energy during high-speed STEM flight training and enable personalized student loadouts. Wave 4 expands the ecosystem by 1,000 production parts (IDs 2001..3000), scaling the total catalog from 1,240 to 2,240 cumulative parts and loadout permutations from 66,578,080 to **392,875,520 unique combinations** ($896 \times 783 \times 560$).

### 1.1 Opaque-Box Requirement-Driven Verification
This testing infrastructure adheres to strict **opaque-box requirement-driven verification**:
- Expected outputs are derived solely from `ORIGINAL_REQUEST.md` and the master mechanical interface standards.
- Tests exercise observable outputs: OpenSCAD CLI exit codes, standard output streams, binary STL byte structures, JSON catalog syntax and semantics, HTML DOM elements, and mathematical invariants.
- No facade tests or dummy implementations are permitted. Every test asserts genuine geometric, physical, and integration properties.

### 1.2 Progressive Testability
The test harness supports progressive verification across all implementation milestones:
- **Milestone 1**: Parametric SCAD generation & master router dispatching.
- **Milestone 2**: Batch compilation & binary STL generation.
- **Milestone 3**: Physical mesh audit (bed adhesion, mass budget, manifoldness, support-free overhangs).
- **Milestone 4**: Cumulative catalog JSON generation (1,000 Wave 4 + 2,240 cumulative entries).
- **Milestone 5**: Web viewer & menu synchronization (`OSITO_Kids_Garage_Loadout_Menu.html`, `KODIAK75_3D_Viewer.html`, `README.md`).
- **Milestone 6**: End-to-End automated validation gate.

---

## 2. 4-Tier Test Architecture

The automated test suite (`cad/test_wave4_e2e_suite.ps1`) is organized into four distinct architectural tiers:

```
+-----------------------------------------------------------------------------------+
|                        KODIAK-75 WAVE 4 E2E TEST SUITE                            |
+-----------------------------------------------------------------------------------+
|  Tier 1: Feature Coverage & OpenSCAD CLI Manifoldness                              |
|    - File existence & non-emptiness (Master router + 5 sub-modules)               |
|    - CLI compilation on representative & boundary PART_IDs                        |
|    - Boundary value testing (2001, 2200, 2201, 2400, 2401, 2575, 2576, 2750, etc.)|
|    - Out-of-bounds invalid ID rejection (2000, 3001)                              |
|    - STDOUT stream analysis (Simple: yes, 0 ERROR:, 0 WARNING:, 0 EXPORT-WARNING) |
+-----------------------------------------------------------------------------------+
|  Tier 2: Boundary & Corner Cases (Physics, Bed Contact & Overhangs)               |
|    - Bed adhesion: |MinZ| <= 0.005mm (Z=0.000mm flat print bed)                   |
|    - TPU 95A mass budget: 0.30g <= Mass <= 1.20g (Vol: 247.9 .. 991.7 mm3)       |
|    - Cheek pod pair combined mass: 0.65g .. 1.15g (0.32g .. 0.58g per pod)        |
|    - Zero degenerate triangles (NaN, zero normal length, area <= 1e-18)           |
|    - 100% support-free overhang angles (<= 45 deg from vertical)                  |
|    - Bounding box envelope checks (clearances & duct walls)                       |
+-----------------------------------------------------------------------------------+
|  Tier 3: Universal Mechanical & Magnetic Interface Standard                       |
|    - Zone 1: Annular recess 8.40 x 0.45mm, conical boss d1=3.40, d2=2.10, h=0.45 |
|              Center N52 socket 2.10 x 1.20mm, outer collar 16.0 .. 17.6mm         |
|    - Zones 2 & 3: Mirrored pairs at Y = +/-15.0mm (pitch >= 30.0mm)               |
|                   Top-facing conical boss & N52 magnet socket, Z <= 3.5mm         |
|    - Zone 4: Dual mounting posts at X = +/-18.0mm (36.0mm pitch)                  |
|              Dual conical bosses & N52 sockets, central tunnel >= 18.0mm          |
+-----------------------------------------------------------------------------------+
|  Tier 4: Real-World Loadout & Ecosystem Integration                               |
|    - Master catalog JSON schema validation (16 required fields)                   |
|    - wave4_catalog.json (1,000 items) & kodiak75_catalog_2240.json (2,240 items)   |
|    - Part ID sequence continuity (2001..3000) & zero duplicates                   |
|    - Mathematical archetype/subvar offset formulas                                |
|    - Web viewer embedded arrays (w: 4 tags, c2001..c2400, ch2401.., b2751..)     |
|    - Filter buttons (wave-4, vwave-4) & combo counter: 392,875,520                |
|    - Twin brain artifact synchronization & README.md documentation               |
|    - UTF-8 without BOM verification across all project files                      |
+-----------------------------------------------------------------------------------+
```

---

## 3. Detailed Tier Specifications

### 3.1 Tier 1: Feature Coverage & OpenSCAD CLI Manifoldness
- **Objective**: Verify that parametric OpenSCAD source models compile into valid 2-manifold geometries via the official OpenSCAD console engine (`openscad.com`).
- **Test Invariants**:
  1. All 6 SCAD files must exist and contain valid OpenSCAD syntax:
     - `KODIAK75_Wave4_Master.scad`
     - `KODIAK75_Wave4_Crowns_A.scad`
     - `KODIAK75_Wave4_Crowns_B.scad`
     - `KODIAK75_Wave4_Cheeks_A.scad`
     - `KODIAK75_Wave4_Cheeks_B.scad`
     - `KODIAK75_Wave4_Belly.scad`
  2. Router compilation must succeed across every module boundary:
     - Top Crowns A: `PART_ID = 2001` (min), `2100` (mid), `2200` (max)
     - Top Crowns B: `PART_ID = 2201` (min), `2300` (mid), `2400` (max)
     - Cheek Pods A: `PART_ID = 2401` (min), `2488` (mid), `2575` (max)
     - Cheek Pods B: `PART_ID = 2576` (min), `2663` (mid), `2750` (max)
     - Under-Belly Skids: `PART_ID = 2751` (min), `2875` (mid), `3000` (max)
  3. Out-of-bounds rejection:
     - `PART_ID = 2000` (underflow boundary)
     - `PART_ID = 3001` (overflow boundary)
  4. Stream Routing Rule:
     - On Windows, `openscad.com` routes `ECHO:`, `WARNING:`, and `ERROR:` to **STDOUT**.
     - STDOUT must contain `Simple:\s+yes`.
     - STDOUT must NOT contain `Simple:\s+no`, `ERROR:`, `WARNING:`, or `EXPORT-WARNING`.

### 3.2 Tier 2: Boundary & Corner Cases (Physics & Geometry)
- **Objective**: Perform byte-level binary STL analysis on compiled components to guarantee printability, mass adherence, and support-free manufacturing.
- **Embedded C# Analysis Engine (`Wave4MeshAuditor`)**:
  - Signed tetrahedral mesh volume:
    $$V = \sum_{i=1}^{N} \frac{-x_{3} y_{2} z_{1} + x_{2} y_{3} z_{1} + x_{3} y_{1} z_{2} - x_{1} y_{3} z_{2} - x_{2} y_{1} z_{3} + x_{1} y_{2} z_{3}}{6.0}$$
  - TPU 95A Mass ($\rho = 1.21\,\text{g/cm}^3 = 0.00121\,\text{g/mm}^3$):
    $$\text{Mass} = V_{\text{mm}^3} \times 0.00121\,\text{g/mm}^3$$
  - Thresholds:
    - Bed Contact: $|\text{MinZ}| \le 0.005\,\text{mm}$ (guarantees $Z = 0.000\,\text{mm}$ build plate adhesion).
    - Mass Budget: $0.30\,\text{g} \le \text{Mass} \le 1.20\,\text{g}$ for all individual STL files.
    - Cheek Pair Mass: $0.65\,\text{g} \le \text{Mass} \le 1.15\,\text{g}$ ($0.32\,\text{g} \dots 0.58\,\text{g}$ per pod).
    - Degenerate Triangles: strictly 0 (no zero-area faces, no NaN coordinates).
    - Overhang Draft Angle: For all external downward faces ($z > 0.005\,\text{mm}$, $n_z < -0.01$), the draft angle from vertical must not exceed $45^\circ$. Internal socket ceilings (recess and magnet pockets) are exempted per bridging standards.

### 3.3 Tier 3: Universal Mechanical & Magnetic Interface Standard
- **Objective**: Verify that every part conforms to the physical interface geometry required to snap onto the standardized KODIAK-75 airframe.
- **Zone 1: Top Canopy Crowns (`2001..2400`)**:
  - Annular mating recess: Outer diameter $8.40 \pm 0.05\,\text{mm}$, depth $0.45 \pm 0.05\,\text{mm}$.
  - Male conical shear boss: Base diameter $d_1 = 3.40\,\text{mm}$, top diameter $d_2 = 2.10\,\text{mm}$, height $h = 0.45\,\text{mm}$.
  - Center N52 magnet socket: Diameter $2.10 \pm 0.05\,\text{mm}$, depth $1.20 \pm 0.05\,\text{mm}$, recessed $0.20\,\text{mm}$.
  - Footprint diameter: $16.0\,\text{mm} \dots 17.6\,\text{mm}$.
- **Zones 2 & 3: Cheek Pod Pairs (`2401..2750`)**:
  - Mirrored pair positioning: Symmetrical around $Y = 0$, hubs located at $Y = \pm 15.0\,\text{mm}$ ($30.0\,\text{mm}$ center pitch).
  - Male conical shear boss: $d_1 = 3.40\,\text{mm}$, $d_2 = 2.10\,\text{mm}$, $h = 0.45\,\text{mm}$.
  - N52 magnet pocket: Diameter $2.10\,\text{mm}$, depth $1.20\,\text{mm}$.
  - Clearance: Maximum Z height $\le 3.5\,\text{mm}$ to prevent prop-wash interference with $40\,\text{mm}/45\,\text{mm}$ duct rings.
- **Zone 4: Under-Belly Skids (`2751..3000`)**:
  - Dual mounting posts along X-axis at $X = \pm 18.0\,\text{mm}$ ($36.0\,\text{mm}$ center-to-center pitch).
  - Dual male conical shear bosses: $d_1 = 3.40\,\text{mm}$, $d_2 = 2.10\,\text{mm}$, $h = 0.45\,\text{mm}$.
  - Dual N52 magnet sockets: Diameter $2.10\,\text{mm}$, depth $1.20\,\text{mm}$.
  - Battery channel clearance: Center tunnel width $\ge 18.0\,\text{mm}$ along Y-axis unobstructed for 1S 550mAh LiHV battery docking.

### 3.4 Tier 4: Real-World Loadout & Ecosystem Integration
- **Objective**: Guarantee seamless data and user-interface synchronization across the entire ecosystem.
- **Master Catalog Validation**:
  - `cad/wave4_catalog.json` must contain exactly 1,000 items (`2001..3000`).
  - `cad/kodiak75_catalog_2240.json` must contain all 2,240 cumulative items.
  - Required 16-field JSON schema:
    `partId` (int), `zone` ("crown"|"cheeks"|"belly"), `stl` (string), `code` (string), `name` (string), `theme` (string), `emoji` (string), `c1` (hex), `c2` (hex), `style` (string), `arch` (int), `subvar` (int), `mass` (float), `volMm3` (float), `dims` (string), `tris` (int), `minZ` (float).
  - Mathematical offset formulas:
    - Crowns: $\text{arch} = (\text{partId} - 2001) \pmod{20}$, $\text{subvar} = \lfloor(\text{partId} - 2001) / 20\rfloor$.
    - Cheeks: $\text{arch} = (\text{partId} - 2401) \pmod{14}$, $\text{subvar} = \lfloor(\text{partId} - 2401) / 14\rfloor$.
    - Belly: $\text{arch} = (\text{partId} - 2751) \pmod{10}$, $\text{subvar} = \lfloor(\text{partId} - 2751) / 10\rfloor$.
- **Web Viewer Synchronization**:
  - `OSITO_Kids_Garage_Loadout_Menu.html`:
    - Embedded array entries with `w: 4`.
    - Wave 4 filter button (`id="wave-4"`).
    - Combination math: $896 \times 783 \times 560 = 392,875,520$.
  - `KODIAK75_3D_Viewer.html` & Brain Artifact `kodiak75_interactive_viewer.html`:
    - Embedded dictionaries with `c2001..c2400`, `ch2401..ch2750`, `b2751..b3000`.
    - Wave 4 viewer filter button (`id="vwave-4"`).
    - `getItemWave` returns 4 for `pid >= 2001`.
  - Zero JavaScript syntax errors in all HTML applications.
  - `README.md` updated with 2,240 parts table and 392,875,520 combo statistics.
  - UTF-8 without BOM verification on all generated/updated files.

---

## 4. Test Execution & Usage Guide

The test harness is implemented in `cad/test_wave4_e2e_suite.ps1`.

### 4.1 CLI Syntax
```powershell
# Run the complete 4-Tier test suite (Full mode)
.\cad\test_wave4_e2e_suite.ps1

# Run in Fast mode (spot-checks representative boundary samples across all tiers)
.\cad\test_wave4_e2e_suite.ps1 -Fast

# Run a specific Tier
.\cad\test_wave4_e2e_suite.ps1 -Tier Tier1
.\cad\test_wave4_e2e_suite.ps1 -Tier Tier2 -Fast
.\cad\test_wave4_e2e_suite.ps1 -Tier Tier3
.\cad\test_wave4_e2e_suite.ps1 -Tier Tier4

# Test specific PART_IDs
.\cad\test_wave4_e2e_suite.ps1 -PartIds 2001, 2200, 2401, 2750, 2751, 3000

# Abort on first failure (useful for CI/debugging)
.\cad\test_wave4_e2e_suite.ps1 -StopOnFail

# Generate a structured JSON test report
.\cad\test_wave4_e2e_suite.ps1 -JsonReport "test_report.json"
```

### 4.2 Parameter Reference
| Parameter | Type | Default | Description |
|---|---|---|---|
| `-Tier` | String (`All`, `Tier1`, `Tier2`, `Tier3`, `Tier4`) | `All` | Selects which architectural tier to execute. |
| `-Fast` | Switch | `False` | Spot-checks 15 boundary and representative parts instead of full 1,000-part scan. |
| `-Full` | Switch | `True` (if `-Fast` omitted) | Performs exhaustive verification across all 1,000 STL files and 2,240 catalog entries. |
| `-PartIds` | Int32[] | None | Restricts geometry and interface verification to specified part IDs. |
| `-OpenScadPath` | String | `C:\Program Files\OpenSCAD\openscad.com` | Path to the OpenSCAD console executable. |
| `-StopOnFail` | Switch | `False` | Halts execution immediately upon encountering an assertion failure. |
| `-JsonReport` | String | None | Optional file path for writing machine-readable JSON results. |
| `-VerboseOutput`| Switch | `False` | Enables verbose diagnostics and per-triangle telemetry output. |

### 4.3 Return Codes
- `0`: All assertions passed successfully.
- `1`: One or more assertions failed.

---

## 5. Comprehensive Verification Matrix

| Requirement ID | Acceptance Criterion | Test Tier & Assertion ID | Target Artifact | Verification Method & Pass Rule |
|---|---|---|---|---|
| **R1 / AC 1** | OpenSCAD Syntax & Zero Warnings | Tier 1 (`T1.2`) | `cad/KODIAK75_Wave4_*.scad` | CLI compile with `openscad.com`: STDOUT contains zero `ERROR:`, zero `WARNING:`. |
| **R1 / AC 2** | 2-Manifold Watertightness | Tier 1 (`T1.4`) & Tier 2 (`T2.3`) | CLI STDOUT & `.stl` files | STDOUT contains `Simple: yes`, 0 `EXPORT-WARNING`; C# byte analysis confirms 0 degenerate triangles. |
| **R1 / AC 3** | Flat Bed Adhesion at Z = 0.00mm | Tier 2 (`T2.1`) | Compiled `.stl` files | Binary STL vertex extraction: $|\text{MinZ}| \le 0.005\,\text{mm}$, bed face contact area $> 0$. |
| **R1 / AC 3** | 100% Support-Free Printing | Tier 2 (`T2.4`) | Compiled `.stl` files | C# normal angle evaluation: external downward faces ($z > 0.005\,\text{mm}$) have draft angle $\le 45^\circ$. |
| **R1 / AC 4** | TPU 95A Mass Budget (0.30..1.20g)| Tier 2 (`T2.2`) | Compiled `.stl` files | C# tetrahedral signed volume $\times 0.00121\,\text{g/mm}^3 \in [0.30\,\text{g}, 1.20\,\text{g}]$. |
| **R2 (Crown)** | Zone 1 Standard Interface | Tier 3 (`T3.1`) | `Crowns_A/B.scad` & STLs | Annular recess $8.40 \times 0.45\,\text{mm}$, conical boss $d_1=3.40, d_2=2.10, h=0.45\,\text{mm}$, magnet socket $2.10 \times 1.20\,\text{mm}$. |
| **R2 (Cheek)** | Zones 2 & 3 Mirrored Pods | Tier 3 (`T3.2`) | `Cheeks_A/B.scad` & STLs | Mirrored at $Y = \pm 15.0\,\text{mm}$, top-facing conical boss & $2.10 \times 1.20\,\text{mm}$ magnet socket, $Z \le 3.5\,\text{mm}$. |
| **R2 (Belly)** | Zone 4 Dual Sockets & Pitch | Tier 3 (`T3.3`) | `Belly.scad` & STLs | Dual posts at $X = \pm 18.0\,\text{mm}$ ($36.0\,\text{mm}$ pitch), battery clearance width $\ge 18.0\,\text{mm}$. |
| **R3 (Catalog)**| 2,240-Part Master Catalog | Tier 4 (`T4.1`) | `cad/*catalog*.json` | 16-field schema, continuous sequence 2001..3000, 2,240 cumulative count, STL file presence on disk. |
| **R3 (Viewers)**| Web Viewers & Menu Sync | Tier 4 (`T4.2`) | `.html` files & `README.md` | `w: 4` tags, `wave-4`/`vwave-4` buttons, combo math $392,875,520$, zero JS syntax errors. |
| **R4** | Local CLI & UTF-8 No BOM | Tier 4 (`T4.3`) | All generated files | Runs locally on `openscad.com`; 0 bytes of BOM (`EF BB BF` absent) across all `.scad`, `.ps1`, `.json`, `.html`, `.md`. |

---

## 6. Implementation Defect Escalation Protocol

As the QA & Test Writer, this test harness operates under strict escalation rules:
1. **Defects in Implementation**: If an OpenSCAD model, batch compiler, catalog generator, or web synchronizer produces failing assertions, the defect is documented with exact file, line number, observed output, and expected output, and escalated to the implementing subagent. Test code is never modified to accommodate broken implementation code.
2. **Defects in Test Suite**: If a test case contains an incorrect expectation contrary to `ORIGINAL_REQUEST.md`, the test writer corrects the test assertion.
3. **Traceability**: All test executions log full assertion metrics, failure diagnoses, and timestamps to ensure reproducible verification audits.
