# OSITO-KODIAK-G473 (Rev 1.0): Custom 1S All-in-One Flight Controller Specification
**Organization:** Osito Drone Services (`ositodrone.com`)  
**Board Codename:** `OSITO_KODIAK_FC_v1` (`board_name BETAFPVG473` 100% Drop-In Firmware Compatible)  
**Manufacturing Target:** **JLCPCB Turnkey SMT Assembly** (4-Layer `1.0mm` FR4, `2oz` Outer Copper, ENIG Finish, 100% Top-Side Single-Pass SMT)  
**Estimated Turnkey Cost (at 20–50 pcs):** **~$15.80 / assembled board** (vs. $44.99 retail COTS)

---

## 1. Why This Custom Board Is Built Specifically for the KODIAK-75
Standard commercial Tiny Whoop flight controllers require hand-soldering external LED strips, have fragile micro-USB ports on the bottom that dent under-belly batteries, and lack native hit-scoring sensors. The **`OSITO-KODIAK-G473`** solves every single production headache in one **100% Single-Sided Top-Mount PCB**:

1. **100% Zero-Solder Assembly (10× Onboard `WS2812B-2020` RGB LEDs Built Right Into the PCB!):**
   * Ten ultra-bright `2.0mm × 2.0mm` addressable RGB LEDs (`LED1`–`LED10`) are factory-soldered directly onto the top perimeter and center of the board:
     * **`LED1` & `LED2` (Front-Left `M4` Quadrant):** High-Intensity Green/White Nose Orientation Vector.
     * **`LED3` & `LED4` (Front-Right `M2` Quadrant):** High-Intensity Green/White Nose Orientation Vector.
     * **`LED5` & `LED6` (Rear-Right `M1` Quadrant):** Team Red / Team Blue Tail ID.
     * **`LED7` & `LED8` (Rear-Left `M3` Quadrant):** Team Red / Team Blue Tail ID.
     * **`LED9` & `LED10` (Center Top Dome Apex):** Illuminates the translucent `KODIAK75_Deck_LOS_v1` dome and glowing toppers (`Siren Lightbar`, `Osito Bear Ears`) from the inside!
2. **100% Firmware Compatibility with `BETAFPVG473` & `Bluejay 48kHz`:**
   * By matching the exact GPIO pin map of the locked **`BETAFPVG473`** Betaflight 4.5+ target (`STM32G473CEU6` MCU + `ICM-42688-P` SPI1 Gyro + `EFM8BB21F16G` 12A ESCs + `UART2` ELRS 2.4GHz), you never have to maintain custom C++ firmware branches—just flash standard **Betaflight `BETAFPVG473`** and load [`firmware/KODIAK75_Betaflight45_Full_BumperTag.txt`](../firmware/KODIAK75_Betaflight45_Full_BumperTag.txt)!
3. **True Flat Bottom Layer (100% Top-Side SMT Placement):**
   * Every single IC, MOSFET, capacitor, `JST-1.25` motor socket, and side-facing `USB-C` / `SH1.0` port sits on **`F.Cu` (Top Layer)**.
   * **`B.Cu` (Bottom Layer)** is 100% smooth soldermask over a solid ground/heat-spreader plane, guaranteeing zero sharp pins above the `1S 550mAh LiHV` pouch cell and cutting JLCPCB SMT setup fees in half (single-sided assembly).
4. **Electronic Magnetic Armor Hit-Detection Header (`J_HIT` 3-Pin `SH1.0`):**
   * Includes an onboard digital Hall-effect magnetic field sensor (`U8: DRV5032FADBZR`) and `J_HIT` expansion port connected to `PB0 / PINIO2` so knocking off the Top Crown N52 magnet can automatically trigger an LED strobe flash and telemetry hit-counter!

---

## 2. Mechanical PCB Outline & Stackup Specification

```text
================================================================================
       OSITO-KODIAK-G473: TOP-DOWN PCB LAYOUT (28.5 x 28.5mm DIAMOND)
                        [ +Y: NOSE / FORWARD ]
                               (0, +14.25)
                                  /\
                                 /  \
                                / M2 \  <-- North M2 Hole (0, +11.0 / Frame Boss)
           [J_M4: Motor 4]     / (O)  \     [J_M2: Motor 2]
           (JST-1.25 3P)      /        \      (JST-1.25 3P)
                 \           / LED1 LED3\           /
                  \   ┌─────/────────────\─────┐   /
                   \  │ [U4:ESC]    [U3:5V BEC]│  /
                    \ │                        │ /
       West M2 Hole  \│  [U2: ICM-42688 Gyro]  │/  East M2 Hole
      (-11.0, 0) (O)──┤      [LED9][LED10]     ├──(O) (+11.0, 0)
                    / │  [U1: STM32G473CEU6]   │ \
                   /  │                        │  \
                  /   │ [U5:ELRS]   [J_CAM 3P] │   \
                 /    └─────\────────────/─────┘    \
           [J_M3: Motor 3]   \ LED7 LED5/   [J_M1: Motor 1]
           (JST-1.25 3P)      \        /      (JST-1.25 3P)
                               \ (O)  /  <-- South M2 Hole (0, -11.0)
                                \ M2 /
                                 \  /
                              [BT2.0 PADS]
                        [ -Y: TAIL / BATTERY ]
================================================================================
* Note: Standard Whoop 25.5mm x 25.5mm square mounting holes rotated 45° into
  Cardinal Diamond sit at radius R = 18.031mm:
  North: (0, +18.031mm) | East: (+18.031mm, 0) | South: (0, -18.031mm) | West: (-18.031mm, 0)
```

* **Board Outline:** Contoured Cardinal Diamond (`39.0mm` point-to-point across M2 ears; `26.0mm` across the 45° diagonal waists so `40mm`/`45mm` propeller tips have generous radial clearance).
* **Mounting Holes:** 4× `2.15mm` unplated holes at `(0, +18.031mm)`, `(+18.031mm, 0)`, `(0, -18.031mm)`, and `(-18.031mm, 0)` with `4.8mm` silicone grommet seating lands.
* **4-Layer PCB Stackup (`1.0mm` Total Thickness):**
  * **`L1 (F.Cu - Top, 2oz / 70µm)`:** High-current ESC power routing, `STM32G473` signal traces, `2.4GHz` 50Ω coplanar waveguide antenna trace, and all SMT pads.
  * **`L2 (In1.Cu - Inner GND, 1oz / 35µm)`:** Unbroken solid ground reference plane (shields the `ICM-42688-P` gyro from ESC switching noise).
  * **`L3 (In2.Cu - Inner Power, 1oz / 35µm)`:** Split `+VBAT` (1S `3.3V–4.35V`), `+5V_BEC` (`2A` continuous for LEDs + FPV pod), and `+3V3_MCU` / `+3V3_GYRO` planes.
  * **`L4 (B.Cu - Bottom, 2oz / 70µm)`:** Bare component-free thermal ground copper pour covered in matte black soldermask with gold ENIG Osito bear silkscreen logo.

---

## 3. CompleteSTM32G473CEU6 Pinout & Subsystem Architecture

| Subsystem | Reference Designator & IC | STM32G473 Pin / Bus | Engineering Function |
| :--- | :--- | :--- | :--- |
| **Main Flight MCU** | `U1`: **STM32G473CEU6** (`UFQFPN-48`, `170MHz` Cortex-M4F) | `8MHz` HSE Crystal (`Y1`) | Runs Betaflight 4.5+ (`BETAFPVG473` target) at `8kHz/8kHz` PID loop with FPU math. |
| **Low-Noise 6-Axis Gyro** | `U2`: **ICM-42688-P** (`LGA-14`) + `U6`: **RT9013-33GB** LDO | `SPI1` (`SCK=PA5`, `MISO=PA6`, `MOSI=PA7`, `CS=PA4`, `EXTI=PC4`) | Dedicated ultra-low-noise `3.3V` LDO + `10uF` decoupling ensures clean `<500ms` `crash_recovery` without gyro saturation on bumper impacts. |
| **12A Continuous 4-in-1 ESC** | `U4`: **EFM8BB21F16G-C-QFN20** (x4) + `Q1..Q12`: **AON7428 / Dual 30V 18A N-FETs** | `MOTOR 1=PB1`, `MOTOR 2=PB0`, `MOTOR 3=PA3`, `MOTOR 4=PA2` | Pre-flashed with **Bluejay `O-H-5 48kHz`** for Bidirectional DShot300 RPM filtering and instant Turtle Mode motor reversal. |
| **Plug-In Motor Headers** | `J_M1`, `J_M2`, `J_M3`, `J_M4`: **JST-1.25mm 3-Pin SMD Vertical** | 3-Phase ESC Outputs (`A, B, C`) | Zero-solder 30-second plug-and-play motor replacement at events. |
| **Onboard ELRS 2.4GHz RX** | `U5`: **ESP8285H16** + `U7`: **SX1281IMLTRT** + `2.4GHz` Ceramic Chip Antenna (`ANT1`) | `UART2` (`TX2=PA2/PB3`, `RX2=PA3/PB4`, `CRSF` at `420000` baud) | Integrated Serial ExpressLRS 2.4GHz receiver with built-in SMD ceramic antenna (no wire antenna for opponent props to chop!). |
| **5V / 2A Buck-Boost BEC** | `U3`: **TPS63020DSJR** (`2A` 1S Buck-Boost Converter) | Powers `+5V` rail from `2.5V` down to `4.35V` | Guarantees rock-solid `5.0V` for the 10 onboard RGB LEDs and FPV camera even when the 1S battery sags to `3.3V` during full-throttle punches. |
| **10× Onboard RGB LEDs** | `LED1`–`LED10`: **WS2812B-2020** (`2.0×2.0mm` Addressable RGB) | `LED_STRIP = PB8` (via `330Ω` series resistor `R_LED`) | 4× Front Nose LEDs + 4× Rear Team LEDs + 2× Center Dome LEDs built directly onto the PCB (zero hand wiring!). |
| **FPV Camera & VTX Pod Port** | `J_CAM`: **JST-SH 1.0mm 4-Pin SMD** (`+5V`, `GND`, `OSD_OUT`, `CAM_IN`) + `U9: AT7456E` OSD | `SPI2` (`AT7456E` OSD) + `UART1` (`SmartAudio`) | Single 4-pin plug connects the optional `Deck_FPV_v1` camera/VTX pod in 60 seconds. |
| **Armor Hit-Detection Sensor** | `U8`: **DRV5032FADBZR** (Omnipolar Hall Sensor) | `PC13 / PINIO1` | Senses magnetic flux changes when the Top Crown N52 Armor Plate is knocked off in mid-air. |
| **Side USB-C Dongle Port** | `J_USB`: **JST-SH 1.0mm 4-Pin Right-Angle** (`VBUS`, `D-`, `D+`, `GND`) | `PA11` (`USB_DM`), `PA12` (`USB_DP`) | Connects to external USB-C adapter board (keeps bottom of PCB 100% flat). |
| **Plug-and-Play Battery Socket** | `J_BAT`: **Right-Angle SMD `BT2.0` / `A30` Male Connector** (`C2918210`) | `+VBAT` & `GND` (via `0.5mΩ` Shunt `R_SHUNT`) | Factory-mounted SMD battery connector at the rear 6 o'clock edge—**100% zero soldering required!** |
| **External LED Expansion Port** | `J_LED_EXT`: **JST-SH 1.0mm 3-Pin Right-Angle** (`+5V`, `GND`, `LED_DOUT`) | Daisy-chained from `LED10` (`PB8`) | Optional plug-and-play socket if you ever want to plug in an extra halo LED ring with zero soldering. |

---

## 4. How to Order Assembled Boards from JLCPCB in 3 Minutes
1. Go to **`jlcpcb.com`** and upload [`OSITO_KODIAK_FC_v1.kicad_pcb`](./OSITO_KODIAK_FC_v1.kicad_pcb) (or export Gerbers from KiCad `File -> Plot`).
2. Select **4 Layers**, **`1.0mm` Thickness**, **Black Soldermask**, **ENIG Surface Finish**, and **`2oz` Outer Copper Weight**.
3. Enable **PCB Assembly (PCBA)** $\rightarrow$ Select **Top Side Only**.
4. Upload [`OSITO_KODIAK_FC_JLCPCB_BOM.csv`](./OSITO_KODIAK_FC_JLCPCB_BOM.csv) and [`OSITO_KODIAK_FC_JLCPCB_CPL.csv`](./OSITO_KODIAK_FC_JLCPCB_CPL.csv). Every component uses verified `LCSC` part numbers (`Cxxxxx`).
