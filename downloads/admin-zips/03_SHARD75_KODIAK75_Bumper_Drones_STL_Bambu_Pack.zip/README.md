# Osito Bumper Drones: KODIAK-75 Master Project Index

**Organization:** Osito Drone Services (`ositodrone.com` • Youth STEM, Micro-Aviation & Flight Academy)  
**Aircraft Name:** **KODIAK-75** (*Kinetic Omnidirectional Defensive Impact Arena Kodiak*)  
**Activity Name:** **Aerial Bumper Tag** (Inside a $101\text{"} \times 101\text{"}$ Pop-Up Netted Arena Tent)

---

## 1. Executive Summary of the KODIAK-75 Architecture

The **KODIAK-75** is an in-house 3D-printed, single-cell (`1S 550mAh LiHV`) aerial bumper-tag micro-drone (~$36\text{–}39\text{g}$ ready-to-play) engineered specifically for kids' birthday events, Maker Faire booths, and Youth STEM academies:

1. **Parent- & School-Safe "Bumper Cars in the Air" Gameplay:**
   * Each drone carries **4 magnetic breakaway Armor Plates / Mod-Pods** (**Top Crown** = 2 pts, **Left/Right Cheek Pods** = 1 pt each, **Under-Belly Skid Plate** = 1 pt).
   * When two drones bump in mid-air, the magnetic armor pieces pop off to score points while **Betaflight Active Crash Recovery** automatically re-levels the drone in $<0.5\text{ seconds}$ so the match keeps going without crashes or prop replacements.
2. **360° Prop-Protected Carbon-Composite Frame (`v2`):**
   * Printed in-house on a **Bambu Lab P1S** in **ePA-CF (Nylon Carbon Fiber)** or **PC-CF**, with a raised $8.5\text{ mm}$ outer perimeter guard wall aligned with the spinning propeller plane so blades can never snag the tent mesh.
   * Two verified wheelbase variants included in `cad/`:
     * **`KODIAK75_Frame_Protected_v2.stl`:** $75.0\text{ mm}$ wheelbase with $42.0\text{ mm}$ ID hoops for **`40mm` bi-blade props** (Gemfan 1610).
     * **`KODIAK75_Frame_Protected_80Pro_45mm.stl`:** $80.8\text{ mm}$ wheelbase with $47.0\text{ mm}$ ID hoops for **`45mm` bi-blade props** (Meteor75 Pro sizing).
3. **60-Second Dual-Mode Upper Deck (LOS vs. FPV):**
   * **Line-of-Sight (LOS) Dome:** Translucent `TPU 95A` dome with bright Green/White nose LEDs and Red/Blue team tail LEDs so beginners can play from outside the tent.
   * **FPV Camera Pod:** Swaps onto the same four `M2` nylon stack screws in 60 seconds for goggle cockpit play.
4. **Unobstructed 1S 550mAh Belly Cradle & Anti-Shatter N52 Magnet Sockets:**
   * Outboard Left/Right `M2` mounting wings keep the $70.0 \times 18.5 \times 7.5\text{ mm}$ battery tunnel 100% clear for 5–6 minute match endurance.
   * All ten $2\text{ mm} \times 1\text{ mm}$ N52 neodymium magnets (`5x` on Drone Sockets = North-Out + `5x` on Removable Plates/Pods = South-Out) sit $0.20\text{ mm}$ recessed inside $2.10 \times 1.20\text{ mm}$ `TPU 95A` pockets with $0.45\text{ mm}$ conical shear keyways (`d1 = 3.40mm, d2 = 2.10mm`) so magnets never shatter on impact and never slide off during 15G turns.
5. **Osito Garage — 2,500-Part Universal Snap-On Kid Customization Ecosystem (`550,069,884` Combinations!) & Live Clicked-Object 3D Visual Inspector:**
   * Kids can mix-and-match **1,000 Wave 4 Production Sacrificial Parts (`PART_ID = 2001..3000`) + 1,000 Wave 3 Mega-1000 Creative Objects (`PART_ID = 1001..2000`) + 100 Creative Wave 2 `TPU 95A` sacrificial parts (`PART_ID = 401..440, 501..535, 601..625`) + 100 Osito Wave 1 parts (`PART_ID = 101..140, 201..235, 301..325`) + 36 Kid Customization Pack parts (`PART_ID = 1..36`) + 4 Classic EPP/TPU Armor Plates** (**996 Top Crowns** × **867 Cheek Pod Pairs** × **637 Belly Skids** = **550,069,884 unique drone loadouts**) in 3 seconds with zero tools—every piece uses the exact same universal magnetic + conical shear-keyway sockets and prints 100% flat at `Z = 0.00mm` without supports!
   * Both the **Interactive 3D CAD Viewer (`KODIAK75_3D_Viewer.html`)** and the **Printable & Interactive Kid's Garage Menu (`OSITO_Kids_Garage_Loadout_Menu.html`)** feature a **Live Clicked-Object 3D Visual Inspector** (with Wave Filters & Instant Search) that renders a rotating close-up 3D visual preview of any clicked part alongside its `.stl` filename, mass, zone, and `2.10×1.20mm` N52 + `0.45mm` conical shear boss geometry.

---

## 2. Complete File Directory (`Bumper Drones/`)

### Engineering, PRDs & Bench Manuals
* **[`KODIAK75_Finished_On_Desk.jpg`](./KODIAK75_Finished_On_Desk.jpg)** — Finished Product Photograph on Maker Workbench with Snap-On Mod-Pods.
* **[`KODIAK-75_PRD_and_Blueprint.md`](./KODIAK-75_PRD_and_Blueprint.md)** — Full Engineering Blueprint & Product Requirements Document.
* **[`KODIAK75_Developer_Handoff_PRD.md`](./KODIAK75_Developer_Handoff_PRD.md)** & **[`.html`](./KODIAK75_Developer_Handoff_PRD.html)** — Contractor / CAD Engineer Scope of Work & Milestone Spec.
* **[`KODIAK75_Printable_Build_Manual.html`](./KODIAK75_Printable_Build_Manual.html)** — 2-Page 8.5"×11" Printable Workbench Build & QA Checklist.
* **[`SHOP_ASSEMBLY_AND_JIG_GUIDE.md`](./SHOP_ASSEMBLY_AND_JIG_GUIDE.md)** — Master Magnet Polarity Wand Protocol & Wiring Guide.
* **[`KODIAK75_BOM_and_Sourcing.md`](./KODIAK75_BOM_and_Sourcing.md)** & **[`.csv`](./KODIAK75_BOM_and_Sourcing.csv)** — Per-Drone (\$101.44 LOS / \$121.43 FPV) & 2-Drone Turnkey Arena Kit (\$607.88) BOM.
* **[`3D_PRINTER_BUYING_GUIDE.md`](./3D_PRINTER_BUYING_GUIDE.md)** — Bambu Lab P1S + Hardened Steel Upgrade + 70°C Dryer shopping list.

### Event Flyer, Kid's Garage Menu, Live Scoreboard & 3D Customizer
* **[`OSITO_KODIAK75_Event_Handout.html`](./OSITO_KODIAK75_Event_Handout.html)** — Printable Parent / Maker Faire / Birthday Flyer.
* **[`OSITO_Kids_Garage_Loadout_Menu.html`](./OSITO_Kids_Garage_Loadout_Menu.html)** — Printable & Interactive **2,500-Part** "Build-Your-Kodiak" Kid's Pit-Table Loadout Menu with **Live Clicked-Object 3D Visual Inspector**, Wave Filter & Search Bar, & Auto-Calculating STEM CoG Pit-Pass (**550,069,884 combinations**).
* **[`KODIAK75_Arena_Scoreboard.html`](./KODIAK75_Arena_Scoreboard.html)** — Full-Screen 3:00 Match Timer & Red vs. Blue Scoreboard App.
* **[`KODIAK75_3D_Viewer.html`](./KODIAK75_3D_Viewer.html)** — Interactive 3D Exploded Stackup, Breakaway Armor, **Close-Up Clicked Object 3D Inspector Canvas (`#partPreviewCanvas`)**, & **2,500-Part Osito Garage Customizer**.

### 3D Printable CAD (`cad/`), Slicer Profiles (`slicer/`) & Firmware (`firmware/`)
* **[`cad/KODIAK75_Parametric_Master.scad`](./cad/KODIAK75_Parametric_Master.scad)** — Master OpenSCAD CSG source file for the airframe, decks, cradle, and wand.
* **[`cad/KODIAK75_Kid_Customization_Pack.scad`](./cad/KODIAK75_Kid_Customization_Pack.scad)** — Parametric OpenSCAD source for the initial **36 Kid Customization Sacrificial Parts (`PART_ID = 1..36`)**.
* **[`cad/KODIAK75_Osito_100_Parts.scad`](./cad/KODIAK75_Osito_100_Parts.scad)** — Master OpenSCAD source for the **100 Wave 1 Osito-Themed Sacrificial Parts (`PART_ID = 101..140, 201..235, 301..325`)**, plus **`cad/compile_and_verify_osito_100_parts.ps1`**.
* **[`cad/KODIAK75_Creative_Wave2_100_Parts.scad`](./cad/KODIAK75_Creative_Wave2_100_Parts.scad)** — Master OpenSCAD source for the **100 Wave 2 Creative Sacrificial Parts (`PART_ID = 401..440, 501..535, 601..625`)** across Food & Candy, Dino & Mythic, Space & Alien, and Arcade & Pirate themes, plus **`cad/compile_and_verify_wave2_100_parts.ps1`**.
* **[`cad/KODIAK75_Wave4_Master.scad`](./cad/KODIAK75_Wave4_Master.scad)**, **[`cad/wave4_catalog.json`](./cad/wave4_catalog.json)** & **[`cad/kodiak75_catalog_2500.json`](./cad/kodiak75_catalog_2500.json)** — Master OpenSCAD Router and 2,500-Cumulative Parts Catalog for **Wave 4: Production Sacrificial Customization (`PART_ID = 2001..3000`)**, spanning:
  * **[`cad/KODIAK75_Wave4_Crowns_A.scad`](./cad/KODIAK75_Wave4_Crowns_A.scad)** (`PART_ID = 2001..2200` — 200 Top Crowns across 20 creative worlds).
  * **[`cad/KODIAK75_Wave4_Crowns_B.scad`](./cad/KODIAK75_Wave4_Crowns_B.scad)** (`PART_ID = 2201..2400` — 200 Top Crowns across 20 creative worlds).
  * **[`cad/KODIAK75_Wave4_Cheeks_A.scad`](./cad/KODIAK75_Wave4_Cheeks_A.scad)** (`PART_ID = 2401..2575` — 175 L/R Cheek Pod Pairs across 14 aerodynamic archetypes).
  * **[`cad/KODIAK75_Wave4_Cheeks_B.scad`](./cad/KODIAK75_Wave4_Cheeks_B.scad)** (`PART_ID = 2576..2750` — 175 L/R Cheek Pod Pairs across 14 aerodynamic archetypes).
  * **[`cad/KODIAK75_Wave4_Belly.scad`](./cad/KODIAK75_Wave4_Belly.scad)** (`PART_ID = 2751..3000` — 250 Dual-Magnet Under-Belly Skids across 10 terrain archetypes).
* **[`cad/KODIAK75_Mega1000_Master.scad`](./cad/KODIAK75_Mega1000_Master.scad)** & **[`cad/mega1000_catalog.json`](./cad/mega1000_catalog.json)** — Master OpenSCAD Router and 1,000-Object Parametric Catalog for **Wave 3: The Mega-1000 Collection (`PART_ID = 1001..2000`)**, split across 5 high-speed print-farm libraries:
  * **[`cad/KODIAK75_Mega1000_Crowns_A.scad`](./cad/KODIAK75_Mega1000_Crowns_A.scad)** (`PART_ID = 1001..1200` — 200 Top Crowns across 10 Creative Worlds, compiled via `cad/compile_mega1000_crowns_a.ps1`).
  * **[`cad/KODIAK75_Mega1000_Crowns_B.scad`](./cad/KODIAK75_Mega1000_Crowns_B.scad)** (`PART_ID = 1201..1400` — 200 Top Crowns across 10 Creative Worlds, compiled via `cad/compile_mega1000_crowns_b.ps1`).
  * **[`cad/KODIAK75_Mega1000_Cheeks_A.scad`](./cad/KODIAK75_Mega1000_Cheeks_A.scad)** (`PART_ID = 1401..1575` — 175 L/R Cheek Pod Pairs, compiled via `cad/compile_mega1000_cheeks_a.ps1`).
  * **[`cad/KODIAK75_Mega1000_Cheeks_B.scad`](./cad/KODIAK75_Mega1000_Cheeks_B.scad)** (`PART_ID = 1576..1750` — 175 L/R Cheek Pod Pairs, compiled via `cad/compile_mega1000_cheeks_b.ps1`).
  * **[`cad/KODIAK75_Mega1000_Belly.scad`](./cad/KODIAK75_Mega1000_Belly.scad)** (`PART_ID = 1751..2000` — 250 Dual-Magnet Under-Belly Skids, compiled via `cad/compile_mega1000_belly.ps1`).
* **[`cad/KODIAK75_Frame_Protected_v2.stl`](./cad/KODIAK75_Frame_Protected_v2.stl)** — 75.0mm 360° Prop-Protected Frame (`42.0mm` ID hoops for `40mm` props).
* **[`cad/KODIAK75_Frame_Protected_80Pro_45mm.stl`](./cad/KODIAK75_Frame_Protected_80Pro_45mm.stl)** — 80.8mm 360° Prop-Protected Frame (`47.0mm` ID hoops for `45mm` props).
* **[`cad/KODIAK75_550Cradle_v1.stl`](./cad/KODIAK75_550Cradle_v1.stl)** — TPU 95A 1S 550mAh Under-Belly Battery Cradle.
* **[`cad/KODIAK75_Deck_LOS_v1.stl`](./cad/KODIAK75_Deck_LOS_v1.stl)** & **[`KODIAK75_Deck_FPV_v1.stl`](./cad/KODIAK75_Deck_FPV_v1.stl)** — Swappable Upper Decks.
* **[`cad/KODIAK75_ArmorPlates_v1.stl`](./cad/KODIAK75_ArmorPlates_v1.stl)** & **[`KODIAK75_Magnet_Polarity_Wand.stl`](./cad/KODIAK75_Magnet_Polarity_Wand.stl)** — Classic Armor Cups (`0.45mm` shear boss) & Polarity Tool.

#### A. Wave 2: 100-Part Creative Sacrificial `.stl` Expansion Pack (`cad/KODIAK75_Creative_Wave2_100_Parts.scad`)
* **40 New Creative Top Canopy Crowns (`PART_ID = 401..440`, `1x N52`):**
  * *Food & Candy (`401..410`):* `KODIAK75_Crown_TacoShell.stl`, `KODIAK75_Crown_BurgerStack.stl`, `KODIAK75_Crown_PizzaSlice.stl`, `KODIAK75_Crown_IceCreamCone.stl`, `KODIAK75_Crown_SprinkleDonut.stl`, `KODIAK75_Crown_FryBox.stl`, `KODIAK75_Crown_CupcakeSwirl.stl`, `KODIAK75_Crown_GummyBear.stl`, `KODIAK75_Crown_BobaTea.stl`, `KODIAK75_Crown_ChefToque.stl`.
  * *Dino & Mythic (`411..420`):* `KODIAK75_Crown_TRexJaw.stl`, `KODIAK75_Crown_TriceraFrill.stl`, `KODIAK75_Crown_PteroCrest.stl`, `KODIAK75_Crown_AnkyloClub.stl`, `KODIAK75_Crown_HydraTriHead.stl`, `KODIAK75_Crown_PhoenixPlume.stl`, `KODIAK75_Crown_GriffinBeak.stl`, `KODIAK75_Crown_KrakenHelm.stl`, `KODIAK75_Crown_MinotaurHorns.stl`, `KODIAK75_Crown_GargoyleCrest.stl`.
  * *Space & Alien (`421..430`):* `KODIAK75_Crown_UFOSaucer.stl`, `KODIAK75_Crown_AlienTriEye.stl`, `KODIAK75_Crown_AstroVisor.stl`, `KODIAK75_Crown_RocketSpire.stl`, `KODIAK75_Crown_WarpCrystal.stl`, `KODIAK75_Crown_RaygunTurret.stl`, `KODIAK75_Crown_SaturnRing.stl`, `KODIAK75_Crown_LunarRadar.stl`, `KODIAK75_Crown_MeteorCrater.stl`, `KODIAK75_Crown_StargateArch.stl`.
  * *Arcade & Pirate (`431..440`):* `KODIAK75_Crown_PixelHeart.stl`, `KODIAK75_Crown_ArcadeJoystick.stl`, `KODIAK75_Crown_TrophyCup.stl`, `KODIAK75_Crown_KingChess.stl`, `KODIAK75_Crown_PirateTricorn.stl`, `KODIAK75_Crown_SubPeriscope.stl`, `KODIAK75_Crown_Hammerhead.stl`, `KODIAK75_Crown_NarwhalTusk.stl`, `KODIAK75_Crown_VikingShip.stl`, `KODIAK75_Crown_DiscoBall.stl`.
* **35 New Creative Left/Right Cheek Pod Pairs (`PART_ID = 501..535`, `2x N52`):**
  * *Food & Candy (`501..508`):* `KODIAK75_Cheek_HotDogPods.stl`, `KODIAK75_Cheek_PopsicleTwins.stl`, `KODIAK75_Cheek_WaffleGrids.stl`, `KODIAK75_Cheek_PretzelLoops.stl`, `KODIAK75_Cheek_CandyCanes.stl`, `KODIAK75_Cheek_CookieShields.stl`, `KODIAK75_Cheek_CroissantHorns.stl`, `KODIAK75_Cheek_WatermelonWedges.stl`.
  * *Dino & Mythic (`509..515`):* `KODIAK75_Cheek_WyvernWings.stl`, `KODIAK75_Cheek_RaptorClaws.stl`, `KODIAK75_Cheek_StegoSpikes.stl`, `KODIAK75_Cheek_PteroGliders.stl`, `KODIAK75_Cheek_PhoenixWings.stl`, `KODIAK75_Cheek_KrakenArms.stl`, `KODIAK75_Cheek_PegasusWings.stl`.
  * *Space & Alien (`516..522`):* `KODIAK75_Cheek_SolarPanels.stl`, `KODIAK75_Cheek_IonCannons.stl`, `KODIAK75_Cheek_AsteroidPods.stl`, `KODIAK75_Cheek_PlasmaCoils.stl`, `KODIAK75_Cheek_StarCruiserFins.stl`, `KODIAK75_Cheek_GravityRings.stl`, `KODIAK75_Cheek_AlienBlasters.stl`.
  * *Arcade & Pirate (`523..535`):* `KODIAK75_Cheek_BoxingGloves.stl`, `KODIAK75_Cheek_PixelSwords.stl`, `KODIAK75_Cheek_CheckeredFlags.stl`, `KODIAK75_Cheek_SpeakerSubs.stl`, `KODIAK75_Cheek_PinballFlippers.stl`, `KODIAK75_Cheek_FootballPads.stl`, `KODIAK75_Cheek_CrabClaws.stl`, `KODIAK75_Cheek_PirateCannons.stl`, `KODIAK75_Cheek_AnchorShields.stl`, `KODIAK75_Cheek_TorpedoTubes.stl`, `KODIAK75_Cheek_MantaWings.stl`, `KODIAK75_Cheek_SeahorseFins.stl`, `KODIAK75_Cheek_CompassRoses.stl`.
* **25 New Creative Dual-Magnet Under-Belly Skids (`PART_ID = 601..625`, `2x N52 at 36.0mm pitch`):**
  * *Food & Candy (`601..605`):* `KODIAK75_Belly_BananaPeelSkids.stl`, `KODIAK75_Belly_ChurroRails.stl`, `KODIAK75_Belly_SushiRollSled.stl`, `KODIAK75_Belly_ChocolateBar.stl`, `KODIAK75_Belly_BaconStrips.stl`.
  * *Dino & Mythic (`606..610`):* `KODIAK75_Belly_DinoTracks.stl`, `KODIAK75_Belly_DragonTailSled.stl`, `KODIAK75_Belly_FossilRibs.stl`, `KODIAK75_Belly_LavaRockSled.stl`, `KODIAK75_Belly_TurtleShell.stl`.
  * *Space & Alien (`611..615`):* `KODIAK75_Belly_LunarLanderPads.stl`, `KODIAK75_Belly_MarsRoverWheels.stl`, `KODIAK75_Belly_WarpSled.stl`, `KODIAK75_Belly_TractorBeam.stl`, `KODIAK75_Belly_HeatshieldTiles.stl`.
  * *Arcade & Pirate (`616..625`):* `KODIAK75_Belly_MonsterTruckTires.stl`, `KODIAK75_Belly_RollerSkates.stl`, `KODIAK75_Belly_HockeySticks.stl`, `KODIAK75_Belly_GamepadSled.stl`, `KODIAK75_Belly_SoccerCleats.stl`, `KODIAK75_Belly_PirateGalleon.stl`, `KODIAK75_Belly_TreasureChest.stl`, `KODIAK75_Belly_SubmarineKeel.stl`, `KODIAK75_Belly_LobsterTail.stl`, `KODIAK75_Belly_OutriggerCanoe.stl`.

#### B. Wave 1: 100-Part Osito-Themed Sacrificial `.stl` Expansion Pack (`cad/KODIAK75_Osito_100_Parts.scad`)
* **40 New Osito Top Canopy Crowns (`PART_ID = 101..140`, `1x N52`, `0.58g–1.18g`):**
  * *Osito Bear & Forest Lore (`101..120`):* `KODIAK75_Crown_GrizzlySnarl.stl`, `KODIAK75_Crown_KodiakRoar.stl`, `KODIAK75_Crown_PolarCrown.stl`, `KODIAK75_Crown_PandaBamboo.stl`, `KODIAK75_Crown_SunBearCrest.stl`, `KODIAK75_Crown_HoneycombDipper.stl`, `KODIAK75_Crown_PineconeCrest.stl`, `KODIAK75_Crown_AntlerSpikes.stl`, `KODIAK75_Crown_WolfHowl.stl`, `KODIAK75_Crown_EagleTalon.stl`, `KODIAK75_Crown_OwlCrest.stl`, `KODIAK75_Crown_BadgerMohawk.stl`, `KODIAK75_Crown_SalmonFin.stl`, `KODIAK75_Crown_ForestCanopy.stl`, `KODIAK75_Crown_AcornSprout.stl`, `KODIAK75_Crown_MapleLeaf.stl`, `KODIAK75_Crown_MountainRidge.stl`, `KODIAK75_Crown_RiverCrest.stl`, `KODIAK75_Crown_BerryBunch.stl`, `KODIAK75_Crown_HibernateHelmet.stl`.
  * *Mecha-Kodiak & Cyber-Aero (`121..140`):* `KODIAK75_Crown_CyberBearVisor.stl`, `KODIAK75_Crown_MechaMohawk.stl`, `KODIAK75_Crown_BattleHelm.stl`, `KODIAK75_Crown_TitaniumCrest.stl`, `KODIAK75_Crown_RadarDome.stl`, `KODIAK75_Crown_TurboScoop.stl`, `KODIAK75_Crown_StealthFin.stl`, `KODIAK75_Crown_PlasmaHorn.stl`, `KODIAK75_Crown_VortexCannon.stl`, `KODIAK75_Crown_SonicDish.stl`, `KODIAK75_Crown_EMPSpike.stl`, `KODIAK75_Crown_ShieldCrest.stl`, `KODIAK75_Crown_AfterburnerCowl.stl`, `KODIAK75_Crown_HeavyBumper.stl`, `KODIAK75_Crown_EnergyCrest.stl`, `KODIAK75_Crown_NitroFin.stl`, `KODIAK75_Crown_CarbonFin.stl`, `KODIAK75_Crown_CyberClaws.stl`, `KODIAK75_Crown_NeonCrest.stl`, `KODIAK75_Crown_OrbitalBeacon.stl`.
* **35 New Osito Left/Right Cheek Pod Pairs (`PART_ID = 201..235`, `2x N52`, `0.83g–1.15g` per pair):**
  * *Osito Bear & Forest Lore (`201..215`):* `KODIAK75_Cheek_BearPaws.stl`, `KODIAK75_Cheek_CubEars.stl`, `KODIAK75_Cheek_GrizzlyWhiskers.stl`, `KODIAK75_Cheek_SalmonSkiffs.stl`, `KODIAK75_Cheek_PineNeedles.stl`, `KODIAK75_Cheek_ForestFangs.stl`, `KODIAK75_Cheek_AcornShells.stl`, `KODIAK75_Cheek_HoneySpatulas.stl`, `KODIAK75_Cheek_BeaverTails.stl`, `KODIAK75_Cheek_FeatherWings.stl`, `KODIAK75_Cheek_ClawShields.stl`, `KODIAK75_Cheek_OwlFeathers.stl`, `KODIAK75_Cheek_MossBanks.stl`, `KODIAK75_Cheek_RiverSkimmers.stl`, `KODIAK75_Cheek_LeafFins.stl`.
  * *Mecha-Kodiak & Cyber-Aero (`216..235`):* `KODIAK75_Cheek_AeroCanards.stl`, `KODIAK75_Cheek_VortexGenerators.stl`, `KODIAK75_Cheek_RamAirDucts.stl`, `KODIAK75_Cheek_WingletDeflectors.stl`, `KODIAK75_Cheek_CombatSpoilers.stl`, `KODIAK75_Cheek_ShieldPlates.stl`, `KODIAK75_Cheek_HeatSinks.stl`, `KODIAK75_Cheek_StrikeBlades.stl`, `KODIAK75_Cheek_ArmorFlaps.stl`, `KODIAK75_Cheek_ThrusterPods.stl`, `KODIAK75_Cheek_AirBrakeFins.stl`, `KODIAK75_Cheek_CornerBumpers.stl`, `KODIAK75_Cheek_InterceptorFins.stl`, `KODIAK75_Cheek_FlakDeflectors.stl`, `KODIAK75_Cheek_SensorWings.stl`, `KODIAK75_Cheek_LaserCowls.stl`, `KODIAK75_Cheek_ReactivePlates.stl`, `KODIAK75_Cheek_WarpNacelles.stl`, `KODIAK75_Cheek_KineticAbsorbers.stl`, `KODIAK75_Cheek_SonicVanes.stl`.
* **25 New Osito Dual-Magnet Under-Belly Skids (`PART_ID = 301..325`, `2x N52 at 36.0mm pitch`, `0.58g–1.12g`):**
  * *Osito Bear & Forest Lore (`301..310`):* `KODIAK75_Belly_HoneyPotSkid.stl`, `KODIAK75_Belly_BearDenRunner.stl`, `KODIAK75_Belly_RiverPebbleSled.stl`, `KODIAK75_Belly_PineLogSkids.stl`, `KODIAK75_Belly_GrizzlyBellySled.stl`, `KODIAK75_Belly_FishBellyRunner.stl`, `KODIAK75_Belly_BirchBarkSkids.stl`, `KODIAK75_Belly_MudSled.stl`, `KODIAK75_Belly_SnowSkiRunner.stl`, `KODIAK75_Belly_ForestSledge.stl`.
  * *Mecha-Kodiak & Cyber-Aero (`311..325`):* `KODIAK75_Belly_RacingSkis.stl`, `KODIAK75_Belly_CombatSled.stl`, `KODIAK75_Belly_DualRailRunners.stl`, `KODIAK75_Belly_HeavyDutySkid.stl`, `KODIAK75_Belly_HighSpeedSliders.stl`, `KODIAK75_Belly_ShockAbsorberSled.stl`, `KODIAK75_Belly_GripRunners.stl`, `KODIAK75_Belly_LandingPontoons.stl`, `KODIAK75_Belly_TacticalSkids.stl`, `KODIAK75_Belly_HydroplaneRunners.stl`, `KODIAK75_Belly_ExoSkids.stl`, `KODIAK75_Belly_StealthSled.stl`, `KODIAK75_Belly_TitaniumRails.stl`, `KODIAK75_Belly_MagnaSkids.stl`, `KODIAK75_Belly_GroundEffectTunnel.stl`.

#### C. Original 36-Part Kid Customization Snap-On `.stl` Pack (`cad/KODIAK75_Kid_Customization_Pack.scad`)
* **15 Top Crown Toppers (`1x N52`):** `KODIAK75_Top_OsitoBearEars.stl`, `KODIAK75_Top_DragonSpikes.stl`, `KODIAK75_Top_MechaCrest.stl`, `KODIAK75_Top_SharkFin.stl`, `KODIAK75_Top_UnicornHorn.stl`, `KODIAK75_Top_VikingHorns.stl`, `KODIAK75_Top_RoyalCrown.stl`, `KODIAK75_Top_MohawkSpikes.stl`, `KODIAK75_Top_BunnyEars.stl`, `KODIAK75_Top_CatEars.stl`, `KODIAK75_Top_SamuraiKabuto.stl`, `KODIAK75_Top_SatelliteDish.stl`, `KODIAK75_Top_WizardCone.stl`, `KODIAK75_Top_SirenBeacon.stl`, `KODIAK75_Top_DinoStegoPlates.stl`.
* **12 Left/Right Cheek Pod Pairs (`2x N52`):** `KODIAK75_Cheek_SweptWings.stl`, `KODIAK75_Cheek_TurboBoosters.stl`, `KODIAK75_Cheek_LightningBolts.stl`, `KODIAK75_Cheek_BatWings.stl`, `KODIAK75_Cheek_FlameFins.stl`, `KODIAK75_Cheek_KnightShields.stl`, `KODIAK75_Cheek_SawbladeBumpers.stl`, `KODIAK75_Cheek_LaserPods.stl`, `KODIAK75_Cheek_EagleFeathers.stl`, `KODIAK75_Cheek_HoneycombPlates.stl`, `KODIAK75_Cheek_MonsterFists.stl`, `KODIAK75_Cheek_SharkGills.stl`.
* **9 Dual-Magnet Belly Skids (`2x N52, 36.0mm`):** `KODIAK75_Belly_BearClawSkids.stl`, `KODIAK75_Belly_HoverSkirt.stl`, `KODIAK75_Belly_TankTreads.stl`, `KODIAK75_Belly_SnowSkis.stl`, `KODIAK75_Belly_SeaplaneFloats.stl`, `KODIAK75_Belly_SkateboardDeck.stl`, `KODIAK75_Belly_SurfboardKeel.stl`, `KODIAK75_Belly_SpiderLegs.stl`, `KODIAK75_Belly_AfterburnerDiffuser.stl`.
* **[`cad/KODIAK75_EPP_Foam_Templates_1to1.svg`](./cad/KODIAK75_EPP_Foam_Templates_1to1.svg)** & **[`.dxf`](./cad/KODIAK75_EPP_Foam_Templates_1to1.dxf)** — 1:1 Scale 6mm EPP Foam Cutting Templates.
* **[`firmware/KODIAK75_Betaflight45_Full_BumperTag.txt`](./firmware/KODIAK75_Betaflight45_Full_BumperTag.txt)** — Complete Betaflight 4.5+ CLI Dump (`BETAFPVG473` target).

### Custom Flight Controller PCBA Package (`pcb/`)
* **[`pcb/OSITO_KODIAK_FC_Architecture_and_Pinout.md`](./pcb/OSITO_KODIAK_FC_Architecture_and_Pinout.md)** — Complete 4-Layer `OSITO-KODIAK-G473 v1.0` Schematic Architecture, Pin Map & JLCPCB Ordering Guide (~$15.80/board turnkey vs. $44.99 retail).
* **[`pcb/OSITO_KODIAK_FC_v1.kicad_pcb`](./pcb/OSITO_KODIAK_FC_v1.kicad_pcb)** — Native KiCad Contoured Cardinal Diamond PCB (`25.5mm × 25.5mm` M2 pattern, 100% flat bottom).
* **[`pcb/OSITO_KODIAK_FC_JLCPCB_BOM.csv`](./pcb/OSITO_KODIAK_FC_JLCPCB_BOM.csv)** — Turnkey Bill of Materials with verified LCSC Part Numbers (`Cxxxxx`) including 10× onboard `WS2812B-2020` RGB LEDs and `DRV5032` magnetic armor hit sensor.
* **[`pcb/OSITO_KODIAK_FC_JLCPCB_CPL.csv`](./pcb/OSITO_KODIAK_FC_JLCPCB_CPL.csv)** — Single-Sided Top-Layer Pick-and-Place (`CPL`) Centroid Coordinates.
