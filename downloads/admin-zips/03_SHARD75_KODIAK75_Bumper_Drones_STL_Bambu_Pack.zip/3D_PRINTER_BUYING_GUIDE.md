﻿# KODIAK-75: 3D Printer Buying Guide (PC-CF, ePA-CF & TPU 95A)

To print the **KODIAK-75** bumper-tag airframe (`KODIAK75_Frame_Protected_v2.stl`) so that the arms and 360° prop hoops survive repeated mid-air collisions without delaminating, your 3D printer must meet **four non-negotiable hardware specs**:

1. **Hardened Steel Nozzle & Hardened Extruder Gears:** Chopped carbon fiber (`PC-CF` and `ePA-CF`) is highly abrasive and will destroy a standard brass nozzle in a single spool.
2. **300°C+ All-Metal Hotend & 105°C–120°C Bed:** Polycarbonate-CF and Nylon-CF require $280^\circ\text{C}\text{–}300^\circ\text{C}$ nozzle temperatures for maximum interlayer weld strength.
3. **Enclosed Chamber (Ideally Actively Heated to 55°C–60°C):** Keeps thin carbon-composite prop-guard hoops from cooling too fast and becoming brittle between layers.
4. **Direct-Drive Extruder:** Required to print flexible **TPU 95A** (`KODIAK75_550Cradle_v1.stl`, `Deck_LOS`, `Deck_FPV`) cleanly without buckling.

---

## Top 4 Recommended 3D Printers for KODIAK-75 Production

| Printer Model | Approx. Price | Max Temps (Nozzle / Bed / Chamber) | Ready for PC-CF & TPU Out of the Box? | Best For |
| :--- | :---: | :---: | :--- | :--- |
| **1. Qidi Tech Q1 Pro** *(Best Pure Carbon-Frame Strength for the Money)* | **~$449 – $499** | **350°C** Nozzle / **120°C** Bed / **60°C Active Chamber Heater** | **100% Ready Stock** (Includes hardened bi-metal nozzle & hardened gears) | **Highest crash durability.** The active $60^\circ\text{C}$ chamber heater produces noticeably stronger layer adhesion on `PC-CF` and `ePA-CF` drone frames than unheated enclosures. |
| **2. Bambu Lab P1S + Hardened Upgrade** *(Best All-Around Shop Workhorse)* | **~$599** + **$35** upgrade (*~$635 total*) | **300°C** Nozzle / **100°C** Bed / Passive Enclosure | **Needs $35 Swap** (Add Bambu `0.4mm Hardened Steel Hotend` + `Hardened Extruder Gear`) | **Easiest workflow.** Plug-and-play with your [`slicer/`](./slicer/) Orca/Bambu profiles, rock-solid reliability, and prints 4x `KODIAK-75` frames simultaneously on its $256 \times 256\text{ mm}$ plate. |
| **3. Bambu Lab X1 Carbon (X1C)** *(Turnkey Flagship)* | **~$1,199** | **300°C** Nozzle / **120°C** Bed / Passive Enclosure | **100% Ready Stock** (Hardened nozzle & gears pre-installed) | **Zero tinkering.** Higher $120^\circ\text{C}$ bed temp than the P1S (great for `CarbonX PC-CF`), LiDAR auto-flow calibration, and hardened hardware out of the box. |
| **4. Creality K1C** *(Budget Ready-to-Print CF Option)* | **~$459 – $519** | **300°C** Nozzle / **100°C** Bed / Passive Enclosure | **100% Ready Stock** ("C" stands for Carbon—ships with hardened Unicorn nozzle) | **Low-cost entry** if you want a pre-installed hardened nozzle primarily for `ePA-CF` (Nylon-CF) and `TPU 95A`. |

---

## Mandatory Companion Tool: 70°C Filament Dryer (~$45 – $69)

> **CRITICAL:** Nylon Carbon Fiber (`ePA-CF`) and Polycarbonate Carbon Fiber (`PC-CF`) absorb moisture from the air within hours. If you print them wet, steam bubbles inside the nozzle will reduce frame crash strength by **50%+**.

* **Recommended Dryer:** **Creality Space Pi Filament Dryer** (~$49, reaches $70^\circ\text{C}$) or **Sunlu FilaDryer S4 / E2**.
* **Shop Workflow:** Dry your `ePA-CF` or `PC-CF` spool at **$70^\circ\text{C}$ for 6 hours** before printing, and feed the filament **directly out of the running dryer box** into the printer's side spool port while printing your `KODIAK-75` frames.
