# Product Requirements Document (PRD) & Developer Scope of Work
## Project: KODIAK-75 (v2 Prop-Protected 1S Breakaway Bumper-Tag Micro-Drone)

| Document Metadata | Details |
| :--- | :--- |
| **Client / Organization** | **Osito Drone Services** (`ositodrone.com` • Youth STEM, Micro-Aviation & Flight Academy) |
| **Product Codename** | **KODIAK-75** (*Kinetic Omnidirectional Defensive Impact Arena Kodiak — 75mm Standard*) |
| **Target Manufacturing Printer** | **Bambu Lab P1S** ($256 \times 256 \times 256\text{ mm}$, $0.4\text{ mm}$ Hardened Steel Nozzle, `ePA-CF` + `TPU 95A`) |
| **Target Operating Arena** | $101\text{ in} \times 101\text{ in} \times 84\text{ in}$ ($2.56\text{ m} \times 2.56\text{ m}$) Pop-Up Netted Screen Tent |
| **Document Purpose** | Complete Mechanical CAD, DFM, and Firmware Specification for Engineering Handoff |

---

## 1. Executive Summary & Project Objective

**Osito Drone Services** requires a production-ready, in-house 3D-printable **75mm 1S micro-bumper-tag quadcopter (`KODIAK-75`)** designed for multi-hit aerial bumper tag inside a $101 \times 101\text{-inch}$ netted pop-up tent.

Unlike toy break-apart drones that shed motors and crash on the first impact, the **KODIAK-75** uses a **two-tier ablative architecture**:
1. **Permanent Inner Airframe (`ePA-CF` / `PC-CF`):** A rigid, crash-proof $75.0\text{ mm}$ diagonal wheelbase frame (or $80.8\text{ mm}$ `80Pro` frame for $45\text{ mm}$ props) featuring **low-profile $360^\circ$ perimeter propeller-guard hoops** that prevent propeller entanglement with the tent mesh while leaving airflow unobstructed.
2. **Sacrificial Outer Armor Plates & Snap-On Kid Mod-Pods (`EPP Foam` + `TPU 95A` + `N52 Magnets`):** Four lightweight, color-coded breakaway armor pods (**Top Crown**, **Left Cheek**, **Right Cheek**, and **Under-Belly Skid**) held onto the frame via recessed $2\text{ mm} \times 1\text{ mm}$ N52 neodymium magnets (10x per drone: 5x on Drone + 5x on Removable Pods). When players collide mid-air, individual Armor Plates shear away cleanly to score points while Betaflight's active `crash_recovery` loop automatically re-levels the drone within $500\text{ ms}$ so bumper-tag continues uninterrupted.

---

## 2. Developer Scope of Work (SOW) & Required Deliverables

The contracted CAD / UAV Engineer shall deliver the following production-ready files:

1. **Native Parametric CAD Assembly (`.f3d` Fusion 360 or `.sldasm` SolidWorks) + Universal `.STEP` Files:**
   * Fully constrained parametric master assembly containing all 5 printed structural modules, reference COTS electronics (`25.5x25.5mm` AIO FC, `1002/0803` motors, `45mm` props, `1S 550mAh` battery, `14x14mm` nano camera), and the 4 breakaway Armor Plates.
   * Clean parameter table allowing single-value adjustment of magnet pocket diameter (`default: 2.10mm`), battery bay tolerances (`default: 70.0 x 18.5 x 7.5mm`), and prop-hoop inner clearance (`default: 47.0mm`).
2. **Watertight, Manifold Production `.STL` / `.3MF` Meshes (Oriented for Support-Free FDM Printing):**
   * `KODIAK75_Frame_Protected_v2.stl` — Main 75.0mm X-Frame with integrated $360^\circ$ low-profile prop-guard hoops (`42.0mm` ID for `40mm` Gemfan 1610 props, `ePA-CF` / `PC-CF`).
   * `KODIAK75_Frame_Protected_80Pro_45mm.stl` — 80.8mm Wheelbase X-Frame with $360^\circ$ prop-guard hoops (`47.0mm` ID for `45mm` props, `ePA-CF` / `PC-CF`).
   * `KODIAK75_Horns_v1.stl` — Cardinal standoff horns and cheek-magnet mounts (`TPU 95A` + `ePA-CF` sandwich).
   * `KODIAK75_550Cradle_v1.stl` — Flush under-belly `1S 550mAh LiHV` battery sleeve with dual belly-Armor Plate magnet sockets (`TPU 95A`).
   * `KODIAK75_Deck_LOS_v1.stl` — Camera-less Line-of-Sight translucent LED dome with top crown magnet socket (`TPU 95A`).
   * `KODIAK75_Deck_FPV_v1.stl` — Swappable $14 \times 14\text{ mm}$ nano FPV camera pod ($15^\circ\text{–}35^\circ$ tilt) with captive `U.FL` antenna tube and top crown magnet socket (`TPU 95A`).
   * `KODIAK75_ArmorPlates_v1.stl` — 3D-printed `TPU 95A` magnet/shim cups and $0.45\text{ mm}$ conical shear-keyway bosses that glue into the cut `6mm` EPP foam Armor Plates.
   * `KODIAK75_Magnet_Polarity_Wand.stl` — Dual-ended shop assembly tool (`BLUE = Frame North-Out` / `RED = Armor Plate South-Out`) to guarantee fleet-wide magnet polarity consistency.
   * **Kid Customization Mod-Pod Pack (`KODIAK75_Kid_Customization_Pack.scad`):** `KODIAK75_Top_OsitoBearEars.stl`, `KODIAK75_Top_DragonSpikes.stl`, `KODIAK75_Top_MechaCrest.stl`, `KODIAK75_Cheek_SweptWings.stl`, `KODIAK75_Cheek_TurboBoosters.stl`, and `KODIAK75_Belly_BearClawSkids.stl` — all using the exact same `2.10 x 1.20mm` N52 magnet pocket and `0.45mm` conical shear boss.
3. **2D Vector Cutting Layouts (`.DXF` and `1:1 .SVG`):**
   * Nested 1:1 cutting sheet for $6\text{ mm}$ Expanded Polypropylene (`EPP 1.3 PCF`) foam Armor Plates (**1x Top Crown**, **2x Cheek Shields**, **1x Belly Skid Plate**).
4. **Pre-Configured Bambu Studio / OrcaSlicer Project Files (`.3MF`):**
   * **Plate 1 (`ePA-CF` / `PC-CF` Structural):** Single-frame test plate + 4-frame batch production plate for the **Bambu Lab P1S** ($0.4\text{ mm}$ hardened steel nozzle, 5 wall loops, 40% gyroid infill, $0.16\text{ mm}$ layer height, zero supports).
   * **Plate 2 (`TPU 95A` Flex Parts):** Complete drone set (`550Cradle`, `Deck_LOS`, `Deck_FPV`, `Armor_Cups`) sliced at 100% concentric infill with calibrated XY hole compensation for the $2.10\text{ mm}$ N52 magnet press-fits.

---

## 3. Hard Mechanical & Dimensional Requirements

### 3.1 Main 75mm Prop-Protected Airframe (`KODIAK75_Frame_Protected_v2`)
* **Wheelbase:** $75.0\text{ mm}$ diagonal motor-to-motor ($53.03\text{ mm}$ adjacent square X).
* **Arm Cross-Section:** $4.5\text{ mm}$ width $\times$ $2.5\text{ mm}$ height contoured I-beam / truss profile extending continuously from the central hub through the motor boss to the outer edge of the prop-guard hoop.
* **Motor Mount Bosses:** $8.5\text{ mm}$ OD, $2.5\text{ mm}$ thickness, featuring a $2.2\text{ mm}$ center shaft/C-clip relief hole and standard 3-hole ($6.6\text{ mm}$ bolt circle) + 4-hole ($6.6\text{ mm}$) `M1.4` mounting slots with recessed screw-head counterbores.
* **360° Low-Profile Prop-Guard Hoops & Raised Outer Blade-Plane Rim:**
  * **Inner Diameter (ID):** $47.0\text{ mm}$ centered on each motor axis (provides $1.0\text{ mm}$ radial tip clearance for $45\text{ mm}$ bi-blade props and $3.5\text{ mm}$ radial clearance for $40\text{ mm}$ Gemfan 1610 props).
  * **Dual-Height Hoop Profile:** $1.6\text{ mm}$ radial wall thickness (4 continuous slicer wall perimeters with $0.4\text{ mm}$ nozzle). The full $360^\circ$ lower structural ring is $3.2\text{ mm}$ tall, while the **exposed outer $240^\circ$ perimeter arc rises to $8.5\text{ mm}$ total height** so the guard wall aligns with the actual elevated Z-plane of the spinning propeller blades on `1002`/`0803` motors.
  * **Perimeter Box-Truss Bridging:** Adjacent prop hoops MUST be joined by tangential gusset bridges at the 12, 3, 6, and 9 o'clock positions so collision loads distribute across all four quadrants rather than flexing a single arm.
* **Flight Controller Mounting Pattern & Prop-Tip Clearance (CRITICAL):**
  * Because $45\text{ mm}$ propellers on a $75.0\text{ mm}$ diagonal wheelbase ($R_{\text{motor}} = 37.5\text{ mm}$) sweep inward to a radius of $37.5 - 22.5 = 15.0\text{ mm}$ ($30.0\text{ mm}$ diameter circle) along the $45^\circ/135^\circ/225^\circ/315^\circ$ motor diagonals, the central hub and upper decks MUST be contoured to $\le 25.0\text{ mm}$ OD along the diagonals.
  * The $25.5\text{ mm} \times 25.5\text{ mm}$ Whoop AIO mounting holes MUST be oriented in the **Cardinal Diamond pattern ($0^\circ, 90^\circ, 180^\circ, 270^\circ$ at $R = 18.031\text{ mm}$)**—tucked into the open cardinal channels *between* the four propeller arcs (providing $5.34\text{ mm}$ radial clearance from $45\text{ mm}$ blade tips)—with $3.0\text{ mm}$ raised thermal air-gap standoff bosses.

### 3.2 Under-Belly 1S 550mAh Battery Cradle (`KODIAK75_550Cradle_v1`)
* **Target Battery Envelope:** Accommodates standard `1S 550mAh LiHV` pouch cells (BetaFPV Lava 550mAh 75C BT2.0: $69.5 \times 16.2 \times 6.7\text{ mm}$; GNB 550mAh A30: $65.0 \times 18.0 \times 6.0\text{ mm}$; Tattu 550mAh: $66.0 \times 15.5 \times 7.5\text{ mm}$).
* **Internal Sleeve Dimensions:** $70.0\text{ mm (L)} \times 18.5\text{ mm (W)} \times 7.5\text{ mm (H)}$ with side weight-relief windows and an integrated $8.5\text{ mm} \times 1.8\text{ mm}$ Velcro strap slot.
* **Outboard M2 Mounting Wings (Non-Blocking Battery Tunnel):** Because a $70\text{ mm}$-long battery running along the X-axis passes directly underneath the Front and Rear M2 diamond screws ($X = \pm 18.031\text{ mm}, Y = 0$), the cradle MUST mount via **outboard Left and Right M2 wings at $(0, \pm 18.031\text{ mm})$** (with flush counterbores for the front/rear screw heads) so no screw shaft ever blocks the slide-in battery tunnel.

### 3.3 60-Second Modular Upper Decks (`Deck_LOS` & `Deck_FPV`)
* Both upper decks MUST share the exact same $25.5 \times 25.5\text{ mm}$ `M2` mounting footprint so operators can convert a drone between **LOS Mode** and **FPV Mode** in under 60 seconds:
  * **Option A (`KODIAK75_Deck_LOS_v1`):** Low-profile translucent `TPU 95A` dome with internal channels for a 2-LED `5V WS2812B` COB strip and an apex N52 magnet socket for the Top CROWN ARMOR PLATE.
  * **Option B (`KODIAK75_Deck_FPV_v1`):** Protective `TPU 95A` canopy accepting $14 \times 14\text{ mm}$ nano cameras (BetaFPV C03, Runcam Nano 3, Caddx Ant Lite) with $15^\circ\text{–}35^\circ$ tilt adjustment, an enclosed rear `U.FL` dipole antenna protection tube, and an identical apex N52 magnet socket.

### 3.4 4-Zone Magnetic Breakaway & Anti-Shatter Socket Geometry
* **Hardware Standard:** $2\text{ mm} \times 1\text{ mm}$ Grade N52 Neodymium disc magnets (`JC-D0201-N52`, $0.02\text{g}$ each, $68\text{–}113\text{g}$ axial pull force).
* **Anti-Shatter Pocket Tolerance:** Because $1\text{ mm}$ sintered neodymium magnets are brittle and will shatter if allowed to slam directly together face-to-face, every magnet pocket MUST be modeled at **$2.10\text{ mm}$ diameter $\times$ $1.20\text{ mm}$ depth**, recessing the magnet **$0.20\text{ mm}$ below the TPU mating face** (leaving a $0.40\text{ mm}$ total TPU cushion gap between mating magnets, or pairing a recessed frame magnet against a $0.15\text{ mm}$ ferromagnetic steel shim on the Armor Plate).
* **Conical Shear Keyway:** Every mating interface MUST incorporate a **$0.50\text{ mm}$ shallow conical dimple ($3.6\text{ mm}$ outer diameter)** and matching boss on the Armor Plate cup so that **15G acrobatic snap-rolls ($>600^\circ/\text{s}$)** do not slide Armor Plates off laterally, while angled drone-on-drone impacts cleanly shear the Armor Plate out of the dimple.
* **4 Mounting Zones:**
  1. **Zone 1 — Top CROWN ARMOR PLATE (2 Points):** 1x vertical N52 socket on the apex of `Deck_LOS` / `Deck_FPV`.
  2. **Zone 2 — Left Cheek Armor Plate (1 Point):** 1x horizontal N52 socket on the 9 o'clock prop-guard bridge.
  3. **Zone 3 — Right Cheek Armor Plate (1 Point):** 1x horizontal N52 socket on the 3 o'clock prop-guard bridge.
  4. **Zone 4 — Belly SKID ARMOR PLATE (1 Point):** 2x vertical N52 sockets ($36.0\text{ mm}$ center-to-center spacing) on the bottom face of `KODIAK75_550Cradle_v1`.

---

## 4. Target Mass Budget & CoG Constraints

| Subsystem / Component | Material / Spec | Target Mass | Max Allowed Mass |
| :--- | :--- | :---: | :---: |
| **Main 75mm Prop-Protected Frame (`v2`)** | Printed `ePA-CF` / `PC-CF` (5 walls, 40% gyroid) | **3.2 g** | 3.8 g |
| **550mAh Belly Cradle (`KODIAK75_550Cradle_v1`)** | Printed `TPU 95A` | **1.6 g** | 2.0 g |
| **Modular Upper Deck (`LOS` or `FPV`)** | Printed `TPU 95A` | **0.5 g / 0.75 g** | 1.0 g |
| **4x Breakaway Armor Plates + TPU Cups + N52 Magnets** | `6mm EPP Foam` + `TPU 95A` + 10x `2x1mm N52` (5x Drone + 5x Plates) | **2.2 g total** | **3.5 g total (<10% AUW)** |
| **Avionics (1S 12A 5-in-1 AIO + BT2.0 Lead + LEDs)** | `25.5x25.5mm` PCB + `20AWG` Pigtail + COB Strip | **5.2 g** | 5.8 g |
| **Propulsion (4x `1002/0803` Motors + 4x `45mm` Props)** | `1.5mm` shafts + `M1.4` screws + PC bi-blades | **9.4 g** | 10.2 g |
| **Optional Nano FPV Camera** | `14x14mm` C03 / Nano 3 / Ant Lite | **0.0 g / 1.5 g** | 1.8 g |
| **Battery Pack** | `1S 550mAh LiHV` (BT2.0 / A30) | **13.8 g** | 15.0 g |
| **Total All-Up Ready-to-Play Weight (AUW)** | **Ready-to-Fight Aircraft** | **35.9g (LOS) / 37.7g (FPV)** | **$\le 41.0\text{ g}$** |

> **Asymmetric Mass-Loss Rule:** Shedding any single Armor Plate or combination of Armor Plates mid-flight MUST shift the aircraft's Center of Gravity (CoG) by **$< 1.5\text{ mm}$**, requiring zero manual trim adjustments.

---

## 5. Reference COTS Hardware Bill of Materials (For CAD Fit-Check)

The developer must model clearance and mounting interfaces against these exact COTS components:
* **Flight Controller (LOCKED):** **BetaFPV Matrix 1S Brushless `5-in-1` AIO** (`board_name BETAFPVG473`, $25.5 \times 25.5\text{ mm}$ Cardinal Diamond mounting holes, $28.5 \times 28.5\text{ mm}$ outer PCB envelope, $3.9\text{g}$ mass, corner `JST-1.25` 3-pin motor sockets, 3-pin `JST-SH` camera header, pre-soldered `BT2.0` lead, and flat underside with side-entry 4-pin `SH1.0` Type-C USB adapter).
* **Motors:** `1002 22,000KV` or `0803 22,000KV` brushless motors ($1.5\text{ mm}$ shaft, $6.6\text{ mm}$ 3-hole `M1.4` base pattern).
* **Propellers:** Gemfan `45mm` (1.8-inch) or Gemfan `1610` (`40mm`) 2-blade polycarbonate propellers.
* **Battery:** BetaFPV Lava `1S 550mAh 75C BT2.0` ($69.5 \times 16.2 \times 6.7\text{ mm}$) and GNB `1S 550mAh 100C A30` ($65.0 \times 18.0 \times 6.0\text{ mm}$).
* **FPV Camera:** BetaFPV `C03` or Runcam `Nano 3` ($14.0 \times 14.0\text{ mm}$ housing).

---

## 6. Acceptance Criteria & Milestone Sign-Off (Definition of Done)

1. **Milestone 1 — 3D CAD & Interference Review (40%):**
   * Delivery of `.STEP` / `.F3D` master assembly demonstrating zero mechanical interference between `45mm` props ($1.0\text{ mm}$ minimum radial clearance inside hoops), AIO FC USB port, `1S 550mAh` battery pouch, and `M2` stack screws.
2. **Milestone 2 — Support-Free Slicer & Mass Verification (30%):**
   * Delivery of `.STL` files and Bambu Lab P1S `.3MF` project files verifying that all printed parts slice **100% support-free** and meet the Section 4 mass targets in Bambu Studio / OrcaSlicer filament estimation.
3. **Milestone 3 — First-Article Fit & QA Sign-Off (30%):**
   * Verification of press-fit tolerance on the $2.10 \times 1.20\text{ mm}$ N52 magnet pockets, 15G lateral Armor Plate retention in the $0.50\text{ mm}$ conical shear keyways, and final delivery of all source CAD, `.STL`, `.3MF`, and `.DXF`/`.SVG` foam template files.
