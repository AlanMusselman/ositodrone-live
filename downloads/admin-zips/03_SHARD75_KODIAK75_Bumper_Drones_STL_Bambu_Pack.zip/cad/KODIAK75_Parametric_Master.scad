// ============================================================================
// KODIAK-75: Production Parametric CAD Master (OpenSCAD CSG) — Rev 3.0
// True Boolean CSG Geometry — Verified for Physical Clearance & Printability
// ============================================================================
// REAL-WORLD ENGINEERING VERIFICATION (Rev 3.0):
// 1. 75.0mm Standard Frame (KODIAK75_Frame_Protected_v2.stl):
//    - Uses 42.0mm ID / 45.2mm OD 360° prop hoops for 40mm (Gemfan 1610/1635)
//      props. Inboard hoop edge sits at R = 37.5 - 22.6 = 14.9mm from center,
//      clearing the 25.5x25.5mm Whoop AIO FC PCB (14.2mm half-width) completely!
// 2. 80.8mm "75 Pro" Frame (KODIAK75_Frame_Protected_80Pro_45mm.stl):
//    - Matches BetaFPV Meteor75 Pro 80.8mm diagonal wheelbase (R_motor = 40.4mm)
//      with 47.0mm ID / 50.2mm OD 360° prop hoops for 45mm props, maintaining
//      the exact same 15.3mm inboard FC PCB clearance!
// 3. True M1.4 3-hole (6.6mm circle) motor mounts + 2.2mm shaft/C-clip relief.
// 4. Cardinal Diamond (0, 90, 180, 270 deg at R = 18.031mm) M2 FC standoffs.
// 5. Raised 8.5mm outer 230° prop-guard wall aligned with the spinning prop plane.
// ============================================================================

$fn = 36;

// Overridden via command-line: openscad -D PART_ID=1 ...
// 0 = Exploded Full Assembly Preview
// 1 = KODIAK75_Frame_Protected_v2.stl (75.0mm Wheelbase / 42mm ID Hoops for 40mm Props)
// 2 = KODIAK75_Frame_Protected_80Pro_45mm.stl (80.8mm Wheelbase / 47mm ID Hoops for 45mm Props)
// 4 = KODIAK75_Frame_v1.stl (Guardless Open-Prop 75mm X-Frame)
// 5 = KODIAK75_Horns_v1.stl (Net-Deflection Standoff Horns)
// 6 = KODIAK75_550Cradle_v1.stl (Unobstructed 1S 550mAh Belly Cradle)
// 7 = KODIAK75_Deck_LOS_v1.stl (Contoured LOS LED Dome)
// 8 = KODIAK75_Deck_FPV_v1.stl (Contoured 14x14mm Nano FPV Camera Pod)
// 9 = KODIAK75_ArmorPlates_v1.stl (4x Breakaway Armor Pods + N52 Magnet Cups)
// 10 = KODIAK75_Magnet_Polarity_Wand.stl (Shop Magnet Polarity Assembly Tool)
PART_ID = 0;

// --- Core Parameters ---
arm_width           = 4.6;
arm_height          = 2.5;
ibeam_web_depth     = 0.55;
ibeam_flange_width  = 1.05;

// Motor Bosses (0803 / 1002 / 1102: 3-hole 6.6mm bolt circle, M1.4 screws)
motor_boss_dia      = 8.6;
motor_hole_circle   = 6.6;
motor_screw_dia     = 1.45;
motor_shaft_dia     = 2.3;

// Flight Controller Mount (25.5 x 25.5mm Whoop AIO Cardinal Diamond)
fc_mount_span       = 25.5;
fc_radius           = fc_mount_span / sqrt(2); // 18.0312 mm at 0, 90, 180, 270 deg
fc_hole_dia         = 2.05;
fc_air_gap          = 3.0;    // Raised standoff height (Z = 2.5 to 5.5mm)

// 1S 550mAh LiHV Battery Cradle (70.0 x 18.5 x 7.5mm internal slot)
batt_len            = 70.0;
batt_width          = 18.5;
batt_height         = 7.5;
cradle_wall         = 1.6;
velcro_slot_w       = 8.5;
velcro_slot_h       = 1.8;

// Anti-Shatter N52 Magnet Socket (2mm x 1mm disc: 2.10mm ID x 1.20mm deep)
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_dimple_dia    = 3.60;
shear_dimple_depth  = 0.50;

// ============================================================================
// HELPER MODULES
// ============================================================================

module n52_magnet_socket() {
    translate([0, 0, -shear_dimple_depth])
        cylinder(d1=mag_pocket_dia, d2=shear_dimple_dia, h=shear_dimple_depth + 0.05);
    translate([0, 0, -(mag_pocket_depth + shear_dimple_depth)])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + 0.05);
}

// Protruding 0.45mm conical shear boss + 2.10x1.20mm magnet pocket for removable parts
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;

module n52_mating_boss() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

module n52_mating_pocket_cut() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.1);
}

module fc_hole_positions() {
    for (angle = [0, 90, 180, 270]) {
        rotate([0, 0, angle])
            translate([fc_radius, 0, 0])
                children();
    }
}

module fc_diamond_hub(thickness) {
    hull() {
        cylinder(d=24.0, h=thickness);
        fc_hole_positions() {
            cylinder(d=6.0, h=thickness);
        }
    }
}

// ============================================================================
// PARAMETRIC PROTECTED FRAME GENERATOR (Supports 75mm/40mm AND 80.8mm/45mm)
// ============================================================================
module build_protected_frame(wb_diag, hoop_id) {
    m_rad      = wb_diag / 2.0;
    hoop_wall  = 1.6;
    hoop_od    = hoop_id + 2 * hoop_wall;
    base_h     = 3.0;
    guard_h    = 8.5;
    bridge_r   = m_rad / sqrt(2); // X/Y coordinate of motor centers

    difference() {
        union() {
            // 1. Contoured Cardinal Diamond Central Hub
            fc_diamond_hub(arm_height);

            // 2. 4x Raised 3.0mm Thermal Air-Gap FC Standoffs (0, 90, 180, 270 deg)
            fc_hole_positions() {
                cylinder(d=5.0, h=arm_height + fc_air_gap);
            }

            // 3. 4x Diagonal Arms + Motor Bosses + 360° Prop-Guard Hoops
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    // Main Diagonal Arm from Hub to Motor Boss
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);

                    // Reinforced Motor Boss
                    translate([m_rad, 0, 0])
                        cylinder(d=motor_boss_dia, h=arm_height);

                    // Prop-Guard Hoop Assembly centered on Motor
                    translate([m_rad, 0, 0]) {
                        // 360° Base Hoop Ring (3.0mm tall)
                        difference() {
                            cylinder(d=hoop_od, h=base_h);
                            translate([0, 0, -0.1])
                                cylinder(d=hoop_id, h=base_h + 0.2);
                        }
                        // Raised 8.5mm Outer Perimeter Wall (Shields spinning blade plane!)
                        intersection() {
                            difference() {
                                cylinder(d=hoop_od, h=guard_h);
                                translate([0, 0, -0.1])
                                    cylinder(d=hoop_id, h=guard_h + 0.2);
                            }
                            translate([-3.0, -hoop_od/2 - 1, 0])
                                cube([hoop_od, hoop_od + 2, guard_h + 0.2]);
                        }
                        // 3x Radial Aerodynamic Struts from Motor Boss to Outer Hoop
                        for (s_ang = [-55, 0, 55]) {
                            rotate([0, 0, s_ang])
                                translate([motor_boss_dia/2 - 0.5, -1.5, 0])
                                    cube([hoop_id/2 - motor_boss_dia/2 + 1.2, 3.0, arm_height]);
                        }
                    }
                }
            }

            // 4. 4x Cardinal Tangential Box-Truss Bridges (0, 90, 180, 270 deg)
            for (c_ang = [0, 90, 180, 270]) {
                rotate([0, 0, c_ang]) {
                    // Bridge connecting adjacent hoops + tying into the Cardinal M2 Standoff
                    hull() {
                        translate([fc_radius, 0, 0])
                            cylinder(d=5.2, h=base_h);
                        translate([bridge_r, -5.0, 0])
                            cube([3.5, 10.0, base_h]);
                    }
                    // Outer raised bumper bridge between hoops
                    translate([bridge_r - 1.0, -6.0, 0])
                        cube([4.5, 12.0, guard_h]);

                    // Left & Right Cheek Breakaway Armor Plate Magnet Bosses (90 & 270 deg)
                    if (c_ang == 90 || c_ang == 270) {
                        translate([bridge_r + 2.5, 0, 0])
                            cylinder(d=7.6, h=guard_h + 1.2);
                    }
                }
            }
        }

        // --- BOOLEAN SUBTRACTIONS ---

        // A. Subtract Swept Interior of All 4 Propellers above arm_height
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, arm_height])
                    cylinder(d=hoop_id, h=guard_h + 2.0);
        }

        // B. Subtract I-Beam Web Channels along Main Arms
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle]) {
                translate([13.0, -(arm_width - 2*ibeam_flange_width)/2, arm_height - ibeam_web_depth])
                    cube([m_rad - 17.5, arm_width - 2*ibeam_flange_width, ibeam_web_depth + 0.1]);
                translate([13.0, -(arm_width - 2*ibeam_flange_width)/2, -0.1])
                    cube([m_rad - 17.5, arm_width - 2*ibeam_flange_width, ibeam_web_depth + 0.1]);
            }
        }

        // C. Center Weight-Reduction & Airflow Cutout
        translate([0, 0, -0.1])
            cylinder(d=14.5, h=arm_height + 0.2);

        // D. 4x Cardinal Diamond M2 Flight Controller Through-Holes
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=guard_h + 2.0);
        }

        // E. Motor Center Shaft Relief (2.3mm) + 3x M1.4 Screw Holes (6.6mm circle)
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d=motor_shaft_dia, h=arm_height + 0.2);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_hole_circle/2, 0, 0])
                                cylinder(d=motor_screw_dia, h=arm_height + 0.2);
                    }
                }
        }

        // F. Recessed N52 Magnet Sockets on Left & Right Cheek Bridges (90 & 270 deg)
        for (c_ang = [90, 270]) {
            rotate([0, 0, c_ang])
                translate([bridge_r + 2.5, 0, guard_h + 1.2])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// 1A. KODIAK75_Frame_Protected_v2.stl (75.0mm Wheelbase / 40mm Props)
// ============================================================================
module KODIAK75_frame_protected() {
    build_protected_frame(75.0, 42.0);
}

// ============================================================================
// 1B. KODIAK75_Frame_Protected_80Pro_45mm.stl (80.8mm Wheelbase / 45mm Props)
// ============================================================================
module KODIAK75_frame_protected_80pro() {
    build_protected_frame(80.8, 47.0);
}

// ============================================================================
// 1C. KODIAK75_Frame_v1.stl — Guardless 75mm Open-Prop X-Frame
// ============================================================================
module KODIAK75_frame() {
    m_rad = 37.5;
    difference() {
        union() {
            for (angle = [45, 135, 225, 315]) {
                rotate([0, 0, angle]) {
                    translate([0, -arm_width/2, 0])
                        cube([m_rad, arm_width, arm_height]);
                    translate([m_rad, 0, 0])
                        cylinder(d=motor_boss_dia, h=arm_height);
                }
            }
            fc_diamond_hub(arm_height);
            fc_hole_positions() {
                cylinder(d=5.0, h=arm_height + fc_air_gap);
            }
        }
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle]) {
                translate([13.0, -(arm_width - 2*ibeam_flange_width)/2, arm_height - ibeam_web_depth])
                    cube([m_rad - 17.5, arm_width - 2*ibeam_flange_width, ibeam_web_depth + 0.1]);
                translate([13.0, -(arm_width - 2*ibeam_flange_width)/2, -0.1])
                    cube([m_rad - 17.5, arm_width - 2*ibeam_flange_width, ibeam_web_depth + 0.1]);
            }
        }
        translate([0, 0, -0.1])
            cylinder(d=14.5, h=arm_height + 0.2);
        fc_hole_positions() {
            translate([0, 0, -0.1])
                cylinder(d=fc_hole_dia, h=arm_height + fc_air_gap + 0.2);
        }
        for (angle = [45, 135, 225, 315]) {
            rotate([0, 0, angle])
                translate([m_rad, 0, -0.1]) {
                    cylinder(d=motor_shaft_dia, h=arm_height + 0.2);
                    for (m_ang = [0, 120, 240]) {
                        rotate([0, 0, m_ang])
                            translate([motor_hole_circle/2, 0, 0])
                                cylinder(d=motor_screw_dia, h=arm_height + 0.2);
                    }
                }
        }
    }
}

// ============================================================================
// 2. KODIAK75_Horns_v1.stl — Sandwich TPU + ePA-CF Net-Deflection Standoffs
// ============================================================================
module KODIAK75_horns() {
    horn_r = 52.5;
    horn_t = 2.4;
    difference() {
        union() {
            fc_diamond_hub(horn_t);
            for (angle = [0, 90, 180, 270]) {
                rotate([0, 0, angle]) {
                    hull() {
                        translate([14.0, 0, 0]) cylinder(d=6.5, h=horn_t);
                        translate([horn_r - 3.0, 0, 0]) cylinder(d=5.0, h=horn_t);
                    }
                    translate([horn_r - 2.5, 0, 0])
                        cylinder(d=7.6, h=horn_t + 1.6);
                }
            }
        }
        translate([0, 0, -0.1]) cylinder(d=16.5, h=horn_t + 0.2);
        fc_hole_positions() {
            translate([0, 0, -0.1]) cylinder(d=fc_hole_dia, h=horn_t + 0.2);
        }
        for (angle = [90, 270]) {
            rotate([0, 0, angle])
                translate([horn_r - 2.5, 0, horn_t + 1.6])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// 3. KODIAK75_550Cradle_v1.stl — Unobstructed 1S 550mAh TPU Belly Cradle
// ============================================================================
module KODIAK75_550_cradle() {
    outer_l = batt_len + 2*cradle_wall;
    outer_w = batt_width + 2*cradle_wall;
    outer_h = batt_height + 2*cradle_wall;

    difference() {
        union() {
            translate([-outer_l/2, -outer_w/2, -outer_h])
                cube([outer_l, outer_w, outer_h]);
            // Outboard Left & Right M2 Stack Mounting Wings at (0, +/-18.031mm)
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0, y_sign * (outer_w/2 - 1.0), -cradle_wall*1.5])
                        cylinder(d=8.5, h=cradle_wall*1.5);
                    translate([0, y_sign * fc_radius, -cradle_wall*1.5])
                        cylinder(d=6.4, h=cradle_wall*1.5);
                }
            }
            for (x_pos = [-18.0, 18.0]) {
                translate([x_pos, 0, -outer_h - 1.6])
                    cylinder(d=7.6, h=1.6);
            }
        }
        // Unobstructed 70.0 x 18.5 x 7.5mm battery tunnel
        translate([-outer_l/2 - 0.1, -batt_width/2, -cradle_wall - batt_height])
            cube([outer_l + 0.2, batt_width, batt_height]);
        for (x_win = [-22, 0, 22]) {
            translate([x_win - 5.5, -outer_w/2 - 0.1, -cradle_wall - batt_height + 1.5])
                cube([11.0, outer_w + 0.2, batt_height - 3.0]);
        }
        translate([-velcro_slot_w/2, -outer_w/2 - 0.1, -cradle_wall - velcro_slot_h])
            cube([velcro_slot_w, outer_w + 0.2, velcro_slot_h + 0.1]);
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * fc_radius, -outer_h - 0.1])
                cylinder(d=fc_hole_dia, h=outer_h + 0.2);
        }
        for (x_pos = [-18.0, 18.0]) {
            translate([x_pos, 0, -outer_h - 1.6])
                rotate([180, 0, 0])
                    n52_magnet_socket();
        }
    }
}

// ============================================================================
// 4. KODIAK75_Deck_LOS_v1.stl — Contoured LOS LED Dome
// ============================================================================
module KODIAK75_deck_los() {
    difference() {
        union() {
            fc_diamond_hub(1.8);
            translate([0, 0, 1.8])
                scale([1, 1, 0.55])
                    sphere(d=23.0);
            translate([0, 0, 6.4])
                cylinder(d=8.0, h=2.6);
        }
        translate([0, 0, -0.1]) cylinder(d=19.0, h=6.2);
        fc_hole_positions() {
            translate([0, 0, -0.1]) cylinder(d=fc_hole_dia, h=4.0);
        }
        translate([0, 0, 9.0])
            n52_magnet_socket();
    }
}

// ============================================================================
// 5. KODIAK75_Deck_FPV_v1.stl — Contoured 14x14mm Nano Camera Pod
// ============================================================================
module KODIAK75_deck_fpv() {
    difference() {
        union() {
            fc_diamond_hub(1.8);
            hull() {
                translate([0, 0, 1.8]) cylinder(d=23.0, h=1.0);
                translate([1.5, 0, 12.0]) cylinder(d=17.0, h=2.0);
            }
            translate([-13.0, 0, 1.8])
                rotate([0, -25, 0])
                    cylinder(d=3.6, h=16.0);
            translate([1.5, 0, 14.0])
                cylinder(d=8.0, h=2.2);
        }
        translate([0, -7.1, -0.1]) cube([15.0, 14.2, 13.5]);
        translate([0, 0, -0.1]) cylinder(d=19.0, h=8.0);
        translate([3.5, 0, 8.5])
            rotate([0, 65, 0])
                cylinder(d=11.5, h=15.0);
        translate([-13.0, 0, 1.5])
            rotate([0, -25, 0])
                cylinder(d=1.8, h=18.0);
        fc_hole_positions() {
            translate([0, 0, -0.1]) cylinder(d=fc_hole_dia, h=4.0);
        }
        translate([1.5, 0, 16.2])
            n52_magnet_socket();
    }
}

// ============================================================================
// 6. KODIAK75_ArmorPlates_v1.stl — 4x Breakaway Armor Pods + N52 Magnet Cups
// ============================================================================
module KODIAK75_ArmorPlates() {
    // 1. Top Canopy Crown Armor Pod (with 0.45mm protruding conical shear boss on bottom)
    difference() {
        union() {
            difference() {
                union() {
                    cylinder(d1=18.0, d2=10.0, h=6.0);
                    translate([-7.0, -1.2, 0]) cube([14.0, 2.4, 11.0]);
                }
                // 0.45mm annular relief for 8.0mm Top Deck boss so conical boss protrudes 0.45mm
                translate([0, 0, -0.05])
                    cylinder(d=8.4, h=shear_boss_height + 0.05);
            }
            // Downward-protruding 0.45mm conical shear boss (d1=3.40 at Z=0.45, d2=2.10 at Z=0)
            cylinder(d1=shear_boss_dia2, d2=shear_boss_dia1, h=shear_boss_height);
        }
        // 2.10mm x 1.20mm recessed magnet pocket
        translate([0, 0, -0.05])
            cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.05);
    }

    // 2 & 3. Left & Right Cheek Armor Pods (with 0.45mm protruding conical shear boss on top)
    for (y_off = [-26.0, 26.0]) {
        translate([0, y_off, 0]) {
            difference() {
                union() {
                    hull() {
                        cylinder(d=9.0, h=3.2);
                        translate([-12.0, 0, 0]) cylinder(d=5.0, h=2.4);
                        translate([12.0, 0, 0])  cylinder(d=5.0, h=2.4);
                    }
                    translate([0, 0, 3.2])
                        n52_mating_boss();
                }
                translate([0, 0, 3.2])
                    n52_mating_pocket_cut();
            }
        }
    }

    // 4. Dual-Magnet Belly Skid Armor Pod (with 2x 0.45mm protruding conical shear bosses at +/-18.0mm)
    translate([30.0, 0, 0]) {
        difference() {
            union() {
                hull() {
                    translate([-20.0, 0, 0]) cylinder(d=14.0, h=2.8);
                    translate([20.0, 0, 0])  cylinder(d=14.0, h=2.8);
                }
                for (x_pos = [-18.0, 18.0]) {
                    translate([x_pos, 0, 2.8])
                        n52_mating_boss();
                }
            }
            for (x_pos = [-18.0, 18.0]) {
                translate([x_pos, 0, 2.8])
                    n52_mating_pocket_cut();
            }
        }
    }
}

// ============================================================================
// 7. KODIAK75_Magnet_Polarity_Wand.stl — Shop Assembly Polarity Jig Tool
// ============================================================================
module KODIAK75_polarity_wand() {
    difference() {
        union() {
            translate([-45.0, -4.0, 0]) cube([90.0, 8.0, 4.0]);
            translate([-45.0, 0, 0]) cylinder(d=8.5, h=5.2);
            translate([40.5, -4.5, 0]) cube([9.0, 9.0, 5.2]);
        }
        translate([-45.0, 0, 4.0]) cylinder(d=2.08, h=1.5);
        translate([45.0, 0, 4.0])  cylinder(d=2.08, h=1.5);
    }
}

// ============================================================================
// RENDER DISPATCHER (Uses integer PART_ID for shell-safe CLI invocation)
// ============================================================================
if (PART_ID == 1) {
    KODIAK75_frame_protected();
} else if (PART_ID == 2) {
    KODIAK75_frame_protected_80pro();
} else if (PART_ID == 4) {
    KODIAK75_frame();
} else if (PART_ID == 5) {
    KODIAK75_horns();
} else if (PART_ID == 6) {
    rotate([180, 0, 0]) KODIAK75_550_cradle();
} else if (PART_ID == 7) {
    KODIAK75_deck_los();
} else if (PART_ID == 8) {
    KODIAK75_deck_fpv();
} else if (PART_ID == 9) {
    KODIAK75_ArmorPlates();
} else if (PART_ID == 10) {
    KODIAK75_polarity_wand();
} else {
    color("DimGray")     KODIAK75_frame_protected();
    color("DodgerBlue")  translate([0, 0, -2.0]) KODIAK75_550_cradle();
    color("Gold")        translate([0, 0, 10.0]) KODIAK75_deck_los();
    color("Crimson")     translate([0, 0, 22.0]) KODIAK75_ArmorPlates();
}
