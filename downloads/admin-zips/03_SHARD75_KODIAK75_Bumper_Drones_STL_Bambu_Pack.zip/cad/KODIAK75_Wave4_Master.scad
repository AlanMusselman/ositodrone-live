// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: 1,000 SACRIFICIAL CUSTOMIZATION PARTS
// PART_ID = 2001..3000 (400 Crowns + 350 Cheek Pod Pairs + 250 Belly Skids)
// Universal Magnetic & Conical Shear-Keyway Standard — 100% Support-Free TPU 95A
// ============================================================================
// Cumulative Total: 1,240 (Waves 0-3) + 1,000 (Wave 4) = 2,240 Total Parts!
// Total Loadout Combinations: 896 Crowns x 783 Cheeks x 560 Belly = 392,878,080!
// ============================================================================
// Usage:
//   openscad -D "PART_ID=2001" -o KODIAK75_Crown_2001.stl KODIAK75_Wave4_Master.scad
// ============================================================================

PART_ID = 2001;

use <KODIAK75_Wave4_Crowns_A.scad>
use <KODIAK75_Wave4_Crowns_B.scad>
use <KODIAK75_Wave4_Cheeks_A.scad>
use <KODIAK75_Wave4_Cheeks_B.scad>
use <KODIAK75_Wave4_Belly.scad>

module render_wave4_object(part_id) {
    if (part_id >= 2001 && part_id <= 2200) {
        KODIAK75_Wave4_Crown_A(part_id);
    } else if (part_id >= 2201 && part_id <= 2400) {
        KODIAK75_Wave4_Crown_B(part_id);
    } else if (part_id >= 2401 && part_id <= 2575) {
        render_wave4_cheek_pair_a(part_id);
    } else if (part_id >= 2576 && part_id <= 2750) {
        render_wave4_cheek_pair_b(part_id);
    } else if (part_id >= 2751 && part_id <= 3000) {
        render_wave4_belly(part_id);
    }
}

render_wave4_object(PART_ID);
