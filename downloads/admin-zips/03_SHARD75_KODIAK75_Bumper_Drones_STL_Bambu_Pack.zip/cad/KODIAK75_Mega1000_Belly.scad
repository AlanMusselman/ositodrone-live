// ============================================================================
// KODIAK-75: Mega-1000 Expansion — Zone 4 Under-Belly Skids (PART_ID = 1751..2000)
// Universal Magnetic Snap-On Breakaway Architecture for Bumper Drones
// ============================================================================
// Total Components in this file: 250 Distinct Sacrificial Belly Skid Modules
// - Zone 4: Creative Under-Belly Skids (PART_ID = 1751 to 2000)
// - 10 Parametric 3D Belly Skid Archetypes (arch = 0..9) x 25 Sub-Variations (subvar = 0..24)
//
// Material: TPU 95A (density = 0.00121 g/mm^3)
// Mass Target Budget: 0.60g .. 1.15g (Volume: 500 .. 950 mm^3)
// Support Policy: 100% Support-Free FDM Printing at Z = 0.00mm
// Polarity Standard: Grade N52 disc magnets (2mm OD x 1mm thick), South-Facing-Out
// ============================================================================

$fn = 28;

// Command-line selector: openscad -D PART_ID=<id> -o <target>.stl KODIAK75_Mega1000_Belly.scad
PART_ID = 1751;

// --- Master Interface Constants (Zone 4 Dual-Magnet Belly Skid) ---
mag_pocket_dia        = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth      = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1       = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2       = 2.10; // Tip diameter of male conical shear boss
shear_boss_height     = 0.45; // Height of male conical shear boss (mates into 0.50mm dimple)
belly_mag_spacing     = 36.0; // Ventral dual-magnet pitch along X-axis (X = -18mm and X = +18mm)

// ============================================================================
// UNIVERSAL ZONE 4 HELPER MODULES
// ============================================================================

// Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45)
module n52_mating_boss_up() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

// Top-facing recessed magnet pocket cut through boss
module n52_mating_pocket_cut_up() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.10);
}

// Zone 4 Dual Mounting Posts Helper (places dual bosses at X = +/-18mm)
module belly_mount_posts(h = 1.60) {
    for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
        translate([x_pos, 0, 0])
            cylinder(d1 = 8.2, d2 = 6.8, h = h);
        translate([x_pos, 0, h - 0.15])
            cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
    }
}

// Zone 4 Dual Magnet Pocket Cuts Helper
module belly_magnet_cuts(h = 1.60) {
    for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
        translate([x_pos, 0, h])
            n52_mating_pocket_cut_up();
    }
}

// Zone 4 Master Trim & Unscaled Dual-Magnet Interface Wrapper
// Scales raw skid Z-profile into the 0.60g-1.15g TPU 95A target range while preserving
// Z=0 flat bed contact and 100% unscaled 36.0mm N52 pockets + 0.45mm conical shear bosses.
module belly_skid_master_trim(z_scale = 0.42, hub_h = 1.60) {
    difference() {
        union() {
            scale([1, 1, z_scale])
                intersection() {
                    children(0);
                    translate([0, 0, 10.0]) cube([100, 100, 20.0], center=true);
                }
            belly_mount_posts(hub_h);
        }
        belly_magnet_cuts(hub_h);
    }
}

// ============================================================================
// 10 PARAMETRIC 3D BELLY SKID ARCHETYPES (arch = 0..9) x 25 SUB-VARIATIONS
// ============================================================================

// ARCH 0: Armored Bash Plate / Plastron / Waffle / PCB Skid
// Varies length, side ribs, hex/grid pockets by subvar (0..24)
module belly_arch_0(subvar = 0) {
    skid_h  = 2.35;
    len_ext = (subvar % 5) * 0.45;
    wid_ext = floor(subvar / 5) * 0.25;
    rib_cnt = 4 + (subvar % 3);
    z_sc    = 0.40 + (subvar % 4) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Octagonal armored plastron plate
            hull() {
                for (x_c = [-18.5 - len_ext, 18.5 + len_ext])
                    for (y_c = [-5.2 - wid_ext, 5.2 + wid_ext])
                        translate([x_c, y_c, 0])
                            cylinder(d=3.6, h=skid_h, $fn=8);
                translate([0, 0, 0])
                    cylinder(d=14.2 + wid_ext, h=skid_h + 0.35, $fn=8);
            }
            // Side bash ribs & waffle blocks along flanks
            for (i = [0 : rib_cnt - 1]) {
                x_r = -14.0 + i * (28.0 / max(1, rib_cnt - 1));
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_r, y_s * (5.0 + wid_ext), 0])
                            cylinder(d=3.4, h=skid_h + 0.55, $fn=6);
                        translate([x_r, y_s * (7.2 + wid_ext), 0])
                            cylinder(d=2.8, h=skid_h + 0.25, $fn=6);
                    }
                }
            }
        }
        // Hex/grid relief pockets along centerline
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=5.8 + (subvar % 3) * 0.2, h=skid_h + 1.2, $fn=(subvar % 2 == 0 ? 6 : 8));
        }
    }
}

// ARCH 1: Clawed / Toed / Cleated Twin Track Runners
// Varies claw count (3..5), runner width, cross-bridge by subvar (0..24)
module belly_arch_1(subvar = 0) {
    skid_h   = 2.40;
    claw_cnt = 3 + (subvar % 3); // 3, 4, or 5 claws
    run_y    = 6.6 + floor(subvar / 5) * 0.28;
    z_sc     = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Central bridge connecting magnet hubs
            hull() {
                translate([-18.5, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([ 18.5, 0, 0]) cylinder(d=10.2, h=skid_h);
            }
            // Twin track runners with cleats/toes
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-19.5, y_s * run_y, 0]) cylinder(d=3.6, h=2.3);
                    translate([ 19.5, y_s * run_y, 0]) cylinder(d=3.6, h=2.3);
                }
                // Forward & rear claw/cleat projections
                for (c = [0 : claw_cnt - 1]) {
                    x_c = -15.0 + c * (30.0 / max(1, claw_cnt - 1));
                    hull() {
                        translate([x_c, y_s * run_y, 0]) cylinder(d=3.8, h=2.7);
                        translate([x_c + 1.2, y_s * (run_y + 2.2), 0]) cylinder(d=2.2, h=2.1, $fn=5);
                    }
                }
            }
            // Cross-bridges tying runners to central spine
            for (x_b = [-15.5, 0.0, 15.5]) {
                translate([x_b, 0, 1.05])
                    cube([4.0, run_y * 2.0, 2.1], center=true);
            }
        }
        for (x_w = [-8.8, 8.8]) {
            hull() {
                translate([x_w - 1.6, 0, -0.1]) cylinder(d=5.5, h=skid_h + 0.4);
                translate([x_w + 1.6, 0, -0.1]) cylinder(d=5.5, h=skid_h + 0.4);
            }
        }
    }
}

// ARCH 2: Hovercraft Skirt / Torus Cushion / Medallion Ring
// Varies outer ring OD, inner louvers, radial struts by subvar (0..24)
module belly_arch_2(subvar = 0) {
    skid_h   = 2.40;
    ring_od  = 16.4 + (subvar % 5) * 0.45;
    hub_od   = 11.0 + floor(subvar / 5) * 0.25;
    z_sc     = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Spine connecting dual magnet hubs
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            // Central hovercraft cushion ring
            translate([0, 0, 0])
                cylinder(d=ring_od, h=skid_h + 0.35);
            // Fore & aft harmonic cushion rings
            for (x_h = [-18.0, 18.0]) {
                translate([x_h, 0, 0])
                    cylinder(d=hub_od, h=skid_h + 0.2);
            }
            // Outer hovercraft skirt bumper rails
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-17.5, y_s * 4.8, 0]) cylinder(d=2.8, h=2.2);
                    translate([  0.0, y_s * (ring_od * 0.46), 0]) cylinder(d=3.0, h=2.4);
                    translate([ 17.5, y_s * 4.8, 0]) cylinder(d=2.8, h=2.2);
                }
            }
        }
        // Central air-cushion plenum chamber & flank vents
        translate([0, 0, -0.1])
            cylinder(d=8.2 + (subvar % 3) * 0.3, h=skid_h + 1.0);
        for (x_w = [-9.5, 9.5]) {
            translate([x_w, 0, -0.1])
                cylinder(d=5.2, h=skid_h + 0.6);
        }
    }
}

// ARCH 3: Cleated Tank Treads / 6-Wheel Rover / Monster Tire Bogies
// Varies wheel/cleat count (3..6), tread depth by subvar (0..24)
module belly_arch_3(subvar = 0) {
    skid_h    = 2.40;
    wheel_cnt = 3 + (subvar % 4); // 3, 4, 5, or 6 wheels per side
    bogie_y   = 7.4 + floor(subvar / 5) * 0.22;
    z_sc      = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Central chassis ladder spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin tank tread rails & cleated bogie wheels
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-16.5, y_s * bogie_y, 0]) cylinder(d=3.0, h=2.2);
                    translate([ 16.5, y_s * bogie_y, 0]) cylinder(d=3.0, h=2.2);
                }
                for (w = [0 : wheel_cnt - 1]) {
                    x_w = -15.5 + w * (31.0 / max(1, wheel_cnt - 1));
                    translate([x_w, y_s * (bogie_y + 0.3), 0])
                        cylinder(d=5.6 - (wheel_cnt * 0.25), h=2.75, $fn=8);
                }
                // Front & rear axle struts
                for (x_a = [-15.0, 0.0, 15.0]) {
                    hull() {
                        translate([x_a, 0, 0]) cylinder(d=3.8, h=skid_h);
                        translate([x_a, y_s * bogie_y, 0]) cylinder(d=3.4, h=2.3);
                    }
                }
            }
        }
        for (x_c = [-8.5, 8.5]) {
            hull() {
                translate([x_c - 1.5, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.4);
                translate([x_c + 1.5, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.4);
            }
        }
    }
}

// ARCH 4: Twin-Tip Snow Skis / Hockey / Banana / Sleigh Runners
// Varies ski tip curl, runner spacing, bridge ribs by subvar (0..24)
module belly_arch_4(subvar = 0) {
    skid_h  = 2.40;
    ski_y   = 6.6 + (subvar % 5) * 0.30;
    tip_x   = 21.5 + floor(subvar / 5) * 0.45;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Central hub spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin-tip snow skis with upturned fore & aft tips
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-19.0, y_s * ski_y, 0]) cylinder(d=3.4, h=2.2);
                    translate([  0.0, y_s * (ski_y + 0.8), 0]) cylinder(d=4.2, h=2.5);
                    translate([ 19.0, y_s * ski_y, 0]) cylinder(d=3.4, h=2.2);
                }
                // Upturned front ski tip curl
                hull() {
                    translate([19.0, y_s * ski_y, 0]) cylinder(d=3.4, h=2.2);
                    translate([tip_x, y_s * (ski_y - 0.8), 1.4]) cylinder(d=2.4, h=1.6);
                }
                // Upturned rear tail curl
                hull() {
                    translate([-19.0, y_s * ski_y, 0]) cylinder(d=3.4, h=2.2);
                    translate([-tip_x + 0.5, y_s * (ski_y - 0.8), 1.2]) cylinder(d=2.2, h=1.5);
                }
            }
            // Cross bridges at magnet hubs
            for (x_b = [-15.5, 15.5]) {
                translate([x_b, 0, 1.05])
                    cube([4.4, ski_y * 2.0, 2.1], center=true);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.4);
        }
    }
}

// ARCH 5: Catamaran Pontoons / Log Raft / Sushi / Outrigger Floats
// Varies pontoon diameter, chine steps, crossbars by subvar (0..24)
module belly_arch_5(subvar = 0) {
    skid_h  = 2.40;
    pont_y  = 7.8 + (subvar % 5) * 0.25;
    pont_d  = 4.0 + floor(subvar / 5) * 0.18;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Central wave-piercing hull spine
            hull() {
                translate([ 21.5, 0, 0]) cylinder(d=3.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([-21.5, 0, 0]) cylinder(d=3.8, h=skid_h);
            }
            // Twin catamaran pontoons with stepped hydroplane chines
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * pont_y, 0]) cylinder(d=2.8, h=2.4);
                    translate([  0.0, y_s * pont_y, 0]) cylinder(d=pont_d, h=2.6);
                    translate([ 20.0, y_s * pont_y, 0]) cylinder(d=2.8, h=2.4);
                }
                // Cross-booms connecting pontoons to central hull
                for (x_b = [-14.5, 14.5]) {
                    hull() {
                        translate([x_b, 0, 0]) cylinder(d=4.2, h=skid_h);
                        translate([x_b, y_s * pont_y, 0]) cylinder(d=3.6, h=2.3);
                    }
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.4);
        }
    }
}

// ARCH 6: Skateboard / Roller Skate / Gamepad / Hoverboard Deck
// Varies deck contour, truck/wheel bumps by subvar (0..24)
module belly_arch_6(subvar = 0) {
    skid_h  = 2.30;
    deck_w  = 12.2 + (subvar % 5) * 0.35;
    truck_x = 12.5 + floor(subvar / 5) * 0.45;
    z_sc    = 0.40 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Contoured skateboard/hoverboard deck with kicktails
            hull() {
                translate([-20.0, 0, 0]) cylinder(d=deck_w - 1.2, h=skid_h);
                translate([  0.0, 0, 0]) cylinder(d=deck_w, h=skid_h);
                translate([ 20.0, 0, 0]) cylinder(d=deck_w - 1.2, h=skid_h);
            }
            // Quad truck hangers & urethane wheel pods
            for (x_t = [-truck_x, truck_x]) {
                translate([x_t, 0, 1.1])
                    cube([4.0, deck_w + 3.2, 2.2], center=true);
                for (y_s = [-1, 1]) {
                    translate([x_t, y_s * (deck_w * 0.5 + 1.8), 0])
                        cylinder(d=5.8, h=2.75);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}

// ARCH 7: Hydroplane Keel / Dragon Tail / Surfboard / Galleon Hull
// Varies central skeg fin, side strakes by subvar (0..24)
module belly_arch_7(subvar = 0) {
    skid_h   = 2.35;
    strake_n = 3 + (subvar % 3); // 3, 4, or 5 strake pairs
    hull_w   = 13.0 + floor(subvar / 5) * 0.30;
    z_sc     = 0.40 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Swept hydroplane/surfboard hull with pointed bow and tapered tail
            hull() {
                translate([ 22.5, 0, 0]) cylinder(d=3.8, h=2.5);
                translate([ 15.0, 0, 0]) cylinder(d=11.0, h=skid_h);
                translate([  0.0, 0, 0]) cylinder(d=hull_w, h=skid_h);
                translate([-18.5, 0, 0]) cylinder(d=10.4, h=skid_h);
                translate([-23.0, 0, 0]) cylinder(d=4.0, h=2.1);
            }
            // Lateral planing strakes & chevron fins
            for (i = [0 : strake_n - 1]) {
                x_s = -12.0 + i * (24.0 / max(1, strake_n - 1));
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_s, 0, 0]) cylinder(d=4.0, h=skid_h + 0.3);
                        translate([x_s - 2.2, y_s * (hull_w * 0.55), 0]) cylinder(d=2.8, h=2.5);
                    }
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.8);
        }
    }
}

// ARCH 8: Quad/Hex Spider Legs / Lunar Lander Pads / Outrigger Feet
// Varies leg sweep angle, footpad diameter by subvar (0..24)
module belly_arch_8(subvar = 0) {
    skid_h  = 2.40;
    pad_d   = 6.4 + (subvar % 5) * 0.30;
    leg_y   = 8.0 + floor(subvar / 5) * 0.25;
    has_mid = (subvar % 2 == 1);
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Central truss spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // 4 corner lunar/spider outrigger legs + saucer footpads
            for (x_p = [-15.0, 15.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_p, 0, 0]) cylinder(d=4.0, h=skid_h);
                        translate([x_p, y_s * leg_y, 0]) cylinder(d=3.2, h=2.2);
                    }
                    translate([x_p, y_s * leg_y, 0])
                        cylinder(d1=pad_d, d2=pad_d - 1.4, h=2.6);
                }
            }
            // Optional middle spider leg pair on odd subvars
            if (has_mid) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([0, 0, 0]) cylinder(d=3.6, h=skid_h);
                        translate([0, y_s * (leg_y + 0.6), 0]) cylinder(d=4.4, h=2.4);
                    }
                }
            }
            // Side longitudinal tie rails connecting front & rear footpads
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-15.0, y_s * leg_y, 0]) cylinder(d=2.4, h=1.9);
                    translate([ 15.0, y_s * leg_y, 0]) cylinder(d=2.4, h=1.9);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.4);
        }
    }
}

// ARCH 9: Venturi Ground-Effect Diffuser / Sub Keel / Jet Strakes
// Varies diffuser tunnel fins (3..5), rear rake by subvar (0..24)
module belly_arch_9(subvar = 0) {
    skid_h  = 2.35;
    fin_cnt = 3 + (subvar % 3); // 3, 4, or 5 rear diffuser vanes
    tun_w   = 6.4 + floor(subvar / 5) * 0.25;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60)
    difference() {
        union() {
            // Aerodynamic ground-effect fuselage spine
            hull() {
                translate([ 21.5, 0, 0]) cylinder(d=8.2, h=skid_h);
                translate([  2.0, 0, 0]) cylinder(d=13.2, h=skid_h);
                translate([-18.5, 0, 0]) cylinder(d=10.4, h=skid_h);
            }
            // Twin outer Venturi tunnel strake rails
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-19.5, y_s * tun_w, 0]) cylinder(d=3.0, h=2.7);
                    translate([ 17.5, y_s * (tun_w - 0.8), 0]) cylinder(d=3.0, h=2.5);
                }
                // Forward canard dive planes
                hull() {
                    translate([14.5, 0, 0]) cylinder(d=4.0, h=skid_h);
                    translate([13.0, y_s * (tun_w + 2.2), 0]) cylinder(d=2.8, h=2.2);
                }
            }
            // Rear multi-vane diffuser fan (-17mm to -23mm)
            for (f = [0 : fin_cnt - 1]) {
                ang = -32 + f * (64.0 / max(1, fin_cnt - 1));
                hull() {
                    translate([-17.0, 0, 0]) cylinder(d=5.2, h=skid_h);
                    translate([-17.0 - 5.8 * cos(ang), 8.5 * sin(ang), 0])
                        cylinder(d=3.2, h=2.3);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}

// Master Parametric Dispatcher for PART_ID = 1751..2000
module render_mega1000_belly(part_id) {
    arch   = (part_id - 1751) % 10;
    subvar = floor((part_id - 1751) / 10);
    if      (arch == 0) belly_arch_0(subvar);
    else if (arch == 1) belly_arch_1(subvar);
    else if (arch == 2) belly_arch_2(subvar);
    else if (arch == 3) belly_arch_3(subvar);
    else if (arch == 4) belly_arch_4(subvar);
    else if (arch == 5) belly_arch_5(subvar);
    else if (arch == 6) belly_arch_6(subvar);
    else if (arch == 7) belly_arch_7(subvar);
    else if (arch == 8) belly_arch_8(subvar);
    else if (arch == 9) belly_arch_9(subvar);
}

// ============================================================================
// NAMED MODULES FOR ALL 250 BELLY SKIDS (PART_ID = 1751..2000)
// ============================================================================
// 1751: 5-Claw Grizzly Track Skids [Kodiak Wilderness] (arch=0, subvar=0)
module KODIAK75_Belly_1751_GrizzlyClawRunners() { belly_arch_0(0); }
// 1752: Cloven Tundra Hoof Pads [Kodiak Wilderness] (arch=1, subvar=0)
module KODIAK75_Belly_1752_MooseHoofSled() { belly_arch_1(0); }
// 1753: Gnawed Aspen Timber Raft [Kodiak Wilderness] (arch=2, subvar=0)
module KODIAK75_Belly_1753_BeaverLogRaft() { belly_arch_2(0); }
// 1754: Silver-Scale Stream Keel [Kodiak Wilderness] (arch=3, subvar=0)
module KODIAK75_Belly_1754_SalmonBellyKeel() { belly_arch_3(0); }
// 1755: Curled Yukon Birch Sled [Kodiak Wilderness] (arch=4, subvar=0)
module KODIAK75_Belly_1755_BirchTobogganCurl() { belly_arch_4(0); }
// 1756: Rawhide Ash-Frame Webbing [Kodiak Wilderness] (arch=5, subvar=0)
module KODIAK75_Belly_1756_SnowshoeLattice() { belly_arch_5(0); }
// 1757: Cushioned Needle Runner [Kodiak Wilderness] (arch=6, subvar=0)
module KODIAK75_Belly_1757_PineBoughBedding() { belly_arch_6(0); }
// 1758: Smooth Glacial Boulder Base [Kodiak Wilderness] (arch=7, subvar=0)
module KODIAK75_Belly_1758_RiverCobbleSkid() { belly_arch_7(0); }
// 1759: Four-Talon Perch Skids [Kodiak Wilderness] (arch=8, subvar=0)
module KODIAK75_Belly_1759_EagleTalonCradle() { belly_arch_8(0); }
// 1760: Mud-Bank Toboggan Groove [Kodiak Wilderness] (arch=9, subvar=0)
module KODIAK75_Belly_1760_OtterBellySlide() { belly_arch_9(0); }
// 1761: Frost-Proof Padded Paws [Kodiak Wilderness] (arch=0, subvar=1)
module KODIAK75_Belly_1761_WolverineTrackPads() { belly_arch_0(1); }
// 1762: Twin Oak-Stave Kegs [Kodiak Wilderness] (arch=1, subvar=1)
module KODIAK75_Belly_1762_HoneyBarrelSkids() { belly_arch_1(1); }
// 1763: Dual Nut-Shell Pontoons [Kodiak Wilderness] (arch=2, subvar=1)
module KODIAK75_Belly_1763_AcornSledRunners() { belly_arch_2(1); }
// 1764: Curved Antler Sled Rails [Kodiak Wilderness] (arch=3, subvar=1)
module KODIAK75_Belly_1764_CaribouSleighRunners() { belly_arch_3(1); }
// 1765: Four-Pad Trail Runners [Kodiak Wilderness] (arch=4, subvar=1)
module KODIAK75_Belly_1765_WolfPackPawSled() { belly_arch_4(1); }
// 1766: Crag-Grip Cloven Skids [Kodiak Wilderness] (arch=5, subvar=1)
module KODIAK75_Belly_1766_BighornHoofCleats() { belly_arch_5(1); }
// 1767: Sphagnum Bog Landing Pad [Kodiak Wilderness] (arch=6, subvar=1)
module KODIAK75_Belly_1767_MossPeatCushion() { belly_arch_6(1); }
// 1768: Cedar-Strip Catamaran [Kodiak Wilderness] (arch=7, subvar=1)
module KODIAK75_Belly_1768_CanoeTwinHulls() { belly_arch_7(1); }
// 1769: Chained Timber Float Base [Kodiak Wilderness] (arch=8, subvar=1)
module KODIAK75_Belly_1769_LogJamBoomSkid() { belly_arch_8(1); }
// 1770: Spiked Brush-Clearer Sled [Kodiak Wilderness] (arch=9, subvar=1)
module KODIAK75_Belly_1770_PorcupineQuillSkid() { belly_arch_9(1); }
// 1771: Silent-Stalk Wide Skids [Kodiak Wilderness] (arch=0, subvar=2)
module KODIAK75_Belly_1771_LynxFurPawPads() { belly_arch_0(2); }
// 1772: Carved Red-Cedar Base [Kodiak Wilderness] (arch=1, subvar=2)
module KODIAK75_Belly_1772_TotemPlankSled() { belly_arch_1(2); }
// 1773: Jagged Pack-Ice Raft [Kodiak Wilderness] (arch=2, subvar=2)
module KODIAK75_Belly_1773_IceFloeSlab() { belly_arch_2(2); }
// 1774: Cross-Stacked Hearth Base [Kodiak Wilderness] (arch=3, subvar=2)
module KODIAK75_Belly_1774_CampfireLogCrib() { belly_arch_3(2); }
// 1775: Yukon Creek Trap Tray [Kodiak Wilderness] (arch=4, subvar=2)
module KODIAK75_Belly_1775_GoldSluiceRiffles() { belly_arch_4(2); }
// 1776: Three-Toe Theropod Tracks [Prehistoric Dinos] (arch=5, subvar=2)
module KODIAK75_Belly_1776_TRexFootprintPads() { belly_arch_5(2); }
// 1777: Armored Osteoderm Plastron [Prehistoric Dinos] (arch=6, subvar=2)
module KODIAK75_Belly_1777_AnkyloBellyScutes() { belly_arch_6(2); }
// 1778: Four-Spike Tail Sled [Prehistoric Dinos] (arch=7, subvar=2)
module KODIAK75_Belly_1778_StegoTailThagomizer() { belly_arch_7(2); }
// 1779: Quad-Paddle Sea Base [Prehistoric Dinos] (arch=8, subvar=2)
module KODIAK75_Belly_1779_PlesioFourFlippers() { belly_arch_8(2); }
// 1780: Sauropod Elephantine Pads [Prehistoric Dinos] (arch=9, subvar=2)
module KODIAK75_Belly_1780_BrachioPillarFeet() { belly_arch_9(2); }
// 1781: Curved Talon Ski-Rails [Prehistoric Dinos] (arch=0, subvar=3)
module KODIAK75_Belly_1781_RaptorSickleRunners() { belly_arch_0(3); }
// 1782: Segmented Thorax Slider [Prehistoric Dinos] (arch=1, subvar=3)
module KODIAK75_Belly_1782_TrilobiteBellyShell() { belly_arch_1(3); }
// 1783: Dual Spiral Shell Skids [Prehistoric Dinos] (arch=2, subvar=3)
module KODIAK75_Belly_1783_AmmoniteTwinCoils() { belly_arch_2(3); }
// 1784: Ice-Age Bone-Runner Sleigh [Prehistoric Dinos] (arch=3, subvar=3)
module KODIAK75_Belly_1784_MammothTuskSled() { belly_arch_3(3); }
// 1785: Vertebrae Ridge Runner [Prehistoric Dinos] (arch=4, subvar=3)
module KODIAK75_Belly_1785_FossilSpineKeel() { belly_arch_4(3); }
// 1786: Twin-Keel Marine Rudder [Prehistoric Dinos] (arch=5, subvar=3)
module KODIAK75_Belly_1786_MosasaurTailFluke() { belly_arch_5(3); }
// 1787: Pahoehoe Rope-Basalt Sled [Prehistoric Dinos] (arch=6, subvar=3)
module KODIAK75_Belly_1787_LavaCrustRunners() { belly_arch_6(3); }
// 1788: Clutch-Ring Cushion Base [Prehistoric Dinos] (arch=7, subvar=3)
module KODIAK75_Belly_1788_DinoEggNestPad() { belly_arch_7(3); }
// 1789: Polished Resin Glider [Prehistoric Dinos] (arch=8, subvar=3)
module KODIAK75_Belly_1789_AmberSlabSlider() { belly_arch_8(3); }
// 1790: Folded Finger-Bone Rails [Prehistoric Dinos] (arch=9, subvar=3)
module KODIAK75_Belly_1790_PteroWingSkids() { belly_arch_9(3); }
// 1791: Twin-Fang Ice Runners [Prehistoric Dinos] (arch=0, subvar=4)
module KODIAK75_Belly_1791_SabertoothJawSled() { belly_arch_0(4); }
// 1792: Swamp-Walker Flat Pads [Prehistoric Dinos] (arch=1, subvar=4)
module KODIAK75_Belly_1792_SpinoWebbedFeet() { belly_arch_1(4); }
// 1793: Scalloped Shield Toboggan [Prehistoric Dinos] (arch=2, subvar=4)
module KODIAK75_Belly_1793_TriceraFrillSled() { belly_arch_2(4); }
// 1794: Serrated Tooth-Row Base [Prehistoric Dinos] (arch=3, subvar=4)
module KODIAK75_Belly_1794_MegalodonJawCradle() { belly_arch_3(4); }
// 1795: Circular Impact Cushion [Prehistoric Dinos] (arch=4, subvar=4)
module KODIAK75_Belly_1795_CraterRimRing() { belly_arch_4(4); }
// 1796: Agate-Core Twin Timbers [Prehistoric Dinos] (arch=5, subvar=4)
module KODIAK75_Belly_1796_PetrifiedWoodLogs() { belly_arch_5(4); }
// 1797: Thick-Bone Bash Plate [Prehistoric Dinos] (arch=6, subvar=4)
module KODIAK75_Belly_1797_StegocerasSkullBase() { belly_arch_6(4); }
// 1798: Finned Ribcage Slider [Prehistoric Dinos] (arch=7, subvar=4)
module KODIAK75_Belly_1798_DimetrodonSpineRail() { belly_arch_7(4); }
// 1799: Bony-Plate Keel Guard [Prehistoric Dinos] (arch=8, subvar=4)
module KODIAK75_Belly_1799_DunkleoArmorBelly() { belly_arch_8(4); }
// 1800: La-Brea Asphalt Cushion [Prehistoric Dinos] (arch=9, subvar=4)
module KODIAK75_Belly_1800_TarPitBubblePad() { belly_arch_9(4); }
// 1801: Ribbed Wyrm Underbelly [Mythic Fantasy] (arch=0, subvar=5)
module KODIAK75_Belly_1801_DragonBellyScales() { belly_arch_0(5); }
// 1802: Streaming Flame-Plume Sled [Mythic Fantasy] (arch=1, subvar=5)
module KODIAK75_Belly_1802_PhoenixTailFeathers() { belly_arch_1(5); }
// 1803: Lion-Paw & Eagle-Claw Base [Mythic Fantasy] (arch=2, subvar=5)
module KODIAK75_Belly_1803_GriffinTalonSkids() { belly_arch_2(5); }
// 1804: Eight-Arm Coiled Cushion [Mythic Fantasy] (arch=3, subvar=5)
module KODIAK75_Belly_1804_KrakenTentacleRaft() { belly_arch_3(5); }
// 1805: Heavy Runed-Iron Foot [Mythic Fantasy] (arch=4, subvar=5)
module KODIAK75_Belly_1805_DwarvenAnvilBase() { belly_arch_4(5); }
// 1806: Lothlorien Vein-Keel Sled [Mythic Fantasy] (arch=5, subvar=5)
module KODIAK75_Belly_1806_ElvenLeafGlider() { belly_arch_5(5); }
// 1807: Tasseled Persian Weave [Mythic Fantasy] (arch=6, subvar=5)
module KODIAK75_Belly_1807_FlyingCarpetFringe() { belly_arch_6(5); }
// 1808: Blocky Granite Stompers [Mythic Fantasy] (arch=7, subvar=5)
module KODIAK75_Belly_1808_GolemStoneFeet() { belly_arch_7(5); }
// 1809: Scythed Bronze-Spoke Skids [Mythic Fantasy] (arch=8, subvar=5)
module KODIAK75_Belly_1809_ChariotTwinWheels() { belly_arch_8(5); }
// 1810: Inscribed Ritual Ring [Mythic Fantasy] (arch=9, subvar=5)
module KODIAK75_Belly_1810_RunicCirclePedestal() { belly_arch_9(5); }
// 1811: Twin Serpent Slither Rails [Mythic Fantasy] (arch=0, subvar=6)
module KODIAK75_Belly_1811_HydraCoiledTails() { belly_arch_0(6); }
// 1812: Cumulus Stride Cushions [Mythic Fantasy] (arch=1, subvar=6)
module KODIAK75_Belly_1812_PegasusHoofClouds() { belly_arch_1(6); }
// 1813: Snapping Wood-Box Base [Mythic Fantasy] (arch=2, subvar=6)
module KODIAK75_Belly_1813_MimicChestTeeth() { belly_arch_2(6); }
// 1814: Tripod Cast-Iron Belly [Mythic Fantasy] (arch=3, subvar=6)
module KODIAK75_Belly_1814_CauldronThreeLegs() { belly_arch_3(6); }
// 1815: Twin Gnawed-Oak Runners [Mythic Fantasy] (arch=4, subvar=6)
module KODIAK75_Belly_1815_WizardStaffRails() { belly_arch_4(6); }
// 1816: Kite-Shield Belly Armor [Mythic Fantasy] (arch=5, subvar=6)
module KODIAK75_Belly_1816_PaladinShieldSled() { belly_arch_5(6); }
// 1817: Spiked Iron-Roller Sled [Mythic Fantasy] (arch=6, subvar=6)
module KODIAK75_Belly_1817_OrcWarChariot() { belly_arch_6(6); }
// 1818: Notched Pond-Leaf Cushion [Mythic Fantasy] (arch=7, subvar=6)
module KODIAK75_Belly_1818_FairyLilypadFloat() { belly_arch_7(6); }
// 1819: Levitation Shard Cradle [Mythic Fantasy] (arch=8, subvar=6)
module KODIAK75_Belly_1819_CrystalClusterBase() { belly_arch_8(6); }
// 1820: Quad-Stance Gallop Pads [Mythic Fantasy] (arch=9, subvar=6)
module KODIAK75_Belly_1820_CentaurFourHooves() { belly_arch_9(6); }
// 1821: Scalloped Fin Hydro-Keel [Mythic Fantasy] (arch=0, subvar=7)
module KODIAK75_Belly_1821_SirenTailFluke() { belly_arch_0(7); }
// 1822: Carved Gothic Plinth [Mythic Fantasy] (arch=1, subvar=7)
module KODIAK75_Belly_1822_GargoylePedestal() { belly_arch_1(7); }
// 1823: Winged Norse Runner Pair [Mythic Fantasy] (arch=2, subvar=7)
module KODIAK75_Belly_1823_ValkyrieSleigh() { belly_arch_2(7); }
// 1824: Segmented Stinger Keel [Mythic Fantasy] (arch=3, subvar=7)
module KODIAK75_Belly_1824_ManticoreScorpion() { belly_arch_3(7); }
// 1825: Cross-Barred Iron Skid [Mythic Fantasy] (arch=4, subvar=7)
module KODIAK75_Belly_1825_DungeonTrapGrate() { belly_arch_4(7); }
// 1826: Split-Roll Mustard Sled [Food & Candy] (arch=5, subvar=7)
module KODIAK75_Belly_1826_HotDogBunCradle() { belly_arch_5(7); }
// 1827: Crisp 16-Pocket Belgian Pad [Food & Candy] (arch=6, subvar=7)
module KODIAK75_Belly_1827_WaffleGridPlate() { belly_arch_6(7); }
// 1828: Smores Honey-Scored Base [Food & Candy] (arch=7, subvar=7)
module KODIAK75_Belly_1828_GrahamCrackerSheet() { belly_arch_7(7); }
// 1829: Snap-Wafer Twin Rails [Food & Candy] (arch=8, subvar=7)
module KODIAK75_Belly_1829_KitKatFourFingers() { belly_arch_8(7); }
// 1830: Dill-Bump Green Pontoons [Food & Candy] (arch=9, subvar=7)
module KODIAK75_Belly_1830_PickleSpearSkids() { belly_arch_9(7); }
// 1831: Cinnamon Brioche Cushion [Food & Candy] (arch=0, subvar=8)
module KODIAK75_Belly_1831_FrenchToastSlab() { belly_arch_0(8); }
// 1832: Salted Twin Timber Skids [Food & Candy] (arch=1, subvar=8)
module KODIAK75_Belly_1832_PretzelRodRails() { belly_arch_1(8); }
// 1833: Red-White Starlight Cushion [Food & Candy] (arch=2, subvar=8)
module KODIAK75_Belly_1833_PeppermintDiscPad() { belly_arch_2(8); }
// 1834: Birch Craft-Stick Runners [Food & Candy] (arch=3, subvar=8)
module KODIAK75_Belly_1834_IcePopStickSkis() { belly_arch_3(8); }
// 1835: Wavy Instant-Block Base [Food & Candy] (arch=4, subvar=8)
module KODIAK75_Belly_1835_RamenNoodleBrick() { belly_arch_4(8); }
// 1836: Flat-Bottom Tortilla Tub [Food & Candy] (arch=5, subvar=8)
module KODIAK75_Belly_1836_TacoBoatCradle() { belly_arch_5(8); }
// 1837: Toasted Hover-Cushion [Food & Candy] (arch=6, subvar=8)
module KODIAK75_Belly_1837_BagelSesameRing() { belly_arch_6(8); }
// 1838: Peanut-Butter Ribbed Rails [Food & Candy] (arch=7, subvar=8)
module KODIAK75_Belly_1838_CeleryStalkBoats() { belly_arch_7(8); }
// 1839: Chocolate-Iced Twin Pontoons [Food & Candy] (arch=8, subvar=8)
module KODIAK75_Belly_1839_EclairPastryPods() { belly_arch_8(8); }
// 1840: Braided Red-Rope Skids [Food & Candy] (arch=9, subvar=8)
module KODIAK75_Belly_1840_LicoriceTwistRails() { belly_arch_9(8); }
// 1841: Swiss-Hole Triangle Keel [Food & Candy] (arch=0, subvar=9)
module KODIAK75_Belly_1841_CheeseWedgeSlider() { belly_arch_0(9); }
// 1842: Footlong Hoagie Pontoons [Food & Candy] (arch=1, subvar=9)
module KODIAK75_Belly_1842_SubSandwichRoll() { belly_arch_1(9); }
// 1843: Cream-Filled Wafer Pad [Food & Candy] (arch=2, subvar=9)
module KODIAK75_Belly_1843_CookieSandwichRing() { belly_arch_2(9); }
// 1844: Rolled-Bark Spice Skids [Food & Candy] (arch=3, subvar=9)
module KODIAK75_Belly_1844_CinnamonStickRaft() { belly_arch_3(9); }
// 1845: Curved Green-Melon Runners [Food & Candy] (arch=4, subvar=9)
module KODIAK75_Belly_1845_WatermelonRindSkis() { belly_arch_4(9); }
// 1846: Wooden Two-Foot Geta Tray [Food & Candy] (arch=5, subvar=9)
module KODIAK75_Belly_1846_SushiGetaboard() { belly_arch_5(9); }
// 1847: Crimped-Edge Berry Base [Food & Candy] (arch=6, subvar=9)
module KODIAK75_Belly_1847_PieCrustLattice() { belly_arch_6(9); }
// 1848: Four-Pillow Campfire Pads [Food & Candy] (arch=7, subvar=9)
module KODIAK75_Belly_1848_MarshmallowPuffs() { belly_arch_7(9); }
// 1849: Golden-Batter Twin Skids [Food & Candy] (arch=8, subvar=9)
module KODIAK75_Belly_1849_CornDogStickRails() { belly_arch_8(9); }
// 1850: Stuffed-Garlic Rim Sled [Food & Candy] (arch=9, subvar=9)
module KODIAK75_Belly_1850_PizzaCrustBumpers() { belly_arch_9(9); }
// 1851: Quad Nebuchadnezzar Discs [Deep Space Sci-Fi] (arch=0, subvar=10)
module KODIAK75_Belly_1851_HoverRepulsorPads() { belly_arch_0(10); }
// 1852: Colonial Folding Struts [Deep Space Sci-Fi] (arch=1, subvar=10)
module KODIAK75_Belly_1852_DropshipLandingSkids() { belly_arch_1(10); }
// 1853: Stainless Aero-Brake Base [Deep Space Sci-Fi] (arch=2, subvar=10)
module KODIAK75_Belly_1853_StarshipBellyFlaps() { belly_arch_2(10); }
// 1854: Telescopic Splat-Pads [Deep Space Sci-Fi] (arch=3, subvar=10)
module KODIAK75_Belly_1854_AlienSaucerTripod() { belly_arch_3(10); }
// 1855: Gundam Twin-Sole Verniers [Deep Space Sci-Fi] (arch=4, subvar=10)
module KODIAK75_Belly_1855_MechaFootThrusters() { belly_arch_4(10); }
// 1856: Perseverance Cleat Treads [Deep Space Sci-Fi] (arch=5, subvar=10)
module KODIAK75_Belly_1856_RoverSixWheelBogie() { belly_arch_5(10); }
// 1857: Subspace Louver Diffuser [Deep Space Sci-Fi] (arch=6, subvar=10)
module KODIAK75_Belly_1857_WarpFieldGrille() { belly_arch_6(10); }
// 1858: Hex-Grid Xenon Thrusters [Deep Space Sci-Fi] (arch=7, subvar=10)
module KODIAK75_Belly_1858_IonDriveNozzleArray() { belly_arch_7(10); }
// 1859: Eagle Crush-Honeycomb Dishes [Deep Space Sci-Fi] (arch=8, subvar=10)
module KODIAK75_Belly_1859_LunarFootpadCups() { belly_arch_8(10); }
// 1860: Neon-Tread Assault Skids [Deep Space Sci-Fi] (arch=9, subvar=10)
module KODIAK75_Belly_1860_CyberTankTracks() { belly_arch_9(10); }
// 1861: Deck-Plating Mag-Lock Base [Deep Space Sci-Fi] (arch=0, subvar=11)
module KODIAK75_Belly_1861_GravityPlateGrid() { belly_arch_0(11); }
// 1862: ISO-Space Ribbed Crate [Deep Space Sci-Fi] (arch=1, subvar=11)
module KODIAK75_Belly_1862_CargoContainerPod() { belly_arch_1(11); }
// 1863: Dual-Tube Stasis Frame [Deep Space Sci-Fi] (arch=2, subvar=11)
module KODIAK75_Belly_1863_CryoSleepCradle() { belly_arch_2(11); }
// 1864: V-Shaped Debris Deflector [Deep Space Sci-Fi] (arch=3, subvar=11)
module KODIAK75_Belly_1864_PlasmaplowSkid() { belly_arch_3(11); }
// 1865: Tensioned Boom Skids [Deep Space Sci-Fi] (arch=4, subvar=11)
module KODIAK75_Belly_1865_SolarSailOutriggers() { belly_arch_4(11); }
// 1866: Ablative Crush-Cone Skirt [Deep Space Sci-Fi] (arch=5, subvar=11)
module KODIAK75_Belly_1866_OrbitalDropPodBase() { belly_arch_5(11); }
// 1867: Articulated Hex-Foot Base [Deep Space Sci-Fi] (arch=6, subvar=11)
module KODIAK75_Belly_1867_SpiderMechSixLegs() { belly_arch_6(11); }
// 1868: Forward-Boom Steering Skis [Deep Space Sci-Fi] (arch=7, subvar=11)
module KODIAK75_Belly_1868_SpeederBikeVanes() { belly_arch_7(11); }
// 1869: Twin Crystalline Runners [Deep Space Sci-Fi] (arch=8, subvar=11)
module KODIAK75_Belly_1869_TachyonSkidRails() { belly_arch_8(11); }
// 1870: Four-Prong Anchor Base [Deep Space Sci-Fi] (arch=9, subvar=11)
module KODIAK75_Belly_1870_AsteroidClampClaws() { belly_arch_9(11); }
// 1871: Inductive Charge Rail Pair [Deep Space Sci-Fi] (arch=0, subvar=12)
module KODIAK75_Belly_1871_DroneDockingShoe() { belly_arch_0(12); }
// 1872: EVA Yellow Grab-Bar Frame [Deep Space Sci-Fi] (arch=1, subvar=12)
module KODIAK75_Belly_1872_ZeroGHandrailSkid() { belly_arch_1(12); }
// 1873: Magnetic Bottle Cradle [Deep Space Sci-Fi] (arch=2, subvar=12)
module KODIAK75_Belly_1873_AntimatterPodRack() { belly_arch_2(12); }
// 1874: Nighthawk Faceted Hull [Deep Space Sci-Fi] (arch=3, subvar=12)
module KODIAK75_Belly_1874_StealthBellyChines() { belly_arch_3(12); }
// 1875: Teleportation Platform Disc [Deep Space Sci-Fi] (arch=4, subvar=12)
module KODIAK75_Belly_1875_PortalPadRing() { belly_arch_4(12); }
// 1876: Wave-Piercing Pontoons [Ocean & Pirates] (arch=5, subvar=12)
module KODIAK75_Belly_1876_CatamaranTwinHulls() { belly_arch_5(12); }
// 1877: Submerged Lift-Wing Rails [Ocean & Pirates] (arch=6, subvar=12)
module KODIAK75_Belly_1877_HydrofoilStrutSkis() { belly_arch_6(12); }
// 1878: Everglades Swamp-Sled [Ocean & Pirates] (arch=7, subvar=12)
module KODIAK75_Belly_1878_AirboatFlatBottom() { belly_arch_7(12); }
// 1879: Clinker-Planked Lapstrake [Ocean & Pirates] (arch=8, subvar=12)
module KODIAK75_Belly_1879_VikingKeelStrakes() { belly_arch_8(12); }
// 1880: Twin Roll-Damping Fins [Ocean & Pirates] (arch=9, subvar=12)
module KODIAK75_Belly_1880_SubBilgeKeels() { belly_arch_9(12); }
// 1881: Lamellar Grip-Pad Base [Ocean & Pirates] (arch=0, subvar=13)
module KODIAK75_Belly_1881_RemoraSuctionDisc() { belly_arch_0(13); }
// 1882: Scuted Belly-Shell Slider [Ocean & Pirates] (arch=1, subvar=13)
module KODIAK75_Belly_1882_SeaTurtlePlastron() { belly_arch_1(13); }
// 1883: Side-Scuttle Walking Base [Ocean & Pirates] (arch=2, subvar=13)
module KODIAK75_Belly_1883_CrabEightLegs() { belly_arch_2(13); }
// 1884: Webbed Ice-Haul Pads [Ocean & Pirates] (arch=3, subvar=13)
module KODIAK75_Belly_1884_WalrusFlipperSled() { belly_arch_3(13); }
// 1885: Malibu Side-By-Side Decks [Ocean & Pirates] (arch=4, subvar=13)
module KODIAK75_Belly_1885_SurfLongboardTwin() { belly_arch_4(13); }
// 1886: Stepped Planing V-Keel [Ocean & Pirates] (arch=5, subvar=13)
module KODIAK75_Belly_1886_JetSkiHullChines() { belly_arch_5(13); }
// 1887: Encrusted Oak-Timbers [Ocean & Pirates] (arch=6, subvar=13)
module KODIAK75_Belly_1887_ShipwreckBarnacles() { belly_arch_6(13); }
// 1888: Twin Navy-Stockless Skids [Ocean & Pirates] (arch=7, subvar=13)
module KODIAK75_Belly_1888_AnchorFlukeSled() { belly_arch_7(13); }
// 1889: Lashed Smuggler Casks [Ocean & Pirates] (arch=8, subvar=13)
module KODIAK75_Belly_1889_RumBarrelRaft() { belly_arch_8(13); }
// 1890: Dory Flat-Transom Skiff [Ocean & Pirates] (arch=9, subvar=13)
module KODIAK75_Belly_1890_RowboatOarlockHull() { belly_arch_9(13); }
// 1891: Weighted Ballast Skirt [Ocean & Pirates] (arch=0, subvar=14)
module KODIAK75_Belly_1891_DivingBellRim() { belly_arch_0(14); }
// 1892: Lagoon Reef Cushion [Ocean & Pirates] (arch=1, subvar=14)
module KODIAK75_Belly_1892_CoralAtollRing() { belly_arch_1(14); }
// 1893: Smooth Pelagic Wing-Base [Ocean & Pirates] (arch=2, subvar=14)
module KODIAK75_Belly_1893_StingrayBellyGlide() { belly_arch_2(14); }
// 1894: Reinforced Crush-Keel [Ocean & Pirates] (arch=3, subvar=14)
module KODIAK75_Belly_1894_IcebreakerSpoonBow() { belly_arch_3(14); }
// 1895: Venetian Ferro-Prow Sled [Ocean & Pirates] (arch=4, subvar=14)
module KODIAK75_Belly_1895_GondolaRockerKeel() { belly_arch_4(14); }
// 1896: Twin-Tube RIB Pontoons [Ocean & Pirates] (arch=5, subvar=14)
module KODIAK75_Belly_1896_InflatableZodiac() { belly_arch_5(14); }
// 1897: Rorqual Grooved Keel [Ocean & Pirates] (arch=6, subvar=14)
module KODIAK75_Belly_1897_WhaleBellyPleats() { belly_arch_6(14); }
// 1898: Spiral Gastropod Base [Ocean & Pirates] (arch=7, subvar=14)
module KODIAK75_Belly_1898_HermitShellSkid() { belly_arch_7(14); }
// 1899: Dual Mark-48 Belly Rack [Ocean & Pirates] (arch=8, subvar=14)
module KODIAK75_Belly_1899_TorpedoTwinCradle() { belly_arch_8(14); }
// 1900: lifesaver Torus Cushion [Ocean & Pirates] (arch=9, subvar=14)
module KODIAK75_Belly_1900_BuoyFloatRing() { belly_arch_9(14); }
// 1901: Triple-Grouser Steel Tracks [Heavy Machines] (arch=0, subvar=15)
module KODIAK75_Belly_1901_ExcavatorCrawler() { belly_arch_0(15); }
// 1902: Alpine Groomer Cleat-Belts [Heavy Machines] (arch=1, subvar=15)
module KODIAK75_Belly_1902_SnowcatWideTracks() { belly_arch_1(15); }
// 1903: Two-Way Entry Stringer Base [Heavy Machines] (arch=2, subvar=15)
module KODIAK75_Belly_1903_ForkliftPalletSkid() { belly_arch_2(15); }
// 1904: Flanged Steel-Rail Trucks [Heavy Machines] (arch=3, subvar=15)
module KODIAK75_Belly_1904_TrainBogieWheels() { belly_arch_3(15); }
// 1905: Twin Vibratory Compactors [Heavy Machines] (arch=4, subvar=15)
module KODIAK75_Belly_1905_RoadRollerDrums() { belly_arch_4(15); }
// 1906: Jabroc Skid-Block & Tunnels [Heavy Machines] (arch=5, subvar=15)
module KODIAK75_Belly_1906_F1PlankDiffuser() { belly_arch_5(15); }
// 1907: Four-Corner Terra-Balloons [Heavy Machines] (arch=6, subvar=15)
module KODIAK75_Belly_1907_MonsterQuadTires() { belly_arch_6(15); }
// 1908: Bell Cross-Tube Landing Gear [Heavy Machines] (arch=7, subvar=15)
module KODIAK75_Belly_1908_HelicopterSkidTubes() { belly_arch_7(15); }
// 1909: Stepped Aluminum Pontoons [Heavy Machines] (arch=8, subvar=15)
module KODIAK75_Belly_1909_SeaplaneEdoFloats() { belly_arch_8(15); }
// 1910: Oversized Low-PSI Rollers [Heavy Machines] (arch=9, subvar=15)
module KODIAK75_Belly_1910_TundraBushTires() { belly_arch_9(15); }
// 1911: Segmented Finger-Cushion [Heavy Machines] (arch=0, subvar=16)
module KODIAK75_Belly_1911_HovercraftBagSkirt() { belly_arch_0(16); }
// 1912: Bolt-On Stump-Guard Plate [Heavy Machines] (arch=1, subvar=16)
module KODIAK75_Belly_1912_BulldozerBellyPan() { belly_arch_1(16); }
// 1913: Gooseneck I-Beam Rails [Heavy Machines] (arch=2, subvar=16)
module KODIAK75_Belly_1913_LowboyTrailerDeck() { belly_arch_2(16); }
// 1914: Four-Corner Jack Stabilizers [Heavy Machines] (arch=3, subvar=16)
module KODIAK75_Belly_1914_CraneOutriggerPads() { belly_arch_3(16); }
// 1915: Angled Earth-Scraper Skids [Heavy Machines] (arch=4, subvar=16)
module KODIAK75_Belly_1915_MineplowTines() { belly_arch_4(16); }
// 1916: Welded Tube-Steel Nerf Bars [Heavy Machines] (arch=5, subvar=16)
module KODIAK75_Belly_1916_OffroadRockSliders() { belly_arch_5(16); }
// 1917: Twin Rear-Caster Struts [Heavy Machines] (arch=6, subvar=16)
module KODIAK75_Belly_1917_DragsterWheelieBars() { belly_arch_6(16); }
// 1918: Carbide-Runner Steer Skis [Heavy Machines] (arch=7, subvar=16)
module KODIAK75_Belly_1918_SnowmobileTwinSkis() { belly_arch_7(16); }
// 1919: Hollow-Drum Mud Floats [Heavy Machines] (arch=8, subvar=16)
module KODIAK75_Belly_1919_SwampBuggyPontoons() { belly_arch_8(16); }
// 1920: Aerodynamic Ice-Track Blades [Heavy Machines] (arch=9, subvar=16)
module KODIAK75_Belly_1920_BobsledFourRunners() { belly_arch_9(16); }
// 1921: Heavy-Plate Channel Runners [Heavy Machines] (arch=0, subvar=17)
module KODIAK75_Belly_1921_ForkliftSkidShoe() { belly_arch_0(17); }
// 1922: Terrain-Following Wear Plates [Heavy Machines] (arch=1, subvar=17)
module KODIAK75_Belly_1922_combineHeaderSkids() { belly_arch_1(17); }
// 1923: V-Hull Blast-Deflector [Heavy Machines] (arch=2, subvar=17)
module KODIAK75_Belly_1923_TankBellyMinePlate() { belly_arch_2(17); }
// 1924: Tailhook Belly-Strut Keel [Heavy Machines] (arch=3, subvar=17)
module KODIAK75_Belly_1924_AircraftArrestor() { belly_arch_3(17); }
// 1925: Four-Post Pyramid Footpads [Heavy Machines] (arch=4, subvar=17)
module KODIAK75_Belly_1925_JackStandBase() { belly_arch_4(17); }
// 1926: 4x8 Hollow-Tube Underside [Arcade, Toys & Sports] (arch=5, subvar=17)
module KODIAK75_Belly_1926_LegoBaseplateGrid() { belly_arch_5(17); }
// 1927: Orange Side-Wall Speed Rails [Arcade, Toys & Sports] (arch=6, subvar=17)
module KODIAK75_Belly_1927_HotWheelsTrackPair() { belly_arch_6(17); }
// 1928: Double-Row Pip Runners [Arcade, Toys & Sports] (arch=7, subvar=17)
module KODIAK75_Belly_1928_DominoTrainTrack() { belly_arch_7(17); }
// 1929: Trapezoid Tape-Window Skid [Arcade, Toys & Sports] (arch=8, subvar=17)
module KODIAK75_Belly_1929_CassetteShellBase() { belly_arch_8(17); }
// 1930: Coin-Door Cabinet Plinth [Arcade, Toys & Sports] (arch=9, subvar=17)
module KODIAK75_Belly_1930_ArcadePedestalBase() { belly_arch_9(17); }
// 1931: Dual-Flipper Lane Sled [Arcade, Toys & Sports] (arch=0, subvar=18)
module KODIAK75_Belly_1931_PinballPlayfield() { belly_arch_0(18); }
// 1932: 64-Square Checkered Base [Arcade, Toys & Sports] (arch=1, subvar=18)
module KODIAK75_Belly_1932_ChessboardGridPad() { belly_arch_1(18); }
// 1933: Property-Edge Square Ring [Arcade, Toys & Sports] (arch=2, subvar=18)
module KODIAK75_Belly_1933_MonopolyBoardFrame() { belly_arch_2(18); }
// 1934: Twin Imperial Disc Pads [Arcade, Toys & Sports] (arch=3, subvar=18)
module KODIAK75_Belly_1934_YoYoHalfShells() { belly_arch_3(18); }
// 1935: Compressed Spring-Ring Base [Arcade, Toys & Sports] (arch=4, subvar=18)
module KODIAK75_Belly_1935_SlinkyFlatCoils() { belly_arch_4(18); }
// 1936: Twin-Tip Camber Freestyle [Arcade, Toys & Sports] (arch=5, subvar=18)
module KODIAK75_Belly_1936_SnowboardWideDeck() { belly_arch_5(18); }
// 1937: Slalom Bevel-Edge Skis [Arcade, Toys & Sports] (arch=6, subvar=18)
module KODIAK75_Belly_1937_WaterSkiPair() { belly_arch_6(18); }
// 1938: Hockey Tuuk-Holder Runners [Arcade, Toys & Sports] (arch=7, subvar=18)
module KODIAK75_Belly_1938_IceSkateHollowBlades() { belly_arch_7(18); }
// 1939: 8-Pin Sprint Cleat Rails [Arcade, Toys & Sports] (arch=8, subvar=18)
module KODIAK75_Belly_1939_TrackSpikeShoes() { belly_arch_8(18); }
// 1940: Padded Vault-Box Base [Arcade, Toys & Sports] (arch=9, subvar=18)
module KODIAK75_Belly_1940_GymnasticsPommel() { belly_arch_9(18); }
// 1941: Directional Sweeper Slider [Arcade, Toys & Sports] (arch=0, subvar=19)
module KODIAK75_Belly_1941_CurlingBroomPad() { belly_arch_0(19); }
// 1942: Center-Net Court Baseplate [Arcade, Toys & Sports] (arch=1, subvar=19)
module KODIAK75_Belly_1942_PingPongTableGrid() { belly_arch_1(19); }
// 1943: Four-Corner Turnbuckle Pad [Arcade, Toys & Sports] (arch=2, subvar=19)
module KODIAK75_Belly_1943_BoxingRingCanvas() { belly_arch_2(19); }
// 1944: Three-Ring Grapple Cushion [Arcade, Toys & Sports] (arch=3, subvar=19)
module KODIAK75_Belly_1944_WrestlingMatCircle() { belly_arch_3(19); }
// 1945: Hexagonal Bounce-Frame [Arcade, Toys & Sports] (arch=4, subvar=19)
module KODIAK75_Belly_1945_TrampolineSpringRing() { belly_arch_4(19); }
// 1946: Quad-Molded Channel Sled [Arcade, Toys & Sports] (arch=5, subvar=19)
module KODIAK75_Belly_1946_WakeboardFinnedDeck() { belly_arch_5(19); }
// 1947: Curved Gudgeon Ice-Runners [Arcade, Toys & Sports] (arch=6, subvar=19)
module KODIAK75_Belly_1947_LugeTwinKufen() { belly_arch_6(19); }
// 1948: Weighted Steel-Runner Plank [Arcade, Toys & Sports] (arch=7, subvar=19)
module KODIAK75_Belly_1948_SkeletonSledFrame() { belly_arch_7(19); }
// 1949: All-Terrain Spring-Truck Base [Arcade, Toys & Sports] (arch=8, subvar=19)
module KODIAK75_Belly_1949_MountainBoardDeck() { belly_arch_8(19); }
// 1950: Grip-Tape Boxed Channel [Arcade, Toys & Sports] (arch=9, subvar=19)
module KODIAK75_Belly_1950_ScooterAluminumDeck() { belly_arch_9(19); }
// 1951: Three-Pedal Brass-Frame Sled [Music, Gems & Storm] (arch=0, subvar=20)
module KODIAK75_Belly_1951_PianoPedalLyre() { belly_arch_0(20); }
// 1952: Stompbox Angled Rail-Frame [Music, Gems & Storm] (arch=1, subvar=20)
module KODIAK75_Belly_1952_PedalboardVelcro() { belly_arch_1(20); }
// 1953: Graduated Rosewood Bar Raft [Music, Gems & Storm] (arch=2, subvar=20)
module KODIAK75_Belly_1953_XylophoneResonators() { belly_arch_2(20); }
// 1954: Isolated Sorbothane-Foot Base [Music, Gems & Storm] (arch=3, subvar=20)
module KODIAK75_Belly_1954_TurntablePlinth() { belly_arch_3(20); }
// 1955: Twin-Woofer Bottom Chassis [Music, Gems & Storm] (arch=4, subvar=20)
module KODIAK75_Belly_1955_BoomboxCassetteDeck() { belly_arch_4(20); }
// 1956: Cumulus Soft-Touch Belly [Music, Gems & Storm] (arch=5, subvar=20)
module KODIAK75_Belly_1956_CloudPillowCushion() { belly_arch_5(20); }
// 1957: Radial Ice-Crystal Base [Music, Gems & Storm] (arch=6, subvar=20)
module KODIAK75_Belly_1957_SnowflakeSixSkids() { belly_arch_6(20); }
// 1958: Split-Fault Basalt Rails [Music, Gems & Storm] (arch=7, subvar=20)
module KODIAK75_Belly_1958_TectonicSlabRunners() { belly_arch_7(20); }
// 1959: Agate-Banded Rim Cushion [Music, Gems & Storm] (arch=8, subvar=20)
module KODIAK75_Belly_1959_GeodeHalfBowl() { belly_arch_8(20); }
// 1960: Twin Fort-Knox Ingot Skids [Music, Gems & Storm] (arch=9, subvar=20)
module KODIAK75_Belly_1960_GoldBullionBars() { belly_arch_9(20); }
// 1961: Brilliant-Cut Belly Shield [Music, Gems & Storm] (arch=0, subvar=21)
module KODIAK75_Belly_1961_DiamondFacetKeel() { belly_arch_0(21); }
// 1962: Interlocking Brass-Cog Base [Music, Gems & Storm] (arch=1, subvar=21)
module KODIAK75_Belly_1962_SteampunkGearPlate() { belly_arch_1(21); }
// 1963: Coupled Wheel-Rail Chassis [Music, Gems & Storm] (arch=2, subvar=21)
module KODIAK75_Belly_1963_LocomotiveDriveRods() { belly_arch_2(21); }
// 1964: Truss-Braced Gondola Keel [Music, Gems & Storm] (arch=3, subvar=21)
module KODIAK75_Belly_1964_AirshipLandingSkid() { belly_arch_3(21); }
// 1965: Coiled Barrel-Arbor Base [Music, Gems & Storm] (arch=4, subvar=21)
module KODIAK75_Belly_1965_ClockworkMainspring() { belly_arch_4(21); }
// 1966: Pleated Leather Cushion [Music, Gems & Storm] (arch=5, subvar=21)
module KODIAK75_Belly_1966_BellowsHingePlate() { belly_arch_5(21); }
// 1967: Scrollwork Cast-Iron Sled [Music, Gems & Storm] (arch=6, subvar=21)
module KODIAK75_Belly_1967_VictorianIronGrate() { belly_arch_6(21); }
// 1968: Copper Grounding-Bar Pair [Music, Gems & Storm] (arch=7, subvar=21)
module KODIAK75_Belly_1968_LightningRodRails() { belly_arch_7(21); }
// 1969: ConcentricGroove Suction Base [Music, Gems & Storm] (arch=8, subvar=21)
module KODIAK75_Belly_1969_WhirlpoolSpiralPad() { belly_arch_8(21); }
// 1970: Wide-Camber Desert Skis [Music, Gems & Storm] (arch=9, subvar=21)
module KODIAK75_Belly_1970_SandDuneSkimmers() { belly_arch_9(21); }
// 1971: Multi-Point Cavern Base [Music, Gems & Storm] (arch=0, subvar=22)
module KODIAK75_Belly_1971_StalactiteDripRack() { belly_arch_0(22); }
// 1972: Dual Optical-Wedge Runners [Music, Gems & Storm] (arch=1, subvar=22)
module KODIAK75_Belly_1972_PrismTriangleRails() { belly_arch_1(22); }
// 1973: Polished Volcanic Glider [Music, Gems & Storm] (arch=2, subvar=22)
module KODIAK75_Belly_1973_ObsidianMirrorSlab() { belly_arch_2(22); }
// 1974: Hopper-Crystal Square Base [Music, Gems & Storm] (arch=3, subvar=22)
module KODIAK75_Belly_1974_BismuthStepPlinth() { belly_arch_3(22); }
// 1975: Eight-Point Wind-Star Disc [Music, Gems & Storm] (arch=4, subvar=22)
module KODIAK75_Belly_1975_CompassRoseMedallion() { belly_arch_4(22); }
// 1976: 20-Foot Undulating Runners [Bugs, Spooky & Heroes] (arch=5, subvar=22)
module KODIAK75_Belly_1976_CentipedeLegRails() { belly_arch_5(22); }
// 1977: Segmented Sternite Slider [Bugs, Spooky & Heroes] (arch=6, subvar=22)
module KODIAK75_Belly_1977_ScorpionBellyPlates() { belly_arch_6(22); }
// 1978: Roly-Poly Woodlouse Shell [Bugs, Spooky & Heroes] (arch=7, subvar=22)
module KODIAK75_Belly_1978_PillbugArmadillo() { belly_arch_7(22); }
// 1979: Hydrophobic Hair-Tip Outriggers [Bugs, Spooky & Heroes] (arch=8, subvar=22)
module KODIAK75_Belly_1979_WaterStriderSkis() { belly_arch_8(22); }
// 1980: Six-Hooked Claw Footpads [Bugs, Spooky & Heroes] (arch=9, subvar=22)
module KODIAK75_Belly_1980_BeetleTarsiPads() { belly_arch_9(22); }
// 1981: Spined Saguaro Timber Pair [Bugs, Spooky & Heroes] (arch=0, subvar=23)
module KODIAK75_Belly_1981_CactusRibSkids() { belly_arch_0(23); }
// 1982: Giant Amazonia Rim-Disc [Bugs, Spooky & Heroes] (arch=1, subvar=23)
module KODIAK75_Belly_1982_LilypadRibbedFloat() { belly_arch_1(23); }
// 1983: Six-Sided Pine Toe-Pincher [Bugs, Spooky & Heroes] (arch=2, subvar=23)
module KODIAK75_Belly_1983_CoffinBoxSled() { belly_arch_2(23); }
// 1984: Sternum & 8-RibToboggan [Bugs, Spooky & Heroes] (arch=3, subvar=23)
module KODIAK75_Belly_1984_SkeletonRibSled() { belly_arch_3(23); }
// 1985: Radial-Silk Cushion Ring [Bugs, Spooky & Heroes] (arch=4, subvar=23)
module KODIAK75_Belly_1985_SpiderWebTrampoline() { belly_arch_4(23); }
// 1986: Folded-Membrane Belly Keel [Bugs, Spooky & Heroes] (arch=5, subvar=23)
module KODIAK75_Belly_1986_BatWingGliderSkid() { belly_arch_5(23); }
// 1987: Curled-Tendril Runner Pair [Bugs, Spooky & Heroes] (arch=6, subvar=23)
module KODIAK75_Belly_1987_PumpkinVinesSled() { belly_arch_6(23); }
// 1988: Ornamental Red-Gold Runners [Bugs, Spooky & Heroes] (arch=7, subvar=23)
module KODIAK75_Belly_1988_SantaSleighScrolls() { belly_arch_7(23); }
// 1989: Iditarod Brush-Bow Skids [Bugs, Spooky & Heroes] (arch=8, subvar=23)
module KODIAK75_Belly_1989_DogSledAshRunners() { belly_arch_8(23); }
// 1990: Round Star-Disc Belly Slide [Bugs, Spooky & Heroes] (arch=9, subvar=23)
module KODIAK75_Belly_1990_HeroShieldSled() { belly_arch_9(23); }
// 1991: Six-Tire Armored Belly Pan [Bugs, Spooky & Heroes] (arch=0, subvar=24)
module KODIAK75_Belly_1991_BatmobileTumbler() { belly_arch_0(24); }
// 1992: 2015 Dual-Pitbull Booster Pad [Bugs, Spooky & Heroes] (arch=1, subvar=24)
module KODIAK75_Belly_1992_HoverboardPinkDeck() { belly_arch_1(24); }
// 1993: Hover-Dom High-Speed Skids [Bugs, Spooky & Heroes] (arch=2, subvar=24)
module KODIAK75_Belly_1993_AnimeMechaSkis() { belly_arch_2(24); }
// 1994: Gold-Trace Solder-Pad Base [Bugs, Spooky & Heroes] (arch=3, subvar=24)
module KODIAK75_Belly_1994_CircuitBoardPCB() { belly_arch_3(24); }
// 1995: Linear-Induction Maglev Skis [Bugs, Spooky & Heroes] (arch=4, subvar=24)
module KODIAK75_Belly_1995_MagnetRailCoils() { belly_arch_4(24); }
// 1996:  Johnny-5 Tri-Track Base [Bugs, Spooky & Heroes] (arch=5, subvar=24)
module KODIAK75_Belly_1996_RoboticTankTreads() { belly_arch_5(24); }
// 1997: Thoroughbrace Leather-Spring Skids [Bugs, Spooky & Heroes] (arch=6, subvar=24)
module KODIAK75_Belly_1997_StagecoachRockers() { belly_arch_6(24); }
// 1998: Welded Bull-Bar Belly Cage [Bugs, Spooky & Heroes] (arch=7, subvar=24)
module KODIAK75_Belly_1998_OutbackRoorBar() { belly_arch_7(24); }
// 1999: Flared-Rim Prospecting Dish [Bugs, Spooky & Heroes] (arch=8, subvar=24)
module KODIAK75_Belly_1999_GoldPanRoundSled() { belly_arch_8(24); }
// 2000: Three-Tier Trophy Plinth [Bugs, Spooky & Heroes] (arch=9, subvar=24)
module KODIAK75_Belly_2000_ChampionPodiumBase() { belly_arch_9(24); }

// ============================================================================
// CLI ENTRYPOINT (PART_ID = 1751..2000)
// ============================================================================
if (PART_ID >= 1751 && PART_ID <= 2000) {
    render_mega1000_belly(PART_ID);
} else {
    belly_arch_0(0);
}
