// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: CHEEK POD PAIRS BATCH B (PART_ID 2576..2750)
// 175 Distinct Support-Free Left/Right Mirrored Cheek Pairs (14 Archetypes x 12.5 Subvars)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.65g .. 1.15g per pair (0.32g .. 0.58g per pod, 540 .. 950 mm^3 pair volume)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Zones 2 & 3 Universal Top-Facing Conical Shear Boss + N52 Pocket (Y = +/-15mm)
// ============================================================================

$fn = 28;

PART_ID = 2576;

// --- Master Interface Constants ---
mag_pocket_dia      = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth    = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1     = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2     = 2.10; // Tip diameter of male conical shear boss
shear_boss_height   = 0.45; // Height of male conical shear boss
cheek_pair_offset_y = 15.0; // Left pod at Y = -15.0mm, Right pod at Y = +15.0mm

// ============================================================================
// UNIVERSAL CHEEK HUB & CONICAL SHEAR BOSS MODULES
// ============================================================================

module n52_mating_pocket_cut_up() {
    translate([0, 0, shear_boss_height - mag_pocket_depth])
        cylinder(d = mag_pocket_dia, h = 20.0);
}

module cheek_hub_solid(pad_h = 2.2, span_x = 16.0) {
    half_x = span_x / 2 - 2.2;
    hull() {
        cylinder(d = 8.6, h = pad_h);
        translate([-half_x, 0, 0]) cylinder(d = 4.2, h = pad_h);
        translate([ half_x, 0, 0]) cylinder(d = 4.2, h = pad_h);
    }
    // Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45) at Z = pad_h
    translate([0, 0, pad_h - 0.10])
        cylinder(d1 = shear_boss_dia1 + 0.10, d2 = shear_boss_dia2, h = shear_boss_height + 0.10);
}

module cheek_hub_cuts(pad_h = 2.2, relief_d = 4.2, relief_y = 5.4, relief_h = 1.15) {
    translate([0, 0, pad_h])
        n52_mating_pocket_cut_up();
}

// ============================================================================
// 14 CREATIVE SUPPORT-FREE 3D CHEEK POD ARCHETYPES (arch = 0..13, subvar = 12..24)
// Each models a single Right pod (+Y outboard, +X forward, Z=0 flat)
// ============================================================================

// ARCH 0: Hyper-Swept Delta Canards (supersonic delta winglets with notched leading edge)
module cheek_w4_b_arch_0(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.2 + (sv % 4) * 0.7;
    pad_h  = 2.20;
    wing_y = 8.5 + (sv % 3) * 0.6;
    sweep  = -1.8 + (sv % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Delta wing plate
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([sweep, wing_y, 0]) cylinder(d1 = 3.6, d2 = 1.4, h = pad_h + 0.7);
            }
            // Dogtooth notch rib
            translate([sweep + 1.6, wing_y * 0.7, 0])
                cylinder(d1 = 2.4, d2 = 1.0, h = pad_h + 0.7, $fn = 3);
        }
        cheek_hub_cuts(pad_h, 4.4, wing_y * 0.55, 1.25);
    }
}

// ARCH 1: Chobham Composite Armor Blocks (sloped composite plates with deflector ridges)
module cheek_w4_b_arch_1(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.8 + (sv % 3) * 0.75;
    pad_h  = 2.20;
    out_y  = 8.4 + (sv % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Sloped armor block
            hull() {
                translate([-span_x * 0.36, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.5, $fn = 8);
                translate([ span_x * 0.36, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.5, $fn = 8);
                translate([0, out_y, 0]) cylinder(d1 = 6.2, d2 = 3.0, h = pad_h + 0.9, $fn = 8);
            }
            // Deflector ridge
            translate([0, out_y * 0.65, 0])
                cylinder(d1 = 3.4, d2 = 1.4, h = pad_h + 1.0, $fn = 4);
        }
        cheek_hub_cuts(pad_h, 4.6, out_y * 0.6, 1.3);
    }
}

// ARCH 2: Quad-Tube Micro-Torpedo Launchers (tiered missile bay fairings with finlets)
module cheek_w4_b_arch_2(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.0 + (sv % 4) * 0.65;
    pad_h  = 2.15;
    tube_l = 8.6 + (sv % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Micro-torpedo launcher pod block
            for (xs = [-1, 1]) {
                translate([xs * 3.6, 2.2, 0]) {
                    hull() {
                        cylinder(d = 4.4, h = pad_h + 0.4);
                        translate([0, tube_l * 0.7, 0])
                            cylinder(d1 = 4.0, d2 = 2.0, h = pad_h + 0.6);
                    }
                    translate([0, tube_l * 0.7, 0])
                        cylinder(d1 = 2.0, d2 = 0.8, h = pad_h + 1.2);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.2, 5.8, 1.2);
    }
}

// ARCH 3: Scramjet Convergent-Divergent Intakes (faceted high-Mach ram diffusers)
module cheek_w4_b_arch_3(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.8 + (sv % 3) * 0.75;
    pad_h  = 2.20;
    intake_y = 8.5 + (sv % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Scramjet diffuser duct cowl
            hull() {
                translate([-span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.5);
                translate([ span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.5);
                translate([1.2, intake_y, 0]) cylinder(d1 = 5.2, d2 = 2.6, h = pad_h + 0.8, $fn = 6);
            }
            // Intake shock cone
            translate([1.2, intake_y * 0.7, 0])
                cylinder(d1 = 3.0, d2 = 1.2, h = pad_h + 1.0, $fn = 3);
        }
        cheek_hub_cuts(pad_h, 4.4, intake_y * 0.58, 1.25);
    }
}

// ARCH 4: Cyber-Dragon Fang Bumpers (faceted cybernetic predatory fangs)
module cheek_w4_b_arch_4(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.2 + (sv % 4) * 0.6;
    pad_h  = 2.15;
    fang_y = 8.8 + (sv % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Dragon jaw cheek crest with unified knuckle plane
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.35);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.35);
                translate([0, 5.6, 0]) cylinder(d = 5.6, h = pad_h + 0.35);
            }
            // Dual predatory cyber fangs with harmonized root height
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 2.8, 4.4, 0]) cylinder(d = 3.4, h = pad_h + 0.35);
                    translate([xs * 3.4, fang_y, 0]) cylinder(d1 = 2.6, d2 = 1.0, h = pad_h + 0.65, $fn = 4);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.2, 5.8, 1.2);
    }
}

// ARCH 5: High-Frequency Resonance Blades (ultra-thin beveled sonic edge foils)
module cheek_w4_b_arch_5(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.6 + (sv % 3) * 0.7;
    pad_h  = 2.20;
    blade_y = 8.6 + (sv % 4) * 0.6;
    sweep   = 2.2 + (sv % 3) * 0.5;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // High-frequency sonic blade foil
            hull() {
                translate([-span_x * 0.3, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.3);
                translate([ span_x * 0.3, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.3);
                translate([sweep, blade_y, 0]) cylinder(d1 = 3.0, d2 = 0.9, h = pad_h + 0.8);
            }
            // Sonic transducer node
            translate([sweep * 0.5, blade_y * 0.6, 0])
                cylinder(d1 = 2.6, d2 = 1.0, h = pad_h + 0.8, $fn = 6);
        }
        cheek_hub_cuts(pad_h, 4.2, blade_y * 0.55, 1.2);
    }
}

// ARCH 6: Ion Thruster Linear Emitters (linear accelerator grid fins with cowls)
module cheek_w4_b_arch_6(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.0 + (sv % 4) * 0.65;
    pad_h  = 2.20;
    ion_y  = 8.4 + (sv % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Ion engine nacelle housing
            hull() {
                translate([0, 3.0, 0]) cylinder(d = 7.8, h = pad_h + 0.5);
                translate([0, ion_y, 0]) cylinder(d1 = 6.6, d2 = 3.4, h = pad_h + 0.8, $fn = 8);
            }
            // Acceleration grid bars
            for (xs = [-1, 1]) {
                translate([xs * 3.4, ion_y * 0.65, 0])
                    cylinder(d1 = 2.4, d2 = 1.0, h = pad_h + 0.5);
            }
        }
        cheek_hub_cuts(pad_h, 4.6, ion_y * 0.6, 1.3);
    }
}

// ARCH 7: Heavy Ribbed Thermal Heatsinks (comb-finned avionics cooler blocks)
module cheek_w4_b_arch_7(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.8 + (sv % 3) * 0.7;
    pad_h  = 2.20;
    out_y  = 8.3 + (sv % 4) * 0.5;
    n_ribs = 4 + (sv % 3);
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Heatsink base block
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ 0, out_y, 0]) cylinder(d = 5.4, h = pad_h + 0.6);
            }
            // Radiator cooling ribs
            for (i = [0 : n_ribs - 1]) {
                frac = (i / max(1, n_ribs - 1)) - 0.5;
                tx = frac * (span_x * 0.65);
                translate([tx, out_y * 0.75, 0])
                    cylinder(d1 = 2.6, d2 = 1.2, h = pad_h + 0.6);
            }
        }
        cheek_hub_cuts(pad_h, 4.4, out_y * 0.58, 1.25);
    }
}

// ARCH 8: Runic Energy Aegis Plates (beveled octagonal aegis crest with studs)
module cheek_w4_b_arch_8(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.2 + (sv % 4) * 0.6;
    pad_h  = 2.15;
    aegis_y = 8.5 + (sv % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Octagonal aegis plate
            hull() {
                translate([-span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([0, aegis_y, 0]) cylinder(d1 = 7.2, d2 = 3.6, h = pad_h + 0.8, $fn = 8);
            }
            // Central runic crest stud
            translate([0, aegis_y * 0.75, 0])
                cylinder(d1 = 3.4, d2 = 1.4, h = pad_h + 1.1, $fn = 8);
        }
        cheek_hub_cuts(pad_h, 4.6, aegis_y * 0.65, 1.3);
    }
}

// ARCH 9: Sharkskin Riblet Boundary Vanes (multi-step fluidic boundary-layer trips)
module cheek_w4_b_arch_9(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.6 + (sv % 3) * 0.75;
    pad_h  = 2.20;
    vane_y = 8.6 + (sv % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Aerodynamic flow fairing
            hull() {
                translate([-span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([ span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([ 0, vane_y, 0]) cylinder(d1 = 3.8, d2 = 1.6, h = pad_h + 0.6);
            }
            // Sharkskin micro-riblets
            for (xs = [-1, 0, 1]) {
                translate([xs * 3.2, vane_y * 0.65, 0])
                    cylinder(d1 = 2.4, d2 = 0.8, h = pad_h + 0.7, $fn = 3);
            }
        }
        cheek_hub_cuts(pad_h, 4.2, vane_y * 0.55, 1.2);
    }
}

// ARCH 10: Phased Array Radar Slabs (stepped sensor facet panels with emitter hubs)
module cheek_w4_b_arch_10(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.0 + (sv % 4) * 0.6;
    pad_h  = 2.15;
    radar_y = 8.5 + (sv % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Radar panel facet slab
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ 0, radar_y, 0]) cylinder(d1 = 4.8, d2 = 2.2, h = pad_h + 0.7, $fn = 6);
            }
            // Phased array emitter nodes
            for (xs = [-1, 0, 1]) {
                translate([xs * 1.6, radar_y * 0.75, 0])
                    cylinder(d1 = 2.2, d2 = 1.0, h = pad_h + 1.0, $fn = 6);
            }
        }
        cheek_hub_cuts(pad_h, 4.4, radar_y * 0.58, 1.25);
    }
}

// ARCH 11: Vectoring Nozzle Pods (gimballed thruster fairing shells with heat shields)
module cheek_w4_b_arch_11(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.2 + (sv % 3) * 0.7;
    pad_h  = 2.20;
    nozzle_y = 8.6 + (sv % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Gimballed thruster fairing
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 3.6, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                    translate([xs * 4.0, nozzle_y, 0]) cylinder(d1 = 4.6, d2 = 2.4, h = pad_h + 0.8);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.4, nozzle_y * 0.6, 1.25);
    }
}

// ARCH 12: Exo-Skeleton Segmented Mandibles (articulated chitinous pincer blades)
module cheek_w4_b_arch_12(subvar = 12) {
    sv     = subvar - 12;
    span_x = 14.8 + (sv % 4) * 0.6;
    pad_h  = 2.15;
    mand_y = 8.6 + (sv % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Articulated chitinous pincer blade
            hull() {
                translate([-span_x * 0.35, 2.4, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.4, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ 1.4, mand_y, 0]) cylinder(d1 = 3.6, d2 = 1.2, h = pad_h + 0.8);
            }
            // Side chitin tooth
            hull() {
                translate([0, 4.6, 0]) cylinder(d = 3.6, h = pad_h + 0.3);
                translate([2.6, mand_y * 0.85, 0]) cylinder(d1 = 2.6, d2 = 0.9, h = pad_h + 0.6);
            }
        }
        cheek_hub_cuts(pad_h, 4.2, mand_y * 0.55, 1.2);
    }
}

// ARCH 13: Hydraulic Shock-Absorber Piston Bumpers (heavy cylindrical dampeners)
module cheek_w4_b_arch_13(subvar = 12) {
    sv     = subvar - 12;
    span_x = 15.0 + (sv % 3) * 0.75;
    pad_h  = 2.20;
    piston_y = 8.6 + (sv % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Heavy hydraulic cylinder cowl
            hull() {
                translate([-span_x * 0.35, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.4);
                translate([0, piston_y, 0]) cylinder(d1 = 6.4, d2 = 3.6, h = pad_h + 0.6, $fn = 8);
            }
            // Piston shaft head
            translate([0, piston_y * 0.92, 0])
                cylinder(d1 = 3.6, d2 = 1.8, h = pad_h + 0.8, $fn = 6);
        }
        cheek_hub_cuts(pad_h, 4.6, piston_y * 0.62, 1.3);
    }
}

// ============================================================================
// SINGLE CHEEK POD DISPATCHER & MIRRORED PAIR RENDERER (PART_ID = 2576..2750)
// ============================================================================
module single_cheek_pod_w4_b(part_id) {
    idx    = part_id - 2401;
    arch   = idx % 14;
    subvar = floor(idx / 14); // 12..24 for 2576..2750

    if      (arch ==  0) cheek_w4_b_arch_0(subvar);
    else if (arch ==  1) cheek_w4_b_arch_1(subvar);
    else if (arch ==  2) cheek_w4_b_arch_2(subvar);
    else if (arch ==  3) cheek_w4_b_arch_3(subvar);
    else if (arch ==  4) cheek_w4_b_arch_4(subvar);
    else if (arch ==  5) cheek_w4_b_arch_5(subvar);
    else if (arch ==  6) cheek_w4_b_arch_6(subvar);
    else if (arch ==  7) cheek_w4_b_arch_7(subvar);
    else if (arch ==  8) cheek_w4_b_arch_8(subvar);
    else if (arch ==  9) cheek_w4_b_arch_9(subvar);
    else if (arch == 10) cheek_w4_b_arch_10(subvar);
    else if (arch == 11) cheek_w4_b_arch_11(subvar);
    else if (arch == 12) cheek_w4_b_arch_12(subvar);
    else                 cheek_w4_b_arch_13(subvar);
}

module render_wave4_cheek_pair_b(part_id = 2576) {
    for (side = [-1, 1]) {
        translate([0, side * cheek_pair_offset_y, 0])
            mirror([0, (side < 0 ? 1 : 0), 0])
                single_cheek_pod_w4_b(part_id);
    }
    // Internal registration marker inside +Y pod hub for 3-volume clean manifold output
    translate([0, cheek_pair_offset_y + 1.8, 0.55])
        cube([0.2, 0.2, 0.2], center = true);
}

if (PART_ID >= 2576 && PART_ID <= 2750) {
    render_wave4_cheek_pair_b(PART_ID);
} else {
    render_wave4_cheek_pair_b(2576);
}
