// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: TOP CANOPY CROWNS BATCH B (PART_ID 2201..2400)
// 200 Distinct Support-Free Top Crowns (20 Creative World Archetypes x 10 Subvars)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.55g .. 1.15g (Volume: 450 .. 950 mm^3)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Universal Zone 1 Conical Shear-Keyway + 2.10x1.20mm N52 Pocket
// ============================================================================

$fn = 24;

PART_ID = 2201;

// --- Universal Zone 1 Mating Constants ---
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;
crown_annular_dia   = 8.40;
crown_annular_depth = 0.45;

// ============================================================================
// UNIVERSAL ZONE 1 TOP CROWN BASE (Z = 0.00mm Flat Bed + Alignment Keyway Rib)
// ============================================================================
module crown_base_w4_b(subvar = 10) {
    base_od = 16.0 + ((subvar - 10) % 5) * 0.40;
    difference() {
        union() {
            cylinder(d1 = base_od, d2 = 14.2, h = 1.65);
            cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height);
        }
        // Annular locking ring groove
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d = 4.80, h = crown_annular_depth + 0.03);
            }
        // Shear ring counter-groove
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = 4.85, h = shear_boss_height + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height + 0.03);
            }
        // Central NdFeB N52 disc magnet pocket
        translate([0, 0, -0.01])
            cylinder(d = mag_pocket_dia, h = 1.25);
    }
    // Restored Zone 1 keyway directional alignment rib (6.5 x 1.2 x 0.35 mm at X = +4.2mm, Z = 0.45mm)
    // with 45-degree chamfered lead-in at inner and outer mating tips
    difference() {
        translate([4.2, 0, 0.45])
            hull() {
                cube([6.5 - 0.70, 1.20, 0.35], center = true);
                cube([6.5, 1.20 - 0.70, 0.35], center = true);
            }
        // Ensure center magnet pocket clearance
        translate([0, 0, -0.01])
            cylinder(d = mag_pocket_dia, h = 1.25);
    }
}

// ============================================================================
// 20 DISTINCT CREATIVE WORLD ARCHETYPES FOR BATCH B (arch = 0..19, subvar = 10..19)
// All sculptures sit on top of crown base (Z = 1.40mm) with support-free draft angles <= 45 deg
// ============================================================================

// ARCH 0: Cyber Mecha & Gundam Batch B (Beam Saber Crest, Hyper-V Fin, Vector Cowling)
module crown_w4_b_arch_0(subvar = 10) {
    sv     = subvar - 10;
    v_span = 5.6 + (sv % 4) * 0.5;
    v_h    = 7.2 + (sv % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 6.4, h = 3.0, $fn = 8);
        // Beam saber central spine
        translate([0, 0, 3.6])
            cylinder(d1 = 4.6, d2 = 1.6, h = v_h * 0.7, $fn = 4);
        // Hyper swept V-fin antennae
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 1.8, 1.40])
                    cylinder(d = 3.4, h = 2.2);
                translate([-1.2, sy * v_span, 1.40 + v_h])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
            hull() {
                translate([1.2, sy * 2.8, 1.40])
                    cylinder(d = 2.8, h = 1.8);
                translate([0.6, sy * (v_span * 0.8), 1.40 + v_h * 0.5])
                    cylinder(d1 = 2.0, d2 = 0.9, h = 1.0);
            }
        }
    }
}

// ARCH 1: Neon Synthwave 80s Batch B (DeLorean Turbo Fin, Laser Grid Lattice)
module crown_w4_b_arch_1(subvar = 10) {
    sv     = subvar - 10;
    fin_h  = 6.8 + (sv % 4) * 0.55;
    grid_w = 5.2 + (sv % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.8, h = 2.4);
        // DeLorean louvered engine cowl fins
        for (i = [-2 : 2]) {
            translate([i * 1.5, 0, 1.40])
                hull() {
                    translate([0, -grid_w * 0.7, 0]) cylinder(d = 2.2, h = 1.8);
                    translate([0,  grid_w * 0.7, 0]) cylinder(d = 2.2, h = 1.8);
                    translate([0, 0, fin_h * 0.75]) cylinder(d1 = 2.0, d2 = 1.0, h = 1.2);
                }
        }
    }
}

// ARCH 2: Anime & Martial Arts (Super Saiyan Ki Aura, Dragon Claws)
module crown_w4_b_arch_2(subvar = 10) {
    sv     = subvar - 10;
    star_r = 4.8 + (sv % 4) * 0.30;
    h_star = 6.8 + (sv % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6);
        for (i = [0 : 3]) {
            rotate([0, 0, i * 90 + (sv % 3) * 10]) {
                hull() {
                    translate([star_r * 0.40, 0, 1.40])
                        cylinder(d1 = 3.4, d2 = 2.2, h = 2.0);
                    translate([star_r, 0, 1.40 + h_star * 0.75])
                        cylinder(d1 = 1.2, d2 = 0.8, h = 1.4);
                    translate([star_r, 0, 1.40 + h_star * 0.75 - 1.0])
                        cylinder(d1 = 0.2, d2 = 1.2, h = 1.0);
                }
            }
        }
        translate([0, 0, 3.4])
            cylinder(d1 = 5.2, d2 = 1.8, h = h_star * 0.65, $fn = 8);
    }
}

// ARCH 3: Viking & Norse Runes (Valkyrie Wings, Horn Spikes, Runic Plinth)
module crown_w4_b_arch_3(subvar = 10) {
    sv     = subvar - 10;
    span_w = 4.4 + (sv % 4) * 0.30;
    h_rune = 7.0 + (sv % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 7.8, h = 2.6, $fn = 6);
        for (sy = [-1, 1]) {
            for (f = [0 : 2]) {
                hull() {
                    translate([f * 1.0 - 1.0, sy * (2.2 + f * 0.25), 1.40])
                        cylinder(d1 = 2.8, d2 = 2.0, h = 2.0);
                    translate([f * 0.8 - 1.4, sy * (span_w - f * 0.40), 1.40 + h_rune * (0.65 + f * 0.15)])
                        cylinder(d1 = 1.2, d2 = 0.8, h = 1.2);
                    translate([f * 0.8 - 1.4, sy * (span_w - f * 0.40), 1.40 + h_rune * (0.65 + f * 0.15) - 0.8])
                        cylinder(d1 = 0.2, d2 = 1.2, h = 0.8);
                }
            }
        }
        translate([0, 0, 3.6])
            cylinder(d1 = 5.0, d2 = 2.4, h = h_rune * 0.6, $fn = 4);
    }
}

// ARCH 4: Egyptian Pharaoh Batch B (Horus Falcon Wings, Obelisk Spire)
module crown_w4_b_arch_4(subvar = 10) {
    sv     = subvar - 10;
    ob_h   = 7.4 + (sv % 4) * 0.55;
    wing_s = 5.2 + (sv % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.6, h = 2.6);
        // Central pyramidal obelisk spire
        translate([0, 0, 3.4])
            cylinder(d1 = 5.4, d2 = 1.8, h = ob_h * 0.65, $fn = 4);
        // Horus falcon side wings
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.0, 1.40])
                    cylinder(d = 3.2, h = 2.0);
                translate([0, sy * wing_s, 1.40 + ob_h * 0.55])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 5: Roman Gladiator Batch B (Colosseum Pillar Ring, Spatha Blades)
module crown_w4_b_arch_5(subvar = 10) {
    sv     = subvar - 10;
    n_cols = 5 + (sv % 3);
    h_col  = 6.5 + (sv % 4) * 0.5;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.2, h = 2.4);
        // Doric colosseum perimeter pillars
        for (i = [0 : n_cols - 1]) {
            ang = i * (360 / n_cols);
            rotate([0, 0, ang]) {
                translate([4.4, 0, 1.40])
                    cylinder(d1 = 2.4, d2 = 1.4, h = h_col * 0.65);
            }
        }
        // Center gladiator spatha blade
        translate([0, 0, 3.2])
            scale([1.4, 0.6, 1.0])
                cylinder(d1 = 4.6, d2 = 1.4, h = h_col * 0.75, $fn = 4);
    }
}

// ARCH 6: Pirate Buccaneers Batch B (Flintlock Barrel Spire, Kraken Tentacle)
module crown_w4_b_arch_6(subvar = 10) {
    sv     = subvar - 10;
    tent_h = 7.0 + (sv % 4) * 0.55;
    span_t = 5.0 + (sv % 3) * 0.5;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.4, h = 2.5);
        // Central flintlock blunderbuss barrel
        translate([0, 0, 3.2])
            cylinder(d1 = 5.6, d2 = 3.8, h = tent_h * 0.6, $fn = 8);
        // Curling kraken tentacles
        for (sy = [-1, 1]) {
            hull() {
                translate([-0.5, sy * 2.2, 1.40])
                    cylinder(d = 3.2, h = 2.0);
                translate([ 1.4, sy * span_t, 1.40 + tent_h * 0.75])
                    cylinder(d1 = 2.2, d2 = 0.8, h = 1.2);
            }
        }
    }
}

// ARCH 7: Extreme Storms & Weather (Hailstorm Crystal Cluster)
module crown_w4_b_arch_7(subvar = 10) {
    sv     = subvar - 10;
    n_hail = 4 + (sv % 3);
    h_hail = 6.6 + (sv % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 8.2, h = 2.4);
        translate([0, 0, 3.2])
            cylinder(d1 = 7.2, d2 = 4.6, h = 2.6);
        for (i = [0 : n_hail - 1]) {
            ang = i * (360 / n_hail) + (sv % 3) * 15;
            rotate([0, 0, ang]) {
                hull() {
                    translate([2.4, 0, 1.40])
                        cylinder(d1 = 2.8, d2 = 1.8, h = 1.8);
                    translate([3.2, 0, 3.4 + h_hail * 0.55])
                        cylinder(d1 = 1.0, d2 = 0.2, h = 1.0);
                }
            }
        }
    }
}

// ARCH 8: Apex Predators & Beasts (Tiger Claws, Raptor Talons)
module crown_w4_b_arch_8(subvar = 10) {
    sv     = subvar - 10;
    claw_s = 4.0 + (sv % 4) * 0.30;
    h_claw = 7.0 + (sv % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.6);
        translate([0, 0, 3.4])
            cylinder(d1 = 6.4, d2 = 3.6, h = 2.8, $fn = 7);
        for (sy = [-1, 1]) {
            for (c = [0 : 2]) {
                hull() {
                    translate([c * 1.0 - 1.2, sy * (2.4 + c * 0.35), 1.40])
                        cylinder(d1 = 2.8, d2 = 2.0, h = 2.2);
                    translate([c * 1.2 - 1.0, sy * (claw_s - c * 0.35), 1.40 + h_claw * (0.65 + c * 0.12)])
                        cylinder(d1 = 1.2, d2 = 0.6, h = 1.2);
                    translate([c * 1.2 - 1.0, sy * (claw_s - c * 0.35), 1.40 + h_claw * (0.65 + c * 0.12) - 1.2])
                        cylinder(d1 = 0.2, d2 = 1.2, h = 1.2);
                }
            }
        }
    }
}

// ARCH 9: Cosmic Black Hole & Nebula Batch B (Pulsar Beacons, Event Horizon Torus)
module crown_w4_b_arch_9(subvar = 10) {
    sv     = subvar - 10;
    h_beam = 7.4 + (sv % 4) * 0.55;
    rim_d  = 11.4 + (sv % 3) * 0.5;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = rim_d, h = 1.8);
        // Torus rim ridge
        translate([0, 0, 3.2])
            cylinder(d1 = rim_d, d2 = rim_d * 0.78, h = 1.6);
        // Dual relativistic pulsar emission beams
        for (sz = [-1, 1]) {
            translate([0, 0, 4.4])
                cylinder(d1 = 4.4, d2 = 1.6, h = h_beam * 0.65, $fn = 8);
        }
    }
}

// ARCH 10: Quantum Physics & Lab Batch B (Tokamak Fusion Ring, Laser Cavity)
module crown_w4_b_arch_10(subvar = 10) {
    sv     = subvar - 10;
    ring_d = 10.2 + (sv % 4) * 0.45;
    h_core = 6.8 + (sv % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = ring_d, h = 1.8);
        // Toroidal magnetic confinement coil ring
        translate([0, 0, 3.2])
            cylinder(d1 = ring_d, d2 = ring_d * 0.8, h = 2.2, $fn = 8);
        // Central plasma column spire
        translate([0, 0, 4.6])
            cylinder(d1 = 4.2, d2 = 1.6, h = h_core * 0.55, $fn = 6);
    }
}

// ARCH 11: Heavy Construction & Mining Batch B (Rotary Drill Bit, Crane Truss)
module crown_w4_b_arch_11(subvar = 10) {
    sv     = subvar - 10;
    drill_h = 7.2 + (sv % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6);
        // Helical fluted drill cone
        translate([0, 0, 3.4])
            cylinder(d1 = 6.6, d2 = 1.8, h = drill_h * 0.7, $fn = 4);
        // Side cutter lugs
        for (ang = [0, 90, 180, 270]) {
            rotate([0, 0, ang + (sv % 4) * 12]) {
                translate([4.0, 0, 1.40])
                    cylinder(d1 = 2.6, d2 = 1.2, h = drill_h * 0.45);
            }
        }
    }
}

// ARCH 12: Emergency Rescue & Fire Batch B (Axe Blade Crest, Dual Siren Pods)
module crown_w4_b_arch_12(subvar = 10) {
    sv     = subvar - 10;
    axe_len = 8.4 + (sv % 4) * 0.55;
    h_axe   = 6.6 + (sv % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.8, h = 2.4);
        // Firefighter pick-head axe blade
        hull() {
            translate([-axe_len * 0.45, 0, 1.40])
                cylinder(d = 2.8, h = 2.2);
            translate([ axe_len * 0.45, 0, 1.40])
                cylinder(d = 2.8, h = 2.2);
            translate([0, 0, 1.40 + h_axe])
                cylinder(d1 = 3.2, d2 = 1.2, h = 1.6);
        }
        // Siren strobe pods
        for (sy = [-1, 1]) {
            translate([0, sy * 3.6, 1.40])
                cylinder(d1 = 3.0, d2 = 1.6, h = h_axe * 0.5);
        }
    }
}

// ARCH 13: Retro 80s Synthwave (Beat-Drop Strobe Beacon)
module crown_w4_b_arch_13(subvar = 10) {
    sv     = subvar - 10;
    head_w = 4.6 + (sv % 4) * 0.25;
    h_dj   = 6.6 + (sv % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.6, h = 2.4);
        translate([0, 0, 3.2])
            cylinder(d1 = 6.8, d2 = 4.2, h = 2.2, $fn = 8);
        // Headband arch
        rotate([90, 0, 0])
            rotate_extrude(angle = 180)
                translate([head_w, 0, 0])
                    circle(r = 0.65);
        // Earcup pods constrained within base outer envelope
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * (head_w - 0.6), 1.40])
                    cylinder(d1 = 2.6, d2 = 1.8, h = 1.8);
                translate([0, sy * head_w, 2.8])
                    sphere(d = 2.0);
            }
        }
        translate([0, 0, 4.4])
            cylinder(d1 = 3.6, d2 = 1.4, h = h_dj * 0.45);
    }
}

// ARCH 14: Bakery & French Pastry Batch B (Eclair Twin Ridges, Brioche Crown)
module crown_w4_b_arch_14(subvar = 10) {
    sv     = subvar - 10;
    h_past = 6.4 + (sv % 4) * 0.5;
    span_e = 4.8 + (sv % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.5);
        // Fluted brioche swirl
        translate([0, 0, 3.2])
            cylinder(d1 = 6.6, d2 = 3.0, h = h_past * 0.65, $fn = 7);
        // Twin eclair side lobes
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.2, 1.40]) cylinder(d = 3.2, h = 2.0);
                translate([0, sy * span_e, 1.40 + h_past * 0.5]) cylinder(d1 = 2.4, d2 = 1.2, h = 1.2);
            }
        }
    }
}

// ARCH 15: Drive-In Diner Classics Batch B (Hot Dog Bun Wings, Jukebox Crest)
module crown_w4_b_arch_15(subvar = 10) {
    sv     = subvar - 10;
    h_juke = 6.8 + (sv % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.8, h = 2.4);
        // Arching jukebox dome
        translate([0, 0, 3.2])
            cylinder(d1 = 6.2, d2 = 3.2, h = h_juke * 0.65, $fn = 6);
        // Twin side bun flares
        for (sy = [-1, 1]) {
            hull() {
                translate([-0.8, sy * 2.2, 1.40]) cylinder(d = 3.0, h = 2.0);
                translate([-1.6, sy * 4.8, 1.40 + h_juke * 0.55]) cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 16: Olympian Gods & Titans Batch B (Poseidon Trident Flukes, Hades Helm)
module crown_w4_b_arch_16(subvar = 10) {
    sv     = subvar - 10;
    h_god  = 7.2 + (sv % 3) * 0.6;
    span_f = 5.2 + (sv % 4) * 0.5;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6, $fn = 8);
        // Central trident spear
        translate([0, 0, 3.4])
            cylinder(d1 = 4.4, d2 = 1.6, h = h_god * 0.7, $fn = 6);
        // Barbed outer flukes
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.0, 1.40]) cylinder(d = 3.0, h = 2.0);
                translate([0.8, sy * span_f, 1.40 + h_god * 0.85]) cylinder(d1 = 2.2, d2 = 0.9, h = 1.2);
            }
        }
    }
}

// ARCH 17: Biomorphic Arthropods Batch B (Stag Beetle Mandibles, Mantis Scythe)
module crown_w4_b_arch_17(subvar = 10) {
    sv     = subvar - 10;
    pincer_s = 5.4 + (sv % 4) * 0.5;
    h_mand   = 7.0 + (sv % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.6);
        // Central thorax hump
        translate([0, 0, 3.2])
            cylinder(d1 = 5.6, d2 = 2.8, h = 2.8, $fn = 6);
        // Twin curved stag beetle mandibles
        for (sy = [-1, 1]) {
            hull() {
                translate([0.4, sy * 2.2, 1.40]) cylinder(d = 3.2, h = 2.0);
                translate([2.2, sy * pincer_s, 1.40 + h_mand]) cylinder(d1 = 2.4, d2 = 0.8, h = 1.2);
            }
        }
    }
}

// ARCH 18: Crystalline Geodes & Gems Batch B (Emerald Hex Prisms, Ruby Step)
module crown_w4_b_arch_18(subvar = 10) {
    sv     = subvar - 10;
    h_gem  = 6.8 + (sv % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 8.2, h = 2.5, $fn = 6);
        // Central hexagonal emerald prism
        translate([0, 0, 3.4])
            cylinder(d1 = 5.2, d2 = 2.4, h = h_gem * 0.65, $fn = 6);
        // Cluster of smaller satellite crystals
        for (i = [0 : 5]) {
            ang = i * 60 + (sv % 3) * 10;
            rotate([0, 0, ang]) {
                translate([3.8, 0, 1.40])
                    cylinder(d1 = 2.4, d2 = 1.0, h = h_gem * 0.5, $fn = 6);
            }
        }
    }
}

// ARCH 19: AI & Cybernetic Future Batch B (Neural Core, Heat-Spreader Spires)
module crown_w4_b_arch_19(subvar = 10) {
    sv     = subvar - 10;
    h_core = 6.6 + (sv % 4) * 0.55;
    spire_s = 4.8 + (sv % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6, $fn = 8);
        // Neural CPU microchip die
        translate([0, 0, 3.4])
            cylinder(d1 = 5.8, d2 = 3.2, h = h_core * 0.55, $fn = 4);
        // Heat spreader corner spires
        for (ang = [45, 135, 225, 315]) {
            rotate([0, 0, ang]) {
                hull() {
                    translate([2.2, 0, 1.40]) cylinder(d = 2.6, h = 1.8);
                    translate([spire_s, 0, 1.40 + h_core * 0.75]) cylinder(d1 = 2.0, d2 = 0.8, h = 1.2);
                }
            }
        }
    }
}

// ============================================================================
// MASTER DISPATCHER FOR CROWNS BATCH B (PART_ID = 2201..2400)
// ============================================================================
module KODIAK75_Wave4_Crown_B(part_id = 2201) {
    idx    = part_id - 2001;
    arch   = idx % 20;
    subvar = floor(idx / 20); // 10..19 for 2201..2400

    union() {
        crown_base_w4_b(subvar);
        if      (arch ==  0) crown_w4_b_arch_0(subvar);
        else if (arch ==  1) crown_w4_b_arch_1(subvar);
        else if (arch ==  2) crown_w4_b_arch_2(subvar);
        else if (arch ==  3) crown_w4_b_arch_3(subvar);
        else if (arch ==  4) crown_w4_b_arch_4(subvar);
        else if (arch ==  5) crown_w4_b_arch_5(subvar);
        else if (arch ==  6) crown_w4_b_arch_6(subvar);
        else if (arch ==  7) crown_w4_b_arch_7(subvar);
        else if (arch ==  8) crown_w4_b_arch_8(subvar);
        else if (arch ==  9) crown_w4_b_arch_9(subvar);
        else if (arch == 10) crown_w4_b_arch_10(subvar);
        else if (arch == 11) crown_w4_b_arch_11(subvar);
        else if (arch == 12) crown_w4_b_arch_12(subvar);
        else if (arch == 13) crown_w4_b_arch_13(subvar);
        else if (arch == 14) crown_w4_b_arch_14(subvar);
        else if (arch == 15) crown_w4_b_arch_15(subvar);
        else if (arch == 16) crown_w4_b_arch_16(subvar);
        else if (arch == 17) crown_w4_b_arch_17(subvar);
        else if (arch == 18) crown_w4_b_arch_18(subvar);
        else if (arch == 19) crown_w4_b_arch_19(subvar);
    }
}

if (PART_ID >= 2201 && PART_ID <= 2400) {
    KODIAK75_Wave4_Crown_B(PART_ID);
} else {
    KODIAK75_Wave4_Crown_B(2201);
}
