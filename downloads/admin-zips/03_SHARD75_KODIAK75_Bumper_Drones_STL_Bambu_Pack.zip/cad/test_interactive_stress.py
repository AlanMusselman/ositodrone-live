"""
Interactive Stress-Test Harness for KODIAK-75 Wave 4
Tests randomizer, dropdown selections, clicks, 3D preview rendering,
and wave filters in Headless Chromium (Microsoft Edge).
Author: Challenger W4 R3
Date: 2026-10-30
"""

import os
import sys
import json
import re
import subprocess
from pathlib import Path

# Ensure UTF-8 output on console
sys.stdout.reconfigure(encoding='utf-8')

CAD_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Bumper Drones\cad")
BASE_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Bumper Drones")
BRAIN_VIEWER_PATH = Path(r"C:\Users\Alan Musselman\.gemini\antigravity\brain\86f1d704-cf9c-4677-bafe-86202cc392d1\kodiak75_interactive_viewer.html")
EDGE_EXE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

GARAGE_HTML_PATH = BASE_DIR / "OSITO_Kids_Garage_Loadout_Menu.html"
VIEWER_HTML_PATH = BASE_DIR / "KODIAK75_3D_Viewer.html"

print("================================================================================")
print("  CHALLENGER W4 R3: HEADLESS CHROMIUM INTERACTIVE STRESS & RENDER AUDIT")
print("================================================================================")

# Script injection templates
EARLY_ERROR_CAPTURE = """<script>
window.__CAUGHT_ERRORS__ = [];
window.addEventListener('error', function(e) {
    window.__CAUGHT_ERRORS__.push({
        type: 'uncaught_error',
        msg: e.message || String(e),
        file: e.filename || 'inline',
        line: e.lineno || 0,
        col: e.colno || 0
    });
});
window.addEventListener('unhandledrejection', function(e) {
    window.__CAUGHT_ERRORS__.push({
        type: 'unhandled_rejection',
        msg: (e.reason && e.reason.message) || String(e.reason)
    });
});
</script>"""

GARAGE_TEST_RUNNER = """<script>
window.addEventListener('DOMContentLoaded', () => {
    const results = { passed: 0, failed: 0, errors: [], tests: [] };

    function assert(id, desc, cond, details) {
        if (cond) {
            results.passed++;
            results.tests.push({ id, desc, status: 'PASS', details: details || '' });
        } else {
            results.failed++;
            results.tests.push({ id, desc, status: 'FAIL', error: details || 'Assertion failed' });
            results.errors.push(`[${id}] ${desc}: ${details}`);
        }
    }

    try {
        // 1. Initial Load verification
        assert('GARAGE_INIT', 'Initial load has 896 crowns, 783 cheeks, 560 belly',
            CROWNS.length === 896 && CHEEKS.length === 783 && BELLY.length === 560,
            `C:${CROWNS.length}, Ch:${CHEEKS.length}, B:${BELLY.length}`);

        // 2. Randomizer Stress Test (25 iterations)
        let randErrors = 0;
        for (let i = 0; i < 25; i++) {
            try {
                randomizeMenuLoadout();
                if (selected.crown < 0 || selected.crown >= CROWNS.length ||
                    selected.cheeks < 0 || selected.cheeks >= CHEEKS.length ||
                    selected.belly < 0 || selected.belly >= BELLY.length) {
                    randErrors++;
                }
            } catch (e) {
                randErrors++;
                results.errors.push(`Randomize iteration ${i} threw: ${e.message}`);
            }
        }
        assert('GARAGE_RANDOMIZE_25X', 'randomizeMenuLoadout() runs 25 times without error and within bounds',
            randErrors === 0, `Rand errors: ${randErrors}`);

        // 3. Part Click and Selection (Wave 4 Boundaries: 2001, 2400, 2401, 2750, 2751, 3000)
        const boundaryChecks = [
            { zone: 'crown', pid: 2001, expArch: 0, expVar: 0 },
            { zone: 'crown', pid: 2400, expArch: 19, expVar: 19 },
            { zone: 'cheeks', pid: 2401, expArch: 0, expVar: 0 },
            { zone: 'cheeks', pid: 2750, expArch: 13, expVar: 24 },
            { zone: 'belly', pid: 2751, expArch: 0, expVar: 0 },
            { zone: 'belly', pid: 3000, expArch: 9, expVar: 24 }
        ];

        let clickErrors = 0;
        for (const b of boundaryChecks) {
            try {
                const arr = b.zone === 'crown' ? CROWNS : b.zone === 'cheeks' ? CHEEKS : BELLY;
                const idx = arr.findIndex(x => x.id === b.pid);
                if (idx < 0) {
                    clickErrors++;
                    results.errors.push(`Could not find part ${b.pid} in ${b.zone}`);
                    continue;
                }
                selectAndInspect(b.zone, idx);
                const item = CATALOG[inspected.zone][inspected.idx];
                if (item.id !== b.pid) {
                    clickErrors++;
                    results.errors.push(`Selected item id ${item.id} != expected ${b.pid}`);
                }
                const title = document.getElementById('inspectorTitle').textContent;
                if (!title.includes(String(b.pid))) {
                    clickErrors++;
                    results.errors.push(`inspectorTitle '${title}' does not contain ${b.pid}`);
                }
                const series = document.getElementById('inspectorSeries').textContent;
                if (!series.includes('Wave 4 Production')) {
                    clickErrors++;
                    results.errors.push(`inspectorSeries '${series}' does not contain 'Wave 4 Production'`);
                }
            } catch (e) {
                clickErrors++;
                results.errors.push(`Selection of ${b.pid} threw: ${e.message}`);
            }
        }
        assert('GARAGE_BOUNDARY_CLICKS', 'All Wave 4 boundary parts (2001, 2400, 2401, 2750, 2751, 3000) select & display correctly',
            clickErrors === 0, `Click errors: ${clickErrors}`);

        // 4. Wave Filtering
        let filterErrors = 0;
        try {
            setWaveFilter(4);
            const w4CrownCards = document.getElementById('grid-crowns').children.length;
            const w4CheekCards = document.getElementById('grid-cheeks').children.length;
            const w4BellyCards = document.getElementById('grid-belly').children.length;
            if (w4CrownCards !== 400 || w4CheekCards !== 350 || w4BellyCards !== 250) {
                filterErrors++;
                results.errors.push(`Wave 4 filter counts mismatch: C:${w4CrownCards}, Ch:${w4CheekCards}, B:${w4BellyCards}`);
            }
            setWaveFilter('all');
            const allCrownCards = document.getElementById('grid-crowns').children.length;
            if (allCrownCards !== 896) {
                filterErrors++;
                results.errors.push(`All filter crowns mismatch: ${allCrownCards} != 896`);
            }
        } catch (e) {
            filterErrors++;
            results.errors.push(`Filter testing threw: ${e.message}`);
        }
        assert('GARAGE_WAVE_FILTER', 'Wave 4 and All filtering correctly adjusts visible cards (400/350/250 -> 896/783/560)',
            filterErrors === 0, `Filter errors: ${filterErrors}`);

        // 5. 3D Preview Inspector Rendering
        let renderErrors = 0;
        for (const b of boundaryChecks) {
            try {
                const arr = b.zone === 'crown' ? CROWNS : b.zone === 'cheeks' ? CHEEKS : BELLY;
                const idx = arr.findIndex(x => x.id === b.pid);
                selectAndInspect(b.zone, idx);
                renderInspectorLoop(); // run one frame of projection & draw
            } catch (e) {
                renderErrors++;
                results.errors.push(`3D Inspector rendering for ${b.pid} threw: ${e.message}`);
            }
        }
        assert('GARAGE_3D_RENDER', '3D Inspector canvas renders all Wave 4 archetypes without throwing exceptions',
            renderErrors === 0, `Render errors: ${renderErrors}`);

    } catch (topE) {
        results.failed++;
        results.errors.push(`Top level runner error: ${topE.message}`);
    }

    results.caughtErrors = window.__CAUGHT_ERRORS__ || [];

    const d = document.createElement('div');
    d.id = 'test-results-dump';
    d.textContent = JSON.stringify(results);
    document.body.appendChild(d);
});
</script>"""

VIEWER_TEST_RUNNER = """<script>
window.addEventListener('DOMContentLoaded', () => {
    const results = { passed: 0, failed: 0, errors: [], tests: [] };

    function assert(id, desc, cond, details) {
        if (cond) {
            results.passed++;
            results.tests.push({ id, desc, status: 'PASS', details: details || '' });
        } else {
            results.failed++;
            results.tests.push({ id, desc, status: 'FAIL', error: details || 'Assertion failed' });
            results.errors.push(`[${id}] ${desc}: ${details}`);
        }
    }

    try {
        // 1. Initial Load verification
        assert('VIEWER_INIT', 'Initial load has 896 crowns, 783 cheeks, 560 belly',
            LOADOUTS.crown.length === 896 && LOADOUTS.cheeks.length === 783 && LOADOUTS.belly.length === 560,
            `C:${LOADOUTS.crown.length}, Ch:${LOADOUTS.cheeks.length}, B:${LOADOUTS.belly.length}`);

        // 2. Randomizer Stress Test (25 iterations)
        let randErrors = 0;
        for (let i = 0; i < 25; i++) {
            try {
                randomizeLoadout();
                if (selectedIdx.crown < 0 || selectedIdx.crown >= LOADOUTS.crown.length ||
                    selectedIdx.cheeks < 0 || selectedIdx.cheeks >= LOADOUTS.cheeks.length ||
                    selectedIdx.belly < 0 || selectedIdx.belly >= LOADOUTS.belly.length) {
                    randErrors++;
                }
            } catch (e) {
                randErrors++;
                results.errors.push(`randomizeLoadout() iteration ${i} threw: ${e.message}`);
            }
        }
        assert('VIEWER_RANDOMIZE_25X', 'randomizeLoadout() runs 25 times without error and within bounds',
            randErrors === 0, `Rand errors: ${randErrors}`);

        // 3. Dropdown Clicks & Selection (Boundary Parts: 2001, 2400, 2401, 2750, 2751, 3000)
        const boundaryChecks = [
            { slot: 'crown', pid: 2001, expSubTag: 'A1\\u2022V1' },
            { slot: 'crown', pid: 2400, expSubTag: 'A20\\u2022V20' },
            { slot: 'cheeks', pid: 2401, expSubTag: 'A1\\u2022V1' },
            { slot: 'cheeks', pid: 2750, expSubTag: 'A14\\u2022V25' },
            { slot: 'belly', pid: 2751, expSubTag: 'A1\\u2022V1' },
            { slot: 'belly', pid: 3000, expSubTag: 'A10\\u2022V25' }
        ];

        let selectErrors = 0;
        for (const b of boundaryChecks) {
            try {
                const list = LOADOUTS[b.slot];
                const idx = list.findIndex(x => x.partId === b.pid);
                if (idx < 0) {
                    selectErrors++;
                    results.errors.push(`Could not find partId ${b.pid} in slot ${b.slot}`);
                    continue;
                }
                selectLoadout(b.slot, idx);
                const item = LOADOUTS[b.slot][selectedIdx[b.slot]];
                if (item.partId !== b.pid) {
                    selectErrors++;
                    results.errors.push(`Selected partId ${item.partId} != expected ${b.pid}`);
                }
                const title = document.getElementById('partPreviewTitle').textContent;
                if (!title.includes(String(b.pid))) {
                    selectErrors++;
                    results.errors.push(`partPreviewTitle '${title}' does not contain ${b.pid}`);
                }
            } catch (e) {
                selectErrors++;
                results.errors.push(`selectLoadout for ${b.pid} threw: ${e.message}`);
            }
        }
        assert('VIEWER_BOUNDARY_SELECT', 'All Wave 4 boundary parts select, update telemetry, and update inspector without error',
            selectErrors === 0, `Select errors: ${selectErrors}`);

        // 4. Cycle Buttons
        let cycleErrors = 0;
        try {
            cycleLoadout('crown');
            cycleLoadout('cheeks');
            cycleLoadout('belly');
        } catch (e) {
            cycleErrors++;
            results.errors.push(`cycleLoadout threw: ${e.message}`);
        }
        assert('VIEWER_CYCLE_BUTTONS', 'cycleLoadout() functions cleanly for crown, cheeks, and belly',
            cycleErrors === 0, `Cycle errors: ${cycleErrors}`);

        // 5. Wave Filtering & Gallery Strip
        let waveFilterErrors = 0;
        try {
            setViewerWave(4);
            renderPartGalleryStrip();
            const strip = document.getElementById('partGalleryStrip');
            const chipCount = strip ? strip.children.length : 0;
            if (chipCount === 0) {
                waveFilterErrors++;
                results.errors.push('No chips rendered in gallery strip under Wave 4');
            }
            setViewerWave('all');
            renderPartGalleryStrip();
        } catch (e) {
            waveFilterErrors++;
            results.errors.push(`setViewerWave threw: ${e.message}`);
        }
        assert('VIEWER_WAVE_FILTER', 'Viewer wave filtering and gallery chips update without error',
            waveFilterErrors === 0, `Wave filter errors: ${waveFilterErrors}`);

        // 6. 3D Preview and Main 3D Canvas Render Loops
        let render3dErrors = 0;
        for (const b of boundaryChecks) {
            try {
                const list = LOADOUTS[b.slot];
                const idx = list.findIndex(x => x.partId === b.pid);
                selectLoadout(b.slot, idx);
                setInspectorSlot(b.slot);
                renderPartPreview();
                render();
            } catch (e) {
                render3dErrors++;
                results.errors.push(`3D Preview rendering for part ${b.pid} in ${b.slot} threw: ${e.message}`);
            }
        }
        assert('VIEWER_3D_PREVIEW_RENDER', '3D close-up preview canvas and main 3D canvas render all Wave 4 parts without error',
            render3dErrors === 0, `Render errors: ${render3dErrors}`);

        // 7. Impact Physics & Recovery Simulation
        let impactErrors = 0;
        try {
            ejectPlate('crown');
            ejectPlate('belly');
            ejectPlate('left');
            ejectPlate('right');
            const scoreText = document.getElementById('scoreDisplay').textContent;
            resetPlates();
            const resetScoreText = document.getElementById('scoreDisplay').textContent;
        } catch (e) {
            impactErrors++;
            results.errors.push(`Impact/Reset threw: ${e.message}`);
        }
        assert('VIEWER_IMPACT_SIM', 'Impact simulation (ejectPlate, resetPlates) operates smoothly without error',
            impactErrors === 0, `Impact errors: ${impactErrors}`);

    } catch (topE) {
        results.failed++;
        results.errors.push(`Top level viewer runner error: ${topE.message}`);
    }

    results.caughtErrors = window.__CAUGHT_ERRORS__ || [];

    const d = document.createElement('div');
    d.id = 'test-results-dump';
    d.textContent = JSON.stringify(results);
    document.body.appendChild(d);
});
</script>"""

def execute_in_headless_browser(html_path, runner_script):
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()

    modified = content.replace("<head>", "<head>\n" + EARLY_ERROR_CAPTURE, 1)
    modified = modified.replace("</body>", runner_script + "\n</body>", 1)

    temp_path = CAD_DIR / f"temp_stress_{Path(html_path).stem}.html"
    with open(temp_path, 'w', encoding='utf-8') as f:
        f.write(modified)

    try:
        res = subprocess.run(
            [EDGE_EXE, "--headless=new", "--virtual-time-budget=5000", "--dump-dom", str(temp_path)],
            capture_output=True, text=True, encoding='utf-8'
        )
    finally:
        temp_path.unlink(missing_ok=True)

    m = re.search(r'<div id="test-results-dump">(.*?)</div>', res.stdout)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception as ex:
            return {"failed": 1, "errors": [f"JSON parse error: {ex}"], "tests": []}
    return {"failed": 1, "errors": ["Could not find test-results-dump in DOM output"], "tests": []}

all_suite_passed = True
total_asserts = 0
total_passed = 0
total_failed = 0

targets = [
    ("OSITO_Kids_Garage_Loadout_Menu.html", GARAGE_HTML_PATH, GARAGE_TEST_RUNNER),
    ("KODIAK75_3D_Viewer.html", VIEWER_HTML_PATH, VIEWER_TEST_RUNNER),
    ("kodiak75_interactive_viewer.html (Brain Artifact)", BRAIN_VIEWER_PATH, VIEWER_TEST_RUNNER)
]

for name, path, runner in targets:
    print(f"\n>>> Stress Testing: {name}")
    print("--------------------------------------------------------------------------------")
    res = execute_in_headless_browser(path, runner)
    
    tests = res.get("tests", [])
    caught_errors = res.get("caughtErrors", [])
    
    for t in tests:
        total_asserts += 1
        mark = "[PASS]" if t["status"] == "PASS" else "[FAIL]"
        if t["status"] == "PASS":
            total_passed += 1
            print(f"  {mark} {t['id']}: {t['desc']}")
            if t.get("details"):
                print(f"         INFO: {t['details']}")
        else:
            total_failed += 1
            all_suite_passed = False
            print(f"  {mark} {t['id']}: {t['desc']}")
            print(f"         ERROR: {t.get('error')}")
            for err in res.get("errors", []):
                print(f"         DETAIL: {err}")

    if caught_errors:
        print(f"  [WARN] Browser runtime caught {len(caught_errors)} uncaught errors:")
        for ce in caught_errors:
            print(f"         - {ce}")
            all_suite_passed = False
    else:
        print("  [PASS] Zero uncaught exceptions or unhandled promise rejections detected.")

print("\n================================================================================")
print(f"  INTERACTIVE STRESS TEST SCORECARD: {total_passed}/{total_asserts} PASSED ({total_failed} FAILED)")
print("================================================================================")

if all_suite_passed:
    print("\n>>> OVERALL INTERACTIVE VERDICT: [PASS] All UI, randomizers, clicks, and 3D previews operate flawlessly!")
else:
    print("\n>>> OVERALL INTERACTIVE VERDICT: [FAIL] One or more interactive operations failed!")

sys.exit(0 if all_suite_passed else 1)
