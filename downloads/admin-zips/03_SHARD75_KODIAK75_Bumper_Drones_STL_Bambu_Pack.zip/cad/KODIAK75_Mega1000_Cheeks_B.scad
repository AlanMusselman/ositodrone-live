// ============================================================================
// KODIAK-75 Mega-1000 Cheek Pods Batch B (PART_ID = 1576..1750)
// 175 Left/Right Cheek Pod Pairs (Zones 2 & 3) across 14 Archetypes x 13 Subvars
// Universal Magnetic & Conical Shear-Keyway Standard — 100% Flat Z=0 TPU 95A
// ============================================================================

$fn = 28;

PART_ID = 1576;

// --- Master Interface Constants ---
mag_pocket_dia    = 2.10;
mag_pocket_depth  = 1.20;
shear_boss_dia1   = 3.40;
shear_boss_dia2   = 2.10;
shear_boss_height = 0.45;
cheek_pair_offset = 15.0;

// --- Derived Archetype & Sub-Variation Selectors ---
arch   = (PART_ID - 1401) % 14;
subvar = floor((PART_ID - 1401) / 14);

// ============================================================================
// UNIVERSAL CHEEK HUB & MAGNETIC SHEAR-KEYWAY INTERFACE
// ============================================================================

module cheek_hub_solid(pad_h = 2.20, span_x = 7.6) {
    hull() {
        cylinder(d = 8.4, h = pad_h);
        translate([-span_x, 0, 0]) cylinder(d = 4.2, h = pad_h - 0.5);
        translate([ span_x, 0, 0]) cylinder(d = 4.2, h = pad_h - 0.5);
    }
    // Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45) at Z = pad_h
    translate([0, 0, pad_h - 0.10])
        cylinder(d1 = shear_boss_dia1 + 0.10, d2 = shear_boss_dia2, h = shear_boss_height + 0.10);
}

module cheek_hub_cuts(pad_h = 2.20) {
    // Concentric 2.10mm x 1.20mm N52 magnet pocket cut from top of shear boss
    translate([0, 0, pad_h + shear_boss_height - mag_pocket_depth])
        cylinder(d = mag_pocket_dia, h = mag_pocket_depth + 0.15);
    // Underside hub flank weight-relief pockets (away from center magnet boss)
    for (xs = [-1, 1]) {
        translate([xs * 5.0, 0, -0.05])
            cylinder(d = 2.8, h = 1.20);
    }
}

// ============================================================================
// 14 DISTINCT CHEEK POD ARCHETYPES (arch = 0..13, subvar = 12..24)
// ============================================================================

// arch 0: Arcade Button / Boxing / Kettlebell / Revolver Pod
module cheek_arch_b_0(subvar = 12) {
    sv = subvar - 12; // 0..12
    pad_h = 2.20;
    dome_d = 9.0 + (sv % 4) * 0.35;
    dome_h = 2.4 + (sv % 3) * 0.20;
    lug_n  = 4 + (sv % 4);
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.2);
            // Neck strut to circular impact pod
            hull() {
                translate([-3.6, 1.5, 0]) cylinder(d = 3.6, h = 2.0);
                translate([ 3.6, 1.5, 0]) cylinder(d = 3.6, h = 2.0);
                translate([ 0.0, 6.2, 0]) cylinder(d = dome_d, h = 2.1);
            }
            // Beveled arcade/revolver drum cylinder
            translate([0, 6.4, 0])
                cylinder(d1 = dome_d + 0.6, d2 = dome_d - 1.0, h = dome_h);
            // Radial revolver flutes / boxing knuckles / tire lugs around perimeter
            for (i = [0 : lug_n - 1]) {
                ang = -55 + i * (110 / max(1, lug_n - 1));
                translate([0, 6.4, 0])
                    rotate([0, 0, ang])
                        translate([0, dome_d * 0.46, 0])
                            cylinder(d1 = 2.4, d2 = 1.6, h = dome_h + 0.25);
            }
            // Top center button cap
            translate([0, 6.4, dome_h - 0.15])
                cylinder(d1 = 4.6, d2 = 3.2, h = 0.70);
        }
        cheek_hub_cuts(pad_h);
        // Underside weight relief pocket under drum
        translate([0, 6.4, -0.05])
            cylinder(d = dome_d - 3.0, h = 1.40);
    }
}

// arch 1: Guitar Wing / Swallowtail / Hero Winglet / Boomerang Pod
module cheek_arch_b_1(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    sweep_x = 8.4 + (sv % 4) * 0.45;
    tip_y   = 10.2 + (sv % 3) * 0.45;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.6);
            // Forward swept wing root
            hull() {
                translate([-6.0, 1.0, 0]) cylinder(d = 3.6, h = 2.1);
                translate([ 5.0, 1.2, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 2.8, 6.8, 0]) cylinder(d = 4.2, h = 2.1);
                translate([-4.2, 5.8, 0]) cylinder(d = 3.4, h = 1.9);
            }
            // Swallowtail / Boomerang dual tips
            hull() {
                translate([ 2.2, 5.8, 0]) cylinder(d = 3.8, h = 2.1);
                translate([ sweep_x, tip_y - 1.2, 0]) cylinder(d1 = 2.8, d2 = 1.8, h = 2.4);
            }
            hull() {
                translate([-3.5, 5.2, 0]) cylinder(d = 3.4, h = 1.9);
                translate([-sweep_x + 1.2, tip_y, 0]) cylinder(d1 = 2.6, d2 = 1.6, h = 2.3);
            }
            // Raised aero strake ribs
            for (r = [-1, 1]) {
                hull() {
                    translate([r * 1.8, 2.5, 1.7]) cylinder(d = 1.5, h = 0.75);
                    translate([r * 4.6, 7.4, 1.7]) cylinder(d = 1.2, h = 0.65);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        // Underside weight-relief cavities
        translate([-1.2, 4.5, -0.05]) cylinder(d = 4.4, h = 1.30);
        translate([ 2.5, 5.2, -0.05]) cylinder(d = 3.6, h = 1.30);
    }
}

// arch 2: Snare Drum / Confetti Cannon / Test Tube / Canteen Pod
module cheek_arch_b_2(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    tube_n = 3 + (sv % 3); // 3, 4, or 5 barrel ribs
    span_w = 6.2 + (sv % 4) * 0.30;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.2);
            // Barrel cradle body
            hull() {
                translate([-span_w, 2.0, 0]) cylinder(d = 3.4, h = 2.0);
                translate([ span_w, 2.0, 0]) cylinder(d = 3.4, h = 2.0);
                translate([-span_w + 0.8, 7.8, 0]) cylinder(d = 3.2, h = 1.9);
                translate([ span_w - 0.8, 7.8, 0]) cylinder(d = 3.2, h = 1.9);
            }
            // Array of test tubes / rocket barrels / drum lugs
            for (i = [0 : tube_n - 1]) {
                tx = -span_w + 1.5 + i * ((2 * span_w - 3.0) / max(1, tube_n - 1));
                hull() {
                    translate([tx, 1.8, 0]) cylinder(d = 2.5, h = 2.4);
                    translate([tx, 8.8, 0]) cylinder(d1 = 2.6, d2 = 1.9, h = 2.4);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        // Underside weight relief trenches
        for (xs = [-3.4, 0, 3.4]) {
            translate([xs, 5.0, -0.05]) cylinder(d = 3.8, h = 1.35);
        }
    }
}

// arch 3: Trumpet / Twin Lightning / Mantis Scythe / Adamantium Claws Pod
module cheek_arch_b_3(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    claw_spread = 6.2 + (sv % 4) * 0.45;
    claw_len    = 9.8 + (sv % 3) * 0.50;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.4);
            // Knuckle / Valve manifold bar
            hull() {
                translate([-5.8, 2.0, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 5.8, 2.0, 0]) cylinder(d = 3.8, h = 2.2);
                translate([-4.2, 4.8, 0]) cylinder(d = 3.4, h = 2.1);
                translate([ 4.2, 4.8, 0]) cylinder(d = 3.4, h = 2.1);
            }
            // Three tapered claws / trumpet bells / scythe blades
            for (c = [-1, 0, 1]) {
                hull() {
                    translate([c * 3.8, 3.8, 0]) cylinder(d = 3.2, h = 2.2);
                    translate([c * claw_spread, claw_len - abs(c)*0.8, 0])
                        cylinder(d1 = 2.4, d2 = 1.3, h = 2.4);
                }
            }
            // Valve buttons on knuckle bar
            for (v = [-3.0, 0, 3.0]) {
                translate([v, 3.2, 1.9]) cylinder(d1 = 2.4, d2 = 1.8, h = 0.75);
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-2.8, 2.8]) {
            translate([xs, 3.8, -0.05]) cylinder(d = 3.6, h = 1.30);
        }
    }
}

// arch 4: Trombone / Ice Shard / Bat Pinion / Batarang Pod
module cheek_arch_b_4(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    wing_span = 8.8 + (sv % 4) * 0.40;
    peak_y    = 9.2 + (sv % 3) * 0.45;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.6);
            // Center bat/shard spine
            hull() {
                translate([0, 1.2, 0]) cylinder(d = 4.4, h = 2.2);
                translate([0, peak_y, 0]) cylinder(d1 = 2.8, d2 = 1.6, h = 2.5);
            }
            // Scalloped left/right pinion shards (single unified hull per side for guaranteed 2-manifold)
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 2.0, 2.0, 0]) cylinder(d = 3.6, h = 2.1);
                    translate([xs * 5.4, 2.0, 0]) cylinder(d = 3.4, h = 2.0);
                    translate([xs * 4.8, 6.2, 0]) cylinder(d = 3.2, h = 2.2);
                    translate([xs * wing_span, 8.2, 0]) cylinder(d1 = 2.6, d2 = 1.5, h = 2.35);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-3.2, 0, 3.2]) {
            translate([xs, 4.4, -0.05]) cylinder(d = 3.4, h = 1.30);
        }
    }
}

// arch 5: Harp / Tidal Wave / Ghost Wisp / Anime Energy Wing Pod
module cheek_arch_b_5(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    curls = 3 + (sv % 3);
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.4);
            // Sweeping S-curve wave / harp soundboard arch
            hull() {
                translate([-6.4, 1.5, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 0.0, 4.8, 0]) cylinder(d = 4.4, h = 2.2);
                translate([ 6.4, 2.2, 0]) cylinder(d = 3.6, h = 2.1);
            }
            // Layered energy plumes / wave crests
            for (i = [0 : curls - 1]) {
                px = -5.4 + i * (10.8 / max(1, curls - 1));
                py = 7.4 + (i % 2) * 1.4 + (sv % 3) * 0.35;
                hull() {
                    translate([px * 0.65, 3.8, 0]) cylinder(d = 3.4, h = 2.1);
                    translate([px, py, 0]) cylinder(d1 = 3.0, d2 = 1.6, h = 2.4);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-2.6, 2.6]) {
            translate([xs, 4.2, -0.05]) cylinder(d = 3.8, h = 1.30);
        }
    }
}

// arch 6: Violin / Ruby Hex / Coffin Shield / Radiation Shield Pod
module cheek_arch_b_6(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    hex_w = 6.6 + (sv % 4) * 0.30;
    hex_y = 8.8 + (sv % 3) * 0.35;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.2);
            // Faceted coffin / ruby hex shield body
            hull() {
                translate([-4.5, 1.5, 0]) cylinder(d = 3.4, h = 2.2, $fn = 6);
                translate([ 4.5, 1.5, 0]) cylinder(d = 3.4, h = 2.2, $fn = 6);
                translate([-hex_w, 5.2, 0]) cylinder(d = 3.5, h = 2.25, $fn = 6);
                translate([ hex_w, 5.2, 0]) cylinder(d = 3.5, h = 2.25, $fn = 6);
                translate([ 0.0, hex_y, 0]) cylinder(d = 3.8, h = 2.35, $fn = 6);
            }
            // Raised bevel crown table on top
            hull() {
                translate([-3.2, 3.6, 2.0]) cylinder(d = 2.2, h = 0.70, $fn = 6);
                translate([ 3.2, 3.6, 2.0]) cylinder(d = 2.2, h = 0.70, $fn = 6);
                translate([ 0.0, hex_y - 1.8, 2.0]) cylinder(d = 2.4, h = 0.70, $fn = 6);
            }
        }
        cheek_hub_cuts(pad_h);
        // Underside hexagonal weight-relief cavities
        translate([-2.8, 4.6, -0.05]) cylinder(d = 4.2, h = 1.35, $fn = 6);
        translate([ 2.8, 4.6, -0.05]) cylinder(d = 4.2, h = 1.35, $fn = 6);
        translate([ 0.0, 6.6, -0.05]) cylinder(d = 3.8, h = 1.35, $fn = 6);
    }
}

// arch 7: Tambourine / Clockwork Cog / Spider Web / Spur Rowel Pod
module cheek_arch_b_7(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    teeth = 5 + (sv % 4); // 5..8 cog teeth / rowel points
    rad   = 5.6 + (sv % 3) * 0.35;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.2);
            // Strut to gear/tambourine center
            hull() {
                translate([-4.2, 1.2, 0]) cylinder(d = 3.6, h = 2.1);
                translate([ 4.2, 1.2, 0]) cylinder(d = 3.6, h = 2.1);
                translate([ 0.0, 6.0, 0]) cylinder(d = rad * 1.65, h = 2.2);
            }
            // Outer gear teeth / jingle zils / spur points
            for (i = [0 : teeth - 1]) {
                a = -75 + i * (150 / max(1, teeth - 1));
                translate([0, 6.0, 0])
                    rotate([0, 0, a])
                        hull() {
                            translate([0, rad * 0.55, 0]) cylinder(d = 2.4, h = 2.3);
                            translate([0, rad + 1.6, 0]) cylinder(d1 = 2.2, d2 = 1.3, h = 2.4);
                        }
            }
            // Raised clockwork hub cap
            translate([0, 6.0, 2.0]) cylinder(d1 = 4.8, d2 = 3.4, h = 0.75);
        }
        cheek_hub_cuts(pad_h);
        translate([0, 6.0, -0.05]) cylinder(d = 5.6, h = 1.35);
    }
}

// arch 8: Microphone / Steampunk Piston / Broom / Web-Shooter Pod
module cheek_arch_b_8(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    len_x = 7.4 + (sv % 4) * 0.35;
    rings = 3 + (sv % 3);
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.2);
            // Twin mounting stanchions
            for (xs = [-3.6, 3.6]) {
                hull() {
                    translate([xs, 1.2, 0]) cylinder(d = 3.6, h = 2.1);
                    translate([xs, 5.6, 0]) cylinder(d = 3.6, h = 2.2);
                }
            }
            // Horizontal cylindrical piston / microphone / web-shooter barrel
            hull() {
                translate([-len_x, 5.8, 0]) cylinder(d1 = 4.2, d2 = 3.4, h = 2.4);
                translate([ len_x, 5.8, 0]) cylinder(d1 = 4.2, d2 = 3.4, h = 2.4);
            }
            // Cooling fins / microphone grille rings / piston collars
            for (i = [0 : rings - 1]) {
                rx = -len_x + 2.0 + i * ((2 * len_x - 4.0) / max(1, rings - 1));
                hull() {
                    translate([rx, 4.4, 0]) cylinder(d = 2.4, h = 2.65);
                    translate([rx, 7.6, 0]) cylinder(d = 2.4, h = 2.65);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-3.6, 0, 3.6]) {
            translate([xs, 5.8, -0.05]) cylinder(d = 3.4, h = 1.35);
        }
    }
}

// arch 9: Pan Flute / Crystal Cluster / Cactus Paddle / Feather Binder Pod
module cheek_arch_b_9(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    pipes = 5;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.4);
            // Stepped pan-flute / crystal cluster array
            for (i = [0 : pipes - 1]) {
                px = (i - 2) * (2.6 + (sv % 3) * 0.12);
                py = 6.8 + (2 - abs(i - 2)) * 1.45 + (sv % 4) * 0.25;
                hull() {
                    translate([px * 0.75, 1.8, 0]) cylinder(d = 3.2, h = 2.1);
                    translate([px, py, 0]) cylinder(d1 = 3.0, d2 = 2.0, h = 2.4, $fn = 8);
                }
            }
            // Cross binder strap across middle
            hull() {
                translate([-6.2, 4.4, 0]) cylinder(d = 2.6, h = 2.55);
                translate([ 6.2, 4.4, 0]) cylinder(d = 2.6, h = 2.55);
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-3.2, 0, 3.2]) {
            translate([xs, 4.8, -0.05]) cylinder(d = 3.6, h = 1.35);
        }
    }
}

// arch 10: Equalizer / Bismuth Step / Monstera / Saddlebag Pod
module cheek_arch_b_10(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    bars  = 4 + (sv % 2); // 4 or 5 equalizer/bismuth bars
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.6);
            // Stepped rectangular/chamfered manifold plate
            hull() {
                translate([-6.4, 1.6, 0]) cylinder(d = 3.6, h = 2.0);
                translate([ 6.4, 1.6, 0]) cylinder(d = 3.6, h = 2.0);
                translate([-5.8, 6.8, 0]) cylinder(d = 3.4, h = 2.0);
                translate([ 5.8, 6.8, 0]) cylinder(d = 3.4, h = 2.0);
            }
            // Equalizer slider bars / bismuth stair steps / monstera ribs
            for (i = [0 : bars - 1]) {
                bx = -5.4 + i * (10.8 / max(1, bars - 1));
                by = 7.6 + ((i + sv) % 3) * 1.1;
                hull() {
                    translate([bx, 2.2, 0]) cylinder(d = 2.4, h = 2.5);
                    translate([bx, by, 0]) cylinder(d1 = 2.6, d2 = 1.8, h = 2.5);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-3.6, 0, 3.6]) {
            translate([xs, 4.6, -0.05]) cylinder(d = 3.8, h = 1.35);
        }
    }
}

// arch 11: Balloon Dog / Copper Coil / Scorpion Pincer / Horseshoe Pod
module cheek_arch_b_11(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    jaw_x = 5.4 + (sv % 4) * 0.35;
    jaw_y = 9.0 + (sv % 3) * 0.40;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.4);
            // U-shaped horseshoe / pincer base arch
            hull() {
                translate([-5.6, 1.8, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 5.6, 1.8, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 0.0, 4.4, 0]) cylinder(d = 4.6, h = 2.2);
            }
            // Left and right curved pincer arms / horseshoe heels
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 4.8, 2.8, 0]) cylinder(d = 3.8, h = 2.2);
                    translate([xs * (jaw_x + 0.8), 6.2, 0]) cylinder(d = 3.6, h = 2.3);
                }
                hull() {
                    translate([xs * (jaw_x + 0.8), 6.2, 0]) cylinder(d = 3.6, h = 2.3);
                    translate([xs * (jaw_x - 2.0), jaw_y, 0]) cylinder(d1 = 2.8, d2 = 1.8, h = 2.4);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-3.8, 3.8]) {
            translate([xs, 4.6, -0.05]) cylinder(d = 3.4, h = 1.30);
        }
    }
}

// arch 12: Jukebox / Bellows / Skeleton Hand / Wagon Wheel Pod
module cheek_arch_b_12(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    spokes = 4 + (sv % 2); // 4 or 5 finger bones / wheel spokes / bucket teeth
    fan_r  = 8.6 + (sv % 4) * 0.35;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.4);
            // Palm / wheel rim arch
            hull() {
                translate([-4.6, 1.5, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 4.6, 1.5, 0]) cylinder(d = 3.8, h = 2.2);
                translate([ 0.0, 4.8, 0]) cylinder(d = 5.4, h = 2.2);
            }
            // Radiating fingers / spokes / digging teeth
            for (i = [0 : spokes - 1]) {
                ang = -48 + i * (96 / max(1, spokes - 1));
                rotate([0, 0, ang])
                    hull() {
                        translate([0, 2.8, 0]) cylinder(d = 2.8, h = 2.2);
                        translate([0, fan_r, 0]) cylinder(d1 = 2.6, d2 = 1.6, h = 2.4);
                    }
            }
            // Outer rim band connecting the spokes
            for (i = [0 : spokes - 2]) {
                a1 = -48 + i * (96 / max(1, spokes - 1));
                a2 = -48 + (i + 1) * (96 / max(1, spokes - 1));
                hull() {
                    rotate([0, 0, a1]) translate([0, fan_r - 1.6, 0]) cylinder(d = 2.2, h = 2.1);
                    rotate([0, 0, a2]) translate([0, fan_r - 1.6, 0]) cylinder(d = 2.2, h = 2.1);
                }
            }
        }
        cheek_hub_cuts(pad_h);
        translate([0, 4.8, -0.05]) cylinder(d = 4.6, h = 1.30);
    }
}

// arch 13: Gramophone / Compass Star / Jack-O-Lantern / Repulsor Disc Pod
module cheek_arch_b_13(subvar = 12) {
    sv = subvar - 12;
    pad_h = 2.20;
    lobe_x = 3.6 + (sv % 4) * 0.25;
    lobe_d = 6.2 + (sv % 3) * 0.35;
    difference() {
        union() {
            cheek_hub_solid(pad_h, 7.6);
            // Twin-lobe binocular / repulsor / pumpkin / gramophone flare body
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 3.0, 1.5, 0]) cylinder(d = 3.8, h = 2.1);
                    translate([xs * lobe_x, 6.2, 0]) cylinder(d1 = lobe_d, d2 = lobe_d - 1.0, h = 2.4);
                }
                // Raised repulsor / lens bezel ring
                translate([xs * lobe_x, 6.2, 2.1])
                    cylinder(d1 = 3.8, d2 = 2.6, h = 0.70);
            }
            // Center compass / pumpkin stem ridge
            hull() {
                translate([0, 2.0, 0]) cylinder(d = 3.6, h = 2.3);
                translate([0, 8.8 + (sv % 3) * 0.4, 0]) cylinder(d1 = 2.8, d2 = 1.6, h = 2.5);
            }
        }
        cheek_hub_cuts(pad_h);
        for (xs = [-1, 1]) {
            translate([xs * lobe_x, 6.0, -0.05]) cylinder(d = 3.8, h = 1.35);
        }
    }
}

// ============================================================================
// ARCHETYPE DISPATCHER & MIRRORED PAIR RENDERER
// ============================================================================

module dispatch_cheek_arch_b(a, sv) {
    if      (a == 0)  cheek_arch_b_0(sv);
    else if (a == 1)  cheek_arch_b_1(sv);
    else if (a == 2)  cheek_arch_b_2(sv);
    else if (a == 3)  cheek_arch_b_3(sv);
    else if (a == 4)  cheek_arch_b_4(sv);
    else if (a == 5)  cheek_arch_b_5(sv);
    else if (a == 6)  cheek_arch_b_6(sv);
    else if (a == 7)  cheek_arch_b_7(sv);
    else if (a == 8)  cheek_arch_b_8(sv);
    else if (a == 9)  cheek_arch_b_9(sv);
    else if (a == 10) cheek_arch_b_10(sv);
    else if (a == 11) cheek_arch_b_11(sv);
    else if (a == 12) cheek_arch_b_12(sv);
    else              cheek_arch_b_13(sv);
}

// Render Left + Right Mirrored Cheek Pod Pair (PART_ID = 1576..1750)
module render_cheek_pair_b(part_id = 1576) {
    a  = (part_id - 1401) % 14;
    sv = floor((part_id - 1401) / 14);
    for (side = [-1, 1]) {
        translate([0, side * 15, 0])
            mirror([0, (side < 0 ? 1 : 0), 0])
                dispatch_cheek_arch_b(a, sv);
    }
    // Internal registration marker inside +Y pod hub for 3-volume structure (Volumes: 3, Simple: yes)
    translate([0, 15 + 1.8, 0.55])
        cube([0.2, 0.2, 0.2], center = true);
}

if (PART_ID >= 1576 && PART_ID <= 1750) {
    render_cheek_pair_b(PART_ID);
}