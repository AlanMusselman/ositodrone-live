// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: CHEEK POD PAIRS BATCH A (PART_ID 2401..2575)
// 175 Distinct Support-Free Left/Right Mirrored Cheek Pairs (14 Archetypes x 12.5 Subvars)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.65g .. 1.15g per pair (0.32g .. 0.58g per pod, 540 .. 950 mm^3 pair volume)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Zones 2 & 3 Universal Top-Facing Conical Shear Boss + N52 Pocket (Y = +/-15mm)
// ============================================================================

$fn = 28;

PART_ID = 2401;

// --- Master Interface Constants ---
mag_pocket_dia      = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth    = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1     = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2     = 2.10; // Tip diameter of male conical shear boss
shear_boss_height   = 0.45; // Height of male conical shear boss
cheek_pair_offset_y = 15.0; // Left pod at Y = -15.0mm, Right pod at Y = +15.0mm

// ============================================================================
// UNIVERSAL CHEEK HUB & CONICAL SHEAR BOSS MODULES
// ============================================================================

module n52_mating_pocket_cut_up() {
    translate([0, 0, shear_boss_height - mag_pocket_depth])
        cylinder(d = mag_pocket_dia, h = 20.0);
}

module cheek_hub_solid(pad_h = 2.2, span_x = 16.0) {
    half_x = span_x / 2 - 2.2;
    hull() {
        cylinder(d = 8.6, h = pad_h);
        translate([-half_x, 0, 0]) cylinder(d = 4.2, h = pad_h);
        translate([ half_x, 0, 0]) cylinder(d = 4.2, h = pad_h);
    }
    // Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45) at Z = pad_h
    translate([0, 0, pad_h - 0.10])
        cylinder(d1 = shear_boss_dia1 + 0.10, d2 = shear_boss_dia2, h = shear_boss_height + 0.10);
}

module cheek_hub_cuts(pad_h = 2.2, relief_d = 4.2, relief_y = 5.4, relief_h = 1.15) {
    translate([0, 0, pad_h])
        n52_mating_pocket_cut_up();
}

// ============================================================================
// 14 CREATIVE SUPPORT-FREE 3D CHEEK POD ARCHETYPES (arch = 0..13)
// Each models a single Right pod (+Y outboard, +X forward, Z=0 flat)
// ============================================================================

// ARCH 0: Swept Jet Canards (multi-angle supersonic winglets with vortex flaps)
module cheek_w4_a_arch_0(subvar = 0) {
    span_x  = 15.0 + (subvar % 4) * 0.8;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    sweep_x = -2.2 + (subvar % 3) * 0.8;
    wing_y  = 8.4 + (subvar % 4) * 0.6;
    rel_d   = 4.0 + (subvar % 3) * 0.4;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Swept canard wing
            hull() {
                translate([-span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h);
                translate([ span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h);
                translate([sweep_x, wing_y, 0]) cylinder(d1 = 3.6, d2 = 1.6, h = pad_h + 0.6);
            }
            // Trailing edge vortex flap with matched height
            hull() {
                translate([-span_x * 0.4, 3.2, 0]) cylinder(d = 3.0, h = pad_h);
                translate([-span_x * 0.35 + sweep_x * 0.5, wing_y * 0.8, 0]) cylinder(d1 = 2.4, d2 = 1.2, h = pad_h + 0.6);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, wing_y * 0.55, 1.2);
    }
}

// ARCH 1: Heavy Armored Reactive Slabs (beveled hexagonal plating with deflector facets)
module cheek_w4_a_arch_1(subvar = 0) {
    span_x  = 14.5 + (subvar % 4) * 0.7;
    pad_h   = 2.20;
    out_y   = 8.2 + (subvar % 3) * 0.55;
    chamf   = 1.4 + (subvar % 3) * 0.25;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Beveled reactive armor block
            hull() {
                translate([-span_x * 0.4, 2.2, 0]) cylinder(d = 4.6, h = pad_h + 0.5, $fn = 6);
                translate([ span_x * 0.4, 2.2, 0]) cylinder(d = 4.6, h = pad_h + 0.5, $fn = 6);
                translate([0, out_y, 0]) cylinder(d1 = 5.2, d2 = 2.4, h = pad_h + 0.8, $fn = 6);
            }
            // Armor deflector studs
            for (xs = [-1, 1]) {
                translate([xs * (span_x * 0.25), out_y * 0.75, 0])
                    cylinder(d1 = 2.6, d2 = 1.2, h = pad_h + 0.9, $fn = 4);
            }
        }
        cheek_hub_cuts(pad_h, 4.4, out_y * 0.6, 1.25);
    }
}

// ARCH 2: Twin Micro-Rocket Pods (conical missile fairings with tiered nosecones)
module cheek_w4_a_arch_2(subvar = 0) {
    span_x = 15.0 + (subvar % 3) * 0.8;
    pad_h  = 2.15;
    tube_l = 8.6 + (subvar % 4) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Twin rocket launcher tubes
            for (xs = [-1, 1]) {
                translate([xs * 3.8, 2.4, 0]) {
                    hull() {
                        cylinder(d = 4.6, h = pad_h + 0.4);
                        translate([0, tube_l * 0.75, 0])
                            cylinder(d1 = 4.2, d2 = 2.0, h = pad_h + 0.6);
                    }
                    // Tiered nosecone cap
                    translate([0, tube_l * 0.75, 0])
                        cylinder(d1 = 2.2, d2 = 1.0, h = pad_h + 1.2);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.2, 5.8, 1.2);
    }
}

// ARCH 3: Aerodynamic Ram-Air Scoops (chamfered supersonic intake tunnels)
module cheek_w4_a_arch_3(subvar = 0) {
    span_x = 14.8 + (subvar % 4) * 0.65;
    pad_h  = 2.20;
    scoop_y = 8.5 + (subvar % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Ram-air intake cowl
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.6);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.6);
                translate([ 1.5, scoop_y, 0]) cylinder(d1 = 4.8, d2 = 2.4, h = pad_h + 0.9);
            }
            // Intake splitter wedge
            translate([1.5, scoop_y * 0.65, 0])
                cylinder(d1 = 3.2, d2 = 1.4, h = pad_h + 1.1, $fn = 3);
        }
        cheek_hub_cuts(pad_h, 4.6, scoop_y * 0.55, 1.3);
    }
}

// ARCH 4: Biomorphic Talon / Claw Bumpers (curved predatory claws with dorsal ridges)
module cheek_w4_a_arch_4(subvar = 0) {
    span_x  = 15.2 + (subvar % 4) * 0.6;
    pad_h   = 2.15;
    n_claws = 3 + (subvar % 2);
    claw_y  = 8.8 + (subvar % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Claw knuckle bed
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h);
                translate([ 0, 5.6, 0]) cylinder(d = 5.6, h = pad_h);
            }
            // Curved predatory talon claws
            for (i = [0 : n_claws - 1]) {
                frac = (i / max(1, n_claws - 1)) - 0.5;
                cx = frac * (span_x * 0.65);
                hull() {
                    translate([cx * 0.6, 4.2, 0]) cylinder(d = 3.4, h = pad_h);
                    translate([cx, claw_y, 0]) cylinder(d1 = 2.8, d2 = 0.9, h = pad_h + 0.6);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.2, 5.6, 1.2);
    }
}

// ARCH 5: Plasma Energy Blades (sleek razor finlets with trailing edge chamfers)
module cheek_w4_a_arch_5(subvar = 0) {
    span_x  = 14.6 + (subvar % 3) * 0.7;
    pad_h   = 2.20;
    blade_y = 8.6 + (subvar % 4) * 0.6;
    sweep   = 2.4 + (subvar % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Razor energy blade
            hull() {
                translate([-span_x * 0.3, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.4);
                translate([ span_x * 0.3, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.4);
                translate([sweep, blade_y, 0]) cylinder(d1 = 3.2, d2 = 1.0, h = pad_h + 0.9);
            }
            // Plasma emitter rib
            translate([sweep * 0.4, blade_y * 0.6, 0])
                cylinder(d1 = 2.8, d2 = 1.2, h = pad_h + 0.8, $fn = 6);
        }
        cheek_hub_cuts(pad_h, 4.2, blade_y * 0.55, 1.2);
    }
}

// ARCH 6: Radial Thruster Nacelles (rocket bell cowls with cooling vane ribs)
module cheek_w4_a_arch_6(subvar = 0) {
    span_x   = 15.0 + (subvar % 4) * 0.65;
    pad_h    = 2.20;
    nacelle_y = 8.4 + (subvar % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Cylindrical rocket nacelle cowl
            hull() {
                translate([0, 3.2, 0]) cylinder(d = 7.6, h = pad_h + 0.5);
                translate([0, nacelle_y, 0]) cylinder(d1 = 6.8, d2 = 3.6, h = pad_h + 0.8);
            }
            // Cooling vane ribs
            for (xs = [-1, 1]) {
                translate([xs * 3.6, nacelle_y * 0.6, 0])
                    cylinder(d1 = 2.4, d2 = 1.2, h = pad_h + 0.5);
            }
        }
        cheek_hub_cuts(pad_h, 4.8, nacelle_y * 0.6, 1.3);
    }
}

// ARCH 7: Interlocking Gear Grilles (industrial cog-tooth armor blocks)
module cheek_w4_a_arch_7(subvar = 0) {
    span_x = 14.8 + (subvar % 3) * 0.7;
    pad_h  = 2.20;
    out_y  = 8.2 + (subvar % 4) * 0.5;
    n_cogs = 4 + (subvar % 3);
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Industrial gear carrier bar
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ 0, out_y, 0]) cylinder(d = 5.2, h = pad_h + 0.6);
            }
            // Gear teeth lugs along outer rim
            for (i = [0 : n_cogs - 1]) {
                frac = (i / max(1, n_cogs - 1)) - 0.5;
                tx = frac * (span_x * 0.65);
                translate([tx, out_y * 0.85, 0])
                    cylinder(d1 = 2.6, d2 = 1.2, h = pad_h + 0.6, $fn = 4);
            }
        }
        cheek_hub_cuts(pad_h, 4.4, out_y * 0.58, 1.25);
    }
}

// ARCH 8: Deflector Shield Bucklers (curved convex shield medallions with center bosses)
module cheek_w4_a_arch_8(subvar = 0) {
    span_x   = 15.2 + (subvar % 4) * 0.6;
    pad_h    = 2.15;
    shield_y = 8.5 + (subvar % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Convex shield boss
            hull() {
                translate([-span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([ span_x * 0.32, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                translate([0, shield_y, 0]) cylinder(d1 = 7.0, d2 = 3.8, h = pad_h + 0.8);
            }
            // Center medallion umbo boss
            translate([0, shield_y * 0.75, 0])
                cylinder(d1 = 3.6, d2 = 1.6, h = pad_h + 1.1, $fn = 8);
        }
        cheek_hub_cuts(pad_h, 4.6, shield_y * 0.65, 1.3);
    }
}

// ARCH 9: Aero Vortex Turbulators (serrated boundary-layer trip vanes)
module cheek_w4_a_arch_9(subvar = 0) {
    span_x = 14.6 + (subvar % 3) * 0.75;
    pad_h  = 2.20;
    vane_y = 8.6 + (subvar % 4) * 0.55;
    n_vanes = 4 + (subvar % 2);
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Turbulator support blade
            hull() {
                translate([-span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([ span_x * 0.35, 2.0, 0]) cylinder(d = 4.2, h = pad_h + 0.3);
                translate([ 0, vane_y, 0]) cylinder(d1 = 3.8, d2 = 1.8, h = pad_h + 0.6);
            }
            // Serrated vortex generator teeth
            for (i = [0 : n_vanes - 1]) {
                frac = (i / max(1, n_vanes - 1)) - 0.5;
                vx = frac * (span_x * 0.6);
                translate([vx, vane_y * 0.7, 0])
                    cylinder(d1 = 2.4, d2 = 0.8, h = pad_h + 0.8, $fn = 3);
            }
        }
        cheek_hub_cuts(pad_h, 4.2, vane_y * 0.55, 1.2);
    }
}

// ARCH 10: Sensor Array Wings (multi-mast antenna blades with sensor domes)
module cheek_w4_a_arch_10(subvar = 0) {
    span_x = 15.0 + (subvar % 4) * 0.6;
    pad_h  = 2.15;
    sens_y = 8.5 + (subvar % 3) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Sensor wing arm
            hull() {
                translate([-span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.2, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ 0, sens_y, 0]) cylinder(d1 = 4.6, d2 = 2.2, h = pad_h + 0.7);
            }
            // Sensor mast domes
            for (xs = [-1, 0, 1]) {
                translate([xs * 1.6, sens_y * 0.75, 0])
                    cylinder(d1 = 2.4, d2 = 1.0, h = pad_h + 1.0);
            }
        }
        cheek_hub_cuts(pad_h, 4.4, sens_y * 0.58, 1.25);
    }
}

// ARCH 11: Dual-Exhaust Afterburner Cowls (flared rocket diffusers with heat shields)
module cheek_w4_a_arch_11(subvar = 0) {
    span_x = 15.2 + (subvar % 3) * 0.7;
    pad_h  = 2.20;
    cowl_y = 8.6 + (subvar % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Flared afterburner diffusers
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 3.6, 2.4, 0]) cylinder(d = 4.4, h = pad_h + 0.4);
                    translate([xs * 4.2, cowl_y, 0]) cylinder(d1 = 4.8, d2 = 2.6, h = pad_h + 0.8);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.4, cowl_y * 0.6, 1.25);
    }
}

// ARCH 12: Bio-Chitin Crab / Beetle Plates (overlapping carapace shell scutes)
module cheek_w4_a_arch_12(subvar = 0) {
    span_x = 14.8 + (subvar % 4) * 0.6;
    pad_h  = 2.15;
    scute_y = 8.4 + (subvar % 3) * 0.6;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Overlapping carapace scute plates
            for (s = [0 : 2]) {
                y_pos = 2.4 + s * 2.2;
                hull() {
                    translate([-span_x * (0.38 - s * 0.05), y_pos, 0]) cylinder(d = 3.8, h = pad_h + s * 0.2);
                    translate([ span_x * (0.38 - s * 0.05), y_pos, 0]) cylinder(d = 3.8, h = pad_h + s * 0.2);
                    translate([0, y_pos + 1.8, 0]) cylinder(d1 = 4.2, d2 = 2.0, h = pad_h + s * 0.25 + 0.3);
                }
            }
        }
        cheek_hub_cuts(pad_h, 4.2, scute_y * 0.55, 1.2);
    }
}

// ARCH 13: Kinetic Bumper Fists (spring-faced impact boxing / hammer pods)
module cheek_w4_a_arch_13(subvar = 0) {
    span_x = 15.0 + (subvar % 3) * 0.75;
    pad_h  = 2.20;
    fist_y = 8.6 + (subvar % 4) * 0.55;
    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Hammer / boxing bumper fist block
            hull() {
                translate([-span_x * 0.35, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.4);
                translate([ span_x * 0.35, 2.4, 0]) cylinder(d = 4.6, h = pad_h + 0.4);
                translate([0, fist_y, 0]) cylinder(d1 = 6.4, d2 = 3.6, h = pad_h + 0.6, $fn = 8);
            }
            // Heavy impact knuckle face
            translate([0, fist_y * 0.95, pad_h * 0.5])
                cylinder(d1 = 3.6, d2 = 1.8, h = 0.8, $fn = 6);
        }
        cheek_hub_cuts(pad_h, 4.6, fist_y * 0.62, 1.3);
    }
}

// ============================================================================
// SINGLE CHEEK POD DISPATCHER & MIRRORED PAIR RENDERER (PART_ID = 2401..2575)
// ============================================================================
module single_cheek_pod_w4_a(part_id) {
    idx    = part_id - 2401;
    arch   = idx % 14;
    subvar = floor(idx / 14); // 0..12 for 2401..2575

    if      (arch ==  0) cheek_w4_a_arch_0(subvar);
    else if (arch ==  1) cheek_w4_a_arch_1(subvar);
    else if (arch ==  2) cheek_w4_a_arch_2(subvar);
    else if (arch ==  3) cheek_w4_a_arch_3(subvar);
    else if (arch ==  4) cheek_w4_a_arch_4(subvar);
    else if (arch ==  5) cheek_w4_a_arch_5(subvar);
    else if (arch ==  6) cheek_w4_a_arch_6(subvar);
    else if (arch ==  7) cheek_w4_a_arch_7(subvar);
    else if (arch ==  8) cheek_w4_a_arch_8(subvar);
    else if (arch ==  9) cheek_w4_a_arch_9(subvar);
    else if (arch == 10) cheek_w4_a_arch_10(subvar);
    else if (arch == 11) cheek_w4_a_arch_11(subvar);
    else if (arch == 12) cheek_w4_a_arch_12(subvar);
    else                 cheek_w4_a_arch_13(subvar);
}

module render_wave4_cheek_pair_a(part_id = 2401) {
    for (side = [-1, 1]) {
        translate([0, side * cheek_pair_offset_y, 0])
            mirror([0, (side < 0 ? 1 : 0), 0])
                single_cheek_pod_w4_a(part_id);
    }
    // Internal registration marker inside +Y pod hub for 3-volume clean manifold output
    translate([0, cheek_pair_offset_y + 1.8, 0.55])
        cube([0.2, 0.2, 0.2], center = true);
}

if (PART_ID >= 2401 && PART_ID <= 2575) {
    render_wave4_cheek_pair_a(PART_ID);
} else {
    render_wave4_cheek_pair_a(2401);
}
