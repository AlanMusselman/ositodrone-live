// ============================================================================
// KODIAK-75: 100 Osito Sacrificial Parts Library (Production Master)
// Universal Magnetic Snap-On Breakaway Architecture for Bumper Drones
// ============================================================================
// Total Components: 100 Distinct Sacrificial Parts
// - Zone 1: Top Crowns       (PART_ID = 101 to 140) [40 Apex Toppers]
// - Zones 2 & 3: Cheek Pairs (PART_ID = 201 to 235) [35 Pairs / 70 Parts]
// - Zone 4: Belly Skids      (PART_ID = 301 to 325) [25 Ventral Skids]
//
// Material: TPU 95A (density = 0.00121 g/mm^3)
// Mass Target Budget: strictly 0.30g to 1.20g per piece (Volume: 248 - 992 mm^3)
// Support Policy: 100% Support-Free FDM Printing at Z = 0.00mm
// Polarity Standard: Grade N52 disc magnets (2mm OD x 1mm thick), South-Facing-Out
// ============================================================================

$fn = 32;

// Command-line selector: openscad -D PART_ID=<id> -o <target>.stl ...
// PART_ID = 0          : Showcase Loadout Preview
// PART_ID = 101 .. 140 : Zone 1 Top Crowns (40 Toppers)
// PART_ID = 201 .. 235 : Zones 2 & 3 Cheek Pod Pairs (35 Pairs / 70 Parts)
// PART_ID = 301 .. 325 : Zone 4 Belly Skids (25 Skids)
PART_ID = 0;

// --- Master Interface Constants ---
mag_pocket_dia        = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth      = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1       = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2       = 2.10; // Tip diameter of male conical shear boss (Z = 0 or tip)
shear_boss_height     = 0.45; // Height of male conical shear boss (mates into 0.50mm dimple)
shear_dimple_dia      = 3.60; // Drone female conical dimple mouth diameter
shear_dimple_depth    = 0.50; // Drone female conical dimple depth
crown_annular_dia     = 8.40; // Shrouds drone's 8.0mm deck boss (0.20mm radial clearance)
crown_annular_depth   = 0.45; // Annular shroud relief depth
belly_mag_spacing     = 36.0; // Ventral dual-magnet pitch along X-axis (X = -18mm and X = +18mm)
cheek_print_spacing   = 32.0; // Y = -16.0mm (Left, Zone 2) and Y = +16.0mm (Right, Zone 3)

// ============================================================================
// UNIVERSAL HELPER MODULES
// ============================================================================

// Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45)
module n52_mating_boss_up() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

// Top-facing recessed magnet pocket cut through boss
module n52_mating_pocket_cut_up() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.10);
}

// Zone 1 Standard Top Crown Base Solid (Print bed at Z = 0)
// Outer skirt OD=15.6mm and central boss tip d2=2.10mm both touch Z=0
module top_crown_base_solid(base_od = 15.6, base_h = 2.6) {
    difference() {
        cylinder(d1 = base_od, d2 = base_od - 3.2, h = base_h);
        translate([0, 0, -0.05])
            cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.05);
    }
    // Male conical shear boss protruding downward reaching exactly Z = 0
    cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1 + 0.20, h = shear_boss_height + 0.35);
}

// Zone 1 Standard Top Crown Magnet Pocket Cut + Annular Recess & Vent Channels
module top_crown_base_cuts(base_h = 2.6) {
    translate([0, 0, -0.05])
        cylinder(d = mag_pocket_dia, h = mag_pocket_depth + shear_boss_height + 0.05);
    // Ensure annular recess around male conical shear boss is always open to Z=0
    difference() {
        translate([0, 0, -0.05])
            cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.05);
        translate([0, 0, -0.10])
            cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1 + 0.30, h = shear_boss_height + 0.45);
    }
    // Vent channels connecting internal weight-relief domes to the 8.4mm annular shroud
    for (a = [0, 120, 240]) {
        rotate([0, 0, a])
            translate([2.6, 0, 0.25])
                cylinder(d = 1.6, h = 2.8);
    }
}

// Zones 2 & 3 Standard Cheek Hub Pad Solid (Print bed at Z = 0)
module cheek_hub_solid(pad_h = 2.4) {
    hull() {
        cylinder(d = 8.8, h = pad_h);
        translate([-8.5, 0, 0]) cylinder(d = 4.4, h = pad_h - 0.6);
        translate([ 8.5, 0, 0]) cylinder(d = 4.4, h = pad_h - 0.6);
    }
    translate([0, 0, pad_h - 0.15])
        cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
}

// Zones 2 & 3 Standard Cheek Hub Magnet Pocket Cut
module cheek_hub_cuts(pad_h = 2.4) {
    translate([0, 0, pad_h])
        n52_mating_pocket_cut_up();
}

// Zone 4 Standard Dual Bosses Up (no-op inside raw body; applied unscaled by belly_skid_master_trim)
module belly_dual_bosses_up(z_top = 1.6) {
}

// Zone 4 Standard Dual Pockets Cut (no-op inside raw body; applied unscaled by belly_skid_master_trim)
module belly_dual_pockets_cut(z_top = 1.6) {
}

// Zone 4 Master Trim & Unscaled Dual-Magnet Interface Wrapper
// Scales raw skid Z-profile into the 0.55g-1.15g TPU 95A target range while preserving
// Z=0 flat bed contact and 100% unscaled 36.0mm N52 pockets + 0.45mm conical shear bosses.
module belly_skid_master_trim(z_scale = 0.42, hub_h = 1.60) {
    difference() {
        union() {
            scale([1, 1, z_scale])
                intersection() {
                    children(0);
                    translate([0, 0, 10.0]) cube([100, 100, 20.0], center=true);
                }
            for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
                translate([x_pos, 0, 0])
                    cylinder(d1 = 8.2, d2 = 6.8, h = hub_h);
                translate([x_pos, 0, hub_h - 0.15])
                    cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
            }
        }
        for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
            translate([x_pos, 0, hub_h])
                n52_mating_pocket_cut_up();
        }
    }
}

// ============================================================================
// ZONE 1: TOP CROWN SACRIFICIAL ACCESSORIES (PART_ID = 101..140)
// ============================================================================

// 101: Grizzly Snarl Crown (Wildlife)
module Crown_GrizzlySnarl() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Brow and muzzle bulk
            hull() {
                translate([0, 0, 2.2]) cylinder(d=11.0, h=3.0);
                translate([3.5, 0, 5.0]) sphere(d=6.5);
            }
            // Snout bridge & nose pad
            hull() {
                translate([3.5, 0, 5.0]) sphere(d=4.5);
                translate([5.5, 0, 6.2]) sphere(d=3.0);
            }
            // Swept dorsal fur crest
            hull() {
                translate([-4.5, 0, 2.2]) cube([3.0, 1.8, 1.0], center=true);
                translate([-2.5, 0, 10.5]) cube([1.8, 1.2, 1.5], center=true);
            }
            // Rounded ears anchored into brow
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-2.2, y_s * 3.0, 5.8]) sphere(d=3.2);
                    translate([-3.2, y_s * 4.8, 7.8])
                        rotate([y_s * 15, 0, 0])
                            cylinder(d=4.2, h=1.8, center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Snarling mouth cavity
        translate([3.8, 0, 3.8]) cube([4.5, 5.0, 2.2], center=true);
        // Mass coring pocket
        translate([0, 0, 2.6]) cylinder(d=6.8, h=4.2);
    }
}
module KODIAK75_Crown_GrizzlySnarl() { Crown_GrizzlySnarl(); }

// 102: Kodiak Roar Crown (Wildlife)
module Crown_KodiakRoar() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            hull() {
                cylinder(d=12.2, h=2.8);
                translate([1.0, 0, 6.5]) sphere(d=8.0);
            }
            // Upper roaring jaw
            hull() {
                translate([1.0, 0, 7.5]) sphere(d=5.5);
                translate([4.5, 0, 8.0]) sphere(d=4.0);
            }
            // Lower jaw
            hull() {
                translate([1.0, 0, 3.5]) sphere(d=5.0);
                translate([4.0, 0, 3.2]) sphere(d=3.5);
            }
            // Canine fangs
            for (y_s = [-1, 1]) {
                translate([4.2, y_s * 1.8, 5.5])
                    cylinder(d1=1.4, d2=0.6, h=2.2);
            }
        }
        top_crown_base_cuts(2.6);
        // Acoustic whistle venturi tunnel
        translate([5.0, 0, 4.8])
            rotate([0, 12, 0])
                cylinder(d1=4.8, d2=3.0, h=9.0, center=true);
        // Resonance core hollow
        translate([1.2, 0, 5.5]) sphere(d=6.0);
    }
}
module KODIAK75_Crown_KodiakRoar() { Crown_KodiakRoar(); }

// 103: Polar Crown (Arctic)
module Crown_PolarCrown() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Faceted hex base
            cylinder(d1=14.0, d2=11.5, h=4.8, $fn=6);
            // 6 Hexagonal ice spires overlapping hex base
            for (i = [0 : 5]) {
                rotate([0, 0, i * 60])
                    translate([4.4, 0, 2.0])
                        cylinder(d1=3.8, d2=0.8, h=(i % 2 == 0 ? 10.5 : 7.0), $fn=4);
            }
            // Central glacier peak
            translate([0, 0, 3.0])
                cylinder(d1=5.2, d2=1.0, h=8.5, $fn=4);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=5.8, h=2.4);
    }
}
module KODIAK75_Crown_PolarCrown() { Crown_PolarCrown(); }

// 104: Panda Bamboo Crown (Forest)
module Crown_PandaBamboo() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Panda cranial dome
            hull() {
                cylinder(d=12.5, h=2.5);
                translate([0, 0, 5.0]) sphere(d=9.8);
            }
            // Rounded ears anchored to dome
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.0, y_s * 3.5, 6.2]) sphere(d=3.6);
                    translate([-1.2, y_s * 5.0, 7.5]) sphere(d=3.8);
                }
            }
            // Flanking bamboo stalks anchored to base & dome
            for (y_s = [-1, 1]) {
                hull() {
                    translate([1.8, y_s * 3.8, 2.0]) cylinder(d=2.8, h=6.5);
                    translate([2.2, y_s * 5.0, 2.0]) cylinder(d1=2.6, d2=2.2, h=9.8);
                }
                // Bamboo leaves overlapping stalk top
                translate([2.2, y_s * 5.0, 11.2])
                    rotate([y_s * 25, 0, 0])
                        cylinder(d1=2.2, d2=0.6, h=2.5);
            }
        }
        top_crown_base_cuts(2.6);
        // Eye recesses
        for (y_s = [-1, 1]) {
            translate([3.6, y_s * 2.2, 5.2])
                rotate([0, 20, y_s * 15])
                    cylinder(d=2.6, h=1.8, center=true);
        }
        // Core cavity
        translate([0, 0, 2.6]) cylinder(d=7.0, h=4.2);
    }
}
module KODIAK75_Crown_PandaBamboo() { Crown_PandaBamboo(); }

// 105: Sun Bear Crest (Wildlife)
module Crown_SunBearCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Crescent collar crest across frontal brow
            hull() {
                translate([4.0, -5.5, 3.0]) cylinder(d=2.6, h=2.0);
                translate([6.2,  0.0, 4.0]) cylinder(d=3.2, h=2.4);
                translate([4.0,  5.5, 3.0]) cylinder(d=2.6, h=2.0);
            }
            // Slender sun bear muzzle
            hull() {
                translate([0, 0, 2.5]) cylinder(d=10.0, h=3.0);
                translate([5.0, 0, 5.0]) sphere(d=4.2);
            }
            // Compact ears
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.8, y_s * 3.2, 5.0]) sphere(d=3.0);
                    translate([-2.5, y_s * 4.6, 6.5]) sphere(d=3.2);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=7.2, h=4.0);
    }
}
module KODIAK75_Crown_SunBearCrest() { Crown_SunBearCrest(); }

// 106: Honeycomb Dipper Crown (Forest)
module Crown_HoneycombDipper() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Solid hex honeycomb base cluster
            hull() {
                for (a = [0 : 60 : 300]) {
                    rotate([0, 0, a])
                        translate([3.8, 0, 2.0])
                            cylinder(d=4.4, h=3.8, $fn=6);
                }
            }
            // Dipper central shaft anchored from Z=2.0
            translate([0, 0, 2.0]) cylinder(d=3.2, h=11.0);
            // Stacked dipper discs
            translate([0, 0, 7.5]) cylinder(d=5.6, h=1.0);
            translate([0, 0, 9.2]) cylinder(d=6.8, h=1.0);
            translate([0, 0, 10.8]) cylinder(d=5.4, h=1.0);
            // Apex honey droplet overlapping shaft
            hull() {
                translate([0, 0, 12.0]) sphere(d=3.2);
                translate([0, 0, 14.2]) sphere(d=1.2);
            }
        }
        top_crown_base_cuts(2.6);
        // Honeycomb cell dimples on top
        for (a = [0 : 60 : 300]) {
            rotate([0, 0, a])
                translate([3.8, 0, 4.5])
                    cylinder(d=2.4, h=1.8, $fn=6);
        }
        translate([0, 0, 2.6]) cylinder(d=5.4, h=2.4);
    }
}
module KODIAK75_Crown_HoneycombDipper() { Crown_HoneycombDipper(); }

// 107: Pinecone Crest (Forest)
module Crown_PineconeCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Core spindle
            cylinder(d1=11.0, d2=4.2, h=12.0);
            // 3 tiers of 6 scales anchored into core spindle
            for (tier = [0 : 2]) {
                for (i = [0 : 5]) {
                    rotate([0, 0, tier * 30 + i * 60])
                        hull() {
                            translate([2.0, 0, 3.2 + tier * 2.6]) sphere(d=2.4);
                            translate([5.0 - tier * 0.8, 0, 4.0 + tier * 2.6])
                                rotate([0, 35, 0])
                                    cube([3.0, 2.6, 1.2], center=true);
                        }
                }
            }
            // Apical rosette overlapping spindle
            translate([0, 0, 11.6]) sphere(d=3.2);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.0, h=5.5);
    }
}
module KODIAK75_Crown_PineconeCrest() { Crown_PineconeCrest(); }

// 108: Antler Spikes Crown (Forest)
module Crown_AntlerSpikes() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Brow pedestal
            hull() {
                translate([0, -4.8, 2.2]) cylinder(d=3.5, h=2.0);
                translate([0,  4.8, 2.2]) cylinder(d=3.5, h=2.0);
            }
            // Twin stag antlers
            for (y_s = [-1, 1]) {
                // Main beam
                hull() {
                    translate([0, y_s * 4.0, 3.0]) cylinder(d=3.0, h=1.5);
                    translate([-1.2, y_s * 6.5, 8.5]) cylinder(d=2.2, h=1.5);
                }
                hull() {
                    translate([-1.2, y_s * 6.5, 8.5]) cylinder(d=2.2, h=1.5);
                    translate([-2.5, y_s * 8.2, 14.5]) cylinder(d=1.4, h=1.5);
                }
                // Brow tine
                hull() {
                    translate([-0.5, y_s * 5.2, 5.5]) cylinder(d=2.0, h=1.0);
                    translate([2.8, y_s * 6.0, 8.2]) cylinder(d=1.2, h=1.0);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_AntlerSpikes() { Crown_AntlerSpikes(); }

// 109: Wolf Howl Crown (Wildlife)
module Crown_WolfHowl() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Howling neck and head sweeping upward
            hull() {
                translate([0, 0, 2.2]) cylinder(d=11.2, h=2.5);
                translate([1.2, 0, 7.5]) sphere(d=7.0);
            }
            hull() {
                translate([1.2, 0, 7.5]) sphere(d=6.5);
                translate([4.0, 0, 14.2]) sphere(d=3.2);
            }
            // Swept wolf ears
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.2, y_s * 3.2, 9.5]) cylinder(d=2.6, h=1.5);
                    translate([-2.8, y_s * 3.6, 13.5]) cylinder(d=1.2, h=1.5);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Side drag flutes
        for (y_s = [-1, 1]) {
            translate([0, y_s * 3.8, 6.0])
                rotate([0, 45, 0])
                    cylinder(d=2.6, h=8.0, center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.5, h=5.5);
    }
}
module KODIAK75_Crown_WolfHowl() { Crown_WolfHowl(); }

// 110: Eagle Talon Crown (Wildlife)
module Crown_EagleTalon() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Dorsal keel blade
            hull() {
                translate([-6.0, 0, 2.2]) cube([1.8, 2.2, 2.0], center=true);
                translate([ 6.0, 0, 2.2]) cube([1.8, 2.2, 2.0], center=true);
                translate([ 0.0, 0, 9.5]) cube([4.0, 1.8, 2.0], center=true);
            }
            // 3 Hooked raptor talons grasping keel
            for (x_t = [-3.5, 3.5]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_t, 0, 9.0]) sphere(d=2.6);
                        translate([x_t, y_s * 4.2, 5.0]) sphere(d=1.6);
                    }
                }
            }
            // Rear talon
            hull() {
                translate([-5.0, 0, 6.0]) sphere(d=2.4);
                translate([-7.2, 0, 3.5]) sphere(d=1.2);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 5.5]) rotate([90, 0, 0]) cylinder(d=3.8, h=5.0, center=true);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_EagleTalon() { Crown_EagleTalon(); }

// 111: Owl Crest (Wildlife)
module Crown_OwlCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Brow facial block
            hull() {
                translate([1.0, 0, 5.0]) cube([3.8, 12.0, 5.0], center=true);
                translate([0.0, 0, 2.2]) cylinder(d=11.0, h=2.5);
            }
            // Pointed feather ear tufts
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-0.5, y_s * 4.8, 7.0]) cylinder(d=3.0, h=1.5);
                    translate([-1.2, y_s * 5.2, 13.0]) cylinder(d=1.0, h=1.5);
                }
            }
            // Beak
            hull() {
                translate([2.5, 0, 5.2]) cube([1.8, 1.8, 1.0], center=true);
                translate([4.5, 0, 3.4]) sphere(d=1.0);
            }
        }
        top_crown_base_cuts(2.6);
        // Dual concave eye disc scoops
        for (y_s = [-1, 1]) {
            translate([2.8, y_s * 3.0, 5.8]) sphere(d=5.8);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.8);
    }
}
module KODIAK75_Crown_OwlCrest() { Crown_OwlCrest(); }

// 112: Badger Mohawk Crown (Wildlife)
module Crown_BadgerMohawk() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Center mohawk spine
            hull() {
                translate([-6.0, 0, 2.2]) cube([2.0, 3.2, 2.0], center=true);
                translate([ 6.0, 0, 2.2]) cube([2.0, 3.2, 2.0], center=true);
                translate([ 0.0, 0, 11.5]) cube([8.0, 2.4, 2.0], center=true);
            }
            // 5 Graduated chisel teeth
            for (i = [0 : 4]) {
                h_tooth = [7.5, 10.5, 12.8, 11.0, 8.5][i];
                x_pos   = -5.0 + i * 2.5;
                hull() {
                    translate([x_pos, 0, 2.5]) cube([1.8, 2.8, 1.0], center=true);
                    translate([x_pos + 0.6, 0, h_tooth]) cube([1.4, 1.6, 1.0], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Side stripe channels
        for (y_s = [-1, 1]) {
            translate([0, y_s * 2.2, 4.0]) cube([14.0, 1.2, 3.0], center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.8);
    }
}
module KODIAK75_Crown_BadgerMohawk() { Crown_BadgerMohawk(); }

// 113: Salmon Fin Crown (River)
module Crown_SalmonFin() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Streamlined fish keel
            hull() {
                translate([-6.0, 0, 2.2]) sphere(d=3.2);
                translate([ 6.0, 0, 2.2]) sphere(d=3.8);
            }
            // Cambered dorsal fin sweeping back
            hull() {
                translate([4.0, 0, 2.2]) cube([2.5, 2.2, 1.5], center=true);
                translate([-1.0, 0, 12.5]) cube([2.5, 1.4, 1.5], center=true);
                translate([-5.5, 0, 4.5]) cube([2.0, 1.4, 1.5], center=true);
            }
            // Caudal flukes at rear
            translate([-6.5, 0, 3.0]) cube([2.0, 6.0, 1.2], center=true);
        }
        top_crown_base_cuts(2.6);
        // Trailing edge notch scallop
        translate([-4.5, 0, 7.5]) rotate([90, 0, 0]) cylinder(d=4.8, h=4.0, center=true);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_SalmonFin() { Crown_SalmonFin(); }

// 114: Forest Canopy Crown (Forest)
module Crown_ForestCanopy() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Trunk pillar
            cylinder(d1=8.0, d2=5.0, h=9.8);
            // 3-tier umbrella leaves anchored directly to central trunk
            for (tier = [0 : 2]) {
                for (a = [0 : 90 : 270]) {
                    rotate([0, 0, a + tier * 30])
                        hull() {
                            translate([0, 0, 4.5 + tier * 2.2]) sphere(d=2.8);
                            translate([5.6 - tier * 0.6, 0, 4.4 + tier * 2.2]) sphere(d=2.0);
                        }
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=5.8, h=3.0);
    }
}
module KODIAK75_Crown_ForestCanopy() { Crown_ForestCanopy(); }

// 115: Acorn Sprout Crown (Forest)
module Crown_AcornSprout() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Acorn cupule with faceted ring
            cylinder(d1=13.5, d2=11.5, h=4.5, $fn=12);
            // Nut dome (bottom well above Z=0)
            translate([0, 0, 4.8]) sphere(d=8.8);
            // Twin oak seedling sprouts anchored into nut dome
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, 0, 6.8]) cylinder(d=2.4, h=2.0);
                    translate([1.2, y_s * 4.5, 12.8]) sphere(d=1.8);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=4.5);
    }
}
module KODIAK75_Crown_AcornSprout() { Crown_AcornSprout(); }

// 116: Maple Leaf Crown (Forest)
module Crown_MapleLeaf() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central spine mast anchored at Z=2.0
            translate([0, 0, 2.0]) cylinder(d=2.8, h=11.5);
            // 5-lobe planar maple leaf along X
            hull() {
                translate([0, 0, 2.4]) cube([5.0, 2.0, 1.6], center=true);
                translate([0, 0, 13.5]) cube([1.5, 1.2, 1.5], center=true);
                translate([ 6.0, 0, 9.0]) cube([1.8, 1.2, 1.5], center=true);
                translate([-6.0, 0, 9.0]) cube([1.8, 1.2, 1.5], center=true);
            }
            hull() {
                translate([ 4.5, 0, 5.5]) cube([1.5, 1.4, 1.0], center=true);
                translate([-4.5, 0, 5.5]) cube([1.5, 1.4, 1.0], center=true);
                translate([ 0.0, 0, 2.4]) cube([4.0, 2.0, 1.4], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.2, h=2.8);
    }
}
module KODIAK75_Crown_MapleLeaf() { Crown_MapleLeaf(); }

// 117: Mountain Ridge Crown (Alpine)
module Crown_MountainRidge() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Massif base
            hull() {
                translate([-5.5, 0, 2.2]) cube([3.0, 4.5, 2.0], center=true);
                translate([ 5.5, 0, 2.2]) cube([3.0, 4.5, 2.0], center=true);
                translate([ 0.0, 0, 6.0]) cube([8.0, 2.8, 2.0], center=true);
            }
            // Primary summit
            translate([2.5, 0, 5.0]) cylinder(d1=5.5, d2=0.8, h=8.0, $fn=3);
            // Secondary sub-peak
            translate([-4.0, 0, 5.0]) cylinder(d1=4.8, d2=0.8, h=5.5, $fn=3);
            // Connecting arête knife-edge
            hull() {
                translate([ 2.5, 0, 10.0]) cube([1.0, 1.2, 1.0], center=true);
                translate([-4.0, 0,  8.0]) cube([1.0, 1.2, 1.0], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 3.8]) rotate([90, 0, 0]) cylinder(d=3.8, h=7.0, center=true);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_MountainRidge() { Crown_MountainRidge(); }

// 118: River Crest Crown (River)
module Crown_RiverCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Wave ramp
            hull() {
                translate([-5.5, 0, 2.2]) cylinder(d=5.0, h=2.0);
                translate([ 1.5, 0, 7.0]) cylinder(d=6.0, h=2.0);
                translate([ 3.5, 0, 11.0]) cylinder(d=3.5, h=1.5);
            }
            // Curling barrel lip
            translate([3.5, 0, 11.0])
                rotate([90, 0, 0])
                    cylinder(r=2.8, h=7.0, center=true);
        }
        top_crown_base_cuts(2.6);
        // Barrel undercut
        translate([2.2, 0, 8.8])
            rotate([90, 0, 0])
                cylinder(d=4.2, h=8.0, center=true);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_RiverCrest() { Crown_RiverCrest(); }

// 119: Berry Bunch Crown (Forest)
module Crown_BerryBunch() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Calyx leaves
            for (a = [0, 120, 240]) {
                rotate([0, 0, a])
                    translate([5.0, 0, 2.2])
                        cylinder(d=5.2, h=1.4);
            }
            // 3 Huckleberry spheres
            for (a = [0, 120, 240]) {
                rotate([0, 0, a])
                    translate([3.2, 0, 5.2])
                        sphere(d=5.6);
            }
            // Center joining stem
            translate([0, 0, 5.5]) cylinder(d1=3.5, d2=2.0, h=4.5);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 5.2]) sphere(d=3.8);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_BerryBunch() { Crown_BerryBunch(); }

// 120: Hibernate Helmet Crown (Wildlife)
module Crown_HibernateHelmet() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Armored dome shell
            hull() {
                cylinder(d=14.2, h=2.5);
                translate([0, 0, 6.0]) sphere(d=11.0);
            }
            // Low-profile ear blisters anchored into dome
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.5, y_s * 3.8, 6.2]) sphere(d=3.6);
                    translate([-2.0, y_s * 5.0, 7.2]) sphere(d=4.0);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Slumbering eye slits
        for (y_s = [-1, 1]) {
            translate([4.5, y_s * 2.8, 5.5])
                rotate([0, 30, 0])
                    cube([1.0, 3.2, 1.2], center=true);
        }
        // Cranial crumple void
        translate([0, 0, 2.6]) cylinder(d1=9.0, d2=6.8, h=5.5);
    }
}
module KODIAK75_Crown_HibernateHelmet() { Crown_HibernateHelmet(); }

// 121: Cyber Bear Visor Crown (Cyber)
module Crown_CyberBearVisor() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Low-poly cyber skull
            hull() {
                cylinder(d=13.5, h=3.0, $fn=6);
                translate([1.0, 0, 6.0]) cylinder(d=10.5, h=3.0, $fn=6);
            }
            // Hex ear sensor pods
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.5, y_s * 3.5, 6.5]) cylinder(d=3.2, h=2.5, center=true, $fn=6);
                    translate([-2.0, y_s * 5.2, 7.0]) cylinder(d=3.6, h=3.5, center=true, $fn=6);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // HUD visor slit
        translate([4.5, 0, 5.8]) cube([2.2, 10.5, 1.6], center=true);
        // Weight hollow
        translate([0, 0, 2.6]) cylinder(d=7.8, h=5.2);
    }
}
module KODIAK75_Crown_CyberBearVisor() { Crown_CyberBearVisor(); }

// 122: Mecha Mohawk Crown (Cyber)
module Crown_MechaMohawk() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Chassis spine
            translate([0, 0, 2.2]) cube([13.0, 3.2, 2.0], center=true);
            // 6 Stepped heat-sink fins
            for (i = [0 : 5]) {
                h_fin = [7.0, 9.5, 12.0, 13.5, 11.5, 8.5][i];
                x_pos = -5.5 + i * 2.2;
                translate([x_pos, 0, 2.0 + (h_fin - 2.0) / 2])
                    cube([1.0, 6.5, h_fin - 2.0], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_MechaMohawk() { Crown_MechaMohawk(); }

// 123: Battle Helm Crown (Battle)
module Crown_BattleHelm() {
    difference() {
        union() {
            top_crown_base_solid(15.8, 2.6);
            // Helmet dome (kept above Z=0)
            hull() {
                cylinder(d=14.0, h=2.6);
                translate([0, 0, 5.8]) sphere(d=11.2);
            }
            // Rivet band
            translate([0, 0, 3.8]) cylinder(d=14.0, h=1.2);
            // Curved Viking horns anchored into dome
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.8, 4.0]) cylinder(d=3.6, h=1.5);
                    translate([0, y_s * 8.2, 7.5]) cylinder(d=2.6, h=1.5);
                }
                hull() {
                    translate([0, y_s * 8.2, 7.5]) cylinder(d=2.6, h=1.5);
                    translate([1.2, y_s * 10.2, 12.2]) cylinder(d=1.4, h=1.5);
                }
            }
            // Nasal armor bar anchored into dome
            hull() {
                translate([3.5, 0, 4.2]) cube([2.0, 2.0, 3.5], center=true);
                translate([5.2, 0, 4.2]) cube([1.6, 2.0, 3.8], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=9.6, h=5.8);
    }
}
module KODIAK75_Crown_BattleHelm() { Crown_BattleHelm(); }

// 124: Titanium Crest Crown (Battle)
module Crown_TitaniumCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Glacis wedge
            hull() {
                translate([-5.5, 0, 2.2]) cube([2.0, 11.0, 2.0], center=true);
                translate([ 5.5, 0, 2.2]) cube([2.0,  8.0, 2.0], center=true);
                translate([ 0.0, 0, 10.5]) cube([4.0,  2.4, 2.0], center=true);
            }
            // Center strike ridge kept above Z=2.0
            translate([0, 0, 6.2]) cube([12.5, 2.2, 8.0], center=true);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=5.5);
    }
}
module KODIAK75_Crown_TitaniumCrest() { Crown_TitaniumCrest(); }

// 125: Radar Dome Crown (Sci-Fi)
module Crown_RadarDome() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.4);
            // Spherical radome
            translate([0, 0, 6.0]) sphere(d=11.8);
            // Equatorial band
            translate([0, 0, 6.0]) cylinder(d=12.4, h=1.4, center=true);
            // Antenna whip mast
            translate([0, 0, 11.0]) cylinder(d1=2.0, d2=0.8, h=5.5);
        }
        top_crown_base_cuts(2.4);
        translate([0, 0, 6.0]) sphere(d=9.2);
        translate([0, 0, 2.4]) cylinder(d=6.8, h=4.0);
    }
}
module KODIAK75_Crown_RadarDome() { Crown_RadarDome(); }

// 126: Turbo Scoop Crown (Aero)
module Crown_TurboScoop() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Teardrop cowling
            hull() {
                cylinder(d=13.0, h=2.5);
                translate([2.0, 0, 4.5]) sphere(d=7.5);
                translate([-4.0, 0, 2.5]) cube([5.0, 7.5, 2.0], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        // NACA intake tunnel
        translate([4.0, 0, 4.0])
            rotate([0, 15, 0])
                cube([6.0, 4.8, 2.6], center=true);
        // Twin exhaust louvers at aft
        for (y_s = [-1, 1]) {
            translate([-3.0, y_s * 2.2, 4.0])
                rotate([0, -25, 0])
                    cube([4.0, 1.2, 2.0], center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.0);
    }
}
module KODIAK75_Crown_TurboScoop() { Crown_TurboScoop(); }

// 127: Stealth Fin Crown (Stealth)
module Crown_StealthFin() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Multi-faceted diamond stealth wedge
            hull() {
                translate([-6.0, 0, 2.2]) cube([1.5, 6.0, 1.5], center=true);
                translate([ 6.0, 0, 2.2]) cube([1.5, 4.0, 1.5], center=true);
                translate([-1.0, 0, 13.0]) cube([3.0, 1.4, 1.5], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        // Side relief facets
        for (y_s = [-1, 1]) {
            translate([0, y_s * 3.5, 6.0])
                rotate([0, 0, y_s * 25])
                    cube([12.0, 2.0, 7.0], center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_StealthFin() { Crown_StealthFin(); }

// 128: Plasma Horn Crown (Sci-Fi)
module Crown_PlasmaHorn() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Forward-raked conical spire
            hull() {
                translate([0, 0, 2.0]) cylinder(d=5.8, h=2.0);
                translate([2.5, 0, 15.0]) sphere(d=2.2);
            }
            // 3 Accelerator coil rings overlapping spire
            translate([0.5, 0, 6.0]) cylinder(d=8.5, h=1.0);
            translate([1.2, 0, 9.5]) cylinder(d=7.0, h=1.0);
            translate([1.8, 0, 12.5]) cylinder(d=5.4, h=1.0);
            translate([2.5, 0, 15.0]) sphere(d=2.6);
        }
        top_crown_base_cuts(2.6);
    }
}
module KODIAK75_Crown_PlasmaHorn() { Crown_PlasmaHorn(); }

// 129: Vortex Cannon Crown (Aero)
module Crown_VortexCannon() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Flared cannon barrel angled forward
            translate([0, 0, 2.2])
                rotate([0, 12, 0])
                    cylinder(d1=9.5, d2=12.0, h=9.5);
            // Bell muzzle ring
            translate([1.8, 0, 11.2])
                rotate([0, 12, 0])
                    cylinder(d=12.8, h=1.6);
        }
        top_crown_base_cuts(2.6);
        // Main bore cavity
        translate([0, 0, 2.0])
            rotate([0, 12, 0])
                cylinder(d=6.8, h=12.0);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_VortexCannon() { Crown_VortexCannon(); }

// 130: Sonic Dish Crown (Sci-Fi)
module Crown_SonicDish() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central pedestal mast connecting base to dish
            translate([0, 0, 2.0]) cylinder(d=5.2, h=6.5);
            // Parabolic dish bowl angled forward
            translate([0, 0, 7.2])
                rotate([0, -20, 0])
                    cylinder(d1=10.5, d2=14.8, h=3.6);
            // Transducer center needle
            translate([0, 0, 6.2])
                rotate([0, -20, 0])
                    cylinder(d1=3.0, d2=1.0, h=5.5);
        }
        top_crown_base_cuts(2.6);
        // Dish interior annular scoop leaving center needle intact
        difference() {
            translate([0, 0, 8.2])
                rotate([0, -20, 0])
                    cylinder(d1=8.6, d2=12.8, h=3.0);
            translate([0, 0, 6.0])
                rotate([0, -20, 0])
                    cylinder(d=3.2, h=6.0);
        }
    }
}
module KODIAK75_Crown_SonicDish() { Crown_SonicDish(); }

// 131: EMP Spike Crown (Sci-Fi)
module Crown_EMPSpike() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Vertical discharge rod anchored at Z=2.0
            translate([0, 0, 2.0]) cylinder(d=3.2, h=13.5);
            // 4 Dielectric insulator discs
            translate([0, 0, 5.0]) cylinder(d=10.0, h=1.0);
            translate([0, 0, 7.8]) cylinder(d=8.6, h=1.0);
            translate([0, 0, 10.6]) cylinder(d=7.2, h=1.0);
            translate([0, 0, 13.4]) cylinder(d=5.8, h=1.0);
            // Coronal cross at tip overlapping rod
            translate([0, 0, 15.2]) {
                cube([4.2, 1.4, 1.4], center=true);
                cube([1.4, 4.2, 1.4], center=true);
            }
        }
        top_crown_base_cuts(2.6);
    }
}
module KODIAK75_Crown_EMPSpike() { Crown_EMPSpike(); }

// 132: Shield Crest Crown (Battle)
module Crown_ShieldCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Heater shield plate curved along Y
            hull() {
                translate([1.5, 0, 4.0]) cube([2.0, 11.5, 2.0], center=true);
                translate([1.5, 0, 12.5]) cube([2.0, 10.0, 2.0], center=true);
                translate([1.5, 0, 2.2]) cube([2.0,  3.0, 1.0], center=true);
            }
            // Embossed bear paw on front
            translate([2.6, 0, 8.5]) {
                cylinder(d=3.6, h=0.8);
                for (a = [-30, -10, 10, 30]) {
                    rotate([0, 0, a]) translate([0, 2.8, 0]) cylinder(d=1.2, h=0.8);
                }
            }
            // A-frame backing truss
            hull() {
                translate([-4.5, 0, 2.2]) cylinder(d=2.8, h=1.5);
                translate([ 0.5, 0, 9.5]) cylinder(d=2.0, h=1.5);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_ShieldCrest() { Crown_ShieldCrest(); }

// 133: Afterburner Cowl Crown (Aero)
module Crown_AfterburnerCowl() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Cowl cylinder
            cylinder(d=13.0, h=9.0);
            // Flame holder cone
            translate([0, 0, 2.2]) cylinder(d1=5.0, d2=1.2, h=6.5);
        }
        top_crown_base_cuts(2.6);
        // Annular nozzle cutout
        translate([0, 0, 3.5]) cylinder(d=9.8, h=6.0);
        // 8 Sawtooth chevrons
        for (a = [0 : 45 : 315]) {
            rotate([0, 0, a])
                translate([5.6, 0, 9.0])
                    rotate([0, 45, 0])
                        cube([2.2, 2.2, 2.2], center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_AfterburnerCowl() { Crown_AfterburnerCowl(); }

// 134: Heavy Bumper Crown (Battle)
module Crown_HeavyBumper() {
    difference() {
        union() {
            top_crown_base_solid(16.0, 2.8);
            // Curved bull bar arc across front
            intersection() {
                translate([0, 0, 4.0])
                    rotate_extrude(angle=120)
                        translate([7.2, 0, 0])
                            circle(d=4.0);
                cylinder(d=20.0, h=10.0);
            }
            // Push bumper blocks
            for (y_s = [-1, 1]) {
                translate([4.8, y_s * 4.5, 4.2])
                    cube([3.0, 2.8, 6.0], center=true);
            }
        }
        top_crown_base_cuts(2.8);
        translate([0, 0, 2.8]) cylinder(d=8.2, h=4.5);
    }
}
module KODIAK75_Crown_HeavyBumper() { Crown_HeavyBumper(); }

// 135: Energy Crest Crown (Sci-Fi)
module Crown_EnergyCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Center energy blade
            hull() {
                translate([0, 0, 2.2]) cube([10.0, 1.8, 2.0], center=true);
                translate([0, 0, 14.0]) cube([ 3.0, 1.4, 2.0], center=true);
            }
            // Flanking outrigger blades
            for (y_s = [-1, 1]) {
                rotate([0, y_s * 18, 0])
                    hull() {
                        translate([0, y_s * 4.0, 2.2]) cube([7.0, 1.5, 2.0], center=true);
                        translate([0, y_s * 4.0, 10.5]) cube([2.5, 1.2, 2.0], center=true);
                    }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_EnergyCrest() { Crown_EnergyCrest(); }

// 136: Nitro Fin Crown (Aero)
module Crown_NitroFin() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // High-aspect vertical stabilizer
            hull() {
                translate([-5.5, 0, 2.2]) cube([2.0, 2.2, 2.0], center=true);
                translate([ 5.5, 0, 2.2]) cube([2.0, 2.2, 2.0], center=true);
                translate([-2.5, 0, 15.5]) cube([3.2, 1.2, 1.5], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        // 3 Speed cutouts
        for (i = [0 : 2]) {
            translate([-1.5 + i * 2.5, 0, 6.0 + i * 3.2])
                rotate([90, 0, 0])
                    cylinder(d=2.6, h=3.0, center=true, $fn=3);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_NitroFin() { Crown_NitroFin(); }

// 137: Carbon Fin Crown (Aero)
module Crown_CarbonFin() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Twin vertical stabilizers canted outward at 20 deg
            for (y_s = [-1, 1]) {
                translate([0, y_s * 4.5, 2.2])
                    rotate([y_s * 20, 0, 0])
                        hull() {
                            translate([-4.5, 0, 0]) cube([2.0, 1.5, 2.0], center=true);
                            translate([ 4.5, 0, 0]) cube([2.0, 1.5, 2.0], center=true);
                            translate([ 1.5, 0, 10.5]) cube([3.5, 1.2, 1.5], center=true);
                        }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_CarbonFin() { Crown_CarbonFin(); }

// 138: Cyber Claws Crown (Cyber)
module Crown_CyberClaws() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Knuckle hub spanning full width
            translate([0, 0, 2.4]) cube([9.0, 9.2, 2.2], center=true);
            // Center claw blade
            hull() {
                translate([1.5, 0, 2.4]) cube([2.5, 1.8, 1.5], center=true);
                translate([-2.5, 0, 13.5]) cube([1.5, 1.2, 1.2], center=true);
            }
            // Twin outer claws anchored into knuckle hub
            for (y_s = [-1, 1]) {
                hull() {
                    translate([1.5, y_s * 3.5, 2.4]) cube([2.2, 1.6, 1.5], center=true);
                    translate([-2.0, y_s * 4.0, 11.0]) cube([1.4, 1.1, 1.2], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
    }
}
module KODIAK75_Crown_CyberClaws() { Crown_CyberClaws(); }

// 139: Neon Crest Crown (Cyber)
module Crown_NeonCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Synthwave dorsal blade
            hull() {
                translate([-6.0, 0, 2.2]) cube([1.8, 3.2, 2.0], center=true);
                translate([ 6.0, 0, 2.2]) cube([1.8, 3.2, 2.0], center=true);
                translate([-1.0, 0, 12.0]) cube([3.2, 2.0, 1.5], center=true);
            }
            // Optical light guide base
            translate([0, 0, 2.2]) cylinder(d=5.0, h=2.0);
        }
        top_crown_base_cuts(2.6);
        // Dual light guide grooves along flanks
        for (y_s = [-1, 1]) {
            translate([0, y_s * 1.5, 7.0])
                rotate([0, 45, 0])
                    cube([12.0, 1.0, 1.2], center=true);
        }
        translate([0, 0, 2.6]) cylinder(d=6.8, h=3.5);
    }
}
module KODIAK75_Crown_NeonCrest() { Crown_NeonCrest(); }

// 140: Orbital Beacon Crown (Sci-Fi)
module Crown_OrbitalBeacon() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.4);
            // Central optical lens dome anchored to base
            translate([0, 0, 3.8]) sphere(d=6.8);
            // 4 Roll-cage pillars anchored at radius 4.4mm into base & top ring
            for (a = [0, 90, 180, 270]) {
                rotate([0, 0, a])
                    translate([4.4, 0, 1.8])
                        cylinder(d=2.2, h=9.2);
            }
            // Top protective bumper ring overlapping pillars
            translate([0, 0, 10.2])
                difference() {
                    cylinder(d=11.0, h=1.6);
                    translate([0, 0, -0.1]) cylinder(d=6.2, h=1.8);
                }
        }
        top_crown_base_cuts(2.4);
        translate([0, 0, 2.4]) cylinder(d=5.6, h=2.4);
    }
}
module KODIAK75_Crown_OrbitalBeacon() { Crown_OrbitalBeacon(); }


// ============================================================================
// ZONES 2 & 3: CHEEK SACRIFICIAL POD PAIRS (PART_ID = 201..235)
// Printed in pairs side-by-side at Y = -16.0mm (Left) and Y = +16.0mm (Right)
// ============================================================================

// 201: Bear Paws Cheek Pair (Wildlife)
module single_bear_paws(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Main palm pad
            hull() {
                translate([0, is_right * 4.2, 0]) cylinder(d=8.0, h=2.2);
                translate([0, is_right * 7.2, 0]) cylinder(d=6.8, h=2.0);
            }
            // 4 Radial toe cushions with micro-claws anchored to palm pad
            for (a = [-36, -12, 12, 36]) {
                hull() {
                    translate([5.0 * sin(a), is_right * (4.2 + 5.0 * cos(a)), 0])
                        cylinder(d=2.8, h=1.8);
                    translate([8.2 * sin(a), is_right * (4.2 + 8.2 * cos(a)), 0])
                        cylinder(d1=3.0, d2=2.4, h=2.0);
                    translate([9.8 * sin(a), is_right * (4.2 + 9.8 * cos(a)), 0])
                        cylinder(d1=1.6, d2=1.0, h=1.3);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 5.5, -0.1]) cylinder(d=4.4, h=1.4);
    }
}
module KODIAK75_Cheek_BearPaws() {
    translate([0, -16.0, 0]) single_bear_paws(-1);
    translate([0,  16.0, 0]) single_bear_paws( 1);
}
module Cheek_BearPaws() { KODIAK75_Cheek_BearPaws(); }

// 202: Cub Ears Cheek Pair (Wildlife)
module single_cub_ears(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Rounded ear shell with rim bead fused into hull
            hull() {
                translate([-3.8, is_right * 3.0, 0]) cylinder(d=3.8, h=2.0);
                translate([ 3.8, is_right * 3.0, 0]) cylinder(d=3.8, h=2.0);
                translate([ 0.0, is_right * 9.5, 0]) cylinder(d1=5.4, d2=4.6, h=3.2);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 7.2, 1.2])
            cylinder(d1=2.6, d2=3.6, h=2.8);
    }
}
module KODIAK75_Cheek_CubEars() {
    translate([0, -16.0, 0]) single_cub_ears(-1);
    translate([0,  16.0, 0]) single_cub_ears( 1);
}
module Cheek_CubEars() { KODIAK75_Cheek_CubEars(); }

// 203: Grizzly Whiskers Cheek Pair (Wildlife)
module single_grizzly_whiskers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 3.5, 0]) cylinder(d=6.2, h=2.2);
            // 3 Swept whisker antennae flat on Z=0
            for (a = [-18, 0, 18]) {
                rotate([0, 0, is_right * a]) {
                    hull() {
                        translate([0, is_right * 3.5, 0]) cylinder(d=2.4, h=2.0);
                        translate([0, is_right * 9.0, 0]) cylinder(d=1.8, h=1.6);
                    }
                    hull() {
                        translate([0, is_right * 9.0, 0]) cylinder(d=1.8, h=1.6);
                        translate([0, is_right * 13.5, 0]) cylinder(d=2.0, h=1.4);
                    }
                }
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_GrizzlyWhiskers() {
    translate([0, -16.0, 0]) single_grizzly_whiskers(-1);
    translate([0,  16.0, 0]) single_grizzly_whiskers( 1);
}
module Cheek_GrizzlyWhiskers() { KODIAK75_Cheek_GrizzlyWhiskers(); }

// 204: Salmon Skiffs Cheek Pair (River)
module single_salmon_skiffs(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Streamlined fish fuselage grounded at Z=0
            hull() {
                translate([ 7.5, is_right * 5.2, 0]) cylinder(d=2.6, h=2.2);
                translate([ 0.0, is_right * 6.2, 0]) cylinder(d=6.2, h=2.6);
                translate([-7.5, is_right * 5.5, 0]) cylinder(d=3.0, h=2.2);
            }
            // Vertical caudal tail fluke grounded at Z=0
            hull() {
                translate([-7.5, is_right * 5.5, 0]) cylinder(d=2.6, h=2.2);
                translate([-8.8, is_right * 5.5, 0]) cylinder(d=1.8, h=3.8);
            }
            // Dorsal ridge
            translate([0, is_right * 6.2, 2.4]) cube([8.0, 1.2, 1.2], center=true);
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 6.2, -0.1]) cylinder(d=4.4, h=1.6);
    }
}
module KODIAK75_Cheek_SalmonSkiffs() {
    translate([0, -16.0, 0]) single_salmon_skiffs(-1);
    translate([0,  16.0, 0]) single_salmon_skiffs( 1);
}
module Cheek_SalmonSkiffs() { KODIAK75_Cheek_SalmonSkiffs(); }

// 205: Pine Needles Cheek Pair (Forest)
module single_pine_needles(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 3.0, 0]) cylinder(d=5.6, h=2.2);
            // 3 Needle spines flat on Z=0
            for (a = [-22, 0, 22]) {
                rotate([0, 0, is_right * a]) {
                    hull() {
                        translate([0, is_right * 3.0, 0]) cylinder(d=2.2, h=2.0);
                        translate([0, is_right * 13.0, 0]) cylinder(d=1.8, h=1.4);
                    }
                }
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_PineNeedles() {
    translate([0, -16.0, 0]) single_pine_needles(-1);
    translate([0,  16.0, 0]) single_pine_needles( 1);
}
module Cheek_PineNeedles() { KODIAK75_Cheek_PineNeedles(); }

// 206: Forest Fangs Cheek Pair (Wildlife)
module single_forest_fangs(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Fang anchor bridge
            hull() {
                translate([-5.5, 0, 0]) cylinder(d=4.0, h=2.0);
                translate([ 5.5, 0, 0]) cylinder(d=4.0, h=2.0);
                translate([ 0.0, is_right * 3.8, 0]) cylinder(d=5.6, h=2.2);
            }
            // Dual curving fangs flat at Z=0
            hull() {
                translate([3.5, is_right * 3.5, 0]) cylinder(d=3.2, h=2.4);
                translate([7.5, is_right * 8.5, 0]) cylinder(d1=1.8, d2=1.2, h=1.6);
            }
            hull() {
                translate([-3.5, is_right * 3.5, 0]) cylinder(d=3.0, h=2.4);
                translate([-6.5, is_right * 7.5, 0]) cylinder(d1=1.8, d2=1.2, h=1.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 4.8, -0.1]) cylinder(d=3.6, h=1.5);
    }
}
module KODIAK75_Cheek_ForestFangs() {
    translate([0, -16.0, 0]) single_forest_fangs(-1);
    translate([0,  16.0, 0]) single_forest_fangs( 1);
}
module Cheek_ForestFangs() { KODIAK75_Cheek_ForestFangs(); }

// 207: Acorn Shells Cheek Pair (Forest)
module single_acorn_shells(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Cupule collar & nut body blister grounded at Z=0
            hull() {
                translate([0, is_right * 4.2, 0]) cylinder(d=7.5, h=2.2, $fn=12);
                translate([0, is_right * 8.6, 0]) cylinder(d1=5.8, d2=4.2, h=2.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 6.5, -0.1]) cylinder(d=4.4, h=1.6);
    }
}
module KODIAK75_Cheek_AcornShells() {
    translate([0, -16.0, 0]) single_acorn_shells(-1);
    translate([0,  16.0, 0]) single_acorn_shells( 1);
}
module Cheek_AcornShells() { KODIAK75_Cheek_AcornShells(); }

// 208: Honey Spatulas Cheek Pair (Forest)
module single_honey_spatulas(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 5.2, 1.0]) cube([3.4, 4.8, 2.0], center=true);
            translate([0, is_right * 10.2, 0]) cylinder(d1=8.8, d2=7.8, h=2.2);
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 10.2, 0.8]) cylinder(d=5.8, h=2.0);
    }
}
module KODIAK75_Cheek_HoneySpatulas() {
    translate([0, -16.0, 0]) single_honey_spatulas(-1);
    translate([0,  16.0, 0]) single_honey_spatulas( 1);
}
module Cheek_HoneySpatulas() { KODIAK75_Cheek_HoneySpatulas(); }

// 209: Beaver Tails Cheek Pair (River)
module single_beaver_tails(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-5.5, 0, 0]) cylinder(d=3.6, h=1.8);
                translate([ 5.5, 0, 0]) cylinder(d=3.6, h=1.8);
                translate([-4.2, is_right * 9.5, 0]) cylinder(d=3.8, h=1.5);
                translate([ 4.2, is_right * 9.5, 0]) cylinder(d=3.8, h=1.5);
            }
        }
        cheek_hub_cuts(2.2);
        // Cross-hatch grooves
        for (x_g = [-2.8, 0, 2.8]) {
            translate([x_g, is_right * 6.2, 1.5])
                rotate([0, 0, is_right * 45])
                    cube([0.8, 6.5, 0.8], center=true);
        }
    }
}
module KODIAK75_Cheek_BeaverTails() {
    translate([0, -16.0, 0]) single_beaver_tails(-1);
    translate([0,  16.0, 0]) single_beaver_tails( 1);
}
module Cheek_BeaverTails() { KODIAK75_Cheek_BeaverTails(); }

// 210: Feather Wings Cheek Pair (Wildlife)
module single_feather_wings(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // 4 Staggered covert feathers with overlapping roots
            for (i = [0 : 3]) {
                l_feather = [13.0, 15.5, 14.0, 11.5][i];
                x_off     = -4.5 + i * 3.0;
                hull() {
                    translate([x_off, 0, 0]) cylinder(d=3.6, h=2.0);
                    translate([x_off - 1.5, is_right * l_feather, 0]) cylinder(d=2.0, h=1.4);
                }
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_FeatherWings() {
    translate([0, -16.0, 0]) single_feather_wings(-1);
    translate([0,  16.0, 0]) single_feather_wings( 1);
}
module Cheek_FeatherWings() { KODIAK75_Cheek_FeatherWings(); }

// 211: Claw Shields Cheek Pair (Wildlife)
module single_claw_shields(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            translate([0, is_right * 3.5, 1.0]) cube([15.0, 6.5, 2.0], center=true);
            // 3 Arched claws
            for (x_c = [-4.5, 0, 4.5]) {
                hull() {
                    translate([x_c, is_right * 4.0, 1.0]) cylinder(d=3.2, h=1.8);
                    translate([x_c - 1.5, is_right * 10.5, 0.5]) cylinder(d=1.4, h=1.2);
                }
            }
        }
        cheek_hub_cuts(2.4);
        // Impact compliance grooves
        for (x_g = [-2.2, 2.2]) {
            translate([x_g, is_right * 5.5, 1.2]) cube([1.0, 5.0, 2.0], center=true);
        }
    }
}
module KODIAK75_Cheek_ClawShields() {
    translate([0, -16.0, 0]) single_claw_shields(-1);
    translate([0,  16.0, 0]) single_claw_shields( 1);
}
module Cheek_ClawShields() { KODIAK75_Cheek_ClawShields(); }

// 212: Owl Feathers Cheek Pair (Wildlife)
module single_owl_feathers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 5.2, 1.0]) cube([14.0, 10.0, 1.8], center=true);
            // Leading-edge serrations
            for (i = [0 : 5]) {
                x_s = -5.0 + i * 2.0;
                translate([x_s, is_right * 10.2, 1.0])
                    cylinder(d=1.8, h=1.8, center=true, $fn=3);
            }
        }
        cheek_hub_cuts(2.2);
        // Trailing weight flutes
        for (x_f = [-4.0, 0, 4.0]) {
            translate([x_f, is_right * 2.0, -0.1]) cylinder(d=3.0, h=1.6);
        }
    }
}
module KODIAK75_Cheek_OwlFeathers() {
    translate([0, -16.0, 0]) single_owl_feathers(-1);
    translate([0,  16.0, 0]) single_owl_feathers( 1);
}
module Cheek_OwlFeathers() { KODIAK75_Cheek_OwlFeathers(); }

// 213: Moss Banks Cheek Pair (Forest)
module single_moss_banks(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // 5 Pillowed mounds
            translate([ 0.0, is_right * 6.0, 0]) cylinder(d=6.6, h=2.4);
            translate([-5.0, is_right * 4.5, 0]) cylinder(d=5.2, h=2.0);
            translate([ 5.0, is_right * 4.5, 0]) cylinder(d=5.2, h=2.0);
            translate([-3.5, is_right * 8.2, 0]) cylinder(d=4.4, h=2.0);
            translate([ 3.5, is_right * 8.2, 0]) cylinder(d=4.4, h=2.0);
        }
        cheek_hub_cuts(2.2);
        // Damping chambers
        for (x_d = [-3.5, 3.5]) {
            translate([x_d, is_right * 5.8, -0.1]) cylinder(d=3.6, h=1.8);
        }
    }
}
module KODIAK75_Cheek_MossBanks() {
    translate([0, -16.0, 0]) single_moss_banks(-1);
    translate([0,  16.0, 0]) single_moss_banks( 1);
}
module Cheek_MossBanks() { KODIAK75_Cheek_MossBanks(); }

// 214: River Skimmers Cheek Pair (River)
module single_river_skimmers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            hull() {
                translate([-7.5, 0, 0]) cylinder(d=3.8, h=2.2);
                translate([ 7.5, 0, 0]) cylinder(d=3.8, h=2.2);
                translate([ 0.0, is_right * 11.0, 0]) cylinder(d=3.0, h=1.8);
            }
        }
        cheek_hub_cuts(2.4);
        // Transom hydro-step notch
        translate([-4.0, is_right * 5.5, -0.1]) cube([3.0, 8.0, 1.2], center=true);
    }
}
module KODIAK75_Cheek_RiverSkimmers() {
    translate([0, -16.0, 0]) single_river_skimmers(-1);
    translate([0,  16.0, 0]) single_river_skimmers( 1);
}
module Cheek_RiverSkimmers() { KODIAK75_Cheek_RiverSkimmers(); }

// 215: Leaf Fins Cheek Pair (Forest)
module single_leaf_fins(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Ovate birch leaf planform
            hull() {
                translate([-4.8, 0, 0]) cylinder(d=3.0, h=2.0);
                translate([ 4.8, 0, 0]) cylinder(d=3.0, h=2.0);
                translate([ 0.0, is_right * 12.0, 0]) cylinder(d=2.4, h=1.6);
            }
            // Raised midrib
            translate([0, is_right * 6.0, 1.4]) cube([1.2, 11.0, 0.8], center=true);
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_LeafFins() {
    translate([0, -16.0, 0]) single_leaf_fins(-1);
    translate([0,  16.0, 0]) single_leaf_fins( 1);
}
module Cheek_LeafFins() { KODIAK75_Cheek_LeafFins(); }

// 216: Aero Canards Cheek Pair (Aero)
module single_aero_canards(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Forward swept delta canard flat on Z=0
            hull() {
                translate([ 5.5, is_right * 2.5, 0]) cylinder(d=2.2, h=1.6);
                translate([-5.5, is_right * 2.5, 0]) cylinder(d=2.2, h=1.6);
                translate([ 1.5, is_right * 11.5, 0]) cylinder(d=3.2, h=1.4);
            }
            // Vertical endplate wingtip fence grounded at Z=0
            hull() {
                translate([-0.5, is_right * 11.5, 0]) cylinder(d=1.4, h=3.8);
                translate([ 3.5, is_right * 11.5, 0]) cylinder(d=1.4, h=3.2);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_AeroCanards() {
    translate([0, -16.0, 0]) single_aero_canards(-1);
    translate([0,  16.0, 0]) single_aero_canards( 1);
}
module Cheek_AeroCanards() { KODIAK75_Cheek_AeroCanards(); }

// 217: Vortex Generators Cheek Pair (Aero)
module single_vortex_generators(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 3.5, 0.9]) cube([17.0, 4.0, 1.8], center=true);
            // 5 Gothic VG triangular vanes
            for (i = [0 : 4]) {
                x_v = -6.0 + i * 3.0;
                yaw = (i % 2 == 0 ? 15 : -15);
                translate([x_v, is_right * 4.2, 1.8])
                    rotate([0, 0, is_right * yaw])
                        cylinder(d=2.6, h=2.5, center=true, $fn=3);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_VortexGenerators() {
    translate([0, -16.0, 0]) single_vortex_generators(-1);
    translate([0,  16.0, 0]) single_vortex_generators( 1);
}
module Cheek_VortexGenerators() { KODIAK75_Cheek_VortexGenerators(); }

// 218: Ram Air Ducts Cheek Pair (Aero)
module single_ram_air_ducts(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Cowling shell
            hull() {
                translate([ 6.5, is_right * 4.8, 1.8]) cylinder(d=5.5, h=3.2);
                translate([-6.5, is_right * 4.8, 1.8]) cylinder(d=5.5, h=3.2);
            }
        }
        cheek_hub_cuts(2.4);
        // Tapered venturi bore
        translate([0, is_right * 4.8, 2.5])
            rotate([0, 90, 0])
                cylinder(d1=4.0, d2=3.0, h=16.0, center=true);
    }
}
module KODIAK75_Cheek_RamAirDucts() {
    translate([0, -16.0, 0]) single_ram_air_ducts(-1);
    translate([0,  16.0, 0]) single_ram_air_ducts( 1);
}
module Cheek_RamAirDucts() { KODIAK75_Cheek_RamAirDucts(); }

// 219: Winglet Deflectors Cheek Pair (Aero)
module single_winglet_deflectors(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Horizontal extension
            translate([0, is_right * 4.5, 1.0]) cube([10.0, 4.5, 2.0], center=true);
            // 75 deg upward curved winglet
            hull() {
                translate([0, is_right * 7.0, 1.0]) cube([8.0, 1.8, 2.0], center=true);
                translate([-1.5, is_right * 8.5, 7.5]) cube([4.0, 1.2, 2.0], center=true);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 4.5, -0.1]) cylinder(d=3.8, h=1.4);
    }
}
module KODIAK75_Cheek_WingletDeflectors() {
    translate([0, -16.0, 0]) single_winglet_deflectors(-1);
    translate([0,  16.0, 0]) single_winglet_deflectors( 1);
}
module Cheek_WingletDeflectors() { KODIAK75_Cheek_WingletDeflectors(); }

// 220: Combat Spoilers Cheek Pair (Aero)
module single_combat_spoilers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Dual bracing pylons anchored into hub and flat at Z=0
            for (x_p = [-4.5, 4.5]) {
                hull() {
                    translate([x_p, is_right * 1.5, 0]) cylinder(d=2.2, h=2.2);
                    translate([x_p, is_right * 4.5, 0]) cylinder(d=2.2, h=4.2);
                }
            }
            // Elevated spoiler wing anchored across pylons
            hull() {
                translate([-6.5, is_right * 4.5, 3.4]) cylinder(d=3.6, h=1.2);
                translate([ 6.5, is_right * 4.5, 2.4]) cylinder(d=3.6, h=1.2);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_CombatSpoilers() {
    translate([0, -16.0, 0]) single_combat_spoilers(-1);
    translate([0,  16.0, 0]) single_combat_spoilers( 1);
}
module Cheek_CombatSpoilers() { KODIAK75_Cheek_CombatSpoilers(); }

// 221: Shield Plates Cheek Pair (Battle)
module single_shield_plates(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Hexagonal armor slab
            hull() {
                translate([-6.5, is_right * 4.5, 0]) cylinder(d=4.0, h=2.5, $fn=6);
                translate([ 6.5, is_right * 4.5, 0]) cylinder(d=4.0, h=2.5, $fn=6);
                translate([ 0.0, is_right * 8.5, 0]) cylinder(d=4.0, h=2.5, $fn=6);
            }
            // Central spine
            translate([0, is_right * 5.0, 2.6]) cube([14.0, 1.6, 0.8], center=true);
        }
        cheek_hub_cuts(2.4);
        // Rivet dimples
        for (x_r = [-4.5, 4.5]) {
            translate([x_r, is_right * 4.5, 2.0]) cylinder(d=1.6, h=1.0);
        }
        translate([0, is_right * 5.5, -0.1]) cylinder(d=4.0, h=1.6);
    }
}
module KODIAK75_Cheek_ShieldPlates() {
    translate([0, -16.0, 0]) single_shield_plates(-1);
    translate([0,  16.0, 0]) single_shield_plates( 1);
}
module Cheek_ShieldPlates() { KODIAK75_Cheek_ShieldPlates(); }

// 222: Heat Sinks Cheek Pair (Cyber)
module single_heat_sinks(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-6.5, is_right * 3.8, 0]) cylinder(d=3.6, h=1.8);
                translate([ 6.5, is_right * 3.8, 0]) cylinder(d=3.6, h=1.8);
            }
            // 7 Transverse heatsink cooling fins clear of center magnet boss
            for (i = [0 : 6]) {
                h_fin = [2.4, 2.9, 3.3, 3.6, 3.3, 2.9, 2.4][i];
                x_pos = -6.0 + i * 2.0;
                hull() {
                    translate([x_pos, is_right * 2.8, 0]) cylinder(d=0.9, h=h_fin);
                    translate([x_pos, is_right * 7.2, 0]) cylinder(d=0.9, h=h_fin);
                }
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_HeatSinks() {
    translate([0, -16.0, 0]) single_heat_sinks(-1);
    translate([0,  16.0, 0]) single_heat_sinks( 1);
}
module Cheek_HeatSinks() { KODIAK75_Cheek_HeatSinks(); }

// 223: Strike Blades Cheek Pair (Battle)
module single_strike_blades(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-5.0, is_right * 3.5, 0]) cylinder(d=4.5, h=2.2);
                translate([ 4.0, is_right * 3.5, 0]) cylinder(d=4.5, h=2.2);
                translate([ 8.5, is_right * 7.5, 0]) cylinder(d=2.6, h=2.0);
            }
        }
        cheek_hub_cuts(2.2);
        // Leaf-spring shock slot cleanly through Z
        hull() {
            translate([-1.0, is_right * 4.2, -0.1]) cylinder(d=1.6, h=3.0);
            translate([ 3.5, is_right * 4.5, -0.1]) cylinder(d=1.6, h=3.0);
        }
    }
}
module KODIAK75_Cheek_StrikeBlades() {
    translate([0, -16.0, 0]) single_strike_blades(-1);
    translate([0,  16.0, 0]) single_strike_blades( 1);
}
module Cheek_StrikeBlades() { KODIAK75_Cheek_StrikeBlades(); }

// 224: Armor Flaps Cheek Pair (Battle)
module single_armor_flaps(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Dropped skirt flap grounded at Z=0
            hull() {
                translate([-6.5, is_right * 3.5, 0]) cylinder(d=3.6, h=2.2);
                translate([ 6.5, is_right * 3.5, 0]) cylinder(d=3.6, h=2.2);
                translate([-6.0, is_right * 8.2, 0]) cylinder(d=3.0, h=1.4);
                translate([ 6.0, is_right * 8.2, 0]) cylinder(d=3.0, h=1.4);
            }
            // 3 Faux barrel hinges on top
            for (x_h = [-4.5, 0, 4.5]) {
                hull() {
                    translate([x_h - 1.0, is_right * 4.2, 0]) cylinder(d=2.2, h=2.6);
                    translate([x_h + 1.0, is_right * 4.2, 0]) cylinder(d=2.2, h=2.6);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, is_right * 5.8, -0.1]) cylinder(d=4.2, h=1.4);
    }
}
module KODIAK75_Cheek_ArmorFlaps() {
    translate([0, -16.0, 0]) single_armor_flaps(-1);
    translate([0,  16.0, 0]) single_armor_flaps( 1);
}
module Cheek_ArmorFlaps() { KODIAK75_Cheek_ArmorFlaps(); }

// 225: Thruster Pods Cheek Pair (Sci-Fi)
module single_thruster_pods(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Flat-bottomed thruster pod nacelle
            hull() {
                translate([-6.0, is_right * 5.2, 0]) cylinder(d=4.6, h=3.5);
                translate([ 6.0, is_right * 5.2, 0]) cylinder(d=4.6, h=3.5);
            }
        }
        cheek_hub_cuts(2.2);
        // Dual bell nozzle bores well inside Z=[0.5, 2.9]
        translate([0, is_right * 5.2, 1.7])
            rotate([0, 90, 0])
                cylinder(d=2.4, h=16.0, center=true);
    }
}
module KODIAK75_Cheek_ThrusterPods() {
    translate([0, -16.0, 0]) single_thruster_pods(-1);
    translate([0,  16.0, 0]) single_thruster_pods( 1);
}
module Cheek_ThrusterPods() { KODIAK75_Cheek_ThrusterPods(); }

// 226: Air Brake Fins Cheek Pair (Aero)
module single_air_brake_fins(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Angled air-brake paddle grounded at Z=0
            hull() {
                translate([-6.5, is_right * 3.0, 0]) cylinder(d=3.0, h=1.8);
                translate([ 6.5, is_right * 3.0, 0]) cylinder(d=3.0, h=1.8);
                translate([-6.0, is_right * 8.2, 0]) cylinder(d=2.6, h=2.8);
                translate([ 6.0, is_right * 8.2, 0]) cylinder(d=2.6, h=2.8);
            }
        }
        cheek_hub_cuts(2.2);
        // 6 Perforated flow ports
        for (x_p = [-4.0, 0, 4.0]) {
            for (y_p = [4.5, 7.0]) {
                translate([x_p, is_right * y_p, -0.1])
                    cylinder(d=1.8, h=3.5);
            }
        }
    }
}
module KODIAK75_Cheek_AirBrakeFins() {
    translate([0, -16.0, 0]) single_air_brake_fins(-1);
    translate([0,  16.0, 0]) single_air_brake_fins( 1);
}
module Cheek_AirBrakeFins() { KODIAK75_Cheek_AirBrakeFins(); }

// 227: Corner Bumpers Cheek Pair (Battle)
module single_corner_bumpers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-6.0, is_right * 4.5, 0]) cylinder(d=4.6, h=2.4);
                translate([ 6.0, is_right * 4.5, 0]) cylinder(d=4.6, h=2.4);
                translate([ 0.0, is_right * 8.2, 0]) cylinder(d=5.2, h=2.4);
            }
        }
        cheek_hub_cuts(2.2);
        // Crumple chambers
        for (x_c = [-3.2, 3.2]) {
            translate([x_c, is_right * 5.8, -0.1]) cylinder(d=3.8, h=2.0);
        }
    }
}
module KODIAK75_Cheek_CornerBumpers() {
    translate([0, -16.0, 0]) single_corner_bumpers(-1);
    translate([0,  16.0, 0]) single_corner_bumpers( 1);
}
module Cheek_CornerBumpers() { KODIAK75_Cheek_CornerBumpers(); }

// 228: Interceptor Fins Cheek Pair (Aero)
module single_interceptor_fins(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // 60 deg extreme delta wing
            hull() {
                translate([ 6.0, 0, 0]) cylinder(d=2.6, h=2.0);
                translate([-8.5, 0, 0]) cylinder(d=2.6, h=2.0);
                translate([-8.5, is_right * 12.0, 0]) cylinder(d=2.0, h=1.4);
            }
        }
        cheek_hub_cuts(2.2);
        // Sawtooth trailing notches
        for (i = [0 : 2]) {
            y_n = 3.5 + i * 3.0;
            translate([-8.5, is_right * y_n, 1.0])
                cylinder(d=2.0, h=2.5, center=true, $fn=3);
        }
    }
}
module KODIAK75_Cheek_InterceptorFins() {
    translate([0, -16.0, 0]) single_interceptor_fins(-1);
    translate([0,  16.0, 0]) single_interceptor_fins( 1);
}
module Cheek_InterceptorFins() { KODIAK75_Cheek_InterceptorFins(); }

// 229: Flak Deflectors Cheek Pair (Battle)
module single_flak_deflectors(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Casemate polygon hull
            hull() {
                translate([-7.0, is_right * 3.5, 0]) cylinder(d=3.8, h=2.4, $fn=6);
                translate([ 7.0, is_right * 3.5, 0]) cylinder(d=3.8, h=2.4, $fn=6);
                translate([ 0.0, is_right * 8.5, 3.8]) cylinder(d=2.4, h=0.8, $fn=6);
            }
        }
        cheek_hub_cuts(2.4);
        translate([0, is_right * 5.0, -0.1]) cylinder(d=4.5, h=2.2, $fn=6);
    }
}
module KODIAK75_Cheek_FlakDeflectors() {
    translate([0, -16.0, 0]) single_flak_deflectors(-1);
    translate([0,  16.0, 0]) single_flak_deflectors( 1);
}
module Cheek_FlakDeflectors() { KODIAK75_Cheek_FlakDeflectors(); }

// 230: Sensor Wings Cheek Pair (Sci-Fi)
module single_sensor_wings(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Sponson winglet anchored from hub out to pitot probe
            hull() {
                translate([-5.5, is_right * 3.5, 0]) cylinder(d=3.2, h=2.0);
                translate([ 7.5, is_right * 5.5, 0]) cylinder(d=2.8, h=2.0);
            }
            // Forward pitot probe rooted at Z=0
            translate([7.5, is_right * 5.5, 0])
                cylinder(d1=2.4, d2=1.2, h=6.5);
            // Dorsal radome blister rooted on sponson
            translate([0, is_right * 4.5, 1.5]) cylinder(d1=4.2, d2=2.0, h=2.0);
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_SensorWings() {
    translate([0, -16.0, 0]) single_sensor_wings(-1);
    translate([0,  16.0, 0]) single_sensor_wings( 1);
}
module Cheek_SensorWings() { KODIAK75_Cheek_SensorWings(); }

// 231: Laser Cowls Cheek Pair (Sci-Fi)
module single_laser_cowls(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-5.5, is_right * 5.0, 0]) cylinder(d=4.4, h=3.4);
                translate([ 5.5, is_right * 5.0, 0]) cylinder(d=4.4, h=3.4);
            }
        }
        cheek_hub_cuts(2.2);
        // Emitter bore well inside Z=[0.5, 2.7]
        translate([0, is_right * 5.0, 1.6])
            rotate([0, 90, 0])
                cylinder(d=2.2, h=15.0, center=true);
    }
}
module KODIAK75_Cheek_LaserCowls() {
    translate([0, -16.0, 0]) single_laser_cowls(-1);
    translate([0,  16.0, 0]) single_laser_cowls( 1);
}
module Cheek_LaserCowls() { KODIAK75_Cheek_LaserCowls(); }

// 232: Reactive Plates Cheek Pair (Battle)
module single_reactive_plates(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            translate([0, is_right * 4.5, 1.0]) cube([17.0, 6.5, 1.8], center=true);
            // 4 ERA cassette tiles
            for (x_t = [-5.5, -1.8, 1.8, 5.5]) {
                translate([x_t, is_right * 6.0, 2.2])
                    cube([3.0, 3.2, 1.2], center=true);
            }
        }
        cheek_hub_cuts(2.4);
        // Bolt dimples
        for (x_t = [-5.5, -1.8, 1.8, 5.5]) {
            translate([x_t, is_right * 6.0, 2.6]) cylinder(d=1.0, h=0.8);
        }
    }
}
module KODIAK75_Cheek_ReactivePlates() {
    translate([0, -16.0, 0]) single_reactive_plates(-1);
    translate([0,  16.0, 0]) single_reactive_plates( 1);
}
module Cheek_ReactivePlates() { KODIAK75_Cheek_ReactivePlates(); }

// 233: Warp Nacelles Cheek Pair (Sci-Fi)
module single_warp_nacelles(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Nacelle body grounded at Z=0
            hull() {
                translate([ 6.5, is_right * 5.2, 0]) cylinder(d=4.4, h=2.8);
                translate([-6.5, is_right * 5.2, 0]) cylinder(d=3.4, h=2.2);
            }
        }
        cheek_hub_cuts(2.2);
        // Lateral plasma grille channels
        translate([0, is_right * 5.2, -0.1]) cylinder(d=3.6, h=1.5);
    }
}
module KODIAK75_Cheek_WarpNacelles() {
    translate([0, -16.0, 0]) single_warp_nacelles(-1);
    translate([0,  16.0, 0]) single_warp_nacelles( 1);
}
module Cheek_WarpNacelles() { KODIAK75_Cheek_WarpNacelles(); }

// 234: Kinetic Absorbers Cheek Pair (Battle)
module single_kinetic_absorbers(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            translate([0, is_right * 4.8, 1.2]) cube([16.5, 7.0, 2.4], center=true);
        }
        cheek_hub_cuts(2.4);
        // 5 Honeycomb cells with non-touching 0.6mm walls
        for (x_h = [-6.0, -3.0, 0, 3.0, 6.0]) {
            translate([x_h, is_right * 5.5, -0.1])
                cylinder(d=2.4, h=3.0, $fn=6);
        }
    }
}
module KODIAK75_Cheek_KineticAbsorbers() {
    translate([0, -16.0, 0]) single_kinetic_absorbers(-1);
    translate([0,  16.0, 0]) single_kinetic_absorbers( 1);
}
module Cheek_KineticAbsorbers() { KODIAK75_Cheek_KineticAbsorbers(); }

// 235: Sonic Vanes Cheek Pair (Aero)
module single_sonic_vanes(is_right = 1) {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            translate([0, is_right * 3.5, 0.9]) cube([16.5, 4.0, 1.8], center=true);
            // 4 Curved acoustic tuning vanes
            for (i = [0 : 3]) {
                x_v   = -4.5 + i * 3.0;
                pitch = 18 + i * 6;
                translate([x_v, is_right * 4.5, 1.8])
                    rotate([0, 0, is_right * pitch])
                        cube([1.0, 6.0, 3.0], center=true);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_SonicVanes() {
    translate([0, -16.0, 0]) single_sonic_vanes(-1);
    translate([0,  16.0, 0]) single_sonic_vanes( 1);
}
module Cheek_SonicVanes() { KODIAK75_Cheek_SonicVanes(); }


// ============================================================================
// ZONE 4: BELLY SKIDS (PART_ID = 301..325)
// Dual-magnet mounting at X = -18.0mm and X = +18.0mm (36.0mm spacing)
// Flat print orientation at Z = 0.00mm, unobstructed 70mm LiHV battery tunnel
// ============================================================================

// 301: Honey Pot Skid (Forest)
module KODIAK75_Belly_HoneyPotSkid() {
    skid_h = 2.4;
    difference() {
        union() {
            // Main barrel hull
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=12.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=12.0, h=skid_h);
                translate([   0.0, 0, 0]) cylinder(d=15.6, h=skid_h);
            }
            // Twin parallel landing strakes
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 5.8, 0]) cylinder(d=2.8, h=1.4);
                    translate([ 21.0, y_s * 5.8, 0]) cylinder(d=2.8, h=1.4);
                }
            }
            // Raised reinforcing bands
            for (x_band = [-10.0, 0.0, 10.0]) {
                translate([x_band, 0, 0])
                    cylinder(d=15.0, h=skid_h + 0.3);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Honey-pot center weight chamber
        hull() {
            translate([-6.5, 0, -0.1]) cylinder(d=7.5, h=skid_h + 0.2);
            translate([ 6.5, 0, -0.1]) cylinder(d=7.5, h=skid_h + 0.2);
        }
        for (x_d = [-12.0, 12.0]) {
            translate([x_d, 0, -0.1]) cylinder(d=4.6, h=skid_h + 0.2);
        }
    }
}
module Belly_HoneyPotSkid() { KODIAK75_Belly_HoneyPotSkid(); }

// 302: Bear Den Runner (Wildlife)
module KODIAK75_Belly_BearDenRunner() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=11.2, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=11.2, h=skid_h);
            }
            // Left & Right rock-hewn runner skids with faceted nodes
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-22.0, y_s * 7.2, 0]) cylinder(d=3.8, h=3.0, $fn=6);
                    translate([ 22.0, y_s * 7.2, 0]) cylinder(d=3.8, h=3.0, $fn=6);
                }
                for (x_n = [-14 : 7 : 14]) {
                    translate([x_n, y_s * 7.2, 0])
                        cylinder(d=4.4, h=3.2, $fn=6);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Hollow cave cavern underneath
        hull() {
            translate([-11.0, 0, -0.1]) cylinder(d=8.2, h=skid_h - 0.6);
            translate([ 11.0, 0, -0.1]) cylinder(d=8.2, h=skid_h - 0.6);
        }
        for (x_v = [-7.0, 0.0, 7.0]) {
            translate([x_v, 0, -0.1])
                cylinder(d=4.8, h=skid_h + 0.2);
        }
    }
}
module Belly_BearDenRunner() { KODIAK75_Belly_BearDenRunner(); }

// 303: River Pebble Sled (River)
module KODIAK75_Belly_RiverPebbleSled() {
    skid_h = 2.4;
    difference() {
        union() {
            // 3 Smooth blended pebble pads
            hull() {
                translate([-18.0, 0, 0]) cylinder(d1=12.4, d2=10.0, h=skid_h);
                translate([ -6.0, 0, 0]) cylinder(d1=14.0, d2=11.0, h=skid_h);
            }
            hull() {
                translate([ -6.0, 0, 0]) cylinder(d1=14.0, d2=11.0, h=skid_h);
                translate([  7.0, 0, 0]) cylinder(d1=13.2, d2=10.5, h=skid_h);
            }
            hull() {
                translate([  7.0, 0, 0]) cylinder(d1=13.2, d2=10.5, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d1=12.4, d2=10.0, h=skid_h);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // River stone-wash channels
        for (x_w = [-9.0, 9.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=6.2, h=skid_h + 0.2);
        }
        translate([0, 0, -0.1])
            cylinder(d=5.0, h=skid_h + 0.2);
    }
}
module Belly_RiverPebbleSled() { KODIAK75_Belly_RiverPebbleSled(); }

// 304: Pine Log Skids (Forest)
module KODIAK75_Belly_PineLogSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin parallel peeled pine log runners
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-22.0, y_s * 7.0, 0]) cylinder(d=4.6, h=2.8);
                    translate([ 22.0, y_s * 7.0, 0]) cylinder(d=4.6, h=2.8);
                }
            }
            // 3 Transverse log cross-ties
            for (x_c = [-18.0, 0.0, 18.0]) {
                translate([x_c, 0, 1.2])
                    cube([4.6, 15.0, 2.4], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_cut = [-9.0, 9.0]) {
            hull() {
                translate([x_cut - 2.5, 0, -0.1]) cylinder(d=5.2, h=skid_h + 0.2);
                translate([x_cut + 2.5, 0, -0.1]) cylinder(d=5.2, h=skid_h + 0.2);
            }
        }
    }
}
module Belly_PineLogSkids() { KODIAK75_Belly_PineLogSkids(); }

// 305: Grizzly Belly Sled (Wildlife)
module KODIAK75_Belly_GrizzlyBellySled() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            // 4 pairs of curved anatomical rib struts
            for (x_rib = [-12.0, -4.0, 4.0, 12.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_rib, 0, 0]) cylinder(d=3.4, h=skid_h);
                        translate([x_rib + 2.0, y_s * 8.2, 0]) cylinder(d=3.0, h=1.8);
                    }
                }
            }
            // Raised center sternum contact strake
            translate([0, 0, 0.6])
                cube([34.0, 2.8, 1.4], center=true);
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.0, 0.0, 8.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=5.4, h=skid_h + 0.2);
        }
    }
}
module Belly_GrizzlyBellySled() { KODIAK75_Belly_GrizzlyBellySled(); }

// 306: Fish Belly Runner (River)
module KODIAK75_Belly_FishBellyRunner() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([ 22.0, 0, 0]) cylinder(d=4.2, h=1.8);
                translate([  6.0, 0, 0]) cylinder(d=13.8, h=skid_h);
                translate([-18.0, 0, 0]) cylinder(d=10.4, h=skid_h);
                translate([-24.0, 0, 0]) cylinder(d=3.4, h=1.6);
            }
            // Swept ventral anal fin skeg at rear
            hull() {
                translate([-13.0, 0, 0]) cylinder(d=2.4, h=3.4);
                translate([-21.0, 0, 0]) cylinder(d=1.8, h=4.0);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_c = [-7.0, 5.0, 14.0]) {
            translate([x_c, 0, -0.1])
                cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_FishBellyRunner() { KODIAK75_Belly_FishBellyRunner(); }

// 307: Birch Bark Skids (Forest)
module KODIAK75_Belly_BirchBarkSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
            }
            // Twin curling birch bark sleigh runners
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.4, 0]) cylinder(d=3.4, h=1.8);
                    translate([ 18.0, y_s * 7.4, 0]) cylinder(d=3.4, h=1.8);
                }
                hull() {
                    translate([18.0, y_s * 7.4, 0]) cylinder(d=3.4, h=1.8);
                    translate([23.5, y_s * 7.4, 2.0]) cylinder(d=3.0, h=1.6);
                }
            }
            for (x_s = [-18.0, 18.0]) {
                translate([x_s, 0, 0.9])
                    cube([4.8, 15.5, 1.8], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_BirchBarkSkids() { KODIAK75_Belly_BirchBarkSkids(); }

// 308: Mud Sled (Alpine)
module KODIAK75_Belly_MudSled() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
            }
            // Wide-stance mud outriggers
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 13.5, 0]) cylinder(d=4.2, h=2.2);
                    translate([ 20.0, y_s * 13.5, 0]) cylinder(d=4.2, h=2.2);
                }
            }
            // Angled connecting bridges
            for (x_w = [-16.0, 16.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_w, 0, 0]) cylinder(d=4.4, h=skid_h);
                        translate([x_w, y_s * 13.5, 0]) cylinder(d=3.8, h=2.0);
                    }
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_cut = [-9.0, 0.0, 9.0]) {
            translate([x_cut, 0, -0.1])
                cylinder(d=6.0, h=skid_h + 0.2);
        }
    }
}
module Belly_MudSled() { KODIAK75_Belly_MudSled(); }

// 309: Snow Ski Runner (Alpine)
module KODIAK75_Belly_SnowSkiRunner() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
            }
            for (x_s = [-18.0, 18.0]) {
                translate([x_s, 0, 1.0])
                    cube([5.0, 16.0, 2.0], center=true);
            }
            // Twin Nordic skis with curved tips
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-23.0, y_s * 7.5, 0]) cylinder(d=3.8, h=1.6);
                    translate([ 19.0, y_s * 7.5, 0]) cylinder(d=3.8, h=1.6);
                }
                hull() {
                    translate([19.0, y_s * 7.5, 0]) cylinder(d=3.8, h=1.6);
                    translate([25.0, y_s * 7.5, 2.2]) cylinder(d=3.0, h=1.4);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (y_s = [-1, 1]) {
            translate([0, y_s * 7.5, -0.1])
                cube([40.0, 1.2, 0.7], center=true);
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_SnowSkiRunner() { KODIAK75_Belly_SnowSkiRunner(); }

// 310: Forest Sledge (Forest)
module KODIAK75_Belly_ForestSledge() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.2, 0]) cylinder(d=4.6, h=2.8, $fn=6);
                    translate([ 21.0, y_s * 7.2, 0]) cylinder(d=4.6, h=2.8, $fn=6);
                }
            }
            for (x_b = [-18.0, 0.0, 18.0]) {
                translate([x_b, 0, 1.3])
                    cube([4.8, 15.6, 2.6], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_m = [-9.0, 9.0]) {
            translate([x_m, 0, -0.1])
                cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_ForestSledge() { KODIAK75_Belly_ForestSledge(); }

// 311: Racing Skis (Racing)
module KODIAK75_Belly_RacingSkis() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.2, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.2, h=skid_h);
            }
            // Razor-slim racing runner blades
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 5.6, 0]) cylinder(d=2.4, h=1.8);
                    translate([ 21.0, y_s * 5.6, 0]) cylinder(d=2.4, h=1.8);
                }
                hull() {
                    translate([21.0, y_s * 5.6, 0]) cylinder(d=2.4, h=1.8);
                    translate([24.5, y_s * 5.6, 1.4]) cylinder(d=1.4, h=1.2);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-10.0, 0.0, 10.0]) {
            hull() {
                translate([x_w - 2.0, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
                translate([x_w + 2.0, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
            }
        }
    }
}
module Belly_RacingSkis() { KODIAK75_Belly_RacingSkis(); }

// 312: Combat Sled (Battle)
module KODIAK75_Belly_CombatSled() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=13.8, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=13.8, h=skid_h);
                translate([ 24.0, 0, 0]) cylinder(d=5.8, h=skid_h);
            }
            for (y_s = [-5.0, 0.0, 5.0]) {
                translate([0, y_s, 0.8])
                    cube([36.0, 1.6, 1.6], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_h = [-8.5, 8.5]) {
            translate([x_h, 0, -0.1])
                cylinder(d=6.4, h=skid_h + 0.2, $fn=6);
        }
    }
}
module Belly_CombatSled() { KODIAK75_Belly_CombatSled(); }

// 313: Dual Rail Runners (Utility)
module KODIAK75_Belly_DualRailRunners() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.4, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.4, h=skid_h);
            }
            for (x_p = [-16.0, 16.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_p, 0, 0]) cylinder(d=3.8, h=skid_h);
                        translate([x_p, y_s * 7.2, 0]) cylinder(d=3.8, h=3.2);
                    }
                }
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.2, 0]) cylinder(d=3.8, h=2.2);
                    translate([ 21.0, y_s * 7.2, 0]) cylinder(d=3.8, h=2.2);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_DualRailRunners() { KODIAK75_Belly_DualRailRunners(); }

// 314: Heavy Duty Skid (Battle)
module KODIAK75_Belly_HeavyDutySkid() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=12.2, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=12.2, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.5, 0]) cylinder(d=4.2, h=3.0);
                    translate([ 21.0, y_s * 7.5, 0]) cylinder(d=4.2, h=3.0);
                }
            }
            for (x_d = [-12.0, 0.0, 12.0]) {
                translate([x_d, 0, 1.4])
                    cube([4.4, 15.0, 2.8], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_t = [-6.0, 6.0]) {
            translate([x_t, 0, -0.1])
                cylinder(d=6.2, h=skid_h + 0.2, $fn=3);
        }
    }
}
module Belly_HeavyDutySkid() { KODIAK75_Belly_HeavyDutySkid(); }

// 315: High Speed Sliders (Racing)
module KODIAK75_Belly_HighSpeedSliders() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.4, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.4, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 6.5, 0]) cylinder(d=4.6, h=1.8);
                    translate([ 20.0, y_s * 6.5, 0]) cylinder(d=4.6, h=1.8);
                }
                hull() {
                    translate([ 20.0, y_s * 6.5, 0]) cylinder(d=4.6, h=1.8);
                    translate([ 24.0, y_s * 6.5, 1.2]) cylinder(d=3.2, h=1.2);
                }
                hull() {
                    translate([-20.0, y_s * 6.5, 0]) cylinder(d=4.6, h=1.8);
                    translate([-24.0, y_s * 6.5, 1.2]) cylinder(d=3.2, h=1.2);
                }
            }
            for (x_s = [-16.0, 16.0]) {
                translate([x_s, 0, 0.9])
                    cube([4.2, 14.0, 1.8], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.0, 0.0, 8.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
        }
    }
}
module Belly_HighSpeedSliders() { KODIAK75_Belly_HighSpeedSliders(); }

// 316: Shock Absorber Sled (Utility)
module KODIAK75_Belly_ShockAbsorberSled() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 6.8, 0]) cylinder(d=3.6, h=1.8);
                    translate([  0.0, y_s * 6.8, 0]) cylinder(d=4.2, h=2.8);
                }
                hull() {
                    translate([  0.0, y_s * 6.8, 0]) cylinder(d=4.2, h=2.8);
                    translate([ 21.0, y_s * 6.8, 0]) cylinder(d=3.6, h=1.8);
                }
            }
            for (x_t = [-16.0, 16.0]) {
                translate([x_t, 0, 1.0])
                    cube([4.6, 14.5, 2.0], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        hull() {
            translate([-8.0, 0, -0.1]) cylinder(d=6.6, h=skid_h + 0.2);
            translate([ 8.0, 0, -0.1]) cylinder(d=6.6, h=skid_h + 0.2);
        }
    }
}
module Belly_ShockAbsorberSled() { KODIAK75_Belly_ShockAbsorberSled(); }

// 317: Grip Runners (Utility)
module KODIAK75_Belly_GripRunners() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 7.0, 0]) cylinder(d=4.6, h=2.6);
                    translate([ 20.0, y_s * 7.0, 0]) cylinder(d=4.6, h=2.6);
                }
                for (x_k = [-16 : 4 : 16]) {
                    translate([x_k, y_s * 7.0, 0.4])
                        rotate([0, 0, 45])
                            cube([2.2, 2.2, 0.8], center=true);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_GripRunners() { KODIAK75_Belly_GripRunners(); }

// 318: Landing Pontoons (River)
module KODIAK75_Belly_LandingPontoons() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.2, 0]) cylinder(d=3.0, h=2.0);
                    translate([  0.0, y_s * 7.2, 0]) cylinder(d=4.8, h=2.6);
                    translate([ 21.0, y_s * 7.2, 0]) cylinder(d=2.8, h=2.0);
                }
            }
            for (x_s = [-16.0, 16.0]) {
                hull() {
                    translate([x_s, -7.2, 0]) cylinder(d=4.6, h=2.0);
                    translate([x_s,  7.2, 0]) cylinder(d=4.6, h=2.0);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_LandingPontoons() { KODIAK75_Belly_LandingPontoons(); }

// 319: Tactical Skids (Battle)
module KODIAK75_Belly_TacticalSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.4, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.4, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 7.2, 0]) cylinder(d=4.4, h=3.0);
                    translate([ 21.0, y_s * 7.2, 0]) cylinder(d=4.4, h=3.0);
                }
                for (x_l = [-12.0, 12.0]) {
                    translate([x_l, y_s * 8.6, 0])
                        cylinder(d=4.8, h=2.6);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Tie-down through-holes
        for (y_s = [-1, 1]) {
            for (x_l = [-12.0, 12.0]) {
                translate([x_l, y_s * 8.6, -0.1])
                    cylinder(d=2.2, h=3.0);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_TacticalSkids() { KODIAK75_Belly_TacticalSkids(); }

// 320: Hydroplane Runners (River)
module KODIAK75_Belly_HydroplaneRunners() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-20.0, 0, 0]) cylinder(d=13.0, h=skid_h);
                translate([ 20.0, 0, 0]) cylinder(d=13.0, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 6.8, 0]) cylinder(d=3.8, h=2.8);
                    translate([ 21.0, y_s * 6.8, 0]) cylinder(d=3.8, h=2.8);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Arched venturi tunnel underneath
        hull() {
            translate([-22.0, 0, -0.1]) cylinder(d=8.0, h=1.4);
            translate([ 22.0, 0, -0.1]) cylinder(d=8.0, h=1.4);
        }
        for (x_w = [-8.0, 8.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_HydroplaneRunners() { KODIAK75_Belly_HydroplaneRunners(); }

// 321: Exo Skids (Sci-Fi)
module KODIAK75_Belly_ExoSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            for (x_n = [-18.0, 0.0, 18.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_n, 0, 0]) cylinder(d=3.6, h=skid_h);
                        translate([x_n, y_s * 8.0, 0]) cylinder(d=3.6, h=3.0, $fn=6);
                    }
                }
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-18.0, y_s * 8.0, 0]) cylinder(d=3.4, h=2.4);
                    translate([ 18.0, y_s * 8.0, 0]) cylinder(d=3.4, h=2.4);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_h = [-9.0, 9.0]) {
            translate([x_h, 0, -0.1])
                cylinder(d=6.2, h=skid_h + 0.2, $fn=6);
        }
    }
}
module Belly_ExoSkids() { KODIAK75_Belly_ExoSkids(); }

// 322: Stealth Sled (Stealth)
module KODIAK75_Belly_StealthSled() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([  0.0, 0, 0]) cylinder(d=16.0, h=skid_h, $fn=4);
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h, $fn=4);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h, $fn=4);
            }
            translate([0, 0, 0.8])
                rotate([45, 0, 0])
                    cube([36.0, 2.2, 2.2], center=true);
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_d = [-9.0, 9.0]) {
            translate([x_d, 0, -0.1])
                cylinder(d=6.0, h=skid_h + 0.2, $fn=4);
        }
    }
}
module Belly_StealthSled() { KODIAK75_Belly_StealthSled(); }

// 323: Titanium Rails (Racing)
module KODIAK75_Belly_TitaniumRails() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=8.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=8.8, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 5.4, 0]) cylinder(d=1.6, h=2.2);
                    translate([ 21.0, y_s * 5.4, 0]) cylinder(d=1.6, h=2.2);
                }
            }
            for (x_s = [-16.0, 16.0]) {
                translate([x_s, 0, 0.8])
                    cube([3.8, 12.0, 1.6], center=true);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-10.0, 0.0, 10.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
        }
    }
}
module Belly_TitaniumRails() { KODIAK75_Belly_TitaniumRails(); }

// 324: Magna Skids (Utility)
module KODIAK75_Belly_MagnaSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            translate([-18.0, 0, 0]) cylinder(d=13.0, h=skid_h);
            translate([ 18.0, 0, 0]) cylinder(d=13.0, h=skid_h);
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
            }
            translate([22.5, 0, 1.2])
                cube([3.4, 12.0, 2.4], center=true);
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_MagnaSkids() { KODIAK75_Belly_MagnaSkids(); }

// 325: Ground Effect Tunnel (Aero)
module KODIAK75_Belly_GroundEffectTunnel() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([ 20.0, 0, 0]) cylinder(d=12.0, h=skid_h);
                translate([-20.0, 0, 0]) cylinder(d=15.0, h=skid_h);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 6.5, 0]) cylinder(d=2.6, h=3.0);
                    translate([ 21.0, y_s * 6.5, 0]) cylinder(d=2.6, h=3.0);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        hull() {
            translate([-14.0, 0, -0.1]) cylinder(d=8.4, h=1.5);
            translate([ 14.0, 0, -0.1]) cylinder(d=6.2, h=1.5);
        }
        translate([0, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
    }
}
module Belly_GroundEffectTunnel() { KODIAK75_Belly_GroundEffectTunnel(); }

// ============================================================================
// SHOWCASE PREVIEW MODULE (PART_ID == 0)
// ============================================================================
module kodiak75_parts100_showcase() {
    // Renders sample 4-piece loadout in arena battle formation
    translate([0, 0, 16.0]) Crown_GrizzlySnarl();
    translate([0, 0, 9.7]) Cheek_BearPaws();
    translate([0, 0, 0.0]) Belly_HoneyPotSkid();
}

// ============================================================================
// MASTER CLI DISPATCHER
// ============================================================================
// Zone 1: Top Crowns (101..140)
if      (PART_ID == 101) Crown_GrizzlySnarl();
else if (PART_ID == 102) Crown_KodiakRoar();
else if (PART_ID == 103) Crown_PolarCrown();
else if (PART_ID == 104) Crown_PandaBamboo();
else if (PART_ID == 105) Crown_SunBearCrest();
else if (PART_ID == 106) Crown_HoneycombDipper();
else if (PART_ID == 107) Crown_PineconeCrest();
else if (PART_ID == 108) Crown_AntlerSpikes();
else if (PART_ID == 109) Crown_WolfHowl();
else if (PART_ID == 110) Crown_EagleTalon();
else if (PART_ID == 111) Crown_OwlCrest();
else if (PART_ID == 112) Crown_BadgerMohawk();
else if (PART_ID == 113) Crown_SalmonFin();
else if (PART_ID == 114) Crown_ForestCanopy();
else if (PART_ID == 115) Crown_AcornSprout();
else if (PART_ID == 116) Crown_MapleLeaf();
else if (PART_ID == 117) Crown_MountainRidge();
else if (PART_ID == 118) Crown_RiverCrest();
else if (PART_ID == 119) Crown_BerryBunch();
else if (PART_ID == 120) Crown_HibernateHelmet();
else if (PART_ID == 121) Crown_CyberBearVisor();
else if (PART_ID == 122) Crown_MechaMohawk();
else if (PART_ID == 123) Crown_BattleHelm();
else if (PART_ID == 124) Crown_TitaniumCrest();
else if (PART_ID == 125) Crown_RadarDome();
else if (PART_ID == 126) Crown_TurboScoop();
else if (PART_ID == 127) Crown_StealthFin();
else if (PART_ID == 128) Crown_PlasmaHorn();
else if (PART_ID == 129) Crown_VortexCannon();
else if (PART_ID == 130) Crown_SonicDish();
else if (PART_ID == 131) Crown_EMPSpike();
else if (PART_ID == 132) Crown_ShieldCrest();
else if (PART_ID == 133) Crown_AfterburnerCowl();
else if (PART_ID == 134) Crown_HeavyBumper();
else if (PART_ID == 135) Crown_EnergyCrest();
else if (PART_ID == 136) Crown_NitroFin();
else if (PART_ID == 137) Crown_CarbonFin();
else if (PART_ID == 138) Crown_CyberClaws();
else if (PART_ID == 139) Crown_NeonCrest();
else if (PART_ID == 140) Crown_OrbitalBeacon();

// Zones 2 & 3: Cheek Pod Pairs (201..235)
else if (PART_ID == 201) Cheek_BearPaws();
else if (PART_ID == 202) Cheek_CubEars();
else if (PART_ID == 203) Cheek_GrizzlyWhiskers();
else if (PART_ID == 204) Cheek_SalmonSkiffs();
else if (PART_ID == 205) Cheek_PineNeedles();
else if (PART_ID == 206) Cheek_ForestFangs();
else if (PART_ID == 207) Cheek_AcornShells();
else if (PART_ID == 208) Cheek_HoneySpatulas();
else if (PART_ID == 209) Cheek_BeaverTails();
else if (PART_ID == 210) Cheek_FeatherWings();
else if (PART_ID == 211) Cheek_ClawShields();
else if (PART_ID == 212) Cheek_OwlFeathers();
else if (PART_ID == 213) Cheek_MossBanks();
else if (PART_ID == 214) Cheek_RiverSkimmers();
else if (PART_ID == 215) Cheek_LeafFins();
else if (PART_ID == 216) Cheek_AeroCanards();
else if (PART_ID == 217) Cheek_VortexGenerators();
else if (PART_ID == 218) Cheek_RamAirDucts();
else if (PART_ID == 219) Cheek_WingletDeflectors();
else if (PART_ID == 220) Cheek_CombatSpoilers();
else if (PART_ID == 221) Cheek_ShieldPlates();
else if (PART_ID == 222) Cheek_HeatSinks();
else if (PART_ID == 223) Cheek_StrikeBlades();
else if (PART_ID == 224) Cheek_ArmorFlaps();
else if (PART_ID == 225) Cheek_ThrusterPods();
else if (PART_ID == 226) Cheek_AirBrakeFins();
else if (PART_ID == 227) Cheek_CornerBumpers();
else if (PART_ID == 228) Cheek_InterceptorFins();
else if (PART_ID == 229) Cheek_FlakDeflectors();
else if (PART_ID == 230) Cheek_SensorWings();
else if (PART_ID == 231) Cheek_LaserCowls();
else if (PART_ID == 232) Cheek_ReactivePlates();
else if (PART_ID == 233) Cheek_WarpNacelles();
else if (PART_ID == 234) Cheek_KineticAbsorbers();
else if (PART_ID == 235) Cheek_SonicVanes();

// Zone 4: Belly Skids (301..325)
else if (PART_ID == 301) belly_skid_master_trim() Belly_HoneyPotSkid();
else if (PART_ID == 302) belly_skid_master_trim() Belly_BearDenRunner();
else if (PART_ID == 303) belly_skid_master_trim() Belly_RiverPebbleSled();
else if (PART_ID == 304) belly_skid_master_trim() Belly_PineLogSkids();
else if (PART_ID == 305) belly_skid_master_trim() Belly_GrizzlyBellySled();
else if (PART_ID == 306) belly_skid_master_trim() Belly_FishBellyRunner();
else if (PART_ID == 307) belly_skid_master_trim() Belly_BirchBarkSkids();
else if (PART_ID == 308) belly_skid_master_trim() Belly_MudSled();
else if (PART_ID == 309) belly_skid_master_trim() Belly_SnowSkiRunner();
else if (PART_ID == 310) belly_skid_master_trim() Belly_ForestSledge();
else if (PART_ID == 311) belly_skid_master_trim() Belly_RacingSkis();
else if (PART_ID == 312) belly_skid_master_trim() Belly_CombatSled();
else if (PART_ID == 313) belly_skid_master_trim() Belly_DualRailRunners();
else if (PART_ID == 314) belly_skid_master_trim(0.37, 1.60) Belly_HeavyDutySkid();
else if (PART_ID == 315) belly_skid_master_trim() Belly_HighSpeedSliders();
else if (PART_ID == 316) belly_skid_master_trim() Belly_ShockAbsorberSled();
else if (PART_ID == 317) belly_skid_master_trim() Belly_GripRunners();
else if (PART_ID == 318) belly_skid_master_trim() Belly_LandingPontoons();
else if (PART_ID == 319) belly_skid_master_trim() Belly_TacticalSkids();
else if (PART_ID == 320) belly_skid_master_trim() Belly_HydroplaneRunners();
else if (PART_ID == 321) belly_skid_master_trim() Belly_ExoSkids();
else if (PART_ID == 322) belly_skid_master_trim() Belly_StealthSled();
else if (PART_ID == 323) belly_skid_master_trim() Belly_TitaniumRails();
else if (PART_ID == 324) belly_skid_master_trim() Belly_MagnaSkids();
else if (PART_ID == 325) belly_skid_master_trim() Belly_GroundEffectTunnel();

// Default: Showcase
else {
    kodiak75_parts100_showcase();
}
