// ============================================================================
// KODIAK-75: Kid-Customizable Magnetic Snap-On Accessory Pack — Rev 2.0 (36-Part Mega Pack)
// True Boolean CSG Geometry — Verified Watertight 2-Manifold (Simple: yes)
// ============================================================================
// UNIVERSAL MAGNET + CONICAL SHEAR-KEYWAY INTERFACE:
// - Mates directly with the KODIAK-75 Top Crown (8.0mm boss), Left/Right Cheek
//   (7.6mm bosses at 3 & 9 o'clock), and 550mAh Belly Cradle (dual 7.6mm bosses
//   at X = -18.0mm and X = +18.0mm, 36.0mm center-to-center spacing).
// - Each part includes a 0.45mm protruding conical shear boss (d1 = 3.40mm,
//   d2 = 2.10mm, h = 0.45mm) centered around a 2.10mm x 1.20mm N52 magnet
//   pocket. This locks into the drone's 3.60mm x 0.50mm conical shear dimple
//   to resist 15G flight maneuvers while shearing off cleanly on bumper tags!
// - All 36 parts are engineered for support-free FDM printing in TPU 95A at
//   ~0.4g to 0.7g mass per part (thin-wall / pocketed geometry).
// ============================================================================

$fn = 32;

// Overridden via command-line: openscad -D PART_ID=1 ...
// 0  = Full 36-Part Customization Showcase Preview
// --- ORIGINAL 6 STARTER PACK PARTS (PART_ID = 1..6) ---
// 1  = KODIAK75_Top_OsitoBearEars.stl       (Osito Bear Ears Crown Topper)
// 2  = KODIAK75_Top_DragonSpikes.stl        (Dragon Spikes Dorsal Fin Topper)
// 3  = KODIAK75_Top_MechaCrest.stl          (Mecha Knight V-Crest Topper)
// 4  = KODIAK75_Cheek_SweptWings.stl        (Starfighter Swept Wings Pair)
// 5  = KODIAK75_Cheek_TurboBoosters.stl     (Turbo Booster Nacelles Pair)
// 6  = KODIAK75_Belly_BearClawSkids.stl     (Bear-Claw Dual-Magnet Hover Skids)
// --- ZONE 1: 12 NEW TOP CROWN SACRIFICIAL TOPPERS (PART_ID = 7..18) ---
// 7  = KODIAK75_Top_SharkFin.stl            (Dorsal Shark Fin w/ rear notch)
// 8  = KODIAK75_Top_UnicornHorn.stl         (Spiral fluted Unicorn Horn)
// 9  = KODIAK75_Top_VikingHorns.stl         (Twin curved Viking Helmet Horns)
// 10 = KODIAK75_Top_RoyalCrown.stl          (5-Point King/Queen Royal Crown ring)
// 11 = KODIAK75_Top_MohawkSpikes.stl        (5-blade Punk Mohawk comb crest)
// 12 = KODIAK75_Top_BunnyEars.stl           (Tall twin Lop/Bunny Ears)
// 13 = KODIAK75_Top_CatEars.stl             (Sharp triangular Cyber-Cat Ears)
// 14 = KODIAK75_Top_SamuraiKabuto.stl       (Crescent Moon Samurai Kabuto crest)
// 15 = KODIAK75_Top_SatelliteDish.stl       (Parabolic Space Radar Dish)
// 16 = KODIAK75_Top_WizardCone.stl          (Tilted Wizard / Witch Hat cone)
// 17 = KODIAK75_Top_SirenBeacon.stl         (Faceted Police/Rescue Lightbar dome)
// 18 = KODIAK75_Top_DinoStegoPlates.stl     (Double row Stegosaurus back plates)
// --- ZONES 2 & 3: 10 NEW CHEEK SACRIFICIAL POD PAIRS (PART_ID = 19..28) ---
// 19 = KODIAK75_Cheek_LightningBolts.stl    (Zig-zag Lightning Bolt winglets)
// 20 = KODIAK75_Cheek_BatWings.stl          (Scalloped Bat / Gargoyle wings)
// 21 = KODIAK75_Cheek_FlameFins.stl         (Hot-Rod triple-lick Flame fins)
// 22 = KODIAK75_Cheek_KnightShields.stl     (Heater-style Medieval Knight Shields)
// 23 = KODIAK75_Cheek_SawbladeBumpers.stl   (Rounded-tooth Buzzsaw bumper discs)
// 24 = KODIAK75_Cheek_LaserPods.stl         (Twin Sci-Fi Starfighter Ion Cannons)
// 25 = KODIAK75_Cheek_EagleFeathers.stl     (Layered Golden Eagle feathered wings)
// 26 = KODIAK75_Cheek_HoneycombPlates.stl   (Hexagonal Energy-Shield armor plates)
// 27 = KODIAK75_Cheek_MonsterFists.stl      (Cartoon Mecha / Hulk smasher gloves)
// 28 = KODIAK75_Cheek_SharkGills.stl        (Slotted Mako Shark pectoral fins)
// --- ZONE 4: 8 NEW DUAL-MAGNET BELLY SKID PLATES (PART_ID = 29..36) ---
// 29 = KODIAK75_Belly_HoverSkirt.stl        (Ribbed Air-Cushion Hovercraft skirt)
// 30 = KODIAK75_Belly_TankTreads.stl        (Mini Armored Tank Tread pontoons)
// 31 = KODIAK75_Belly_SnowSkis.stl          (Twin upturned Alpine Snow Skis)
// 32 = KODIAK75_Belly_SeaplaneFloats.stl    (Twin stepped Seaplane Pontoon floats)
// 33 = KODIAK75_Belly_SkateboardDeck.stl    (Mini Skateboard Deck w/ faux trucks)
// 34 = KODIAK75_Belly_SurfboardKeel.stl     (Streamlined Longboard w/ twin skegs)
// 35 = KODIAK75_Belly_SpiderLegs.stl        (4-corner Cyber-Spider landing struts)
// 36 = KODIAK75_Belly_AfterburnerDiffuser.stl (Venturi racecar diffuser + nozzles)
PART_ID = 0;

// --- Universal N52 Magnet & Conical Shear-Keyway Parameters ---
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_dimple_dia    = 3.60;
shear_dimple_depth  = 0.50;

// Male mating conical boss on removable accessories (mates into 3.60x0.50mm dimple)
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;
belly_mag_spacing   = 36.0; // X = -18.0mm and X = +18.0mm

// ============================================================================
// UNIVERSAL MAGNET + SHEAR BOSS HELPER MODULES
// ============================================================================

// Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45)
module n52_mating_boss_up() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

// Top-facing 2.10mm x 1.20mm recessed magnet pocket cut
module n52_mating_pocket_cut_up() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.10);
}

// Standard lightweight Top Crown base with bottom-facing 0.45mm conical shear boss
// Outer skirt (d=16.0mm) and central shear boss tip (d=2.10mm) both sit on Z=0
// for 100% support-free bed adhesion while shrouding the 8.0mm Top Deck boss.
module top_crown_base_solid(base_od=15.6, base_h=2.6) {
    difference() {
        cylinder(d1=base_od, d2=base_od - 3.2, h=base_h);
        // 0.45mm annular relief for the drone's 8.0mm Top Deck boss
        translate([0, 0, -0.05])
            cylinder(d=8.4, h=shear_boss_height + 0.05);
    }
    // Downward-protruding 0.45mm conical shear boss (d=3.40 at Z=0.45 -> d=2.10 at Z=0)
    cylinder(d1=shear_boss_dia2, d2=shear_boss_dia1, h=shear_boss_height);
}

module top_crown_base_cuts(base_h=2.6) {
    // 2.10mm x 1.20mm recessed N52 magnet pocket from Z=0 upward
    translate([0, 0, -0.05])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.05);
}

// Standard Cheek Pod Hub Pad with top-facing 0.45mm conical shear boss at Z = pad_h
module cheek_hub_solid(pad_h=2.4) {
    hull() {
        cylinder(d=8.8, h=pad_h);
        translate([-8.5, 0, 0]) cylinder(d=4.4, h=pad_h - 0.6);
        translate([ 8.5, 0, 0]) cylinder(d=4.4, h=pad_h - 0.6);
    }
    translate([0, 0, pad_h])
        n52_mating_boss_up();
}

// ============================================================================
// PART 1: Osito Bear Ears Crown (KODIAK75_Top_OsitoBearEars.stl)
// ============================================================================
module KODIAK75_Top_OsitoBearEars() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            intersection() {
                translate([0, 0, 1.0])
                    rotate([0, 90, 0])
                        cylinder(d=14.0, h=2.2, center=true);
                translate([-2.0, -9.0, 0])
                    cube([4.0, 18.0, 9.0]);
            }
            for (y_sign = [-1, 1]) {
                translate([0, y_sign * 6.8, 9.2])
                    rotate([y_sign * -12, 0, 0]) {
                        hull() {
                            rotate([0, 90, 0])
                                cylinder(d=9.6, h=2.0, center=true);
                            translate([0, -y_sign * 3.2, -6.8])
                                rotate([0, 90, 0])
                                    cylinder(d=4.4, h=2.2, center=true);
                        }
                    }
            }
        }
        top_crown_base_cuts(2.6);
        for (y_sign = [-1, 1]) {
            translate([0.65, y_sign * 6.8, 9.4])
                rotate([y_sign * -12, 0, 0])
                    rotate([0, 90, 0])
                        cylinder(d=5.8, h=1.2);
            translate([-1.85, y_sign * 6.8, 9.4])
                rotate([y_sign * -12, 0, 0])
                    rotate([0, 90, 0])
                        cylinder(d=5.2, h=1.2);
        }
    }
}

// ============================================================================
// PART 2: Dragon Spikes Dorsal Fin (KODIAK75_Top_DragonSpikes.stl)
// ============================================================================
module KODIAK75_Top_DragonSpikes() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            hull() {
                translate([3.2, -1.0, 1.8]) cube([4.0, 2.0, 1.0]);
                translate([8.5, -0.6, 9.5]) cube([1.6, 1.2, 1.6]);
            }
            hull() {
                translate([-2.2, -1.1, 1.8]) cube([5.2, 2.2, 1.0]);
                translate([-4.2, -0.6, 13.5]) cube([2.0, 1.2, 1.8]);
            }
            hull() {
                translate([-7.2, -1.0, 1.8]) cube([4.8, 2.0, 1.0]);
                translate([-11.5, -0.6, 8.2]) cube([1.8, 1.2, 1.5]);
            }
            hull() {
                translate([-6.5, -0.8, 1.8]) cube([13.0, 1.6, 1.0]);
                translate([-2.0, -0.7, 6.8]) cube([5.0, 1.4, 1.0]);
            }
        }
        top_crown_base_cuts(2.6);
        for (y_sign = [-1, 1]) {
            translate([0, y_sign * 1.35, 5.2])
                rotate([90, 0, 0])
                    cylinder(d=3.6, h=1.2, center=true);
        }
    }
}

// ============================================================================
// PART 3: Mecha Knight V-Crest (KODIAK75_Top_MechaCrest.stl)
// ============================================================================
module KODIAK75_Top_MechaCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            hull() {
                translate([0, 0, 2.0]) cylinder(d=6.4, h=1.0);
                translate([1.8, 0, 6.2]) sphere(d=3.6);
            }
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([0.5, y_sign * 1.5, 2.2])
                        cube([2.4, 1.8, 2.2], center=true);
                    translate([-2.2, y_sign * 12.5, 13.0])
                        cube([1.6, 1.4, 2.0], center=true);
                }
                hull() {
                    translate([0.0, y_sign * 1.8, 4.2])
                        cube([1.8, 1.6, 2.0], center=true);
                    translate([-1.2, y_sign * 7.8, 11.2])
                        cube([1.4, 1.2, 1.6], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
    }
}

// ============================================================================
// PART 4: Starfighter Swept Wings Pair (KODIAK75_Cheek_SweptWings.stl)
// ============================================================================
module single_swept_wing(is_right=1) {
    difference() {
        union() {
            hull() {
                cylinder(d=8.8, h=2.4);
                translate([-9.5, 0, 0]) cylinder(d=4.6, h=1.8);
                translate([9.5, 0, 0])  cylinder(d=4.6, h=1.8);
            }
            hull() {
                translate([-6.0, 0, 0]) cylinder(d=4.4, h=1.6);
                translate([7.0, 0, 0])  cylinder(d=4.4, h=1.6);
                translate([-8.5, is_right * 10.5, 0]) cylinder(d=2.8, h=1.2);
                translate([-2.5, is_right * 11.5, 0]) cylinder(d=3.2, h=1.4);
            }
            hull() {
                translate([-8.5, is_right * 10.5, 0]) cylinder(d=2.6, h=4.8);
                translate([-2.5, is_right * 11.5, 0]) cylinder(d=2.6, h=2.6);
            }
            translate([0, 0, 2.4])
                n52_mating_boss_up();
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        translate([-4.0, is_right * 6.2, 0.8])
            cylinder(d=4.6, h=2.0);
    }
}

module KODIAK75_Cheek_SweptWings() {
    translate([0, -16.0, 0]) single_swept_wing(-1);
    translate([0,  16.0, 0]) single_swept_wing(1);
}

// ============================================================================
// PART 5: Turbo Booster Nacelles Pair (KODIAK75_Cheek_TurboBoosters.stl)
// ============================================================================
module single_turbo_booster(is_right=1) {
    difference() {
        union() {
            hull() {
                cylinder(d=8.8, h=2.6);
                translate([-10.0, 0, 0]) cylinder(d=4.6, h=2.0);
                translate([10.0, 0, 0])  cylinder(d=4.6, h=2.0);
                translate([0, is_right * 5.2, 0]) cylinder(d=7.2, h=2.4);
            }
            hull() {
                translate([-8.0, is_right * 5.8, 2.8])
                    rotate([0, 90, 0])
                        cylinder(d=6.8, h=16.0);
                translate([-6.0, is_right * 5.8, 0])
                    cube([12.0, 5.6, 1.2], center=true);
            }
            translate([-9.5, is_right * 5.8, 2.8])
                rotate([0, 90, 0])
                    cylinder(d1=7.8, d2=6.6, h=2.5);
            translate([0, 0, 2.6])
                n52_mating_boss_up();
        }
        translate([0, 0, 2.6])
            n52_mating_pocket_cut_up();
        translate([-9.6, is_right * 5.8, 2.8])
            rotate([0, 90, 0])
                cylinder(d1=5.6, d2=3.6, h=5.5);
        translate([3.0, is_right * 5.8, 2.8])
            rotate([0, 90, 0])
                cylinder(d1=3.6, d2=5.0, h=5.5);
    }
}

module KODIAK75_Cheek_TurboBoosters() {
    translate([0, -14.0, 0]) single_turbo_booster(-1);
    translate([0,  14.0, 0]) single_turbo_booster(1);
}

// ============================================================================
// PART 6: Bear-Claw Hover Skids (KODIAK75_Belly_BearClawSkids.stl)
// ============================================================================
module KODIAK75_Belly_BearClawSkids() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-belly_mag_spacing/2, 0, 0]) cylinder(d=11.6, h=skid_h);
                translate([ belly_mag_spacing/2, 0, 0]) cylinder(d=11.6, h=skid_h);
            }
            for (x_end = [-1, 1]) {
                translate([x_end * (belly_mag_spacing/2), 0, 0]) {
                    cylinder(d=14.4, h=skid_h);
                    for (claw_ang = [-28, 0, 28]) {
                        rotate([0, 0, (x_end > 0 ? 0 : 180) + claw_ang])
                            hull() {
                                translate([4.5, 0, 0]) cylinder(d=4.2, h=skid_h);
                                translate([11.2, 0, 0]) cylinder(d1=1.8, d2=2.8, h=skid_h * 0.75);
                            }
                    }
                }
            }
            for (y_sign = [-1, 1]) {
                hull() {
                    translate([-16.0, y_sign * 5.8, 0]) cylinder(d=3.0, h=skid_h);
                    translate([ 16.0, y_sign * 5.8, 0]) cylinder(d=3.0, h=skid_h);
                }
            }
            for (x_pos = [-belly_mag_spacing/2, belly_mag_spacing/2]) {
                translate([x_pos, 0, skid_h])
                    n52_mating_boss_up();
            }
        }
        for (x_pos = [-belly_mag_spacing/2, belly_mag_spacing/2]) {
            translate([x_pos, 0, skid_h])
                n52_mating_pocket_cut_up();
        }
        for (x_cut = [-8.5, 0, 8.5]) {
            hull() {
                translate([x_cut - 1.8, 0, -0.1]) cylinder(d=5.2, h=skid_h + 0.2);
                translate([x_cut + 1.8, 0, -0.1]) cylinder(d=5.2, h=skid_h + 0.2);
            }
        }
    }
}

// ============================================================================
// ZONE 1: 12 NEW TOP CROWN SACRIFICIAL TOPPERS (PART_ID = 7..18)
// ============================================================================

// PART 7: Dorsal Shark Fin with hydrodynamic leading edge and rear notch
module KODIAK75_Top_SharkFin() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            hull() {
                translate([-6.0, 0, 2.0]) cylinder(d=2.2, h=1.0);
                translate([ 6.5, 0, 2.0]) cylinder(d=2.8, h=1.0);
                translate([-4.5, 0, 15.5]) cylinder(d=1.8, h=1.2);
                translate([ 0.5, 0, 13.0]) cylinder(d=2.2, h=1.2);
            }
        }
        top_crown_base_cuts(2.6);
        // Characteristic rear Mako shark fin notch
        translate([-5.5, 0, 7.2])
            rotate([90, 0, 0])
                cylinder(d=5.6, h=4.0, center=true);
        // Side weight-relief flutes
        for (y_s = [-1, 1]) {
            translate([1.0, y_s * 1.3, 6.5])
                rotate([90, 0, 0])
                    cylinder(d=4.4, h=1.0, center=true);
        }
    }
}

// PART 8: Spiral Fluted Unicorn Horn (18mm tall, rounded safety tip)
module KODIAK75_Top_UnicornHorn() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Tilted forward magic horn with stacked spiral-flute rings
            for (i = [0 : 4]) {
                hull() {
                    translate([i * 0.7, 0, 2.0 + i * 2.8])
                        cylinder(d1=7.2 - i * 1.1, d2=6.2 - i * 1.0, h=1.6);
                    translate([(i + 1) * 0.7, 0, 2.0 + (i + 1) * 2.8])
                        cylinder(d=5.8 - i * 1.0, h=1.2);
                }
            }
            // Rounded safety tip at Z = 17.5mm
            translate([3.5, 0, 16.5])
                cylinder(d1=2.6, d2=1.8, h=1.5);
        }
        top_crown_base_cuts(2.6);
    }
}

// PART 9: Twin Curved Viking Helmet Horns
module KODIAK75_Top_VikingHorns() {
    difference() {
        union() {
            top_crown_base_solid(15.8, 2.6);
            // Viking brow rim
            cylinder(d1=15.8, d2=13.6, h=3.8);
            // Left & Right sweeping curved horns (2-segment support-free arch)
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 4.5, 2.4]) cylinder(d=5.2, h=1.4);
                    translate([0, y_s * 10.2, 6.8]) cylinder(d=3.8, h=1.4);
                }
                hull() {
                    translate([0, y_s * 10.2, 6.8]) cylinder(d=3.8, h=1.4);
                    translate([1.2, y_s * 12.2, 13.5]) cylinder(d=2.0, h=1.4);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Hollow interior of helmet dome above magnet socket
        translate([0, 0, 2.6])
            cylinder(d=9.6, h=4.0);
    }
}

// PART 10: 5-Point King/Queen Royal Crown Ring
module KODIAK75_Top_RoyalCrown() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Flared golden crown wall
            cylinder(d1=13.2, d2=15.6, h=6.5);
            // 5 Royal Crown Spires with ball finials
            for (a = [0 : 72 : 288]) {
                rotate([0, 0, a]) {
                    hull() {
                        translate([6.2, 0, 5.5]) cylinder(d=3.2, h=1.0);
                        translate([7.2, 0, 11.2]) cylinder(d=2.2, h=1.2);
                    }
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Hollow center chalice reduces weight to ~0.48g
        translate([0, 0, 2.4])
            cylinder(d1=9.2, d2=12.2, h=10.5);
    }
}

// PART 11: 5-Blade Punk Mohawk Comb Crest
module KODIAK75_Top_MohawkSpikes() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central Mohawk Spine Base
            translate([-6.5, -1.0, 1.8])
                cube([13.0, 2.0, 2.4]);
            // 5 Fanned Punk Mohawk Blades
            for (idx = [-2 : 2]) {
                hull() {
                    translate([idx * 2.6, -0.9, 2.4])
                        cube([2.0, 1.8, 1.2], center=true);
                    translate([idx * 4.4, -0.6, 12.8 - abs(idx) * 1.4])
                        cube([2.2, 1.2, 1.6], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
    }
}

// PART 12: Tall Twin Lop/Bunny Ears with hollowed inner ear channels
module KODIAK75_Top_BunnyEars() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.4, 2.0])
                        cylinder(d=4.4, h=1.2);
                    translate([-1.2, y_s * 6.8, 16.5])
                        cylinder(d=5.8, h=1.4);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Hollow inner bunny ear channels on forward face
        for (y_s = [-1, 1]) {
            hull() {
                translate([1.4, y_s * 3.8, 4.5])
                    cylinder(d=2.2, h=1.0);
                translate([0.4, y_s * 6.8, 15.0])
                    cylinder(d=3.0, h=1.0);
            }
        }
    }
}

// PART 13: Sharp Triangular Cyber-Cat Ears
module KODIAK75_Top_CatEars() {
    difference() {
        union() {
            top_crown_base_solid(15.8, 2.6);
            for (y_s = [-1, 1]) {
                hull() {
                    translate([1.8, y_s * 3.2, 2.0]) cylinder(d=2.6, h=1.0);
                    translate([-2.2, y_s * 3.6, 2.0]) cylinder(d=3.2, h=1.0);
                    translate([0, y_s * 6.8, 2.0]) cylinder(d=2.8, h=1.0);
                    translate([-0.5, y_s * 7.8, 11.8]) cylinder(d=1.8, h=1.2);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Recessed Cyber-Cat ear pockets on front
        for (y_s = [-1, 1]) {
            hull() {
                translate([1.5, y_s * 5.2, 3.8]) cylinder(d=2.4, h=1.0);
                translate([0.8, y_s * 7.0, 9.2]) cylinder(d=1.4, h=1.0);
            }
        }
    }
}

// PART 14: Crescent Moon Samurai Kabuto Crest
module KODIAK75_Top_SamuraiKabuto() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central Kabuto Forehead Mounting Post
            hull() {
                translate([0, 0, 2.0]) cylinder(d=6.0, h=1.2);
                translate([1.0, 0, 5.5]) cylinder(d=4.4, h=1.2);
            }
            // Sweeping Crescent Moon Blades (Left & Right)
            for (y_s = [-1, 1]) {
                hull() {
                    translate([1.0, 0, 4.5]) cube([2.0, 3.0, 2.2], center=true);
                    translate([0.5, y_s * 7.5, 7.2]) cube([1.8, 2.8, 2.2], center=true);
                }
                hull() {
                    translate([0.5, y_s * 7.5, 7.2]) cube([1.8, 2.8, 2.2], center=true);
                    translate([0.0, y_s * 11.2, 14.2]) cube([1.4, 1.6, 1.8], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
    }
}

// PART 15: Parabolic Space Radar Dish with central feed horn
module KODIAK75_Top_SatelliteDish() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Angled Parabolic Radar Dish Bowl (support-free 40 deg rim)
            translate([0, 0, 2.2])
                cylinder(d1=9.0, d2=18.4, h=5.6);
            // Central LNB Feed Horn Spire
            translate([0, 0, 2.2])
                cylinder(d1=3.2, d2=2.0, h=10.2);
            translate([0, 0, 11.4])
                cylinder(d=3.8, h=1.4);
        }
        top_crown_base_cuts(2.6);
        // Excavate parabolic dish interior around the central feed horn
        difference() {
            translate([0, 0, 3.8])
                cylinder(d1=6.8, d2=16.0, h=4.5);
            translate([0, 0, 2.0])
                cylinder(d=4.2, h=11.0);
        }
    }
}

// PART 16: Tilted Wizard / Witch Hat Cone with wide brim
module KODIAK75_Top_WizardCone() {
    difference() {
        union() {
            top_crown_base_solid(18.4, 2.2);
            // Wide enchanted hat brim with hatband
            translate([0, 0, 1.6])
                cylinder(d1=18.4, d2=12.0, h=1.8);
            // Crooked 3-stage conical wizard spire
            hull() {
                translate([0, 0, 3.0]) cylinder(d=10.8, h=1.0);
                translate([-1.2, 0, 8.5]) cylinder(d=6.8, h=1.0);
            }
            hull() {
                translate([-1.2, 0, 8.5]) cylinder(d=6.8, h=1.0);
                translate([-3.4, 0, 14.5]) cylinder(d=2.4, h=1.2);
            }
        }
        top_crown_base_cuts(2.6);
        // Internal weight-reduction cavity inside wizard cone
        translate([0, 0, 2.4])
            cylinder(d1=7.2, d2=3.0, h=6.5);
    }
}

// PART 17: Faceted Police/Rescue Lightbar Dome
module KODIAK75_Top_SirenBeacon() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.4);
            // Twin-pod aero rescue lightbar across Y axis
            hull() {
                for (y_s = [-1, 1]) {
                    translate([0, y_s * 5.8, 2.0])
                        cylinder(d1=8.6, d2=6.4, h=4.8, $fn=8);
                }
            }
            // Central strobe beacon dome
            translate([0, 0, 6.4])
                cylinder(d1=6.8, d2=4.2, h=2.4, $fn=8);
        }
        top_crown_base_cuts(2.4);
        // Hollow underside pockets under left/right lightbar pods
        for (y_s = [-1, 1]) {
            translate([0, y_s * 6.2, 1.8])
                cylinder(d=4.6, h=3.6);
        }
    }
}

// PART 18: Double Row of Diamond Stegosaurus Back Plates
module KODIAK75_Top_DinoStegoPlates() {
    difference() {
        union() {
            top_crown_base_solid(15.8, 2.6);
            // Alternating Left & Right Diamond Stego Dorsal Plates
            for (y_s = [-1, 1]) {
                for (x_i = [-1, 0, 1]) {
                    translate([x_i * 4.2 + (y_s * 0.8), y_s * 2.4, 2.0])
                        rotate([y_s * -14, 0, 0]) {
                            hull() {
                                translate([0, -0.6, 0]) cube([2.6, 1.2, 0.8], center=true);
                                translate([0, -0.6, 4.5]) cube([5.0, 1.2, 1.2], center=true);
                                translate([0, -0.6, 8.8 - abs(x_i)*1.5]) cube([1.8, 1.0, 1.0], center=true);
                            }
                        }
                }
            }
        }
        top_crown_base_cuts(2.6);
    }
}

// ============================================================================
// ZONES 2 & 3: 10 NEW CHEEK SACRIFICIAL POD PAIRS (PART_ID = 19..28)
// ============================================================================

// PART 19: Zig-Zag Lightning Bolt Side Winglets
module single_lightning_bolt(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Zig-zag lightning bolt winglet planform
            hull() {
                translate([4.5, 0, 0]) cylinder(d=4.0, h=1.8);
                translate([-2.0, is_right * 5.5, 0]) cylinder(d=3.6, h=1.8);
            }
            hull() {
                translate([-2.0, is_right * 5.5, 0]) cylinder(d=3.6, h=1.8);
                translate([3.5, is_right * 7.8, 0]) cylinder(d=3.2, h=1.6);
            }
            hull() {
                translate([3.5, is_right * 7.8, 0]) cylinder(d=3.2, h=1.6);
                translate([-7.5, is_right * 12.0, 0]) cylinder(d=2.2, h=2.4);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
    }
}
module KODIAK75_Cheek_LightningBolts() {
    translate([0, -16.0, 0]) single_lightning_bolt(-1);
    translate([0,  16.0, 0]) single_lightning_bolt(1);
}

// PART 20: Scalloped Bat / Gargoyle Membrane Wings
module single_bat_wing(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            hull() {
                translate([-7.5, 0, 0]) cylinder(d=4.0, h=1.6);
                translate([ 7.5, 0, 0]) cylinder(d=4.0, h=1.6);
                translate([ 4.0, is_right * 10.5, 0]) cylinder(d=2.6, h=1.6);
                translate([-7.5, is_right * 11.0, 0]) cylinder(d=2.4, h=1.6);
            }
            // Raised Bat Wing Claw Thumb & Ribs
            hull() {
                translate([3.5, 0, 1.4]) cylinder(d=2.2, h=1.0);
                translate([4.5, is_right * 11.2, 1.4]) cylinder(d=1.8, h=1.2);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // Scalloped bat-membrane cutouts along trailing edge
        for (x_sc = [-5.0, -0.5]) {
            translate([x_sc, is_right * 11.8, -0.1])
                cylinder(d=4.6, h=3.0);
        }
    }
}
module KODIAK75_Cheek_BatWings() {
    translate([0, -16.0, 0]) single_bat_wing(-1);
    translate([0,  16.0, 0]) single_bat_wing(1);
}

// PART 21: Hot-Rod Triple-Lick Flame Side Fins
module single_flame_fin(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            for (f_idx = [-1, 0, 1]) {
                hull() {
                    translate([f_idx * 4.2 + 2.0, 0, 0])
                        cylinder(d=4.2, h=1.8);
                    translate([f_idx * 4.8 - 6.5, is_right * (9.5 - abs(f_idx)*1.8), 0])
                        cylinder(d=2.2, h=2.2);
                }
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
    }
}
module KODIAK75_Cheek_FlameFins() {
    translate([0, -16.0, 0]) single_flame_fin(-1);
    translate([0,  16.0, 0]) single_flame_fin(1);
}

// PART 22: Heater-Style Medieval Knight Shields with raised cross boss
module single_knight_shield(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Heater shield plate
            hull() {
                translate([ 8.0, is_right * 3.5, 0]) cylinder(d=4.6, h=1.8);
                translate([ 8.0, is_right * -3.5, 0]) cylinder(d=4.6, h=1.8);
                translate([-2.0, is_right * 5.0, 0]) cylinder(d=4.0, h=1.8);
                translate([-2.0, is_right * -5.0, 0]) cylinder(d=4.0, h=1.8);
                translate([-10.5, 0, 0]) cylinder(d=2.8, h=1.8);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // Engraved Heraldic Cross Recess on outer face (Z = 0..0.6mm)
        translate([-1.0, 0, -0.1]) cube([14.0, 2.0, 0.7], center=true);
        translate([ 2.5, 0, -0.1]) cube([2.0, 8.0, 0.7], center=true);
    }
}
module KODIAK75_Cheek_KnightShields() {
    translate([0, -16.0, 0]) single_knight_shield(-1);
    translate([0,  16.0, 0]) single_knight_shield(1);
}

// PART 23: Rounded-Tooth Buzzsaw / Gear Bumper Discs
module single_sawblade_bumper(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            translate([0, is_right * 3.5, 0]) {
                cylinder(d=14.8, h=1.8);
                for (t_ang = [0 : 45 : 315]) {
                    rotate([0, 0, t_ang])
                        hull() {
                            translate([5.8, 0, 0]) cylinder(d=2.8, h=1.8);
                            translate([8.4, is_right * 1.4, 0]) cylinder(d=1.8, h=1.8);
                        }
                }
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // Weight-relief cooling holes in sawblade web
        for (h_ang = [45, 135, 225, 315]) {
            translate([0, is_right * 3.5, 0])
                rotate([0, 0, h_ang])
                    translate([4.4, 0, -0.1])
                        cylinder(d=2.4, h=3.0);
        }
    }
}
module KODIAK75_Cheek_SawbladeBumpers() {
    translate([0, -16.0, 0]) single_sawblade_bumper(-1);
    translate([0,  16.0, 0]) single_sawblade_bumper(1);
}

// PART 24: Twin Sci-Fi Starfighter Ion Cannon Pods (blunt safety barrels)
module single_laser_pod(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Outboard weapon pylon
            hull() {
                cylinder(d=7.8, h=2.2);
                translate([0, is_right * 6.0, 0]) cube([10.0, 3.6, 2.2], center=true);
            }
            // Twin parallel blunt-tipped Ion Cannon barrels
            for (y_b = [4.2, 7.8]) {
                hull() {
                    translate([-7.5, is_right * y_b, 1.8])
                        rotate([0, 90, 0])
                            cylinder(d=3.4, h=16.5);
                    translate([0, is_right * y_b, 0])
                        cube([14.0, 2.8, 1.0], center=true);
                }
                // Muzzle flash suppressor ring
                translate([7.0, is_right * y_b, 1.8])
                    rotate([0, 90, 0])
                        cylinder(d=4.2, h=2.0);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
    }
}
module KODIAK75_Cheek_LaserPods() {
    translate([0, -15.0, 0]) single_laser_pod(-1);
    translate([0,  15.0, 0]) single_laser_pod(1);
}

// PART 25: Layered Golden Eagle Feathered Wings
module single_eagle_feather(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // 4 Layered primary flight feathers
            for (f = [0 : 3]) {
                hull() {
                    translate([5.5 - f * 3.2, 0, 0])
                        cylinder(d=3.8, h=2.0 - f * 0.15);
                    translate([1.5 - f * 3.8, is_right * (11.0 - f * 1.4), 0])
                        cylinder(d=2.4, h=1.6);
                }
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
    }
}
module KODIAK75_Cheek_EagleFeathers() {
    translate([0, -16.0, 0]) single_eagle_feather(-1);
    translate([0,  16.0, 0]) single_eagle_feather(1);
}

// PART 26: Hexagonal Energy-Shield Reactive Armor Plates
module single_honeycomb_plate(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // 3-Cell Hexagonal Reactive Armor Cluster
            for (x_c = [-6.5, 0, 6.5]) {
                translate([x_c, is_right * (x_c == 0 ? 3.2 : 1.2), 0])
                    cylinder(d=9.4, h=2.0, $fn=6);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // Recessed hex energy cells on outer face
        for (x_c = [-6.5, 0, 6.5]) {
            translate([x_c, is_right * (x_c == 0 ? 3.2 : 1.2), -0.1])
                cylinder(d=5.8, h=0.9, $fn=6);
        }
    }
}
module KODIAK75_Cheek_HoneycombPlates() {
    translate([0, -15.0, 0]) single_honeycomb_plate(-1);
    translate([0,  15.0, 0]) single_honeycomb_plate(1);
}

// PART 27: Cartoon Mecha / Hulk Smasher Bumper Gloves
module single_monster_fist(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            // Armored wrist gauntlet
            hull() {
                translate([-3.5, 0, 0]) cylinder(d=6.8, h=2.4);
                translate([ 3.5, is_right * 3.5, 0]) cylinder(d=8.4, h=2.8);
            }
            // 4 Sculpted Mecha Knuckle Bumpers forward/outboard
            for (k = [-1.5 : 1 : 1.5]) {
                translate([5.5 - abs(k)*0.8, is_right * (4.2 + k * 2.2), 0])
                    cylinder(d1=3.8, d2=4.4, h=3.2);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // Weight-saving hollow palm recess
        translate([3.5, is_right * 4.2, -0.1])
            cylinder(d=4.8, h=1.6);
    }
}
module KODIAK75_Cheek_MonsterFists() {
    translate([0, -16.0, 0]) single_monster_fist(-1);
    translate([0,  16.0, 0]) single_monster_fist(1);
}

// PART 28: Slotted Hammerhead / Mako Shark Pectoral Fins
module single_shark_gill(is_right=1) {
    difference() {
        union() {
            cheek_hub_solid(2.4);
            hull() {
                translate([ 7.5, 0, 0]) cylinder(d=4.4, h=1.8);
                translate([-7.5, 0, 0]) cylinder(d=3.6, h=1.6);
                translate([-4.5, is_right * 11.5, 0]) cylinder(d=2.6, h=1.6);
            }
        }
        translate([0, 0, 2.4])
            n52_mating_pocket_cut_up();
        // 3 Slotted Bio-Mechanical Shark Gill Vents
        for (x_g = [-2.5, 0.5, 3.5]) {
            translate([x_g, is_right * 4.8, -0.1])
                rotate([0, 0, is_right * 28])
                    cube([1.3, 4.6, 3.0], center=true);
        }
    }
}
module KODIAK75_Cheek_SharkGills() {
    translate([0, -16.0, 0]) single_shark_gill(-1);
    translate([0,  16.0, 0]) single_shark_gill(1);
}

// ============================================================================
// ZONE 4: 8 NEW DUAL-MAGNET BELLY SKID PLATES (PART_ID = 29..36)
// Dual N52 Magnet Sockets + 0.45mm Conical Shear Bosses at X = -18.0 & +18.0mm
// ============================================================================

module belly_dual_bosses_up(z_top=2.4) {
    for (x_pos = [-belly_mag_spacing/2, belly_mag_spacing/2]) {
        translate([x_pos, 0, z_top])
            n52_mating_boss_up();
    }
}

module belly_dual_pockets_cut(z_top=2.4) {
    for (x_pos = [-belly_mag_spacing/2, belly_mag_spacing/2]) {
        translate([x_pos, 0, z_top])
            n52_mating_pocket_cut_up();
    }
}

// PART 29: Ribbed Air-Cushion Hovercraft Bumper Skirt
module KODIAK75_Belly_HoverSkirt() {
    skid_h = 2.4;
    difference() {
        union() {
            // Pill-shaped hovercraft plenum skirt
            hull() {
                translate([-19.0, 0, 0]) cylinder(d1=16.8, d2=14.0, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d1=16.8, d2=14.0, h=skid_h);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Twin air-cushion plenum chambers on bottom (leaves central cross-bridge)
        for (x_c = [-8.0, 8.0]) {
            hull() {
                translate([x_c - 3.5, 0, -0.1]) cylinder(d=8.4, h=1.2);
                translate([x_c + 3.5, 0, -0.1]) cylinder(d=8.4, h=1.2);
            }
        }
        // Central weight-reduction window
        translate([0, 0, -0.1]) cylinder(d=6.8, h=skid_h + 0.2);
    }
}

// PART 30: Mini Armored Tank Tread Dual Pontoons
module KODIAK75_Belly_TankTreads() {
    skid_h = 2.4;
    difference() {
        union() {
            // Central Spine with Dual Magnet Bosses
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.4, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=10.4, h=skid_h);
            }
            // Left & Right Armored Tank Tread Pontoons with grouser cleats
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 6.8, 0]) cylinder(d=3.6, h=skid_h + 0.8);
                    translate([ 20.0, y_s * 6.8, 0]) cylinder(d=3.6, h=skid_h + 0.8);
                }
                for (x_t = [-16 : 8 : 16]) {
                    translate([x_t, y_s * 7.8, 1.6])
                        cube([3.2, 2.4, 3.2], center=true);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}

// PART 31: Twin Upturned Alpine Snow Skis with central bridge
module KODIAK75_Belly_SnowSkis() {
    skid_h = 2.4;
    difference() {
        union() {
            // Central Magnet Mounting Bridge
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            // Cross-Struts to Twin Alpine Skis
            for (x_s = [-18.0, 18.0]) {
                translate([x_s, 0, 0.9])
                    cube([5.2, 16.0, 1.8], center=true);
            }
            // Left & Right Alpine Skis with upturned forward tips
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-22.0, y_s * 7.6, 0]) cylinder(d=3.6, h=1.6);
                    translate([ 20.0, y_s * 7.6, 0]) cylinder(d=3.8, h=1.6);
                }
                hull() {
                    translate([20.0, y_s * 7.6, 0]) cylinder(d=3.8, h=1.6);
                    translate([25.5, y_s * 7.6, 2.2]) cylinder(d=3.0, h=1.4);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}

// PART 32: Twin Stepped Seaplane Pontoon Floats
module KODIAK75_Belly_SeaplaneFloats() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=10.2, h=skid_h);
            }
            for (x_s = [-16.0, 16.0]) {
                translate([x_s, 0, 1.0])
                    cube([5.0, 15.0, 2.0], center=true);
            }
            // Twin Stepped Hydroplane Floats
            for (y_s = [-1, 1]) {
                // Forward planing hull
                hull() {
                    translate([ 0.0, y_s * 7.2, 0]) cylinder(d=4.8, h=2.8);
                    translate([22.0, y_s * 7.2, 0.8]) cylinder(d=2.4, h=2.0);
                }
                // Stepped aft hull
                hull() {
                    translate([-21.0, y_s * 7.2, 0]) cylinder(d=2.8, h=2.0);
                    translate([  0.0, y_s * 7.2, 0]) cylinder(d=4.4, h=2.2);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}

// PART 33: Mini Skateboard Deck with kicktails and faux wheel trucks
module KODIAK75_Belly_SkateboardDeck() {
    skid_h = 2.4;
    difference() {
        union() {
            // Flat center skateboard deck
            hull() {
                translate([-18.5, 0, 0]) cylinder(d=13.6, h=skid_h);
                translate([ 18.5, 0, 0]) cylinder(d=13.6, h=skid_h);
            }
            // Forward & Aft Kicktails + Faux Skateboard Wheels
            for (x_end = [-1, 1]) {
                hull() {
                    translate([x_end * 18.5, 0, 0]) cylinder(d=13.2, h=1.8);
                    translate([x_end * 24.5, 0, 1.2]) cylinder(d=11.0, h=1.6);
                }
                for (y_s = [-1, 1]) {
                    translate([x_end * 13.5, y_s * 7.2, 0])
                        cylinder(d=4.2, h=3.2);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-7.5, 0, 7.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}

// PART 34: Streamlined Longboard Surfboard with twin skeg fins
module KODIAK75_Belly_SurfboardKeel() {
    skid_h = 2.4;
    difference() {
        union() {
            // Pointed Nose + Swallow-Tail Surfboard Planform
            hull() {
                translate([ 25.0, 0, 0]) cylinder(d=3.6, h=1.8);
                translate([  6.0, 0, 0]) cylinder(d=15.2, h=skid_h);
                translate([-18.5, 0, 0]) cylinder(d=11.6, h=skid_h);
                translate([-23.5, -3.2, 0]) cylinder(d=2.8, h=1.8);
                translate([-23.5,  3.2, 0]) cylinder(d=2.8, h=1.8);
            }
            // Twin Aft Skeg Keel Fins
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-13.0, y_s * 4.2, 0]) cylinder(d=2.0, h=3.6);
                    translate([-20.5, y_s * 4.2, 0]) cylinder(d=1.6, h=4.4);
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-7.5, 0, 7.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}

// PART 35: 4-Corner Cyber-Spider / Mech Landing Struts
module KODIAK75_Belly_SpiderLegs() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.6, h=skid_h);
                translate([ 19.0, 0, 0]) cylinder(d=10.6, h=skid_h);
            }
            // 4 Diagonal Cyber-Spider Outrigger Legs with raised foot pads
            for (x_end = [-1, 1]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_end * 17.5, 0, 0]) cylinder(d=4.4, h=skid_h);
                        translate([x_end * 23.5, y_s * 9.5, 0]) cylinder(d=4.6, h=3.6);
                    }
                }
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        for (x_w = [-8.5, 0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}

// PART 36: Venturi Racecar Under-Tray Diffuser with rear exhaust nozzles
module KODIAK75_Belly_AfterburnerDiffuser() {
    skid_h = 2.4;
    difference() {
        union() {
            hull() {
                translate([ 20.0, 0, 0]) cylinder(d=11.6, h=skid_h);
                translate([-19.5, 0, 0]) cylinder(d=15.6, h=skid_h);
            }
            // 3 Aero Venturi Diffuser Strakes along rear under-tray
            for (y_v = [-4.2, 0, 4.2]) {
                translate([-14.0, y_v, 1.8])
                    cube([14.0, 1.4, 3.6], center=true);
            }
            // Twin Rear Afterburner Exhaust Nozzles
            for (y_s = [-1, 1]) {
                translate([-21.5, y_s * 3.8, 1.8])
                    rotate([0, 90, 0])
                        cylinder(d1=5.2, d2=4.2, h=4.5);
            }
            belly_dual_bosses_up(skid_h);
        }
        belly_dual_pockets_cut(skid_h);
        // Hollow exhaust bores
        for (y_s = [-1, 1]) {
            translate([-21.6, y_s * 3.8, 1.8])
                rotate([0, 90, 0])
                    cylinder(d=3.0, h=3.2);
        }
        for (x_w = [-6.5, 1.5, 9.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
        }
    }
}

// ============================================================================
// CLI RENDER DISPATCHER (PART_ID = 1..36)
// ============================================================================
if      (PART_ID == 1)  { KODIAK75_Top_OsitoBearEars(); }
else if (PART_ID == 2)  { KODIAK75_Top_DragonSpikes(); }
else if (PART_ID == 3)  { KODIAK75_Top_MechaCrest(); }
else if (PART_ID == 4)  { KODIAK75_Cheek_SweptWings(); }
else if (PART_ID == 5)  { KODIAK75_Cheek_TurboBoosters(); }
else if (PART_ID == 6)  { KODIAK75_Belly_BearClawSkids(); }
else if (PART_ID == 7)  { KODIAK75_Top_SharkFin(); }
else if (PART_ID == 8)  { KODIAK75_Top_UnicornHorn(); }
else if (PART_ID == 9)  { KODIAK75_Top_VikingHorns(); }
else if (PART_ID == 10) { KODIAK75_Top_RoyalCrown(); }
else if (PART_ID == 11) { KODIAK75_Top_MohawkSpikes(); }
else if (PART_ID == 12) { KODIAK75_Top_BunnyEars(); }
else if (PART_ID == 13) { KODIAK75_Top_CatEars(); }
else if (PART_ID == 14) { KODIAK75_Top_SamuraiKabuto(); }
else if (PART_ID == 15) { KODIAK75_Top_SatelliteDish(); }
else if (PART_ID == 16) { KODIAK75_Top_WizardCone(); }
else if (PART_ID == 17) { KODIAK75_Top_SirenBeacon(); }
else if (PART_ID == 18) { KODIAK75_Top_DinoStegoPlates(); }
else if (PART_ID == 19) { KODIAK75_Cheek_LightningBolts(); }
else if (PART_ID == 20) { KODIAK75_Cheek_BatWings(); }
else if (PART_ID == 21) { KODIAK75_Cheek_FlameFins(); }
else if (PART_ID == 22) { KODIAK75_Cheek_KnightShields(); }
else if (PART_ID == 23) { KODIAK75_Cheek_SawbladeBumpers(); }
else if (PART_ID == 24) { KODIAK75_Cheek_LaserPods(); }
else if (PART_ID == 25) { KODIAK75_Cheek_EagleFeathers(); }
else if (PART_ID == 26) { KODIAK75_Cheek_HoneycombPlates(); }
else if (PART_ID == 27) { KODIAK75_Cheek_MonsterFists(); }
else if (PART_ID == 28) { KODIAK75_Cheek_SharkGills(); }
else if (PART_ID == 29) { KODIAK75_Belly_HoverSkirt(); }
else if (PART_ID == 30) { KODIAK75_Belly_TankTreads(); }
else if (PART_ID == 31) { KODIAK75_Belly_SnowSkis(); }
else if (PART_ID == 32) { KODIAK75_Belly_SeaplaneFloats(); }
else if (PART_ID == 33) { KODIAK75_Belly_SkateboardDeck(); }
else if (PART_ID == 34) { KODIAK75_Belly_SurfboardKeel(); }
else if (PART_ID == 35) { KODIAK75_Belly_SpiderLegs(); }
else if (PART_ID == 36) { KODIAK75_Belly_AfterburnerDiffuser(); }
else {
    color("Goldenrod")   translate([-35,  25, 0]) KODIAK75_Top_OsitoBearEars();
    color("Crimson")     translate([  0,  25, 0]) KODIAK75_Top_DragonSpikes();
    color("RoyalBlue")   translate([ 35,  25, 0]) KODIAK75_Top_MechaCrest();
    color("DarkOrange")  translate([-35, -20, 0]) KODIAK75_Cheek_SweptWings();
    color("MediumPurple")translate([ 35, -20, 0]) KODIAK75_Cheek_TurboBoosters();
    color("SeaGreen")    translate([  0, -55, 0]) KODIAK75_Belly_BearClawSkids();
}
