// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 3: MEGA-1000 CROWNS BATCH A (PART_ID 1001..1200)
// 200 Creative Support-Free Top Crowns (20 Archetypes x 10 Sub-Variations)
// ============================================================================
// Material: TPU 95A (density = 0.00121 g/mm^3)
// Mass Budget: 0.55g .. 1.15g (Volume: 450 .. 950 mm^3)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Universal Zone 1 Conical Shear-Keyway + 2.10x1.20mm N52 Pocket
// ============================================================================

$fn = 24;

PART_ID = 1001;

// --- Universal Zone 1 Mating Constants ---
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;
crown_annular_dia   = 8.40;
crown_annular_depth = 0.45;

// ============================================================================
// UNIVERSAL ZONE 1 TOP CROWN BASE (Z = 0.00mm Flat Bed + Alignment Keyway Rib)
// ============================================================================
module crown_base_a(subvar = 0) {
    base_od = 16.0 + (subvar % 5) * 0.40; // 16.0mm .. 17.6mm
    difference() {
        union() {
            // Outer tapered skirt sitting flat at Z = 0.00mm
            cylinder(d1 = base_od, d2 = 14.2, h = 1.65);
            // Central male conical shear boss
            cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height);
        }
        // 8.40mm x 0.45mm annular recess (difference of d=8.40 minus central boss d=4.80)
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d = 4.80, h = crown_annular_depth + 0.03);
            }
        // Taper relief around central conical shear boss (d1=3.40, d2=2.10, h=0.45)
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = 4.85, h = shear_boss_height + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height + 0.03);
            }
        // 2.10mm x 1.20mm N52 magnet pocket at Z = -0.01
        translate([0, 0, -0.01])
            cylinder(d = mag_pocket_dia, h = 1.25);
    }
    // 6.5mm x 1.2mm x 0.35mm directional alignment keyway rib at X = +4.2mm, Z = 0.45mm
    translate([4.2, 0, 0.45])
        cube([6.5, 1.2, 0.35], center = true);
}

// ============================================================================
// 20 DISTINCT, CREATIVE, SUPPORT-FREE 3D SCULPTURE ARCHETYPES (arch = 0..19)
// All sculptures merge cleanly into Z = 1.40mm top of crown base (<= 45 deg overhang)
// ============================================================================

// arch 0: Totem / Multi-Tier Spire with side wings (varies height, tier taper, wing sweep)
module crown_arch_0(subvar = 0) {
    h_tot = 7.2 + (subvar % 5) * 0.65;
    w_span = 5.4 + (subvar % 4) * 0.55;
    w_sweep = -0.8 + (subvar % 3) * 0.7;
    union() {
        // Tier 1 plinth
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 8.4, h = h_tot * 0.38);
        // Tier 2 carved totem body
        translate([0, 0, 1.40 + h_tot * 0.35])
            cylinder(d1 = 8.8, d2 = 6.2, h = h_tot * 0.38);
        // Tier 3 crown beak / apex
        translate([0, 0, 1.40 + h_tot * 0.70])
            cylinder(d1 = 6.6, d2 = 2.8, h = h_tot * 0.30, $fn = 6);
        // Swept Totem Side Wings (print-safe 45 deg bottom slope)
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.4, 1.40])
                    cylinder(d = 3.2, h = h_tot * 0.65);
                translate([w_sweep, sy * w_span, 1.40 + (w_span - 2.4) * 0.85])
                    cylinder(d1 = 2.4, d2 = 1.4, h = h_tot * 0.32);
            }
        }
    }
}

// arch 1: Twin Antler / Multi-Tine Rack (varies tine count 2..5, spread angle, height)
module crown_arch_1(subvar = 0) {
    tines = 2 + (subvar % 4); // 2..5 tines
    spread = 4.6 + (subvar % 4) * 0.45;
    rack_h = 6.4 + (subvar % 5) * 0.55;
    union() {
        // Central skull brow pedicle
        translate([0, 0, 1.40])
            cylinder(d1 = 10.4, d2 = 7.4, h = 2.6);
        for (sy = [-1, 1]) {
            // Main antler palmation beam
            hull() {
                translate([0, sy * 2.0, 1.40])
                    cylinder(d = 3.6, h = 2.2);
                translate([-0.8, sy * spread, 1.40 + (spread - 1.5) * 0.90])
                    cylinder(d = 3.0, h = 2.4);
            }
            // Multi-tine points rising from palmation
            for (t = [0 : tines - 1]) {
                tx = -2.2 + t * (4.4 / max(1, tines - 1));
                tz = 1.40 + (spread - 1.5) * 0.85 + (t % 2) * 0.5;
                hull() {
                    translate([tx * 0.5, sy * (2.2 + t * 0.4), 1.40 + 1.2])
                        cylinder(d = 2.6, h = 2.0);
                    translate([tx, sy * (spread + 0.3), tz])
                        cylinder(d1 = 2.4, d2 = 1.1, h = rack_h * 0.45);
                }
            }
        }
    }
}

// arch 2: Swept Raptor / Eagle Talon Crest (varies blade sweep, dorsal ridge count)
module crown_arch_2(subvar = 0) {
    ridges = 3 + (subvar % 3); // 3..5 dorsal ridges
    sweep_x = -2.2 - (subvar % 4) * 0.45;
    crest_h = 7.0 + (subvar % 5) * 0.55;
    union() {
        // Aerodynamic raptor crown helm
        hull() {
            translate([1.2, 0, 1.40]) cylinder(d = 9.6, h = 1.8);
            translate([-2.0, 0, 1.40]) cylinder(d = 7.6, h = 1.8);
            translate([sweep_x * 0.5, 0, 1.40 + crest_h * 0.65]) cylinder(d = 4.2, h = 1.6);
        }
        // Swept talon ridges
        for (i = [0 : ridges - 1]) {
            rx = 2.4 - i * (5.2 / max(1, ridges - 1));
            rh = crest_h * (1.0 - i * 0.12);
            hull() {
                translate([rx, 0, 1.40])
                    scale([1.4, 0.75, 1.0]) cylinder(d = 4.2, h = 1.6);
                translate([rx + sweep_x * 0.6, 0, 1.40 + rh])
                    cylinder(d = 1.6, h = 0.8);
            }
        }
    }
}

// arch 3: Stepped Lodge / Pyramid / Ziggurat Dome (varies step count 3..6, top finial)
module crown_arch_3(subvar = 0) {
    steps = 3 + (subvar % 4); // 3..6 steps
    step_h = 1.25 + (subvar % 3) * 0.15;
    sides = (subvar % 2 == 0) ? 8 : 6;
    union() {
        for (s = [0 : steps - 1]) {
            d_bot = 12.6 - s * (7.2 / steps);
            d_top = d_bot - 1.2;
            translate([0, 0, 1.40 + s * step_h])
                rotate([0, 0, s * 15])
                    cylinder(d1 = d_bot, d2 = d_top, h = step_h + 0.15, $fn = sides);
        }
        // Top finial spire
        translate([0, 0, 1.40 + steps * step_h - 0.15])
            cylinder(d1 = 4.8, d2 = 1.8, h = 1.95 + (subvar % 4) * 0.4, $fn = sides);
    }
}

// arch 4: Curved Dual Fang / Tusk / Horn Pair (varies horn pitch, tip twist, brow ridge)
module crown_arch_4(subvar = 0) {
    horn_h = 6.8 + (subvar % 5) * 0.60;
    pitch_x = 1.2 + (subvar % 4) * 0.55;
    span_y = 4.4 + (subvar % 3) * 0.55;
    union() {
        // Armored brow ridge
        hull() {
            translate([1.0, -3.0, 1.40]) cylinder(d = 5.4, h = 2.4);
            translate([1.0,  3.0, 1.40]) cylinder(d = 5.4, h = 2.4);
            translate([-1.5, 0, 1.40]) cylinder(d = 6.8, h = 3.0);
        }
        // Dual curved tusks / horns (2-segment support-free loft)
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.6, 1.40])
                    cylinder(d = 4.4, h = 1.8);
                translate([pitch_x * 0.5, sy * span_y, 1.40 + horn_h * 0.48])
                    cylinder(d = 3.2, h = 1.4);
            }
            hull() {
                translate([pitch_x * 0.5, sy * span_y, 1.40 + horn_h * 0.48])
                    cylinder(d = 3.2, h = 1.4);
                translate([pitch_x, sy * (span_y - 0.6), 1.40 + horn_h])
                    cylinder(d = 1.4, h = 0.8);
            }
        }
    }
}

// arch 5: Pointed Fox / Lynx / Wolf / Cub Ears (varies ear height, tilt, inner hollow pocket)
module crown_arch_5(subvar = 0) {
    ear_h = 6.6 + (subvar % 5) * 0.60;
    tilt_y = 3.8 + (subvar % 4) * 0.40;
    difference() {
        union() {
            // Forehead crown skullcap
            translate([0, 0, 1.40])
                cylinder(d1 = 11.4, d2 = 8.6, h = 2.4);
            // Left & Right pointed ears
            for (sy = [-1, 1]) {
                hull() {
                    translate([0, sy * 2.8, 1.40])
                        scale([1.1, 1.3, 1.0]) cylinder(d = 4.8, h = 1.8);
                    translate([-0.4, sy * tilt_y, 1.40 + ear_h])
                        cylinder(d = 1.5, h = 0.8);
                }
            }
        }
        // Shallow front ear pinna hollows (support-free vertical scoop)
        for (sy = [-1, 1]) {
            hull() {
                translate([2.2, sy * 3.1, 2.8]) sphere(d = 1.8 + (subvar % 3) * 0.25);
                translate([1.6, sy * (tilt_y - 0.2), 1.40 + ear_h * 0.72]) sphere(d = 1.2);
            }
        }
    }
}

// arch 6: Feathered Plume / Fan / Mohawk Array (varies plume count 3..7, fan arc)
module crown_arch_6(subvar = 0) {
    plumes = 3 + (subvar % 5); // 3..7 plumes
    fan_r = 6.8 + (subvar % 4) * 0.50;
    union() {
        // Central plume clasp
        translate([0, 0, 1.40])
            cylinder(d1 = 11.2, d2 = 8.4, h = 2.8);
        // Radial fan of feathers (all rising within <= 42 deg from base)
        for (i = [0 : plumes - 1]) {
            frac = (plumes == 1) ? 0 : (i / (plumes - 1)) * 2.0 - 1.0;
            px = frac * 3.8;
            pz = 1.40 + (fan_r - abs(frac) * 1.8);
            hull() {
                translate([px * 0.55, 0, 1.40])
                    scale([1.0, 0.90, 1.0]) cylinder(d = 4.1, h = 1.8);
                translate([px, 0, pz])
                    scale([1.1, 0.70, 1.0]) cylinder(d = 2.8, h = 1.0);
            }
        }
    }
}

// arch 7: Aero Dorsal Fin / Shark / SailFin (varies fin chord, leading-edge sweep, dorsal notches)
module crown_arch_7(subvar = 0) {
    fin_h = 7.6 + (subvar % 5) * 0.60;
    chord = 9.8 + (subvar % 4) * 0.50;
    notches = 1 + (subvar % 3);
    difference() {
        union() {
            // Streamlined dorsal fairing base
            hull() {
                translate([chord * 0.32, 0, 1.40]) cylinder(d = 5.8, h = 2.2);
                translate([-chord * 0.35, 0, 1.40]) cylinder(d = 5.0, h = 2.2);
                translate([0, 0, 1.40]) cylinder(d = 9.6, h = 2.0);
            }
            // Swept hydro/aero dorsal fin blade
            hull() {
                translate([chord * 0.30, 0, 1.40]) cylinder(d = 3.8, h = 1.8);
                translate([-chord * 0.32, 0, 1.40]) cylinder(d = 3.3, h = 2.4);
                translate([-chord * 0.22, 0, 1.40 + fin_h]) cylinder(d = 2.2, h = 0.8);
                translate([0.5, 0, 1.40 + fin_h * 0.78]) cylinder(d = 2.8, h = 0.8);
            }
        }
        // Trailing-edge hydrodynamic notches (45-deg print-safe cuts)
        for (n = [0 : notches - 1]) {
            translate([-chord * 0.36, 0, 3.2 + n * 1.8])
                rotate([0, 45, 0])
                    cube([1.6, 6.0, 1.6], center = true);
        }
    }
}

// arch 8: Royal / Diadem / Turret Crown Ring (varies turret points 4..8, jewel bosses)
module crown_arch_8(subvar = 0) {
    pts = 4 + (subvar % 5); // 4..8 crown points
    ring_h = 4.6 + (subvar % 4) * 0.45;
    tip_h = ring_h + 2.2 + (subvar % 3) * 0.45;
    difference() {
        union() {
            // Faceted royal band
            translate([0, 0, 1.40])
                cylinder(d1 = 12.2, d2 = 11.2, h = ring_h, $fn = pts * 2);
            // Crown turret spires around perimeter
            for (i = [0 : pts - 1]) {
                ang = i * (360 / pts);
                rotate([0, 0, ang]) {
                    hull() {
                        translate([4.0, 0, 1.40]) cylinder(d = 3.2, h = ring_h);
                        translate([4.3, 0, 1.40 + tip_h]) sphere(d = 1.8);
                    }
                    // Exterior jewel boss
                    translate([5.2, 0, 1.40 + ring_h * 0.50])
                        sphere(d = 2.0);
                }
            }
        }
        // Central royal bowl cavity (tapered flat bottom at Z = 3.2mm)
        translate([0, 0, 3.20])
            cylinder(d1 = 5.4, d2 = 7.4, h = tip_h + 1.0);
    }
}

// arch 9: Curled Ram / Spiral / Nautilus Shell (varies spiral lobes, ridge ribs)
module crown_arch_9(subvar = 0) {
    lobes = 5 + (subvar % 4); // 5..8 spiral chambers
    shell_r = 3.4 + (subvar % 3) * 0.35;
    union() {
        // Central shell saddle
        translate([0, 0, 1.40])
            cylinder(d1 = 11.2, d2 = 8.4, h = 2.8);
        // Golden-ratio nautilus / curled ram lobes rising from base
        for (sy = [-1, 1]) {
            for (k = [0 : lobes - 1]) {
                ang = k * (200 / lobes) - 20;
                rad = 1.8 + k * 0.35;
                lx = rad * cos(ang);
                lz = 2.2 + rad * sin(ang) + k * 0.42;
                ld = 3.0 + k * 0.28;
                hull() {
                    translate([lx * 0.6, sy * 2.2, 1.40])
                        cylinder(d = ld * 0.85, h = 1.6);
                    translate([lx, sy * (2.2 + (subvar % 3) * 0.25), max(2.2, lz)])
                        sphere(d = ld);
                }
            }
        }
    }
}

// arch 10: Ribbed Dome / Burger / Hive / Helmet (varies tier rings, top dome vent)
module crown_arch_10(subvar = 0) {
    tiers = 3 + (subvar % 3); // 3..5 tiers
    dome_h = 5.4 + (subvar % 4) * 0.40;
    difference() {
        union() {
            // Tiered ribbed rings ( <= 45 deg step chamfers )
            for (t = [0 : tiers - 1]) {
                tz = 1.40 + t * (dome_h / tiers);
                td = 11.6 - t * 1.3;
                hull() {
                    translate([0, 0, tz]) cylinder(d = td - 0.8, h = 0.4);
                    translate([0, 0, tz + 0.45]) cylinder(d = td, h = (dome_h / tiers) * 0.55);
                    translate([0, 0, tz + (dome_h / tiers)]) cylinder(d = td - 1.2, h = 0.3);
                }
            }
            // Top rounded cap
            translate([0, 0, 1.40 + dome_h - 0.15])
                cylinder(d1 = 7.8, d2 = 4.0, h = 1.55);
        }
        // Top vent crater
        translate([0, 0, 1.40 + dome_h - 1.2])
            cylinder(d1 = 2.8, d2 = 4.6, h = 3.2);
    }
}

// arch 11: Hydro / Speedboat / Teardrop Streamliner (varies nose cone length, tail strakes)
module crown_arch_11(subvar = 0) {
    len_x = 5.4 + (subvar % 4) * 0.45;
    h_peak = 5.8 + (subvar % 5) * 0.50;
    strakes = 2 + (subvar % 2); // 2..3 tail strakes
    union() {
        // Teardrop canopy fuselage
        hull() {
            translate([len_x * 0.65, 0, 1.40]) cylinder(d = 5.0, h = 1.8);
            translate([0, 0, 1.40]) cylinder(d = 10.4, h = 2.2);
            translate([-len_x * 0.70, 0, 1.40]) cylinder(d = 4.2, h = 1.6);
            translate([-len_x * 0.20, 0, 1.40 + h_peak]) sphere(d = 3.8);
        }
        // Twin/triple rear hydroplane strakes
        for (s = [0 : strakes - 1]) {
            sy = (strakes == 2) ? ((s == 0) ? -2.4 : 2.4) : ((s - 1) * 2.5);
            hull() {
                translate([0, sy, 1.40]) cylinder(d = 2.4, h = 2.0);
                translate([-len_x * 0.75, sy, 1.40 + h_peak * 0.72]) cylinder(d = 1.6, h = 1.2);
            }
        }
    }
}

// arch 12: Radial Quill / Starburst / Sunburst Array (varies radial ray count 5..9, central core)
module crown_arch_12(subvar = 0) {
    rays = 5 + (subvar % 5); // 5..9 radial quills
    ray_h = 6.2 + (subvar % 4) * 0.50;
    ray_r = 5.0 + (subvar % 3) * 0.40;
    union() {
        // Central sunburst core
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 6.4, h = ray_h * 0.82);
        // Radial starburst quills (sloped at <= 42 deg from base)
        for (i = [0 : rays - 1]) {
            ang = i * (360 / rays);
            rotate([0, 0, ang]) {
                hull() {
                    translate([1.8, 0, 1.40]) cylinder(d = 3.0, h = 2.0);
                    translate([ray_r, 0, 1.40 + (ray_r - 1.2) * 1.15])
                        cylinder(d1 = 2.0, d2 = 1.0, h = 1.6);
                }
            }
        }
    }
}

// arch 13: Twin Radar / Periscope / Stalk Pods (varies stalk spacing, dish/orb diameter)
module crown_arch_13(subvar = 0) {
    span_y = 3.4 + (subvar % 4) * 0.35;
    stalk_h = 5.2 + (subvar % 4) * 0.50;
    orb_d = 4.2 + (subvar % 3) * 0.35;
    union() {
        // Central sensor bridge
        hull() {
            translate([0, -2.6, 1.40]) cylinder(d = 6.4, h = 2.4);
            translate([0,  2.6, 1.40]) cylinder(d = 6.4, h = 2.4);
        }
        // Left & Right radar/periscope stalks with 45-deg chamfered pods
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.4, 1.40]) cylinder(d = 3.6, h = 1.8);
                translate([0, sy * span_y, 1.40 + stalk_h]) cylinder(d = 3.0, h = 1.0);
            }
            // Support-free chamfered sensor pod at top of stalk
            translate([0, sy * span_y, 1.40 + stalk_h - 0.4])
                cylinder(d1 = 2.8, d2 = orb_d, h = 1.4);
            translate([0, sy * span_y, 1.40 + stalk_h + 1.0])
                cylinder(d1 = orb_d, d2 = orb_d * 0.65, h = 1.4);
        }
    }
}

// arch 14: Acorn / Mushroom / Cupcake / Chef Toque Cap (varies cap overhang chamfer, stem ribs)
module crown_arch_14(subvar = 0) {
    stem_h = 2.6 + (subvar % 3) * 0.40;
    cap_d = 12.0 + (subvar % 4) * 0.40;
    cap_h = 3.5 + (subvar % 4) * 0.40;
    lobes = 6 + (subvar % 4) * 2;
    union() {
        // Fluted stem
        translate([0, 0, 1.40])
            cylinder(d1 = 10.2, d2 = 8.8, h = stem_h);
        // 45-deg self-supporting cap underside flaring out to cap_d
        translate([0, 0, 1.40 + stem_h - 0.2])
            cylinder(d1 = 8.6, d2 = cap_d, h = (cap_d - 8.6) * 0.55, $fn = lobes);
        // Domed cap crown
        translate([0, 0, 1.40 + stem_h - 0.2 + (cap_d - 8.6) * 0.55])
            cylinder(d1 = cap_d, d2 = 5.2, h = cap_h * 0.65, $fn = lobes);
        // Acorn / cherry top pip
        translate([0, 0, 1.40 + stem_h + (cap_d - 8.6) * 0.55 + cap_h * 0.60])
            cylinder(d1 = 4.8, d2 = 1.8, h = 1.4);
    }
}

// arch 15: Forward-Swept Scythe / Mantis / Cyber Blade (varies twin/single blade geometry)
module crown_arch_15(subvar = 0) {
    blade_h = 7.2 + (subvar % 5) * 0.55;
    fwd_x = 2.8 + (subvar % 4) * 0.45;
    twin = (subvar % 2 == 1);
    union() {
        // Cyber chassis base
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 8.4, h = 2.4);
        for (sy = twin ? [-1, 1] : [0]) {
            y_off = sy * 2.2;
            b_thk = twin ? 2.4 : 3.6;
            // Lower rear-angled strut
            hull() {
                translate([-1.0, y_off, 1.40]) cylinder(d = b_thk + 1.0, h = 1.8);
                translate([-2.2, y_off, 1.40 + blade_h * 0.48]) cylinder(d = b_thk, h = 1.4);
            }
            // Upper forward-swept scythe blade (<= 42 deg overhang)
            hull() {
                translate([1.4, y_off, 1.40]) cylinder(d = b_thk, h = 2.0);
                translate([-2.2, y_off, 1.40 + blade_h * 0.48]) cylinder(d = b_thk, h = 1.4);
                translate([fwd_x, y_off, 1.40 + blade_h]) cylinder(d = b_thk * 0.65, h = 0.8);
            }
        }
    }
}

// arch 16: Rainbow / Stargate / Portal / Horseshoe Arch (varies arch thickness, keystone chevrons)
module crown_arch_16(subvar = 0) {
    arch_h = 6.8 + (subvar % 5) * 0.50;
    arch_w = 4.6 + (subvar % 3) * 0.35;
    chevrons = 3 + (subvar % 3); // 3..5 chevrons
    difference() {
        union() {
            // Portal plinth
            translate([0, 0, 1.40])
                cylinder(d1 = 11.6, d2 = 9.4, h = 2.2);
            // Solid outer arch ring
            hull() {
                for (sy = [-1, 1]) {
                    translate([0, sy * arch_w, 1.40])
                        cylinder(d = 3.4, h = 2.2);
                    translate([0, sy * (arch_w * 0.72), 1.40 + arch_h * 0.65])
                        cylinder(d = 3.2, h = 1.2);
                }
                translate([0, 0, 1.40 + arch_h])
                    cylinder(d = 3.4, h = 1.0);
            }
            // Perimeter keystone chevrons
            for (c = [0 : chevrons - 1]) {
                ang = -65 + c * (130 / max(1, chevrons - 1));
                cy = (arch_w * 0.85) * sin(ang);
                cz = 2.0 + (arch_h * 0.78) * cos(ang);
                translate([0, cy, cz])
                    cube([4.0, 1.4, 1.4], center = true);
            }
        }
        // Pointed Gothic / Stargate portal window (45-deg self-supporting roof apex!)
        hull() {
            translate([0, -1.6, 3.0]) rotate([0, 90, 0]) cylinder(d = 1.4, h = 10.0, center = true);
            translate([0,  1.6, 3.0]) rotate([0, 90, 0]) cylinder(d = 1.4, h = 10.0, center = true);
            translate([0,  0.0, 3.0 + arch_h * 0.42]) rotate([0, 90, 0]) cylinder(d = 1.0, h = 10.0, center = true);
        }
    }
}

// arch 17: Hex Crystal / Geode / Prism Cluster (varies crystal pillar count 3..6, facet angles)
module crown_arch_17(subvar = 0) {
    pillars = 3 + (subvar % 4); // 3..6 crystal pillars
    c_height = 7.8 + (subvar % 5) * 0.55;
    union() {
        // Central tallest hex crystal prism
        translate([0, 0, 1.40])
            rotate([0, 0, subvar * 15])
                cylinder(d1 = 8.0, d2 = 5.2, h = c_height * 0.75 + 0.15, $fn = 6);
        translate([0, 0, 1.40 + c_height * 0.75])
            rotate([0, 0, subvar * 15])
                cylinder(d1 = 5.2, d2 = 1.0, h = c_height * 0.25, $fn = 6);
        // Surrounding angled crystal shards
        for (i = [0 : pillars - 1]) {
            ang = i * (360 / pillars) + 25;
            sh = c_height * (0.58 + (i % 2) * 0.15);
            rotate([0, 0, ang]) {
                hull() {
                    translate([2.2, 0, 1.40])
                        cylinder(d = 4.8, h = 1.8, $fn = 6);
                    translate([3.8, 0, 1.40 + sh])
                        cylinder(d = 1.8, h = 0.8, $fn = 6);
                }
            }
        }
    }
}

// arch 18: Pine Cone / Pineapple / Pagoda Multi-Scale Spire (varies scale tiers 3..6)
module crown_arch_18(subvar = 0) {
    tiers = 3 + (subvar % 4); // 3..6 tiers
    spire_h = 6.8 + (subvar % 5) * 0.55;
    union() {
        for (t = [0 : tiers - 1]) {
            tz = 1.40 + t * (spire_h / tiers);
            td = 12.0 - t * (5.4 / tiers);
            // 45-degree upward-flaring pagoda/pinecone scale ring
            translate([0, 0, tz - 0.10])
                rotate([0, 0, t * 22.5])
                    cylinder(d1 = td * 0.78, d2 = td, h = (spire_h / tiers) * 0.55 + 0.15, $fn = 8);
            translate([0, 0, tz + (spire_h / tiers) * 0.55 - 0.05])
                rotate([0, 0, t * 22.5])
                    cylinder(d1 = td, d2 = td * 0.68, h = (spire_h / tiers) * 0.50 + 0.10, $fn = 8);
        }
        // Top crown tuft
        translate([0, 0, 1.40 + spire_h - 0.15])
            cylinder(d1 = 4.8, d2 = 1.6, h = 1.75, $fn = 8);
    }
}

// arch 19: Twin Summit / V-Crest / Mecha Antenna (varies V-angle, center crest gem)
module crown_arch_19(subvar = 0) {
    v_h = 7.2 + (subvar % 5) * 0.60;
    v_span = 4.6 + (subvar % 4) * 0.45;
    gem_h = 4.4 + (subvar % 3) * 0.55;
    union() {
        // Central mecha forehead gem / summit ridge
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 5.4, h = gem_h, $fn = 6);
        // Twin V-fin mecha antennas / mountain peaks
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 1.8, 1.40])
                    scale([1.2, 0.85, 1.0]) cylinder(d = 3.8, h = 2.0);
                translate([-0.6, sy * v_span, 1.40 + v_h])
                    cylinder(d = 1.8, h = 0.8);
            }
            // Side cheek guard finlet
            hull() {
                translate([0.8, sy * 2.8, 1.40]) cylinder(d = 3.0, h = 1.6);
                translate([0.4, sy * (v_span * 0.78), 1.40 + v_h * 0.52]) cylinder(d = 2.0, h = 1.0);
            }
        }
    }
}

// ============================================================================
// MASTER DISPATCHER FOR CROWNS BATCH A (PART_ID = 1001..1200)
// ============================================================================
module KODIAK75_Mega1000_Crown_A(part_id = 1001) {
    idx    = part_id - 1001;
    arch   = idx % 20;
    subvar = floor(idx / 20);

    union() {
        crown_base_a(subvar);
        if      (arch == 0)  crown_arch_0(subvar);
        else if (arch == 1)  crown_arch_1(subvar);
        else if (arch == 2)  crown_arch_2(subvar);
        else if (arch == 3)  crown_arch_3(subvar);
        else if (arch == 4)  crown_arch_4(subvar);
        else if (arch == 5)  crown_arch_5(subvar);
        else if (arch == 6)  crown_arch_6(subvar);
        else if (arch == 7)  crown_arch_7(subvar);
        else if (arch == 8)  crown_arch_8(subvar);
        else if (arch == 9)  crown_arch_9(subvar);
        else if (arch == 10) crown_arch_10(subvar);
        else if (arch == 11) crown_arch_11(subvar);
        else if (arch == 12) crown_arch_12(subvar);
        else if (arch == 13) crown_arch_13(subvar);
        else if (arch == 14) crown_arch_14(subvar);
        else if (arch == 15) crown_arch_15(subvar);
        else if (arch == 16) crown_arch_16(subvar);
        else if (arch == 17) crown_arch_17(subvar);
        else if (arch == 18) crown_arch_18(subvar);
        else if (arch == 19) crown_arch_19(subvar);
    }
}

if (PART_ID >= 1001 && PART_ID <= 1200) {
    KODIAK75_Mega1000_Crown_A(PART_ID);
}