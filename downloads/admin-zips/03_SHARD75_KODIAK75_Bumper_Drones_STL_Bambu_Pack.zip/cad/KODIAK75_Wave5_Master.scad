// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 5: 261 STEM ACADEMY EXPANSION PARTS
// PART_ID = 3001..3261 (100 Crowns + 84 Cheek Pod Pairs + 77 Belly Skids)
// Cumulative Total: 2,239 (Waves 0-4) + 261 (Wave 5) = 2,500 Total Parts!
// Total Loadout Combinations: 996 Crowns x 867 Cheeks x 637 Belly = 550,069,884
// ============================================================================
// Wave 5 reuses the proven Wave 4 geometry modules at subvariation ranges that
// Wave 4 never used, so every part is a new parameter combination and keeps the
// Universal Magnetic & Conical Shear-Keyway Standard (support-free TPU 95A).
//   Crowns  3001..3100 -> Wave4 Crown_B  archetypes, subvar 20..24
//   Cheeks  3101..3184 -> Wave4 Cheek_B  archetypes, subvar 25..30
//   Belly   3185..3261 -> Wave4 Belly    archetypes, subvar 25..33
// Usage: openscad -D "PART_ID=3001" -o out.stl KODIAK75_Wave5_Master.scad
// ============================================================================

PART_ID = 3001;

use <KODIAK75_Wave4_Crowns_B.scad>
use <KODIAK75_Wave4_Cheeks_B.scad>
use <KODIAK75_Wave4_Belly.scad>

module render_wave5_object(part_id) {
    if (part_id >= 3001 && part_id <= 3100) {
        i = part_id - 3001;
        KODIAK75_Wave4_Crown_B(2001 + 20 * (20 + floor(i / 20)) + (i % 20));
    } else if (part_id >= 3101 && part_id <= 3184) {
        i = part_id - 3101;
        render_wave4_cheek_pair_b(2401 + 14 * (25 + floor(i / 14)) + (i % 14));
    } else if (part_id >= 3185 && part_id <= 3261) {
        // virtual id keeps arch == (part_id - 2751) % 10 for the web previews
        render_wave4_belly(part_id - 179);
    }
}

render_wave5_object(PART_ID);