// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: TOP CANOPY CROWNS BATCH A (PART_ID 2001..2200)
// 200 Distinct Support-Free Top Crowns (20 Creative World Archetypes x 10 Subvars)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.55g .. 1.15g (Volume: 450 .. 950 mm^3)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Universal Zone 1 Conical Shear-Keyway + 2.10x1.20mm N52 Pocket
// ============================================================================

$fn = 24;

PART_ID = 2001;

// --- Universal Zone 1 Mating Constants ---
mag_pocket_dia      = 2.10;
mag_pocket_depth    = 1.20;
shear_boss_dia1     = 3.40;
shear_boss_dia2     = 2.10;
shear_boss_height   = 0.45;
crown_annular_dia   = 8.40;
crown_annular_depth = 0.45;

// ============================================================================
// UNIVERSAL ZONE 1 TOP CROWN BASE (Z = 0.00mm Flat Bed + Alignment Keyway Rib)
// ============================================================================
module crown_base_w4_a(subvar = 0) {
    base_od = 16.0 + (subvar % 5) * 0.40;
    difference() {
        union() {
            cylinder(d1 = base_od, d2 = 14.2, h = 1.65);
            cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height);
        }
        // Annular locking ring groove
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d = 4.80, h = crown_annular_depth + 0.03);
            }
        // Shear ring counter-groove
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = 4.85, h = shear_boss_height + 0.01);
                translate([0, 0, -0.01])
                    cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1, h = shear_boss_height + 0.03);
            }
        // Central NdFeB N52 disc magnet pocket
        translate([0, 0, -0.01])
            cylinder(d = mag_pocket_dia, h = 1.25);
    }
    // Restored Zone 1 keyway directional alignment rib (6.5 x 1.2 x 0.35 mm at X = +4.2mm, Z = 0.45mm)
    // with 45-degree chamfered lead-in at inner and outer mating tips
    difference() {
        translate([4.2, 0, 0.45])
            hull() {
                cube([6.5 - 0.70, 1.20, 0.35], center = true);
                cube([6.5, 1.20 - 0.70, 0.35], center = true);
            }
        // Ensure center magnet pocket clearance
        translate([0, 0, -0.01])
            cylinder(d = mag_pocket_dia, h = 1.25);
    }
}

// ============================================================================
// 20 DISTINCT CREATIVE WORLD ARCHETYPES FOR BATCH A (arch = 0..19, subvar = 0..9)
// All sculptures sit on top of crown base (Z = 1.40mm) with support-free draft angles <= 45 deg
// ============================================================================

// ARCH 0: Cyber Mecha & Gundam (V-Fin Antennas, Thruster Cowl, Forehead Gem)
module crown_w4_a_arch_0(subvar = 0) {
    v_span = 5.2 + (subvar % 4) * 0.55;
    v_h    = 6.8 + (subvar % 3) * 0.65;
    gem_d  = 4.6 + (subvar % 3) * 0.4;
    union() {
        // Central mecha helmet cowl / brow
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 6.2, h = 3.2, $fn = 6);
        // Forehead crest gem
        translate([1.2, 0, 2.4])
            scale([1.2, 0.8, 1.0])
                cylinder(d1 = gem_d, d2 = 1.8, h = v_h * 0.45 + 1.4, $fn = 4);
        // Twin V-Fin antenna wings
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 1.8, 1.40])
                    cylinder(d = 3.4, h = 2.2);
                translate([-0.6, sy * v_span, 1.40 + v_h])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
            // Side cheek deflector fin
            hull() {
                translate([1.0, sy * 2.8, 1.40])
                    cylinder(d = 2.8, h = 1.8);
                translate([0.5, sy * (v_span * 0.75), 1.40 + v_h * 0.55])
                    cylinder(d1 = 2.0, d2 = 1.0, h = 1.0);
            }
        }
    }
}

// ARCH 1: Cyberpunk Neon & Street Racer (Sunburst Ridge Spire)
module crown_w4_a_arch_1(subvar = 0) {
    n_spikes = 4 + (subvar % 3);
    sun_r    = 3.0 + (subvar % 3) * 0.20;
    sun_h    = 6.8 + (subvar % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.6, h = 2.4);
        translate([0, 0, 3.2])
            cylinder(d1 = 7.2, d2 = 4.6, h = 2.4);
        for (i = [0 : n_spikes - 1]) {
            ang = -60 + i * (120 / max(1, n_spikes - 1));
            rotate([0, 0, ang]) {
                hull() {
                    translate([2.2, 0, 1.40])
                        cylinder(d1 = 2.0, d2 = 1.4, h = 1.8);
                    translate([sun_r, 0, 3.2 + sun_h * 0.55])
                        cylinder(d1 = 1.0, d2 = 0.3, h = 1.0);
                }
            }
        }
        translate([0, 0, 3.4])
            cylinder(d1 = 4.8, d2 = 1.6, h = sun_h * 0.65);
    }
}

// ARCH 2: Anime & Martial Arts (Super Saiyan Hair Spikes, Chakra Halo)
module crown_w4_a_arch_2(subvar = 0) {
    n_locks = 4 + (subvar % 3);
    h_hair  = 7.2 + (subvar % 4) * 0.6;
    sweep   = -1.2 + (subvar % 3) * 0.4;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 8.0, h = 2.6);
        for (i = [0 : n_locks - 1]) {
            ang = i * (360 / n_locks);
            rotate([0, 0, ang]) {
                hull() {
                    translate([2.2, 0, 1.40])
                        cylinder(d1 = 3.6, d2 = 2.4, h = 2.4);
                    translate([3.0 + sweep, 0, 1.40 + h_hair * 0.85])
                        cylinder(d1 = 1.4, d2 = 0.4, h = 1.2);
                    translate([3.0 + sweep, 0, 1.40 + h_hair * 0.85 - 1.0])
                        cylinder(d1 = 0.2, d2 = 1.4, h = 1.0);
                }
            }
        }
        translate([0, 0, 3.8])
            cylinder(d1 = 4.8, d2 = 1.6, h = h_hair * 0.6, $fn = 5);
    }
}

// ARCH 3: Viking & Norse Runes (Valkyrie Wings, Horn Spikes, Runic Plinth)
module crown_w4_a_arch_3(subvar = 0) {
    wing_span = 5.8 + (subvar % 4) * 0.5;
    wing_h    = 7.0 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 7.8, h = 2.8, $fn = 8);
        for (sy = [-1, 1]) {
            // Feathered wing blade
            hull() {
                translate([0, sy * 2.2, 1.40])
                    cylinder(d = 3.6, h = 2.2);
                translate([-1.2, sy * wing_span, 1.40 + wing_h])
                    cylinder(d1 = 2.4, d2 = 1.0, h = 1.4);
            }
            // Secondary wing barb
            hull() {
                translate([1.2, sy * 2.6, 1.40])
                    cylinder(d = 2.8, h = 1.8);
                translate([0.6, sy * (wing_span * 0.7), 1.40 + wing_h * 0.6])
                    cylinder(d1 = 2.0, d2 = 0.9, h = 1.0);
            }
        }
        // Center Mjolnir hammer boss
        translate([0, 0, 3.8])
            cylinder(d1 = 5.4, d2 = 3.2, h = 3.2, $fn = 6);
    }
}

// ARCH 4: Egyptian Pharaoh (Anubis Jackal Ears, Nemes Headdress Flaps)
module crown_w4_a_arch_4(subvar = 0) {
    ear_h    = 7.4 + (subvar % 4) * 0.55;
    ear_span = 4.8 + (subvar % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.4, h = 2.6);
        for (sy = [-1, 1]) {
            // Pointed jackal ear
            hull() {
                translate([0.5, sy * 2.2, 1.40])
                    cylinder(d = 3.4, h = 2.2);
                translate([-0.5, sy * ear_span, 1.40 + ear_h])
                    cylinder(d1 = 2.4, d2 = 0.8, h = 1.2);
            }
            // Nemes shroud rib
            hull() {
                translate([-1.8, sy * 2.6, 1.40])
                    cylinder(d = 2.6, h = 1.6);
                translate([-2.4, sy * (ear_span * 0.85), 1.40 + ear_h * 0.45])
                    cylinder(d1 = 2.2, d2 = 1.2, h = 1.0);
            }
        }
        // Central Uraeus cobra crest
        translate([1.8, 0, 3.2])
            cylinder(d1 = 4.2, d2 = 1.8, h = ear_h * 0.55, $fn = 7);
    }
}

// ARCH 5: Roman Gladiator (Centurion Horsehair Plume, Colosseum Arches)
module crown_w4_a_arch_5(subvar = 0) {
    plume_len = 8.8 + (subvar % 4) * 0.6;
    plume_h   = 6.5 + (subvar % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.5);
        // Centurion longitudinal crest ridge
        hull() {
            translate([-plume_len * 0.45, 0, 1.40])
                cylinder(d = 3.2, h = plume_h * 0.5);
            translate([ plume_len * 0.45, 0, 1.40])
                cylinder(d = 3.2, h = plume_h * 0.5);
            translate([0, 0, 1.40 + plume_h])
                cylinder(d1 = 3.6, d2 = 1.4, h = 1.8);
        }
        // Side guard flanges
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.6, 1.40])
                    cylinder(d = 3.0, h = 2.0);
                translate([0, sy * 4.6, 1.40 + plume_h * 0.45])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 6: Pirate Buccaneers (Jolly Roger Skull Brow, Crossbone Fins)
module crown_w4_a_arch_6(subvar = 0) {
    bone_span = 5.2 + (subvar % 4) * 0.5;
    skull_d   = 6.2 + (subvar % 3) * 0.4;
    h_crest   = 6.2 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.6);
        // Skull dome
        translate([0.5, 0, 3.4])
            cylinder(d1 = skull_d, d2 = skull_d * 0.5, h = h_crest * 0.65, $fn = 8);
        // Crossed cutlass / bone side tips
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.0, 1.40])
                    cylinder(d = 3.2, h = 2.0);
                translate([-1.2, sy * bone_span, 1.40 + h_crest * 0.75])
                    cylinder(d1 = 2.4, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 7: Extreme Storms & Weather (Lightning Fork, Tornado Vortex Funnel)
module crown_w4_a_arch_7(subvar = 0) {
    vortex_h = 7.2 + (subvar % 4) * 0.55;
    twist_r  = 4.2 + (subvar % 3) * 0.35;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.2, h = 2.4);
        for (i = [0 : 3]) {
            rotate([0, 0, i * 90]) {
                hull() {
                    translate([twist_r * 0.45, 0, 1.40])
                        cylinder(d1 = 3.4, d2 = 2.2, h = 2.0);
                    translate([twist_r, 0, 1.40 + vortex_h * 0.75])
                        cylinder(d1 = 1.4, d2 = 0.6, h = 1.2);
                    translate([twist_r, 0, 1.40 + vortex_h * 0.75 - 1.0])
                        cylinder(d1 = 0.2, d2 = 1.4, h = 1.0);
                }
            }
        }
        translate([0, 0, 3.4])
            cylinder(d1 = 4.6, d2 = 2.0, h = vortex_h * 0.65, $fn = 6);
    }
}

// ARCH 8: Jungle Apex Predators (Jaguar Fangs, Predator Crest Spikes)
module crown_w4_a_arch_8(subvar = 0) {
    fang_span = 4.8 + (subvar % 4) * 0.45;
    fang_h    = 6.8 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.6);
        for (sy = [-1, 1]) {
            // Curved predatory fang
            hull() {
                translate([0.8, sy * 2.0, 1.40])
                    cylinder(d = 3.4, h = 2.2);
                translate([1.8, sy * fang_span, 1.40 + fang_h])
                    cylinder(d1 = 2.4, d2 = 0.8, h = 1.2);
            }
            // Back jaw ridge
            hull() {
                translate([-1.8, sy * 2.4, 1.40])
                    cylinder(d = 2.8, h = 1.8);
                translate([-2.4, sy * (fang_span * 0.75), 1.40 + fang_h * 0.5])
                    cylinder(d1 = 2.0, d2 = 1.0, h = 1.0);
            }
        }
        // Forehead prowler gem
        translate([0, 0, 3.6])
            cylinder(d1 = 5.0, d2 = 2.0, h = fang_h * 0.55, $fn = 5);
    }
}

// ARCH 9: Deep Space & Astronomy (Saturn Rings, Accretion Disc)
module crown_w4_a_arch_9(subvar = 0) {
    ring_od = 11.2 + (subvar % 4) * 0.35;
    tilt_h  = 6.2 + (subvar % 3) * 0.55;
    union() {
        // Conical supporting cowl extending up to disc diameter (eliminates horizontal downward step)
        translate([0, 0, 1.40])
            cylinder(d1 = 12.0, d2 = ring_od, h = 1.8);
        translate([0, 0, 3.2])
            cylinder(d = ring_od, h = 0.65);
        translate([0, 0, 3.4])
            sphere(d = 4.4);
        translate([0, 0, 3.8])
            cylinder(d1 = 3.6, d2 = 1.4, h = tilt_h * 0.55);
    }
}

// ARCH 10: Quantum Physics (Orbital Electron Lobes, Nucleus Core)
module crown_w4_a_arch_10(subvar = 0) {
    lobe_r = 3.8 + (subvar % 3) * 0.35;
    core_h = 6.4 + (subvar % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.6, h = 2.5);
        translate([0, 0, 3.8])
            cylinder(d1 = 5.6, d2 = 1.6, h = core_h * 0.6);
        for (i = [0 : 3]) {
            rotate([0, 0, i * 90 + (subvar % 3) * 15]) {
                hull() {
                    translate([lobe_r * 0.45, 0, 1.40])
                        cylinder(d1 = 3.4, d2 = 2.2, h = 2.2);
                    translate([lobe_r, 0, 1.40 + core_h * 0.75])
                        cylinder(d1 = 1.4, d2 = 0.6, h = 1.2);
                    translate([lobe_r, 0, 1.40 + core_h * 0.75 - 1.0])
                        cylinder(d1 = 0.2, d2 = 1.4, h = 1.0);
                }
            }
        }
    }
}

// ARCH 11: Heavy Industry (Excavator Teeth, Crane Jib, Dozer Blade)
module crown_w4_a_arch_11(subvar = 0) {
    blade_w = 6.4 + (subvar % 4) * 0.45;
    jib_h   = 6.8 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.2, h = 2.4, $fn = 6);
        for (sx = [-1, 1]) {
            hull() {
                // Grounded at Z = 1.40 directly on base plinth
                translate([sx * 2.8, 0, 1.40])
                    cylinder(d1 = 3.2, d2 = 2.0, h = 2.0);
                translate([sx * (blade_w * 0.45), 0, 1.40 + jib_h * 0.70])
                    cylinder(d1 = 1.4, d2 = 0.8, h = 1.2);
            }
        }
        translate([0, 0, 3.4])
            cylinder(d1 = 5.2, d2 = 2.2, h = jib_h * 0.65, $fn = 4);
    }
}

// ARCH 12: Emergency Rescue & Fire (Fire Chief Crest, Siren Beacon Array)
module crown_w4_a_arch_12(subvar = 0) {
    siren_h = 6.8 + (subvar % 4) * 0.55;
    beacon_d = 5.2 + (subvar % 3) * 0.45;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.6, h = 2.5);
        // Siren beacon dome
        translate([0, 0, 3.4])
            cylinder(d1 = beacon_d, d2 = beacon_d * 0.6, h = siren_h * 0.65, $fn = 8);
        // Shield badge brow
        translate([2.2, 0, 3.0])
            scale([1.0, 0.75, 1.0])
                cylinder(d1 = 4.2, d2 = 1.6, h = siren_h * 0.45, $fn = 3);
        // Side lightbar flashers
        for (sy = [-1, 1]) {
            translate([0, sy * 3.8, 1.40])
                cylinder(d1 = 3.2, d2 = 1.6, h = siren_h * 0.55);
        }
    }
}

// ARCH 13: Retro 80s Synthwave (Turntable Disc, Equalizer Columns)
module crown_w4_a_arch_13(subvar = 0) {
    disc_od = 9.8 + (subvar % 3) * 0.30;
    col_h   = 6.2 + (subvar % 4) * 0.55;
    union() {
        // Conical supporting cowl matching disc_od at Z = 3.2
        translate([0, 0, 1.40])
            cylinder(d1 = 11.2, d2 = disc_od, h = 1.8);
        translate([0, 0, 3.2])
            cylinder(d = disc_od, h = 0.65);
        for (i = [0 : 3]) {
            translate([cos(i * 90) * 2.4, sin(i * 90) * 2.4, 3.2])
                cylinder(d1 = 2.2, d2 = 1.2, h = col_h * 0.55 + (subvar % 3) * 0.35, $fn = 6);
        }
        translate([0, 0, 3.8])
            cylinder(d1 = 3.6, d2 = 1.6, h = 2.2);
    }
}

// ARCH 14: Bakery & French Pastry (Croissant Horns, Macaron Tier Crown)
module crown_w4_a_arch_14(subvar = 0) {
    horn_span = 5.4 + (subvar % 4) * 0.45;
    pastry_h  = 6.4 + (subvar % 3) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.8, h = 2.4);
        // Macaron rounded cake tiers
        translate([0, 0, 3.2])
            cylinder(d1 = 6.8, d2 = 4.6, h = 2.2);
        translate([0, 0, 4.8])
            cylinder(d1 = 5.0, d2 = 2.2, h = pastry_h * 0.55);
        // Curved croissant horn tips
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.2, 1.40])
                    cylinder(d = 3.2, h = 2.0);
                translate([-1.2, sy * horn_span, 1.40 + pastry_h * 0.7])
                    cylinder(d1 = 2.4, d2 = 1.2, h = 1.2);
            }
        }
    }
}

// ARCH 15: Drive-In Diner Classics (Milkshake Swirl, Retro Fin Wings)
module crown_w4_a_arch_15(subvar = 0) {
    swirl_h = 7.2 + (subvar % 4) * 0.55;
    fin_w   = 5.2 + (subvar % 3) * 0.5;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 7.6, h = 2.4);
        // Soft-serve swirl cone
        translate([0, 0, 3.2])
            cylinder(d1 = 6.6, d2 = 2.0, h = swirl_h * 0.7, $fn = 7);
        // 50s Cadillac tailfin wings
        for (sy = [-1, 1]) {
            hull() {
                translate([-1.0, sy * 2.4, 1.40])
                    cylinder(d = 3.0, h = 2.0);
                translate([-2.4, sy * fin_w, 1.40 + swirl_h * 0.65])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 16: Olympian Gods & Titans (Zeus Lightning Trident, Crown Coronet)
module crown_w4_a_arch_16(subvar = 0) {
    tri_span = 5.0 + (subvar % 4) * 0.45;
    tri_h    = 7.4 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6, $fn = 8);
        // Center trident prong
        translate([0, 0, 3.4])
            cylinder(d1 = 4.4, d2 = 1.6, h = tri_h * 0.68, $fn = 6);
        // Left & right trident barb prongs
        for (sy = [-1, 1]) {
            hull() {
                translate([0, sy * 2.0, 1.40])
                    cylinder(d = 3.0, h = 2.0);
                translate([0, sy * tri_span, 1.40 + tri_h * 0.85])
                    cylinder(d1 = 2.2, d2 = 0.9, h = 1.4);
            }
        }
    }
}

// ARCH 17: Biomorphic Arthropods (Hercules Beetle Horn, Mandible Scythes)
module crown_w4_a_arch_17(subvar = 0) {
    horn_len = 6.4 + (subvar % 4) * 0.55;
    horn_h   = 7.0 + (subvar % 3) * 0.6;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.6, d2 = 7.4, h = 2.6);
        // Forward arching beetle horn
        hull() {
            translate([0, 0, 1.40])
                cylinder(d = 4.2, h = 2.2);
            translate([horn_len * 0.6, 0, 1.40 + horn_h])
                cylinder(d1 = 2.6, d2 = 1.0, h = 1.4);
        }
        // Lateral pincer pincers
        for (sy = [-1, 1]) {
            hull() {
                translate([0.5, sy * 2.2, 1.40])
                    cylinder(d = 3.0, h = 2.0);
                translate([1.2, sy * 4.6, 1.40 + horn_h * 0.55])
                    cylinder(d1 = 2.2, d2 = 1.0, h = 1.2);
            }
        }
    }
}

// ARCH 18: Geology & Minerals (Bismuth Crystal Hopper Steps, Pyrite Cube)
module crown_w4_a_arch_18(subvar = 0) {
    step_w = 8.6 + (subvar % 4) * 0.35;
    step_h = 6.6 + (subvar % 3) * 0.6;
    union() {
        // Monotonically contracting steps (no tier extends past previous tier's top)
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 8.6, h = 1.8, $fn = 4);
        translate([0, 0, 3.2])
            cylinder(d1 = 8.6, d2 = step_w * 0.72, h = 1.6, $fn = 4);
        translate([0, 0, 4.8])
            cylinder(d1 = step_w * 0.72, d2 = step_w * 0.44, h = 1.6, $fn = 4);
        translate([0, 0, 6.4])
            cylinder(d1 = step_w * 0.44, d2 = 1.8, h = step_h * 0.35, $fn = 4);
    }
}

// ARCH 19: AI & Cybernetic Future (Neural Mesh Dome, Optical Sensor Eye)
module crown_w4_a_arch_19(subvar = 0) {
    eye_d   = 5.6 + (subvar % 3) * 0.45;
    mesh_h  = 6.6 + (subvar % 4) * 0.55;
    union() {
        translate([0, 0, 1.40])
            cylinder(d1 = 10.8, d2 = 8.0, h = 2.6, $fn = 8);
        // Optical sensor eyeball turret
        translate([0.8, 0, 3.4])
            cylinder(d1 = eye_d, d2 = eye_d * 0.6, h = mesh_h * 0.55, $fn = 8);
        // Cybernetic data antennas
        for (sy = [-1, 1]) {
            hull() {
                translate([-1.2, sy * 2.2, 1.40])
                    cylinder(d = 2.8, h = 1.8);
                translate([-2.0, sy * 4.6, 1.40 + mesh_h * 0.75])
                    cylinder(d1 = 2.0, d2 = 0.8, h = 1.2);
            }
        }
        // Dorsal heat heatsink ribs
        for (xs = [-2, 0, 2]) {
            translate([xs, 0, 3.6])
                cube([0.8, 4.6, 1.6], center = true);
        }
    }
}

// ============================================================================
// MASTER DISPATCHER FOR CROWNS BATCH A (PART_ID = 2001..2200)
// ============================================================================
module KODIAK75_Wave4_Crown_A(part_id = 2001) {
    idx    = part_id - 2001;
    arch   = idx % 20;
    subvar = floor(idx / 20); // 0..9 for 2001..2200

    union() {
        crown_base_w4_a(subvar);
        if      (arch ==  0) crown_w4_a_arch_0(subvar);
        else if (arch ==  1) crown_w4_a_arch_1(subvar);
        else if (arch ==  2) crown_w4_a_arch_2(subvar);
        else if (arch ==  3) crown_w4_a_arch_3(subvar);
        else if (arch ==  4) crown_w4_a_arch_4(subvar);
        else if (arch ==  5) crown_w4_a_arch_5(subvar);
        else if (arch ==  6) crown_w4_a_arch_6(subvar);
        else if (arch ==  7) crown_w4_a_arch_7(subvar);
        else if (arch ==  8) crown_w4_a_arch_8(subvar);
        else if (arch ==  9) crown_w4_a_arch_9(subvar);
        else if (arch == 10) crown_w4_a_arch_10(subvar);
        else if (arch == 11) crown_w4_a_arch_11(subvar);
        else if (arch == 12) crown_w4_a_arch_12(subvar);
        else if (arch == 13) crown_w4_a_arch_13(subvar);
        else if (arch == 14) crown_w4_a_arch_14(subvar);
        else if (arch == 15) crown_w4_a_arch_15(subvar);
        else if (arch == 16) crown_w4_a_arch_16(subvar);
        else if (arch == 17) crown_w4_a_arch_17(subvar);
        else if (arch == 18) crown_w4_a_arch_18(subvar);
        else if (arch == 19) crown_w4_a_arch_19(subvar);
    }
}

if (PART_ID >= 2001 && PART_ID <= 2200) {
    KODIAK75_Wave4_Crown_A(PART_ID);
} else {
    KODIAK75_Wave4_Crown_A(2001);
}
