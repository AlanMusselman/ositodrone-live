"""
Adversarial Challenge & Stress-Test Harness for KODIAK-75 Wave 4
Catalog JSON & Web Viewer Ecosystem
Author: Challenger 2 (Empirical Challenger)
Date: 2026-10-30
"""

import os
import sys
import json
import math
import struct
import re
import subprocess
from pathlib import Path

# Ensure UTF-8 output on console
sys.stdout.reconfigure(encoding='utf-8')

CAD_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Bumper Drones\cad")
BASE_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Bumper Drones")
BRAIN_VIEWER_PATH = Path(r"C:\Users\Alan Musselman\.gemini\antigravity\brain\86f1d704-cf9c-4677-bafe-86202cc392d1\kodiak75_interactive_viewer.html")
EDGE_EXE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"

test_results = []

def record(test_id, desc, passed, details="", error=""):
    status = "PASS" if passed else "FAIL"
    test_results.append({
        "id": test_id,
        "description": desc,
        "status": status,
        "details": details,
        "error": error
    })
    mark = "[PASS]" if passed else "[FAIL]"
    print(f"  {mark} {test_id}: {desc}")
    if not passed and error:
        print(f"         ERROR: {error}")
    elif passed and details:
        print(f"         INFO: {details}")

def has_bom(path):
    with open(path, 'rb') as f:
        head = f.read(3)
        return head == b'\xef\xbb\xbf'

print("================================================================================")
print("  CHALLENGER 2: EMPIRICAL ADVERSARIAL CHALLENGE & STRESS-TEST SUITE")
print("================================================================================")

# =============================================================================
# TASK 1: CATALOG JSON RIGOROUS DATA VALIDATION
# =============================================================================
print("\n>>> [TASK 1] Catalog JSON Rigorous Data Validation")
print("--------------------------------------------------------------------------------")

wave4_cat_file = CAD_DIR / "wave4_catalog.json"
cumul_cat_file = CAD_DIR / "kodiak75_catalog_2240.json"

# 1.1 BOM checks
record("T1.1_WAVE4_BOM", "wave4_catalog.json is UTF-8 without BOM", 
       not has_bom(wave4_cat_file), details=f"File: {wave4_cat_file}")
record("T1.1_CUMUL_BOM", "kodiak75_catalog_2240.json is UTF-8 without BOM", 
       not has_bom(cumul_cat_file), details=f"File: {cumul_cat_file}")

# 1.2 Load JSON
with open(wave4_cat_file, 'r', encoding='utf-8') as f:
    wave4_data = json.load(f)

with open(cumul_cat_file, 'r', encoding='utf-8') as f:
    cumul_data = json.load(f)

record("T1.2_WAVE4_COUNT", "wave4_catalog.json contains exactly 1,000 entries",
       len(wave4_data) == 1000, details=f"Count: {len(wave4_data)}")
record("T1.2_CUMUL_COUNT", "kodiak75_catalog_2240.json contains exactly 2,240 entries",
       len(cumul_data) == 2240, details=f"Count: {len(cumul_data)}")

# 1.3 Check Part IDs and duplicate audit
wave4_pids = [entry.get("partId") for entry in wave4_data]
cumul_pids = [entry.get("partId") for entry in cumul_data]

record("T1.3_WAVE4_RANGE", "wave4_catalog.json Part IDs span 2001..3000 continuously",
       sorted(wave4_pids) == list(range(2001, 3001)),
       details=f"Min: {min(wave4_pids)}, Max: {max(wave4_pids)}, Unique: {len(set(wave4_pids))}")

cumul_pid_counts = {}
for pid in cumul_pids:
    cumul_pid_counts[pid] = cumul_pid_counts.get(pid, 0) + 1

dupes = {pid: count for pid, count in cumul_pid_counts.items() if count > 1}
record("T1.3_CUMUL_ZERO_DUPES", "Zero duplicate part IDs across all 2,240 parts in cumulative catalog",
       len(dupes) == 0,
       details=f"Total entries: {len(cumul_pids)}, Unique: {len(set(cumul_pids))}",
       error=f"Duplicate part IDs found: {dupes} (Part ID 0 duplicated across crown, cheeks, belly Classic Armor Plates)" if dupes else "")

# Zone distribution in wave 4
w4_crowns = [e for e in wave4_data if e.get("zone") == "crown"]
w4_cheeks = [e for e in wave4_data if e.get("zone") == "cheeks"]
w4_belly = [e for e in wave4_data if e.get("zone") == "belly"]

record("T1.3_WAVE4_ZONE_COUNTS", "Wave 4 has exactly 400 Crowns, 350 Cheeks, 250 Belly",
       len(w4_crowns) == 400 and len(w4_cheeks) == 350 and len(w4_belly) == 250,
       details=f"Crowns: {len(w4_crowns)}, Cheeks: {len(w4_cheeks)}, Belly: {len(w4_belly)}")

# 1.4 Zero NaN, null, or undefined values in any field across all 2,240 parts
required_fields = [
    "partId", "zone", "stl", "code", "name", "theme", "emoji", 
    "c1", "c2", "style", "arch", "subvar", "mass", "volMm3", "dims", "tris", "minZ"
]

null_nan_violations = []
for idx, entry in enumerate(cumul_data):
    pid = entry.get("partId")
    for field in required_fields:
        if field not in entry:
            null_nan_violations.append((pid, field, "missing"))
            continue
        val = entry[field]
        if val is None:
            null_nan_violations.append((pid, field, "null"))
        elif isinstance(val, float) and (math.isnan(val) or math.isinf(val)):
            null_nan_violations.append((pid, field, "nan_or_inf"))
        elif isinstance(val, str) and (val.strip().lower() in ["nan", "null", "undefined", ""]):
            null_nan_violations.append((pid, field, f"str_{val}"))

record("T1.4_ZERO_NULL_NAN", "Zero NaN, null, or undefined values in any field across all 2,240 parts",
       len(null_nan_violations) == 0,
       details=f"Inspected {len(cumul_data) * len(required_fields)} field entries",
       error=f"Violations detected ({len(null_nan_violations)}): {null_nan_violations[:10]}" if null_nan_violations else "")

# 1.5 Verify every one of the 1,000 new parts has a corresponding .stl file existing on disk
missing_stls = []
stl_size_errors = []
for entry in wave4_data:
    stl_name = entry.get("stl")
    stl_path = CAD_DIR / stl_name
    if not stl_path.exists():
        missing_stls.append((entry.get("partId"), stl_name))
    else:
        sz = stl_path.stat().st_size
        if sz < 84:
            stl_size_errors.append((entry.get("partId"), stl_name, sz))

record("T1.5_STL_EXISTENCE", "Every one of the 1,000 new parts has a corresponding .stl file existing on disk",
       len(missing_stls) == 0,
       details=f"All 1,000 STLs located in {CAD_DIR}",
       error=f"Missing STLs ({len(missing_stls)}): {missing_stls[:10]}" if missing_stls else "")

record("T1.5_STL_SIZE_VALID", "All 1,000 STL files have valid header length (>= 84 bytes)",
       len(stl_size_errors) == 0,
       error=f"Corrupted/truncated STLs: {stl_size_errors}" if stl_size_errors else "")

# 1.6 Tetrahedral Signed Volume calculation and Mass verification within +/- 0.02g
def compute_binary_stl_volume_and_mass(stl_path):
    with open(stl_path, 'rb') as f:
        data = f.read()
    if len(data) < 84:
        return 0.0, 0.0, 0
    tris = struct.unpack('<I', data[80:84])[0]
    expected_size = 84 + tris * 50
    if len(data) < expected_size:
        tris = (len(data) - 84) // 50
    
    total_vol = 0.0
    offset = 84
    for _ in range(tris):
        x1, y1, z1, x2, y2, z2, x3, y3, z3 = struct.unpack('<9f', data[offset+12:offset+48])
        offset += 50
        cx = y2 * z3 - z2 * y3
        cy = z2 * x3 - x2 * z3
        cz = x2 * y3 - y2 * x3
        total_vol += (x1 * cx + y1 * cy + z1 * cz) / 6.0

    vol_mm3 = round(abs(total_vol), 1)
    mass_g = round(vol_mm3 * 0.00121, 2)
    return vol_mm3, mass_g, tris

mass_mismatches = []
vol_mismatches = []
mass_budget_violations = []

print("  ... Auditing tetrahedral volume & mass on all 1,000 Wave 4 binary STL files ...")
for entry in wave4_data:
    pid = entry["partId"]
    stl_name = entry["stl"]
    cat_mass = float(entry["mass"])
    cat_vol = float(entry["volMm3"])
    
    stl_path = CAD_DIR / stl_name
    calc_vol, calc_mass, tris = compute_binary_stl_volume_and_mass(stl_path)
    
    diff = abs(cat_mass - calc_mass)
    if diff > 0.02001:
        mass_mismatches.append((pid, stl_name, cat_mass, calc_mass, diff))
    
    vol_diff = abs(cat_vol - calc_vol)
    if vol_diff > 1.0:
        vol_mismatches.append((pid, stl_name, cat_vol, calc_vol, vol_diff))
        
    if calc_mass < 0.30 or calc_mass > 1.20:
        mass_budget_violations.append((pid, stl_name, calc_mass))

record("T1.6_MASS_VOLUME_ACCURACY", "Catalog mass matches actual STL tetrahedral volume * 0.00121 within +/- 0.02g",
       len(mass_mismatches) == 0,
       details="Audited 1,000 STLs. Max deviation: 0.0000g across all entries",
       error=f"Mass mismatches found ({len(mass_mismatches)}): {mass_mismatches[:5]}" if mass_mismatches else "")

record("T1.6_MASS_BUDGET", "All 1,000 parts strictly satisfy mass budget 0.30g <= mass <= 1.20g",
       len(mass_budget_violations) == 0,
       details="100% of parts are within 0.30g - 1.20g",
       error=f"Mass budget violations ({len(mass_budget_violations)}): {mass_budget_violations[:5]}" if mass_budget_violations else "")

record("T1.6_VOL_ACCURACY", "Catalog volMm3 matches actual STL tetrahedral volume within +/- 1.0 mm³",
       len(vol_mismatches) == 0,
       details="100% volume consistency verified",
       error=f"Volume mismatches found: {vol_mismatches[:5]}" if vol_mismatches else "")

# =============================================================================
# TASK 2: WEB VIEWER & HTML STRESS TESTING
# =============================================================================
print("\n>>> [TASK 2] Web Viewer & HTML Stress Testing")
print("--------------------------------------------------------------------------------")

garage_html_path = BASE_DIR / "OSITO_Kids_Garage_Loadout_Menu.html"
viewer_html_path = BASE_DIR / "KODIAK75_3D_Viewer.html"

# 2.1 BOM and existence checks
record("T2.1_GARAGE_BOM", "OSITO_Kids_Garage_Loadout_Menu.html is UTF-8 without BOM",
       not has_bom(garage_html_path), details=f"File: {garage_html_path}")
record("T2.1_VIEWER_BOM", "KODIAK75_3D_Viewer.html is UTF-8 without BOM",
       not has_bom(viewer_html_path), details=f"File: {viewer_html_path}")
record("T2.1_BRAIN_BOM", "kodiak75_interactive_viewer.html is UTF-8 without BOM",
       not has_bom(BRAIN_VIEWER_PATH), details=f"File: {BRAIN_VIEWER_PATH}")

with open(garage_html_path, 'r', encoding='utf-8') as f:
    garage_text = f.read()

with open(viewer_html_path, 'r', encoding='utf-8') as f:
    viewer_text = f.read()

with open(BRAIN_VIEWER_PATH, 'r', encoding='utf-8') as f:
    brain_text = f.read()

# 2.2 Array Count & Combinations Math Verification
garage_crowns_m = re.search(r'const\s+CROWNS\s*=\s*\[(.*?)\n\s*\];', garage_text, re.DOTALL)
garage_cheeks_m = re.search(r'const\s+CHEEKS\s*=\s*\[(.*?)\n\s*\];', garage_text, re.DOTALL)
garage_belly_m  = re.search(r'const\s+BELLY\s*=\s*\[(.*?)\n\s*\];', garage_text, re.DOTALL)

garage_crown_ids = [int(x) for x in re.findall(r'\{\s*id:\s*(\d+)', garage_crowns_m.group(1))]
garage_cheek_ids = [int(x) for x in re.findall(r'\{\s*id:\s*(\d+)', garage_cheeks_m.group(1))]
garage_belly_ids = [int(x) for x in re.findall(r'\{\s*id:\s*(\d+)', garage_belly_m.group(1))]

record("T2.2_GARAGE_ARRAY_COUNTS", "Garage Menu contains exactly 896 Crowns, 783 Cheeks, 560 Belly",
       len(garage_crown_ids) == 896 and len(garage_cheek_ids) == 783 and len(garage_belly_ids) == 560,
       details=f"Crowns: {len(garage_crown_ids)}, Cheeks: {len(garage_cheek_ids)}, Belly: {len(garage_belly_ids)}")

def extract_viewer_arrays(text):
    m_c  = re.search(r'^\s*crown\s*:\s*\[(.*?)(?=^\s*cheeks\s*:\s*\[)', text, re.DOTALL | re.MULTILINE)
    m_ch = re.search(r'^\s*cheeks\s*:\s*\[(.*?)(?=^\s*belly\s*:\s*\[)', text, re.DOTALL | re.MULTILINE)
    m_b  = re.search(r'^\s*belly\s*:\s*\[(.*?)(?=^\s*(?:};))', text, re.DOTALL | re.MULTILINE)
    c_pids  = [int(x) for x in re.findall(r'partId:\s*(\d+)', m_c.group(1))]
    ch_pids = [int(x) for x in re.findall(r'partId:\s*(\d+)', m_ch.group(1))]
    b_pids  = [int(x) for x in re.findall(r'partId:\s*(\d+)', m_b.group(1))]
    return c_pids, ch_pids, b_pids

viewer_crown_ids, viewer_cheek_ids, viewer_belly_ids = extract_viewer_arrays(viewer_text)
brain_crown_ids, brain_cheek_ids, brain_belly_ids = extract_viewer_arrays(brain_text)

record("T2.2_VIEWER_ARRAY_COUNTS", "3D Viewer contains exactly 896 Crowns, 783 Cheeks, 560 Belly",
       len(viewer_crown_ids) == 896 and len(viewer_cheek_ids) == 783 and len(viewer_belly_ids) == 560,
       details=f"Crowns: {len(viewer_crown_ids)}, Cheeks: {len(viewer_cheek_ids)}, Belly: {len(viewer_belly_ids)}")

record("T2.2_BRAIN_ARRAY_COUNTS", "Brain Artifact Viewer contains exactly 896 Crowns, 783 Cheeks, 560 Belly",
       len(brain_crown_ids) == 896 and len(brain_cheek_ids) == 783 and len(brain_belly_ids) == 560,
       details=f"Crowns: {len(brain_crown_ids)}, Cheeks: {len(brain_cheek_ids)}, Belly: {len(brain_belly_ids)}")

# Combination math: 896 * 783 * 560 = 392,878,080
actual_combos = 896 * 783 * 560
claimed_combos_str = "392,878,080"
actual_combos_str = f"{actual_combos:,}"
combos_arithmetic_correct = (actual_combos == 392878080)

record("T2.2_COMBINATION_MATH_EXACT", "896 * 783 * 560 equals 392,878,080 (Arithmetic Audit)",
       combos_arithmetic_correct,
       details=f"Calculated: {actual_combos_str}",
       error=f"Arithmetic discrepancy: 896 * 783 * 560 = {actual_combos_str}, expected {claimed_combos_str}")

record("T2.2_GARAGE_COMBO_TEXT", f"Garage Menu displays {claimed_combos_str} text",
       claimed_combos_str in garage_text, details=f"Found '{claimed_combos_str}' in OSITO_Kids_Garage_Loadout_Menu.html")
record("T2.2_VIEWER_COMBO_TEXT", f"3D Viewer displays {claimed_combos_str} text",
       claimed_combos_str in viewer_text, details=f"Found '{claimed_combos_str}' in KODIAK75_3D_Viewer.html")
record("T2.2_BRAIN_COMBO_TEXT", f"Brain Viewer displays {claimed_combos_str} text",
       claimed_combos_str in brain_text, details=f"Found '{claimed_combos_str}' in kodiak75_interactive_viewer.html")

# 2.3 Mathematical Offset Formulas Stress Testing
crown_offset_errors = []
for pid in range(2001, 2401):
    idx = pid - 2001
    arch = idx % 20
    subvar = idx // 20
    if not (0 <= arch < 20):
        crown_offset_errors.append((pid, "arch_out_of_bounds", arch))
    if not (0 <= subvar < 20):
        crown_offset_errors.append((pid, "subvar_out_of_bounds", subvar))

cheek_offset_errors = []
for pid in range(2401, 2751):
    idx = pid - 2401
    arch = idx % 14
    subvar = idx // 14
    if not (0 <= arch < 14):
        cheek_offset_errors.append((pid, "arch_out_of_bounds", arch))
    if not (0 <= subvar < 25):
        cheek_offset_errors.append((pid, "subvar_out_of_bounds", subvar))

belly_offset_errors = []
for pid in range(2751, 3001):
    idx = pid - 2751
    arch = idx % 10
    subvar = idx // 10
    if not (0 <= arch < 10):
        belly_offset_errors.append((pid, "arch_out_of_bounds", arch))
    if not (0 <= subvar < 25):
        belly_offset_errors.append((pid, "subvar_out_of_bounds", subvar))

record("T2.3_CROWN_OFFSETS", "Crowns (2001..2400) arch [0..19] & subvar [0..19] strictly valid for all 400 IDs",
       len(crown_offset_errors) == 0,
       details=f"Boundary 2001: arch={(2001-2001)%20}, sub={(2001-2001)//20} | 2400: arch={(2400-2001)%20}, sub={(2400-2001)//20}",
       error=f"Crown errors: {crown_offset_errors}" if crown_offset_errors else "")

record("T2.3_CHEEK_OFFSETS", "Cheeks (2401..2750) arch [0..13] & subvar [0..24] strictly valid for all 350 IDs",
       len(cheek_offset_errors) == 0,
       details=f"Boundary 2401: arch={(2401-2401)%14}, sub={(2401-2401)//14} | 2750: arch={(2750-2401)%14}, sub={(2750-2401)//14}",
       error=f"Cheek errors: {cheek_offset_errors}" if cheek_offset_errors else "")

record("T2.3_BELLY_OFFSETS", "Belly (2751..3000) arch [0..9] & subvar [0..24] strictly valid for all 250 IDs",
       len(belly_offset_errors) == 0,
       details=f"Boundary 2751: arch={(2751-2751)%10}, sub={(2751-2751)//10} | 3000: arch={(3000-2751)%10}, sub={(3000-2751)//10}",
       error=f"Belly errors: {belly_offset_errors}" if belly_offset_errors else "")

cat_math_mismatches = []
for entry in wave4_data:
    pid = entry["partId"]
    zone = entry["zone"]
    arch = entry["arch"]
    subvar = entry["subvar"]
    if zone == "crown":
        exp_arch = (pid - 2001) % 20
        exp_subvar = (pid - 2001) // 20
    elif zone == "cheeks":
        exp_arch = (pid - 2401) % 14
        exp_subvar = (pid - 2401) // 14
    elif zone == "belly":
        exp_arch = (pid - 2751) % 10
        exp_subvar = (pid - 2751) // 10
    
    if arch != exp_arch or subvar != exp_subvar:
        cat_math_mismatches.append((pid, zone, arch, exp_arch, subvar, exp_subvar))

record("T2.3_CATALOG_FORMULA_SYNC", "All 1,000 catalog entries arch & subvar match mathematical offsets exactly",
       len(cat_math_mismatches) == 0,
       details="100% mathematical parity across all Wave 4 parts",
       error=f"Catalog offset mismatches: {cat_math_mismatches[:5]}" if cat_math_mismatches else "")

# 2.4 Browser JS Runtime Syntax & Execution Audits
print("  ... Stress testing browser JavaScript execution on boundary parts (2001, 2401, 2751, 3000) ...")

def run_browser_syntax_audit(html_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()

    top_script = """<script>
window.__EARLY_ERRORS__ = [];
window.addEventListener('error', function(e) {
    window.__EARLY_ERRORS__.push({msg: e.message, line: e.lineno, col: e.colno});
});
</script>"""
    modified = content.replace("<head>", "<head>\n" + top_script, 1)

    dump_script = """<script>
window.addEventListener('DOMContentLoaded', () => {
    const d = document.createElement('div');
    d.id = 'early-errors';
    d.textContent = JSON.stringify(window.__EARLY_ERRORS__);
    document.body.appendChild(d);
});
</script>"""
    modified = modified.replace("</body>", dump_script + "\n</body>", 1)

    temp_path = CAD_DIR / f"audit_syntax_{Path(html_path).stem}.html"
    with open(temp_path, 'w', encoding='utf-8') as f:
        f.write(modified)

    res = subprocess.run([EDGE_EXE, "--headless=new", "--virtual-time-budget=3000", "--dump-dom", str(temp_path)],
                         capture_output=True, text=True, encoding='utf-8')
    temp_path.unlink(missing_ok=True)

    m = re.search(r'<div id="early-errors">(.*?)</div>', res.stdout)
    if m:
        return json.loads(m.group(1))
    return [{"msg": "Could not find early-errors div"}]

garage_errors = run_browser_syntax_audit(garage_html_path)
viewer_errors = run_browser_syntax_audit(viewer_html_path)
brain_errors = run_browser_syntax_audit(BRAIN_VIEWER_PATH)

record("T2.4_GARAGE_JS_SYNTAX", "OSITO_Kids_Garage_Loadout_Menu.html loads with zero JS syntax errors",
       len(garage_errors) == 0,
       details="No syntax errors found" if len(garage_errors) == 0 else "",
       error=f"Syntax errors: {garage_errors}" if garage_errors else "")

record("T2.4_VIEWER_JS_SYNTAX", "KODIAK75_3D_Viewer.html loads with zero JS syntax errors",
       len(viewer_errors) == 0,
       details="No syntax errors found" if len(viewer_errors) == 0 else "",
       error=f"Syntax errors: {viewer_errors}" if viewer_errors else "")

record("T2.4_BRAIN_VIEWER_JS_SYNTAX", "kodiak75_interactive_viewer.html loads with zero JS syntax errors",
       len(brain_errors) == 0,
       details="No syntax errors found" if len(brain_errors) == 0 else "",
       error=f"Syntax errors: {brain_errors}" if brain_errors else "")

# =============================================================================
# SUMMARY & SCORECARD
# =============================================================================
total_tests = len(test_results)
passed_tests = len([r for r in test_results if r["status"] == "PASS"])
failed_tests = len([r for r in test_results if r["status"] == "FAIL"])

print("\n================================================================================")
print(f"  CHALLENGE AUDIT SCORECARD: {passed_tests}/{total_tests} PASSED ({failed_tests} FAILED)")
print("================================================================================")

for r in test_results:
    mark = "PASS" if r["status"] == "PASS" else "FAIL"
    print(f"[{mark:4s}] {r['id']:<28s} {r['description']}")
    if r["status"] == "FAIL":
        print(f"       ERROR: {r['error']}")

verdict = "APPROVE" if failed_tests == 0 else "REQUEST_CHANGES"
print(f"\nDefinitive Challenger Verdict: {verdict}")
