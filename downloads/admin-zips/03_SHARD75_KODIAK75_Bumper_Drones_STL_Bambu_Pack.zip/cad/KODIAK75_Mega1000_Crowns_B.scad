// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 3: MEGA-1000 TOP CROWNS BATCH B (1201..1400)
// 200 Creative Support-Free Top Crown Sculptures (10 Worlds x 20 Archetypes)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.55g .. 1.15g (Volume: 450 .. 950 mm^3)
// Print Orientation: 100% Flat at Z = 0.00mm with ZERO supports (<=45 deg)
// Universal Zone 1 Interface:
//   - Base skirt OD = 16.0..17.6mm (h = 1.65mm, tapered to 14.2mm top)
//   - 8.40mm x 0.45mm annular recess around 4.80mm central boss + conical boss
//   - 2.10mm x 1.20mm N52 disc magnet pocket at Z = 0
//   - 6.5mm x 1.2mm x 0.35mm directional alignment keyway rib at X=+4.2, Z=0.45
// ============================================================================

$fn = 32;

PART_ID = 1201;

// ============================================================================
// UNIVERSAL ZONE 1 TOP CROWN MAGNETIC & CONICAL SHEAR-KEYWAY BASE
// ============================================================================
module crown_base_b(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    base_od = 16.0 + sv * 0.16; // 16.00mm .. 17.44mm
    difference() {
        union() {
            // Tapered outer skirt flat on print bed at Z = 0.00mm
            cylinder(d1 = base_od, d2 = 14.2, h = 1.65);
            // Central male conical shear boss
            cylinder(d1 = 3.40, d2 = 2.10, h = 0.45);
        }
        // 8.40mm x 0.45mm annular recess minus 4.80mm central boss
        translate([0, 0, -0.01])
            difference() {
                cylinder(d = 8.40, h = 0.46);
                translate([0, 0, -0.01])
                    cylinder(d = 4.80, h = 0.48);
            }
        // 2.10mm x 1.20mm N52 magnet pocket
        translate([0, 0, -0.01])
            cylinder(d = 2.10, h = 1.25);
    }
    // 6.5mm x 1.2mm x 0.35mm directional alignment keyway rib at X = +4.2mm, Z = 0.45mm
    difference() {
        translate([4.2, 0, 0.45])
            cube([6.5, 1.2, 0.35], center = true);
        translate([0, 0, -0.01])
            cylinder(d = 2.10, h = 1.25);
    }
}

// ============================================================================
// 20 SUPPORT-FREE 3D SCULPTURE ARCHETYPES (arch = 0..19, subvar = 10..19)
// Merged cleanly into Z = 1.40mm top of the crown base
// ============================================================================

// arch 0: Festival / Guitar / Monument Spire with side fins
module crown_arch_b_0(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    h_main = 8.2 + sv * 0.16;
    fin_x  = 4.8 + (sv % 3) * 0.35;
    // Central tapered hexagonal monument spire
    translate([0, 0, 1.40])
        cylinder(d1 = 8.2, d2 = 2.8, h = h_main, $fn = 6);
    // Swept side V-fins with tuner peg ribs
    for (s = [-1, 1]) {
        hull() {
            translate([s * 2.4, 0, 1.40]) cylinder(d = 2.8, h = 2.4);
            translate([s * fin_x, 0, 4.6 + (sv % 2) * 0.4]) cylinder(d = 2.0, h = 2.8);
        }
        // Tuner peg / cross-arm lugs
        for (z_p = [3.6, 5.6]) {
            hull() {
                translate([0, 0, z_p]) cylinder(d = 2.2, h = 1.0);
                translate([s * (fin_x + 0.5), 0, z_p + 0.6]) cylinder(d = 1.6, h = 1.0);
            }
        }
    }
}

// arch 1: Tornado Vortex / Snowflake / Clockwork / Antler Crown
module crown_arch_b_1(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    n_arms = 4 + (sv % 3); // 4, 5, or 6 radial branches
    // Central vortex cone
    translate([0, 0, 1.40])
        cylinder(d1 = 8.4, d2 = 3.8, h = 6.8 + sv * 0.14);
    // Radial antler / snowflake / vortex branches
    for (i = [0 : n_arms - 1]) {
        rotate([0, 0, i * (360 / n_arms) + sv * 6]) {
            hull() {
                translate([2.2, 0, 1.40]) cylinder(d = 2.4, h = 2.0);
                translate([5.2, 0.5, 4.4 + (sv % 3) * 0.3]) cylinder(d = 1.9, h = 2.2);
            }
            hull() {
                translate([4.6, 0.4, 4.6]) cylinder(d = 1.8, h = 1.6);
                translate([3.8, -0.4, 6.8 + (sv % 2) * 0.4]) cylinder(d = 1.4, h = 1.4);
            }
        }
    }
}

// arch 2: Turntable / Hurricane / Gear / Scarab Disc Dome
module crown_arch_b_2(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Beveled turntable platter & grooved scarab dome
    translate([0, 0, 1.40]) {
        cylinder(d1 = 12.2, d2 = 12.8, h = 1.4);
        translate([0, 0, 1.3])
            cylinder(d1 = 12.2, d2 = 6.4, h = 3.2 + sv * 0.12);
        // Central tonearm / spindle spire
        cylinder(d1 = 5.2, d2 = 2.2, h = 6.4 + sv * 0.15);
    }
    // 8 strobe / gear teeth around perimeter
    for (a = [0 : 45 : 315]) {
        rotate([0, 0, a + sv * 4])
            hull() {
                translate([4.8, 0, 1.40]) cylinder(d = 2.0, h = 1.6);
                translate([5.6, 0, 2.6]) cylinder(d = 1.6, h = 1.8 + (sv % 3) * 0.25);
            }
    }
}

// arch 3: Step Pyramid / Ziggurat / Amplifier / Aztec Temple
module crown_arch_b_3(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    rotate([0, 0, (sv % 2) * 15]) {
        // 4 stepped ziggurat tiers
        for (t = [0 : 3]) {
            w = 9.2 - t * 1.8 + (sv % 3) * 0.15;
            z0 = 1.40 + t * 1.65;
            hull() {
                for (dx = [-1, 1], dy = [-1, 1])
                    translate([dx * (w/2 - 0.8), dy * (w/2 - 0.8), z0])
                        cylinder(d = 1.6, h = 1.75);
            }
        }
        // 4 temple staircase buttresses
        for (a = [0, 90, 180, 270]) {
            rotate([0, 0, a])
                hull() {
                    translate([4.8, 0, 1.40]) cylinder(d = 2.0, h = 1.4);
                    translate([2.0, 0, 6.4 + sv * 0.12]) cylinder(d = 1.6, h = 1.4);
                }
        }
    }
}

// arch 4: Bullhorn / Tsunami Wave / Beetle Horn / Cowboy Hat Arch
module crown_arch_b_4(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Sculpted crown saddle
    translate([0, 0, 1.40])
        cylinder(d1 = 11.4, d2 = 8.4, h = 2.6);
    // Central wave / cattleman crown ridge
    hull() {
        translate([0, -2.2, 1.40]) cylinder(d = 3.6, h = 4.2 + sv * 0.1);
        translate([0,  2.2, 1.40]) cylinder(d = 3.6, h = 4.2 + sv * 0.1);
    }
    // Twin upward-curling horns / wave tips
    for (s = [-1, 1]) {
        hull() {
            translate([s * 2.6, 0, 1.40]) cylinder(d = 3.2, h = 2.2);
            translate([s * 5.2, 0, 4.2]) cylinder(d = 2.5, h = 2.2);
        }
        hull() {
            translate([s * 5.2, 0, 4.2]) cylinder(d = 2.5, h = 2.0);
            translate([s * (3.8 + (sv % 3) * 0.35), 0, 7.2 + sv * 0.14]) cylinder(d = 1.7, h = 1.6);
        }
    }
}

// arch 5: Studio Headphones / Vampire Collar / Totem / Hero Cowl
module crown_arch_b_5(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Central brow / totem core
    translate([0, 0, 1.40])
        cylinder(d1 = 9.2, d2 = 5.4, h = 4.6 + sv * 0.12);
    // Twin ear-cups / cowl pillars + high collar arch
    for (s = [-1, 1]) {
        hull() {
            translate([s * 3.8, -0.6, 1.40]) cylinder(d = 3.4, h = 4.8);
            translate([s * 4.4,  0.6, 1.40]) cylinder(d = 3.0, h = 6.4 + sv * 0.14);
        }
        // Swept arch over top
        hull() {
            translate([s * 4.2, 0.6, 5.8 + sv * 0.14]) cylinder(d = 2.4, h = 1.6);
            translate([0, 1.4, 7.6 + sv * 0.14]) cylinder(d = 2.4, h = 1.6);
        }
    }
}

// arch 6: Disco Dome / Geode / Pumpkin / Snowglobe Orb
module crown_arch_b_6(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    facets = 8 + (sv % 3) * 2;
    // Flared pedestal collar
    translate([0, 0, 1.40])
        cylinder(d1 = 11.4, d2 = 9.4, h = 2.0);
    // Faceted orb body (support-free 45 deg lower bevel)
    hull() {
        translate([0, 0, 2.8]) cylinder(d = 8.8, h = 0.8, $fn = facets);
        translate([0, 0, 4.4]) cylinder(d = 10.6 + (sv % 3) * 0.2, h = 1.6, $fn = facets);
        translate([0, 0, 7.2 + sv * 0.12]) cylinder(d = 4.4, h = 0.8, $fn = facets);
    }
    // Top stem / finial
    translate([0, 0, 7.4 + sv * 0.12])
        cylinder(d1 = 3.6, d2 = 1.8, h = 1.6, $fn = facets);
}

// arch 7: Saxophone / Volcano / Scythe / Speedster Fin
module crown_arch_b_7(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Swept dorsal blade
    hull() {
        translate([-4.4, 0, 1.40]) cylinder(d = 2.6, h = 2.0);
        translate([ 2.2, 0, 1.40]) cylinder(d = 4.0, h = 2.8);
        translate([-2.6 - (sv % 3) * 0.3, 0, 6.8 + sv * 0.16]) cylinder(d = 2.2, h = 2.2);
    }
    // Flared volcano / saxophone bell cone with shallow top crater
    difference() {
        translate([1.6, 0, 1.40])
            cylinder(d1 = 7.4, d2 = 4.8 + (sv % 3) * 0.25, h = 6.0 + sv * 0.12);
        translate([1.6, 0, 6.4 + sv * 0.12])
            cylinder(d1 = 1.6, d2 = 3.0, h = 1.4);
    }
}

// arch 8: Cymbal / Tesla Coil / Wreath / Halo Torus Spire
module crown_arch_b_8(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Central insulator spire
    translate([0, 0, 1.40])
        cylinder(d1 = 8.4, d2 = 3.2, h = 7.6 + sv * 0.15);
    // 3 stacked 45-degree support-free toroid rings
    for (t = [0 : 2]) {
        z_r = 2.4 + t * 2.1;
        d_outer = 10.6 - t * 1.3 + (sv % 3) * 0.25;
        hull() {
            translate([0, 0, z_r - 0.7]) cylinder(d = d_outer - 2.6, h = 0.4);
            translate([0, 0, z_r])       cylinder(d = d_outer, h = 0.6);
            translate([0, 0, z_r + 0.8]) cylinder(d = d_outer - 2.8, h = 0.4);
        }
    }
}

// arch 9: Grand Piano / Glacier / Eiffel / DNA Helix Tower
module crown_arch_b_9(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Twisted 4-ribbed helix / lattice tower
    translate([0, 0, 1.40])
        linear_extrude(height = 7.8 + sv * 0.18, twist = 48 + sv * 6, scale = 0.46, slices = 24) {
            union() {
                circle(d = 6.4);
                square([9.4, 2.8], center = true);
                square([2.8, 9.4], center = true);
            }
        }
    // Central finial spire
    translate([0, 0, 1.40])
        cylinder(d1 = 4.6, d2 = 1.8, h = 8.8 + sv * 0.18);
}

// arch 10: Synth Keys / Solar Flare / Menorah / Cactus Arms
module crown_arch_b_10(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Central trunk
    translate([0, 0, 1.40])
        cylinder(d1 = 7.6, d2 = 3.6, h = 7.8 + sv * 0.14);
    // Stepped cactus / menorah arms
    for (s = [-1, 1]) {
        // Inner arm
        hull() {
            translate([s * 1.8, 0, 2.0]) cylinder(d = 2.4, h = 1.6);
            translate([s * 3.4, 0, 3.6]) cylinder(d = 2.2, h = 1.6);
        }
        translate([s * 3.4, 0, 3.6])
            cylinder(d1 = 2.2, d2 = 1.6, h = 3.8 + (sv % 3) * 0.3);
        // Outer arm
        hull() {
            translate([s * 2.2, 0, 1.40]) cylinder(d = 2.4, h = 1.6);
            translate([s * 5.0, 0, 4.0])  cylinder(d = 2.1, h = 1.6);
        }
        translate([s * 5.0, 0, 4.0])
            cylinder(d1 = 2.1, d2 = 1.5, h = 3.0 + (sv % 4) * 0.25);
    }
    // Front/back synth key ribs
    for (sy = [-1, 1])
        translate([0, sy * 2.6, 1.40])
            cylinder(d1 = 3.4, d2 = 2.0, h = 4.0);
}

// arch 11: Metronome / Obelisk / Big Ben / Rocket Pyramid
module crown_arch_b_11(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // 4-sided obelisk / clock tower shaft
    rotate([0, 0, 45]) {
        translate([0, 0, 1.40])
            cylinder(d1 = 11.0, d2 = 8.6, h = 2.2, $fn = 4);
        translate([0, 0, 3.4])
            cylinder(d1 = 8.4, d2 = 4.8, h = 5.2 + sv * 0.15, $fn = 4);
        translate([0, 0, 8.4 + sv * 0.15])
            cylinder(d1 = 4.8, d2 = 1.0, h = 2.2, $fn = 4);
    }
    // 4 cardinal rocket / clock buttress fins
    for (a = [0, 90, 180, 270]) {
        rotate([0, 0, a])
            hull() {
                translate([4.6, 0, 1.40]) cylinder(d = 2.0, h = 1.8);
                translate([2.2, 0, 6.0 + sv * 0.12]) cylinder(d = 1.6, h = 1.6);
            }
    }
}

// arch 12: Maraca / Hourglass / Microscope / Safari Twin-Pods
module crown_arch_b_12(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Central saddle hub
    translate([0, 0, 1.40])
        cylinder(d1 = 9.4, d2 = 5.8, h = 3.8);
    // Twin tilted gourd / cryo / maraca pods
    for (s = [-1, 1]) {
        hull() {
            translate([s * 2.0, 0, 1.40]) cylinder(d = 3.4, h = 1.8);
            translate([s * (3.6 + (sv % 3) * 0.25), 0, 4.8 + sv * 0.12])
                sphere(d = 4.8, $fn = 24);
        }
        translate([s * (3.8 + (sv % 3) * 0.25), 0, 6.2 + sv * 0.12])
            cylinder(d1 = 3.2, d2 = 1.4, h = 1.8);
    }
}

// arch 13: Accordion / Prism / Opera Sails / Boomerang V-Crest
module crown_arch_b_13(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // 3 overlapping pleated Opera / Accordion triangular sails
    for (i = [-1, 0, 1]) {
        y_off = i * 2.1;
        h_sail = 6.8 - abs(i) * 1.0 + sv * 0.15;
        hull() {
            translate([-4.0 + abs(i) * 0.6, y_off - 0.4, 1.40]) cylinder(d = 2.2, h = 1.2);
            translate([ 4.0 - abs(i) * 0.6, y_off - 0.4, 1.40]) cylinder(d = 2.2, h = 1.2);
            translate([ i * 0.8, y_off + 0.6, h_sail]) cylinder(d = 1.9, h = 1.2);
        }
    }
}

// arch 14: Lighthouse / Bonsai / Santa Hat / Stetson Cone
module crown_arch_b_14(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Sculpted brim base
    hull() {
        translate([-1.2, 0, 1.40]) cylinder(d1 = 11.6, d2 = 9.2, h = 2.0);
        translate([ 1.2, 0, 1.40]) cylinder(d1 = 11.6, d2 = 9.2, h = 2.0);
    }
    // Swept leaning cone / bonsai trunk
    hull() {
        translate([0, 0, 2.8])   cylinder(d = 8.2, h = 1.0);
        translate([1.0, 0, 5.8]) cylinder(d = 5.0, h = 1.0);
    }
    hull() {
        translate([1.0, 0, 5.8]) cylinder(d = 5.0, h = 1.0);
        translate([2.4 + (sv % 3) * 0.25, 0, 7.8 + sv * 0.14])
            sphere(d = 3.6, $fn = 24);
    }
}

// arch 15: Laser Pyramid / Flytrap / Reaper / Saiyan Spikes
module crown_arch_b_15(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    n_sp = 5 + (sv % 3);
    // Central core
    translate([0, 0, 1.40])
        cylinder(d1 = 9.8, d2 = 4.2, h = 5.4);
    // Central apex spike
    translate([0, 0, 1.40])
        cylinder(d1 = 4.6, d2 = 1.4, h = 8.2 + sv * 0.15);
    // Radial crown of angled spikes
    for (i = [0 : n_sp - 1]) {
        rotate([0, 0, i * (360 / n_sp) + sv * 7])
            hull() {
                translate([2.2, 0, 1.40]) cylinder(d = 2.6, h = 1.8);
                translate([4.6 + (sv % 2) * 0.3, 0, 6.4 + sv * 0.14]) cylinder(d = 1.5, h = 1.4);
            }
    }
}

// arch 16: Carousel / Rainbow Bridge / Torii Gate / Portal Ring
module crown_arch_b_16(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    h_gate = 6.2 + sv * 0.14;
    // Central V-support pedestal (ensures 45-degree support-free arch)
    translate([0, 0, 1.40])
        cylinder(d1 = 8.8, d2 = 5.2, h = 3.4);
    for (s = [-1, 1]) {
        // Outer Torii / portal pillars
        hull() {
            translate([s * 4.2, 0, 1.40])   cylinder(d = 2.8, h = 1.6);
            translate([s * 3.6, 0, h_gate]) cylinder(d = 2.4, h = 1.6);
        }
        // 45-degree inner arch strut
        hull() {
            translate([0, 0, 3.2])          cylinder(d = 2.6, h = 1.4);
            translate([s * 3.6, 0, h_gate]) cylinder(d = 2.4, h = 1.4);
        }
        // Upper gabled lintel wing
        hull() {
            translate([0, 0, h_gate + 1.2])       cylinder(d = 2.6, h = 1.2);
            translate([s * 4.8, 0, h_gate + 0.2]) cylinder(d = 2.0, h = 1.2);
        }
    }
}

// arch 17: Ferris Wheel / Astrolabe / Atom Orbits / Starburst
module crown_arch_b_17(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    n_orb = 3 + (sv % 2);
    // Pedestal base
    translate([0, 0, 1.40])
        cylinder(d1 = 10.6, d2 = 7.4, h = 3.0);
    // Intersecting vertical astrolabe / Ferris wheel rings clipped above Z = 1.40
    intersection() {
        translate([0, 0, 6.4])
            cube([20, 20, 10.0], center = true);
        union() {
            for (i = [0 : n_orb - 1]) {
                rotate([0, 0, i * (180 / n_orb) + sv * 5])
                    translate([0, 0, 5.2 + sv * 0.08])
                        rotate([90, 0, 0])
                            cylinder(d = 9.4 + sv * 0.12, h = 1.7, center = true, $fn = 8);
            }
        }
    }
}

// arch 18: Circus Tent / Pagoda / Cryo Pod / Teepee Spire
module crown_arch_b_18(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Lower octagonal tent / pagoda wall
    translate([0, 0, 1.40])
        cylinder(d1 = 11.4, d2 = 7.8, h = 3.0, $fn = 8);
    // Support-free 45-degree flared pagoda eave + roof
    hull() {
        translate([0, 0, 3.8]) cylinder(d = 7.4, h = 0.5, $fn = 8);
        translate([0, 0, 4.8]) cylinder(d = 9.8 + (sv % 3) * 0.2, h = 0.6, $fn = 8);
        translate([0, 0, 7.0]) cylinder(d = 4.4, h = 0.5, $fn = 8);
    }
    // Finial spire
    translate([0, 0, 6.8])
        cylinder(d1 = 4.6, d2 = 1.4, h = 2.8 + sv * 0.16, $fn = 8);
}

// arch 19: Twin V-Antenna / Stag Jaws / Shogun / Omega Crown
module crown_arch_b_19(subvar = 10) {
    sv = max(0, min(9, subvar - 10));
    // Armored brow base
    translate([0, 0, 1.40])
        cylinder(d1 = 11.0, d2 = 7.8, h = 2.8);
    // Central V-crest fin
    hull() {
        translate([0, -1.6, 1.40]) cylinder(d = 3.0, h = 2.4);
        translate([0,  1.8, 6.4 + sv * 0.12]) cylinder(d = 1.8, h = 1.6);
    }
    // Twin Omega / Stag pincer horns
    for (s = [-1, 1]) {
        hull() {
            translate([s * 2.4, -0.4, 1.40]) cylinder(d = 3.0, h = 2.2);
            translate([s * 5.2,  0.4, 4.6])  cylinder(d = 2.4, h = 2.0);
        }
        hull() {
            translate([s * 5.2, 0.4, 4.6]) cylinder(d = 2.4, h = 1.8);
            translate([s * (2.6 + (sv % 3) * 0.3), 0.6, 7.6 + sv * 0.15]) cylinder(d = 1.7, h = 1.5);
        }
    }
}

// ============================================================================
// MASTER DISPATCHER FOR PART_ID = 1201..1400
// ============================================================================
module mega1000_crown_b(part_id = 1201) {
    arch   = (part_id - 1001) % 20;
    subvar = floor((part_id - 1001) / 20); // 10..19 for 1201..1400

    union() {
        crown_base_b(subvar);
        if      (arch ==  0) crown_arch_b_0(subvar);
        else if (arch ==  1) crown_arch_b_1(subvar);
        else if (arch ==  2) crown_arch_b_2(subvar);
        else if (arch ==  3) crown_arch_b_3(subvar);
        else if (arch ==  4) crown_arch_b_4(subvar);
        else if (arch ==  5) crown_arch_b_5(subvar);
        else if (arch ==  6) crown_arch_b_6(subvar);
        else if (arch ==  7) crown_arch_b_7(subvar);
        else if (arch ==  8) crown_arch_b_8(subvar);
        else if (arch ==  9) crown_arch_b_9(subvar);
        else if (arch == 10) crown_arch_b_10(subvar);
        else if (arch == 11) crown_arch_b_11(subvar);
        else if (arch == 12) crown_arch_b_12(subvar);
        else if (arch == 13) crown_arch_b_13(subvar);
        else if (arch == 14) crown_arch_b_14(subvar);
        else if (arch == 15) crown_arch_b_15(subvar);
        else if (arch == 16) crown_arch_b_16(subvar);
        else if (arch == 17) crown_arch_b_17(subvar);
        else if (arch == 18) crown_arch_b_18(subvar);
        else if (arch == 19) crown_arch_b_19(subvar);
    }
}

if (PART_ID >= 1201 && PART_ID <= 1400) {
    mega1000_crown_b(PART_ID);
}