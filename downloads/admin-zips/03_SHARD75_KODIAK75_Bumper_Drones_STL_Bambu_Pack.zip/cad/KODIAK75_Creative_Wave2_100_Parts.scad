// ============================================================================
// KODIAK-75: Creative Wave 2 â€” Crowns (401..440) & Cheek Pods (501..535)
// Universal Magnetic Snap-On Breakaway Architecture for Bumper Drones
// ============================================================================
// Total Components in this file: 75 Distinct Sacrificial Modules
// - Zone 1: Creative Top Crowns       (PART_ID = 401 to 440) [40 Apex Toppers]
// - Zones 2 & 3: Creative Cheek Pairs (PART_ID = 501 to 535) [35 Pairs / 70 Parts]
//
// Material: TPU 95A (density = 0.00121 g/mm^3)
// Mass Target Budget:
//   - Crowns (401..440): 0.45g .. 1.15g (Volume: 372 .. 950 mm^3)
//   - Cheek Pairs (501..535): 0.38g .. 0.58g per pod (0.76g .. 1.16g per pair)
// Support Policy: 100% Support-Free FDM Printing at Z = 0.00mm
// Polarity Standard: Grade N52 disc magnets (2mm OD x 1mm thick), South-Facing-Out
// ============================================================================

$fn = 32;

// Command-line selector: openscad -D PART_ID=<id> -o <target>.stl ...
PART_ID = 0;

// --- Master Interface Constants ---
mag_pocket_dia        = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth      = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1       = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2       = 2.10; // Tip diameter of male conical shear boss (Z = 0 or tip)
shear_boss_height     = 0.45; // Height of male conical shear boss (mates into 0.50mm dimple)
shear_dimple_dia      = 3.60; // Drone female conical dimple mouth diameter
shear_dimple_depth    = 0.50; // Drone female conical dimple depth
crown_annular_dia     = 8.40; // Shrouds drone's 8.0mm deck boss (0.20mm radial clearance)
crown_annular_depth   = 0.45; // Annular shroud relief depth
belly_mag_spacing     = 36.0; // Ventral dual-magnet pitch along X-axis (X = -18mm and X = +18mm)
cheek_print_spacing   = 32.0; // Y = -16.0mm (Left, Zone 2) and Y = +16.0mm (Right, Zone 3)

// ============================================================================
// UNIVERSAL HELPER MODULES
// ============================================================================

// Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45)
module n52_mating_boss_up() {
    cylinder(d1=shear_boss_dia1, d2=shear_boss_dia2, h=shear_boss_height);
}

// Top-facing recessed magnet pocket cut through boss
module n52_mating_pocket_cut_up() {
    translate([0, 0, -mag_pocket_depth])
        cylinder(d=mag_pocket_dia, h=mag_pocket_depth + shear_boss_height + 0.10);
}

// Zone 1 Standard Top Crown Base Solid (Print bed at Z = 0)
// Outer skirt OD=15.6mm and central boss tip d2=2.10mm both touch Z=0
module top_crown_base_solid(base_od = 15.6, base_h = 2.6) {
    difference() {
        cylinder(d1 = base_od, d2 = base_od - 3.2, h = base_h);
        translate([0, 0, -0.05])
            cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.05);
    }
    // Male conical shear boss protruding downward reaching exactly Z = 0
    cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1 + 0.20, h = shear_boss_height + 0.35);
}

// Zone 1 Standard Top Crown Magnet Pocket Cut + Annular Recess & Vent Channels
module top_crown_base_cuts(base_h = 2.6) {
    translate([0, 0, -0.05])
        cylinder(d = mag_pocket_dia, h = mag_pocket_depth + shear_boss_height + 0.05);
    // Ensure annular recess around male conical shear boss is always open to Z=0
    difference() {
        translate([0, 0, -0.05])
            cylinder(d = crown_annular_dia, h = crown_annular_depth + 0.05);
        translate([0, 0, -0.10])
            cylinder(d1 = shear_boss_dia2, d2 = shear_boss_dia1 + 0.30, h = shear_boss_height + 0.45);
    }
    // Vent channels connecting internal weight-relief domes to the 8.4mm annular shroud
    for (a = [0, 120, 240]) {
        rotate([0, 0, a])
            translate([2.6, 0, 0.25])
                cylinder(d = 1.6, h = 2.8);
    }
}

// Zones 2 & 3 Standard Cheek Hub Pad Solid (Print bed at Z = 0)
module cheek_hub_solid(pad_h = 2.4) {
    hull() {
        cylinder(d = 8.8, h = pad_h);
        translate([-8.5, 0, 0]) cylinder(d = 4.4, h = pad_h - 0.6);
        translate([ 8.5, 0, 0]) cylinder(d = 4.4, h = pad_h - 0.6);
    }
    translate([0, 0, pad_h - 0.15])
        cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
}

// Zones 2 & 3 Standard Cheek Hub Magnet Pocket Cut
module cheek_hub_cuts(pad_h = 2.4) {
    translate([0, 0, pad_h])
        n52_mating_pocket_cut_up();
}

// ============================================================================
// ZONE 1: 40 NEW CREATIVE TOP CANOPY CROWNS (PART_ID = 401..440)
// ============================================================================

// 401: KODIAK75_Crown_TacoShell (Food & Candy â€” Crispy Taco Shell Crest)
module KODIAK75_Crown_TacoShell() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // U-folded taco shell walls & wavy lettuce/beef filling crest
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-5.0, y_s * 2.2, 2.0]) cylinder(d=2.2, h=4.5);
                    translate([ 5.0, y_s * 2.2, 2.0]) cylinder(d=2.2, h=4.5);
                    translate([ 0.0, y_s * 2.6, 2.0]) cylinder(d=2.6, h=7.5);
                }
            }
            // Wavy salsa & cheese ridge down the middle
            for (x_p = [-3.6, -1.2, 1.2, 3.6]) {
                hull() {
                    translate([x_p, 0, 2.0]) cylinder(d=3.6, h=4.0);
                    translate([x_p, 0, 7.2]) sphere(d=3.2);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.2, h=3.2);
    }
}
module Crown_TacoShell() { KODIAK75_Crown_TacoShell(); }

// 402: KODIAK75_Crown_BurgerStack (Food & Candy â€” Triple Cheeseburger Stack)
module KODIAK75_Crown_BurgerStack() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Bottom bun & seared patty
            translate([0, 0, 2.2]) cylinder(d=12.6, h=1.8);
            // Melted square cheese slice (rotated 45 deg)
            translate([0, 0, 4.0]) rotate([0, 0, 45]) cylinder(d1=13.2, d2=12.0, h=1.0, $fn=4);
            // Second patty
            translate([0, 0, 4.8]) cylinder(d=12.2, h=1.6);
            // Domed sesame seed top bun
            hull() {
                translate([0, 0, 6.2]) cylinder(d=12.4, h=1.0);
                translate([0, 0, 8.2]) cylinder(d1=9.6, d2=5.0, h=1.8);
            }
            // Sesame seed bumps on dome
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    translate([3.2, 0, 9.2])
                        sphere(d=1.6);
            }
        }
        top_crown_base_cuts(2.6);
        // Open top/bottom weight relief
        translate([0, 0, 2.2]) cylinder(d=7.2, h=6.2);
    }
}
module Crown_BurgerStack() { KODIAK75_Crown_BurgerStack(); }

// 403: KODIAK75_Crown_PizzaSlice (Food & Candy â€” Pepperoni Pizza Fin)
module KODIAK75_Crown_PizzaSlice() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Wedge fin pointing forward (+X) with rolled crust at rear (-X)
            hull() {
                translate([ 6.0, 0, 2.0]) cylinder(d=2.2, h=3.5);
                translate([-4.8, -3.2, 2.0]) cylinder(d=2.6, h=9.0);
                translate([-4.8,  3.2, 2.0]) cylinder(d=2.6, h=9.0);
            }
            // Rolled rear crust bolster
            hull() {
                translate([-4.8, -3.5, 8.5]) sphere(d=3.0);
                translate([-4.8,  3.5, 8.5]) sphere(d=3.0);
            }
            // Pepperoni discs embossed on both flanks
            for (y_s = [-1, 1]) {
                translate([-1.5, y_s * 2.0, 5.2]) sphere(d=2.8);
                translate([ 2.0, y_s * 1.2, 4.2]) sphere(d=2.4);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=3.0);
    }
}
module Crown_PizzaSlice() { KODIAK75_Crown_PizzaSlice(); }

// 404: KODIAK75_Crown_IceCreamCone (Food & Candy â€” Swirl Ice Cream Cone)
module KODIAK75_Crown_IceCreamCone() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Waffle cone collar
            translate([0, 0, 2.0]) cylinder(d1=12.4, d2=10.8, h=2.8, $fn=12);
            // Soft-serve swirl tiers
            translate([0, 0, 4.4]) cylinder(d1=11.4, d2=9.2, h=2.4);
            translate([0, 0, 6.4]) cylinder(d1=9.6, d2=6.8, h=2.4);
            // Curled soft-serve peak
            hull() {
                translate([0, 0, 8.4]) cylinder(d=6.8, h=1.0);
                translate([0.8, 0, 11.2]) sphere(d=2.6);
            }
            // Helical swirl ribs
            for (a = [0:90:270]) {
                rotate([0, 0, a])
                    hull() {
                        translate([4.8, 0, 4.6]) sphere(d=2.0);
                        translate([3.2, 1.5, 8.2]) sphere(d=1.6);
                    }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=5.5);
    }
}
module Crown_IceCreamCone() { KODIAK75_Crown_IceCreamCone(); }

// 405: KODIAK75_Crown_SprinkleDonut (Food & Candy â€” Frosted Sprinkle Donut Ring)
module KODIAK75_Crown_SprinkleDonut() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Upright frosted donut ring mounted on pedestal
            hull() {
                translate([0, -3.5, 2.0]) cylinder(d=3.6, h=2.0);
                translate([0,  3.5, 2.0]) cylinder(d=3.6, h=2.0);
            }
            translate([0, 0, 7.2])
                rotate([0, 90, 0])
                    rotate_extrude($fn=28)
                        translate([3.8, 0, 0])
                            circle(d=4.2, $fn=20);
            // Sprinkle pill bumps around top arc
            for (a = [-60, -30, 0, 30, 60]) {
                translate([0, 4.2 * sin(a), 7.2 + 4.2 * cos(a)])
                    sphere(d=1.8);
            }
        }
        top_crown_base_cuts(2.6);
    }
}
module Crown_SprinkleDonut() { KODIAK75_Crown_SprinkleDonut(); }

// 406: KODIAK75_Crown_FryBox (Food & Candy â€” Golden French Fry Carton)
module KODIAK75_Crown_FryBox() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Flared carton box
            hull() {
                translate([0, 0, 2.2]) cube([7.0, 9.6, 0.8], center=true);
                translate([0, 0, 6.2]) cube([8.2, 11.2, 0.8], center=true);
            }
            // 5 Crinkle-cut french fry sticks fanning upward
            for (i = [-2 : 2]) {
                hull() {
                    translate([0, i * 1.8, 5.5]) cube([2.2, 1.8, 1.0], center=true);
                    translate([(i % 2) * 0.8, i * 2.3, 10.5 - abs(i) * 0.6])
                        cube([2.0, 1.8, 1.2], center=true);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.2, h=4.5);
    }
}
module Crown_FryBox() { KODIAK75_Crown_FryBox(); }

// 407: KODIAK75_Crown_CupcakeSwirl (Food & Candy â€” Birthday Cupcake & Cherry)
module KODIAK75_Crown_CupcakeSwirl() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Fluted cupcake liner (12-sided star-like flutes)
            for (a = [0:30:330]) {
                rotate([0, 0, a])
                    hull() {
                        translate([4.2, 0, 2.0]) cylinder(d=2.6, h=1.0);
                        translate([5.0, 0, 5.2]) cylinder(d=2.8, h=0.8);
                    }
            }
            translate([0, 0, 2.0]) cylinder(d1=10.5, d2=11.6, h=3.8);
            // Buttercream swirl dome
            translate([0, 0, 5.6]) cylinder(d1=11.2, d2=7.8, h=2.4);
            // Top cherry sphere
            translate([0, 0, 9.2]) sphere(d=4.4);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=7.0, h=5.2);
    }
}
module Crown_CupcakeSwirl() { KODIAK75_Crown_CupcakeSwirl(); }

// 408: KODIAK75_Crown_GummyBear (Food & Candy â€” Giant Gummy Bear Totem)
module KODIAK75_Crown_GummyBear() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Chubby seated gummy torso & belly
            hull() {
                translate([0, 0, 2.0]) cylinder(d=10.4, h=2.0);
                translate([0, 0, 5.2]) sphere(d=8.8);
            }
            // Gummy bear head & snout
            hull() {
                translate([0, 0, 8.6]) sphere(d=7.2);
                translate([2.6, 0, 8.2]) sphere(d=3.6);
            }
            // Round gummy ears
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 2.4, 10.2]) sphere(d=2.4);
                    translate([0, y_s * 3.4, 11.4]) sphere(d=3.0);
                }
                // Side stubby arms
                hull() {
                    translate([1.2, y_s * 3.6, 5.2]) sphere(d=2.8);
                    translate([2.4, y_s * 4.8, 5.0]) sphere(d=2.6);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=5.5);
    }
}
module Crown_GummyBear() { KODIAK75_Crown_GummyBear(); }

// 409: KODIAK75_Crown_BobaTea (Food & Candy â€” Boba Milk Tea & Straw)
module KODIAK75_Crown_BobaTea() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Tapered boba cup & sealed dome lid
            translate([0, 0, 2.0]) cylinder(d1=10.6, d2=11.8, h=4.8);
            // Cup rim lip
            translate([0, 0, 6.4]) cylinder(d=12.6, h=0.9);
            // Clear dome lid with tapioca pearl bumps around rim
            hull() {
                translate([0, 0, 7.0]) cylinder(d=11.4, h=0.6);
                translate([0, 0, 8.6]) cylinder(d=6.8, h=0.8);
            }
            // Fat boba straw angled slightly
            hull() {
                translate([0.5, 0, 7.5]) cylinder(d=3.6, h=1.0);
                translate([1.8, 0, 11.8]) cylinder(d=3.6, h=0.8);
            }
            // Tapioca pearls around lower cup skirt
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    translate([5.2, 0, 3.2]) sphere(d=2.2);
            }
        }
        top_crown_base_cuts(2.6);
        // Hollow cup interior connected to base cuts
        translate([0, 0, 2.2]) cylinder(d=7.2, h=5.8);
    }
}
module Crown_BobaTea() { KODIAK75_Crown_BobaTea(); }

// 410: KODIAK75_Crown_ChefToque (Food & Candy â€” Master Chef Puffy Toque)
module KODIAK75_Crown_ChefToque() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Pleated headband cylinder
            translate([0, 0, 2.0]) cylinder(d1=11.6, d2=11.2, h=3.6);
            // 6 Puffy cloud lobes forming the chef toque crown
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    hull() {
                        translate([2.8, 0, 5.2]) sphere(d=4.4);
                        translate([3.6, 0, 7.8]) sphere(d=5.2);
                    }
            }
            translate([0, 0, 8.2]) sphere(d=6.8);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=7.0, h=5.8);
    }
}
module Crown_ChefToque() { KODIAK75_Crown_ChefToque(); }

// 411: KODIAK75_Crown_TRexJaw (Dino & Mythic â€” T-Rex Dino Snapper Jaw)
module KODIAK75_Crown_TRexJaw() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Heavy T-Rex skull & brow ridges
            hull() {
                translate([-1.5, 0, 2.0]) cylinder(d=11.4, h=3.2);
                translate([-2.0, 0, 7.2]) sphere(d=7.6);
                translate([ 5.2, 0, 6.2]) sphere(d=5.4);
            }
            // Lower jaw sweeps forward
            hull() {
                translate([-1.0, 0, 2.0]) cylinder(d=9.6, h=2.0);
                translate([ 4.8, 0, 3.0]) sphere(d=4.2);
            }
            // Brow hornlets & upper serrated teeth
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.5, y_s * 2.8, 7.5]) sphere(d=2.6);
                    translate([-2.5, y_s * 3.6, 9.2]) sphere(d=1.8);
                }
                for (x_t = [1.5, 3.5, 5.0]) {
                    translate([x_t, y_s * 1.8, 3.8])
                        cylinder(d1=1.2, d2=1.8, h=2.2);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=3.8);
    }
}
module Crown_TRexJaw() { KODIAK75_Crown_TRexJaw(); }

// 412: KODIAK75_Crown_TriceraFrill (Dino & Mythic â€” Triceratops 3-Horn Frill)
module KODIAK75_Crown_TriceraFrill() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Swept scalloped rear bony frill shield
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.2, h=2.2);
                translate([-4.2, -5.2, 7.8]) sphere(d=2.8);
                translate([-5.2,  0.0, 9.5]) sphere(d=3.0);
                translate([-4.2,  5.2, 7.8]) sphere(d=2.8);
            }
            // Nasal horn (+X)
            hull() {
                translate([3.2, 0, 2.2]) cylinder(d=3.6, h=2.2);
                translate([6.2, 0, 6.8]) sphere(d=1.6);
            }
            // Twin long brow horns
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 2.6, 3.8]) sphere(d=3.2);
                    translate([5.6, y_s * 3.8, 9.6]) sphere(d=1.6);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=2.6);
    }
}
module Crown_TriceraFrill() { KODIAK75_Crown_TriceraFrill(); }

// 413: KODIAK75_Crown_PteroCrest (Dino & Mythic â€” Pterodactyl Swept Cranial Crest)
module KODIAK75_Crown_PteroCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Streamlined aerodynamic beak (+X) & high swept cranial blade (-X)
            hull() {
                translate([ 6.5, 0, 2.2]) cylinder(d=2.0, h=1.8);
                translate([ 0.0, 0, 2.0]) cylinder(d=9.2, h=3.2);
                translate([-7.2, 0, 10.5]) sphere(d=2.4);
            }
            // Cheek stabilizer strakes
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.8, 2.0]) cylinder(d=2.6, h=2.0);
                    translate([-3.5, y_s * 2.0, 6.5]) sphere(d=2.0);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=5.8, h=2.8);
    }
}
module Crown_PteroCrest() { KODIAK75_Crown_PteroCrest(); }

// 414: KODIAK75_Crown_AnkyloClub (Dino & Mythic â€” Ankylosaurus Tail Mace Dome)
module KODIAK75_Crown_AnkyloClub() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Armored osteoderm central dome
            hull() {
                translate([0, 0, 2.0]) cylinder(d=12.6, h=2.0);
                translate([0, 0, 6.2]) sphere(d=8.4);
            }
            // 4 Heavy lateral impact mace lobes
            for (a = [45, 135, 225, 315]) {
                rotate([0, 0, a])
                    hull() {
                        translate([3.2, 0, 3.8]) sphere(d=4.2);
                        translate([6.2, 0, 5.2]) sphere(d=3.6);
                    }
            }
            // Apex dorsal osteoderm spike
            translate([0, 0, 6.0]) cylinder(d1=5.2, d2=1.6, h=4.2, $fn=6);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=4.8);
    }
}
module Crown_AnkyloClub() { KODIAK75_Crown_AnkyloClub(); }

// 415: KODIAK75_Crown_HydraTriHead (Dino & Mythic â€” Three-Headed Hydra Crown)
module KODIAK75_Crown_HydraTriHead() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central scaled neck trunk
            translate([0, 0, 2.0]) cylinder(d1=11.6, d2=8.4, h=3.2);
            // 3 Branching dragon heads (center forward + 2 flanking)
            for (a = [-42, 0, 42]) {
                rotate([0, 0, a]) {
                    hull() {
                        translate([1.2, 0, 4.2]) sphere(d=4.4);
                        translate([4.2, 0, 8.4]) sphere(d=3.8);
                    }
                    // Snout & crest horn
                    hull() {
                        translate([4.2, 0, 8.4]) sphere(d=3.6);
                        translate([6.6, 0, 8.0]) sphere(d=2.2);
                    }
                    hull() {
                        translate([3.6, 0, 9.0]) sphere(d=2.4);
                        translate([1.8, 0, 11.2]) sphere(d=1.4);
                    }
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.2, h=3.4);
    }
}
module Crown_HydraTriHead() { KODIAK75_Crown_HydraTriHead(); }

// 416: KODIAK75_Crown_PhoenixPlume (Dino & Mythic â€” Rising Phoenix Flame Plume)
module KODIAK75_Crown_PhoenixPlume() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central blazing flame spire
            hull() {
                translate([0, 0, 2.0]) cylinder(d=10.4, h=2.0);
                translate([-1.5, 0, 12.2]) sphere(d=2.2);
            }
            // Flanking swept fire feathers
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.0, 2.2]) cylinder(d=3.6, h=2.0);
                    translate([-2.5, y_s * 5.2, 8.8]) sphere(d=2.0);
                }
                hull() {
                    translate([2.0, y_s * 2.2, 2.2]) cylinder(d=3.2, h=2.0);
                    translate([3.5, y_s * 3.4, 6.8]) sphere(d=1.8);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=3.6);
    }
}
module Crown_PhoenixPlume() { KODIAK75_Crown_PhoenixPlume(); }

// 417: KODIAK75_Crown_GriffinBeak (Dino & Mythic â€” Golden Griffin Hooked Beak)
module KODIAK75_Crown_GriffinBeak() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Aquiline skull dome
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.4, h=2.6);
                translate([-0.5, 0, 6.8]) sphere(d=7.6);
            }
            // Hooked raptor beak curving forward and down (strictly Z >= 2.2)
            hull() {
                translate([2.0, 0, 6.2]) sphere(d=5.2);
                translate([5.8, 0, 5.2]) sphere(d=3.2);
            }
            hull() {
                translate([5.8, 0, 5.2]) sphere(d=3.2);
                translate([6.8, 0, 3.2]) sphere(d=1.8);
            }
            // Swept feathered ear tufts
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-1.0, y_s * 2.8, 6.8]) sphere(d=2.8);
                    translate([-4.8, y_s * 4.5, 10.2]) sphere(d=1.6);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=4.2);
    }
}
module Crown_GriffinBeak() { KODIAK75_Crown_GriffinBeak(); }

// 418: KODIAK75_Crown_KrakenHelm (Dino & Mythic â€” Deep-Sea Kraken Tentacle Dome)
module KODIAK75_Crown_KrakenHelm() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Bulbous octopus mantle dome tilted slightly back
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.8, h=2.2);
                translate([-1.2, 0, 7.8]) sphere(d=8.2);
            }
            // 6 Curled tentacles radiating around base
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    hull() {
                        translate([4.2, 0, 2.2]) sphere(d=3.0);
                        translate([6.8, 1.2, 4.8]) sphere(d=2.0);
                    }
            }
            // Prominent angry brow ridges
            for (y_s = [-1, 1]) {
                translate([3.2, y_s * 2.4, 5.4]) sphere(d=2.8);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=5.2);
    }
}
module Crown_KrakenHelm() { KODIAK75_Crown_KrakenHelm(); }

// 419: KODIAK75_Crown_MinotaurHorns (Dino & Mythic â€” Labyrinth Minotaur Bull Horns)
module KODIAK75_Crown_MinotaurHorns() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Heavy armored bull forehead boss
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.8, h=2.6);
                translate([0, 0, 5.8]) sphere(d=7.8);
            }
            // Twin sweeping bull horns curving outward, forward, and up
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-0.5, y_s * 2.8, 5.2]) sphere(d=4.2);
                    translate([ 1.0, y_s * 6.4, 7.2]) sphere(d=3.2);
                }
                hull() {
                    translate([ 1.0, y_s * 6.4, 7.2]) sphere(d=3.2);
                    translate([ 4.8, y_s * 5.6, 10.6]) sphere(d=1.6);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=3.8);
    }
}
module Crown_MinotaurHorns() { KODIAK75_Crown_MinotaurHorns(); }

// 420: KODIAK75_Crown_GargoyleCrest (Dino & Mythic â€” Gothic Gargoyle Winged Brow)
module KODIAK75_Crown_GargoyleCrest() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Chiseled gothic gargoyle cranium
            translate([0, 0, 2.0]) cylinder(d1=12.2, d2=8.6, h=5.2, $fn=6);
            // Bat-winged brow fins & central gothic spire
            hull() {
                translate([0, 0, 3.0]) cylinder(d=4.4, h=2.0, $fn=6);
                translate([-2.0, 0, 10.8]) sphere(d=2.2);
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.2, 2.4]) cylinder(d=3.2, h=3.0);
                    translate([-2.2, y_s * 6.8, 9.2]) sphere(d=2.0);
                    translate([ 2.5, y_s * 5.2, 6.2]) sphere(d=1.8);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=4.2);
    }
}
module Crown_GargoyleCrest() { KODIAK75_Crown_GargoyleCrest(); }

// 421: KODIAK75_Crown_UFOSaucer (Space & Alien â€” Area-51 Flying Saucer Disc)
module KODIAK75_Crown_UFOSaucer() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Saucer lower cone & wide rim (45-deg self-supporting overhang)
            translate([0, 0, 2.0]) cylinder(d1=11.2, d2=15.8, h=2.4);
            translate([0, 0, 4.4]) cylinder(d1=15.8, d2=9.8, h=1.8);
            // Bubble cockpit cupola
            translate([0, 0, 5.8]) sphere(d=7.8);
            // 6 Glowing thruster nodules anchored into saucer rim
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    hull() {
                        translate([5.6, 0, 4.4]) sphere(d=2.2);
                        translate([7.4, 0, 4.4]) sphere(d=2.0);
                    }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=4.8);
    }
}
module Crown_UFOSaucer() { KODIAK75_Crown_UFOSaucer(); }

// 422: KODIAK75_Crown_AlienTriEye (Space & Alien â€” Cosmic Alien Tri-Eye Stalks)
module KODIAK75_Crown_AlienTriEye() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Martian brain-dome base
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.8, h=2.2);
                translate([0, 0, 5.2]) sphere(d=8.2);
            }
            // 3 Eyeball stalks (center high, left/right splayed)
            for (i = [-1, 0, 1]) {
                hull() {
                    translate([0.5, i * 2.2, 4.8]) sphere(d=2.6);
                    translate([1.5 - abs(i)*0.8, i * 4.6, 9.6 + (1 - abs(i))*1.4])
                        sphere(d=2.4);
                }
                // Bulbous alien eyeball at tip
                translate([1.5 - abs(i)*0.8, i * 4.6, 9.6 + (1 - abs(i))*1.4])
                    sphere(d=4.0);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=3.8);
    }
}
module Crown_AlienTriEye() { KODIAK75_Crown_AlienTriEye(); }

// 423: KODIAK75_Crown_AstroVisor (Space & Alien â€” Apollo Gold Astronaut Helmet)
module KODIAK75_Crown_AstroVisor() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Spacesuit neck ring & spherical helmet shell
            translate([0, 0, 2.0]) cylinder(d=12.6, h=2.0);
            hull() {
                translate([0, 0, 3.8]) cylinder(d=12.0, h=1.2);
                translate([0, 0, 6.6]) sphere(d=11.2);
            }
            // Raised sun-visor shroud & side comm pods
            for (y_s = [-1, 1]) {
                translate([0, y_s * 5.4, 6.6])
                    rotate([90, 0, 0])
                        cylinder(d=3.6, h=1.6, center=true);
            }
            // Top EVA camera box
            translate([0, 0, 11.8]) cube([3.6, 4.8, 1.8], center=true);
        }
        top_crown_base_cuts(2.6);
        // Core out helmet interior from below (connected to base cuts)
        translate([0, 0, 2.2]) cylinder(d=7.4, h=6.8);
        translate([0, 0, 6.6]) sphere(d=8.2);
    }
}
module Crown_AstroVisor() { KODIAK75_Crown_AstroVisor(); }

// 424: KODIAK75_Crown_RocketSpire (Space & Alien â€” Retro Finned Rocket Nosecone)
module KODIAK75_Crown_RocketSpire() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Ogive-style rocket fuselage & nosecone
            translate([0, 0, 2.0]) cylinder(d1=10.2, d2=8.4, h=4.5);
            translate([0, 0, 6.5]) cylinder(d1=8.4, d2=1.8, h=6.0);
            translate([0, 0, 12.5]) sphere(d=1.8);
            // 3 Retro delta fins anchored into base
            for (a = [0, 120, 240]) {
                rotate([0, 0, a])
                    hull() {
                        translate([3.2, 0, 2.0]) cube([2.0, 1.8, 5.5], center=false);
                        translate([6.2, -0.8, 2.0]) cube([1.2, 1.6, 2.8], center=false);
                    }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.2, h=5.5);
    }
}
module Crown_RocketSpire() { KODIAK75_Crown_RocketSpire(); }

// 425: KODIAK75_Crown_WarpCrystal (Space & Alien â€” Hexagonal Warp Core Cluster)
module KODIAK75_Crown_WarpCrystal() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central tall hexagonal dilithium crystal
            translate([0, 0, 2.0]) cylinder(d1=6.8, d2=5.2, h=7.5, $fn=6);
            translate([0, 0, 9.5]) cylinder(d1=5.2, d2=0.8, h=3.2, $fn=6);
            // 6 Angled secondary crystal shards around perimeter
            for (a = [0:60:300]) {
                rotate([0, 0, a])
                    translate([3.4, 0, 2.0])
                        rotate([0, 18, 0]) {
                            cylinder(d1=4.2, d2=3.2, h=5.2, $fn=6);
                            translate([0, 0, 5.2]) cylinder(d1=3.2, d2=0.6, h=2.2, $fn=6);
                        }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=5.8, h=4.5);
    }
}
module Crown_WarpCrystal() { KODIAK75_Crown_WarpCrystal(); }

// 426: KODIAK75_Crown_RaygunTurret (Space & Alien â€” Retro Atomic Raygun Ring)
module KODIAK75_Crown_RaygunTurret() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Swivel turret dome
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.6, h=2.4);
                translate([-1.0, 0, 6.2]) sphere(d=7.8);
            }
            // Raygun barrel & cooling fin rings pointing forward (+X)
            hull() {
                translate([-1.0, 0, 6.2]) sphere(d=4.4);
                translate([ 7.2, 0, 6.8]) sphere(d=2.2);
            }
            // 3 Atomic cooling rings along barrel
            for (x_r = [1.8, 3.8, 5.6]) {
                translate([x_r, 0, 6.5])
                    rotate([0, 85, 0])
                        cylinder(d=5.2 - x_r*0.3, h=1.0, center=true);
            }
            // Rear fin stabilizer
            hull() {
                translate([-2.5, 0, 5.5]) sphere(d=3.0);
                translate([-5.5, 0, 9.8]) sphere(d=1.8);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.2, h=3.8);
    }
}
module Crown_RaygunTurret() { KODIAK75_Crown_RaygunTurret(); }

// 427: KODIAK75_Crown_SaturnRing (Space & Alien â€” Tilted Saturn Ringed Planet)
module KODIAK75_Crown_SaturnRing() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Pedestal collar & Saturn sphere
            translate([0, 0, 2.0]) cylinder(d1=11.2, d2=8.4, h=2.6);
            translate([0, 0, 6.8]) sphere(d=8.8);
            // Tilted planetary ring (22 deg, well within support-free angle)
            translate([0, 0, 6.8])
                rotate([22, 0, 0])
                    cylinder(d1=15.4, d2=14.6, h=1.6, center=true);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=5.5);
    }
}
module Crown_SaturnRing() { KODIAK75_Crown_SaturnRing(); }

// 428: KODIAK75_Crown_LunarRadar (Space & Alien â€” Lunar Lander Dish Array)
module KODIAK75_Crown_LunarRadar() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Octagonal gold-foil lander ascent stage base
            translate([0, 0, 2.0]) cylinder(d1=12.4, d2=10.0, h=2.8, $fn=8);
            // Parabolic dish bowl opening upward
            translate([0, 0, 4.4]) cylinder(d1=7.2, d2=14.6, h=3.8);
            // Central feed horn spire inside dish
            translate([0, 0, 4.4]) cylinder(d1=3.2, d2=1.6, h=6.8);
            translate([0, 0, 11.2]) sphere(d=2.6);
        }
        top_crown_base_cuts(2.6);
        // Dish concave interior cut from top
        translate([0, 0, 5.6]) cylinder(d1=5.0, d2=12.4, h=3.0);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=2.6);
    }
}
module Crown_LunarRadar() { KODIAK75_Crown_LunarRadar(); }

// 429: KODIAK75_Crown_MeteorCrater (Space & Alien â€” Flaming Meteorite Impact Core)
module KODIAK75_Crown_MeteorCrater() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Jagged crater rim & flaming meteorite core
            for (a = [0:45:315]) {
                rotate([0, 0, a])
                    hull() {
                        translate([4.5, 0, 2.0]) cylinder(d=3.6, h=2.2, $fn=5);
                        translate([5.6, 0, 5.8 + (a % 90 == 0 ? 1.6 : 0.0)]) sphere(d=2.2, $fn=6);
                    }
            }
            // Central flaming impact fireball trailing upward
            hull() {
                translate([0, 0, 2.2]) cylinder(d=8.4, h=2.0);
                translate([0, 0, 6.2]) sphere(d=6.8, $fn=8);
                translate([-2.2, 0, 11.2]) sphere(d=2.2);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=4.2);
    }
}
module Crown_MeteorCrater() { KODIAK75_Crown_MeteorCrater(); }

// 430: KODIAK75_Crown_StargateArch (Space & Alien â€” Portal Stargate Chevron Ring)
module KODIAK75_Crown_StargateArch() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Pedestal ramp
            hull() {
                translate([0, -4.5, 2.0]) cylinder(d=3.8, h=2.0);
                translate([0,  4.5, 2.0]) cylinder(d=3.8, h=2.0);
            }
            // Upright Stargate portal ring
            translate([0, 0, 7.6])
                rotate([0, 90, 0])
                    difference() {
                        cylinder(d=11.8, h=3.4, center=true);
                        cylinder(d=6.8, h=4.0, center=true);
                    }
            // 5 Chevron lock blocks around upper arc
            for (a = [-70, -35, 0, 35, 70]) {
                translate([0, 5.6 * sin(a), 7.6 + 5.6 * cos(a)])
                    cube([4.2, 1.8, 1.8], center=true);
            }
        }
        top_crown_base_cuts(2.6);
    }
}
module Crown_StargateArch() { KODIAK75_Crown_StargateArch(); }

// 431: KODIAK75_Crown_PixelHeart (Arcade & Pirate â€” 8-Bit Arcade Voxel Heart)
module KODIAK75_Crown_PixelHeart() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Stepped 8-bit voxel heart layers (self-supporting 45-deg stepped bevels)
            translate([0, 0, 2.0]) cylinder(d=10.8, h=1.6);
            translate([0, 0, 4.2]) cube([3.8, 5.2, 2.2], center=true);
            translate([0, 0, 6.0]) cube([3.8, 8.4, 2.2], center=true);
            translate([0, 0, 7.8]) cube([3.8, 11.2, 2.2], center=true);
            // Twin upper heart lobes
            for (y_s = [-1, 1]) {
                translate([0, y_s * 3.0, 9.6]) cube([3.8, 4.2, 2.0], center=true);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=5.6, h=2.2);
    }
}
module Crown_PixelHeart() { KODIAK75_Crown_PixelHeart(); }

// 432: KODIAK75_Crown_ArcadeJoystick (Arcade & Pirate â€” Classic Ball-Top Arcade Stick)
module KODIAK75_Crown_ArcadeJoystick() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Black dust-washer collar & rubber boot bellow tiers
            translate([0, 0, 2.0]) cylinder(d=13.2, h=1.4);
            translate([0, 0, 3.4]) cylinder(d1=9.6, d2=7.2, h=1.8);
            // Robust shaft & classic arcade ball-top
            translate([0, 0, 5.0]) cylinder(d=4.4, h=3.8);
            translate([0, 0, 9.6]) sphere(d=7.8);
            // 2 Arcade fire buttons on base deck
            for (y_s = [-1, 1]) {
                translate([3.6, y_s * 3.4, 2.6]) cylinder(d=3.2, h=1.6);
            }
        }
        top_crown_base_cuts(2.6);
    }
}
module Crown_ArcadeJoystick() { KODIAK75_Crown_ArcadeJoystick(); }

// 433: KODIAK75_Crown_TrophyCup (Arcade & Pirate â€” Grand Champion Trophy Cup)
module KODIAK75_Crown_TrophyCup() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Pedestal & trophy stem
            translate([0, 0, 2.0]) cylinder(d1=11.4, d2=6.8, h=2.6);
            // Flared golden chalice bowl
            translate([0, 0, 4.6]) cylinder(d1=6.8, d2=11.8, h=5.6);
            // Twin champion handles anchored at 45 deg
            for (y_s = [-1, 1]) {
                hull() {
                    translate([0, y_s * 3.2, 4.8]) sphere(d=2.2);
                    translate([0, y_s * 6.8, 7.6]) sphere(d=2.2);
                }
                hull() {
                    translate([0, y_s * 6.8, 7.6]) sphere(d=2.2);
                    translate([0, y_s * 5.2, 9.6]) sphere(d=2.2);
                }
            }
        }
        top_crown_base_cuts(2.6);
        // Open top cup bowl cavity
        translate([0, 0, 6.2]) cylinder(d1=5.2, d2=9.2, h=4.5);
    }
}
module Crown_TrophyCup() { KODIAK75_Crown_TrophyCup(); }

// 434: KODIAK75_Crown_KingChess (Arcade & Pirate â€” Grandmaster Chess King Cross)
module KODIAK75_Crown_KingChess() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Baluster collar & flared chess crown
            translate([0, 0, 2.0]) cylinder(d1=11.8, d2=8.0, h=2.4);
            translate([0, 0, 4.4]) cylinder(d=10.2, h=1.2);
            translate([0, 0, 5.6]) cylinder(d1=7.8, d2=10.4, h=3.2);
            // Finial dome & royal cross on top
            translate([0, 0, 8.8]) cylinder(d1=10.4, d2=5.2, h=1.4);
            translate([0, 0, 11.4]) cube([2.4, 2.4, 3.6], center=true);
            translate([0, 0, 11.6]) cube([2.4, 5.2, 1.8], center=true);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=5.8, h=5.5);
    }
}
module Crown_KingChess() { KODIAK75_Crown_KingChess(); }

// 435: KODIAK75_Crown_PirateTricorn (Arcade & Pirate â€” Captain's Pirate Tricorn Hat)
module KODIAK75_Crown_PirateTricorn() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Central skullcap dome
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.8, h=2.2);
                translate([0, 0, 6.2]) sphere(d=8.4);
            }
            // Three folded tricorn upturned brims (120 deg apart)
            for (a = [0, 120, 240]) {
                rotate([0, 0, a])
                    hull() {
                        translate([5.6, 0, 4.2]) sphere(d=2.8);
                        translate([-2.6,  5.6, 7.2]) sphere(d=2.6);
                        translate([-2.6, -5.6, 7.2]) sphere(d=2.6);
                    }
            }
            // Captain's feather plume on side
            hull() {
                translate([0, 3.8, 5.5]) sphere(d=2.4);
                translate([-3.5, 4.5, 10.2]) sphere(d=2.0);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=4.8);
    }
}
module Crown_PirateTricorn() { KODIAK75_Crown_PirateTricorn(); }

// 436: KODIAK75_Crown_SubPeriscope (Arcade & Pirate â€” Submarine Twin Periscope Tower)
module KODIAK75_Crown_SubPeriscope() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Streamlined submarine conning tower sail
            hull() {
                translate([ 3.2, 0, 2.0]) cylinder(d=5.8, h=4.8);
                translate([-3.2, 0, 2.0]) cylinder(d=4.4, h=4.8);
            }
            // Diving planes on conning tower sides
            hull() {
                translate([1.0, -5.8, 4.6]) sphere(d=1.8);
                translate([1.0,  5.8, 4.6]) sphere(d=1.8);
                translate([0.0,  0.0, 3.2]) sphere(d=3.6);
            }
            // Primary tall attack periscope (+X Hood)
            translate([1.8, 0, 6.2]) cylinder(d=3.6, h=4.4);
            hull() {
                translate([1.8, 0, 10.2]) sphere(d=3.8);
                translate([4.4, 0, 10.2]) cylinder(d=3.4, h=1.2, center=true);
            }
            // Secondary radar mast (-X)
            translate([-2.4, 0, 6.2]) cylinder(d=2.8, h=3.2);
            translate([-2.4, 0, 9.4]) sphere(d=3.2);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=5.8, h=3.8);
    }
}
module Crown_SubPeriscope() { KODIAK75_Crown_SubPeriscope(); }

// 437: KODIAK75_Crown_Hammerhead (Arcade & Pirate â€” Hammerhead Shark T-Foil)
module KODIAK75_Crown_Hammerhead() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Shark dorsal body & tall dorsal fin
            hull() {
                translate([ 3.5, 0, 2.0]) cylinder(d=6.8, h=3.2);
                translate([-3.5, 0, 2.0]) cylinder(d=5.6, h=3.2);
                translate([-3.0, 0, 10.5]) sphere(d=2.0);
            }
            // Wide cephalofoil T-hammer head across Y-axis with lateral eye pods
            hull() {
                translate([2.8, -6.8, 4.6]) cylinder(d=3.4, h=2.2);
                translate([2.8,  6.8, 4.6]) cylinder(d=3.4, h=2.2);
                translate([0.5,  0.0, 2.2]) cylinder(d=6.8, h=3.0);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=3.2);
    }
}
module Crown_Hammerhead() { KODIAK75_Crown_Hammerhead(); }

// 438: KODIAK75_Crown_NarwhalTusk (Arcade & Pirate â€” Arctic Narwhal Spiral Tusk)
module KODIAK75_Crown_NarwhalTusk() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Rounded Arctic narwhal melon head & blowhole ridge
            hull() {
                translate([0, 0, 2.0]) cylinder(d=11.8, h=2.2);
                translate([-0.8, 0, 5.8]) sphere(d=8.4);
            }
            // Long spiral unicorn tusk jutting forward and upward
            hull() {
                translate([1.8, 0, 5.2]) sphere(d=4.0);
                translate([7.8, 0, 11.4]) sphere(d=1.6);
            }
            // Spiral collars along tusk
            for (t = [0.25, 0.50, 0.75]) {
                translate([1.8 + t*6.0, 0, 5.2 + t*6.2])
                    sphere(d=3.8 - t*1.6);
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.4, h=4.0);
    }
}
module Crown_NarwhalTusk() { KODIAK75_Crown_NarwhalTusk(); }

// 439: KODIAK75_Crown_VikingShip (Arcade & Pirate â€” Longship Dragon Figurehead)
module KODIAK75_Crown_VikingShip() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Clinker hull prow curving up into dragon neck
            hull() {
                translate([-4.0, 0, 2.0]) cylinder(d=8.8, h=2.4);
                translate([ 2.5, 0, 2.0]) cylinder(d=6.8, h=3.2);
                translate([ 4.2, 0, 8.8]) sphere(d=4.0);
            }
            // Snarling dragon figurehead snout & mane crest
            hull() {
                translate([4.2, 0, 8.8]) sphere(d=4.0);
                translate([7.0, 0, 8.2]) sphere(d=2.4);
            }
            hull() {
                translate([3.2, 0, 9.4]) sphere(d=2.8);
                translate([0.5, 0, 11.4]) sphere(d=1.8);
            }
            // Viking round shields mounted along both gunwales
            for (y_s = [-1, 1]) {
                for (x_p = [-2.2, 1.5]) {
                    translate([x_p, y_s * 4.2, 4.0])
                        sphere(d=3.4);
                }
            }
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.0, h=3.2);
    }
}
module Crown_VikingShip() { KODIAK75_Crown_VikingShip(); }

// 440: KODIAK75_Crown_DiscoBall (Arcade & Pirate â€” Faceted Party Disco Sphere)
module KODIAK75_Crown_DiscoBall() {
    difference() {
        union() {
            top_crown_base_solid(15.6, 2.6);
            // Mirrored pedestal collar
            translate([0, 0, 2.0]) cylinder(d1=11.6, d2=8.4, h=2.4, $fn=12);
            // Low-poly faceted disco ball sphere ($fn=10 gives crisp mirror tiles)
            translate([0, 0, 7.4]) sphere(d=10.6, $fn=10);
            // Top party star ring
            translate([0, 0, 11.8]) cylinder(d1=4.8, d2=2.4, h=1.4, $fn=8);
        }
        top_crown_base_cuts(2.6);
        translate([0, 0, 2.2]) cylinder(d=6.8, h=6.2);
    }
}
module Crown_DiscoBall() { KODIAK75_Crown_DiscoBall(); }


// ============================================================================
// ZONES 2 & 3: 35 NEW CREATIVE LEFT/RIGHT CHEEK POD PAIRS (PART_ID = 501..535)
// Each module renders Left & Right pair via:
//   for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0])
// ============================================================================

// 501: KODIAK75_Cheek_HotDogPods (Food & Candy â€” Twin Hot Dog Bun Bumpers)
module single_cheek_501() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Split hot-dog bun cushions
            for (y_b = [3.4, 7.6]) {
                hull() {
                    translate([-6.2, y_b, 0]) cylinder(d=3.4, h=2.2);
                    translate([ 6.2, y_b, 0]) cylinder(d=3.4, h=2.2);
                }
            }
            // Frankfurter sausage & wavy mustard zigzag down center
            hull() {
                translate([-7.8, 5.5, 0]) cylinder(d=3.2, h=2.8);
                translate([ 7.8, 5.5, 0]) cylinder(d=3.2, h=2.8);
            }
        }
        cheek_hub_cuts(2.2);
        for (x_r = [-3.2, 3.2]) translate([x_r, 5.5, -0.1]) cylinder(d=4.6, h=1.6);
    }
}
module KODIAK75_Cheek_HotDogPods() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_501();
}
module Cheek_HotDogPods() { KODIAK75_Cheek_HotDogPods(); }

// 502: KODIAK75_Cheek_PopsicleTwins (Food & Candy â€” Twin Ice Popsicle Blades)
module single_cheek_502() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Wooden popsicle stick connecting hub to bar
            hull() {
                translate([0, 2.0, 0]) cylinder(d=3.6, h=2.0);
                translate([0, 5.2, 0]) cylinder(d=3.6, h=2.0);
            }
            // Twin-stick rounded ice-pop bar
            hull() {
                translate([-3.8, 5.0, 0]) cylinder(d=3.8, h=2.4);
                translate([ 3.8, 5.0, 0]) cylinder(d=3.8, h=2.4);
                translate([-3.4, 11.2, 0]) cylinder(d=3.8, h=2.2);
                translate([ 3.4, 11.2, 0]) cylinder(d=3.8, h=2.2);
            }
        }
        cheek_hub_cuts(2.2);
        // Twin drip flutes on top face
        for (x_g = [-1.8, 1.8]) {
            translate([x_g, 8.2, 1.6]) cube([1.2, 4.8, 1.2], center=true);
        }
        translate([0, 8.2, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_PopsicleTwins() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_502();
}
module Cheek_PopsicleTwins() { KODIAK75_Cheek_PopsicleTwins(); }

// 503: KODIAK75_Cheek_WaffleGrids (Food & Candy â€” Belgian Waffle Grid Bumpers)
module single_cheek_503() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            hull() {
                translate([-5.2, 3.2, 0]) cylinder(d=3.6, h=2.4);
                translate([ 5.2, 3.2, 0]) cylinder(d=3.6, h=2.4);
                translate([-4.8, 9.6, 0]) cylinder(d=3.6, h=2.4);
                translate([ 4.8, 9.6, 0]) cylinder(d=3.6, h=2.4);
            }
        }
        cheek_hub_cuts(2.2);
        // Belgian waffle square pockets on top & bottom
        for (x_p = [-3.2, 0.0, 3.2]) {
            for (y_p = [5.0, 8.0]) {
                translate([x_p, y_p, 1.4]) cube([2.0, 2.0, 1.6], center=true);
            }
        }
        translate([0, 6.5, -0.1]) cylinder(d=4.6, h=1.2);
    }
}
module KODIAK75_Cheek_WaffleGrids() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_503();
}
module Cheek_WaffleGrids() { KODIAK75_Cheek_WaffleGrids(); }

// 504: KODIAK75_Cheek_PretzelLoops (Food & Candy â€” Salted Pretzel Twist Pods)
module single_cheek_504() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Left & right pretzel loops + central twisted knot
            for (x_s = [-1, 1]) {
                translate([x_s * 3.4, 6.2, 0])
                    difference() {
                        cylinder(d=7.2, h=2.2);
                        translate([0, 0, -0.1]) cylinder(d=3.2, h=2.5);
                    }
            }
            // Central twist crossover & salt crystals
            translate([0, 4.5, 0]) cylinder(d=4.6, h=2.6);
            for (x_s = [-4.2, 0, 4.2]) {
                translate([x_s, 8.2, 2.2]) cube([1.2, 1.2, 0.8], center=true);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_PretzelLoops() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_504();
}
module Cheek_PretzelLoops() { KODIAK75_Cheek_PretzelLoops(); }

// 505: KODIAK75_Cheek_CandyCanes (Food & Candy â€” Peppermint Candy Cane Hooks)
module single_cheek_505() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Straight peppermint cane stem & J-hook crook at front (+X)
            hull() {
                translate([-6.5, 3.8, 0]) cylinder(d=3.4, h=2.4);
                translate([ 4.5, 4.2, 0]) cylinder(d=3.6, h=2.4);
            }
            hull() {
                translate([4.5, 4.2, 0]) cylinder(d=3.6, h=2.4);
                translate([7.2, 7.2, 0]) cylinder(d=3.4, h=2.4);
            }
            hull() {
                translate([7.2, 7.2, 0]) cylinder(d=3.4, h=2.4);
                translate([4.2, 9.8, 0]) cylinder(d=3.2, h=2.4);
            }
            hull() {
                translate([4.2, 9.8, 0]) cylinder(d=3.2, h=2.4);
                translate([1.5, 7.8, 0]) cylinder(d=3.0, h=2.2);
            }
        }
        cheek_hub_cuts(2.2);
        // Diagonal candy stripe notches
        for (x_g = [-4.0, -0.5, 3.0]) {
            translate([x_g, 4.2, 2.2]) rotate([0, 0, 35]) cube([1.0, 4.2, 0.8], center=true);
        }
    }
}
module KODIAK75_Cheek_CandyCanes() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_505();
}
module Cheek_CandyCanes() { KODIAK75_Cheek_CandyCanes(); }

// 506: KODIAK75_Cheek_CookieShields (Food & Candy â€” Choc-Chip Cookie Bucklers)
module single_cheek_506() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Scalloped cookie disc
            translate([0, 6.4, 0]) cylinder(d1=10.8, d2=10.0, h=2.2);
            // Chocolate chip morsels on top
            for (pt = [[-2.5, 5.2], [2.5, 5.2], [0, 8.2], [-2.2, 8.8], [2.2, 8.8]]) {
                translate([pt[0], pt[1], 2.0]) cylinder(d1=2.2, d2=1.0, h=1.0);
            }
        }
        cheek_hub_cuts(2.2);
        // Crisp bite marks on outer edge + bottom weight relief
        translate([4.6, 9.8, -0.1]) cylinder(d=3.2, h=2.6);
        translate([0, 6.4, -0.1]) cylinder(d=5.2, h=1.2);
    }
}
module KODIAK75_Cheek_CookieShields() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_506();
}
module Cheek_CookieShields() { KODIAK75_Cheek_CookieShields(); }

// 507: KODIAK75_Cheek_CroissantHorns (Food & Candy â€” Crescent Croissant Bumpers)
module single_cheek_507() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Central flaky pastry belly & curved crescent horn tips
            hull() {
                translate([0, 6.2, 0]) cylinder(d=5.8, h=2.6);
                translate([-4.8, 4.8, 0]) cylinder(d=4.2, h=2.2);
                translate([ 4.8, 4.8, 0]) cylinder(d=4.2, h=2.2);
            }
            for (x_s = [-1, 1]) {
                hull() {
                    translate([x_s * 4.8, 4.8, 0]) cylinder(d=4.2, h=2.2);
                    translate([x_s * 7.8, 2.2, 0]) cylinder(d=2.4, h=1.8);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 6.0, -0.1]) cylinder(d=4.0, h=1.4);
    }
}
module KODIAK75_Cheek_CroissantHorns() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_507();
}
module Cheek_CroissantHorns() { KODIAK75_Cheek_CroissantHorns(); }

// 508: KODIAK75_Cheek_WatermelonWedges (Food & Candy â€” Juicy Watermelon Slice Fins)
module single_cheek_508() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Semicircular watermelon slice & thicker outer rind rim
            intersection() {
                translate([0, 2.2, 0]) cylinder(d=14.8, h=2.2);
                translate([-8.0, 2.0, 0]) cube([16.0, 9.0, 3.0]);
            }
            intersection() {
                difference() {
                    translate([0, 2.2, 0]) cylinder(d=14.8, h=2.8);
                    translate([0, 2.2, -0.1]) cylinder(d=11.6, h=3.0);
                }
                translate([-8.0, 2.0, 0]) cube([16.0, 9.0, 3.0]);
            }
        }
        cheek_hub_cuts(2.2);
        // Teardrop seed divots
        for (a = [-35, 0, 35]) {
            translate([4.4 * sin(a), 2.2 + 4.4 * cos(a), 1.4])
                cylinder(d=1.6, h=1.2);
        }
        translate([0, 5.2, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_WatermelonWedges() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_508();
}
module Cheek_WatermelonWedges() { KODIAK75_Cheek_WatermelonWedges(); }

// 509: KODIAK75_Cheek_WyvernWings (Dino & Mythic â€” Spiked Wyvern Membrane Wings)
module single_cheek_509() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Leading-edge wing bone &thumb claw (+X)
            hull() {
                translate([2.0, 2.0, 0]) cylinder(d=3.4, h=2.4);
                translate([6.5, 9.2, 0]) cylinder(d=2.6, h=2.2);
                translate([8.2, 10.5, 0]) cylinder(d=1.4, h=1.8);
            }
            // Scalloped bat-membrane ribs
            hull() {
                translate([6.5, 9.2, 0]) cylinder(d=2.2, h=1.8);
                translate([0.0, 9.8, 0]) cylinder(d=2.2, h=1.8);
                translate([0.0, 2.2, 0]) cylinder(d=4.0, h=2.0);
            }
            hull() {
                translate([ 0.0, 9.8, 0]) cylinder(d=2.2, h=1.6);
                translate([-6.2, 8.2, 0]) cylinder(d=2.2, h=1.8);
                translate([-4.0, 1.8, 0]) cylinder(d=3.6, h=1.8);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.8, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_WyvernWings() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_509();
}
module Cheek_WyvernWings() { KODIAK75_Cheek_WyvernWings(); }

// 510: KODIAK75_Cheek_RaptorClaws (Dino & Mythic â€” Velociraptor Sickle Talons)
module single_cheek_510() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Knuckle root pad
            hull() {
                translate([-3.5, 2.4, 0]) cylinder(d=4.2, h=2.4);
                translate([ 3.5, 2.4, 0]) cylinder(d=4.2, h=2.4);
            }
            // Giant curved sickle killer-claw (+X) & secondary slasher (-X)
            hull() {
                translate([1.5, 2.8, 0]) cylinder(d=4.2, h=2.6);
                translate([5.2, 7.6, 0]) cylinder(d=3.0, h=2.2);
            }
            hull() {
                translate([5.2, 7.6, 0]) cylinder(d=3.0, h=2.2);
                translate([8.4, 5.2, 0]) cylinder(d=1.6, h=1.6);
            }
            hull() {
                translate([-2.5, 2.8, 0]) cylinder(d=3.6, h=2.2);
                translate([-0.5, 8.8, 0]) cylinder(d=2.2, h=1.8);
                translate([ 2.2, 10.2, 0]) cylinder(d=1.4, h=1.4);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_RaptorClaws() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_510();
}
module Cheek_RaptorClaws() { KODIAK75_Cheek_RaptorClaws(); }

// 511: KODIAK75_Cheek_StegoSpikes (Dino & Mythic â€” Stegosaurus Thagomizer Spikes)
module single_cheek_511() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Pentagonal dorsal plate + twin thagomizer tail spikes
            hull() {
                translate([-3.6, 2.2, 0]) cylinder(d=3.6, h=2.2);
                translate([ 3.6, 2.2, 0]) cylinder(d=3.6, h=2.2);
                translate([-5.2, 6.8, 0]) cylinder(d=2.4, h=2.0);
                translate([ 5.2, 6.8, 0]) cylinder(d=2.4, h=2.0);
                translate([ 0.0, 11.4, 0]) cylinder(d=2.0, h=2.4);
            }
            // Flanking thagomizer spikes
            for (x_s = [-1, 1]) {
                hull() {
                    translate([x_s * 3.5, 3.0, 0]) cylinder(d=3.0, h=2.4);
                    translate([x_s * 8.2, 8.6, 0]) cylinder(d=1.4, h=1.6);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.8, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_StegoSpikes() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_511();
}
module Cheek_StegoSpikes() { KODIAK75_Cheek_StegoSpikes(); }

// 512: KODIAK75_Cheek_PteroGliders (Dino & Mythic â€” Pteranodon Finger-Strut Wings)
module single_cheek_512() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Swept-back elongated wing-finger spar & membrane
            hull() {
                translate([ 5.2, 2.2, 0]) cylinder(d=3.6, h=2.4);
                translate([-7.8, 10.6, 0]) cylinder(d=2.2, h=2.0);
            }
            hull() {
                translate([ 5.2, 2.2, 0]) cylinder(d=2.8, h=1.6);
                translate([-5.2, 2.0, 0]) cylinder(d=2.8, h=1.6);
                translate([-7.8, 10.6, 0]) cylinder(d=2.0, h=1.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([-1.5, 5.0, -0.1]) cylinder(d=4.0, h=1.1);
    }
}
module KODIAK75_Cheek_PteroGliders() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_512();
}
module Cheek_PteroGliders() { KODIAK75_Cheek_PteroGliders(); }

// 513: KODIAK75_Cheek_PhoenixWings (Dino & Mythic â€” Blazing Phoenix Feather Fans)
module single_cheek_513() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // 4 Overlapping flame-tipped primary feathers fanning backward
            for (i = [0 : 3]) {
                ang = -25 + i * 16;
                len = [10.2, 11.8, 11.2, 9.4][i];
                rotate([0, 0, ang])
                    hull() {
                        translate([0, 2.2, 0]) cylinder(d=3.4, h=2.2);
                        translate([-1.2, len, 0]) cylinder(d=2.0, h=1.8);
                    }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.2, -0.1]) cylinder(d=4.0, h=1.2);
    }
}
module KODIAK75_Cheek_PhoenixWings() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_513();
}
module Cheek_PhoenixWings() { KODIAK75_Cheek_PhoenixWings(); }

// 514: KODIAK75_Cheek_KrakenArms (Dino & Mythic â€” Suction-Cup Kraken Tentacles)
module single_cheek_514() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // S-curving octopus tentacle with raised suction-cup rings
            hull() {
                translate([-3.5, 2.2, 0]) cylinder(d=4.4, h=2.4);
                translate([ 2.5, 5.8, 0]) cylinder(d=3.8, h=2.2);
            }
            hull() {
                translate([ 2.5, 5.8, 0]) cylinder(d=3.8, h=2.2);
                translate([-2.8, 9.6, 0]) cylinder(d=3.0, h=2.0);
            }
            hull() {
                translate([-2.8, 9.6, 0]) cylinder(d=3.0, h=2.0);
                translate([-6.2, 8.2, 0]) cylinder(d=1.8, h=1.8);
            }
            // Suction cup nodules along top of tentacle
            for (pt = [[-1.0, 3.8], [2.2, 5.8], [0.0, 7.8], [-2.8, 9.6]]) {
                translate([pt[0], pt[1], 2.0]) cylinder(d=2.2, h=0.8);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_KrakenArms() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_514();
}
module Cheek_KrakenArms() { KODIAK75_Cheek_KrakenArms(); }

// 515: KODIAK75_Cheek_PegasusWings (Dino & Mythic â€” Mythic Pegasus Feathered Wings)
module single_cheek_515() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Sculpted arched shoulder & 3 tiered pinion feathers
            hull() {
                translate([3.8, 2.2, 0]) cylinder(d=4.0, h=2.4);
                translate([5.2, 6.8, 0]) cylinder(d=3.6, h=2.4);
            }
            for (i = [0 : 2]) {
                hull() {
                    translate([5.2 - i*2.6, 6.8 + i*1.2, 0]) cylinder(d=3.4 - i*0.4, h=2.2 - i*0.2);
                    translate([-6.8 - i*0.8, 5.4 + i*2.2, 0]) cylinder(d=2.2, h=1.8);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.5, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_PegasusWings() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_515();
}
module Cheek_PegasusWings() { KODIAK75_Cheek_PegasusWings(); }

// 516: KODIAK75_Cheek_SolarPanels (Space & Alien â€” Deployable Satellite Solar Arrays)
module single_cheek_516() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Deployment yoke & rectangular photovoltaic wing panel
            translate([0, 3.2, 1.0]) cube([4.2, 3.0, 2.0], center=true);
            hull() {
                translate([-5.4, 4.8, 0]) cylinder(d=2.4, h=2.0);
                translate([ 5.4, 4.8, 0]) cylinder(d=2.4, h=2.0);
                translate([-5.4, 11.2, 0]) cylinder(d=2.4, h=2.0);
                translate([ 5.4, 11.2, 0]) cylinder(d=2.4, h=2.0);
            }
        }
        cheek_hub_cuts(2.2);
        // Solar cell grid score lines
        for (x_g = [-3.2, 0, 3.2]) {
            translate([x_g, 8.0, 1.8]) cube([0.7, 7.6, 0.8], center=true);
        }
        translate([0, 8.0, 1.8]) cube([11.8, 0.7, 0.8], center=true);
        translate([0, 8.0, -0.1]) cylinder(d=4.8, h=1.0);
    }
}
module KODIAK75_Cheek_SolarPanels() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_516();
}
module Cheek_SolarPanels() { KODIAK75_Cheek_SolarPanels(); }

// 517: KODIAK75_Cheek_IonCannons (Space & Alien â€” Twin Orbital Ion Cannon Pods)
module single_cheek_517() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Armored cannon housing & dual forward emitter barrels (+X)
            hull() {
                translate([-4.5, 4.8, 0]) cylinder(d=4.4, h=2.6);
                translate([ 2.5, 5.8, 0]) cylinder(d=5.2, h=2.6);
            }
            for (y_b = [4.2, 7.6]) {
                hull() {
                    translate([1.0, y_b, 0]) cylinder(d=2.8, h=2.2);
                    translate([8.4, y_b, 0]) cylinder(d=2.4, h=2.0);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([-1.0, 5.2, -0.1]) cylinder(d=4.0, h=1.4);
    }
}
module KODIAK75_Cheek_IonCannons() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_517();
}
module Cheek_IonCannons() { KODIAK75_Cheek_IonCannons(); }

// 518: KODIAK75_Cheek_AsteroidPods (Space & Alien â€” Cratered Asteroid Rock Shields)
module single_cheek_518() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Low-poly boulder cluster ($fn=7)
            hull() {
                translate([-3.8, 4.8, 0]) cylinder(d=6.2, h=2.6, $fn=7);
                translate([ 3.8, 5.4, 0]) cylinder(d=6.8, h=2.8, $fn=7);
                translate([ 0.0, 9.2, 0]) cylinder(d=5.8, h=2.4, $fn=6);
            }
        }
        cheek_hub_cuts(2.2);
        // Meteorite impact craters on top face
        translate([-2.2, 5.8, 1.8]) cylinder(d1=1.8, d2=3.4, h=1.4);
        translate([ 2.6, 6.2, 1.8]) cylinder(d1=2.0, d2=3.8, h=1.4);
        translate([ 0.0, 6.0, -0.1]) cylinder(d=4.8, h=1.3);
    }
}
module KODIAK75_Cheek_AsteroidPods() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_518();
}
module Cheek_AsteroidPods() { KODIAK75_Cheek_AsteroidPods(); }

// 519: KODIAK75_Cheek_PlasmaCoils (Space & Alien â€” Ribbed Tesla Plasma Inductors)
module single_cheek_519() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Central plasma core spine
            hull() {
                translate([-6.8, 5.6, 0]) cylinder(d=3.6, h=2.2);
                translate([ 6.8, 5.6, 0]) cylinder(d=3.6, h=2.2);
            }
            // 4 Raised toroidal inductor coil ribs
            for (x_c = [-4.5, -1.5, 1.5, 4.5]) {
                hull() {
                    translate([x_c, 2.2, 0]) cylinder(d=2.0, h=2.4);
                    translate([x_c, 8.8, 0]) cylinder(d=2.2, h=2.8);
                }
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.6, -0.1]) cylinder(d=4.2, h=1.2);
    }
}
module KODIAK75_Cheek_PlasmaCoils() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_519();
}
module Cheek_PlasmaCoils() { KODIAK75_Cheek_PlasmaCoils(); }

// 520: KODIAK75_Cheek_StarCruiserFins (Space & Alien â€” Galactic Cruiser Twin Pylons)
module single_cheek_520() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Swept aerodynamic pylon & outboard warp thruster pod
            hull() {
                translate([-4.0, 2.0, 0]) cylinder(d=3.6, h=2.0);
                translate([ 4.0, 2.0, 0]) cylinder(d=3.6, h=2.0);
                translate([-2.5, 8.8, 0]) cylinder(d=3.0, h=2.0);
            }
            hull() {
                translate([ 6.8, 8.8, 0]) cylinder(d=2.8, h=2.6);
                translate([-7.2, 8.8, 0]) cylinder(d=3.4, h=2.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.5, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_StarCruiserFins() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_520();
}
module Cheek_StarCruiserFins() { KODIAK75_Cheek_StarCruiserFins(); }

// 521: KODIAK75_Cheek_GravityRings (Space & Alien â€” Gyroscopic Anti-Grav Rings)
module single_cheek_521() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Outer anti-grav ring & central levitation core connected by struts
            translate([0, 6.8, 0]) cylinder(d=11.2, h=2.2);
            translate([0, 6.8, 0]) cylinder(d=4.4, h=2.8);
            translate([0, 6.8, 1.1]) cube([11.0, 2.2, 2.2], center=true);
            translate([0, 6.8, 1.1]) cube([2.2, 11.0, 2.2], center=true);
        }
        cheek_hub_cuts(2.2);
        // 4 Arc quadrant cutouts forming the gyro ring
        difference() {
            translate([0, 6.8, -0.1]) cylinder(d=7.8, h=2.6);
            translate([0, 6.8, -0.2]) cylinder(d=4.4, h=3.0);
            translate([0, 6.8, 1.1]) cube([11.4, 2.2, 2.8], center=true);
            translate([0, 6.8, 1.1]) cube([2.2, 11.4, 2.8], center=true);
        }
    }
}
module KODIAK75_Cheek_GravityRings() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_521();
}
module Cheek_GravityRings() { KODIAK75_Cheek_GravityRings(); }

// 522: KODIAK75_Cheek_AlienBlasters (Space & Alien â€” Retro Saucer Ray-Blasters)
module single_cheek_522() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Bulbous retro raygun chamber & finned emitter tip
            translate([-2.0, 6.0, 0]) cylinder(d=6.8, h=2.6);
            hull() {
                translate([-2.0, 6.0, 0]) cylinder(d=4.2, h=2.2);
                translate([ 7.8, 6.0, 0]) cylinder(d=2.2, h=2.0);
            }
            for (x_r = [2.2, 4.8]) {
                translate([x_r, 6.0, 0]) cylinder(d=4.8 - x_r*0.2, h=2.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([-2.0, 6.0, -0.1]) cylinder(d=4.2, h=1.4);
    }
}
module KODIAK75_Cheek_AlienBlasters() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_522();
}
module Cheek_AlienBlasters() { KODIAK75_Cheek_AlienBlasters(); }

// 523: KODIAK75_Cheek_BoxingGloves (Arcade & Pirate â€” Heavyweight KO Boxing Gloves)
module single_cheek_523() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Laced wrist cuff (-X) & bulbous padded boxing fist (+X)
            hull() {
                translate([-5.2, 5.2, 0]) cylinder(d=4.8, h=2.2);
                translate([-1.2, 5.2, 0]) cylinder(d=5.2, h=2.4);
            }
            hull() {
                translate([0.5, 5.2, 0]) cylinder(d=6.6, h=2.8);
                translate([4.6, 6.2, 0]) cylinder(d=6.8, h=2.8);
            }
            // Curled thumb bolster on inner side
            hull() {
                translate([0.5, 2.8, 0]) cylinder(d=3.6, h=2.6);
                translate([3.8, 3.2, 0]) cylinder(d=3.8, h=2.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([2.2, 5.8, -0.1]) cylinder(d=4.8, h=1.5);
    }
}
module KODIAK75_Cheek_BoxingGloves() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_523();
}
module Cheek_BoxingGloves() { KODIAK75_Cheek_BoxingGloves(); }

// 524: KODIAK75_Cheek_PixelSwords (Arcade & Pirate â€” 8-Bit Diamond Voxel Swords)
module single_cheek_524() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Pommel & hilt (-X), stepped crossguard, and voxel blade (+X)
            hull() {
                translate([-6.8, 3.8, 0]) cube([2.8, 2.8, 2.2]);
                translate([-2.2, 5.2, 0]) cube([2.4, 2.4, 2.2]);
            }
            // Crossguard
            hull() {
                translate([-2.5, 2.0, 0]) cube([2.4, 2.4, 2.4]);
                translate([-0.5, 9.2, 0]) cube([2.4, 2.4, 2.4]);
            }
            // Voxel blade jutting forward (+X)
            hull() {
                translate([-1.0, 5.2, 0]) cube([2.6, 3.0, 2.2]);
                translate([ 6.8, 7.6, 0]) cube([2.2, 2.2, 2.0]);
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_PixelSwords() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_524();
}
module Cheek_PixelSwords() { KODIAK75_Cheek_PixelSwords(); }

// 525: KODIAK75_Cheek_CheckeredFlags (Arcade & Pirate â€” Grand Prix Checkered Pennants)
module single_cheek_525() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Flagpole mast (+X) & waving racing pennant (-X)
            hull() {
                translate([5.6, 1.8, 0]) cylinder(d=2.6, h=2.4);
                translate([4.2, 10.6, 0]) cylinder(d=2.4, h=2.4);
            }
            hull() {
                translate([ 4.4, 4.2, 0]) cylinder(d=2.6, h=2.2);
                translate([ 4.0, 10.2, 0]) cylinder(d=2.6, h=2.2);
                translate([-5.8, 5.2, 0]) cylinder(d=2.4, h=2.0);
                translate([-6.4, 9.6, 0]) cylinder(d=2.4, h=2.0);
            }
        }
        cheek_hub_cuts(2.2);
        // Alternating recessed checker squares on top
        for (ix = [0 : 2]) {
            for (iy = [0 : 1]) {
                if ((ix + iy) % 2 == 0) {
                    translate([2.2 - ix * 3.0, 5.8 + iy * 2.4, 1.5])
                        cube([2.4, 2.0, 1.2], center=true);
                }
            }
        }
        translate([-1.0, 7.0, -0.1]) cylinder(d=4.4, h=1.1);
    }
}
module KODIAK75_Cheek_CheckeredFlags() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_525();
}
module Cheek_CheckeredFlags() { KODIAK75_Cheek_CheckeredFlags(); }

// 526: KODIAK75_Cheek_SpeakerSubs (Arcade & Pirate â€” Dual Bass Woofer Boom-Pods)
module single_cheek_526() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Twin subwoofer cabinets side-by-side along X
            hull() {
                translate([-3.8, 6.2, 0]) cylinder(d=7.8, h=2.6);
                translate([ 3.8, 6.2, 0]) cylinder(d=7.8, h=2.6);
            }
            // Central dust-cap domes inside speaker cones
            for (x_s = [-3.8, 3.8]) {
                translate([x_s, 6.2, 1.6]) cylinder(d1=3.0, d2=1.8, h=1.4);
            }
        }
        cheek_hub_cuts(2.2);
        // Annular speaker cone surrounds on top + weight cut below
        for (x_s = [-3.8, 3.8]) {
            difference() {
                translate([x_s, 6.2, 1.8]) cylinder(d=5.8, h=1.2);
                translate([x_s, 6.2, 1.6]) cylinder(d=3.0, h=1.6);
            }
            translate([x_s, 6.2, -0.1]) cylinder(d=4.2, h=1.2);
        }
    }
}
module KODIAK75_Cheek_SpeakerSubs() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_526();
}
module Cheek_SpeakerSubs() { KODIAK75_Cheek_SpeakerSubs(); }

// 527: KODIAK75_Cheek_PinballFlippers (Arcade & Pirate â€” Arcade Pinball Bat Flippers)
module single_cheek_527() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Classic teardropped pinball flipper bat (fat pivot at -X, tapered tip at +X)
            hull() {
                translate([-4.2, 6.2, 0]) cylinder(d=7.6, h=2.6);
                translate([ 6.8, 8.8, 0]) cylinder(d=3.2, h=2.2);
            }
            // Raised rubber bumper rim & pivot cap
            translate([-4.2, 6.2, 2.4]) cylinder(d=4.2, h=0.6);
        }
        cheek_hub_cuts(2.2);
        translate([-2.5, 6.2, -0.1]) cylinder(d=4.6, h=1.3);
    }
}
module KODIAK75_Cheek_PinballFlippers() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_527();
}
module Cheek_PinballFlippers() { KODIAK75_Cheek_PinballFlippers(); }

// 528: KODIAK75_Cheek_FootballPads (Arcade & Pirate â€” Linebacker Shoulder Bumpers)
module single_cheek_528() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Prolate pigskin football shoulder pad with raised white laces
            hull() {
                translate([-7.5, 5.8, 0]) cylinder(d=2.6, h=2.0);
                translate([ 0.0, 6.2, 0]) cylinder(d=7.8, h=2.6);
                translate([ 7.5, 5.8, 0]) cylinder(d=2.6, h=2.0);
            }
            // Longitudinal lace spine & 4 cross-laces
            translate([0, 6.2, 2.5]) cube([8.2, 1.0, 0.6], center=true);
            for (x_l = [-3.0, -1.0, 1.0, 3.0]) {
                translate([x_l, 6.2, 2.5]) cube([0.8, 3.4, 0.6], center=true);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 6.2, -0.1]) cylinder(d=4.8, h=1.4);
    }
}
module KODIAK75_Cheek_FootballPads() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_528();
}
module Cheek_FootballPads() { KODIAK75_Cheek_FootballPads(); }

// 529: KODIAK75_Cheek_CrabClaws (Arcade & Pirate â€” King Crab Snapper Pincers)
module single_cheek_529() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Armored crab chela palm & twin snapping pincer jaws (+X)
            hull() {
                translate([-4.8, 4.8, 0]) cylinder(d=4.8, h=2.4);
                translate([ 1.2, 6.2, 0]) cylinder(d=6.8, h=2.6);
            }
            // Outer curved crusher jaw
            hull() {
                translate([1.2, 7.6, 0]) cylinder(d=4.0, h=2.4);
                translate([5.6, 9.6, 0]) cylinder(d=3.0, h=2.2);
                translate([8.2, 7.6, 0]) cylinder(d=1.8, h=1.8);
            }
            // Inner cutter thumb jaw
            hull() {
                translate([1.2, 4.2, 0]) cylinder(d=3.4, h=2.2);
                translate([7.4, 5.2, 0]) cylinder(d=1.8, h=1.8);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.8, -0.1]) cylinder(d=4.4, h=1.3);
    }
}
module KODIAK75_Cheek_CrabClaws() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_529();
}
module Cheek_CrabClaws() { KODIAK75_Cheek_CrabClaws(); }

// 530: KODIAK75_Cheek_PirateCannons (Arcade & Pirate â€” Broadside Iron Deck Cannons)
module single_cheek_530() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Stepped wooden naval gun carriage & iron cannon barrel (+X)
            hull() {
                translate([-4.6, 3.6, 0]) cylinder(d=3.6, h=2.2);
                translate([ 3.2, 3.6, 0]) cylinder(d=3.6, h=2.2);
                translate([-3.6, 7.2, 0]) cylinder(d=3.6, h=2.2);
                translate([ 2.6, 7.2, 0]) cylinder(d=3.6, h=2.2);
            }
            // Breech cascabel knob (-X) & reinforced muzzle ring (+X)
            translate([-6.4, 5.8, 0]) cylinder(d=3.0, h=2.4);
            hull() {
                translate([-4.8, 5.8, 0]) cylinder(d=5.2, h=2.8);
                translate([ 7.2, 5.8, 0]) cylinder(d=3.8, h=2.4);
            }
            translate([7.6, 5.8, 0]) cylinder(d=4.6, h=2.6);
        }
        cheek_hub_cuts(2.2);
        translate([-0.5, 5.8, -0.1]) cylinder(d=4.6, h=1.4);
    }
}
module KODIAK75_Cheek_PirateCannons() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_530();
}
module Cheek_PirateCannons() { KODIAK75_Cheek_PirateCannons(); }

// 531: KODIAK75_Cheek_AnchorShields (Arcade & Pirate â€” Naval Admiralty Anchor Plates)
module single_cheek_531() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Anchor shank & cross-stock (+Y)
            hull() {
                translate([0, 2.0, 0]) cylinder(d=3.6, h=2.4);
                translate([0, 10.6, 0]) cylinder(d=3.4, h=2.4);
            }
            hull() {
                translate([-4.2, 3.8, 0]) cylinder(d=2.8, h=2.2);
                translate([ 4.2, 3.8, 0]) cylinder(d=2.8, h=2.2);
            }
            // Curved anchor crown & twin fluke barbs
            for (x_s = [-1, 1]) {
                hull() {
                    translate([0, 10.2, 0]) cylinder(d=3.6, h=2.4);
                    translate([x_s * 5.2, 8.8, 0]) cylinder(d=3.2, h=2.2);
                }
                hull() {
                    translate([x_s * 5.2, 8.8, 0]) cylinder(d=3.2, h=2.2);
                    translate([x_s * 6.8, 6.2, 0]) cylinder(d=2.0, h=2.0);
                }
            }
        }
        cheek_hub_cuts(2.2);
    }
}
module KODIAK75_Cheek_AnchorShields() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_531();
}
module Cheek_AnchorShields() { KODIAK75_Cheek_AnchorShields(); }

// 532: KODIAK75_Cheek_TorpedoTubes (Arcade & Pirate â€” Twin Yellow Sub Torpedoes)
module single_cheek_532() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Pylon bridge & hydrodynamic torpedo body
            hull() {
                translate([-3.5, 2.0, 0]) cylinder(d=3.6, h=2.0);
                translate([ 3.5, 2.0, 0]) cylinder(d=3.6, h=2.0);
                translate([ 0.0, 6.2, 0]) cylinder(d=5.2, h=2.2);
            }
            hull() {
                translate([ 8.2, 6.2, 0]) cylinder(d=3.2, h=2.4);
                translate([ 4.0, 6.2, 0]) cylinder(d=5.2, h=2.6);
                translate([-5.5, 6.2, 0]) cylinder(d=4.4, h=2.4);
                translate([-8.2, 6.2, 0]) cylinder(d=2.4, h=2.0);
            }
            // Aft propeller shroud fins (-X)
            hull() {
                translate([-6.8, 3.4, 0]) cylinder(d=2.0, h=2.6);
                translate([-6.8, 9.0, 0]) cylinder(d=2.0, h=2.6);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 6.2, -0.1]) cylinder(d=4.2, h=1.3);
    }
}
module KODIAK75_Cheek_TorpedoTubes() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_532();
}
module Cheek_TorpedoTubes() { KODIAK75_Cheek_TorpedoTubes(); }

// 533: KODIAK75_Cheek_MantaWings (Arcade & Pirate â€” Giant Manta Ray Hydro-Wings)
module single_cheek_533() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Graceful delta manta pectoral wing + cephalic horn lobe (+X) & whip tail (-X)
            hull() {
                translate([ 5.2, 2.2, 0]) cylinder(d=3.6, h=2.2);
                translate([-4.8, 2.2, 0]) cylinder(d=3.2, h=2.0);
                translate([-1.2, 11.4, 0]) cylinder(d=2.6, h=2.0);
            }
            // Forward cephalic lobe (+X)
            hull() {
                translate([4.5, 2.8, 0]) cylinder(d=3.2, h=2.2);
                translate([7.8, 4.8, 0]) cylinder(d=2.0, h=1.8);
            }
            // Trailing whip tail (-X)
            hull() {
                translate([-4.5, 2.8, 0]) cylinder(d=2.8, h=2.0);
                translate([-8.4, 4.2, 0]) cylinder(d=1.6, h=1.6);
            }
        }
        cheek_hub_cuts(2.2);
        // Gill slits on top surface
        for (x_g = [-1.5, 0.5, 2.5]) {
            translate([x_g, 5.6, 1.6]) rotate([0, 0, 20]) cube([0.8, 3.2, 1.0], center=true);
        }
        translate([0, 5.5, -0.1]) cylinder(d=4.4, h=1.1);
    }
}
module KODIAK75_Cheek_MantaWings() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_533();
}
module Cheek_MantaWings() { KODIAK75_Cheek_MantaWings(); }

// 534: KODIAK75_Cheek_SeahorseFins (Arcade & Pirate â€” Coral Reef Seahorse Pectorals)
module single_cheek_534() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // Scalloped seahorse dorsal fin fan & curled prehensile tail (-X)
            for (a = [-32, -10, 12, 34]) {
                rotate([0, 0, a])
                    hull() {
                        translate([0, 2.4, 0]) cylinder(d=3.2, h=2.0);
                        translate([0, 9.8, 0]) cylinder(d=3.0, h=2.2);
                    }
            }
            // Curled seahorse tail spiral at rear (-X)
            hull() {
                translate([-4.8, 3.0, 0]) cylinder(d=3.2, h=2.2);
                translate([-7.8, 6.2, 0]) cylinder(d=2.8, h=2.2);
            }
            hull() {
                translate([-7.8, 6.2, 0]) cylinder(d=2.8, h=2.2);
                translate([-5.6, 8.6, 0]) cylinder(d=2.4, h=2.0);
            }
        }
        cheek_hub_cuts(2.2);
        translate([0, 5.6, -0.1]) cylinder(d=4.2, h=1.2);
    }
}
module KODIAK75_Cheek_SeahorseFins() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_534();
}
module Cheek_SeahorseFins() { KODIAK75_Cheek_SeahorseFins(); }

// 535: KODIAK75_Cheek_CompassRoses (Arcade & Pirate â€” 8-Point Nautical Compass Stars)
module single_cheek_535() {
    difference() {
        union() {
            cheek_hub_solid(2.2);
            // 4 Cardinal star points + 4 Intercardinal points centered at Y=6.4
            for (a = [0, 90, 180, 270]) {
                translate([0, 6.4, 0])
                    rotate([0, 0, a])
                        hull() {
                            cylinder(d=4.2, h=2.6);
                            translate([5.8, 0, 0]) cylinder(d=1.6, h=1.8);
                        }
            }
            for (a = [45, 135, 225, 315]) {
                translate([0, 6.4, 0])
                    rotate([0, 0, a])
                        hull() {
                            cylinder(d=3.6, h=2.2);
                            translate([4.4, 0, 0]) cylinder(d=1.6, h=1.6);
                        }
            }
            // Compass bezel ring
            translate([0, 6.4, 0]) cylinder(d=8.2, h=2.0);
        }
        cheek_hub_cuts(2.2);
        translate([0, 6.4, -0.1]) cylinder(d=4.4, h=1.2);
    }
}
module KODIAK75_Cheek_CompassRoses() {
    for (s = [-1, 1]) translate([0, s * 16, 0]) mirror([0, (s < 0 ? 1 : 0), 0]) single_cheek_535();
}
module Cheek_CompassRoses() { KODIAK75_Cheek_CompassRoses(); }


// Zone 4 Standard Dual Bosses Up (no-op inside raw body; applied unscaled by belly_skid_master_trim)
module belly_dual_bosses_up(z_top = 1.6) {
}

// Zone 4 Standard Dual Pockets Cut (no-op inside raw body; applied unscaled by belly_skid_master_trim)
module belly_dual_pockets_cut(z_top = 1.6) {
}

// Zone 4 Master Trim & Unscaled Dual-Magnet Interface Wrapper
// Scales raw skid Z-profile into the 0.50g-1.15g TPU 95A target range while preserving
// Z=0 flat bed contact and 100% unscaled 36.0mm N52 pockets + 0.45mm conical shear bosses.
module belly_skid_master_trim(z_scale = 0.42, hub_h = 1.60) {
    difference() {
        union() {
            scale([1, 1, z_scale])
                intersection() {
                    children(0);
                    translate([0, 0, 10.0]) cube([100, 100, 20.0], center=true);
                }
            for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
                translate([x_pos, 0, 0])
                    cylinder(d1 = 8.2, d2 = 6.8, h = hub_h);
                translate([x_pos, 0, hub_h - 0.15])
                    cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
            }
        }
        for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
            translate([x_pos, 0, hub_h])
                n52_mating_pocket_cut_up();
        }
    }
}

// ============================================================================
// ZONE 4: 25 CREATIVE UNDER-BELLY SKIDS (PART_ID = 601..625)
// ============================================================================

// 601: Slippery Twin Banana Runners (Food & Candy)
module KODIAK75_Belly_BananaPeelSkids() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central stem spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin curved banana peel runners with upturned tips and stems
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-19.0, y_s * 6.2, 0]) cylinder(d=3.2, h=2.0, $fn=5);
                    translate([  0.0, y_s * 8.0, 0]) cylinder(d=4.6, h=2.6, $fn=5);
                }
                hull() {
                    translate([  0.0, y_s * 8.0, 0]) cylinder(d=4.6, h=2.6, $fn=5);
                    translate([ 19.0, y_s * 6.2, 0]) cylinder(d=3.2, h=2.0, $fn=5);
                }
                // Upturned banana stem tips
                hull() {
                    translate([ 19.0, y_s * 6.2, 0]) cylinder(d=3.2, h=2.0, $fn=5);
                    translate([ 23.5, y_s * 5.2, 1.8]) cylinder(d=2.2, h=1.6, $fn=5);
                }
                hull() {
                    translate([-19.0, y_s * 6.2, 0]) cylinder(d=3.2, h=2.0, $fn=5);
                    translate([-23.0, y_s * 5.2, 1.4]) cylinder(d=2.0, h=1.4, $fn=5);
                }
            }
            // Cross bridges at magnet hubs
            for (x_b = [-16.0, 16.0]) {
                translate([x_b, 0, 1.0])
                    cube([4.4, 14.0, 2.0], center=true);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_BananaPeelSkids() { KODIAK75_Belly_BananaPeelSkids(); }

// 602: Ridged Cinnamon Churro Skids (Food & Candy)
module KODIAK75_Belly_ChurroRails() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin star-fluted churro rails with cinnamon-sugar ridges
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.5, y_s * 7.2, 0]) cylinder(d=4.4, h=2.6, $fn=6);
                    translate([ 21.5, y_s * 7.2, 0]) cylinder(d=4.4, h=2.6, $fn=6);
                }
                // longitudinal star flutes along top of churro
                translate([0, y_s * 7.2, 2.4])
                    cube([42.0, 1.4, 1.0], center=true);
                for (x_r = [-18 : 6 : 18]) {
                    translate([x_r, y_s * 7.2, 0])
                        cylinder(d=5.0, h=2.8, $fn=6);
                }
            }
            // Diagonal churro tie struts
            for (x_c = [-16.0, 0.0, 16.0]) {
                translate([x_c, 0, 1.1])
                    cube([4.2, 15.0, 2.2], center=true);
            }
        }
        for (x_w = [-8.5, 8.5]) {
            hull() {
                translate([x_w - 2.0, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
                translate([x_w + 2.0, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
            }
        }
    }
}
module Belly_ChurroRails() { KODIAK75_Belly_ChurroRails(); }

// 603: Maki Sushi Roll & Chopsticks (Food & Candy)
module KODIAK75_Belly_SushiRollSled() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central maki sushi roll disc and hub spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            // Central round Nori Maki roll body
            translate([0, 0, 0])
                cylinder(d=13.6, h=skid_h + 0.6);
            // Twin tapered wooden chopsticks flanking the maki roll
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-22.0, y_s * 8.0, 0]) cylinder(d=4.0, h=2.4);
                    translate([ 22.0, y_s * 6.8, 0]) cylinder(d=2.6, h=2.4);
                }
            }
            // Cross bridges connecting chopsticks to hubs
            for (x_b = [-15.0, 15.0]) {
                translate([x_b, 0, 1.1])
                    cube([4.4, 15.6, 2.2], center=true);
            }
        }
        // Salmon/avocado core cutouts inside the maki roll & weight pockets
        for (x_w = [-9.5, 9.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.2);
        }
        translate([0, 0, -0.1]) cylinder(d=6.2, h=skid_h + 1.0);
    }
}
module Belly_SushiRollSled() { KODIAK75_Belly_SushiRollSled(); }

// 604: Snap-Block Chocolate Bar Skid (Food & Candy)
module KODIAK75_Belly_ChocolateBar() {
    skid_h = 2.2;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Rectangular chocolate bar baseplate
            hull() {
                for (x_c = [-20.0, 20.0])
                    for (y_c = [-6.2, 6.2])
                        translate([x_c, y_c, 0]) cylinder(d=3.2, h=skid_h);
            }
            // 2x5 raised beveled chocolate pip blocks
            for (x_b = [-16.0, -8.0, 0.0, 8.0, 16.0]) {
                for (y_b = [-3.6, 3.6]) {
                    hull() {
                        translate([x_b, y_b, skid_h - 0.2])
                            cube([6.2, 5.4, 0.4], center=true);
                        translate([x_b, y_b, skid_h + 0.9])
                            cube([4.4, 3.8, 0.4], center=true);
                    }
                }
            }
        }
        // Weight relief cutouts in central snap grooves
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=5.8, h=skid_h + 1.5);
        }
    }
}
module Belly_ChocolateBar() { KODIAK75_Belly_ChocolateBar(); }

// 605: Wavy Crispy Bacon Runners (Food & Candy)
module KODIAK75_Belly_BaconStrips() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin wavy rippled bacon strip runners
            for (y_s = [-1, 1]) {
                for (i = [-4 : 3]) {
                    x1 = i * 5.0;
                    x2 = (i + 1) * 5.0;
                    y1 = y_s * (6.8 + ((i % 2 == 0) ? 1.2 : -1.0));
                    y2 = y_s * (6.8 + (((i + 1) % 2 == 0) ? 1.2 : -1.0));
                    hull() {
                        translate([x1, y1, 0]) cylinder(d=4.0, h=2.6);
                        translate([x2, y2, 0]) cylinder(d=4.0, h=2.6);
                    }
                }
            }
            // Cross bridges connecting the wavy strips to the magnet hubs
            for (x_t = [-16.0, 0.0, 16.0]) {
                translate([x_t, 0, 1.1])
                    cube([4.4, 14.5, 2.2], center=true);
            }
        }
        for (x_w = [-8.5, 8.5]) {
            hull() {
                translate([x_w - 2.0, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
                translate([x_w + 2.0, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
            }
        }
    }
}
module Belly_BaconStrips() { KODIAK75_Belly_BaconStrips(); }

// 606: Giant T-Rex Footprint Pads (Dino & Mythic)
module KODIAK75_Belly_DinoTracks() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central bridge connecting front & rear dino footpads
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=11.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=11.6, h=skid_h);
            }
            // Three-toed T-Rex claw pads at front and rear hubs
            for (x_pad = [-18.0, 18.0]) {
                for (ang = [-32, 0, 32]) {
                    hull() {
                        translate([x_pad, 0, 0]) cylinder(d=8.0, h=skid_h);
                        translate([x_pad + 6.5 * cos(ang), 8.5 * sin(ang), 0])
                            cylinder(d=3.2, h=2.6, $fn=5);
                    }
                }
                // Rear dewclaw spur
                hull() {
                    translate([x_pad, 0, 0]) cylinder(d=7.0, h=skid_h);
                    translate([x_pad - 5.5, 0, 0]) cylinder(d=3.0, h=2.2);
                }
            }
            // Lateral stride stabilizing rails
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-14.0, y_s * 5.2, 0]) cylinder(d=3.0, h=2.0);
                    translate([ 14.0, y_s * 5.2, 0]) cylinder(d=3.0, h=2.0);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_DinoTracks() { KODIAK75_Belly_DinoTracks(); }

// 607: Armored Dragon Tail Keel (Dino & Mythic)
module KODIAK75_Belly_DragonTailSled() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Tapered segmented dragon tail body
            hull() {
                translate([ 21.0, 0, 0]) cylinder(d=11.6, h=skid_h);
                translate([  0.0, 0, 0]) cylinder(d=13.4, h=skid_h);
                translate([-18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([-24.5, 0, 0]) cylinder(d=3.6, h=2.0);
            }
            // Segmented chevron armor plates & lateral osteoderm spikes
            for (x_seg = [-12.0, -4.0, 4.0, 12.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_seg, 0, 0]) cylinder(d=4.4, h=skid_h + 0.4);
                        translate([x_seg - 2.5, y_s * 7.8, 0]) cylinder(d=2.8, h=2.4, $fn=4);
                    }
                }
            }
            // Arrowhead tail-spade tip at rear
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=5.0, h=2.4);
                translate([-22.0, -5.5, 0]) cylinder(d=2.4, h=2.0);
                translate([-22.0,  5.5, 0]) cylinder(d=2.4, h=2.0);
                translate([-25.0, 0, 0]) cylinder(d=2.0, h=1.8);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}
module Belly_DragonTailSled() { KODIAK75_Belly_DragonTailSled(); }

// 608: Prehistoric Dino Ribcage Skid (Dino & Mythic)
module KODIAK75_Belly_FossilRibs() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central fossilized vertebral spine
            hull() {
                translate([-19.5, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 19.5, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Raised vertebra nodes along spine
            for (x_v = [-12.0, -6.0, 0.0, 6.0, 12.0]) {
                translate([x_v, 0, 0])
                    cylinder(d=6.8, h=skid_h + 0.6, $fn=6);
            }
            // 5 pairs of curved skeletal fossil ribs + outer costal runner rim
            for (x_r = [-14.0, -7.0, 0.0, 7.0, 14.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_r, 0, 0]) cylinder(d=3.2, h=skid_h);
                        translate([x_r - 1.5, y_s * 8.4, 0]) cylinder(d=3.0, h=2.4);
                    }
                }
            }
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-16.0, y_s * 8.4, 0]) cylinder(d=2.8, h=2.0);
                    translate([ 13.0, y_s * 8.4, 0]) cylinder(d=2.8, h=2.0);
                }
            }
        }
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.4, h=skid_h + 0.8);
        }
    }
}
module Belly_FossilRibs() { KODIAK75_Belly_FossilRibs(); }

// 609: Magma Basalt Hex-Stone Sled (Dino & Mythic)
module KODIAK75_Belly_LavaRockSled() {
    skid_h = 2.4;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.8, h=skid_h, $fn=6);
                translate([ 18.0, 0, 0]) cylinder(d=10.8, h=skid_h, $fn=6);
            }
            // Interlocking columnar basalt hex-pillars along flanks
            for (x_h = [-16.0, -8.0, 0.0, 8.0, 16.0]) {
                for (y_s = [-1, 1]) {
                    translate([x_h, y_s * 6.0, 0])
                        cylinder(d=7.2, h=skid_h + ((abs(x_h) == 8.0) ? 0.6 : 0.2), $fn=6);
                }
            }
        }
        // Magma fissure vents along centerline
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=6.2, h=skid_h + 1.0, $fn=6);
        }
    }
}
module Belly_LavaRockSled() { KODIAK75_Belly_LavaRockSled(); }

// 610: Domed Sea-Turtle Plastron Skid (Dino & Mythic)
module KODIAK75_Belly_TurtleShell() {
    skid_h = 2.4;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Oval sea-turtle plastron belly shield
            hull() {
                translate([-19.0, 0, 0]) cylinder(d=10.4, h=skid_h);
                translate([  0.0, 0, 0]) scale([1.0, 1.15, 1.0]) cylinder(d=15.0, h=skid_h + 0.4, $fn=8);
                translate([ 19.0, 0, 0]) cylinder(d=10.4, h=skid_h);
            }
            // Four swept sea-turtle flipper skids at corners
            for (y_s = [-1, 1]) {
                // Front flippers
                hull() {
                    translate([12.0, y_s * 4.0, 0]) cylinder(d=4.4, h=skid_h);
                    translate([ 7.0, y_s * 10.5, 0]) cylinder(d=3.0, h=2.0);
                }
                // Rear flippers
                hull() {
                    translate([-12.0, y_s * 4.0, 0]) cylinder(d=4.0, h=skid_h);
                    translate([-16.0, y_s * 9.0, 0]) cylinder(d=2.8, h=1.8);
                }
            }
        }
        // Plastron scute weight relief chambers
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=6.0, h=skid_h + 0.8, $fn=6);
        }
    }
}
module Belly_TurtleShell() { KODIAK75_Belly_TurtleShell(); }

// 611: Apollo 4-Pad Lunar Footpads (Space & Alien)
module KODIAK75_Belly_LunarLanderPads() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central descent-stage truss spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // 4 circular Apollo saucer footpads on outrigger struts
            for (x_p = [-15.0, 15.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_p, 0, 0]) cylinder(d=4.2, h=skid_h);
                        translate([x_p, y_s * 8.5, 0]) cylinder(d=3.4, h=2.2);
                    }
                    // Saucer dish footpad
                    translate([x_p, y_s * 8.5, 0])
                        cylinder(d1=7.6, d2=5.8, h=2.6);
                }
            }
            // Longitudinal connecting truss rails between front & rear pads
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-15.0, y_s * 8.5, 0]) cylinder(d=2.4, h=1.8);
                    translate([ 15.0, y_s * 8.5, 0]) cylinder(d=2.4, h=1.8);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_LunarLanderPads() { KODIAK75_Belly_LunarLanderPads(); }

// 612: 6-Wheel Rocker-Bogie Rover Skid (Space & Alien)
module KODIAK75_Belly_MarsRoverWheels() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
            }
            // Rocker-bogie suspension struts + 6 cleated Mars rover wheels
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-16.0, y_s * 7.6, 0]) cylinder(d=3.0, h=2.2);
                    translate([ 16.0, y_s * 7.6, 0]) cylinder(d=3.0, h=2.2);
                }
                for (x_w = [-16.0, 0.0, 16.0]) {
                    hull() {
                        translate([x_w, 0, 0]) cylinder(d=3.6, h=skid_h);
                        translate([x_w, y_s * 7.6, 0]) cylinder(d=3.6, h=2.4);
                    }
                    // Cleated rover wheel drum
                    translate([x_w, y_s * 7.8, 0])
                        cylinder(d=6.2, h=2.8, $fn=8);
                }
            }
        }
        for (x_c = [-8.5, 8.5]) {
            hull() {
                translate([x_c - 1.5, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
                translate([x_c + 1.5, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
            }
        }
    }
}
module Belly_MarsRoverWheels() { KODIAK75_Belly_MarsRoverWheels(); }

// 613: Twin Starfleet Nacelle Runners (Space & Alien)
module KODIAK75_Belly_WarpSled() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
            }
            // Swept warp pylons
            for (x_p = [-14.0, 14.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_p, 0, 0]) cylinder(d=4.2, h=skid_h);
                        translate([x_p - 2.0, y_s * 7.8, 0]) cylinder(d=3.8, h=2.4);
                    }
                }
            }
            // Twin streamlined warp nacelles with domed Bussard collectors
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-22.0, y_s * 7.8, 0]) cylinder(d=3.4, h=2.6);
                    translate([ 21.0, y_s * 7.8, 0]) cylinder(d=4.4, h=2.6);
                }
                // Field grille nodes
                for (x_g = [-10.0, -2.0, 6.0]) {
                    translate([x_g, y_s * 7.8, 0])
                        cylinder(d=5.2, h=2.8, $fn=6);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_WarpSled() { KODIAK75_Belly_WarpSled(); }

// 614: Concentric Emitter Ring Skid (Space & Alien)
module KODIAK75_Belly_TractorBeam() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
            }
            // Central concentric graviton emitter dish ring
            translate([0, 0, 0])
                cylinder(d=17.6, h=skid_h + 0.4);
            // Secondary harmonic rings around front & rear hubs
            for (x_h = [-18.0, 18.0]) {
                translate([x_h, 0, 0])
                    cylinder(d=11.6, h=skid_h + 0.2);
            }
            // 4 radial waveguide ribs
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-18.0, y_s * 4.8, 0]) cylinder(d=2.6, h=2.2);
                    translate([  0.0, y_s * 7.8, 0]) cylinder(d=2.8, h=2.4);
                    translate([ 18.0, y_s * 4.8, 0]) cylinder(d=2.6, h=2.2);
                }
            }
        }
        // Central graviton emitter aperture and adjacent weight cutouts
        translate([0, 0, -0.1])
            cylinder(d=8.4, h=skid_h + 1.0);
        for (x_w = [-9.5, 9.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.2, h=skid_h + 0.6);
        }
    }
}
module Belly_TractorBeam() { KODIAK75_Belly_TractorBeam(); }

// 615: Orbiter Hex Re-Entry Heatshield (Space & Alien)
module KODIAK75_Belly_HeatshieldTiles() {
    skid_h = 2.2;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Delta-winged orbiter belly silhouette
            hull() {
                translate([ 21.0, 0, 0]) cylinder(d=9.0, h=skid_h);
                translate([  0.0, 0, 0]) cylinder(d=13.0, h=skid_h);
                translate([-16.0, -8.0, 0]) cylinder(d=5.2, h=skid_h);
                translate([-16.0,  8.0, 0]) cylinder(d=5.2, h=skid_h);
                translate([-19.5, 0, 0]) cylinder(d=10.4, h=skid_h);
            }
            // Raised silica hex thermal protection tiles along flanks
            for (x_t = [-14.0, -7.0, 0.0, 7.0, 14.0]) {
                for (y_s = [-1, 1]) {
                    translate([x_t, y_s * 4.6, 0])
                        cylinder(d=5.6, h=skid_h + 0.6, $fn=6);
                }
            }
        }
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1])
                cylinder(d=5.8, h=skid_h + 1.0, $fn=6);
        }
    }
}
module Belly_HeatshieldTiles() { KODIAK75_Belly_HeatshieldTiles(); }

// 616: Quad Bigfoot Monster Tires (Arcade & Pirate)
module KODIAK75_Belly_MonsterTruckTires() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Monster truck ladder frame chassis
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.0, h=skid_h);
            }
            // Front & rear heavy solid axles + 4 oversized mud-bogger tires
            for (x_a = [-14.5, 14.5]) {
                translate([x_a, 0, 1.1])
                    cube([4.4, 16.0, 2.2], center=true);
                for (y_s = [-1, 1]) {
                    translate([x_a, y_s * 8.2, 0])
                        cylinder(d=7.8, h=3.0, $fn=10);
                }
            }
            // Side nerf bars connecting front and rear monster tires
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-14.5, y_s * 8.2, 0]) cylinder(d=2.8, h=2.0);
                    translate([ 14.5, y_s * 8.2, 0]) cylinder(d=2.8, h=2.0);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_MonsterTruckTires() { KODIAK75_Belly_MonsterTruckTires(); }

// 617: Retro Quad Roller Skate Chassis (Arcade & Pirate)
module KODIAK75_Belly_RollerSkates() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Skate sole plate
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=10.6, h=skid_h);
            }
            // Front rubber toe-stop bumper
            hull() {
                translate([18.0, 0, 0]) cylinder(d=7.0, h=skid_h);
                translate([23.0, 0, 0]) cylinder(d=6.4, h=2.8, $fn=8);
            }
            // Quad urethane skate wheels on double-action trucks
            for (x_t = [-13.5, 11.5]) {
                translate([x_t, 0, 1.1])
                    cube([4.2, 15.0, 2.2], center=true);
                for (y_s = [-1, 1]) {
                    translate([x_t, y_s * 7.6, 0])
                        cylinder(d=6.8, h=2.8);
                }
            }
            // Side rail reinforcement
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-13.5, y_s * 7.2, 0]) cylinder(d=2.6, h=2.0);
                    translate([ 11.5, y_s * 7.2, 0]) cylinder(d=2.6, h=2.0);
                }
            }
        }
        for (x_w = [-8.0, 0.0, 8.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_RollerSkates() { KODIAK75_Belly_RollerSkates(); }

// 618: Crossed Ice Hockey Stick Blades (Arcade & Pirate)
module KODIAK75_Belly_HockeySticks() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central puck & hub spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Center vulcanized rubber hockey puck
            translate([0, 0, 0])
                cylinder(d=13.2, h=skid_h + 0.4);
            // Twin hockey stick shafts and curved taped slap-shot blades
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-21.0, y_s * 5.8, 0]) cylinder(d=3.4, h=2.4);
                    translate([ 14.0, y_s * 6.8, 0]) cylinder(d=3.6, h=2.6);
                }
                // Curved hockey blade at front
                hull() {
                    translate([ 14.0, y_s * 6.8, 0]) cylinder(d=3.6, h=2.8);
                    translate([ 21.5, y_s * 8.4, 0]) cylinder(d=4.2, h=2.8);
                    translate([ 23.5, y_s * 5.2, 0]) cylinder(d=3.4, h=2.6);
                }
                // Struts tying shafts to hubs
                for (x_s = [-16.0, 16.0]) {
                    hull() {
                        translate([x_s, 0, 0]) cylinder(d=4.0, h=skid_h);
                        translate([x_s, y_s * 6.4, 0]) cylinder(d=3.4, h=2.2);
                    }
                }
            }
        }
        for (x_w = [-9.0, 0.0, 9.0]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.8);
        }
    }
}
module Belly_HockeySticks() { KODIAK75_Belly_HockeySticks(); }

// 619: Retro 16-Bit D-Pad Controller (Arcade & Pirate)
module KODIAK75_Belly_GamepadSled() {
    skid_h = 2.2;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Dog-bone 16-bit gamepad silhouette with rounded left/right grips
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=13.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=13.6, h=skid_h);
            }
            for (x_g = [-16.0, 16.0]) {
                hull() {
                    translate([x_g, -3.5, 0]) cylinder(d=9.6, h=skid_h + 0.2);
                    translate([x_g,  3.5, 0]) cylinder(d=9.6, h=skid_h + 0.2);
                }
            }
            // Raised cross D-Pad & arcade A/B action buttons on flanks
            for (y_s = [-1, 1]) {
                translate([-10.0, y_s * 4.5, 1.4])
                    cube([4.4, 2.2, 2.8], center=true);
                translate([-10.0, y_s * 4.5, 1.4])
                    cube([2.2, 4.4, 2.8], center=true);
                translate([10.0, y_s * 4.5, 0])
                    cylinder(d=3.8, h=2.8);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}
module Belly_GamepadSled() { KODIAK75_Belly_GamepadSled(); }

// 620: Twin Studded Turf Boot Cleats (Arcade & Pirate)
module KODIAK75_Belly_SoccerCleats() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            hull() {
                translate([-18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.8, h=skid_h);
            }
            // Twin contoured soccer boot outsoles with conical turf studs
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 7.0, 0]) cylinder(d=4.2, h=2.2);
                    translate([  4.0, y_s * 7.6, 0]) cylinder(d=5.2, h=2.2);
                    translate([ 20.0, y_s * 6.8, 0]) cylinder(d=4.0, h=2.2);
                }
                // Conical turf cleat studs along each boot plate
                for (x_st = [-18.0, -10.0, -2.0, 6.0, 14.0, 19.0]) {
                    translate([x_st, y_s * 7.2, 0])
                        cylinder(d1=3.8, d2=2.4, h=3.2);
                }
            }
            // Arch torsion bridges
            for (x_b = [-16.0, 16.0]) {
                translate([x_b, 0, 1.0])
                    cube([4.4, 14.5, 2.0], center=true);
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.2);
        }
    }
}
module Belly_SoccerCleats() { KODIAK75_Belly_SoccerCleats(); }

// 621: Twin-Keel Pirate Ship Hull (Arcade & Pirate)
module KODIAK75_Belly_PirateGalleon() {
    skid_h = 2.4;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Swept Spanish galleon hull with pointed bowsprit prow and transom stern
            hull() {
                translate([ 23.5, 0, 0]) cylinder(d=3.6, h=2.6);
                translate([ 16.0, 0, 0]) cylinder(d=11.4, h=skid_h);
                translate([  0.0, 0, 0]) cylinder(d=14.4, h=skid_h);
                translate([-19.0, 0, 0]) cylinder(d=11.0, h=skid_h);
            }
            // Twin bilge keels & broadside cannon port strakes
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-18.0, y_s * 6.2, 0]) cylinder(d=3.0, h=2.8);
                    translate([ 15.0, y_s * 6.2, 0]) cylinder(d=3.0, h=2.8);
                }
                for (x_c = [-10.0, -3.0, 4.0, 11.0]) {
                    translate([x_c, y_s * 6.8, 1.4])
                        cube([2.4, 3.0, 2.8], center=true);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}
module Belly_PirateGalleon() { KODIAK75_Belly_PirateGalleon(); }

// 622: Banded Gold Treasure Chest Skid (Arcade & Pirate)
module KODIAK75_Belly_TreasureChest() {
    skid_h = 2.2;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Iron-bound sunken treasure chest base
            hull() {
                for (x_c = [-19.5, 19.5])
                    for (y_c = [-5.8, 5.8])
                        translate([x_c, y_c, 0]) cylinder(d=3.6, h=skid_h);
            }
            // 4 heavy riveted iron strapping bands across the chest
            for (x_b = [-14.0, -5.0, 5.0, 14.0]) {
                translate([x_b, 0, 1.4])
                    cube([3.2, 15.6, 2.8], center=true);
            }
            // Corner iron lock-plates
            for (y_s = [-1, 1]) {
                translate([0, y_s * 6.8, 1.5])
                    cube([6.0, 2.6, 3.0], center=true);
            }
        }
        for (x_w = [-9.5, 0.0, 9.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 1.0);
        }
    }
}
module Belly_TreasureChest() { KODIAK75_Belly_TreasureChest(); }

// 623: Deep-Dive Submarine Ballast Hull (Arcade & Pirate)
module KODIAK75_Belly_SubmarineKeel() {
    skid_h = 2.4;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Teardrop Albacore-hull submarine keel
            hull() {
                translate([ 22.0, 0, 0]) cylinder(d=8.4, h=skid_h);
                translate([  4.0, 0, 0]) cylinder(d=13.6, h=skid_h);
                translate([-18.0, 0, 0]) cylinder(d=10.2, h=skid_h);
                translate([-23.5, 0, 0]) cylinder(d=4.4, h=2.0);
            }
            // Bow & stern hydroplane dive planes
            for (y_s = [-1, 1]) {
                // Bow planes
                hull() {
                    translate([15.0, 0, 0]) cylinder(d=4.0, h=skid_h);
                    translate([14.0, y_s * 8.6, 0]) cylinder(d=3.0, h=2.2);
                }
                // Stern cruciform stabilizers
                hull() {
                    translate([-17.0, 0, 0]) cylinder(d=4.0, h=skid_h);
                    translate([-19.5, y_s * 7.8, 0]) cylinder(d=2.8, h=2.2);
                }
                // External saddle ballast tanks
                hull() {
                    translate([-10.0, y_s * 6.0, 0]) cylinder(d=3.4, h=2.6);
                    translate([ 10.0, y_s * 6.0, 0]) cylinder(d=3.4, h=2.6);
                }
            }
        }
        // Flood vents along ballast keel
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}
module Belly_SubmarineKeel() { KODIAK75_Belly_SubmarineKeel(); }

// 624: Segmented Lobster Fan-Tail Sled (Arcade & Pirate)
module KODIAK75_Belly_LobsterTail() {
    skid_h = 2.4;
    belly_skid_master_trim(0.40, 1.60)
    difference() {
        union() {
            // Overlapping crustacean abdominal somite plates
            for (i = [0 : 4]) {
                x_s = 18.0 - i * 8.0;
                w_s = 13.6 - i * 0.8;
                hull() {
                    translate([x_s, 0, 0]) cylinder(d=10.6, h=skid_h);
                    translate([x_s - 3.0, -w_s/2, 0]) cylinder(d=3.6, h=2.6);
                    translate([x_s - 3.0,  w_s/2, 0]) cylinder(d=3.6, h=2.6);
                }
            }
            // Five-lobed lobster telson tail fan at rear (-18mm to -24mm)
            for (ang = [-40, -20, 0, 20, 40]) {
                hull() {
                    translate([-17.0, 0, 0]) cylinder(d=6.0, h=skid_h);
                    translate([-17.0 - 6.5 * cos(ang), 9.5 * sin(ang), 0])
                        cylinder(d=3.6, h=2.2);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.8, h=skid_h + 0.6);
        }
    }
}
module Belly_LobsterTail() { KODIAK75_Belly_LobsterTail(); }

// 625: Polynesian Twin Outrigger Floats (Arcade & Pirate)
module KODIAK75_Belly_OutriggerCanoe() {
    skid_h = 2.4;
    belly_skid_master_trim(0.42, 1.60)
    difference() {
        union() {
            // Central wave-piercing dugout canoe hull
            hull() {
                translate([ 22.5, 0, 0]) cylinder(d=3.6, h=skid_h);
                translate([ 18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([-18.0, 0, 0]) cylinder(d=9.6, h=skid_h);
                translate([-22.5, 0, 0]) cylinder(d=3.6, h=skid_h);
            }
            // Curved Polynesian aka cross-booms at front and rear
            for (x_b = [-14.0, 14.0]) {
                for (y_s = [-1, 1]) {
                    hull() {
                        translate([x_b, 0, 0]) cylinder(d=4.2, h=skid_h);
                        translate([x_b, y_s * 8.8, 0]) cylinder(d=3.6, h=2.4);
                    }
                }
            }
            // Twin sleek ama outrigger pontoons
            for (y_s = [-1, 1]) {
                hull() {
                    translate([-20.0, y_s * 8.8, 0]) cylinder(d=2.8, h=2.4);
                    translate([  0.0, y_s * 8.8, 0]) cylinder(d=4.4, h=2.4);
                    translate([ 20.0, y_s * 8.8, 0]) cylinder(d=2.8, h=2.4);
                }
            }
        }
        for (x_w = [-8.5, 0.0, 8.5]) {
            translate([x_w, 0, -0.1]) cylinder(d=5.6, h=skid_h + 0.2);
        }
    }
}
module Belly_OutriggerCanoe() { KODIAK75_Belly_OutriggerCanoe(); }


// ============================================================================
// MASTER CLI DISPATCHER (401..440 & 501..535)
// ============================================================================
// Zone 1: Creative Top Crowns (401..440)
if      (PART_ID == 401) KODIAK75_Crown_TacoShell();
else if (PART_ID == 402) KODIAK75_Crown_BurgerStack();
else if (PART_ID == 403) KODIAK75_Crown_PizzaSlice();
else if (PART_ID == 404) KODIAK75_Crown_IceCreamCone();
else if (PART_ID == 405) KODIAK75_Crown_SprinkleDonut();
else if (PART_ID == 406) KODIAK75_Crown_FryBox();
else if (PART_ID == 407) KODIAK75_Crown_CupcakeSwirl();
else if (PART_ID == 408) KODIAK75_Crown_GummyBear();
else if (PART_ID == 409) KODIAK75_Crown_BobaTea();
else if (PART_ID == 410) KODIAK75_Crown_ChefToque();
else if (PART_ID == 411) KODIAK75_Crown_TRexJaw();
else if (PART_ID == 412) KODIAK75_Crown_TriceraFrill();
else if (PART_ID == 413) KODIAK75_Crown_PteroCrest();
else if (PART_ID == 414) KODIAK75_Crown_AnkyloClub();
else if (PART_ID == 415) KODIAK75_Crown_HydraTriHead();
else if (PART_ID == 416) KODIAK75_Crown_PhoenixPlume();
else if (PART_ID == 417) KODIAK75_Crown_GriffinBeak();
else if (PART_ID == 418) KODIAK75_Crown_KrakenHelm();
else if (PART_ID == 419) KODIAK75_Crown_MinotaurHorns();
else if (PART_ID == 420) KODIAK75_Crown_GargoyleCrest();
else if (PART_ID == 421) KODIAK75_Crown_UFOSaucer();
else if (PART_ID == 422) KODIAK75_Crown_AlienTriEye();
else if (PART_ID == 423) KODIAK75_Crown_AstroVisor();
else if (PART_ID == 424) KODIAK75_Crown_RocketSpire();
else if (PART_ID == 425) KODIAK75_Crown_WarpCrystal();
else if (PART_ID == 426) KODIAK75_Crown_RaygunTurret();
else if (PART_ID == 427) KODIAK75_Crown_SaturnRing();
else if (PART_ID == 428) KODIAK75_Crown_LunarRadar();
else if (PART_ID == 429) KODIAK75_Crown_MeteorCrater();
else if (PART_ID == 430) KODIAK75_Crown_StargateArch();
else if (PART_ID == 431) KODIAK75_Crown_PixelHeart();
else if (PART_ID == 432) KODIAK75_Crown_ArcadeJoystick();
else if (PART_ID == 433) KODIAK75_Crown_TrophyCup();
else if (PART_ID == 434) KODIAK75_Crown_KingChess();
else if (PART_ID == 435) KODIAK75_Crown_PirateTricorn();
else if (PART_ID == 436) KODIAK75_Crown_SubPeriscope();
else if (PART_ID == 437) KODIAK75_Crown_Hammerhead();
else if (PART_ID == 438) KODIAK75_Crown_NarwhalTusk();
else if (PART_ID == 439) KODIAK75_Crown_VikingShip();
else if (PART_ID == 440) KODIAK75_Crown_DiscoBall();

// Zones 2 & 3: Creative Cheek Pod Pairs (501..535)
else if (PART_ID == 501) KODIAK75_Cheek_HotDogPods();
else if (PART_ID == 502) KODIAK75_Cheek_PopsicleTwins();
else if (PART_ID == 503) KODIAK75_Cheek_WaffleGrids();
else if (PART_ID == 504) KODIAK75_Cheek_PretzelLoops();
else if (PART_ID == 505) KODIAK75_Cheek_CandyCanes();
else if (PART_ID == 506) KODIAK75_Cheek_CookieShields();
else if (PART_ID == 507) KODIAK75_Cheek_CroissantHorns();
else if (PART_ID == 508) KODIAK75_Cheek_WatermelonWedges();
else if (PART_ID == 509) KODIAK75_Cheek_WyvernWings();
else if (PART_ID == 510) KODIAK75_Cheek_RaptorClaws();
else if (PART_ID == 511) KODIAK75_Cheek_StegoSpikes();
else if (PART_ID == 512) KODIAK75_Cheek_PteroGliders();
else if (PART_ID == 513) KODIAK75_Cheek_PhoenixWings();
else if (PART_ID == 514) KODIAK75_Cheek_KrakenArms();
else if (PART_ID == 515) KODIAK75_Cheek_PegasusWings();
else if (PART_ID == 516) KODIAK75_Cheek_SolarPanels();
else if (PART_ID == 517) KODIAK75_Cheek_IonCannons();
else if (PART_ID == 518) KODIAK75_Cheek_AsteroidPods();
else if (PART_ID == 519) KODIAK75_Cheek_PlasmaCoils();
else if (PART_ID == 520) KODIAK75_Cheek_StarCruiserFins();
else if (PART_ID == 521) KODIAK75_Cheek_GravityRings();
else if (PART_ID == 522) KODIAK75_Cheek_AlienBlasters();
else if (PART_ID == 523) KODIAK75_Cheek_BoxingGloves();
else if (PART_ID == 524) KODIAK75_Cheek_PixelSwords();
else if (PART_ID == 525) KODIAK75_Cheek_CheckeredFlags();
else if (PART_ID == 526) KODIAK75_Cheek_SpeakerSubs();
else if (PART_ID == 527) KODIAK75_Cheek_PinballFlippers();
else if (PART_ID == 528) KODIAK75_Cheek_FootballPads();
else if (PART_ID == 529) KODIAK75_Cheek_CrabClaws();
else if (PART_ID == 530) KODIAK75_Cheek_PirateCannons();
else if (PART_ID == 531) KODIAK75_Cheek_AnchorShields();
else if (PART_ID == 532) KODIAK75_Cheek_TorpedoTubes();
else if (PART_ID == 533) KODIAK75_Cheek_MantaWings();
else if (PART_ID == 534) KODIAK75_Cheek_SeahorseFins();
else if (PART_ID == 535) KODIAK75_Cheek_CompassRoses();

// Zone 4: Creative Under-Belly Skids (601..625)
else if (PART_ID == 601) KODIAK75_Belly_BananaPeelSkids();
else if (PART_ID == 602) KODIAK75_Belly_ChurroRails();
else if (PART_ID == 603) KODIAK75_Belly_SushiRollSled();
else if (PART_ID == 604) KODIAK75_Belly_ChocolateBar();
else if (PART_ID == 605) KODIAK75_Belly_BaconStrips();
else if (PART_ID == 606) KODIAK75_Belly_DinoTracks();
else if (PART_ID == 607) KODIAK75_Belly_DragonTailSled();
else if (PART_ID == 608) KODIAK75_Belly_FossilRibs();
else if (PART_ID == 609) KODIAK75_Belly_LavaRockSled();
else if (PART_ID == 610) KODIAK75_Belly_TurtleShell();
else if (PART_ID == 611) KODIAK75_Belly_LunarLanderPads();
else if (PART_ID == 612) KODIAK75_Belly_MarsRoverWheels();
else if (PART_ID == 613) KODIAK75_Belly_WarpSled();
else if (PART_ID == 614) KODIAK75_Belly_TractorBeam();
else if (PART_ID == 615) KODIAK75_Belly_HeatshieldTiles();
else if (PART_ID == 616) KODIAK75_Belly_MonsterTruckTires();
else if (PART_ID == 617) KODIAK75_Belly_RollerSkates();
else if (PART_ID == 618) KODIAK75_Belly_HockeySticks();
else if (PART_ID == 619) KODIAK75_Belly_GamepadSled();
else if (PART_ID == 620) KODIAK75_Belly_SoccerCleats();
else if (PART_ID == 621) KODIAK75_Belly_PirateGalleon();
else if (PART_ID == 622) KODIAK75_Belly_TreasureChest();
else if (PART_ID == 623) KODIAK75_Belly_SubmarineKeel();
else if (PART_ID == 624) KODIAK75_Belly_LobsterTail();
else if (PART_ID == 625) KODIAK75_Belly_OutriggerCanoe();
else {
    translate([0, 0, 16.0]) KODIAK75_Crown_TacoShell();
    translate([0, 0, 9.7])  KODIAK75_Cheek_HotDogPods();
    translate([0, 0, 0.0])  KODIAK75_Belly_BananaPeelSkids();
}
