// ============================================================================
// KODIAK-75: Mega-1000 Wave 3 — Cheek Pod Pairs Batch A (PART_ID = 1401..1575)
// Universal Magnetic Snap-On Breakaway Architecture for Bumper Drones
// ============================================================================
// Total Components in this file: 175 Distinct Left/Right Cheek Pod Pairs
// - Zones 2 & 3: Creative Cheek Pairs (PART_ID = 1401 to 1575) [175 Pairs / 350 Pods]
// - 14 Distinct Support-Free 3D Archetypes (arch = 0..13) x 13 Sub-Variations (subvar = 0..12)
//
// Material: TPU 95A (density = 0.00121 g/mm^3)
// Mass Target Budget: 0.65g .. 1.15g per pair (0.32g .. 0.58g per pod, 540 .. 950 mm^3 pair volume)
// Support Policy: 100% Support-Free FDM Printing flat at Z = 0.00mm
// Polarity Standard: Grade N52 disc magnets (2mm OD x 1mm thick), South-Facing-Out
// ============================================================================

$fn = 28;

// Command-line selector: openscad -D PART_ID=<id> -o <target>.stl ...
PART_ID = 1401;

// --- Master Interface Constants ---
mag_pocket_dia      = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth    = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1     = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2     = 2.10; // Tip diameter of male conical shear boss
shear_boss_height   = 0.45; // Height of male conical shear boss (mates into 0.50mm dimple)
cheek_pair_offset_y = 15.0; // Left pod at Y = -15.0mm, Right pod at Y = +15.0mm

// ============================================================================
// UNIVERSAL HELPER MODULES (ZONES 2 & 3 CHEEK HUB & CONICAL SHEAR BOSS)
// ============================================================================

// Top-facing recessed magnet pocket cut through conical shear boss
// At hub top z = pad_h, boss extends to pad_h + 0.45. Pocket cuts 1.20mm down from top of boss:
// z_bottom = pad_h + 0.45 - 1.20 = pad_h - 0.75.
module n52_mating_pocket_cut_up() {
    translate([0, 0, shear_boss_height - mag_pocket_depth])
        cylinder(d = mag_pocket_dia, h = mag_pocket_depth + 0.10);
}

// Zones 2 & 3 Standard Cheek Hub Pad Solid (Print bed at Z = 0.00mm)
module cheek_hub_solid(pad_h = 2.2, span_x = 16.0) {
    half_x = span_x / 2 - 2.2;
    hull() {
        cylinder(d = 8.6, h = pad_h);
        translate([-half_x, 0, 0]) cylinder(d = 4.2, h = pad_h - 0.4);
        translate([ half_x, 0, 0]) cylinder(d = 4.2, h = pad_h - 0.4);
    }
    // Top-facing male conical shear boss (d1=3.40, d2=2.10, h=0.45) at [0, 0, pad_h]
    translate([0, 0, pad_h - 0.10])
        cylinder(d1 = shear_boss_dia1 + 0.10, d2 = shear_boss_dia2, h = shear_boss_height + 0.10);
}

// Zones 2 & 3 Standard Cheek Hub Magnet Pocket Cut + Underside Weight Relief
module cheek_hub_cuts(pad_h = 2.2, relief_d = 4.2, relief_y = 5.4, relief_h = 1.15) {
    translate([0, 0, pad_h])
        n52_mating_pocket_cut_up();
    if (relief_d > 0) {
        translate([0, relief_y, -0.05])
            cylinder(d = relief_d, h = relief_h + 0.05);
    }
}

// ============================================================================
// 14 CREATIVE SUPPORT-FREE 3D CHEEK POD ARCHETYPES (arch = 0..13)
// Each module models a single Right-side pod (+Y outboard, +X forward, Z=0 flat)
// parameterized by subvar (0..12) for unique geometry & strict 0.65g..1.15g pair mass.
// ============================================================================

// ARCH 0: Clawed Paw / Gauntlet / Fist Bumper Pod
module cheek_arch_a_0(subvar = 0) {
    span_x   = 14.0 + (subvar % 5) * 0.9;
    pad_h    = 2.15 + (subvar % 3) * 0.08;
    n_claws  = 3 + (subvar % 2); // 3 or 4 claws/knuckles
    out_y    = 8.6 + (subvar % 4) * 0.55;
    sweep_x  = ((subvar % 3) - 1) * 1.1;
    rel_d    = 4.0 + (subvar % 4) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Muscular paw / gauntlet palm cushion
            hull() {
                translate([-3.8 - (subvar % 3) * 0.4, 2.2, 0]) cylinder(d = 4.6, h = pad_h + 0.25);
                translate([ 3.8 + (subvar % 3) * 0.4, 2.2, 0]) cylinder(d = 4.6, h = pad_h + 0.25);
                translate([ sweep_x * 0.5, 5.8, 0]) cylinder(d = 6.2, h = pad_h + 0.35);
            }
            // Sculpted curved talons / gauntlet knuckles
            for (i = [0 : n_claws - 1]) {
                frac = (i / (n_claws - 1)) - 0.5;
                cx_root = frac * (span_x * 0.62);
                cx_tip  = cx_root * 1.15 + sweep_x;
                cy_tip  = out_y - abs(frac) * 1.6;
                hull() {
                    translate([cx_root, 4.4, 0]) cylinder(d = 3.2, h = pad_h + 0.2);
                    translate([cx_tip, cy_tip, 0]) cylinder(d1 = 2.2, d2 = 1.2, h = pad_h - 0.2);
                }
            }
            // Raised dorsal knuckle ridge
            translate([0, 4.2, pad_h])
                cube([7.2 + (subvar % 3) * 0.8, 1.8, 0.5], center = true);
        }
        cheek_hub_cuts(pad_h, rel_d, 4.8, 1.15);
    }
}

// ARCH 1: Swept Aero Wing / Feather Pinion Pod
module cheek_arch_a_1(subvar = 0) {
    span_x  = 14.5 + (subvar % 5) * 0.85;
    pad_h   = 2.10 + (subvar % 3) * 0.08;
    out_y   = 9.4 + (subvar % 4) * 0.6;
    sweep   = -2.2 - (subvar % 4) * 0.7;
    n_slots = 2 + (subvar % 3); // 2, 3, or 4 pinion feathers
    rel_d   = 4.2 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Swept leading-edge spar
            hull() {
                translate([ span_x * 0.35, 1.8, 0]) cylinder(d = 3.8, h = pad_h + 0.25);
                translate([ sweep, out_y, 0]) cylinder(d = 2.8, h = pad_h);
                translate([-span_x * 0.32, 2.0, 0]) cylinder(d = 3.4, h = pad_h);
            }
            // Staggered pinion feather tips / winglet fences
            for (i = [0 : n_slots - 1]) {
                fx = 2.5 - i * (7.2 / n_slots);
                fy = out_y - i * 1.1;
                hull() {
                    translate([fx + 1.2, 2.6, 0]) cylinder(d = 3.0, h = pad_h);
                    translate([fx + sweep * 0.6, fy, 0]) cylinder(d = 2.0, h = pad_h - 0.2);
                }
            }
            // Wingtip vertical aero fence
            hull() {
                translate([sweep + 1.2, out_y - 0.4, 0]) cylinder(d = 1.6, h = pad_h + 0.6);
                translate([sweep - 1.8, out_y - 0.8, 0]) cylinder(d = 1.6, h = pad_h + 0.4);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.0, 1.15);
    }
}

// ARCH 2: Twin-Bell Thruster / Booster / Hot-Dog Pod
module cheek_arch_a_2(subvar = 0) {
    span_x  = 14.2 + (subvar % 5) * 0.8;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    pod_len = 12.6 + (subvar % 4) * 0.9;
    pod_y   = 5.6 + (subvar % 3) * 0.4;
    n_rings = 2 + (subvar % 3);
    rel_d   = 3.8 + (subvar % 3) * 0.3;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Twin parallel cylindrical booster nacelles / buns
            for (yb = [pod_y - 1.8, pod_y + 1.8]) {
                hull() {
                    translate([-pod_len * 0.42, yb, 0]) cylinder(d = 3.4, h = pad_h + 0.15);
                    translate([ pod_len * 0.42, yb, 0]) cylinder(d = 3.4, h = pad_h + 0.15);
                }
            }
            // Central core tube & aft flared thruster bell (-X)
            hull() {
                translate([-pod_len * 0.48, pod_y, 0]) cylinder(d = 4.2, h = pad_h + 0.4);
                translate([ pod_len * 0.46, pod_y, 0]) cylinder(d = 3.4, h = pad_h + 0.3);
            }
            // Compressor / cooling rings along pod
            for (i = [0 : n_rings - 1]) {
                rx = -3.2 + i * (6.4 / max(1, n_rings - 1));
                hull() {
                    translate([rx, pod_y - 2.2, 0]) cylinder(d = 1.8, h = pad_h + 0.5);
                    translate([rx, pod_y + 2.2, 0]) cylinder(d = 1.8, h = pad_h + 0.5);
                }
            }
        }
        cheek_hub_cuts(pad_h, 0, 0, 0);
        for (xr = [-2.6, 2.6]) {
            translate([xr, pod_y, -0.05]) cylinder(d = rel_d, h = 1.25);
        }
    }
}

// ARCH 3: Zig-Zag Lightning / Raptor Sickle / Blade Pod
module cheek_arch_a_3(subvar = 0) {
    span_x  = 14.0 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    out_y   = 9.0 + (subvar % 4) * 0.55;
    zig_x   = 4.8 + (subvar % 3) * 0.7;
    rel_d   = 4.0 + (subvar % 4) * 0.3;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Root bolster
            hull() {
                translate([-4.2, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.15);
                translate([ 4.2, 2.0, 0]) cylinder(d = 4.0, h = pad_h + 0.15);
                translate([ 0.0, 5.2, 0]) cylinder(d = 4.8, h = pad_h + 0.25);
            }
            // Zig-zag lightning bolt / raptor sickle segments
            hull() {
                translate([-2.5, 2.6, 0]) cylinder(d = 3.8, h = pad_h + 0.25);
                translate([ zig_x, 6.2, 0]) cylinder(d = 3.2, h = pad_h + 0.15);
            }
            hull() {
                translate([ zig_x, 6.2, 0]) cylinder(d = 3.2, h = pad_h + 0.15);
                translate([-1.2, 7.6, 0]) cylinder(d = 3.0, h = pad_h + 0.1);
            }
            hull() {
                translate([-1.2, 7.6, 0]) cylinder(d = 3.0, h = pad_h + 0.1);
                translate([ zig_x + 1.8, out_y, 0]) cylinder(d1 = 2.4, d2 = 1.4, h = pad_h - 0.1);
            }
            // Secondary rear barb (-X)
            hull() {
                translate([-2.8, 3.2, 0]) cylinder(d = 3.2, h = pad_h + 0.1);
                translate([-zig_x - 1.2, out_y - 1.4, 0]) cylinder(d1 = 2.2, d2 = 1.4, h = pad_h - 0.15);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 4.8, 1.15);
    }
}

// ARCH 4: Scalloped Bat / Wyvern / Membrane Wing Pod
module cheek_arch_a_4(subvar = 0) {
    span_x  = 14.4 + (subvar % 5) * 0.8;
    pad_h   = 2.10 + (subvar % 3) * 0.08;
    out_y   = 9.2 + (subvar % 4) * 0.5;
    rib_ext = 5.4 + (subvar % 3) * 0.65;
    rel_d   = 4.2 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Webbed membrane panels
            hull() {
                translate([ 4.2, 2.0, 0]) cylinder(d = 3.6, h = pad_h - 0.2);
                translate([-4.2, 2.0, 0]) cylinder(d = 3.6, h = pad_h - 0.2);
                translate([ rib_ext, out_y - 0.8, 0]) cylinder(d = 2.4, h = pad_h - 0.3);
                translate([ 0.0, out_y + 0.4, 0]) cylinder(d = 2.4, h = pad_h - 0.3);
                translate([-rib_ext, out_y - 1.2, 0]) cylinder(d = 2.4, h = pad_h - 0.3);
            }
            // 3 Raised skeletal bat/wyvern finger struts + thumb claw
            for (rx = [-rib_ext, 0.0, rib_ext]) {
                hull() {
                    translate([rx * 0.35, 2.0, 0]) cylinder(d = 2.6, h = pad_h + 0.3);
                    translate([rx, (rx == 0 ? out_y + 0.6 : out_y - 0.6), 0]) cylinder(d = 1.8, h = pad_h + 0.15);
                }
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.2, 1.10);
        // Scalloped trailing-edge membrane cutouts
        for (sx = [-rib_ext * 0.52, rib_ext * 0.52]) {
            translate([sx, out_y + 0.9, -0.05])
                cylinder(d = 3.2 + (subvar % 2) * 0.4, h = pad_h + 0.5);
        }
    }
}

// ARCH 5: Hot-Rod Flame / Phoenix / Croissant Crescent Pod
module cheek_arch_a_5(subvar = 0) {
    span_x  = 14.0 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    out_y   = 8.6 + (subvar % 4) * 0.5;
    horn_x  = 6.4 + (subvar % 4) * 0.55;
    rel_d   = 4.0 + (subvar % 4) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Central crescent belly / flame core
            hull() {
                translate([ 0.0, out_y - 2.0, 0]) cylinder(d = 5.6, h = pad_h + 0.3);
                translate([-4.2, 4.4, 0]) cylinder(d = 4.2, h = pad_h + 0.15);
                translate([ 4.2, 4.4, 0]) cylinder(d = 4.2, h = pad_h + 0.15);
            }
            // Swept crescent horn / flame tongues curving inward & outward
            for (xs = [-1, 1]) {
                hull() {
                    translate([xs * 4.2, 4.4, 0]) cylinder(d = 4.0, h = pad_h + 0.15);
                    translate([xs * horn_x, 2.4 + (subvar % 2) * 1.2, 0]) cylinder(d = 2.4, h = pad_h - 0.1);
                }
                hull() {
                    translate([xs * 2.2, out_y - 2.2, 0]) cylinder(d = 3.2, h = pad_h + 0.2);
                    translate([xs * (horn_x - 1.6), out_y, 0]) cylinder(d = 2.0, h = pad_h);
                }
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.4, 1.20);
    }
}

// ARCH 6: Heraldic Knight Shield / Buckler / Waffle Grid Pod
module cheek_arch_a_6(subvar = 0) {
    span_x  = 13.8 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    sh_w    = 4.8 + (subvar % 4) * 0.45;
    out_y   = 9.4 + (subvar % 3) * 0.45;
    rel_d   = 4.4 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Beveled heater shield / waffle plate body
            hull() {
                translate([-sh_w, 3.0, 0]) cylinder(d = 3.6, h = pad_h + 0.2);
                translate([ sh_w, 3.0, 0]) cylinder(d = 3.6, h = pad_h + 0.2);
                translate([-sh_w * 0.85, out_y - 1.2, 0]) cylinder(d = 3.4, h = pad_h + 0.2);
                translate([ sh_w * 0.85, out_y - 1.2, 0]) cylinder(d = 3.4, h = pad_h + 0.2);
                translate([ 0.0, out_y + 0.4, 0]) cylinder(d = 3.0, h = pad_h + 0.25);
            }
            // Raised heraldic cross / rim boss
            translate([0, 6.2, pad_h + 0.1])
                cube([sh_w * 1.5, 1.4, 0.45], center = true);
            translate([0, 6.2, pad_h + 0.1])
                cube([1.6, 5.2, 0.45], center = true);
        }
        cheek_hub_cuts(pad_h, rel_d, 6.0, 1.20);
        // Waffle / coffer recess pockets on top quadrants
        for (xp = [-2.4, 2.4]) {
            for (yp = [4.6, 7.8]) {
                translate([xp, yp, pad_h - 0.5])
                    cube([1.9 + (subvar % 2) * 0.3, 1.7, 1.2], center = true);
            }
        }
    }
}

// ARCH 7: Toothed Sawblade / Compass Rose / Gear Bumper Pod
module cheek_arch_a_7(subvar = 0) {
    span_x  = 13.8 + (subvar % 5) * 0.8;
    pad_h   = 2.10 + (subvar % 3) * 0.08;
    n_teeth = 5 + (subvar % 4); // 5, 6, 7, or 8 radial teeth
    rad_out = 5.4 + (subvar % 3) * 0.45;
    cy_hub  = 6.0 + (subvar % 2) * 0.4;
    rel_d   = 4.4 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Circular sawblade / gear / compass disc
            translate([0, cy_hub, 0])
                cylinder(d = rad_out * 1.55, h = pad_h + 0.15);
            // Radial teeth around outer arc
            for (i = [0 : n_teeth - 1]) {
                ang = -75 + i * (150 / max(1, n_teeth - 1));
                translate([0, cy_hub, 0])
                    rotate([0, 0, ang])
                        hull() {
                            cylinder(d = 3.2, h = pad_h + 0.2);
                            translate([0, rad_out, 0]) cylinder(d = 1.6, h = pad_h - 0.1);
                        }
            }
            // Central raised compass/gear collar
            translate([0, cy_hub, 0])
                cylinder(d = 4.6, h = pad_h + 0.45);
        }
        cheek_hub_cuts(pad_h, rel_d, cy_hub, 1.20);
    }
}

// ARCH 8: Dual-Barrel Laser / Ion Cannon / Torpedo Pod
module cheek_arch_a_8(subvar = 0) {
    span_x    = 14.0 + (subvar % 5) * 0.85;
    pad_h     = 2.15 + (subvar % 3) * 0.08;
    bbl_len   = 7.2 + (subvar % 4) * 0.6;
    n_barrels = 2 + (subvar % 2); // 2 or 3 forward barrels
    rel_d     = 4.0 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Armored turret breech housing
            hull() {
                translate([-4.4 - (subvar % 3) * 0.4, 3.8, 0]) cylinder(d = 4.4, h = pad_h + 0.25);
                translate([ 1.8, 4.2, 0]) cylinder(d = 4.8, h = pad_h + 0.25);
                translate([-3.6, 7.6, 0]) cylinder(d = 4.0, h = pad_h + 0.15);
                translate([ 1.8, 7.8, 0]) cylinder(d = 4.4, h = pad_h + 0.2);
            }
            // Forward-pointing laser / cannon barrels (+X)
            for (i = [0 : n_barrels - 1]) {
                by = 4.0 + i * (4.2 / max(1, n_barrels - 1));
                hull() {
                    translate([0.5, by, 0]) cylinder(d = 2.6, h = pad_h + 0.1);
                    translate([bbl_len, by, 0]) cylinder(d = 2.1, h = pad_h - 0.1);
                }
                // Muzzle flash ring
                translate([bbl_len - 0.4, by, 0])
                    cylinder(d = 2.7, h = pad_h + 0.15);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.4, 1.20);
    }
}

// ARCH 9: Layered Eagle / Pegasus / Owl Feather Fan Pod
module cheek_arch_a_9(subvar = 0) {
    span_x   = 14.2 + (subvar % 5) * 0.85;
    pad_h    = 2.15 + (subvar % 3) * 0.08;
    n_plumes = 4 + (subvar % 3); // 4, 5, or 6 fan feathers
    fan_len  = 9.4 + (subvar % 4) * 0.55;
    rel_d    = 4.0 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Arched shoulder covert bolster
            hull() {
                translate([-4.2, 2.2, 0]) cylinder(d = 4.0, h = pad_h + 0.25);
                translate([ 4.2, 2.2, 0]) cylinder(d = 4.0, h = pad_h + 0.25);
                translate([ 0.0, 5.4, 0]) cylinder(d = 5.4, h = pad_h + 0.30);
            }
            // Radial fan of overlapping feathers
            for (i = [0 : n_plumes - 1]) {
                ang = -36 + i * (72 / max(1, n_plumes - 1)) - (subvar % 3) * 3;
                plen = fan_len - abs(i - (n_plumes - 1) / 2) * 0.75;
                rotate([0, 0, ang])
                    hull() {
                        translate([0, 2.2, 0]) cylinder(d = 3.4, h = pad_h + 0.15);
                        translate([0, plen, 0]) cylinder(d = 2.2, h = pad_h - 0.1);
                    }
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.2, 1.15);
    }
}

// ARCH 10: Honeycomb Hex / ERA Reactive Tile / Subwoofer Pod
module cheek_arch_a_10(subvar = 0) {
    span_x  = 14.0 + (subvar % 5) * 0.8;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    hex_r   = 4.8 + (subvar % 4) * 0.35;
    hex_sp  = 3.4 + (subvar % 3) * 0.35;
    rel_d   = 3.8 + (subvar % 3) * 0.3;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Twin interlocking hexagonal reactive / speaker pods
            hull() {
                translate([-hex_sp, 5.8, 0]) cylinder(d = hex_r * 1.55, h = pad_h + 0.2, $fn = 6);
                translate([ hex_sp, 5.8, 0]) cylinder(d = hex_r * 1.55, h = pad_h + 0.2, $fn = 6);
            }
            // Raised hex rim bezels
            for (xh = [-hex_sp, hex_sp]) {
                translate([xh, 5.8, 0])
                    cylinder(d = hex_r * 1.35, h = pad_h + 0.45, $fn = 6);
            }
        }
        cheek_hub_cuts(pad_h, 0, 0, 0);
        // Recessed hex cells on top + underside weight pockets
        for (xh = [-hex_sp, hex_sp]) {
            translate([xh, 5.8, pad_h - 0.35])
                cylinder(d = hex_r * 0.88, h = 1.2, $fn = 6);
            translate([xh, 5.8, -0.05])
                cylinder(d = rel_d, h = 1.20);
        }
    }
}

// ARCH 11: Curved Horn / Pretzel / Kraken Tentacle Pod
module cheek_arch_a_11(subvar = 0) {
    span_x  = 14.0 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    curl_x  = 5.2 + (subvar % 4) * 0.55;
    out_y   = 9.0 + (subvar % 3) * 0.5;
    rel_d   = 4.0 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // S-curving tentacle / ram horn / pretzel loop
            hull() {
                translate([-3.8, 2.2, 0]) cylinder(d = 4.4, h = pad_h + 0.2);
                translate([ 2.8, 5.4, 0]) cylinder(d = 3.8, h = pad_h + 0.15);
            }
            hull() {
                translate([ 2.8, 5.4, 0]) cylinder(d = 3.8, h = pad_h + 0.15);
                translate([ curl_x, 7.8, 0]) cylinder(d = 3.2, h = pad_h + 0.1);
            }
            hull() {
                translate([ curl_x, 7.8, 0]) cylinder(d = 3.2, h = pad_h + 0.1);
                translate([ 0.5, out_y, 0]) cylinder(d = 2.8, h = pad_h);
            }
            hull() {
                translate([ 0.5, out_y, 0]) cylinder(d = 2.8, h = pad_h);
                translate([-curl_x + 0.8, out_y - 1.4, 0]) cylinder(d = 2.2, h = pad_h - 0.1);
            }
            hull() {
                translate([-curl_x + 0.8, out_y - 1.4, 0]) cylinder(d = 2.2, h = pad_h - 0.1);
                translate([-3.8, 4.8, 0]) cylinder(d = 2.6, h = pad_h);
            }
            // Suction cup / horn ridge nodules on top
            for (pt = [[-1.0, 3.8], [2.6, 5.4], [curl_x - 0.6, 7.6], [0.5, out_y]]) {
                translate([pt[0], pt[1], pad_h - 0.25])
                    cylinder(d = 2.0, h = 0.70);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 5.0, 1.15);
    }
}

// ARCH 12: Louvered Shark Gill / Heatsink / Ribbed Fin Pod
module cheek_arch_a_12(subvar = 0) {
    span_x  = 14.2 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    n_fins  = 4 + (subvar % 3); // 4, 5, or 6 gill louvers / heatsink fins
    out_y   = 8.6 + (subvar % 4) * 0.5;
    rel_d   = 4.2 + (subvar % 3) * 0.35;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Longitudinal spine manifold
            hull() {
                translate([-5.8 - (subvar % 3) * 0.4, 4.6, 0]) cylinder(d = 3.8, h = pad_h);
                translate([ 5.8 + (subvar % 3) * 0.4, 4.6, 0]) cylinder(d = 3.8, h = pad_h);
            }
            // Angled gill / heatsink louver blades
            for (i = [0 : n_fins - 1]) {
                fx = -5.0 + i * (10.0 / max(1, n_fins - 1));
                hull() {
                    translate([fx + 0.8, 2.0, 0]) cylinder(d = 2.2, h = pad_h + 0.15);
                    translate([fx - 1.0, out_y, 0]) cylinder(d = 2.0, h = pad_h + 0.3);
                }
            }
        }
        cheek_hub_cuts(pad_h, rel_d, 4.8, 1.15);
    }
}

// ARCH 13: Disc Shield / Pizza Wedge / Starfish / Medallion Pod
module cheek_arch_a_13(subvar = 0) {
    span_x  = 13.8 + (subvar % 5) * 0.85;
    pad_h   = 2.15 + (subvar % 3) * 0.08;
    disc_d  = 9.8 + (subvar % 4) * 0.65;
    cy_disc = 6.0 + (subvar % 3) * 0.35;
    n_studs = 4 + (subvar % 4);
    rel_d   = 4.6 + (subvar % 3) * 0.4;

    difference() {
        union() {
            cheek_hub_solid(pad_h, span_x);
            // Round buckler / medallion / cookie / slice shield
            translate([0, cy_disc, 0])
                cylinder(d1 = disc_d, d2 = disc_d - 0.6, h = pad_h + 0.15);
            // Raised outer rim & central dome boss
            translate([0, cy_disc, pad_h + 0.05])
                cylinder(d1 = 4.2, d2 = 2.8, h = 0.55);
            for (i = [0 : n_studs - 1]) {
                ang = i * (360 / n_studs);
                translate([0, cy_disc, 0])
                    rotate([0, 0, ang])
                        translate([disc_d * 0.34, 0, pad_h])
                            cylinder(d1 = 2.0, d2 = 1.2, h = 0.5);
            }
        }
        cheek_hub_cuts(pad_h, rel_d, cy_disc, 1.25);
    }
}

// ============================================================================
// MASTER CHEEK POD PAIR GENERATOR (PART_ID = 1401..1575)
// Renders Left (Y = -15mm) and Right (Y = +15mm) mirrored pair
// ============================================================================
module single_cheek_pod_a(part_id) {
    arch   = (part_id - 1401) % 14;
    subvar = floor((part_id - 1401) / 14);

    if      (arch == 0)  cheek_arch_a_0(subvar);
    else if (arch == 1)  cheek_arch_a_1(subvar);
    else if (arch == 2)  cheek_arch_a_2(subvar);
    else if (arch == 3)  cheek_arch_a_3(subvar);
    else if (arch == 4)  cheek_arch_a_4(subvar);
    else if (arch == 5)  cheek_arch_a_5(subvar);
    else if (arch == 6)  cheek_arch_a_6(subvar);
    else if (arch == 7)  cheek_arch_a_7(subvar);
    else if (arch == 8)  cheek_arch_a_8(subvar);
    else if (arch == 9)  cheek_arch_a_9(subvar);
    else if (arch == 10) cheek_arch_a_10(subvar);
    else if (arch == 11) cheek_arch_a_11(subvar);
    else if (arch == 12) cheek_arch_a_12(subvar);
    else                 cheek_arch_a_13(subvar);
}

module render_cheek_pair_a(part_id) {
    for (side = [-1, 1]) {
        translate([0, side * cheek_pair_offset_y, 0])
            mirror([0, (side < 0 ? 1 : 0), 0])
                single_cheek_pod_a(part_id);
    }
    // Internal registration marker inside +Y pod hub for 3-volume structure (Volumes: 3, Simple: yes)
    translate([0, cheek_pair_offset_y + 1.8, 0.55])
        cube([0.2, 0.2, 0.2], center = true);
}

if (PART_ID >= 1401 && PART_ID <= 1575) {
    render_cheek_pair_a(PART_ID);
} else {
    render_cheek_pair_a(1401);
}