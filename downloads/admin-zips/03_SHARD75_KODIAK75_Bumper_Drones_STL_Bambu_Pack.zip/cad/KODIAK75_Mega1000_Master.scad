// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 3: MEGA-1000 MASTER OPENSCAD ROUTER
// PART_ID = 1001..2000 (400 Crowns + 350 Cheek Pod Pairs + 250 Belly Skids)
// Combined with Original 40 + Wave 1 (100) + Wave 2 (100) = 1,240 Total Parts!
// ============================================================================
// Usage:
//   openscad -D "PART_ID=1001" -o KODIAK75_Crown_1001_GrizzlyTotem.stl KODIAK75_Mega1000_Master.scad
// ============================================================================

PART_ID = 1001;

use <KODIAK75_Mega1000_Crowns_A.scad>
use <KODIAK75_Mega1000_Crowns_B.scad>
use <KODIAK75_Mega1000_Cheeks_A.scad>
use <KODIAK75_Mega1000_Cheeks_B.scad>
use <KODIAK75_Mega1000_Belly.scad>

module render_mega1000_object(part_id) {
    if (part_id >= 1001 && part_id <= 1200) {
        KODIAK75_Mega1000_Crown_A(part_id);
    } else if (part_id >= 1201 && part_id <= 1400) {
        mega1000_crown_b(part_id);
    } else if (part_id >= 1401 && part_id <= 1575) {
        render_cheek_pair_a(part_id);
    } else if (part_id >= 1576 && part_id <= 1750) {
        render_cheek_pair_b(part_id);
    } else if (part_id >= 1751 && part_id <= 2000) {
        render_mega1000_belly(part_id);
    }
}

render_mega1000_object(PART_ID);
