// ============================================================================
// KODIAK-75 BUMPER DRONE - WAVE 4: UNDER-BELLY SKIDS (PART_ID 2751..3000)
// 250 Distinct Support-Free Under-Belly Skids (10 Archetypes x 25 Subvars)
// ============================================================================
// Material: TPU 95A (density = 1.21 g/cm^3 = 0.00121 g/mm^3)
// Mass Target Budget: 0.60g .. 1.15g (Volume: 500 .. 950 mm^3)
// Print Orientation: 100% Flat at Z = 0.00mm with Zero Supports (<= 45 deg overhang)
// Mating Standard: Zone 4 Dual Sockets & Conical Shear Bosses at 36.0mm Pitch (X = +/-18mm)
// ============================================================================

$fn = 28;

PART_ID = 2751;

// --- Master Interface Constants (Zone 4 Dual-Magnet Belly Skid) ---
mag_pocket_dia    = 2.10; // Clearance for 2.00mm N52 disc magnet (+0.10mm press-fit)
mag_pocket_depth  = 1.20; // 1.00mm magnet thickness + 0.20mm anti-shatter recess
shear_boss_dia1   = 3.40; // Base diameter of male conical shear boss at mating plane
shear_boss_dia2   = 2.10; // Tip diameter of male conical shear boss
shear_boss_height = 0.45; // Height of male conical shear boss
belly_mag_spacing = 36.0; // Ventral dual-magnet pitch along X-axis (X = -18mm and X = +18mm)

// ============================================================================
// UNIVERSAL ZONE 4 HELPER MODULES
// ============================================================================

module n52_mating_boss_up() {
    cylinder(d1 = shear_boss_dia1, d2 = shear_boss_dia2, h = shear_boss_height);
}

module n52_mating_pocket_cut_up() {
    translate([0, 0, shear_boss_height - mag_pocket_depth])
        cylinder(d = mag_pocket_dia, h = mag_pocket_depth + 0.10);
}

module belly_mount_posts(h = 1.60) {
    for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
        translate([x_pos, 0, 0])
            cylinder(d1 = 8.2, d2 = 6.8, h = h);
        translate([x_pos, 0, h - 0.15])
            cylinder(d1 = shear_boss_dia1 + 0.15, d2 = shear_boss_dia2, h = shear_boss_height + 0.15);
    }
}

module belly_magnet_cuts(h = 1.60) {
    for (x_pos = [-belly_mag_spacing / 2, belly_mag_spacing / 2]) {
        translate([x_pos, 0, h])
            n52_mating_pocket_cut_up();
    }
}

module belly_skid_master_trim(z_scale = 0.42, hub_h = 1.60) {
    difference() {
        union() {
            scale([0.92, 0.92, z_scale * 0.65])
                intersection() {
                    children(0);
                    translate([0, 0, 10.0]) cube([100, 100, 20.0], center = true);
                }
            belly_mount_posts(hub_h);
        }
        belly_magnet_cuts(hub_h);
    }
}

// ============================================================================
// 10 PARAMETRIC 3D BELLY SKID ARCHETYPES (arch = 0..9) x 25 SUB-VARIATIONS
// ============================================================================

// ARCH 0: Armored Bash Plate / Plastron (octagonal waffle-reinforced belly hull)
module belly_w4_arch_0(subvar = 0) {
    len_ext = (subvar % 5) * 0.45;
    wid_ext = floor(subvar / 5) * 0.25;
    rib_cnt = 4 + (subvar % 3);
    z_sc    = 0.40 + (subvar % 4) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Main armored keel spine
            hull() {
                translate([-19.0 - len_ext, 0, 0]) cylinder(d = 8.6, h = 3.6);
                translate([ 19.0 + len_ext, 0, 0]) cylinder(d = 8.6, h = 3.6);
            }
            // Lateral bash plate wings
            hull() {
                translate([-12.0, -7.0 - wid_ext, 0]) cylinder(d = 4.2, h = 2.8);
                translate([ 12.0, -7.0 - wid_ext, 0]) cylinder(d = 4.2, h = 2.8);
                translate([-12.0,  7.0 + wid_ext, 0]) cylinder(d = 4.2, h = 2.8);
                translate([ 12.0,  7.0 + wid_ext, 0]) cylinder(d = 4.2, h = 2.8);
            }
            // Transverse stiffener ribs
            for (i = [0 : rib_cnt - 1]) {
                frac = (i / max(1, rib_cnt - 1)) - 0.5;
                rx = frac * 32.0;
                translate([rx, 0, 0])
                    cube([1.8, 14.0 + wid_ext * 1.5, 3.4], center = true);
            }
        }
    }
}

// ARCH 1: High-Speed Dual Ski Runners (twin cambered toboggan rails with rockered tips)
module belly_w4_arch_1(subvar = 0) {
    len_ext = (subvar % 5) * 0.5;
    rail_y  = 6.5 + floor(subvar / 5) * 0.25;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Central connector bridge between posts
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 7.8, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 7.8, h = 3.4);
            }
            // Twin outboard ski rails
            for (sy = [-1, 1]) {
                hull() {
                    translate([-21.0 - len_ext, sy * rail_y, 0]) cylinder(d1 = 3.6, d2 = 2.0, h = 4.2);
                    translate([-14.0,           sy * rail_y, 0]) cylinder(d = 4.0, h = 3.0);
                    translate([ 14.0,           sy * rail_y, 0]) cylinder(d = 4.0, h = 3.0);
                    translate([ 21.0 + len_ext, sy * rail_y, 0]) cylinder(d1 = 3.6, d2 = 2.0, h = 4.2);
                }
                // Angled cross-struts from bridge to rail
                for (xs = [-10, 10]) {
                    hull() {
                        translate([xs, 0, 0]) cylinder(d = 3.4, h = 3.0);
                        translate([xs * 1.2, sy * rail_y, 0]) cylinder(d = 3.0, h = 2.8);
                    }
                }
            }
        }
    }
}

// ARCH 2: Tank / Crawler Dual Treads (segmented track-wheel sleds with mud relief)
module belly_w4_arch_2(subvar = 0) {
    len_ext = (subvar % 5) * 0.45;
    tread_y = 6.8 + floor(subvar / 5) * 0.25;
    n_pads  = 6 + (subvar % 3);
    z_sc    = 0.39 + (subvar % 4) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Main backbone truss
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
            }
            // Dual crawler tread sponsons
            for (sy = [-1, 1]) {
                hull() {
                    translate([-20.0 - len_ext, sy * tread_y, 0]) cylinder(d = 4.4, h = 3.2);
                    translate([ 20.0 + len_ext, sy * tread_y, 0]) cylinder(d = 4.4, h = 3.2);
                }
                // Individual track pad lugs
                for (i = [0 : n_pads - 1]) {
                    frac = (i / max(1, n_pads - 1)) - 0.5;
                    tx = frac * (36.0 + len_ext * 1.5);
                    translate([tx, sy * tread_y, 0])
                        cube([2.0, 4.4, 3.4], center = true);
                }
            }
        }
    }
}

// ARCH 3: Air-Cushion Hover Pontoons (flared perimeter skirts with ground channel)
module belly_w4_arch_3(subvar = 0) {
    len_ext = (subvar % 5) * 0.5;
    wid_ext = floor(subvar / 5) * 0.3;
    z_sc    = 0.40 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Central airframe spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
            }
            // Perimeter hovercraft skirt
            difference() {
                hull() {
                    translate([-20.0 - len_ext, -7.5 - wid_ext, 0]) cylinder(d = 4.4, h = 3.2);
                    translate([ 20.0 + len_ext, -7.5 - wid_ext, 0]) cylinder(d = 4.4, h = 3.2);
                    translate([-20.0 - len_ext,  7.5 + wid_ext, 0]) cylinder(d = 4.4, h = 3.2);
                    translate([ 20.0 + len_ext,  7.5 + wid_ext, 0]) cylinder(d = 4.4, h = 3.2);
                }
                // Ventral air plenum chamber recess
                translate([0, 0, -0.05])
                    hull() {
                        translate([-14.0, -4.0, 0]) cylinder(d = 4.0, h = 5.0);
                        translate([ 14.0, -4.0, 0]) cylinder(d = 4.0, h = 5.0);
                        translate([-14.0,  4.0, 0]) cylinder(d = 4.0, h = 5.0);
                        translate([ 14.0,  4.0, 0]) cylinder(d = 4.0, h = 5.0);
                    }
            }
        }
    }
}

// ARCH 4: Twin Hydrofoil Keels (swept catamaran sponsons for ultra-low friction)
module belly_w4_arch_4(subvar = 0) {
    len_ext = (subvar % 5) * 0.55;
    keel_y  = 6.8 + floor(subvar / 5) * 0.25;
    z_sc    = 0.42 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Central mounting post beam
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 7.8, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 7.8, h = 3.4);
            }
            // Catamaran hydrofoil keels
            for (sy = [-1, 1]) {
                hull() {
                    translate([-21.0 - len_ext, sy * keel_y, 0]) cylinder(d1 = 4.4, d2 = 1.6, h = 3.8);
                    translate([ 21.0 + len_ext, sy * keel_y, 0]) cylinder(d1 = 4.4, d2 = 1.6, h = 3.8);
                }
                // Dynamic flow step wedges
                for (xs = [-10, 0, 10]) {
                    translate([xs, sy * keel_y, 0])
                        cylinder(d1 = 3.2, d2 = 1.4, h = 3.6, $fn = 3);
                }
            }
        }
    }
}

// ARCH 5: Multi-Legged Outrigger Skids (six-pod insectoid landing pads with dampers)
module belly_w4_arch_5(subvar = 0) {
    len_ext = (subvar % 5) * 0.45;
    span_y  = 7.4 + floor(subvar / 5) * 0.25;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Center mounting spine
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
            }
            // 6 outrigger landing pad feet
            for (xs = [-16.0 - len_ext, 0, 16.0 + len_ext]) {
                for (sy = [-1, 1]) {
                    hull() {
                        translate([xs * 0.7, 0, 0]) cylinder(d = 4.0, h = 3.0);
                        translate([xs, sy * span_y, 0]) cylinder(d1 = 5.2, d2 = 3.0, h = 2.8);
                    }
                }
            }
        }
    }
}

// ARCH 6: Maglev Rail Coils (stepped linear-induction coil tracks)
module belly_w4_arch_6(subvar = 0) {
    len_ext = (subvar % 5) * 0.45;
    rail_y  = 6.6 + floor(subvar / 5) * 0.25;
    n_coils = 5 + (subvar % 3);
    z_sc    = 0.40 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Spine bridge
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
            }
            // Dual linear induction coil tracks
            for (sy = [-1, 1]) {
                hull() {
                    translate([-20.0 - len_ext, sy * rail_y, 0]) cylinder(d = 4.4, h = 3.2);
                    translate([ 20.0 + len_ext, sy * rail_y, 0]) cylinder(d = 4.4, h = 3.2);
                }
                // Stepped magnetic coil nodes
                for (i = [0 : n_coils - 1]) {
                    frac = (i / max(1, n_coils - 1)) - 0.5;
                    cx = frac * (34.0 + len_ext);
                    translate([cx, sy * rail_y, 0])
                        cylinder(d1 = 3.4, d2 = 1.8, h = 3.6, $fn = 8);
                }
            }
        }
    }
}

// ARCH 7: Snowshoe Webbed Lattice (rawhide-style shock-absorbing cross-rib sled)
module belly_w4_arch_7(subvar = 0) {
    len_ext = (subvar % 5) * 0.5;
    wid_ext = floor(subvar / 5) * 0.25;
    n_ribs  = 6 + (subvar % 3);
    z_sc    = 0.39 + (subvar % 4) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Perimeter hoop frame
            difference() {
                hull() {
                    translate([-20.0 - len_ext, 0, 0]) cylinder(d = 8.0 + wid_ext * 2.0, h = 3.2);
                    translate([ 20.0 + len_ext, 0, 0]) cylinder(d = 8.0 + wid_ext * 2.0, h = 3.2);
                }
                // Lightening core cutout
                translate([0, 0, -0.05])
                    hull() {
                        translate([-15.0, 0, 0]) cylinder(d = 3.6, h = 4.0);
                        translate([ 15.0, 0, 0]) cylinder(d = 3.6, h = 4.0);
                    }
            }
            // Cross-webbing rawhide ribs
            for (i = [0 : n_ribs - 1]) {
                frac = (i / max(1, n_ribs - 1)) - 0.5;
                rx = frac * 32.0;
                translate([rx, 0, 0])
                    cube([1.6, 9.0 + wid_ext * 1.5, 3.0], center = true);
            }
            // Center mounting hub pads
            for (xs = [-18, 18]) {
                translate([xs, 0, 0]) cylinder(d = 8.0, h = 3.2);
            }
        }
    }
}

// ARCH 8: Heavy-Duty Pipe Roll-Cage (truss-braced tubular rock-crawler sliders)
module belly_w4_arch_8(subvar = 0) {
    len_ext = (subvar % 5) * 0.5;
    rail_y  = 7.0 + floor(subvar / 5) * 0.25;
    z_sc    = 0.41 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Central heavy chassis beam
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.2, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.2, h = 3.4);
            }
            // Tubular outer rock sliders
            for (sy = [-1, 1]) {
                hull() {
                    translate([-21.0 - len_ext, sy * rail_y, 0]) cylinder(d = 4.2, h = 3.2);
                    translate([ 21.0 + len_ext, sy * rail_y, 0]) cylinder(d = 4.2, h = 3.2);
                }
                // Tubular diagonal truss braces
                for (xs = [-12, 0, 12]) {
                    hull() {
                        translate([xs * 0.7, 0, 0]) cylinder(d = 3.6, h = 3.0);
                        translate([xs, sy * rail_y, 0]) cylinder(d = 3.6, h = 3.0);
                    }
                }
            }
        }
    }
}

// ARCH 9: Spring-Arch Shock Dampers (elliptical leaf-spring cushions for high drops)
module belly_w4_arch_9(subvar = 0) {
    len_ext = (subvar % 5) * 0.5;
    wid_ext = floor(subvar / 5) * 0.25;
    n_leaves = 3 + (subvar % 2);
    z_sc    = 0.40 + (subvar % 3) * 0.01;
    belly_skid_master_trim(z_sc, 1.60) {
        union() {
            // Main backbone
            hull() {
                translate([-18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
                translate([ 18.0, 0, 0]) cylinder(d = 8.0, h = 3.4);
            }
            // Elliptical leaf spring arches
            for (sy = [-1, 1]) {
                for (l = [0 : n_leaves - 1]) {
                    frac = (l / max(1, n_leaves - 1)) - 0.5;
                    lx = frac * (28.0 + len_ext);
                    hull() {
                        translate([lx * 0.7, 0, 0]) cylinder(d = 3.8, h = 3.0);
                        translate([lx, sy * (6.6 + wid_ext), 0]) cylinder(d1 = 4.4, d2 = 2.4, h = 3.6);
                    }
                }
            }
        }
    }
}

// ============================================================================
// MASTER DISPATCHER FOR UNDER-BELLY SKIDS (PART_ID = 2751..3000)
// ============================================================================
module render_wave4_belly(part_id = 2751) {
    idx    = part_id - 2751;
    arch   = idx % 10;
    subvar = floor(idx / 10); // 0..24 for 2751..3000

    if      (arch == 0) belly_w4_arch_0(subvar);
    else if (arch == 1) belly_w4_arch_1(subvar);
    else if (arch == 2) belly_w4_arch_2(subvar);
    else if (arch == 3) belly_w4_arch_3(subvar);
    else if (arch == 4) belly_w4_arch_4(subvar);
    else if (arch == 5) belly_w4_arch_5(subvar);
    else if (arch == 6) belly_w4_arch_6(subvar);
    else if (arch == 7) belly_w4_arch_7(subvar);
    else if (arch == 8) belly_w4_arch_8(subvar);
    else if (arch == 9) belly_w4_arch_9(subvar);
}

if (PART_ID >= 2751 && PART_ID <= 3000) {
    render_wave4_belly(PART_ID);
} else {
    render_wave4_belly(2751);
}
