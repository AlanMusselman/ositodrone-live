# SHARD-75 / KODIAK-75: Sourced Bill of Materials (BOM) & Starter Kit Pricing

This document breaks down the unit cost for a single **SHARD-75 / KODIAK-75** aircraft across its verified mass configurations (**`37.1g` (LOS)** / **`38.8g` (Dual LOS+FPV)** / **`45.5g` (Full Optical-Flow + LiDAR + N52 Armor Spec)**; `$101.44` LOS / `$121.43` Dual LOS+FPV, `$112.50` blended fleet average) alongside the complete **2-Drone Arena Turnkey Kit** (including bulk filament spools, spare props/batteries, the 6-port charger, and the $101 \times 101\text{-inch}$ netted bumper-tag tent).

> **Spreadsheet Export:** You can also open [`KODIAK75_BOM_and_Sourcing.csv`](./KODIAK75_BOM_and_Sourcing.csv) directly in Excel or Google Sheets.

---

## 1. Per-Drone Unit BOM (Marginal Build Cost)

| Category | Component | Recommended COTS Part / Specification | Qty | Unit Cost | Extended |
| :--- | :--- | :--- | :---: | :---: | :---: |
| **Avionics (LOCKED)** | **BetaFPV Matrix 1S `5-in-1` AIO FC** | **BetaFPV Matrix 1S Brushless `5-in-1` (`STM32G473`, `ICM42688P`, `12A Bluejay 48kHz`, `JST-1.25` Motor Sockets, `Serial ELRS 2.4G`, `400mW OpenVTX`, Pre-soldered `BT2.0`, Side `SH1.0` USB-C Dongle, `3.9g`)** | 1 | \$44.99 | **\$44.99** |
| **Propulsion** | Brushless Motors (x4) | `1002 22,000KV` or `0803 22,000KV` (`1.5mm` shaft, `M1.4` 3-hole mount, `JST-1.25` 3-pin plugs) | 1 set | \$39.99 | **\$39.99** |
| **Propulsion** | Open Bi-Blade Props | Gemfan `1610` (`40mm`) or Gemfan `45mm` Polycarbonate Bi-Blades (`1.5mm` shaft) | 1 set | \$2.99 | **\$2.99** |
| **Power** | 1S 550mAh LiHV Pack | BetaFPV Lava `1S 550mAh 75C BT2.0` (`13.8g`, plugs directly into Matrix 1S) | 1 | \$4.80 | **\$4.80** |
| **Power** | Spare BT2.0 Pigtail | Spare `BT2.0` `20AWG` Silicone Pigtail *(Matrix 1S includes 1x pre-soldered)* | 1 | \$1.99 | **\$1.99** |
| **LOS Vision** | Directional RGB LEDs | `5V WS2812B` Micro COB Strip (White/Green Nose + Red/Blue Team Tail/Dome) | 1 | \$3.50 | **\$3.50** |
| **3D Printed** | PC-CF / ePA-CF Frame | `KODIAK75_Frame_v1.stl` + `KODIAK75_Horns_v1.stl` core (~$3.5\text{g}$ filament) | 1 set | \$0.18 | **\$0.18** |
| **3D Printed** | TPU 95A/56D Parts | `550Cradle` + `Horns` skins + `Deck_LOS` + `Deck_FPV` + Magnet Cups (~$6\text{g}$) | 1 set | \$0.20 | **\$0.20** |
| **Breakaway** | EPP Foam Armor Plates | 4x Cut EPP Foam Pods (Top Crown, L/R Cheeks, Belly Skid) | 1 set | \$0.75 | **\$0.75** |
| **Breakaway** | N52 Micro Magnets | $2\text{ mm} \times 1\text{ mm}$ Grade N52 Neodymium Discs (`JC-D0201-N52`, 5x Drone + 5x Plates) | 10 pcs | \$0.08 | **\$0.80** |
| **Hardware** | Fasteners & Grommets | `M2 x 14mm` Nylon Stack Screws + Silicone Soft-Mount Grommets + `M1.4` Motor Screws | 1 set | \$1.25 | **\$1.25** |
| **Subtotal** | **SHARD-75 / KODIAK-75 LOS Mode** | **Ready-to-Play Camera-Less Line-of-Sight Build (`37.1g` AUW)** | — | — | **\$101.44** |
| **FPV Add-On** | Plug-In Nano Camera | BetaFPV `C03` / Runcam `Nano 3` / Caddx `Ant Lite` (`14x14mm`, `JST-SH` 3-pin) | 1 | \$19.99 | **+\$19.99** |
| **TOTAL** | **SHARD-75 / KODIAK-75 Dual-Mode** | **Complete LOS + FPV Convertible Aircraft (`38.8g` Dual LOS+FPV / `45.5g` Full Optical-Flow + LiDAR + N52 Armor Spec; `$112.50` blended fleet avg)** | — | — | **\$121.43** |

---

## 2. Complete 2-Drone Arena Starter Kit (Fleet + Tent + Spares)

| Item | Quantity Included | Total Cost | Notes |
| :--- | :---: | :---: | :--- |
| **2x KODIAK-75 Dual-Mode Drones** (Avionics, Motors, FPV Pods, LEDs) | 2 Complete Quads | **\$221.90** | Includes both LOS LED Domes and FPV Camera Pods for both aircraft |
| **12x 1S 550mAh LiHV Batteries** (BetaFPV Lava 75C BT2.0 or GNB A30) | 12 Packs (6 per drone) | **\$57.60** | Continuous rotation: 2 flying, 6 charging, 4 resting |
| **6x Sets of Spare 40mm–45mm Bi-Blade Props** (24 blades total) | 6 Packs | **\$17.94** | Bulk polycarbonate spares for open-prop clashes |
| **1x Spool CarbonX PC-CF or eSUN ePA-CF Filament** (750g–1kg) | 1 Spool | **\$64.99** | Prints **350+ replacement frames** in-house |
| **1x Spool TPU 95A Filament** (1kg) + **EPP Foam Sheet** + **100x N52 Magnets** | Bulk Shop Stock | **\$62.47** | Enough material for 30+ full sets of breakaway Armor Plates & cradles |
| **1x VIFLY WhoopStor V3 6-Port 1S LiHV Storage Charger** | 1 Charger | **\$42.99** | Charges 6x 550mAh packs at $1.3\text{A}$ in ~25 minutes |
| **1x Alvantor $101\text{"} \times 101\text{"} \times 84\text{"}$ Pop-Up Netted Screen Tent** | 1 Arena Tent | **\$139.99** | Portable fiberglass-ribbed no-see-um mesh BUMPER TAG ARENA |
| **COMPLETE 2-DRONE ARENA TURNKEY TOTAL** | **Full System** | **\$607.88** | Everything required to print, build, charge, and run 2-player bumper-tag heats |
