﻿# Project Handoff Context: KODIAK-75 (1S Breakaway Bumper-Tag Micro-Drone)

## 1. Project Overview & System Identity
* **Codename:** KODIAK-75 (*Kinetic Omnidirectional Defensive Impact Arena Kodiak — 75mm Standard*)
* **Core Mission:** A single-cell (1S) micro-bumper-tag quadcopter engineered to bumper match inside a confined 101 x 101-inch ($2.56\text{ m} \times 2.56\text{ m}$) pop-up netted screen tent (such as an Alvantor fiberglass-ribbed no-see-um mesh shelter).
* **Primary Mechanic:** Two-tier ablative structure. The inner carbon-printed propulsion chassis is permanent and crash-proof, while four outer sacrificial armor "Armor Plates" (held on by micro-neodymium magnets) physically shear off upon mid-air collision or open-prop strikes. Betaflight's active `crash_recovery` loop automatically re-levels the drone within 500 ms of impact so bumper-tag continues uninterrupted.

## 2. Design Evolution & Locked Architectural Decisions
* **Rejected Propulsion-Breakaway Toys:** Evaluated and rejected full-module break-apart drones (Makeblock Airblock, 140g) and LEGO frames (Flybrix) because detaching a motor on the first collision grounds the aircraft and interrupts match flow.
* **Removed Propeller Guards (Guardless "Printpick" Layout):** Transitioned from a 65mm ducted Tiny Whoop to an open-prop guardless architecture to eliminate duct drag and weight, increasing thrust efficiency and enabling offensive prop-strike armor stripping.
* **Standardized on a 75mm In-House 3D-Printed Carbon Frame:** Scaled the diagonal wheelbase to 75.0 mm to clear 40mm to 45mm open bi-blade propellers and accommodate the length of a larger battery.
* **Upgraded Power to 1S 550mAh LiHV:** Stepped up from a 300mAh pack (~8.2g) to a 1S 550mAh LiHV pack (~13.5g–15.0g, ~68mm x 16mm x 6.5mm) with a high-current BT2.0 or A30 connector for 4.5 to 6.5 minutes of Match Endurance.
* **Made the FPV Camera Optional (Dual LOS / FPV Modular Deck):** Engineered a 60-second swappable upper deck on the M2 flight controller stack so the drone can fly either Camera-Less Line-of-Sight (LOS) (using directional front/rear LEDs and Angle/Headless mode) or FPV (using a plug-in nano camera pod).

## 3. Deliverables Implemented in This Workspace
1. **[`KODIAK-75_PRD_and_Blueprint.md`](./KODIAK-75_PRD_and_Blueprint.md):** Complete Engineering Blueprint and Product Requirements Document.
2. **[`cad/`](./cad/):** Parametric OpenSCAD scripts (`KODIAK75_Parametric_Master.scad`) and generated 3D-printable `.stl` meshes for all 6 KODIAK-75 structural and breakaway modules.
3. **[`slicer/`](./slicer/):** OrcaSlicer / PrusaSlicer print profiles (`.json` and `.ini`) for CarbonX PC-CF / ePA-CF, TPU 95A/56D, and the multi-layer TPU + ePA-CF sandwich standoff horns.
4. **[`firmware/`](./firmware/):** Full Betaflight 4.5+ `diff all` CLI configuration including PID/filter defaults, RPM filtering, AUX mode matrix, VTX Pit Mode protection, and addressable RGB LED strip team/orientation profile.
