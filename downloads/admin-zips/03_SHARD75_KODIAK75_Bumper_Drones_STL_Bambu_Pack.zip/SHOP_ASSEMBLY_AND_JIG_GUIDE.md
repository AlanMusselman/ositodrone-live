# KODIAK-75: Shop Assembly, Wiring & Magnet Polarity Jig Manual

**Osito Drone Services — Bench Production & Fleet Maintenance Standard**

This manual provides the step-by-step production workflow for building, wiring, and polarity-checking a fleet of **KODIAK-75** Bumper Drones so that **any breakaway Armor Plate or Kid Customization Mod-Pod in your bin fits any drone in your fleet**.

---

## 1. The Golden Rule: Fleet-Wide N52 Magnet Polarity Standard

If even one magnet is glued in backward, spare Armor Plates will **repel** instead of snap onto the drone during a tournament! Follow the **Osito Master Polarity Jig Protocol** on every single build:

```text
================================================================================
              OSITO KODIAK-75 MASTER MAGNET POLARITY STANDARD
================================================================================

   [ DRONE CHASSIS / HORNS / CRADLE / DECK ]        [ EPP FOAM BREAKAWAY Armor Plate ]
   ┌───────────────────────────────────────┐        ┌──────────────────────────┐
   │ TPU Socket (2.10mm x 1.20mm Deep)     │        │ TPU Cup in 6mm EPP Foam  │
   │                                       │        │                          │
   │     ┌───────────────────┐             │        │     ┌──────────────┐     │
   │     │ N52 2x1mm Magnet  │  (+0.20mm   │        │     │ N52 OR 0.15mm│     │
   │     │ NORTH FACING OUT  │   Recess)   │  ◄═══► │     │ SOUTH OUT    │     │
   │     │ (BLUE SHARPIE DOT)│             │  SNAP! │     │ (RED DOT)    │     │
   │     └───────────────────┘             │        │     └──────────────┘     │
   └───────────────────────────────────────┘        └──────────────────────────┘
================================================================================
```

### How to Use Your Master Polarity Tool (2-Ended Dowel Jig)
1. Take a $100\text{ mm}$ wooden dowel or 3D-printed wand (`6mm` diameter).
2. Glue one $2\text{ mm} \times 1\text{ mm}$ N52 magnet to the **BLUE end** of the wand with **SOUTH facing out** (label this end: **`DRONE FRAME INSTALLER`**).
3. Glue one $2\text{ mm} \times 1\text{ mm}$ N52 magnet to the **RED end** of the wand with **NORTH facing out** (label this end: **`FOAM Armor Plate INSTALLER`**).
4. **Installing Drone Frame Magnets (5x per drone: 1x Top Deck, 1x Left Horn, 1x Right Horn, 2x Belly Cradle):**
   * Stick a fresh N52 magnet onto the **`BLUE / DRONE FRAME INSTALLER`** tip of your wand.
   * Apply a micro-drop of flexible CA glue (or Starbond Black Medium CA) into the $2.10\text{ mm} \times 1.20\text{ mm}$ TPU socket on the drone.
   * Press the magnet straight in with the wand until it seats $0.20\text{ mm}$ below the TPU rim, then slide the wand sideways to release.
5. **Installing Breakaway Armor Plate Magnets (5x per Armor Plate set: 1x Crown, 1x L-Cheek, 1x R-Cheek, 2x Belly Skid):**
   * Stick a fresh N52 magnet onto the **`RED / FOAM Armor Plate INSTALLER`** tip of your wand.
   * Press it into the TPU Armor Plate cup with a micro-drop of CA glue and slide sideways to release.
   * *(Pro Shop Tip: If you use $0.15\text{ mm}$ ferromagnetic steel shims on the EPP foam Armor Plates instead of magnets, Armor Plates become 100% polarity-agnostic and can never repel!)*

---

## 2. Step-by-Step 3D Print & Sandwich Layup Checklist

### Step 2.1 — Main 75mm Guardless Frame (`KODIAK75_Frame_v1.stl`)
* **Filament:** CarbonX PC-CF or eSUN ePA-CF (dried at $70^\circ\text{C}$ for 6 hours).
* **Slicer Profile:** Load [`slicer/KODIAK75_PC-CF_Frame_OrcaProfile.json`](./slicer/KODIAK75_PC-CF_Frame_OrcaProfile.json) (5 walls, 40% gyroid infill, $0.16\text{ mm}$ layer height).
* **Post-Print Inspection:** Peel off the $3\text{ mm}$ outer brim. Ream the four $25.5\text{ mm} \times 25.5\text{ mm}$ FC holes with a $2.0\text{ mm}$ bit by hand and verify the $3.0\text{ mm}$ integrated thermal air-gap bosses are clean.

### Step 2.2 — Composite Standoff Horns (`KODIAK75_Horns_v1.stl`)
* **Slicer Profile:** Load [`slicer/KODIAK75_Horns_Sandwich_OrcaProfile.json`](./slicer/KODIAK75_Horns_Sandwich_OrcaProfile.json) ($0.20\text{ mm}$ layer height, 100% infill).
* **Multi-Layer Filament Swap Sequence:**
  1. **Layers 1–2 ($0.00\text{–}0.40\text{ mm}$):** Start print loaded with **TPU 95A** (creates the flexible bottom impact skin).
  2. **Layer 3 Pause ($Z = 0.60\text{ mm}$):** Unload TPU 95A and load **ePA-CF** (prints the stiff net-deflection core across Layers 3–10).
  3. **Layer 11 Pause ($Z = 2.20\text{ mm}$):** Unload ePA-CF and reload **TPU 95A** (prints the top shock-absorbing skin and the left/right cheek N52 magnet sockets).

### Step 2.3 — TPU Battery Cradle & Modular Upper Decks
* Print [`KODIAK75_550Cradle_v1.stl`](./cad/KODIAK75_550Cradle_v1.stl), [`KODIAK75_Deck_LOS_v1.stl`](./cad/KODIAK75_Deck_LOS_v1.stl), [`KODIAK75_Deck_FPV_v1.stl`](./cad/KODIAK75_Deck_FPV_v1.stl), and [`KODIAK75_ArmorPlates_v1.stl`](./cad/KODIAK75_ArmorPlates_v1.stl) using [`slicer/KODIAK75_TPU95A_Flex_OrcaProfile.json`](./slicer/KODIAK75_TPU95A_Flex_OrcaProfile.json).

---

## 3. Avionics Soldering & Mechanical Stackup Sequence

```text
================================================================================
                  KODIAK-75 VERTICAL M2 STACKUP ORDER
================================================================================
   [7] M2 Nylon Locknuts (4x) — Hand-tighten until silicone grommets compress 15%
    │
   [6] Modular Upper Deck (`Deck_LOS` OR `Deck_FPV` pod)
    │
   [5] BetaFPV Matrix 1S 5-in-1 AIO FC (G473, 3.9g — Flat Bottom PCB + Side SH1.0 USB-C Header)
    │   └── Seated inside 4x Silicone Soft-Mount Grommets (Pre-soldered BT2.0 Rearward)
   [4] Composite Net-Deflection Standoff Horns (`KODIAK75_Horns_v1`)
    │
   [3] 3.0mm Integral Thermal Air-Gap Standoffs (Part of `KODIAK75_Frame_Protected_v2`)
    │
   [2] Main 75mm PC-CF / ePA-CF Frame (`KODIAK75_Frame_Protected_v2`)
    │
   [1] Flush Under-Belly 1S 550mAh TPU Cradle (`KODIAK75_550Cradle_v1`)
    ▲
   [0] 4x M2 x 14mm Nylon Screws inserted from BOTTOM UP
================================================================================
```

### Wiring & Soldering Pinout (LOCKED: BetaFPV Matrix 1S `5-in-1` G473 Flight Controller)
1. **Pre-Soldered Battery Pigtail (`BT2.0` on `18/20AWG` Silicone Wire):**
   * The **BetaFPV Matrix 1S 5-in-1** ships with the `BT2.0` pigtail **already factory-soldered** to the rear `BAT+` and `GND` pads!
   * **Mandatory Strain Relief:** Loop a micro zip-tie around the rear 6 o'clock frame bridge and the `BT2.0` wire so yanking a battery pack during a 30-second pit stop pulls on the frame, **never** on the FC pads.
2. **External USB-C Dongle (`4-Pin SH1.0 Side Socket`):**
   * Because the Matrix 1S uses a **side-entry 4-pin `SH1.0` socket** for its plug-in USB-C adapter board, the bottom of the PCB is 100% flat—eliminating any risk of a metal USB port pressing into the `1S 550mAh LiHV` pouch cell underneath.
3. **Addressable RGB / COB LED Strip (100% Plug-and-Play Option OR 3-Pad Solder):**
   * **Zero-Solder Method (Recommended for Kids & Fast Builds):**
     * On the **Custom `OSITO-KODIAK-G473` PCB**: All **10 `WS2812B-2020` RGB LEDs are already factory-soldered directly onto the board** (`LED1`–`LED10`), and the `BT2.0` battery connector (`J_BAT`) is factory-mounted on the rear edge—**zero soldering anywhere on the drone!**
     * On the **COTS `BetaFPV Matrix 1S 5-in-1` (in Camera-Less LOS Mode)**: Plug a pre-wired `5V` COB LED strip with a **3-pin `JST-SH 1.0mm` connector** directly into the onboard 3-pin camera socket (`+5V` and `GND`)—**100% plug-and-play with zero soldering!**
   * **Optional 3-Pad Solder Method (Only if running COTS Matrix 1S + FPV Camera + External Addressable LEDs simultaneously):**
     * Solder the 3-wire harness to the dedicated **`5V`**, **`GND`**, and **`LED`** pads on the Matrix 1S `5-in-1` (`LEDs 0–3` = Front Green/White Nose; `LEDs 4–7` = Rear Team Red/Blue; `LEDs 8–9` = Top Dome).
4. **Plug-and-Play Brushless Motors (`1002` or `0803` `22,000KV`, `1.5mm` Shafts, `JST-1.25` 3-Pin Plugs):**
   * Mount each motor to the arm bosses using **3x `M1.4 x 3mm` screws**.
   * **Zero Motor Soldering Required:** Plug the 4 motor `JST-1.25` 3-pin connectors directly into the 4 corner motor sockets on the **BetaFPV Matrix 1S 5-in-1** (`M1` Rear-Right, `M2` Front-Right, `M3` Rear-Left, `M4` Front-Left).
   * Verify Props-Out direction (`M1` & `M4` = CW, `M2` & `M3` = CCW) in Betaflight Motors tab (`Bluejay 48kHz` Bidirectional DShot comes pre-flashed on the Matrix 1S!).
5. **Optional 60-Second Nano FPV Camera Swap (`3-Pin JST-SH` Header):**
   * To convert from `Deck_LOS` to `Deck_FPV`, simply plug the `BetaFPV C03` nano camera's 3-pin `JST-SH` plug (`5V`, `GND`, `CAM/VI`) into the onboard camera socket on the Matrix 1S `5-in-1` and snap the `U.FL` dipole antenna onto the VTX connector.

---

## 4. EPP Foam Armor Plate Fabrication (`cad/KODIAK75_EPP_Foam_Templates_1to1.svg`)

1. Print [`cad/KODIAK75_EPP_Foam_Templates_1to1.svg`](./cad/KODIAK75_EPP_Foam_Templates_1to1.svg) at **100% scale** on standard paper and verify the printed **50.0 mm calibration ruler** with calipers.
2. Tape the template onto a $6\text{ mm}$ sheet of $1.3\text{ PCF}$ ($20\text{ g/L}$) Expanded Polypropylene (EPP) foam (or load [`cad/KODIAK75_EPP_Foam_Templates_1to1.dxf`](./cad/KODIAK75_EPP_Foam_Templates_1to1.dxf) onto your CNC drag-knife / laser cutter).
3. Cut along the solid red lines and core out the $7.0\text{ mm}$ blue dashed circles to glue in the TPU magnet cups from [`KODIAK75_ArmorPlates_v1.stl`](./cad/KODIAK75_ArmorPlates_v1.stl) using Beacon Foam-Tac.
4. Weigh all four finished Armor Plates on a $0.01\text{g}$ pocket scale:
   * **Top Crown:** $\le 0.5\text{g}$
   * **Left & Right Cheek Shields:** $\le 0.5\text{g}$ each
   * **Belly Skid Plate:** $\le 0.6\text{g}$
   * **Total Armor Plate Set:** $\le 2.1\text{g}$ (well below the $3.5\text{g}$ / $10\%$ AUW stability ceiling).
