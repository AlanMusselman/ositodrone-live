// ============================================================================
// OSITO LILBEAR-65 & OSITO-FC29-F411-12A-HB: Parametric OpenSCAD Master Suite
// ============================================================================
// Parts generated via PART_SELECT:
//   "ALL"          - Complete assembled drone + FC + jigs preview
//   "FC_PCB"       - 29.0 x 29.0 x 7.6mm Flight Controller Mechanical Mockup
//   "FRAME_65"     - 65mm Wheelbase 6mm (0615) Brushed Motor Frame (1S 300mAh)
//   "CANOPY_FPV"   - AcrolilBear65-Replacement Micro FPV Camera Canopy (25.5x25.5)
//   "CANOPY_LOS"   - Lightweight Line-of-Sight & UART1/2/3 Expansion Canopy
//   "SMT_JIG"      - Double-Sided In-House SMT Stencil & Reflow Carrier Fixture
//   "POGO_JIG"     - Production Pogo-Pin SWD/DFU & H-Bridge ESC Test Fixture
// ============================================================================

PART_SELECT = "ALL";
PART_ID = 0; // 0=ALL, 1=FC_PCB, 2=FRAME_65, 3=CANOPY_FPV, 4=CANOPY_LOS, 5=SMT_JIG, 6=POGO_JIG
$fn = 64;

// --- Core Flight Controller Parameters (Exact User Spec) ---
fc_width        = 29.0;     // 29 x 29 mm outer envelope
fc_length       = 29.0;
fc_total_h      = 7.6;      // 7.6 mm total Z envelope (-3.0mm bottom to +4.6mm top)
fc_pcb_thick    = 1.0;      // 4-Layer 1.0mm FR4 TG170
fc_mount_span   = 25.5;     // 25.5 x 25.5 mm mounting pattern
fc_hole_d       = 2.1;      // M2 silicone grommet mounting hole

// --- 65mm Brushed Frame Parameters (AcrolilBear65 Replacement) ---
wheelbase       = 65.0;                     // 65mm motor-to-motor diagonal
motor_r         = wheelbase / 2.0;          // 32.5 mm radial distance
motor_xy        = motor_r * cos(45);        // 22.981 mm X/Y motor center
motor_id        = 6.10;                     // 6mm (0615) brushed motor slip-fit ID
motor_od        = 8.50;                     // Motor pod outer diameter
motor_pod_h     = 12.5;                     // Supports 15mm tall 0615 motor can
prop_d          = 31.0;                     // 31mm Whoop propeller
duct_id         = 32.6;                     // 32.6mm duct inner diameter
duct_od         = 35.0;                     // 35.0mm duct outer diameter
duct_h          = 7.5;                      // Aerodynamic prop shroud height

// --- 1S 300mAh LiHV Battery Bay Parameters ---
bat_w           = 11.8;                     // Standard 1S 300mAh width (11.2mm + clearance)
bat_h           = 6.8;                      // Standard 1S 300mAh thickness (6.4mm + clearance)
bat_l           = 42.0;                     // Battery cradle length

// ============================================================================
// 1. OSITO-FC29-F411-12A-HB FLIGHT CONTROLLER MECHANICAL MOCKUP (29x29x7.6mm)
// ============================================================================
module fc_pcb_mockup() {
    union() {
        difference() {
            union() {
                // 1.0mm 4-Layer PCB Substrate (Z = 0 to 1.0mm) with corner chamfers
                linear_extrude(height = fc_pcb_thick)
                    offset(r = 2.0) offset(delta = -2.0)
                        square([fc_width, fc_length], center = true);

                // Top Side Components (+Z from 1.0mm up to 4.6mm -> +3.6mm height)
                // U1: STM32F411CEU6 (UFQFPN-48 7x7x0.8mm rotated 45 deg)
                translate([0, 1.5, fc_pcb_thick])
                    rotate([0, 0, 45])
                        translate([-3.5, -3.5, 0]) cube([7.0, 7.0, 0.9]);

                // U2: Bosch BMI270 Gyro (2.5x3.0x0.8mm)
                translate([-1.25, -5.2 - 1.5, fc_pcb_thick])
                    cube([2.5, 3.0, 0.9]);

                // U3: Semtech SX1280 SPI ELRS 2.4GHz (4x4x0.9mm)
                translate([-2.0, 8.2 - 2.0, fc_pcb_thick])
                    cube([4.0, 4.0, 0.9]);

                // ANT1: 2.4GHz SMD Ceramic Antenna (Top Front, reaches +3.2mm above PCB)
                translate([-1.6, 12.2, fc_pcb_thick])
                    cube([3.2, 1.6, 3.2]);

                // U4: AT7456E Analog OSD (TSSOP-28)
                translate([-8.8, -4.5, fc_pcb_thick])
                    cube([4.4, 9.0, 1.1]);

                // Top H-Bridge MOSFETs Q1A, Q1B, Q2A, Q2B (SOIC-8 / DFN)
                for (yp = [-9.8, -4.5, 4.5, 9.8]) {
                    translate([6.2, yp - 2.4, fc_pcb_thick])
                        cube([4.0, 4.8, 1.2]);
                }

                // J1: USB Type-C Receptacle (Rear Edge, +3.6mm top profile)
                translate([-4.5, -14.2, fc_pcb_thick])
                    cube([9.0, 6.5, 3.6]);

                // J_CAM: 3-Pin JST-0.8 FPV Camera Header
                translate([-6.5, 11.5, fc_pcb_thick])
                    cube([4.5, 2.5, 2.2]);

                // 4x M2 Anti-Vibration Grommet Collars at 25.5 x 25.5mm (+3.6mm top)
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -1.0])
                        cylinder(d = 3.8, h = 5.6);
                }

                // Bottom Side Components (-Z from 0 down to -3.0mm -> Total H = 7.6mm)
                // 4x JST-1.25mm 2-Pin Brushed Motor Headers (M1..M4, -3.0mm bottom)
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 9.8 - 2.2, sy * 7.8 - 1.5, -3.0])
                        cube([4.4, 3.0, 3.0]);
                }

                // Bottom H-Bridge MOSFETs Q3A, Q3B, Q4A, Q4B & 4x EFM8BB21 ESC MCUs
                for (yp = [-9.8, -4.5, 4.5, 9.8]) {
                    translate([-10.2, yp - 2.4, -1.2])
                        cube([4.0, 4.8, 1.2]);
                }
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 5.5 - 1.5, sy * 6.5 - 1.5, -0.9])
                        cube([3.0, 3.0, 0.9]);
                }

                // U13 RTC6705 VTX + U10 TPS63020 5V Buck-Boost + C_BULK 220uF (-1.9mm)
                translate([-2.0, 4.2 - 2.0, -0.9]) cube([4.0, 4.0, 0.9]);
                translate([-1.5, -4.5 - 2.0, -1.0]) cube([3.0, 4.0, 1.0]);
                translate([3.0, -12.0, -1.9]) cube([3.5, 2.8, 1.9]);
            }

            // 4x 25.5 x 25.5mm Mounting Through-Holes (d = 2.1mm)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -5.0])
                    cylinder(d = fc_hole_d, h = 15.0);
            }
        }
    }
}

// ============================================================================
// 2. OSITO LILBEAR-65 65MM BRUSHED DRONE FRAME (6MM MOTORS, 1S 300MAH, 25.5x25.5)
// ============================================================================
module frame_65mm() {
    difference() {
        union() {
            // A. 4x 31mm Propeller Ducts at (+/-22.981, +/-22.981)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * motor_xy, sy * motor_xy, 0]) {
                    // Outer aerodynamic shroud wall
                    difference() {
                        cylinder(d = duct_od, h = duct_h);
                        translate([0, 0, -0.5])
                            cylinder(d = duct_id, h = duct_h + 1.0);
                    }
                    // Bottom lip reinforcement ring
                    difference() {
                        cylinder(d = duct_od + 0.8, h = 1.6);
                        translate([0, 0, -0.5])
                            cylinder(d = duct_id, h = 2.6);
                    }
                    // 6mm (0615) Brushed Motor Pod (Z = -3.0 to +9.5mm)
                    translate([0, 0, -3.0])
                        cylinder(d = motor_od, h = motor_pod_h);

                    // Motor Pod Bottom Shoulder Stop (retains motor from sliding down)
                    translate([0, 0, -3.0])
                        cylinder(d = motor_od, h = 1.2);

                    // 3x Radial Motor Struts connecting Motor Pod to Duct Wall
                    for (ang = [45 + (sx*sy > 0 ? 0 : 90), 165 + (sx*sy > 0 ? 0 : 90), 285 + (sx*sy > 0 ? 0 : 90)]) {
                        rotate([0, 0, ang])
                            translate([motor_id/2 - 0.2, -1.1, 0])
                                cube([(duct_id - motor_id)/2 + 0.6, 2.2, 2.2]);
                    }
                }
            }

            // B. Perimeter Inter-Duct Gusset Bridges (Forms Rigid Box Perimeter)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * motor_xy, -6.5, 0]) cylinder(d = 2.8, h = duct_h);
                    translate([sx * motor_xy,  6.5, 0]) cylinder(d = 2.8, h = duct_h);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-6.5, sy * motor_xy, 0]) cylinder(d = 2.8, h = duct_h);
                    translate([ 6.5, sy * motor_xy, 0]) cylinder(d = 2.8, h = duct_h);
                }
            }

            // C. Central X-Chassis Plate & 25.5 x 25.5mm FC Standoff Bosses
            for (sx = [-1, 1], sy = [-1, 1]) {
                // Diagonal Carbon-Style Arm Strut from Center to Motor Pod
                hull() {
                    translate([sx * 7.0, sy * 7.0, 0]) cylinder(d = 3.6, h = 2.4);
                    translate([sx * motor_xy, sy * motor_xy, 0]) cylinder(d = 4.2, h = 2.4);
                }
                // 25.5 x 25.5mm Flight Controller Mounting Posts
                hull() {
                    translate([sx * fc_mount_span/2, sy * fc_mount_span/2, 0])
                        cylinder(d = 5.2, h = 5.5);
                    translate([sx * 10.5, sy * 10.5, 0])
                        cylinder(d = 3.6, h = 2.4);
                }
                // Upper FC Alignment Pin Boss
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, 5.5])
                    cylinder(d = 3.8, h = 2.0);
            }

            // Central Perimeter Frame Ring (Leaves center open for JST-1.25 plugs & airflow)
            difference() {
                linear_extrude(height = 2.4)
                    offset(r = 2.0)
                        square([24.0, 24.0], center = true);
                translate([0, 0, -0.5])
                    linear_extrude(height = 3.4)
                        offset(r = 1.5)
                            square([18.5, 18.5], center = true);
            }

            // D. Under-Slung 1S 300mAh LiHV Battery Cradle & Landing Skids (Z = -8.2 to 0mm)
            translate([0, 0, -bat_h - 1.4]) {
                difference() {
                    // Outer Battery Tray + Twin Skid Rails
                    union() {
                        translate([-(bat_w + 3.2)/2, -bat_l/2, 0])
                            cube([bat_w + 3.2, bat_l, bat_h + 1.6]);
                        // Bottom Twin Landing Skid Runners
                        for (sx = [-1, 1]) {
                            translate([sx * (bat_w/2 + 0.8) - 1.0, -bat_l/2, -1.2])
                                cube([2.0, bat_l, 1.4]);
                        }
                    }
                    // Inner 1S 300mAh Battery Tunnel (11.8mm wide x 6.8mm tall)
                    translate([-bat_w/2, -bat_l/2 - 1.0, 1.4])
                        cube([bat_w, bat_l + 2.0, bat_h + 0.5]);
                    // Side Weight-Saving Grip Windows
                    for (yp = [-12, 0, 12]) {
                        translate([-(bat_w + 6)/2, yp - 3.5, 2.6])
                            cube([bat_w + 6, 7.0, bat_h - 2.0]);
                    }
                }
            }
        }

        // --- Subtractive Bores & Clearances ---
        // 1. 4x 6mm Brushed Motor Bores (d = 6.10mm) + Bottom Wire/Shaft Exit (d = 4.6mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 0]) {
                // Main 6.10mm motor body bore from Z = -1.8mm up to +12mm
                translate([0, 0, -1.8])
                    cylinder(d = motor_id, h = 15.0);
                // Bottom shaft & JST-1.25 wire exit hole through lower lip
                translate([0, 0, -4.0])
                    cylinder(d = 4.6, h = 4.0);
                // Outward flex relief slot for easy press-in motor swap
                rotate([0, 0, atan2(sy, sx)])
                    translate([0, -0.6, 0.5])
                        cube([6.0, 1.2, 10.0]);
            }
        }

        // 2. Ensure Duct Interiors are 100% Clear Above Struts (Z = 2.2mm to duct_h)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * motor_xy, sy * motor_xy, 2.2])
                difference() {
                    cylinder(d = duct_id, h = duct_h + 2.0);
                    translate([0, 0, -0.5])
                        cylinder(d = motor_od, h = duct_h + 3.0);
                }
        }

        // 3. 4x M2 Screw Bore Holes in 25.5 x 25.5mm FC Posts (d = 1.75mm self-tapping)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -1.0])
                cylinder(d = 1.75, h = 10.0);
        }
    }
}

// ============================================================================
// 3. ACROLILBEAR65-STYLE MICRO FPV CAMERA CANOPY (25.5x25.5mm MOUNT)
// ============================================================================
module canopy_fpv() {
    difference() {
        union() {
            // Aerodynamic Canopy Dome Shell
            difference() {
                hull() {
                    translate([0, 0, 0]) cylinder(d = 26.0, h = 1.5);
                    translate([0, 2.0, 9.0]) sphere(d = 17.0);
                    translate([0, 8.5, 6.5]) rotate([-15, 0, 0]) cylinder(d = 13.6, h = 4.0);
                }
                // Hollow interior clearing 29x29mm FC components
                hull() {
                    translate([0, 0, -0.5]) cylinder(d = 22.8, h = 1.5);
                    translate([0, 2.0, 8.6]) sphere(d = 13.8);
                    translate([0, 8.0, 6.2]) rotate([-15, 0, 0]) cylinder(d = 10.6, h = 4.5);
                }
                // Cut flat bottom at Z = 0
                translate([-30, -30, -20]) cube([60, 60, 20]);
            }

            // 4x 25.5 x 25.5mm Mounting Ears
            for (sx = [-1, 1], sy = [-1, 1]) {
                hull() {
                    translate([sx * fc_mount_span/2, sy * fc_mount_span/2, 0])
                        cylinder(d = 5.4, h = 2.0);
                    translate([sx * 9.0, sy * 9.0, 0])
                        cylinder(d = 4.0, h = 2.0);
                }
            }

            // Rear 5.8GHz Whip Dipole Antenna Guard Tube
            translate([0, -10.5, 4.0])
                rotate([25, 0, 0])
                    cylinder(d = 4.2, h = 10.0);
        }

        // 4x 25.5 x 25.5mm M2 Mounting Holes
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -1.0])
                cylinder(d = 2.2, h = 5.0);
        }

        // Front 15-Deg Uptilt Micro FPV Camera Lens Bore (d = 10.2mm)
        translate([0, 6.0, 6.0])
            rotate([-75, 0, 0])
                cylinder(d = 10.2, h = 12.0);

        // Side VTX & H-Bridge Cooling Louvers
        for (yp = [-3, 1.5]) {
            translate([-15, yp, 4.5])
                cube([30, 2.2, 5.0]);
        }

        // Antenna Tube Inner Bore
        translate([0, -10.5, 3.0])
            rotate([25, 0, 0])
                cylinder(d = 2.0, h = 14.0);
    }
}

// ============================================================================
// 4. LINE-OF-SIGHT (LOS) & UART1/2/3 EXPANSION CANOPY
// ============================================================================
module canopy_los() {
    difference() {
        union() {
            // Low-Profile Protective Roll Hoop Bridge over FC
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * fc_mount_span/2, -fc_mount_span/2, 0])
                        cylinder(d = 5.4, h = 2.0);
                    translate([sx * 7.5, 0, 7.0])
                        cylinder(d = 3.6, h = 2.0);
                }
                hull() {
                    translate([sx * fc_mount_span/2, fc_mount_span/2, 0])
                        cylinder(d = 5.4, h = 2.0);
                    translate([sx * 7.5, 0, 7.0])
                        cylinder(d = 3.6, h = 2.0);
                }
            }
            // Top Cross-Bridge with Forward Orientation Pointer Arrow (+Y)
            hull() {
                translate([-8.0, 0, 7.0]) cylinder(d = 3.8, h = 2.0);
                translate([ 8.0, 0, 7.0]) cylinder(d = 3.8, h = 2.0);
                translate([ 0.0, 9.5, 7.0]) cylinder(d = 2.4, h = 2.0);
            }
        }
        // 4x 25.5 x 25.5mm M2 Mounting Holes
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * fc_mount_span/2, sy * fc_mount_span/2, -1.0])
                cylinder(d = 2.2, h = 5.0);
        }
    }
}

// ============================================================================
// 5. IN-HOUSE DOUBLE-SIDED SMT STENCIL & REFLOW CARRIER JIG (FOR 29x29mm PCB)
// ============================================================================
module smt_stencil_jig() {
    // 55 x 55 x 9.0mm Bench Carrier:
    //   - Top Face: 29.25 x 29.25 x 1.0mm flush pocket + deep relief cavity for
    //               Bottom-Side Stencil Printing & 2nd-Pass Reflow!
    difference() {
        // Main Carrier Block with Corner Stencil Alignment Pin Holes
        translate([-27.5, -27.5, 0])
            cube([55.0, 55.0, 9.0]);

        // 29.25 x 29.25 x 1.0mm Flush PCB Seat Pocket on Top Face (Z = 8.0 to 9.0mm)
        translate([-14.625, -14.625, 8.0])
            cube([29.25, 29.25, 1.5]);

        // Corner Finger/Tweezers Pick-Out Reliefs
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 14.6, sy * 14.6, 6.5])
                cylinder(d = 5.0, h = 4.0);
        }

        // Deep Under-Board Component Relief Cavity (24.0 x 24.0 x 5.0mm, Z = 3.0 to 8.0mm)
        // Clears STM32F411, USB-C, SX1280, AT7456E, and Top FETs during Side-B paste/reflow!
        translate([-12.0, -12.0, 3.0])
            cube([24.0, 24.0, 5.5]);

        // USB-C Overhang Slot at Rear (-Y)
        translate([-6.0, -16.5, 3.0])
            cube([12.0, 5.0, 6.5]);

        // Central Thermal Airflow Vent
        translate([0, 0, -1.0])
            cylinder(d = 14.0, h = 6.0);

        // 4x Outer Stencil Registration Dowel Holes (d = 3.0mm)
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 22.0, sy * 22.0, -1.0])
                cylinder(d = 3.0, h = 12.0);
        }
    }
}

// ============================================================================
// 6. IN-HOUSE POGO-PIN SWD/DFU & H-BRIDGE ESC PRODUCTION TEST JIG
// ============================================================================
module pogo_test_jig() {
    difference() {
        union() {
            // Base Test Dock (44 x 44 x 12mm)
            translate([-22.0, -22.0, 0])
                cube([44.0, 44.0, 12.0]);

            // 4x 25.5 x 25.5mm PCB Guide Posts with Tapered Alignment Pins
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * fc_mount_span/2, sy * fc_mount_span/2, 12.0]) {
                    cylinder(d = 5.0, h = 4.5);
                    translate([0, 0, 4.5])
                        cylinder(d1 = 2.0, d2 = 1.5, h = 3.0);
                }
            }
        }

        // 6x Pogo-Pin Barrel Bore Holes (2.54mm pitch grid for SWDIO, SWCLK, BOOT0, NRST, 3V3, GND)
        for (i = [-2.5 : 1 : 2.5]) {
            translate([i * 2.54, -2.5, -1.0])
                cylinder(d = 1.40, h = 15.0);
        }

        // Bottom Wiring Channel for Pogo-Pin Harness
        translate([-12.0, -6.0, -0.5])
            cube([24.0, 8.0, 5.5]);
    }
}

// ============================================================================
// MASTER DISPATCHER
// ============================================================================
if (PART_ID == 1 || PART_SELECT == "FC_PCB") {
    fc_pcb_mockup();
} else if (PART_ID == 2 || PART_SELECT == "FRAME_65") {
    frame_65mm();
} else if (PART_ID == 3 || PART_SELECT == "CANOPY_FPV") {
    canopy_fpv();
} else if (PART_ID == 4 || PART_SELECT == "CANOPY_LOS") {
    canopy_los();
} else if (PART_ID == 5 || PART_SELECT == "SMT_JIG") {
    smt_stencil_jig();
} else if (PART_ID == 6 || PART_SELECT == "POGO_JIG") {
    pogo_test_jig();
} else {
    // Full Assembly Preview
    frame_65mm();
    translate([0, 0, 5.5]) fc_pcb_mockup();
    translate([0, 0, 7.5]) canopy_fpv();
}
