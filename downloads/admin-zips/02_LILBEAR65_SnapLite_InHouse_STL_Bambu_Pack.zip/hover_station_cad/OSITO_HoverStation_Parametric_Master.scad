// ============================================================================
// OSITO HOVER STATION (65mm 1S 300mAh Brushed ELRS Tabletop Training Rig) — REV 1.1 AUDITED
// Designed for OSITO LILBEAR-65 + OSITO-FC29-AT32-LITE-LOS ($5.84 2L FC)
// Remediated per Pre-Prototype Mechanical & CAD Verification Audit:
//   1. Shifted rod towers & bullseye to Y = -12.0mm and rear 4-slot 1S 300mAh caddy to Y = +38..+56mm
//      (>9.1mm physical clearance to 35.0mm front ducts at Y_max = +28.88mm).
//   2. Narrowed outrigger waist to 6.0mm (Y = +-3.0mm) through the X = +-22.981mm inter-duct corridor
//      and added 1.8mm elevated M2 standoff feet with d=4.0mm alignment boss pockets so outriggers
//      clear the Z=7.5mm frame ducts and inter-duct gusset bridges by >= 1.8mm vertically and 2.48mm radially.
//   3. Overlapped all CSG unions/subtractions by 0.2mm (zero coplanar faces) & added 1.5mm rod lead-in chamfers.
//   4. Shortened altitude target clip pointer flag to 10.0mm so it cannot contact ducts at any angle.
// ============================================================================

PART_ID = 1;
$fn = 64;

// --- Core Hover Station Geometry ---
rod_span        = 96.0;     // Center-to-center distance between twin vertical guide rods (X = -48mm, +48mm)
rod_d           = 4.20;     // Slip-fit socket for standard 4.0mm OD Carbon Fiber rod
rod_y           = -12.0;    // Forward-shifted rod/drone center for >9.1mm clearance to rear battery caddy
fc_mount_span   = 25.5;     // Standard Whoop 25.5 x 25.5mm M2 mounting pattern
fc_hole_d       = 2.2;      // M2 screw clearance

// ============================================================================
// PART 1: TABLETOP HOVER STATION BASE PAD + 4x 1S 300mAh BATTERY CADDY
// ============================================================================
module hover_station_base() {
    difference() {
        union() {
            // Main Octagonal Base Plate (156 x 132 x 8mm)
            hull() {
                for (sx = [-1, 1], sy = [-1, 1]) {
                    translate([sx * 64.0, sy * 52.0, 0])
                        cylinder(r = 14.0, h = 8.0);
                }
            }

            // Concentric Bullseye Landing Pad Raised Target Rings (Sunk 0.2mm into Z=7.8mm to eliminate coplanarity)
            translate([0, rod_y, 7.8]) {
                difference() {
                    cylinder(d = 76.0, h = 1.8);
                    translate([0, 0, -0.2]) cylinder(d = 68.0, h = 2.4);
                }
                difference() {
                    cylinder(d = 46.0, h = 1.8);
                    translate([0, 0, -0.2]) cylinder(d = 38.0, h = 2.4);
                }
                cylinder(d = 14.0, h = 1.8);
            }

            // Twin Reinforced Vertical Guide-Rod Towers at X = -48mm and X = +48mm, Y = -12.0mm
            for (sx = [-1, 1]) {
                translate([sx * (rod_span / 2.0), rod_y, 0]) {
                    cylinder(d1 = 22.0, d2 = 14.0, h = 26.0);
                    // 4x Gusset ribs
                    for (ang = [0, 90, 180, 270]) {
                        rotate([0, 0, ang])
                            translate([-1.5, 0, 0])
                                cube([3.0, 12.0, 18.0]);
                    }
                }
            }

            // Integrated 4-Slot 1S 300mAh LiHV Battery Holder Block at Rear (Y = +38.0 to +58.0mm)
            // Front ducts end at Y = -12.0 + 22.981 + 17.9 = +28.88mm -> 9.12mm clear gap!
            translate([-46.0, 38.0, 0])
                cube([92.0, 20.0, 22.0]);
        }

        // Twin 4.20mm Vertical Carbon Rod Sockets (22mm deep blind holes + 1.5mm top lead-in chamfer)
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), rod_y, 4.0])
                cylinder(d = rod_d, h = 23.0);
            translate([sx * (rod_span / 2.0), rod_y, 24.5])
                cylinder(d1 = rod_d, d2 = 5.8, h = 1.7);
        }

        // 4x Vertical Slots for 1S 300mAh LiHV Packs (12.4 x 7.4 x 18mm deep)
        for (i = [-1.5, -0.5, 0.5, 1.5]) {
            translate([i * 21.0 - 6.2, 42.3, 4.0])
                cube([12.4, 7.4, 20.0]);
        }

        // 4x Corner M4 Table-Clamp / Rubber-Foot Holes
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * 64.0, sy * 52.0, -1.0])
                cylinder(d = 4.5, h = 12.0);
        }
    }
}

// ============================================================================
// PART 2: DRONE HOVER-SLIDER COLLAR & LOS CANOPY (Mounts to 25.5x25.5mm FC)
// Remediated with:
//   - 1.8mm elevated M2 standoff feet + d=4.0mm bottom boss counterbores
//   - 6.0mm narrow outrigger waist through the X=+-22.981mm inter-duct corridor (2.48mm duct gap)
//   - Peaked gothic roll-arch (support-free printing)
// ============================================================================
module drone_slider_collar() {
    difference() {
        union() {
            // 4x Elevated M2 Standoff Posts at 25.5 x 25.5mm (Z = 0 to 4.4mm)
            for (sx = [-1, 1], sy = [-1, 1]) {
                translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), 0])
                    cylinder(d = 6.0, h = 4.4);
            }

            // Elevated Perimeter Frame connecting the 4 M2 FC posts (Z = 1.8 to 4.4mm, clearing frame bosses/gussets)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), -fc_mount_span / 2.0, 1.8]) cylinder(d = 4.2, h = 2.6);
                    translate([sx * (fc_mount_span / 2.0),  fc_mount_span / 2.0, 1.8]) cylinder(d = 4.2, h = 2.6);
                }
            }
            for (sy = [-1, 1]) {
                hull() {
                    translate([-fc_mount_span / 2.0, sy * (fc_mount_span / 2.0), 1.8]) cylinder(d = 4.2, h = 2.6);
                    translate([ fc_mount_span / 2.0, sy * (fc_mount_span / 2.0), 1.8]) cylinder(d = 4.2, h = 2.6);
                }
            }

            // Peaked Gothic Roll-Arch & Top Tether Loop over FC (100% support-free 40-deg overhang)
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), 0, 3.8]) cylinder(d = 3.8, h = 0.6);
                    translate([sx * 3.5, 0, 15.5]) cylinder(d = 4.0, h = 2.0);
                }
            }
            hull() {
                translate([-3.5, 0, 15.5]) cylinder(d = 4.0, h = 2.0);
                translate([ 3.5, 0, 15.5]) cylinder(d = 4.0, h = 2.0);
            }

            // Forward (+Y) High-Visibility Nose Pointer Arrow for Student Orientation (Z = 1.8 to 4.4mm)
            hull() {
                translate([-4.0, fc_mount_span / 2.0, 1.8]) cylinder(d = 2.4, h = 2.6);
                translate([ 4.0, fc_mount_span / 2.0, 1.8]) cylinder(d = 2.4, h = 2.6);
                translate([ 0.0, fc_mount_span / 2.0 + 9.0, 1.8]) cylinder(d = 2.0, h = 2.6);
            }

            // Twin Narrow-Waist Outrigger Arms (Z = 1.8 to 4.8mm)
            // Section 1: Narrow 6.0mm waist (Y = +-3.0mm) from X = +-12.75mm to X = +-36.0mm (clears 35mm ducts by 2.48mm!)
            // Section 2: Flare from X = +-36.0mm to the d=11.2mm bushing at X = +-48.0mm
            for (sx = [-1, 1]) {
                hull() {
                    translate([sx * (fc_mount_span / 2.0), -1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                    translate([sx * (fc_mount_span / 2.0),  1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                    translate([sx * 36.0, -1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                    translate([sx * 36.0,  1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                }
                hull() {
                    translate([sx * 36.0, -1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                    translate([sx * 36.0,  1.6, 1.8]) cylinder(d = 2.8, h = 3.0);
                    translate([sx * (rod_span / 2.0), 0, 1.8]) cylinder(d = 11.2, h = 3.0);
                }
                // Flared Bell-Mouth Linear Slider Bushing at X = +-48.0mm (Z = 0 to 10.0mm)
                translate([sx * (rod_span / 2.0), 0, 0])
                    cylinder(d = 11.2, h = 10.0);
            }
        }

        // 4x M2 Through-Holes + d=4.1mm x 1.3mm Bottom Alignment Boss Recess Pockets
        for (sx = [-1, 1], sy = [-1, 1]) {
            translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -1.0])
                cylinder(d = fc_hole_d, h = 8.0);
            translate([sx * (fc_mount_span / 2.0), sy * (fc_mount_span / 2.0), -0.2])
                cylinder(d = 4.1, h = 1.5);
        }

        // Twin Flared Bell-Mouth Guide Holes at X = +-48.0mm (Overlapped by 0.2mm to eliminate coplanar CSG faces)
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), 0, 0]) {
                translate([0, 0, -0.5]) cylinder(d = 6.8, h = 11.0);
                translate([0, 0, -0.2]) cylinder(d1 = 8.9, d2 = 6.8, h = 3.4);
                translate([0, 0,  6.8]) cylinder(d1 = 6.8, d2 = 8.9, h = 3.4);
            }
        }
    }
}

// ============================================================================
// PART 3: TOP SAFETY STOPPER BRIDGE (Caps the twin 4mm rods at X=+-48mm)
// ============================================================================
module top_stopper_bridge() {
    difference() {
        union() {
            hull() {
                for (sx = [-1, 1]) {
                    translate([sx * (rod_span / 2.0), 0, 0])
                        cylinder(d = 13.0, h = 6.0);
                }
            }
            for (sx = [-1, 1]) {
                translate([sx * (rod_span / 2.0), 0, 0])
                    cylinder(d = 13.0, h = 16.0);
            }
            // Central Tether Eye Loop
            translate([0, 0, 0])
                cylinder(d = 16.0, h = 6.0);
        }

        // Twin 4.20mm Press-Fit Rod Sockets (12mm deep + 1.5mm top lead-in chamfer)
        for (sx = [-1, 1]) {
            translate([sx * (rod_span / 2.0), 0, 4.0])
                cylinder(d = 4.20, h = 13.0);
            translate([sx * (rod_span / 2.0), 0, 14.5])
                cylinder(d1 = 4.20, d2 = 5.6, h = 1.7);
        }

        // Central 6mm Tether / Lanyard Hole
        translate([0, 0, -1.0])
            cylinder(d = 6.0, h = 9.0);
    }
}

// ============================================================================
// PART 4: 3x SNAP-ON ALTITUDE TARGET POINTER CLIPS (15cm / 25cm / 35cm Goals)
// Shortened 10.0mm pointer flag guarantees zero contact with 35mm ducts at any angle
// ============================================================================
module altitude_target_clips() {
    for (idx = [-1, 0, 1]) {
        translate([idx * 22.0, 0, 0]) {
            difference() {
                union() {
                    // C-Clip Body around 4mm rod
                    cylinder(d = 9.2, h = 8.0);
                    // 10.0mm Outward/Forward Target Pointer Flag
                    hull() {
                        translate([0, 3.0, 0]) cylinder(d = 5.0, h = 4.0);
                        translate([0, 10.0, 0]) cylinder(d = 2.2, h = 4.0);
                    }
                }
                // 4.05mm Snap Bore
                translate([0, 0, -1.0])
                    cylinder(d = 4.05, h = 10.0);
                // Side Snap-Opening Jaw (3.1mm gap)
                translate([-1.55, -6.0, -1.0])
                    cube([3.10, 6.0, 10.0]);
            }
        }
    }
}

if (PART_ID == 1) {
    hover_station_base();
} else if (PART_ID == 2) {
    drone_slider_collar();
} else if (PART_ID == 3) {
    top_stopper_bridge();
} else if (PART_ID == 4) {
    altitude_target_clips();
}
