# OSITO HOVER STATION: 3D-Printed Tabletop Vertical Guide-Rod & Gimbal Training Rig

**Designed For:** `OSITO LILBEAR-65` (65mm Brushed Frame) + [`OSITO-FC29-AT32-LITE-LOS`](../pcb_lite_los/OSITO_AT32_LITE_LOS_PRD_and_Schematic_Netlist.md) (`$5.84` 2-Layer 1S 300mAh ELRS Flight Controller)  
**CAD Directory:** [`Osito_lilBear65_InHouse/hover_station_cad/`](./)

---

## 1. How the Hover Station Works

At crowded school STEM fairs, birthday parties, and indoor booths, handing a first-time 7-year-old a free-flying drone risks immediate wall crashes or battery drain before they learn throttle sensitivity.

The **Osito Hover Station** solves this with a **Twin $4.0\text{ mm}$ Carbon-Rod Vertical Guide & Pitch/Roll Gimbal Rig**:
1. **Zero Center-PCB Interference:** Because the [`OSITO-FC29-AT32-LITE-LOS`](../pcb_lite_los/OSITO_AT32_LITE_LOS.kicad_pcb) flight controller and `1S 300mAh LiHV` battery occupy the center of the 65mm frame ($X=0, Y=0$), the [`OSITO_HoverStation_Drone_Slider_Collar.stl`](./OSITO_HoverStation_Drone_Slider_Collar.stl) bolts onto the standard $25.5 \times 25.5\text{ mm}$ M2 FC standoffs and extends **twin ultra-lightweight outrigger arms ($1.9\text{g}$) between the front and rear ducts** to $X = \pm 48.0\text{ mm}$ (clearing the $35.0\text{ mm}$ OD ducts by $7.5\text{ mm}$).
2. **Bell-Mouth Anti-Bind Gimbal Sleeves ($\pm 18^\circ$ Pitch/Roll Freedom):** Each outrigger ends in a $10\text{ mm}$ tall flared bell-mouth bushing ($6.8\text{ mm}$ waist bore, $8.8\text{ mm}$ top/bottom flares) riding on two vertical $4.0\text{ mm}$ OD carbon fiber rods ($350\text{–}500\text{ mm}$ tall).
   - **Cannot Yaw-Spin or Flip Over:** The twin rods lock yaw orientation toward the student and prevent full roll-overs.
   - **Active Gyro Stabilization Feel:** Because the flared bushings allow $\pm 18^\circ$ of Pitch and Roll tilt, the student still feels the `AT32F435` + `BMI270` PID loop actively leveling the drone while they master **Throttle Hover Control**!
3. **3-Mode Versatility (Twin-Rod Slider, Single-Rod Pivot, or Overhead Tether):**
   - **Mode A (Twin Guide Rods):** Pure vertical altitude & throttle training with $\pm 18^\circ$ pitch/roll feel.
   - **Mode B (Overhead Lanyard Tether):** Remove the drone collar outriggers and clip a lightweight braided nylon tether from the [`OSITO_HoverStation_Top_Stopper_Bridge.stl`](./OSITO_HoverStation_Top_Stopper_Bridge.stl) eye-loop to the top arch of the canopy for $360^\circ$ tethered hovering inside a $30\text{ cm}$ radius!
   - **Mode C (1S 300mAh Battery OR Continuous Bench Power):** Run untethered on the 4 charged `1S 300mAh LiHV` packs stored right in the base's rear caddy, **or** run an ultra-flexible $22\text{AWG}$ silicone pair from a $4.0\text{V}$ bench supply up to the `BT2.0` pigtail for non-stop 4-hour booth operation!

---

## 2. 3D-Printable STL Bill of Materials (`hover_station_cad/`)

All 4 STL files are compiled from [`OSITO_HoverStation_Parametric_Master.scad`](./OSITO_HoverStation_Parametric_Master.scad) via [`generate_hover_station_stls.ps1`](./generate_hover_station_stls.ps1):

| Part File | Material | Filament / Hardware Cost | Function |
| :--- | :--- | :---: | :--- |
| **[`OSITO_HoverStation_Base_Pad.stl`](./OSITO_HoverStation_Base_Pad.stl)** | **PLA+ / PETG** (3 walls, 20% gyroid) | `$1.10` (`~48g`) | $156 \times 120\text{ mm}$ octagonal bullseye landing pad, twin reinforced $4.2\text{ mm}$ carbon rod towers ($96.0\text{ mm}$ span), and integrated **4-Slot `1S 300mAh LiHV` Battery Caddy** |
| **[`OSITO_HoverStation_Drone_Slider_Collar.stl`](./OSITO_HoverStation_Drone_Slider_Collar.stl)** | **Tough PLA+ / PETG / PA-CF** (100% infill) | `$0.08` (`~2.4g`) | Bolts to $25.5 \times 25.5\text{ mm}$ M2 FC mounts; includes protective FC roll-arch, forward nose arrow, and twin $X = \pm 48\text{ mm}$ flared bell-mouth slider bushings |
| **[`OSITO_HoverStation_Top_Stopper_Bridge.stl`](./OSITO_HoverStation_Top_Stopper_Bridge.stl)** | **PETG / PLA+** (3 walls, 25% infill) | `$0.22` (`~9.5g`) | Press-fits onto the top of the two $4.0\text{ mm}$ rods so the drone can never fly off the top at 100% throttle; includes central $6\text{ mm}$ tether eye-loop |
| **[`OSITO_HoverStation_Altitude_Target_Clips.stl`](./OSITO_HoverStation_Altitude_Target_Clips.stl)** | **Neon Green / Orange PLA+ or TPU** | `$0.06` (`~2.5g`) | 3× snap-on altitude goal pointers (`15cm`, `25cm`, `35cm`) that clip onto the $4.0\text{ mm}$ rods for the *"10-Second Steady Hover Challenge"* |
| **2× $4.0\text{ mm} \times 450\text{ mm}$ Pultruded Carbon Fiber Rods** | COTS Carbon Rod (Amazon / McMaster) | `$1.50` / pair | Ultra-smooth, rigid vertical guide rails inserted into the Base Pad and capped by the Top Stopper Bridge |
| **TOTAL HOVER STATION RIG COST** | — | **`$2.96`** *(rig) + **`$21.29`** (drone w/ `$5.84` FC)* | **Complete Tabletop Hover Station + Drone for `$24.25` total!** |
