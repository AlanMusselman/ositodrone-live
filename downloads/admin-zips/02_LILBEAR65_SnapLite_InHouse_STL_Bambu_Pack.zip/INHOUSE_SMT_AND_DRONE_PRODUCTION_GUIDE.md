# OSITO LILBEAR-65 & OSITO-FC29-F411-12A-HB (REV 1.1): In-House SMT & Drone Production Manual

**Document ID:** `SOP-OSITO-LILBEAR65-001 (REV 1.1 Audited & Cleared)`  
**Scope:** End-to-end in-house manufacturing of the **`OSITO-FC29-F411-12A-HB REV 1.1`** ($29 \times 29 \times 7.6\text{ mm}$) Flight Controller from bare 4-layer PCBs, plus in-house 3D printing and final assembly of the **`OSITO LILBEAR-65`** (NewBeeDrone AcrolilBear65 replacement).

---

## 1. Bare PCB & Laser Stencil Ordering Specification (External Fab)

Order the **bare 4-layer PCB panel** and **framed/frameless stainless-steel solder paste stencil** from **Sierra Circuits (Sunnyvale, CA)**, **Bay Area Circuits (Fremont, CA)**, or **JLCPCB (`JLC04101H-7628`)**:
* **Dimensions:** $29.0 \times 29.0\text{ mm}$ single board, panelized as a **$2 \times 2$ array ($68 \times 68\text{ mm}$ with $5\text{ mm}$ rails, V-score or mouse-bites)** with $4\times \varnothing 1.0\text{ mm}$ optical fiducials on the panel rails and $\ge 0.30\text{ mm}$ ($12\text{ mil}$) copper-to-edge clearance on all perimeter pads.
* **Layers & Thickness:** **4 Layers**, **$1.0\text{ mm}$ finished thickness** ($\pm 10\%$).
* **Material & Stackup:** **FR4 TG170** high-$T_g$ substrate (`JLC04101H-7628` controlled impedance stackup).
* **Copper Weight:** **$2.0\text{ oz}$ Outer Layers (`L1 Top`, `L4 Bottom`)** (with zero traces routed between $0.50\text{ mm}$ pitch QFN pads) or **$1.0\text{ oz}$ Outer / $1.0\text{ oz}$ Inner** standard-etch option; $\varnothing 0.20\text{ mm}$ drill / $\varnothing 0.45\text{ mm}$ pad RF stitching vias ($5.0\text{ mil}$ annular ring).
* **Solder Mask & Surface Finish:** **Glossy Green or Glossy Black LPI Solder Mask** (mandatory to retain $\ge 3.15\text{ mil}$ mask dams between $0.50\text{ mm}$ pitch QFN pads) + **ENIG ($1\text{U"}$ Gold)** finish.
* **Laser Stencil:** **$0.12\text{ mm}$ ($120\,\mu\text{m}$) Electropolished Stainless Steel**, with **$2 \times 2$ window-paned apertures ($50\%\text{–}60\%$ area coverage)** on all exposed center thermal pads (`STM32F411`, `SX1280`, `EFM8BB21`, `TPS63020`, `RTC6705`, `RTC6659E`) to prevent QFN floating and mid-chip solder balling.

---

## 2. In-House Double-Sided SMT Assembly Workflow (130 Discrete Placements)

Print two copies of [`cad/OSITO_FC29_SMT_Stencil_Printer_Jig.stl`](./cad/OSITO_FC29_SMT_Stencil_Printer_Jig.stl) in high-temp **PC-CF or PETG-CF** for bench stencil printing.

### Phase 2A: Pass 1 — Bottom Layer (`L4`, 66 Placements) Stencil, Pick-and-Place & Reflow
We assemble the **Bottom Layer (`L4`) first** using **SAC305 ($96.5\text{Sn}/3.0\text{Ag}/0.5\text{Cu}$, Melting Point $217^\circ\text{C}$)** no-clean Type 4 solder paste:
1. **Stencil Print (`L4`):** Seat the bare $29 \times 29\text{ mm}$ PCB (Bottom side facing up) into the flush $1.0\text{ mm}$ top pocket of `OSITO_FC29_SMT_Stencil_Printer_Jig.stl`. Align the Bottom stencil apertures and draw a $45^\circ$ stainless squeegee across the board at $25\text{ mm/s}$.
2. **Pick-and-Place (`L4`):** Load [`pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv`](./pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv) (`Layer = Bottom`, 66 discrete placements) into your desktop PnP machine:
   * 4× `EFM8BB21F16G-C-QFN20` ESC MCUs (`U5–U8`) + 4× `100nF` decoupling caps (`C38–C41`)
   * 4× `AO4614B` Bottom H-Bridge MOSFETs (`Q3A, Q3B, Q4A, Q4B` at $180^\circ$) + 4× `BC847BS` Pre-Drivers (`Q_DRV1–4`) + 4× `BAT54S` Flyback Schottky Arrays (`D_M1–D_M4`) + Gate/Base resistors (`R17–R20`, `R25–R36`) + Motor snubber caps (`C34–C37`)
   * `TPS63020DSJR` 5V Buck-Boost (`U10`) + $1.5\,\mu\text{H}$ Inductor (`L_BB`) + Dual $22\,\mu\text{F}$ output bank (`C11A, C11B`) + $2.2\,\mu\text{H}$ LC Inductor (`L_LC`) + `C10, C12, C14, R3, R4, R5`
   * `RTC6705` VTX Synth (`U13` `QFN-40 6x6mm`), `RTC6659E` PA (`U14` `QFN-16 3x3mm`), `EFM8BB10` VTX MCU (`U15`), $8\text{ MHz}$ Crystal (`Y4`), `U.FL` (`J_VTX_ANT`)
   * $5\text{ m}\Omega$ `1206` Shunt (`R_SHUNT` `PA1206FRM470R005L`), `INA199A1` (`U9`), $220\,\mu\text{F}$ Polymer Cap (`C_BULK` — **verify `+` stripe matches silkscreen `+` mark!**), $100\,\mu\text{F}$ Tantalum (`C13` — **verify `+` stripe matches `+` mark!**), and 4× `JST-1.25` 2-Pin Vertical Motor Receptacles (`J_M1–J_M4`).
3. **Pass 1 Reflow Profile (SAC305):**
   * **Preheat:** $25^\circ\text{C} \rightarrow 150^\circ\text{C}$ @ $1.8^\circ\text{C/s}$
   * **Thermal Soak:** $150^\circ\text{C} \rightarrow 180^\circ\text{C}$ for $75\text{ seconds}$
   * **Reflow Peak:** $242^\circ\text{C}$ peak ($45\text{ seconds}$ Time Above Liquidus $217^\circ\text{C}$)
   * **Cooling:** $\le 3.0^\circ\text{C/s}$ natural forced-air cool down.

### Phase 2B: Pass 2 — Top Layer (`L1`, 64 Placements) Stencil, Pick-and-Place & Reflow
1. **Mount in Relief Pocket:** Flip the board over (Top side `L1` facing up) and seat it into `OSITO_FC29_SMT_Stencil_Printer_Jig.stl`. The $24 \times 24 \times 5.0\text{ mm}$ central relief cavity clears all Bottom-side components while supporting the PCB perimeter flush with the top surface.
2. **Stencil Print (`L1`):** Apply **SAC305 Type 4** solder paste across the Top stencil.
3. **Pick-and-Place (`L1`):** Run the `Layer = Top` job (64 discrete placements) from [`pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv`](./pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv):
   * `STM32F411CEU6` (`U1` at $45^\circ$) + `C1` ($2.2\,\mu\text{F}$ `VCAP1` on Pin 22) + `C2–C7` + `R12` ($10\text{k}$ `BOOT0`) + $8.000\text{ MHz}$ Crystal (`Y1`) + `C8, C9` ($15\text{ pF}$ load caps)
   * `Bosch BMI270` IMU (`U2`, Pin 5 `VDDIO` & Pin 8 `VDD`) + `LP5907MFX-3.3` Gyro LDO (`U12`) + `AP2112K-3.3` Digital LDO (`U11`) + `C15–C20`
   * `Semtech SX1280IMLTRT` (`U3`) + $52.000\text{ MHz}$ Crystal (`Y2` + `C26, C27`) + Single-Ended $50\,\Omega$ $\pi$-Match (`L1_RF` $1.5\text{ nH}$, `C23` $1.0\text{ pF}$, `C24` $1.5\text{ pF}$, `C25` $100\text{ pF}$) + Ceramic Antenna (`ANT1`) + `L_RF, C21, C22`
   * `AT7456E` OSD (`U4`) + $27.000\text{ MHz}$ Crystal (`Y3` + `C32, C33`) + Precision $75\,\Omega$ Video Resistors (`R8, R9`) + `C28–C31, R6, R7`
   * 4× `AO4614B` Top H-Bridge MOSFETs (`Q1A, Q1B, Q2A, Q2B` at $0^\circ$) + Top Gate Resistors (`R13–R16`, `R21–R24`)
   * 16-Pin `USB-C` (`J1`) + `R10, R11` ($5.1\text{ k}\Omega$ `CC1/CC2`) + `D1` (`USBLC6-2SC6`) + `D2` (`MBR0520LT1G` `VBUS` Schottky diode) + 3-Pin `JST-SH-1.0mm` Camera Header (`J_CAM`).
4. **Pass 2 Reflow (`BMI270` Safe Peak):** Keep peak temperature strictly between **$235^\circ\text{C}$ and $240^\circ\text{C}$** (never exceed $245^\circ\text{C}$ to protect the Bosch `BMI270` MEMS proof-mass calibration).
5. **Pigtail Soldering:** Hand-solder the $45\text{ mm}$ `20 AWG` **BT2.0 (or PH2.0) 1S battery pigtail** to `PAD_BAT+` and `PAD_BAT-` at $370^\circ\text{C}$ using a chisel tip.

---

## 3. In-House Firmware Provisioning (Pogo-Pin Test Jig)

Snap the reflowed board onto [`cad/OSITO_FC29_Pogo_Flashing_Test_Jig.stl`](./cad/OSITO_FC29_Pogo_Flashing_Test_Jig.stl):

1. **Step 1 — Two-Stage Current-Limited Smoke Test (Buck-Boost Inrush Safe):**
   * Pre-check resistance across `PAD_BAT+` to `PAD_BAT-` ($>10\text{ k}\Omega$) and `+5V_RAW` / `+3V3_DIG` to `GND` ($>5\text{ k}\Omega$).
   * Set bench supply to **$3.80\text{V}$ DC** with a **$350\text{ mA}$ current limit** (allows the $220\,\mu\text{F}$ polymer bulk cap and `TPS63020` $2\times 22\,\mu\text{F}$ output bank to charge without false current-limit foldback), then verify steady-state quiescent draw drops to **$85\text{–}115\text{ mA}$** (with VTX in Pit Mode).
   * Verify test points:
     * `TP_5V` = **$5.04\text{V} \pm 0.08\text{V}$** (`TPS63020` Buck-Boost)
     * `TP_3V3_DIG` = **$3.30\text{V} \pm 0.04\text{V}$** (`AP2112K-3.3`)
     * `TP_3V3_GYRO` = **$3.30\text{V} \pm 0.03\text{V}$** (`LP5907MFX-3.3`, ripple $<10\text{ mV}_{\text{p-p}}$)
     * `VCAP1 (C1)` = **$1.20\text{V} \pm 0.04\text{V}$** (`STM32F411` internal core regulator)
2. **Step 2 — Flash `STM32F411CEU6` via USB DFU (or SWD Pogo Pins):**
   * Hold `BOOT0` (or press the pogo-jig DFU toggle) and connect a USB-C cable (`R10/R11` $5.1\text{ k}\Omega$ resistors automatically negotiate $5\text{V}$ from USB-C hosts, and `D2` `MBR0520LT1G` powers the board safely).
   * Flash **Betaflight 4.5.x (`STM32F411` Unified Target)**.
   * Open the Betaflight CLI tab, paste the entire contents of [`firmware/OSITO_F411_BRUSHED_ELRS_Betaflight45_Target_and_CLI.txt`](./firmware/OSITO_F411_BRUSHED_ELRS_Betaflight45_Target_and_CLI.txt), and type `save`.
3. **Step 3 — Flash 4× `EFM8BB21` H-Bridge ESCs (`Bluejay v0.21 Brushed Bidirectional`):**
   * Flash initial bootloader via the bottom `C2CK / C2D` pogo pads using an Arduino/ST-Link C2 programmer, then configure over USB Pass-Through at https://esc-configurator.com/:
     * Firmware: **Bluejay v0.21 (`H-Bridge / Bidirectional Brushed 48kHz`)**
     * Direction: `M1 = Reversed`, `M2 = Normal`, `M3 = Normal`, `M4 = Reversed` (**Props-Out Whoop Standard**)
     * Confirm **Bidirectional / Turtle Mode (`DSHOT_CMD_SPIN_DIRECTION_REVERSED`)** is active.
4. **Step 4 — ExpressLRS 3.0+ Binding Verification:**
   * Confirm packet lock (`LQ = 100%`, `RSSI dBm >= -35 dBm` at $1\text{ m}$) with any ELRS 3.x 2.4GHz transmitter matching your fleet binding phrase.

---

## 4. In-House 3D Printing & Final `OSITO LILBEAR-65` Drone Assembly

### 4.1 Slicer Settings for 65mm Airframe & Canopies (`cad/`)
| STL File | Recommended Filament | Layer Height | Perimeters / Infill | Print Mass |
| :--- | :--- | :---: | :---: | :---: |
| [`OSITO_LILBEAR65_Frame_65mm_6mmBrushed.stl`](./cad/OSITO_LILBEAR65_Frame_65mm_6mmBrushed.stl) | **PA12-CF**, **Polypropylene (PP)**, or **Tough PLA+** | $0.16\text{ mm}$ | 3 Walls, 100% Solid Struts | **$3.8\text{ g}$** |
| [`OSITO_LILBEAR65_Canopy_FPV_MicroCam.stl`](./cad/OSITO_LILBEAR65_Canopy_FPV_MicroCam.stl) | **TPU 95A** (High-Vis Orange/Cyan) | $0.16\text{ mm}$ | 2 Walls, 35% Gyroid | **$1.3\text{ g}$** |
| [`OSITO_LILBEAR65_Canopy_LOS_Lite.stl`](./cad/OSITO_LILBEAR65_Canopy_LOS_Lite.stl) | **TPU 95A** or **PETG** | $0.16\text{ mm}$ | 3 Walls, 50% Infill | **$0.7\text{ g}$** |
| [`OSITO_FC29_SMT_Stencil_Printer_Jig.stl`](./cad/OSITO_FC29_SMT_Stencil_Printer_Jig.stl) | **PC-CF** or **PETG-CF** | $0.20\text{ mm}$ | 4 Walls, 40% Grid | $26\text{ g}$ (Tool) |
| [`OSITO_FC29_Pogo_Flashing_Test_Jig.stl`](./cad/OSITO_FC29_Pogo_Flashing_Test_Jig.stl) | **PETG** or **PLA+** | $0.20\text{ mm}$ | 4 Walls, 30% Grid | $22\text{ g}$ (Tool) |

### 4.2 5-Minute Final Drone Assembly Sequence
1. **Install 4× 6mm (`0615`) Brushed Motors:** Press four $6 \times 15\text{ mm}$ ($19,500\text{KV}$) brushed motors down into the $\varnothing 6.10\text{ mm}$ split-clamp motor pods until the cans seat against the bottom retention shoulder. Route the twisted wire leads inward along the diagonal struts.
2. **Mount the `OSITO-FC29-F411-12A-HB REV 1.1` Flight Controller:** Insert 4× M2 silicone anti-vibration grommets into the $25.5 \times 25.5\text{ mm}$ holes (`USB-C` facing Rear `-Y`, `ANT1` Ceramic ELRS antenna facing Front `+Y`) and press the FC onto the 4 frame standoffs.
3. **Plug in Motors & FPV Camera:** Plug the 4 motor `JST-1.25` connectors into `J_M1` (RR), `J_M2` (FR), `J_M3` (RL), and `J_M4` (FL) on the bottom of the FC. Plug the 1S Nano FPV Camera into the 3-pin `JST-SH-1.0mm` header (`J_CAM`) on top and snap the `5.8GHz` dipole whip antenna onto `J_VTX_ANT`.
4. **Install 31mm Props (Props-Out) & Canopy:** Press two CW ($M1, M4$) and two CCW ($M2, M3$) $31\text{ mm}$ 4-blade props onto the $1.0\text{ mm}$ motor shafts. Seat the camera inside `OSITO_LILBEAR65_Canopy_FPV_MicroCam.stl` and secure the canopy + FC with 4× $\text{M2} \times 6\text{ mm}$ nylon/steel screws.
5. **Final Turtle Mode & Hover QA Sign-Off:**
   * Insert a charged **1S 300mAh LiHV ($4.35\text{V}$)** pack into the bottom cradle.
   * Place the drone **upside-down** on a mat, activate **`AUX3` (Turtle Mode)**, arm (`AUX1`), and push the pitch stick forward: verify that the two front 6mm brushed motors spin in **reverse** and cleanly flip the drone right-side up!
   * Disarm, switch off `AUX3`, re-arm, and verify hands-off stable hover at **36–40% throttle** with crisp $0.0\text{ dB}$ OSD video on `Raceband 1 (5658 MHz)`.
