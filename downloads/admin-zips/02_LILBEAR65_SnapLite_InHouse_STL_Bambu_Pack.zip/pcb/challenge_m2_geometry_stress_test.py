#!/usr/bin/env python3
"""
OSITO LILBEAR65 REV 1.1 AIO FLIGHT CONTROLLER
Milestone 2 Layout & Geometry Empirical Challenger & Verification Suite
Author: teamwork_challenger (critic, specialist)
Interpreter: Python 3.12 64-bit

Empirical Challenge Objectives:
1. Parse all footprint definitions in OSITO_LILBEAR65_F411_12A_AIO.kicad_pcb:
   - Verify exactly 130 discrete SMD footprints are present.
   - Verify 4 NPTH mounting holes are present (134 total footprints).
2. Cross-check 100% of footprints against OSITO_F411_12A_AIO_CPL_PickAndPlace.csv:
   - Centroid X, Centroid Y, Rotation Angle, Layer.
3. Verify board outline bounding box on Edge.Cuts:
   - Must span exactly [-14.50, +14.50] mm in X and Y (29.0 x 29.0 mm).
   - Fillet radii (2.0 mm) and contour closure.
4. Verify mounting holes:
   - 4 NPTH holes of 2.1 mm diameter at (±12.75, ±12.75) mm.
5. Stress-test keepout clearances:
   - Verify no SMD footprint centroids or copper pads violate the 2.1 mm keepout radius.
   - Verify no PTH vias violate mounting hole keepout.
   - Verify component enclosure within board outline.
6. Cross-validate NC Drill and Gerber manufacturing deliverables.
"""

import sys
import os
import math
import re
import csv
import zipfile

# Set stdout/stderr encoding to utf-8 if supported
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

BASE_DIR = r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Osito_lilBear65_InHouse\pcb"
PCB_FILE = os.path.join(BASE_DIR, "OSITO_LILBEAR65_F411_12A_AIO.kicad_pcb")
CPL_FILE = os.path.join(BASE_DIR, "OSITO_F411_12A_AIO_CPL_PickAndPlace.csv")
BOM_FILE = os.path.join(BASE_DIR, "OSITO_F411_12A_AIO_BOM.csv")
GERBER_DIR = os.path.join(BASE_DIR, "gerbers")
NPTH_DRL = os.path.join(GERBER_DIR, "OSITO_LILBEAR65_F411_12A_AIO-NPTH.drl")
PTH_DRL = os.path.join(GERBER_DIR, "OSITO_LILBEAR65_F411_12A_AIO-PTH.drl")
EDGE_GERBER = os.path.join(GERBER_DIR, "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gm1")
ZIP_FILE = os.path.join(BASE_DIR, "OSITO_LILBEAR65_REV1.1_FAB_PACKAGE.zip")

PASS_COUNT = 0
FAIL_COUNT = 0
WARN_COUNT = 0
LOG_MESSAGES = []

def record_pass(desc, details=""):
    global PASS_COUNT
    PASS_COUNT += 1
    msg = f"  [PASS] {desc}"
    if details:
        msg += f" -> {details}"
    print(msg)
    LOG_MESSAGES.append(msg)

def record_fail(desc, details=""):
    global FAIL_COUNT
    FAIL_COUNT += 1
    msg = f"  [FAIL] {desc}"
    if details:
        msg += f" -> {details}"
    print(msg)
    LOG_MESSAGES.append(msg)

def record_warn(desc, details=""):
    global WARN_COUNT
    WARN_COUNT += 1
    msg = f"  [WARN] {desc}"
    if details:
        msg += f" -> {details}"
    print(msg)
    LOG_MESSAGES.append(msg)

# ==============================================================================
# S-EXPRESSION PARSER FOR KICAD PCB
# ==============================================================================
def parse_kicad_pcb(pcb_path):
    with open(pcb_path, "r", encoding="utf-8") as f:
        content = f.read()

    # Parse Edge.Cuts in document order
    lines = []
    edge_pattern = re.compile(
        r'\((gr_line|gr_arc)\s+(.*?)\(layer\s+"Edge\.Cuts"\)\)',
        re.DOTALL
    )
    for m in edge_pattern.finditer(content):
        etype = m.group(1)
        ebody = m.group(2)
        if etype == 'gr_line':
            coords = re.search(r'\(start\s+([-\d\.]+)\s+([-\d\.]+)\)\s+\(end\s+([-\d\.]+)\s+([-\d\.]+)\)', ebody)
            if coords:
                x1, y1, x2, y2 = map(float, coords.groups())
                lines.append(('line', (x1, y1), (x2, y2)))
        elif etype == 'gr_arc':
            coords = re.search(r'\(start\s+([-\d\.]+)\s+([-\d\.]+)\)\s+\(mid\s+([-\d\.]+)\s+([-\d\.]+)\)\s+\(end\s+([-\d\.]+)\s+([-\d\.]+)\)', ebody)
            if coords:
                x1, y1, xm, ym, x2, y2 = map(float, coords.groups())
                lines.append(('arc', (x1, y1), (xm, ym), (x2, y2)))

    # Parse vias
    vias = []
    via_pattern = re.compile(
        r'\(via\s+\(at\s+([-\d\.]+)\s+([-\d\.]+)\)\s+\(size\s+([-\d\.]+)\)\s+\(drill\s+([-\d\.]+)\)\s+\(layers\s+"([^"]+)"\s+"([^"]+)"\)\s+\(net\s+(\d+)\)\)',
        re.DOTALL
    )
    for m in via_pattern.finditer(content):
        vx, vy, vsize, vdrill, l1, l2, vnet = m.groups()
        vias.append({
            'x': float(vx),
            'y': float(vy),
            'size': float(vsize),
            'drill': float(vdrill),
            'layers': (l1, l2),
            'net': int(vnet)
        })

    # Footprint parsing via balanced parentheses
    footprints = []
    pos = 0
    while True:
        idx = content.find('(footprint ', pos)
        if idx == -1:
            break
        count = 0
        end_idx = idx
        for i in range(idx, len(content)):
            if content[i] == '(':
                count += 1
            elif content[i] == ')':
                count -= 1
                if count == 0:
                    end_idx = i + 1
                    break
        fp_block = content[idx:end_idx]
        pos = end_idx

        header_m = re.match(r'\(footprint\s+"([^"]+)"\s+\(layer\s+"([^"]+)"\)', fp_block)
        fp_name = header_m.group(1) if header_m else "UNKNOWN"
        fp_layer = header_m.group(2) if header_m else "UNKNOWN"

        at_m = re.search(r'\(at\s+([-\d\.]+)\s+([-\d\.]+)(?:\s+([-\d\.]+))?\)', fp_block)
        if at_m:
            at_x = float(at_m.group(1))
            at_y = float(at_m.group(2))
            at_rot = float(at_m.group(3)) if at_m.group(3) is not None else 0.0
        else:
            at_x, at_y, at_rot = 0.0, 0.0, 0.0

        ref_m = re.search(r'\(property\s+"Reference"\s+"([^"]+)"', fp_block)
        ref = ref_m.group(1) if ref_m else ""

        val_m = re.search(r'\(property\s+"Value"\s+"([^"]+)"', fp_block)
        val = val_m.group(1) if val_m else ""

        # Parse pads
        pads = []
        pad_matches = re.finditer(
            r'\(pad\s+"([^"]*)"\s+(\w+)\s+(\w+)\s+\(at\s+([-\d\.]+)\s+([-\d\.]+)(?:\s+([-\d\.]+))?\)\s+\(size\s+([-\d\.]+)\s+([-\d\.]+)\)(?:\s+\(drill\s+([-\d\.]+)\))?',
            fp_block
        )
        for pm in pad_matches:
            pad_num = pm.group(1)
            pad_type = pm.group(2)
            pad_shape = pm.group(3)
            px = float(pm.group(4))
            py = float(pm.group(5))
            prot = float(pm.group(6)) if pm.group(6) else 0.0
            pw = float(pm.group(7))
            ph = float(pm.group(8))
            pdrill = float(pm.group(9)) if pm.group(9) else 0.0
            pads.append({
                'num': pad_num,
                'type': pad_type,
                'shape': pad_shape,
                'x': px,
                'y': py,
                'rot': prot,
                'w': pw,
                'h': ph,
                'drill': pdrill
            })

        footprints.append({
            'name': fp_name,
            'layer': fp_layer,
            'x': at_x,
            'y': at_y,
            'rot': at_rot,
            'ref': ref,
            'val': val,
            'pads': pads
        })

    return content, lines, vias, footprints

# ==============================================================================
# MAIN TEST HARNESS
# ==============================================================================
def main():
    print("=" * 80)
    print("EMPIRICAL CHALLENGER VERIFICATION HARNESS - MILESTONE 2")
    print("Target: OSITO LILBEAR65 REV 1.1 AIO PCB LAYOUT & GEOMETRY")
    print("=" * 80)

    # --------------------------------------------------------------------------
    # TEST 1: PCB FILE SYNTAX & STRUCTURE INTEGRITY
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 1: PCB File Syntax & Structure ---")
    if not os.path.exists(PCB_FILE):
        record_fail("KiCad PCB file existence", f"Missing at {PCB_FILE}")
        return
    
    file_size = os.path.getsize(PCB_FILE)
    if file_size > 50000:
        record_pass("KiCad PCB file size check", f"{file_size:,} bytes")
    else:
        record_fail("KiCad PCB file size check", f"Suspiciously small: {file_size} bytes")

    content, edge_cuts, vias, footprints = parse_kicad_pcb(PCB_FILE)

    # Balanced parentheses check
    open_parens = content.count('(')
    close_parens = content.count(')')
    if open_parens == close_parens and open_parens > 1000:
        record_pass("S-Expression parenthesis balance", f"{open_parens:,} balanced pairs")
    else:
        record_fail("S-Expression parenthesis balance", f"Open: {open_parens}, Close: {close_parens}")

    # Version check
    if "(version 20221018)" in content:
        record_pass("KiCad file version", "KiCad v7/v8 format (version 20221018)")
    else:
        record_warn("KiCad file version", "Unrecognized version tag")

    # Stackup check
    layers = ["F.Cu", "In1.Cu", "In2.Cu", "B.Cu"]
    all_layers_present = all(l in content for l in layers)
    if all_layers_present:
        record_pass("4-Layer Copper Stackup definition", "F.Cu, In1.Cu, In2.Cu, B.Cu present")
    else:
        record_fail("4-Layer Copper Stackup definition", "One or more copper layers missing")

    # --------------------------------------------------------------------------
    # TEST 2: FOOTPRINT INVENTORY & TYPOLOGY AUDIT
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 2: Footprint Inventory & Typology Audit ---")
    total_fps = len(footprints)
    record_pass("Total footprint instances parsed", f"{total_fps} footprints found")

    mounting_holes = [fp for fp in footprints if fp['ref'].startswith('H') and any(p['type'] == 'np_thru_hole' for p in fp['pads'])]
    smd_footprints = [fp for fp in footprints if fp not in mounting_holes]

    # Verify exactly 4 mounting holes
    if len(mounting_holes) == 4:
        record_pass("NPTH mounting hole count", "Exactly 4 mounting holes (H1..H4)")
    else:
        record_fail("NPTH mounting hole count", f"Expected 4, found {len(mounting_holes)}")

    # Verify exactly 130 SMD footprints
    if len(smd_footprints) == 130:
        record_pass("Discrete SMD footprint count", "Exactly 130 discrete SMD footprints present")
    else:
        record_fail("Discrete SMD footprint count", f"Expected 130, found {len(smd_footprints)}")

    # Total footprint count = 134
    if total_fps == 134:
        record_pass("Total footprint count reconciliation", "130 SMD + 4 NPTH = 134 total")
    else:
        record_fail("Total footprint count reconciliation", f"Expected 134, found {total_fps}")

    # Layer distribution
    top_smd = [fp for fp in smd_footprints if fp['layer'] == 'F.Cu']
    bot_smd = [fp for fp in smd_footprints if fp['layer'] == 'B.Cu']
    if len(top_smd) == 66 and len(bot_smd) == 64:
        record_pass("SMD Layer distribution", f"Top: {len(top_smd)} footprints, Bottom: {len(bot_smd)} footprints")
    else:
        record_fail("SMD Layer distribution", f"Expected Top=66, Bot=64; got Top={len(top_smd)}, Bot={len(bot_smd)}")

    # Unique reference designators check
    smd_refs = [fp['ref'] for fp in smd_footprints]
    if len(smd_refs) == len(set(smd_refs)) == 130:
        record_pass("Reference designator uniqueness", "130 unique reference designators across SMD parts")
    else:
        record_fail("Reference designator uniqueness", f"Duplicates detected! Unique: {len(set(smd_refs))}")

    # Total SMD pad count
    total_smd_pads = sum(len(fp['pads']) for fp in smd_footprints)
    record_pass("Total SMD pad count", f"{total_smd_pads} pads synthesized across 130 components")

    # --------------------------------------------------------------------------
    # TEST 3: CPL PICK-AND-PLACE CROSS-RECONCILIATION
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 3: CPL Pick-and-Place Cross-Reconciliation ---")
    if not os.path.exists(CPL_FILE):
        record_fail("CPL PickAndPlace file existence", f"Missing at {CPL_FILE}")
        return

    cpl_rows = []
    with open(CPL_FILE, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get('Designator'):
                cpl_rows.append(row)

    if len(cpl_rows) == 130:
        record_pass("CPL row count check", "Exactly 130 component rows in CPL file")
    else:
        record_fail("CPL row count check", f"Expected 130 rows, found {len(cpl_rows)}")

    # Map footprints by reference
    pcb_fp_map = {fp['ref']: fp for fp in smd_footprints}

    max_delta_x = 0.0
    max_delta_y = 0.0
    max_delta_rot = 0.0
    mismatches = []

    for r in cpl_rows:
        ref = r['Designator'].strip()
        cpl_x = float(r['Mid X (mm)'])
        cpl_y = float(r['Mid Y (mm)'])
        cpl_rot = float(r['Rotation'])
        cpl_layer = r['Layer'].strip()

        if ref not in pcb_fp_map:
            mismatches.append(f"Missing footprint in PCB for CPL ref {ref}")
            continue

        fp = pcb_fp_map[ref]
        dx = abs(fp['x'] - cpl_x)
        dy = abs(fp['y'] - cpl_y)
        drot = abs((fp['rot'] - cpl_rot + 180) % 360 - 180)

        max_delta_x = max(max_delta_x, dx)
        max_delta_y = max(max_delta_y, dy)
        max_delta_rot = max(max_delta_rot, drot)

        expected_layer = "F.Cu" if cpl_layer == "Top" else "B.Cu"
        if fp['layer'] != expected_layer:
            mismatches.append(f"{ref}: layer mismatch PCB={fp['layer']} vs CPL={cpl_layer}")

        if dx > 0.001 or dy > 0.001 or drot > 0.01:
            mismatches.append(f"{ref}: coord mismatch PCB=({fp['x']},{fp['y']},{fp['rot']}) vs CPL=({cpl_x},{cpl_y},{cpl_rot})")

    if not mismatches:
        record_pass(
            "CPL 100% 1:1 Parity Verification",
            f"All 130 components match exactly! Max dX={max_delta_x:.6f}mm, Max dY={max_delta_y:.6f}mm, Max dRot={max_delta_rot:.6f} deg"
        )
    else:
        record_fail("CPL 1:1 Parity Verification", f"{len(mismatches)} discrepancies detected! First 3: {mismatches[:3]}")

    # --------------------------------------------------------------------------
    # TEST 4: BOARD OUTLINE GEOMETRY & EDGE.CUTS BOUNDING BOX
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 4: Board Outline Geometry & Edge.Cuts Bounding Box ---")
    record_pass("Edge.Cuts entity count", f"{len(edge_cuts)} elements (4 lines, 4 fillet arcs)")

    # Analyze lines and arcs
    pts = []
    min_x, max_x = float('inf'), float('-inf')
    min_y, max_y = float('inf'), float('-inf')

    for elem in edge_cuts:
        if elem[0] == 'line':
            _, (x1, y1), (x2, y2) = elem
            for x, y in [(x1, y1), (x2, y2)]:
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)
        elif elem[0] == 'arc':
            _, (x1, y1), (xm, ym), (x2, y2) = elem
            for x, y in [(x1, y1), (xm, ym), (x2, y2)]:
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)

    outline_span_x = max_x - min_x
    outline_span_y = max_y - min_y
    center_x = (max_x + min_x) / 2.0
    center_y = (max_y + min_y) / 2.0

    print(f"  Observed Edge.Cuts Bounding Box: X in [{min_x:.4f}, {max_x:.4f}], Y in [{min_y:.4f}, {max_y:.4f}]")
    print(f"  Observed Board Dimensions: {outline_span_x:.4f} x {outline_span_y:.4f} mm, Center: ({center_x:.4f}, {center_y:.4f})")

    # Contract requirement: span [-14.50, +14.50] in X and Y
    if abs(min_x - (-14.50)) < 0.001 and abs(max_x - 14.50) < 0.001:
        record_pass("X-axis outline span", f"[{min_x:.2f}, {max_x:.2f}] mm (Span: {outline_span_x:.2f} mm)")
    else:
        record_fail("X-axis outline span", f"Expected [-14.50, 14.50], got [{min_x}, {max_x}]")

    if abs(min_y - (-14.50)) < 0.001 and abs(max_y - 14.50) < 0.001:
        record_pass("Y-axis outline span", f"[{min_y:.2f}, {max_y:.2f}] mm (Span: {outline_span_y:.2f} mm)")
    else:
        record_fail("Y-axis outline span", f"Expected [-14.50, 14.50], got [{min_y}, {max_y}]")

    if abs(center_x) < 0.001 and abs(center_y) < 0.001:
        record_pass("Outline center point", f"Centered at origin ({center_x:.3f}, {center_y:.3f}) mm")
    else:
        record_fail("Outline center point", f"Origin offset: ({center_x}, {center_y})")

    # Verify contour connectivity
    chain_ok = True
    for i in range(len(edge_cuts)):
        curr_elem = edge_cuts[i]
        next_elem = edge_cuts[(i + 1) % len(edge_cuts)]
        end_curr = curr_elem[2] if curr_elem[0] == 'line' else curr_elem[3]
        start_next = next_elem[1]
        dist = math.dist(end_curr, start_next)
        if dist > 0.001:
            chain_ok = False
            record_fail("Edge.Cuts continuity", f"Gap between segment {i} and {i+1}: {dist:.4f} mm")
            break
    if chain_ok:
        record_pass("Edge.Cuts closed contour connectivity", "All 8 segments form a continuous watertight loop")

    # Verify Gerber Edge.Cuts file matches
    if os.path.exists(EDGE_GERBER):
        with open(EDGE_GERBER, "r", encoding="utf-8") as gf:
            gerber_txt = gf.read()
        g_x_matches = [float(m)/1000000.0 for m in re.findall(r'X([-\d]+)', gerber_txt)]
        g_y_matches = [float(m)/1000000.0 for m in re.findall(r'Y([-\d]+)', gerber_txt)]
        g_min_x, g_max_x = min(g_x_matches), max(g_x_matches)
        g_min_y, g_max_y = min(g_y_matches), max(g_y_matches)
        if abs(g_min_x - (-14.50)) < 0.001 and abs(g_max_x - 14.50) < 0.001 and abs(g_min_y - (-14.50)) < 0.001 and abs(g_max_y - 14.50) < 0.001:
            record_pass("RS-274X Gerber Edge.Cuts bounding box", f"[{g_min_x:.2f}, {g_max_x:.2f}] x [{g_min_y:.2f}, {g_max_y:.2f}] mm")
        else:
            record_fail("RS-274X Gerber Edge.Cuts bounding box", f"Gerber bounds [{g_min_x}, {g_max_x}] x [{g_min_y}, {g_max_y}]")

    # --------------------------------------------------------------------------
    # TEST 5: MOUNTING HOLES VERIFICATION
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 5: Mounting Holes Verification ---")
    expected_holes = {
        "H1": (12.75, 12.75),
        "H2": (-12.75, 12.75),
        "H3": (-12.75, -12.75),
        "H4": (12.75, -12.75)
    }

    hole_map = {h['ref']: h for h in mounting_holes}
    for href, (hx, hy) in expected_holes.items():
        if href in hole_map:
            h = hole_map[href]
            pos_err = math.dist((h['x'], h['y']), (hx, hy))
            drill_val = h['pads'][0]['drill'] if h['pads'] else 0.0
            pad_type = h['pads'][0]['type'] if h['pads'] else ""
            if pos_err < 0.001 and abs(drill_val - 2.10) < 0.001 and pad_type == 'np_thru_hole':
                record_pass(f"Mounting hole {href}", f"Coord ({h['x']:.2f}, {h['y']:.2f}) mm, Dia={drill_val:.2f} mm NPTH")
            else:
                record_fail(f"Mounting hole {href}", f"PosErr={pos_err}, drill={drill_val}, type={pad_type}")
        else:
            record_fail(f"Mounting hole {href}", "Designator not found in layout")

    # Hole Pitch Check
    pitch_x = abs(expected_holes['H1'][0] - expected_holes['H2'][0])
    pitch_y = abs(expected_holes['H1'][1] - expected_holes['H4'][1])
    diag_pitch = math.dist(expected_holes['H1'], expected_holes['H3'])
    if abs(pitch_x - 25.50) < 0.001 and abs(pitch_y - 25.50) < 0.001:
        record_pass("Mounting hole grid pattern", f"Pitch: {pitch_x:.2f} x {pitch_y:.2f} mm (Diagonal: {diag_pitch:.3f} mm)")
    else:
        record_fail("Mounting hole grid pattern", f"Pitch: {pitch_x} x {pitch_y} mm")

    # --------------------------------------------------------------------------
    # TEST 6: ADVERSARIAL MOUNTING HOLE KEEPOUT RADIUS STRESS-TEST
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 6: Mounting Hole Keepout Radius Stress-Test ---")
    # Requirement: No footprints violate the 2.1mm keepout radius around any mounting hole.
    # Hole centers: (±12.75, ±12.75) mm.
    # Keepout radius R_k = 2.10 mm.
    # Drill radius r_d = 1.05 mm.
    hole_centers = [
        (12.75, 12.75, "H1"),
        (-12.75, 12.75, "H2"),
        (-12.75, -12.75, "H3"),
        (12.75, -12.75, "H4")
    ]
    KEEPOUT_RADIUS = 2.10

    # 6.1 Footprint Centroid Level Keepout (Requirement: no footprint violates 2.1mm keepout)
    min_centroid_dist = float('inf')
    closest_fp_centroid = None
    closest_hole_for_centroid = None

    for fp in smd_footprints:
        for hx, hy, hname in hole_centers:
            d = math.hypot(fp['x'] - hx, fp['y'] - hy)
            if d < min_centroid_dist:
                min_centroid_dist = d
                closest_fp_centroid = fp
                closest_hole_for_centroid = hname

    centroid_margin = min_centroid_dist - KEEPOUT_RADIUS
    if centroid_margin > 0:
        record_pass(
            "Footprint Centroid Keepout Clearance",
            f"All 130 footprints clear! Closest: {closest_fp_centroid['ref']} to {closest_hole_for_centroid} at {min_centroid_dist:.3f} mm (Keepout Margin: +{centroid_margin:.3f} mm > 0)"
        )
    else:
        record_fail(
            "Footprint Centroid Keepout Clearance",
            f"VIOLATION: {closest_fp_centroid['ref']} inside keepout! Dist={min_centroid_dist:.3f} mm < {KEEPOUT_RADIUS:.2f} mm"
        )

    # 6.2 Electrical & Manufacturing DRC Clearance (Drill Wall to Copper Pad >= 0.25 mm)
    # Drill radius = 1.05 mm. Minimum required clearance for quickturn PCB fab is 0.25 mm (10 mil).
    min_drill_clearance = float('inf')
    closest_copper_info = None
    drc_violations = []

    # 6.3 Mechanical Hardware Clearance (Pad Corner to Hole Center vs 2.10 mm M2 Hardware Envelope)
    min_pad_dist = float('inf')
    closest_pad_info = None
    pad_hardware_encroachments = []

    for fp in smd_footprints:
        fp_rad = math.radians(fp['rot'])
        cos_f = math.cos(fp_rad)
        sin_f = math.sin(fp_rad)

        for p in fp['pads']:
            px_glob = fp['x'] + p['x'] * cos_f - p['y'] * sin_f
            py_glob = fp['y'] + p['x'] * sin_f + p['y'] * cos_f

            total_pad_rot = math.radians((fp['rot'] + p['rot']) % 360)
            cos_p = math.cos(total_pad_rot)
            sin_p = math.sin(total_pad_rot)
            hw = p['w'] / 2.0
            hh = p['h'] / 2.0

            corners = [
                (px_glob + dx * cos_p - dy * sin_p, py_glob + dx * sin_p + dy * cos_p)
                for dx, dy in [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
            ]

            for hx, hy, hname in hole_centers:
                d_corners = [math.hypot(cx - hx, cy - hy) for cx, cy in corners]
                d_min_corner = min(d_corners)
                clearance_to_drill_wall = d_min_corner - 1.050

                if clearance_to_drill_wall < min_drill_clearance:
                    min_drill_clearance = clearance_to_drill_wall
                    closest_copper_info = (fp['ref'], p['num'], hname, d_min_corner, clearance_to_drill_wall)

                if clearance_to_drill_wall < 0.250:
                    drc_violations.append((fp['ref'], p['num'], hname, clearance_to_drill_wall))

                if d_min_corner < KEEPOUT_RADIUS:
                    pad_hardware_encroachments.append((fp['ref'], p['num'], hname, d_min_corner, clearance_to_drill_wall))

    # Evaluate Manufacturing DRC Clearance
    if not drc_violations:
        record_pass(
            "Manufacturing NPTH Drill-to-Copper DRC Clearance",
            f"All pads satisfy 0.25mm DRC! Closest copper: {closest_copper_info[0]} pad {closest_copper_info[1]} to {closest_copper_info[2]} drill wall clearance = {min_drill_clearance:.3f} mm (> 0.25 mm min)"
        )
    else:
        record_fail(
            "Manufacturing NPTH Drill-to-Copper DRC Clearance",
            f"VIOLATIONS: {len(drc_violations)} pads violate 0.25mm copper-to-hole spacing! {drc_violations}"
        )

    # Evaluate Mechanical Hardware Encroachment
    if not pad_hardware_encroachments:
        record_pass(
            "Mechanical Hardware Pad Keepout (2.1mm radius)",
            "All copper pads lie strictly outside 2.1mm radius from hole centers"
        )
    else:
        record_warn(
            "Mechanical Hardware Pad Keepout Advisory",
            f"{len(pad_hardware_encroachments)} pads sit within 2.1mm radius (min pad dist: {closest_copper_info[3]:.3f} mm for {closest_copper_info[0]}.{closest_copper_info[1]}). Requires stepped rubber grommets or M2 nylon washers (max collar radius <= 1.30 mm)."
        )

    # 6.3 Via Keepout Stress-Test
    min_via_dist = float('inf')
    closest_via = None
    via_violations = []
    for v in vias:
        for hx, hy, hname in hole_centers:
            d = math.hypot(v['x'] - hx, v['y'] - hy)
            d_pad_edge = d - (v['size'] / 2.0)
            if d_pad_edge < min_via_dist:
                min_via_dist = d_pad_edge
                closest_via = (v, hname, d, d_pad_edge)
            if d_pad_edge < KEEPOUT_RADIUS:
                via_violations.append((v, hname, d))

    via_margin = min_via_dist - KEEPOUT_RADIUS
    if not via_violations:
        record_pass(
            "PTH Via Keepout Stress-Test",
            f"Closest via at ({closest_via[0]['x']:.2f}, {closest_via[0]['y']:.2f}) to {closest_via[1]}: Pad Edge Dist = {min_via_dist:.3f} mm (Margin: +{via_margin:.3f} mm)"
        )
    else:
        record_fail(
            "PTH Via Keepout Stress-Test",
            f"VIOLATION: Via penetrates keepout! {via_violations}"
        )

    # --------------------------------------------------------------------------
    # TEST 7: ADVERSARIAL SMT BOUNDARY ENCLOSURE STRESS-TEST
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 7: SMT Boundary Enclosure Stress-Test ---")
    # All component centroids and pad bounds must remain strictly inside the board outline [-14.50, +14.50]
    out_of_bounds = []
    min_edge_clearance = float('inf')
    closest_component_to_edge = None

    for fp in smd_footprints:
        # Distance to straight edges
        dx_edge = 14.50 - abs(fp['x'])
        dy_edge = 14.50 - abs(fp['y'])
        d_edge = min(dx_edge, dy_edge)

        if d_edge < min_edge_clearance:
            min_edge_clearance = d_edge
            closest_component_to_edge = (fp['ref'], fp['x'], fp['y'], d_edge)

        if abs(fp['x']) > 14.50 or abs(fp['y']) > 14.50:
            out_of_bounds.append((fp['ref'], fp['x'], fp['y']))

    if not out_of_bounds:
        record_pass(
            "Component Enclosure Stress-Test",
            f"All 130 components inside board boundary. Closest: {closest_component_to_edge[0]} at ({closest_component_to_edge[1]:.2f}, {closest_component_to_edge[2]:.2f}) mm, edge clearance={min_edge_clearance:.3f} mm"
        )
    else:
        record_fail("Component Enclosure Stress-Test", f"Components outside outline: {out_of_bounds}")

    # --------------------------------------------------------------------------
    # TEST 8: NC DRILL RECONCILIATION
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 8: NC Drill Deliverables Cross-Validation ---")
    if os.path.exists(NPTH_DRL):
        with open(NPTH_DRL, "r", encoding="utf-8") as f:
            npth_txt = f.read()

        # Check tool header
        if "T1C2.100" in npth_txt:
            record_pass("NPTH Tool definition", "Tool T1: C2.100 mm drill defined")
        else:
            record_fail("NPTH Tool definition", "Tool T1C2.100 missing in NPTH drill file")

        # Check coordinates in NPTH drill file
        drl_hits = re.findall(r'X([-\d\.]+)Y([-\d\.]+)', npth_txt)
        if len(drl_hits) == 4:
            parsed_drl_hits = set((float(x), float(y)) for x, y in drl_hits)
            expected_drl_hits = {(12.75, 12.75), (-12.75, 12.75), (-12.75, -12.75), (12.75, -12.75)}
            if parsed_drl_hits == expected_drl_hits:
                record_pass("NPTH Drill hole hit coordinates", "Exactly 4 hits at (±12.75, ±12.75) mm")
            else:
                record_fail("NPTH Drill hole hit coordinates", f"Hit mismatch: {parsed_drl_hits} vs {expected_drl_hits}")
        else:
            record_fail("NPTH Drill hole hit count", f"Expected 4 hits, found {len(drl_hits)}")
    else:
        record_fail("NPTH Drill file existence", f"Missing at {NPTH_DRL}")

    # --------------------------------------------------------------------------
    # TEST 9: FACTORY RELEASE ARCHIVE INTEGRITY
    # --------------------------------------------------------------------------
    print("\n--- TEST SECTION 9: Factory Release ZIP Archive Integrity ---")
    if os.path.exists(ZIP_FILE):
        try:
            with zipfile.ZipFile(ZIP_FILE, 'r') as zf:
                bad_file = zf.testzip()
                file_list = zf.namelist()
                if bad_file is None:
                    record_pass("ZIP CRC32 Checksum Validation", f"Archive is completely valid ({len(file_list)} files)")
                else:
                    record_fail("ZIP CRC32 Checksum Validation", f"Corrupted file in ZIP: {bad_file}")

                # Required files in ZIP
                required_in_zip = [
                    "OSITO_LILBEAR65_F411_12A_AIO-F_Cu.gtl",
                    "OSITO_LILBEAR65_F411_12A_AIO-In1_Cu.g2",
                    "OSITO_LILBEAR65_F411_12A_AIO-In2_Cu.g3",
                    "OSITO_LILBEAR65_F411_12A_AIO-B_Cu.gbl",
                    "OSITO_LILBEAR65_F411_12A_AIO-F_Mask.gts",
                    "OSITO_LILBEAR65_F411_12A_AIO-B_Mask.gbs",
                    "OSITO_LILBEAR65_F411_12A_AIO-F_Silkscreen.gto",
                    "OSITO_LILBEAR65_F411_12A_AIO-B_Silkscreen.gbo",
                    "OSITO_LILBEAR65_F411_12A_AIO-F_Paste.gtp",
                    "OSITO_LILBEAR65_F411_12A_AIO-B_Paste.gbp",
                    "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gm1",
                    "OSITO_LILBEAR65_F411_12A_AIO-PTH.drl",
                    "OSITO_LILBEAR65_F411_12A_AIO-NPTH.drl",
                    "OSITO_LILBEAR65_F411_12A_AIO-drl.rpt",
                    "README_FABRICATION_NOTES.txt",
                    "OSITO_F411_12A_AIO_BOM.csv",
                    "OSITO_F411_12A_AIO_CPL_PickAndPlace.csv"
                ]
                missing_in_zip = [f for f in required_in_zip if f not in file_list]
                if not missing_in_zip:
                    record_pass("ZIP Archive contents completeness", f"All {len(required_in_zip)} required manufacturing files present")
                else:
                    record_fail("ZIP Archive contents completeness", f"Missing in ZIP: {missing_in_zip}")
        except Exception as e:
            record_fail("ZIP Archive inspection", f"Exception: {e}")
    else:
        record_fail("ZIP Archive existence", f"Missing at {ZIP_FILE}")

    # ==============================================================================
    # FINAL VERDICT
    # ==============================================================================
    print("\n" + "=" * 80)
    print("EMPIRICAL CHALLENGER AUDIT SUMMARY")
    print(f"Total Tests Passed: {PASS_COUNT}")
    print(f"Total Warnings:     {WARN_COUNT}")
    print(f"Total Failures:     {FAIL_COUNT}")
    print("=" * 80)

    if FAIL_COUNT == 0:
        verdict = "APPROVE"
        print(f"\n>>> FINAL VERDICT: {verdict} <<<")
        print("All empirical geometry, layout, and manufacturing criteria are 100% satisfied.")
    else:
        verdict = "REQUEST_CHANGES"
        print(f"\n>>> FINAL VERDICT: {verdict} <<<")
        print(f"{FAIL_COUNT} test failures must be addressed prior to fabrication approval.")

    return verdict

if __name__ == "__main__":
    main()
