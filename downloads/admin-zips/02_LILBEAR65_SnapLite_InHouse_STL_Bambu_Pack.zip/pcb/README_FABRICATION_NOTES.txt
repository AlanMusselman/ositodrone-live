================================================================================
PCB MANUFACTURING FABRICATION NOTES & SPECIFICATIONS
Project: OSITO LILBEAR65 REV 1.1 AIO FLIGHT CONTROLLER
Target Board Model: OSITO-FC29-F411-12A-HB (REV 1.1)
Platform: 1S 65mm Brushed Whoop (AcrolilBear65 Architectural Drop-In Replacement)
Date of Release: October 29, 2026
Authorizing Authority: Teamwork Engineering & Fabrication Operations
================================================================================

1. GENERAL BOARD PARAMETERS:
--------------------------------------------------------------------------------
- Outer Dimensions      : 29.00 mm x 29.00 mm (+/- 0.10 mm)
- Corner Fillet Radius  : 2.00 mm symmetric corner radius on all 4 corners
- Mounting Hole Pattern : 25.50 mm x 25.50 mm square span centered at (0.0, 0.0) mm
- Mounting Hole Details : 4x Non-Plated Through Holes (NPTH), diameter 2.10 mm
                          Drill centers at (+/-12.75 mm, +/-12.75 mm)
                          Keepout zone: 4.20 mm diameter circular collar around each hole
- Total Board Thickness : 1.00 mm nominal (+/- 10% tolerance: 0.90 mm to 1.10 mm)
- Layer Count           : 4 Layers (Symmetric core & prepreg stackup)

2. 4-LAYER STACKUP PARAMETERS (JLCPCB JLC04101H-7628 / SIERRA CIRCUITS 4L QUICK-TURN):
--------------------------------------------------------------------------------
- Layer 1 (Top Copper)  : 2.0 oz Finished (70 um) [Option: 1.0 oz / 35 um finished]
                          Function: High-Speed Signals, 50-Ohm RF Microstrip, Top FETs
- Dielectric 1-2        : 0.200 mm (7.87 mil) 7628 Prepreg (Dielectric Er = 4.6 +/- 0.2)
- Layer 2 (Inner 1)     : 1.0 oz Copper (35 um)
                          Function: Unbroken Solid Ground (GND) Reference Plane
- Core Dielectric       : 0.460 mm (18.1 mil) FR4 TG170 Core (Dielectric Er = 4.6 +/- 0.2)
- Layer 3 (Inner 2)     : 1.0 oz Copper (35 um)
                          Function: Split Power Planes (VBAT_ESC, +5V_CLEAN, +3V3_DIG, +3V3_GYRO)
- Dielectric 3-4        : 0.200 mm (7.87 mil) 7628 Prepreg (Dielectric Er = 4.6 +/- 0.2)
- Layer 4 (Bottom Copper): 2.0 oz Finished (70 um) [Option: 1.0 oz / 35 um finished]
                          Function: Bottom ESC FETs, BEC, 5.8GHz VTX, Motor Connectors
- Laminate Material     : High-Tg FR4 (Glass transition temp Tg >= 170 deg C, Td >= 340 deg C)
                          Must withstand 2-pass lead-free reflow thermal shock (peak 242 deg C)

3. SURFACE FINISH & SOLDER MASK:
--------------------------------------------------------------------------------
- Surface Plating       : Chemical ENIG (Electroless Nickel Immersion Gold) per IPC-4552
                          Gold thickness: 1 - 2 micro-inches (0.025 - 0.05 um)
                          Nickel thickness: 120 - 240 micro-inches (3.0 - 6.0 um)
                          MANDATORY: Atom-flat coplanarity required for 0.50mm pitch QFNs/LGA-14.
                          HASL or Lead-Free HASL is STRICTLY PROHIBITED.
- Solder Mask Type      : High-Resolution Liquid Photoimageable (LPI) Solder Mask
- Solder Mask Color     : Glossy Green or Glossy Black (Both sides)
                          NOTE: Matte Black is prohibited (fails 3.15 mil web dam requirement).
- Minimum Solder Mask Dam: 0.080 mm (3.15 mil)
- Mask Expansion        : 0.050 mm (2.0 mil) per pad perimeter edge
- Silkscreen Legend     : High-Resolution White LPI, Double-Sided (Top & Bottom)
                          Minimum text line width: 0.12 mm (5.0 mil)

4. DESIGN RULE THRESHOLDS (DRC):
--------------------------------------------------------------------------------
- Minimum Outer Trace/Space : 5.0 mil / 5.0 mil (0.127 mm / 0.127 mm) on 2.0 oz Cu
- Minimum Inner Trace/Space : 4.0 mil / 4.0 mil (0.100 mm / 0.100 mm) on 1.0 oz Cu
- Minimum Mechanical Drill  : 0.30 mm (11.8 mil) standard / 0.20 mm (7.9 mil) RF stitching
- Minimum Annular Ring      : >= 5.0 mil (0.125 mm) on outer 2.0 oz layers
- Copper to Outline Clear   : >= 0.30 mm (12.0 mil) on all perimeter routing edges
- Copper to NPTH Clear      : >= 0.50 mm (20.0 mil) around mounting hole perimeters

5. CONTROLLED IMPEDANCE TRANSMISSION LINES:
--------------------------------------------------------------------------------
- Layer 1 RF Trace (ELRS 2.4GHz) : 50 Ohm +/- 10% Single-Ended Coplanar Waveguide with Ground (CPWG)
  * Trace Width (W)              : 0.340 mm (13.4 mil)
  * Ground Clearance Gap (S)     : 0.200 mm (7.87 mil)
  * Prepreg Height to L2 (h)     : 0.200 mm (7.87 mil) 7628 Prepreg (Er = 4.6)
  * Ground Shielding Vias        : 0.20 mm drill / 0.45 mm pad spaced <= 1.5 mm on both sides

6. LASER STENCIL & SMT SOLDER PASTE:
--------------------------------------------------------------------------------
- Laser Stencil Material: 0.120 mm (4.7 mil) electropolished stainless steel
- Thermal Center Pads   : Apply 2x2 window-paned stencil apertures with 50% to 60% area
                          coverage on all exposed center pads (U1 UFQFPN-48, U3 QFN-24,
                          U5-U8 QFN-20, U10 VSON-14, U13 QFN-40, U14 QFN-16, U15 QFN-20).

7. QUALITY ASSURANCE & TESTING:
--------------------------------------------------------------------------------
- Electrical Testing    : 100% Netlist Flying Probe Test per IPC-9252 Class 2
- Visual Inspection     : Automated Optical Inspection (AOI) per IPC-A-600 Class 2
- Cleanliness           : Ionic contamination <= 1.56 ug NaCl eq./cm^2 (IPC-TM-650 2.3.25)
- Packaging             : Vacuum sealed in moisture-barrier bags with desiccant and HIC card.

================================================================================
END OF FABRICATION NOTES
================================================================================
