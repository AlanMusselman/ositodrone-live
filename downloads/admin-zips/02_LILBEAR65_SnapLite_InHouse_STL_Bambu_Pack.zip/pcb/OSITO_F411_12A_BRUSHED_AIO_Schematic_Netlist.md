# OSITO-FC29-F411-12A-HB: Pin-to-Pin Electrical Schematic, Netlist & 4-Layer PCB Specification

**Board Revision:** `REV 1.1 (Audited, Remediated & Cleared for Fabrication)`  
**Dimensions:** $29.0 \times 29.0 \times 7.6\text{ mm}$ ($1.0\text{ mm}$ 4-Layer FR4 TG170, $2\text{ oz}$ Outer / $1\text{ oz}$ Inner Cu, Glossy Green/Black LPI Mask)  
**Mounting Holes:** $25.5 \times 25.5\text{ mm}$ ($\varnothing 2.1\text{ mm}$ NPTH with $\varnothing 4.2\text{ mm}$ silicone grommet keepout)

---

## 1. 4-Layer PCB Stackup, Impedance Control & DFM Rules (REV 1.1)

| Layer | Name | Copper Weight | Dielectric Thickness | Primary Routing & Plane Allocation |
| :---: | :--- | :---: | :---: | :--- |
| **L1 (Top)** | `TOP_SIGNAL_RF` | **$2.0\text{ oz}$ ($70\,\mu\text{m}$)** *(or $1.0\text{ oz}$ Option)* | — | `STM32F411CEU6`, `BMI270`, `SX1280` $50\,\Omega$ RF microstrip, `AT7456E` OSD, USB-C, Top H-Bridge FETs (`M1/M2`), UART1/2/3 Pads |
| **Prepreg** | `7628 Prepreg` | — | $0.20\text{ mm}$ ($\varepsilon_r = 4.6$) | High-isolation prepreg for $50\,\Omega$ RF trace reference to `L2_GND` |
| **L2 (Inner 1)** | `INNER_GND` | **$1.0\text{ oz}$ ($35\,\mu\text{m}$)** | — | **Unbroken Solid `GND` Reference Plane** under MCU, BMI270, SX1280, and RTC6705 |
| **Core** | `FR4 TG170 Core` | — | $0.46\text{ mm}$ ($\varepsilon_r = 4.6$) | Structural core |
| **L3 (Inner 2)** | `INNER_PWR` | **$1.0\text{ oz}$ ($35\,\mu\text{m}$)** | — | Split Power Planes: Heavy `VBAT_ESC` polygon (outer perimeter), `+5V_CLEAN` (video), `+3V3_DIG`, and `+3V3_GYRO` |
| **Prepreg** | `7628 Prepreg` | — | $0.20\text{ mm}$ ($\varepsilon_r = 4.6$) | Dielectric separation to Bottom layer |
| **L4 (Bottom)** | `BOT_ESC_VTX` | **$2.0\text{ oz}$ ($70\,\mu\text{m}$)** *(or $1.0\text{ oz}$ Option)* | — | 4× `EFM8BB21` ESC MCUs, Bottom H-Bridge FETs (`M3/M4`), `TPS63020` 5V Buck-Boost, `RTC6705` (`QFN-40`) + `RTC6659E` (`QFN-16`) VTX, 4× `JST-1.25` Motor Headers |

### Mandatory Fabrication & DFM Rules (Verified in Audit `OSITO-ENG-AUD-2026-001`)
1. **$50\,\Omega$ Coplanar Waveguide (L1 Referenced to L2 `GND`):** Trace width $W = 0.34\text{ mm}$, Ground gap $S = 0.20\text{ mm}$ with **$\varnothing 0.20\text{ mm}$ drill / $\varnothing 0.45\text{ mm}$ pad** stitching vias ($0.125\text{ mm} / 5.0\text{ mil}$ annular ring) every $1.5\text{ mm}$.
2. **Outer Layer $0.50\text{ mm}$ Pitch QFN Breakout:** Zero traces may route *between* adjacent $0.50\text{ mm}$ pitch QFN pads (`STM32F411`, `BMI270`, `SX1280`, `EFM8BB21`, `TPS63020`, `RTC6705`). All QFN pads break out directly outward or into offset vias to `L2/L3`.
3. **Solder Mask & Stencil Apertures:** Use **Glossy Green or Glossy Black LPI solder mask** (maintains $\ge 3.15\text{ mil}$ solder mask dams between $0.50\text{ mm}$ pitch pads). Apply **$2 \times 2$ window-paned stencil apertures ($50\%\text{–}60\%$ area coverage)** on all exposed QFN/UFQFPN/VSON thermal pads.
4. **Board Edge Clearance & IPC-2152 Polygon Pours:** Maintain $\ge 0.30\text{ mm}$ ($12\text{ mil}$) copper-to-edge clearance on all perimeter pads. All motor power paths use solid copper polygon pours ($\ge 1.02\text{ mm}$ per channel, $\ge 4.35\text{ mm}$ main `VBAT_ESC` bus, rated for $1.5\text{A}$ continuous hover / $4.0\text{A}$ per-channel punch-out / $16\text{A}$ total burst with $12\text{A}$-rated `AO4614B` silicon).

---

## 2. Subsystem Pin-to-Pin Schematics & Netlists (REV 1.1 Remediated)

### 2.1 Sheet 1: Power Conditioning, ADC Telemetry & USB Type-C (`VBAT`, `5.0V Buck-Boost + LC`, `3.3V Dual LDOs`)

```text
[PAD_BAT+] (1S 300mAh BT2.0+) ----+----> [R_SHUNT 5mOhm 1% 1W 1206 (Yageo PA1206FRM470R005L)] ----> Net: VBAT_ESC
                                  |
                                  +----> [C_BULK 220uF 6.3V Polymer CASE-B (Positive '+' Stripe to VBAT)] ----> GND
                                  |
                                  +----> [U9 INA199A1DCKR (50V/V)] ----> Net: ADC_CURR ----> STM32 Pin 19 (PB1 / ADC1_IN9)
                                  +----> [R1 10k 1% 0402] --+-- [R2 10k 1% 0402] --> GND
                                                            +--> Net: ADC_VBAT (2:1 Divider) ----> STM32 Pin 18 (PB0 / ADC1_IN8)

USB Type-C Power & Configuration (J1 TYPE-C-31-M-12 + D1 USBLC6-2SC6):
  - J1 Pin A5 (CC1)  ----> [R10 5.1k 1% 0402] ----> GND (Mandatory USB-C Sink Negotiation)
  - J1 Pin B5 (CC2)  ----> [R11 5.1k 1% 0402] ----> GND (Mandatory USB-C Sink Negotiation)
  - J1 VBUS (A4/B4)  ----> [D2 MBR0520LT1G SOD-123 Schottky Anode -> Cathode] ----> Net: +5V_RAW (Prevents VBAT Backfeed)
  - J1 D-/D+         ----> [D1 USBLC6-2SC6 ESD Array] ----> STM32 PA11 (USB_DM) / PA12 (USB_DP)

Net: VBAT_RAW ----> U10 (TPS63020DSJR Buck-Boost VSON-14):
  - Pins 6,7 (VIN)   : VBAT_RAW (Decoupled by C10 22uF 10V 0603 X5R)
  - Pin 5 (VINA)     : VBAT_RAW (via R5 10R 0402 + C14 100nF 0402 to GND)
  - Pins 3,4 (L1)    : Connected to L_BB (1.5uH 4.5A Shielded Inductor, 3x3mm) Pin 1
  - Pins 1,2 (L2)    : Connected to L_BB Pin 2
  - Pins 10,11 (VOUT): +5V_RAW (Set to 5.045V via FB divider R3=1.0M 1% / R4=110k 1% to Pin 12 FB)
  - Directly at VOUT : Dual Ceramic Output Bank [C11A 22uF 10V 0603 X5R] || [C11B 22uF 10V 0603 X5R] to PGND (Pins 13,14)
  - Pin 8 (EN), Pin 9 (PS/SYNC): Tied to VINA (Forced PWM low-ripple mode)

Active Video LC Pi-Filter:
  +5V_RAW ---+--- [L_LC 2.2uH 2A 2016] ---+---> Net: +5V_CLEAN (To AT7456E, RTC6705 VTX, Cam, UART 5V Pads)
             |                            |
     [C11A + C11B]                 [C12 22uF 0603] + [C13 100uF 10V Tantalum CASE-A ('+' Stripe to +5V_CLEAN)]
             |                            |
            GND                          GND

Dual Isolated 3.3V LDO Regulators:
  1. Digital & RF LDO (`U11 AP2112K-3.3TRG1` SOT-23-5, 600mA):
     - VIN (Pin 1), EN (Pin 3): +5V_RAW (Decoupled by C15 100nF 0402)
     - VOUT (Pin 5)           : +3V3_DIG (Decoupled by C16 1.0uF 0402; powers STM32F411CEU6 + SX1280 ELRS)
  2. Ultra-Low-Noise Gyro LDO (`U12 LP5907MFX-3.3/NOPB` SOT-23-5, 250mA, <10uVrms noise):
     - VIN (Pin 1), EN (Pin 3): +5V_CLEAN (Decoupled by C17 100nF 0402)
     - VOUT (Pin 5)           : +3V3_GYRO (Decoupled by C18 1.0uF 0402; powers Bosch BMI270 exclusively)

STM32F411CEU6 Core Stabilization, Reset & HSE Crystal Network:
  - Pin 22 (VCAP1)   ----> [C1 2.2uF 6.3V X5R 0402 (Samsung CL05A225MQ5NNNC)] ----> GND (Placed <1.5mm from Pin 22)
  - Pins 9,24,36,48  ----> [C2, C3, C4, C5 4x 100nF 16V X7R 0402] + [C6 4.7uF 10V X5R 0603] ----> GND
  - Pin 7 (NRST)     ----> [C7 100nF 16V X7R 0402] ----> GND + TP_NRST
  - Pin 44 (BOOT0)   ----> [R12 10k 1% 0402] ----> GND + TP_BOOT0
  - Pins 5,6 (PH0/1) ----> [Y1 8.000MHz ABM8-8.000MHZ-B2-T] + [C8 15pF 0402 C0G] & [C9 15pF 0402 C0G] ----> GND
```

---

### 2.2 Sheet 2: 4-Channel Bidirectional Brushed Full H-Bridge ESC (`AO4614B` + Anti-Shoot-Through & Flyback Protection)

Each of the 4 brushed motor channels (`M1` Rear-Right, `M2` Front-Right, `M3` Rear-Left, `M4` Front-Left) includes dedicated gate pull-up/pull-down resistors, NPN base current-limiting resistors, and fast Schottky flyback clamping diodes:

```text
                       VBAT_ESC (2.8V - 4.35V Heavy Polygon Pour)
                              |                         |
                   [R_PU_Ax 4.7k 0402]       [R_PU_Bx 4.7k 0402] (Pulls P-Gates HIGH to VBAT_ESC when OFF)
                              |                         |
                         +----+----+               +----+----+
                         | Source  |               | Source  |
     HIN_A (via Q_DRVx   | P-FET A |               | P-FET B |   HIN_B (via Q_DRVx
     + R_B 2.2k 0402) -->| AO4614B |               | AO4614B |<-- + R_B 2.2k 0402)
                         |  Drain  |               |  Drain  |
                         +----+----+               +----+----+
                              |                         |
                              +-----> [J_Mx Pin 1]      +-----> [J_Mx Pin 2]
                              |       (6mm Motor+)      |       (6mm Motor-)
                              |      [C34-C37 100nF 0402 Snubber Across Motor Terminals]
                              |      [D_Mx BAT54S Dual Schottky Flyback Clamping to VBAT_ESC / GND]
                         +----+----+               +----+----+
                         |  Drain  |               |  Drain  |
     LIN_A (N-Gate) ---->| N-FET A |               | N-FET B |<---- LIN_B (N-Gate)
                         | AO4614B |               | AO4614B |
                         | Source  |               | Source  |
                         +----+----+               +----+----+
                              |                         |
                   [R_PD_Ax 10k 0402]        [R_PD_Bx 10k 0402] (Pulls N-Gates LOW to GND during MCU boot)
                              |                         |
                             GND                       GND
```

| Channel | Betaflight Position | MCU DShot Pin | ESC MCU (`EFM8BB21`) | H-Bridge FET Pair | Gate R / Base R / Flyback | Motor Header (`JST-1.25`) |
| :---: | :--- | :---: | :---: | :---: | :--- | :---: |
| **Motor 1** | Rear Right (CW) | `PA0` (`TIM2_CH1`) | `U5` (`C38` $100\text{ nF}$) | `Q1A`, `Q1B` (`AO4614B`) | `R13/14` $4.7\text{k}$, `R21/22` $10\text{k}$, `R29/30` $2.2\text{k}$, `D_M1` `BAT54S` | `J_M1` (Bottom RR) |
| **Motor 2** | Front Right (CCW) | `PA1` (`TIM2_CH2`) | `U6` (`C39` $100\text{ nF}$) | `Q2A`, `Q2B` (`AO4614B`) | `R15/16` $4.7\text{k}$, `R23/24` $10\text{k}$, `R31/32` $2.2\text{k}$, `D_M2` `BAT54S` | `J_M2` (Bottom FR) |
| **Motor 3** | Rear Left (CCW) | `PB9` (`TIM4_CH4`) | `U7` (`C40` $100\text{ nF}$) | `Q3A`, `Q3B` (`AO4614B`) | `R17/18` $4.7\text{k}$, `R25/26` $10\text{k}$, `R33/34` $2.2\text{k}$, `D_M3` `BAT54S` | `J_M3` (Bottom RL) |
| **Motor 4** | Front Left (CW) | `PB8` (`TIM4_CH3`) | `U8` (`C41` $100\text{ nF}$) | `Q4A`, `Q4B` (`AO4614B`) | `R19/20` $4.7\text{k}$, `R27/28` $10\text{k}$, `R35/36` $2.2\text{k}$, `D_M4` `BAT54S` | `J_M4` (Bottom FL) |

---

### 2.3 Sheet 3: Bosch BMI270 IMU (`SPI1`) & SPI ExpressLRS 2.4GHz (`SPI3`, ELRS 3.0+)

#### Bosch BMI270 (`U2`, LGA-14 $2.5 \times 3.0\text{ mm}$ — Verified to Datasheet `BST-BMI270-DS000-01` §7.1)
* **`Pin 8 (VDD)` & `Pin 5 (VDDIO)`:** Connected to isolated `+3V3_GYRO` (`LP5907MFX-3.3`) with `C19` ($100\text{ nF}$ `0402` on Pin 8) and `C20` ($100\text{ nF}$ `0402` on Pin 5) placed within $0.8\text{ mm}$ of package.
* **`Pin 2 (ASDx)` & `Pin 3 (ASCx)`:** Left **Floating (`NC`)** (Auxiliary I2C unused).
* **`Pin 6 (GNDIO)` & `Pin 7 (GND)`:** Connected to solid `GND` plane.
* **`Pin 12 (CSB)`** $\rightarrow$ `PA4` (`GYRO_CS`)
* **`Pin 13 (SCx)`** $\rightarrow$ `PA5` (`SPI1_SCK`)
* **`Pin 1 (SDO)`** $\rightarrow$ `PA6` (`SPI1_MISO`)
* **`Pin 14 (SDx)`** $\rightarrow$ `PA7` (`SPI1_MOSI`)
* **`Pin 4 (INT1)`** $\rightarrow$ **`PC14` (`GYRO_EXTI` / `EXTI14` hardware interrupt)**

#### Semtech SX1280IMLTRT SPI ELRS 2.4GHz (`U3`, QFN-24 $4 \times 4\text{ mm}$ — Verified to Datasheet `DS.SX1280-1.W.APP`)
* **Frequency Reference:** `Y2` = **$52.000\text{ MHz}$ $\pm 10\text{ ppm}$ SMD Crystal (`NX2016SA-52.000M`)** on `XTA` (Pin 17) / `XTB` (Pin 18) with load capacitors `C26` ($10\text{ pF}$ `0402` C0G) and `C27` ($10\text{ pF}$ `0402` C0G).
* **Single-Ended $50\,\Omega$ RF $\pi$-Matching Network (Pin 22 `RFIO`):**
  * **Pins 20 & 21 (`GND`):** Connected directly to solid `L2_GND` plane via thermal/RF vias.
  * **Pin 22 (`RFIO`):** Routed through Semtech's single-ended $50\,\Omega$ $\pi$-matching network:
    $$\text{Pin 22 (RFIO)} \xrightarrow{\text{Shunt } C_{23}=1.0\text{ pF}} \text{Series } L_{1\text{RF}}=1.5\text{ nH (`LQG15HS1N5S02D`)} \xrightarrow{\text{Shunt } C_{24}=1.5\text{ pF}} \text{Series } C_{25}=100\text{ pF DC Block} \rightarrow \text{ANT1 / J\_ANT\_ELRS}$$
* **DC-DC Mode & Decoupling:** `Pin 2 (DCC_SW)` $\rightarrow$ `L_RF` ($15\,\mu\text{H}$ `0603` `LQM18PN150MFR`) $\rightarrow$ `Pin 1 (VDD_IN)` + `C21` ($470\text{ nF}$ `0402`) and `C22` ($100\text{ nF}$ `0402`).

---

### 2.4 Sheet 4: AT7456E Analog OSD (`SPI2`) & 25–200mW 5.8GHz VTX (`RTC6705 QFN-40 + RTC6659E QFN-16`)

* **Camera Connector (`J_CAM`):** 3-Pin **`JST-SH-1.0mm` (`BM03B-SRSS-TB`)** + Parallel Solder Pads (`PAD_CAM_5V`, `PAD_CAM_GND`, `PAD_CAM_VIN`):
  * `PAD_CAM_VIN` $\rightarrow$ **`R8` ($75\,\Omega \pm 1\%$ `0402`)** termination to `GND` + **`C30` ($100\text{ nF}$ `0402`)** AC-coupling capacitor $\rightarrow$ `U4 AT7456E Pin 22 (VIN)`.
* **OSD Overlay (`U4 AT7456E` TSSOP-28):**
  * Powered by `+5V_CLEAN` via `R6` ($10\,\Omega$) + `C28` ($100\text{ nF}$) on `AVDD` and `R7` ($10\,\Omega$) + `C29` ($100\text{ nF}$) on `DVDD`.
  * Clocked by `Y3` = $27.000\text{ MHz}$ crystal (`CLKIN` Pin 16 / `CLKOUT` Pin 17) with `C32, C33` ($2 \times 18\text{ pF}$ `0402` C0G).
  * **Matched $75\,\Omega$ CVBS Video Output:** `U4 Pin 26 (VOUT)` $\rightarrow$ **`R9` ($75\,\Omega \pm 1\%$ `0402`, Yageo `RC0402FR-0775RL`)** + **`C31` ($22\,\mu\text{F}$ `0603` X5R)** AC-coupling $\rightarrow$ **`U13 RTC6705 Pin 6 (`VIDEO_IN`)** ($0.0\text{ dB}$ insertion loss, $1.00\text{V}_{\text{p-p}}$ into internal $75\,\Omega$ VTX termination).
* **5.8GHz 25–200mW VTX (`U13 RTC6705` QFN-40 $6 \times 6\text{ mm}$ + `U14 RTC6659E` QFN-16 $3 \times 3\text{ mm}$ + `U15 EFM8BB10F8G` QFN-20):**
  * `U15` receives **SmartAudio v2.1** on `VTX_SA` (connected via `JP1` to `PA2 / UART2_TX` by default, or `PB2 / UART3_TX`) and drives `RTC6705` (`QFN-40`) + `RTC6659E` (`QFN-16` PA) across Pit Mode / $25\text{ mW}$ / $100\text{ mW}$ / $200\text{ mW}$ to `J_VTX_ANT` (`U.FL`).
