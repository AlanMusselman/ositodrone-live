#!/usr/bin/env python3
"""
EMPIRICAL CHALLENGER VERIFICATION HARNESS - MILESTONE 2
Osito lilBear65 AIO Flight Controller (OSITO-FC29-F411-12A-HB REV 1.1)

Rigorous Adversarial Empirical Audit:
1. Gerber RS-274X Syntax & Aperture Reference Integrity (12 layers)
   - Verifies %FSLAX46Y46*%, %MOMM*%, %LPD*%, EOF M02*
   - Verifies all D-code aperture references (D10, D11, ...) are explicitly defined in %ADD...*%
   - Verifies bounding box coordinates strictly conform to the 29.0 x 29.0 mm physical outline envelope
2. Board Outline (Edge_Cuts) Parity (.gm1 and .gko)
   - Verifies identical byte parity across both extensions for universal CAM compatibility
   - Verifies 29.0 x 29.0 mm envelope with 2.0 mm corner fillets
3. Excellon NC Drill Verification (PTH vs NPTH)
   - Verifies M48 header, METRIC, %, and M30 EOF
   - Verifies all tool selections (T1, T2) are pre-defined via T<n>C<dia>
   - Verifies complete separation between plated through-holes (23 vias) and non-plated mounting holes (4 holes)
   - Verifies exact coordinates of 4x NPTH 2.1mm mounting holes at (±12.750, ±12.750) mm
   - Verifies drill report (-drl.rpt) tooling table and hit counts
4. Factory Fabrication Archive (OSITO_LILBEAR65_REV1.1_FAB_PACKAGE.zip) Audit
   - Verifies archive integrity with testzip() (CRC32)
   - Verifies exact 18-file manifest (no missing, no extraneous, no macOS artifacts)
   - Performs byte-for-byte SHA256 and CRC32 parity comparison against raw disk files
5. Manufacturing Fabrication Notes (README_FABRICATION_NOTES.txt) Audit
   - Verifies all fabrication parameters: 29x29mm, 25.5mm pattern, 4 layers, JLC04101H-7628 stackup,
     ENIG finish, 5/5 mil DRC, 0.3mm min drill, 50-Ohm CPWG impedance.
6. KiCad PCB Layout (OSITO_LILBEAR65_F411_12A_AIO.kicad_pcb) Cross-Reconciliation
   - Verifies S-expression parenthesis balance
   - Verifies 130 SMT footprints matching CPL centroids, rotations, and layer assignments
   - Verifies 4 NPTH mounting hole footprints at (±12.75, ±12.75) mm
"""

import sys
import os
import re
import csv
import math
import tempfile
import zipfile
import hashlib
import zlib
from pathlib import Path

# Paths
BASE_DIR = Path(r"c:\Users\Alan Musselman\OneDrive\Documents\Osito drone\Osito_lilBear65_InHouse\pcb")
GERBERS_DIR = BASE_DIR / "gerbers"
ZIP_PATH = BASE_DIR / "OSITO_LILBEAR65_REV1.1_FAB_PACKAGE.zip"
NOTES_PATH = BASE_DIR / "README_FABRICATION_NOTES.txt"
BOM_PATH = BASE_DIR / "OSITO_F411_12A_AIO_BOM.csv"
CPL_PATH = BASE_DIR / "OSITO_F411_12A_AIO_CPL_PickAndPlace.csv"
KICAD_PCB_PATH = BASE_DIR / "OSITO_LILBEAR65_F411_12A_AIO.kicad_pcb"

EXPECTED_GERBERS = [
    "OSITO_LILBEAR65_F411_12A_AIO-F_Cu.gtl",
    "OSITO_LILBEAR65_F411_12A_AIO-B_Cu.gbl",
    "OSITO_LILBEAR65_F411_12A_AIO-In1_Cu.g2",
    "OSITO_LILBEAR65_F411_12A_AIO-In2_Cu.g3",
    "OSITO_LILBEAR65_F411_12A_AIO-F_Mask.gts",
    "OSITO_LILBEAR65_F411_12A_AIO-B_Mask.gbs",
    "OSITO_LILBEAR65_F411_12A_AIO-F_Silkscreen.gto",
    "OSITO_LILBEAR65_F411_12A_AIO-B_Silkscreen.gbo",
    "OSITO_LILBEAR65_F411_12A_AIO-F_Paste.gtp",
    "OSITO_LILBEAR65_F411_12A_AIO-B_Paste.gbp",
    "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gm1",
    "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gko",
]

EXPECTED_DRILLS = [
    "OSITO_LILBEAR65_F411_12A_AIO-PTH.drl",
    "OSITO_LILBEAR65_F411_12A_AIO-NPTH.drl",
]

EXPECTED_DRILL_REPORT = "OSITO_LILBEAR65_F411_12A_AIO-drl.rpt"

EXPECTED_ZIP_FILES = set(
    EXPECTED_GERBERS +
    EXPECTED_DRILLS +
    [EXPECTED_DRILL_REPORT, "README_FABRICATION_NOTES.txt", "OSITO_F411_12A_AIO_BOM.csv", "OSITO_F411_12A_AIO_CPL_PickAndPlace.csv"]
)

class ChallengerReport:
    def __init__(self):
        self.passes = []
        self.failures = []
        self.warnings = []

    def check(self, condition: bool, test_name: str, details: str = ""):
        if condition:
            self.passes.append((test_name, details))
            print(f"  [PASS] {test_name}: {details}")
        else:
            self.failures.append((test_name, details))
            print(f"  [FAIL] {test_name}: {details}")

    def warn(self, condition: bool, test_name: str, details: str = ""):
        if not condition:
            self.warnings.append((test_name, details))
            print(f"  [WARN] {test_name}: {details}")

    def summary(self):
        print("\n" + "="*80)
        print("EMPIRICAL CHALLENGER AUDIT SUMMARY")
        print("="*80)
        print(f"Total Passes:   {len(self.passes)}")
        print(f"Total Failures: {len(self.failures)}")
        print(f"Total Warnings: {len(self.warnings)}")
        if self.failures:
            print("\nFAILURES:")
            for name, det in self.failures:
                print(f"  - {name}: {det}")
        if self.warnings:
            print("\nWARNINGS:")
            for name, det in self.warnings:
                print(f"  - {name}: {det}")
        print("="*80)
        verdict = "APPROVE" if not self.failures else "REQUEST_CHANGES"
        print(f"VERDICT: {verdict}")
        print("="*80)
        return verdict


def parse_gerber_file(filepath: Path):
    """
    Parses an RS-274X Gerber file, validating headers, aperture definitions,
    aperture reference integrity, coordinates, and M02* EOF.
    """
    content = filepath.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines()

    has_format = bool(re.search(r"%FS[LT][AI]X\d{2}Y\d{2}\*%", content))
    has_unit_mm = bool(re.search(r"%MO(MM)\*%", content))
    has_polarity = bool(re.search(r"%LP[DC]\*%", content))
    has_eof = "M02*" in content or "%M02*%" in content

    # Find aperture definitions: %ADD<num><shape>[,<params>]*%
    defined_apertures = set()
    for m in re.finditer(r"%ADD(\d+)([A-Za-z]+)(?:,([^%]+))?\*%", content):
        defined_apertures.add(int(m.group(1)))

    # Find aperture selections: D<num>* (where num >= 10)
    referenced_apertures = set()
    for m in re.finditer(r"(?<![A-Za-z0-9])D(\d+)\*", content):
        d_val = int(m.group(1))
        if d_val >= 10:
            referenced_apertures.add(d_val)

    # Check for undefined aperture references
    undefined_apertures = referenced_apertures - defined_apertures

    # Find coordinate commands: X<num>Y<num>D<op>* or similar
    coord_matches = re.finditer(r"(?:X([+-]?\d+))?(?:Y([+-]?\d+))?D0?([123])\*", content)
    xs = []
    ys = []
    d_codes = []

    # Format 4.6 (scale factor 1e6 for mm)
    scale = 1e6

    for m in coord_matches:
        x_str, y_str, d_str = m.groups()
        if x_str is not None:
            xs.append(int(x_str) / scale)
        if y_str is not None:
            ys.append(int(y_str) / scale)
        if d_str is not None:
            d_codes.append(int(d_str))

    # Also parse G01/G02/G03 arc coordinates if present
    for m in re.finditer(r"(?:X([+-]?\d+))?(?:Y([+-]?\d+))?(?:I([+-]?\d+))?(?:J([+-]?\d+))?D0?([123])\*", content):
        x_str, y_str = m.group(1), m.group(2)
        if x_str is not None:
            xs.append(int(x_str) / scale)
        if y_str is not None:
            ys.append(int(y_str) / scale)

    has_polygons = "G36*" in content and "G37*" in content

    return {
        "filesize": filepath.stat().st_size,
        "line_count": len(lines),
        "has_format": has_format,
        "has_unit_mm": has_unit_mm,
        "has_polarity": has_polarity,
        "has_eof": has_eof,
        "aperture_count": len(defined_apertures),
        "defined_apertures": defined_apertures,
        "referenced_apertures": referenced_apertures,
        "undefined_apertures": undefined_apertures,
        "coord_count": len(xs) + len(ys),
        "min_x": min(xs) if xs else None,
        "max_x": max(xs) if xs else None,
        "min_y": min(ys) if ys else None,
        "max_y": max(ys) if ys else None,
        "has_polygons": has_polygons,
    }


def parse_excellon_file(filepath: Path):
    """
    Parses an Excellon NC Drill file, validating header, tools, coordinate points, and M30.
    """
    content = filepath.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines()

    has_m48 = any(l.strip() == "M48" for l in lines)
    has_metric = any("METRIC" in l for l in lines)
    has_header_end = any(l.strip() == "%" for l in lines)
    has_m30 = any("M30" in l for l in lines)

    # Tool definitions: T<num>C<diameter>
    tools = {}
    tool_defs = re.findall(r"T(\d+)C([0-9.]+)", content)
    for t_num, dia in tool_defs:
        tools[int(t_num)] = float(dia)

    # Parse hits per tool and check tool references
    current_tool = None
    tool_hits = {t: [] for t in tools}
    undefined_tools = set()

    for line in lines:
        l = line.strip()
        t_sel = re.match(r"^T(\d+)$", l)
        if t_sel:
            current_tool = int(t_sel.group(1))
            if current_tool not in tools:
                undefined_tools.add(current_tool)
            if current_tool not in tool_hits:
                tool_hits[current_tool] = []
            continue

        coord_match = re.match(r"^X([+-]?[0-9.]+)Y([+-]?[0-9.]+)$", l)
        if coord_match and current_tool is not None:
            x_val = float(coord_match.group(1))
            y_val = float(coord_match.group(2))
            tool_hits[current_tool].append((x_val, y_val))

    total_hits = sum(len(hits) for hits in tool_hits.values())

    return {
        "filesize": filepath.stat().st_size,
        "has_m48": has_m48,
        "has_metric": has_metric,
        "has_header_end": has_header_end,
        "has_m30": has_m30,
        "tools": tools,
        "undefined_tools": undefined_tools,
        "tool_hits": tool_hits,
        "total_hits": total_hits,
        "raw_content": content,
    }


def main():
    report = ChallengerReport()
    print("="*80)
    print("STARTING INDEPENDENT EMPIRICAL CHALLENGE AUDIT - MILESTONE 2")
    print(f"Base Directory: {BASE_DIR}")
    print("="*80)

    # --------------------------------------------------------------------------
    # 1. GERBER FILES VERIFICATION (12 FILES)
    # --------------------------------------------------------------------------
    print("\n--- 1. AUDITING 12 GERBER RS-274X FILES ---")
    report.check(GERBERS_DIR.is_dir(), "Gerbers Directory Exists", str(GERBERS_DIR))

    for g_name in EXPECTED_GERBERS:
        g_path = GERBERS_DIR / g_name
        exists = g_path.is_file()
        report.check(exists, f"Gerber File Exists: {g_name}", f"Size: {g_path.stat().st_size if exists else 0} B")
        if not exists:
            continue

        metrics = parse_gerber_file(g_path)
        report.check(metrics["filesize"] > 0, f"{g_name} Non-Empty", f"{metrics['filesize']} bytes")
        report.check(metrics["has_format"], f"{g_name} RS-274X Format Header", "FSLAX46Y46 detected")
        report.check(metrics["has_unit_mm"], f"{g_name} Unit Mode MM", "MOMM detected")
        report.check(metrics["has_polarity"], f"{g_name} Polarity Definition", "LPD/LPC detected")
        report.check(metrics["has_eof"], f"{g_name} End-Of-File Marker", "M02* detected")
        report.check(metrics["aperture_count"] > 0, f"{g_name} Aperture Definitions", f"{metrics['aperture_count']} apertures defined")
        report.check(len(metrics["undefined_apertures"]) == 0, f"{g_name} Aperture Reference Integrity",
                     "All referenced apertures are defined" if not metrics["undefined_apertures"] else f"Undefined: {metrics['undefined_apertures']}")
        report.check(metrics["coord_count"] > 0, f"{g_name} Coordinates Present", f"{metrics['coord_count']} coordinate commands")

        # Verify coordinates lie within board boundary envelope (±15.0 mm with small tolerance for edge margin)
        if metrics["min_x"] is not None and metrics["max_x"] is not None:
            in_x = -15.5 <= metrics["min_x"] and metrics["max_x"] <= 15.5
            report.check(in_x, f"{g_name} X Bounding Box", f"X in [{metrics['min_x']:.2f}, {metrics['max_x']:.2f}] mm (envelope [-15.5, +15.5])")
        if metrics["min_y"] is not None and metrics["max_y"] is not None:
            in_y = -15.5 <= metrics["min_y"] and metrics["max_y"] <= 15.5
            report.check(in_y, f"{g_name} Y Bounding Box", f"Y in [{metrics['min_y']:.2f}, {metrics['max_y']:.2f}] mm (envelope [-15.5, +15.5])")

    # --------------------------------------------------------------------------
    # 2. EDGE CUTS AUDIT (.gm1 and .gko)
    # --------------------------------------------------------------------------
    print("\n--- 2. AUDITING BOARD OUTLINE (Edge_Cuts) ---")
    ec_gm1 = GERBERS_DIR / "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gm1"
    ec_gko = GERBERS_DIR / "OSITO_LILBEAR65_F411_12A_AIO-Edge_Cuts.gko"
    report.check(ec_gm1.read_bytes() == ec_gko.read_bytes(), "Edge_Cuts .gm1 and .gko Parity", "Identical content for CAM compatibility")
    
    # Audit Edge Cuts geometry: check for 29x29mm envelope (±14.5mm) and 2.0mm corner fillets (transition at ±12.5mm)
    ec_content = ec_gm1.read_text(encoding="utf-8")
    report.check("14500000" in ec_content and "12500000" in ec_content,
                 "Edge Cuts Dimensions Match 29.0x29.0mm", "±14.50mm outer extent and ±12.50mm fillet tangent nodes verified")

    # --------------------------------------------------------------------------
    # 3. EXCELLON NC DRILL AUDIT (PTH & NPTH)
    # --------------------------------------------------------------------------
    print("\n--- 3. AUDITING EXCELLON NC DRILL FILES ---")
    pth_path = GERBERS_DIR / "OSITO_LILBEAR65_F411_12A_AIO-PTH.drl"
    npth_path = GERBERS_DIR / "OSITO_LILBEAR65_F411_12A_AIO-NPTH.drl"
    drl_rpt_path = GERBERS_DIR / EXPECTED_DRILL_REPORT

    report.check(pth_path.is_file(), "PTH Drill File Exists", str(pth_path))
    report.check(npth_path.is_file(), "NPTH Drill File Exists", str(npth_path))
    report.check(drl_rpt_path.is_file(), "Drill Report Exists", str(drl_rpt_path))

    pth_data = parse_excellon_file(pth_path)
    npth_data = parse_excellon_file(npth_path)

    # PTH Checks
    report.check(pth_data["has_m48"] and pth_data["has_metric"] and pth_data["has_m30"],
                 "PTH Drill Format Header & EOF", "M48, METRIC, %, M30 verified")
    report.check(len(pth_data["undefined_tools"]) == 0, "PTH Tool Definition Integrity",
                 "All tools defined in header" if not pth_data["undefined_tools"] else f"Undefined: {pth_data['undefined_tools']}")
    report.check("Plated" in pth_data["raw_content"] or "PTH" in pth_data["raw_content"],
                 "PTH Plated Through Hole Marker", "Plated / PTH flag verified")
    report.check(pth_data["total_hits"] == 23, "PTH Total Hole Count", f"{pth_data['total_hits']} hits (expected 23)")
    report.check(0.200 in pth_data["tools"].values() and 0.300 in pth_data["tools"].values(),
                 "PTH Tool Diameters", f"Tools: {pth_data['tools']} (0.20mm stitching, 0.30mm vias)")

    # NPTH Checks
    report.check(npth_data["has_m48"] and npth_data["has_metric"] and npth_data["has_m30"],
                 "NPTH Drill Format Header & EOF", "M48, METRIC, %, M30 verified")
    report.check(len(npth_data["undefined_tools"]) == 0, "NPTH Tool Definition Integrity",
                 "All tools defined in header" if not npth_data["undefined_tools"] else f"Undefined: {npth_data['undefined_tools']}")
    report.check("NonPlated" in npth_data["raw_content"] or "NPTH" in npth_data["raw_content"],
                 "NPTH Non-Plated Marker", "NonPlated / NPTH flag verified")
    report.check(npth_data["total_hits"] == 4, "NPTH Total Hole Count", f"{npth_data['total_hits']} hits (expected 4)")
    report.check(list(npth_data["tools"].values()) == [2.100],
                 "NPTH Tool Diameter", f"Tools: {npth_data['tools']} (expected exactly 2.100mm)")

    # Check NPTH coordinates: 4x mounting holes at (±12.75, ±12.75) mm
    npth_tool1_hits = npth_data["tool_hits"].get(1, [])
    expected_npth_coords = {(12.75, 12.75), (-12.75, 12.75), (-12.75, -12.75), (12.75, -12.75)}
    actual_npth_coords = {(round(x, 3), round(y, 3)) for x, y in npth_tool1_hits}

    coords_match = (actual_npth_coords == expected_npth_coords)
    report.check(coords_match, "NPTH 4x 2.1mm Mounting Hole Positions",
                 f"Actual: {sorted(list(actual_npth_coords))} | Expected: {sorted(list(expected_npth_coords))}")

    # Verify separation: NPTH holes NOT in PTH file, and PTH vias NOT in NPTH file
    npth_in_pth = any((round(x, 3), round(y, 3)) in expected_npth_coords
                      for hits in pth_data["tool_hits"].values() for x, y in hits)
    report.check(not npth_in_pth, "Separation: No NPTH Mounting Holes in PTH File", "Verified zero overlap")

    # Verify drill report
    rpt_content = drl_rpt_path.read_text(encoding="utf-8")
    has_rpt_t1_pth = bool(re.search(r"T1\s+0\.200mm.*?count:\s*10", rpt_content))
    has_rpt_t2_pth = bool(re.search(r"T2\s+0\.300mm.*?count:\s*13", rpt_content))
    has_rpt_t1_npth = bool(re.search(r"T1\s+2\.100mm.*?count:\s*4", rpt_content))
    report.check(has_rpt_t1_pth, "Drill Report T1 (0.20mm) Count", "10 plated vias")
    report.check(has_rpt_t2_pth, "Drill Report T2 (0.30mm) Count", "13 plated vias")
    report.check(has_rpt_t1_npth, "Drill Report NPTH (2.10mm) Count", "4 unplated mounting holes")

    # --------------------------------------------------------------------------
    # 4. AUDITING ZIP FABRICATION ARCHIVE (OSITO_LILBEAR65_REV1.1_FAB_PACKAGE.zip)
    # --------------------------------------------------------------------------
    print("\n--- 4. AUDITING ZIP FABRICATION ARCHIVE ---")
    report.check(ZIP_PATH.is_file(), "Fabrication ZIP Package Exists", str(ZIP_PATH))

    if ZIP_PATH.is_file():
        try:
            with zipfile.ZipFile(ZIP_PATH, 'r') as zf:
                # 4.1 Test archive CRC32
                corrupt_file = zf.testzip()
                report.check(corrupt_file is None, "ZIP Archive Integrity Test (CRC32)",
                             "0 corrupt files" if corrupt_file is None else f"Corrupt: {corrupt_file}")

                # 4.2 Check file inventory
                zip_namelist = set(zf.namelist())
                report.check(len(zip_namelist) == 18, "ZIP Archive File Count", f"Found {len(zip_namelist)} files (expected 18)")
                report.check(zip_namelist == EXPECTED_ZIP_FILES, "ZIP Archive Manifest Parity",
                             f"Missing: {EXPECTED_ZIP_FILES - zip_namelist}, Extra: {zip_namelist - EXPECTED_ZIP_FILES}")

                # 4.3 Byte-for-byte comparison with raw disk files
                raw_file_mapping = {}
                for name in EXPECTED_GERBERS + EXPECTED_DRILLS + [EXPECTED_DRILL_REPORT]:
                    raw_file_mapping[name] = GERBERS_DIR / name
                raw_file_mapping["README_FABRICATION_NOTES.txt"] = NOTES_PATH
                raw_file_mapping["OSITO_F411_12A_AIO_BOM.csv"] = BOM_PATH
                raw_file_mapping["OSITO_F411_12A_AIO_CPL_PickAndPlace.csv"] = CPL_PATH

                all_bytes_match = True
                mismatches = []
                for fname, raw_path in raw_file_mapping.items():
                    if not raw_path.is_file():
                        all_bytes_match = False
                        mismatches.append(f"{fname}: raw disk file missing ({raw_path})")
                        continue
                    zip_bytes = zf.read(fname)
                    disk_bytes = raw_path.read_bytes()
                    if zip_bytes != disk_bytes:
                        all_bytes_match = False
                        mismatches.append(f"{fname}: zip len={len(zip_bytes)} vs disk len={len(disk_bytes)}")

                report.check(all_bytes_match, "ZIP Archive 18/18 Files Byte-for-Byte Match Raw Disk Files",
                             "All 18 files identical" if all_bytes_match else f"Mismatches: {mismatches}")

                # 4.4 Test extraction into clean temporary directory
                with tempfile.TemporaryDirectory() as tmpdir:
                    zf.extractall(tmpdir)
                    extracted_files = list(Path(tmpdir).iterdir())
                    report.check(len(extracted_files) == 18, "ZIP Clean Extraction Test",
                                 f"Extracted {len(extracted_files)} files successfully into temporary directory")

        except Exception as e:
            report.check(False, "ZIP Archive Opening / Reading", f"Exception: {e}")

    # --------------------------------------------------------------------------
    # 5. AUDITING MANUFACTURING FABRICATION NOTES
    # --------------------------------------------------------------------------
    print("\n--- 5. AUDITING MANUFACTURING FABRICATION NOTES ---")
    report.check(NOTES_PATH.is_file(), "Fabrication Notes File Exists", str(NOTES_PATH))
    if NOTES_PATH.is_file():
        notes_text = NOTES_PATH.read_text(encoding="utf-8")
        has_dims = bool(re.search(r"29\.00?\s*mm\s*x\s*29\.00?\s*mm", notes_text, re.IGNORECASE))
        has_mount = bool(re.search(r"25\.50?\s*mm\s*x\s*25\.50?\s*mm", notes_text, re.IGNORECASE))
        has_layers = bool(re.search(r"4\s*Layers?", notes_text, re.IGNORECASE))
        has_stackup = "JLC04101H-7628" in notes_text or "7628" in notes_text
        has_enig = "ENIG" in notes_text
        has_drc = bool(re.search(r"5(?:\.0)?\s*mil\s*/\s*5(?:\.0)?\s*mil", notes_text))
        has_drill = bool(re.search(r"0\.30?\s*mm", notes_text))
        has_imp = bool(re.search(r"50\s*Ohm", notes_text))

        report.check(has_dims, "Notes: Board Dimensions", "29.00 mm x 29.00 mm specified")
        report.check(has_mount, "Notes: Mounting Pattern", "25.50 mm x 25.50 mm specified")
        report.check(has_layers, "Notes: Layer Count", "4 Layers specified")
        report.check(has_stackup, "Notes: Stackup Specification", "JLC04101H-7628 specified")
        report.check(has_enig, "Notes: Surface Finish", "ENIG specified")
        report.check(has_drc, "Notes: Min Trace/Space", "5.0 mil / 5.0 mil outer, 4.0 mil / 4.0 mil inner specified")
        report.check(has_drill, "Notes: Min Drill Size", "0.30 mm min drill specified")
        report.check(has_imp, "Notes: Controlled Impedance", "50 Ohm RF microstrip specified")

    # --------------------------------------------------------------------------
    # 6. PCB LAYOUT CROSS-CHECK (OSITO_LILBEAR65_F411_12A_AIO.kicad_pcb)
    # --------------------------------------------------------------------------
    print("\n--- 6. CROSS-CHECKING KICAD PCB LAYOUT FILE ---")
    report.check(KICAD_PCB_PATH.is_file(), "KiCad PCB Layout File Exists", str(KICAD_PCB_PATH))
    if KICAD_PCB_PATH.is_file():
        kicad_content = KICAD_PCB_PATH.read_text(encoding="utf-8")
        # Check parenthesis balance
        open_parens = kicad_content.count("(")
        close_parens = kicad_content.count(")")
        report.check(open_parens == close_parens, "KiCad S-Expression Balanced Parentheses",
                     f"{open_parens} open == {close_parens} close")
        
        # Parse all footprints
        placed_footprints = re.findall(
            r'\(footprint\s+"([^"]+)".*?\(layer\s+"([^"]+)".*?\(at\s+([-\d.]+)\s+([-\d.]+)(?:\s+([-\d.]+))?\).*?\(property\s+"Reference"\s+"([^"]+)"',
            kicad_content, re.DOTALL
        )
        report.check(len(placed_footprints) == 134, "KiCad Total Footprint Count",
                     f"Found {len(placed_footprints)} footprints (130 SMT components + 4 mounting holes)")

        # Verify CPL cross-reconciliation
        with open(CPL_PATH, "r", encoding="utf-8") as f:
            cpl_rows = list(csv.DictReader(f))

        fp_map = {ref: (pkg, cu_layer, float(x), float(y), float(rot) if rot else 0.0)
                  for pkg, cu_layer, x, y, rot, ref in placed_footprints}
        
        missing_cpl = []
        coord_mismatch = []
        layer_mismatch = []
        for r in cpl_rows:
            des = r["Designator"].strip()
            cx = float(r["Mid X (mm)"])
            cy = float(r["Mid Y (mm)"])
            crot = float(r["Rotation"])
            clayer = "F.Cu" if r["Layer"].strip() == "Top" else "B.Cu"
            if des not in fp_map:
                missing_cpl.append(des)
            else:
                pkg, cu_layer, fx, fy, frot = fp_map[des]
                if abs(fx - cx) > 0.01 or abs(fy - cy) > 0.01 or abs(frot - crot) > 0.1:
                    coord_mismatch.append((des, (cx, cy, crot), (fx, fy, frot)))
                if cu_layer != clayer:
                    layer_mismatch.append((des, clayer, cu_layer))

        report.check(len(missing_cpl) == 0, "KiCad Layout SMT Component Count vs CPL",
                     f"100% of 130 CPL components present (missing: {missing_cpl})")
        report.check(len(coord_mismatch) == 0, "KiCad Layout Centroid & Rotation Parity vs CPL",
                     f"100% match within 0.01mm tolerance (mismatches: {len(coord_mismatch)})")
        report.check(len(layer_mismatch) == 0, "KiCad Layout Layer Parity vs CPL",
                     f"100% match: 66 Top (F.Cu), 64 Bottom (B.Cu) (mismatches: {len(layer_mismatch)})")

    # --------------------------------------------------------------------------
    # SUMMARY & VERDICT
    # --------------------------------------------------------------------------
    verdict = report.summary()
    sys.exit(0 if verdict == "APPROVE" else 1)

if __name__ == "__main__":
    main()
