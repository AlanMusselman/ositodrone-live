# OSITO-FC29-AT32-LITE-LOS: Complete Bill of Materials (BOM) & Cost Breakdown

**Target Board:** `OSITO-FC29-AT32-LITE-LOS REV 1.0` *(1S 300mAh ELRS 2.4GHz Brushed No-Camera Flight Controller)*  
**Total SMD Placements:** **63 Discrete SMD Components** (59 on Top Layer `F.Cu` for Single-Pass Stencil Reflow + 4 Bottom `JST-1.25` Motor Receptacles)

---

## 1. Unit Cost Comparison: Full FPV Board vs. Ultra-Cheap LOS Board

| Configuration | Bare PCB Spec | SMD Part Count | Reflow Passes | Unit FC Cost | Complete 65mm Drone Cost |
| :--- | :--- | :---: | :---: | :---: | :---: |
| **[`OSITO-FC29-F411-12A-HB`](../pcb/OSITO_F411_12A_AIO_BOM_and_Sourcing.md)** *(Full FPV + VTX + OSD + H-Bridge)* | 4-Layer ENIG (`$1.15`) | 130 parts | 2-Sided Reflow | `$18.63` | `$48.18` *(with Cam)* |
| **`OSITO-FC29-AT32-LITE-LOS`** *(No-Cam ELRS + `AT32F435` + 4× `AO3400A`)* | **2-Layer HASL (`$0.40`)** | **63 parts** | **1-Pass Top Reflow** | **`$5.84`** | **`$21.29`** *(with 4× Motors, Props, Frame & 1S 300mAh LiHV)* |
| **`OSITO-FC29-AT32-LITE-LOS` (w/ `ICM-42688-P` / `LSM6DSO` Gyro Swap)** | **2-Layer HASL (`$0.40`)** | **63 parts** | **1-Pass Top Reflow** | **`$5.14`** | **`$20.59`** |

---

## 2. Complete Discrete SMD Bill of Materials (`$5.84` / Board)

All 28 line items (63 SMD placements + bare PCB + battery pigtail) match [`OSITO_AT32_LITE_LOS_BOM.csv`](./OSITO_AT32_LITE_LOS_BOM.csv) and [`OSITO_AT32_LITE_LOS_CPL_PickAndPlace.csv`](./OSITO_AT32_LITE_LOS_CPL_PickAndPlace.csv):

| Item | Designator | Qty | Description | MPN | Package | LCSC P/N | Unit | Ext. Cost |
| :---: | :--- | :---: | :--- | :--- | :---: | :---: | :---: | :---: |
| 1 | `PCB1` | 1 | 2-Layer Bare PCB $29\times29\times1.0\text{ mm}$ FR4 1oz Lead-Free HASL | `OSITO-FC29-AT32-LITE-LOS` | `29x29mm_2L` | JLCPCB | `$0.40` | **`$0.400`** |
| 2 | `U1` | 1 | MCU ARM Cortex-M4F $288\text{ MHz}$ $1\text{MB}$ Flash (Betaflight 4.5) | Artery `AT32F435CGU7` | `UFQFPN-48` | `C5122563` | `$1.35` | **`$1.350`** |
| 3 | `U2` | 1 | 6-Axis MEMS IMU Gyro *(or swap `ICM-42688-P` `C2848105` @ `$0.65`)* | Bosch `BMI270` | `LGA-14` | `C969094` | `$1.35` | **`$1.350`** |
| 4 | `U3` | 1 | 2.4GHz ExpressLRS 3.0+ RF Transceiver | Semtech `SX1280IMLTRT` | `QFN-24` | `C139290` | `$1.05` | **`$1.050`** |
| 5 | `U4` | 1 | $3.3\text{V}$ $600\text{ mA}$ Low-Dropout Digital & ELRS LDO | Diodes Inc `AP2112K-3.3TRG1` | `SOT-23-5` | `C51118` | `$0.06` | **`$0.060`** |
| 6 | `U5` | 1 | $3.3\text{V}$ $250\text{ mA}$ Ultra-Low-Noise Gyro LDO | TI `LP5907MFX-3.3/NOPB` | `SOT-23-5` | `C80670` | `$0.12` | **`$0.120`** |
| 7 | `Q1–Q4` | 4 | $30\text{V}$ $5.7\text{A}$ ($19\text{ m}\Omega$) N-Ch Brushed PWM MOSFETs | AOS `AO3400A` | `SOT-23` | `C20917` | `$0.03` | **`$0.120`** |
| 8 | `D_M1–D_M4` | 4 | $40\text{V}$ $1\text{A}$ Schottky Motor Flyback Diodes | CJ `B5819WS` | `SOD-123` | `C8598` | `$0.015` | **`$0.060`** |
| 9 | `D1` | 1 | USB 2.0 ESD Protection Array | STMicro `USBLC6-2SC6` | `SOT-23-6` | `C7519` | `$0.06` | **`$0.060`** |
| 10 | `D2, D3` | 2 | $20\text{V}$ $0.5\text{A}$ Power OR-ing Schottky Diodes (`VBUS`/`VBAT`) | ON Semi `MBR0520LT1G` | `SOD-123` | `C8592` | `$0.03` | **`$0.060`** |
| 11 | `Y1` | 1 | $8.000\text{ MHz}$ $\pm10\text{ ppm}$ SMD Crystal (`AT32` HSE) | Abracon `ABM8-8.000MHZ-B2-T` | `SMD-3225-4P` | `C9002` | `$0.10` | **`$0.100`** |
| 12 | `Y2` | 1 | $52.000\text{ MHz}$ $\pm10\text{ ppm}$ SMD Crystal (`SX1280` RF) | NDK `NX2016SA-52.000M` | `SMD-2016-4P` | `C510924` | `$0.16` | **`$0.160`** |
| 13 | `ANT1` | 1 | $2.4\text{ GHz}$ SMD Ceramic Chip Antenna (Onboard ELRS) | Johanson `2450AT18B100E` | `SMD-3216` | `C126701` | `$0.15` | **`$0.150`** |
| 14 | `J1` | 1 | 16-Pin USB Type-C SMD Receptacle | Hroparts `TYPE-C-31-M-12` | `USB-C-16P` | `C165948` | `$0.10` | **`$0.100`** |
| 15 | `J_M1–J_M4` | 4 | `JST-1.25mm` 2-Pin SMD Motor Receptacles | CJT `A1251WV-S-2P` | `SMD-1.25-2P` | `C145920` | `$0.03` | **`$0.120`** |
| 16 | `L_RF` | 1 | $15\,\mu\text{H}$ `0603` Shielded Inductor (`SX1280` DC-DC) | Murata `LQM18PN150MFR` | `0603` | `C86116` | `$0.03` | **`$0.030`** |
| 17 | `L1_RF` | 1 | $1.5\text{ nH}$ `0402` RF $\pi$-Match Inductor | Murata `LQG15HS1N5S02D` | `0402` | `C15132` | `$0.02` | **`$0.020`** |
| 18 | `C_BULK` | 1 | $220\,\mu\text{F}$ $6.3\text{V}$ Low-ESR Polymer Bulk Cap | Panasonic `6TPE220MAZB` | `CASE-B_3528` | `C134792` | `$0.18` | **`$0.180`** |
| 19 | `C1` | 1 | $2.2\,\mu\text{F}$ $6.3\text{V}$ `0402` Cap (`VCAP1`) | Samsung `CL05A225KQ5NNNC` | `0402` | `C12923` | `$0.005` | **`$0.005`** |
| 20 | `C10,11,18,20` | 4 | $10\,\mu\text{F}$ $10\text{V}$ `0402` Caps (LDO Input/Output) | Samsung `CL05A106MQ5NNNC` | `0402` | `C15525` | `$0.008` | **`$0.032`** |
| 21 | `C2–7,19,21,22,26–29` | 13 | $100\text{ nF}$ $16\text{V}$ `0402` Decoupling & Motor Snubber Caps | Samsung `CL05B104KO5NNNC` | `0402` | `C1525` | `$0.002` | **`$0.026`** |
| 22 | `C8, C9` | 2 | $15\text{ pF}$ $50\text{V}$ `0402` Crystal Load Caps | Murata `GRM1555C1H150JA01D` | `0402` | `C1548` | `$0.003` | **`$0.006`** |
| 23 | `C23, C24` | 2 | $1.2\text{ pF}$ $50\text{V}$ `0402` RF $\pi$-Match Shunt Caps | Murata `GRM1555C1H1R2WA01D` | `0402` | `C1540` | `$0.004` | **`$0.008`** |
| 24 | `C25` | 1 | $100\text{ pF}$ $50\text{V}$ `0402` RF DC-Block Cap | Murata `GRM1555C1H101JA01D` | `0402` | `C1546` | `$0.003` | **`$0.003`** |
| 25 | `R1,2,12,R_PD1–4` | 7 | $10\text{ k}\Omega$ 1% `0402` Resistors (`VBAT`, `BOOT0`, FET Pull-Downs) | Yageo `RC0402FR-0710KL` | `0402` | `C25744` | `$0.002` | **`$0.014`** |
| 26 | `R_G1–R_G4` | 4 | $100\,\Omega$ 1% `0402` Resistors (FET Gate Damping) | Yageo `RC0402FR-07100RL` | `0402` | `C25077` | `$0.002` | **`$0.008`** |
| 27 | `R10, R11` | 2 | $5.1\text{ k}\Omega$ 1% `0402` Resistors (`USB-C` `CC1/CC2`) | Yageo `RC0402FR-075K1L` | `0402` | `C25905` | `$0.002` | **`$0.004`** |
| 28 | `PIGTAIL1` | 1 | `BT2.0` or `PH2.0` 1S $40\text{ mm}$ Battery Lead | Generic `BT2.0-1S-40MM` | Wire Lead | Wholesale | `$0.25` | **`$0.250`** |
| — | **TOTAL** | **63 SMD** | **Complete `OSITO-FC29-AT32-LITE-LOS` Flight Controller** | — | — | — | — | **`$5.846`** |
