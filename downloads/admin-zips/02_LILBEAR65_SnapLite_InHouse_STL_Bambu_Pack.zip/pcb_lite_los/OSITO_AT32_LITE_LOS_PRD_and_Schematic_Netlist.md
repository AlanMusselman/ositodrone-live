# OSITO-FC29-AT32-LITE-LOS: Ultra-Low-Cost 2-Layer 1S 300mAh ELRS Brushed LOS Flight Controller

**Part Number:** `OSITO-FC29-AT32-LITE-LOS REV 1.0`  
**Target Platform:** 1S 300mAh LiHV Brushed Line-of-Sight (No Camera / No VTX) Micro-Drone (`OSITO LILBEAR-65 LOS`)  
**Total Unit Cost (PCB + 63 SMD Parts + Pigtail):** **`$5.84 USD`** *(vs. `$18.63` for the 4-Layer FPV H-Bridge board — **68.6% cheaper**)*  
**PCB Stackup:** **2-Layer $1.0\text{ mm}$ FR4 TG150, $1\text{ oz}$ Copper, Lead-Free HASL** (`$2.00` for 5 boards / `$0.40` per bare PCB at JLCPCB)

---

## 1. How We Slashed the Flight Controller Cost from `$18.63` to `$5.84`

By designing specifically for a **1S 300mAh Line-of-Sight (No-Camera) ELRS drone**, we eliminate 67 components and two entire copper layers that are only required for analog FPV video and bidirectional H-bridge motor reversal:

| Engineering Optimization | Full FPV Board (`OSITO-FC29-F411-12A-HB`) | Stripped LOS Board (`OSITO-FC29-AT32-LITE-LOS`) | Cost Saved |
| :--- | :--- | :--- | :---: |
| **1. No Camera / VTX / OSD** | `AT7456E` OSD + `RTC6705` + `RTC6659E` PA + `EFM8BB10` + Crystals + `J_CAM` + `J_VTX` | **Removed completely** (0g dead weight, 0mA idle draw) | **`-$3.75`** |
| **2. No 5V Buck-Boost BEC** | `TPS63020DSJR` 5V 2A Buck-Boost + $1.5\,\mu\text{H}$ Inductor + $2\times22\,\mu\text{F}$ + LC filter | **Direct 1S $\rightarrow$ 3.3V LDO** (`AP2112K-3.3` + `LP5907-3.3` with USB/VBAT Schottky OR-ing) | **`-$1.15`** |
| **3. 4× Low-Side N-FET PWM ESC** | 4× `EFM8BB21` MCUs + 8× `AO4614B` SOIC-8 FETs + 4× `BC847BS` drivers (`$3.68`) | **4× `AO3400A` (`SOT-23`, $5.7\text{A}$, $19\text{ m}\Omega$) N-FETs** driven by $32\text{ kHz}$ Hardware Timer PWM + 4× `B5819WS` Schottky flyback diodes (`$0.20`) | **`-$3.48`** |
| **4. `AT32F435CGU7` MCU** | `STM32F411CEU6` ($100\text{ MHz}$, $512\text{ KB}$ Flash, `$2.45`) | **Artery `AT32F435CGU7`** ($288\text{ MHz}$, $1024\text{ KB}$ Flash, Betaflight 4.5 native, pin-compatible `QFN-48`, `$1.35`) | **`-$1.10`** |
| **5. 2-Layer Lead-Free HASL PCB** | 4-Layer FR4 TG170 $2\text{oz}/1\text{oz}$ ENIG (`$1.15`/board) | **2-Layer FR4 $1\text{oz}$ Lead-Free HASL** (`$0.40`/board at JLCPCB; 100% of active SMD parts on Top side for 1-pass reflow!) | **`-$0.75`** |
| **6. Simplified Telemetry & RF** | High-side `INA199A1` current shunt amp + dual U.FL connectors | Built-in `2450AT18B100E` Ceramic ELRS Antenna + 2:1 `VBAT` ADC divider (Betaflight Virtual Current Meter calibrated to 1S 300mAh curve) | **`-$2.56`** |
| **TOTAL UNIT BOM** | **`$18.63`** *(130 SMD parts, 2-sided reflow)* | **`$5.84`** *(63 SMD parts, single-pass top reflow + 4 motor plugs)* | **`-$12.79` (-68.6%)** |

> [!TIP]
> **Want to push it to `$5.14` per board?** You can drop-in substitute an **InvenSense `ICM-42688-P`** or **ST `LSM6DSO`** (`LGA-14` $2.5 \times 3.0\text{ mm}$, footprint-identical to `BMI270` on `SPI1`) for `$0.65` at LCSC instead of `$1.35` for the Bosch `BMI270`.

---

## 2. System Block Diagram (`OSITO-FC29-AT32-LITE-LOS`)

```mermaid
flowchart TD
    subgraph PWR["1S 300mAh LiHV & USB-C Dual-OR Power Stage (Zero 5V BEC)"]
        BAT["1S 300mAh LiHV Battery\n(2.8V - 4.35V via BT2.0)"]
        USBC["J1 USB Type-C\n(VBUS 5.0V + D1 USBLC6 ESD\n+ R10/R11 5.1k CC1/CC2)"]
        CAP["C_BULK 220uF 6.3V POSCAP"]
        VDIV["R1/R2 10k/10k (2:1)\n-> PB0 (ADC1_IN8 VBAT)"]
        OR_DIODE["D2 & D3 MBR0520LT1G\nSchottky Power OR-ing\n(VIN_LDO Rail)"]
        LDO_DIG["U4 AP2112K-3.3 (600mA)\n-> +3V3_DIG Rail"]
        LDO_GYRO["U5 LP5907MFX-3.3 (250mA)\nUltra-Low-Noise -> +3V3_GYRO"]

        BAT --> CAP
        BAT --> VDIV
        BAT -->|"D3"| OR_DIODE
        USBC -->|"D2"| OR_DIODE
        OR_DIODE --> LDO_DIG
        OR_DIODE --> LDO_GYRO
    end

    subgraph CORE["AT32F435CGU7 Flight Controller Core (288MHz Cortex-M4F)"]
        MCU["U1 AT32F435CGU7 (UFQFPN-48)\n+ C1 2.2uF VCAP1 (Pin 22)\n+ R12 10k BOOT0 + C7 100nF NRST"]
        XTAL["Y1 8.000MHz Crystal\n+ C8/C9 15pF Load Caps"]
        XTAL --> MCU
        USBC <-->|"PA11/PA12 USB DFU"| MCU
    end

    subgraph RF_IMU["SPI Sensors & ExpressLRS 2.4GHz"]
        BMI["U2 Bosch BMI270 IMU\n(SPI1: PA4-PA7, EXTI: PC14)"]
        SX1280["U3 Semtech SX1280 + Y2 52MHz\n(SPI3: PA15/PB3-PB7/PC13)\n+ Pi-Match -> ANT1 Ceramic 2.4GHz"]
        MCU <-->|"SPI1"| BMI
        MCU <-->|"SPI3"| SX1280
    end

    subgraph ESC["4-Channel 32kHz Low-Side N-FET Brushed PWM ESC Stage"]
        FET["4x Q1-Q4 AO3400A (SOT-23, 5.7A, 19mOhm)\n+ 4x R_G 100-Ohm Gate Damping\n+ 4x R_PD 10k Gate Pull-Downs"]
        FLYBACK["4x D_M1-D_M4 B5819WS\n40V 1A Schottky Flyback Diodes\n+ 4x C26-C29 100nF HF Snubber Caps"]
        MOT["4x 6mm (0615/0716) Brushed Motors\n(J_M1-J_M4 JST-1.25 2-Pin)"]
        MCU -->|"32kHz Hardware PWM\n(PA0, PA1, PB9, PB8)"| FET
        CAP -->|"VBAT Solid Bus"| MOT
        FET --> MOT
        FLYBACK <--> MOT
    end

    LDO_DIG --> MCU
    LDO_DIG --> SX1280
    LDO_GYRO --> BMI
```

---

## 3. Complete `AT32F435CGU7` Pinout & Hardware Timer Matrix

| Pin | GPIO | Function | Hardware Timer / Bus | Connected Component / Net |
| :---: | :---: | :--- | :--- | :--- |
| **10** | `PA0` | **`MOTOR 1` (Rear Right)** | `TMR2_CH1` ($32\text{ kHz}$ PWM) | `R_G1` ($100\,\Omega$) $\rightarrow$ `Q1` (`AO3400A` Gate) + `R_PD1` ($10\text{ k}\Omega$ to `GND`) |
| **11** | `PA1` | **`MOTOR 2` (Front Right)** | `TMR2_CH2` ($32\text{ kHz}$ PWM) | `R_G2` ($100\,\Omega$) $\rightarrow$ `Q2` (`AO3400A` Gate) + `R_PD2` ($10\text{ k}\Omega$ to `GND`) |
| **46** | `PB9` | **`MOTOR 3` (Rear Left)** | `TMR4_CH4` ($32\text{ kHz}$ PWM) | `R_G3` ($100\,\Omega$) $\rightarrow$ `Q3` (`AO3400A` Gate) + `R_PD3` ($10\text{ k}\Omega$ to `GND`) |
| **45** | `PB8` | **`MOTOR 4` (Front Left)** | `TMR4_CH3` ($32\text{ kHz}$ PWM) | `R_G4` ($100\,\Omega$) $\rightarrow$ `Q4` (`AO3400A` Gate) + `R_PD4` ($10\text{ k}\Omega$ to `GND`) |
| **14** | `PA4` | `GYRO_CS` | `SPI1_CS` | `U2` (`BMI270` Pin 12 `CSB`) |
| **15** | `PA5` | `SPI1_SCK` | `SPI1_SCK` | `U2` (`BMI270` Pin 13 `SCX`) |
| **16** | `PA6` | `SPI1_MISO` | `SPI1_MISO` | `U2` (`BMI270` Pin 1 `SDO`) |
| **17** | `PA7` | `SPI1_MOSI` | `SPI1_MOSI` | `U2` (`BMI270` Pin 14 `SDX`) |
| **3** | `PC14` | `GYRO_EXTI` | `EXTI_Line14` | `U2` (`BMI270` Pin 4 `INT1`) |
| **38** | `PA15` | `ELRS_CS` | `SPI3_NSS` | `U3` (`SX1280` Pin 9 `NSS`) |
| **39** | `PB3` | `SPI3_SCK` | `SPI3_SCK` | `U3` (`SX1280` Pin 10 `SCK`) |
| **40** | `PB4` | `SPI3_MISO` | `SPI3_MISO` | `U3` (`SX1280` Pin 12 `MISO`) |
| **41** | `PB5` | `SPI3_MOSI` | `SPI3_MOSI` | `U3` (`SX1280` Pin 11 `MOSI`) |
| **42** | `PB6` | `ELRS_EXTI` | `EXTI_Line6` | `U3` (`SX1280` Pin 7 `DIO1`) |
| **43** | `PB7` | `ELRS_BUSY` | Digital Input | `U3` (`SX1280` Pin 6 `BUSY`) |
| **2** | `PC13` | `ELRS_RESET` | Digital Output | `U3` (`SX1280` Pin 8 `NRESET`) |
| **18** | `PB0` | `ADC_VBAT` | `ADC1_IN8` | `R1/R2` ($10\text{ k}\Omega / 10\text{ k}\Omega$, $2:1$ Divider from `VBAT`) |
| **32/33** | `PA11/12` | `USB_DM / DP` | `OTG_FS1` | `D1` (`USBLC6-2SC6`) $\leftrightarrow$ `J1` (`USB-C`) |
| **5/6** | `PH0/PH1` | `HSE_IN / OUT` | $8.000\text{ MHz}$ Crystal | `Y1` (`ABM8-8.000MHZ`) + `C8/C9` ($15\text{ pF}$) |
| **22** | `VCAP1` | `VCAP1_1V2` | Internal Core LDO | `C1` ($2.2\,\mu\text{F}$ `0402` to `GND`) |
| **44** | `BOOT0` | `BOOT0` | DFU Boot Select | `R12` ($10\text{ k}\Omega$ Pull-Down to `GND`) |
| **7** | `NRST` | `NRST` | Active-Low Reset | `C7` ($100\text{ nF}$ Filter Cap to `GND`) |

---

## 4. 4-Channel Brushed N-FET ESC Schematic Details (`Q1–Q4`)

Each of the 4 brushed coreless motor channels (`M1` Rear Right, `M2` Front Right, `M3` Rear Left, `M4` Front Left) uses an identical, ultra-reliable 5-component low-side switching stage:
1. **Motor Positive (`J_Mx Pin 1`):** Tied directly to the solid `VBAT` copper bus ($3.0\text{V–}4.35\text{V}$ from the 1S 300mAh LiHV battery + `C_BULK` $220\,\mu\text{F}$ polymer cap).
2. **Motor Negative (`J_Mx Pin 2`):** Connected to **Pin 3 (Drain)** of `Qx` (`AO3400A`, `SOT-23`).
3. **MOSFET Source (`Qx Pin 2`):** Connected directly to the solid bottom-layer `GND` plane.
4. **MOSFET Gate (`Qx Pin 1`):** Driven by `AT32F435` hardware timer output via a **$100\,\Omega$ gate resistor (`R_Gx`)** to eliminate high-frequency ringing, with a **$10\text{ k}\Omega$ pull-down resistor (`R_PDx`)** to `GND` so the MOSFET stays strictly OFF while the MCU boots or sits in DFU mode.
5. **Inductive Flyback Protection (`D_Mx` + `C26–C29`):** A `B5819WS` ($40\text{V}, 1\text{A}$ Schottky diode in `SOD-123`) + $100\text{ nF}$ ceramic capacitor (`0402`) are placed directly across `J_Mx Pin 2` (Anode) and `J_Mx Pin 1` (`VBAT`, Cathode) to clamp inductive voltage spikes when the $32\text{ kHz}$ PWM switches off and suppress brush commutator RF noise before it can reach the `BMI270` gyro or `SX1280` receiver.
