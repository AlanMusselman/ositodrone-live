================================================================================
PCB MANUFACTURING NOTES: OSITO-FC29-AT32-LITE-LOS (REV 1.1 AUDITED)
Ultra-Low-Cost 2-Layer 1S 300mAh ELRS 2.4GHz Brushed LOS Flight Controller
================================================================================
- Dimensions       : 29.00 mm x 29.00 mm (2.0 mm corner radius)
- Mounting Pattern : 25.50 mm x 25.50 mm Whoop M2 NPTH (4x 2.10 mm holes)
- Layers           : 2 Layers (F.Cu & B.Cu) — Standard JLCPCB $2 Special Eligible!
- Thickness        : 1.00 mm FR4 Standard Tg135-150
- Copper Weight    : 1.0 oz (35 um) Outer Layers
- Surface Finish   : Lead-Free HASL (or ENIG optional)
- Minimum Via Drill: 0.30 mm drill / 0.60 mm pad (No microvia surcharge!)
- Minimum Trace/Gap: 6 mil / 6 mil (0.15 mm / 0.15 mm)
- Stencil          : Top-Side (F.Paste) Single-Pass SMT Stencil with 2x2 windowed
                     QFN thermal apertures on U1 (AT32F435 QFN-48 6x6mm) and U3 (SX1280)
================================================================================
