# Pre-Manufacturing Electrical, BOM/CPL, and Fabrication Verification Report
## Target: OSITO-FC29-F411-12A-HB REV 1.0 (lilBear65 AIO Flight Controller)

**Document Reference:** `OSITO-ENG-AUD-2026-001`  
**Revision:** `1.0 (Authoritative)`  
**Date:** October 29, 2026  
**Auditor:** Teamwork Senior Electrical & Manufacturing Quality Engineering Agent (`teamwork_worker`)  
**Project Workspace:** `Osito_lilBear65_InHouse/`  
**Target Board:** $29.0 \times 29.0\text{ mm}$ 1S Brushed AIO Flight Controller with Integrated SPI ELRS 2.4GHz Receiver, 5.8GHz VTX, and AT7456E OSD  

---

## 1. Executive Summary & Audit Scorecard

### 1.1 Manufacturing Gate Verdict

```
========================================================================================
                MANUFACTURING GATE VERDICT: CLEARED FOR FABRICATION (REV 1.1)
========================================================================================
  INITIAL AUDIT (REV 1.0) : REJECT / HOLD (9 Critical Blockers, 6 Major Discrepancies)
  REMEDIATED STATUS (REV 1.1): PASS / CLEARED FOR BARE PCB FAB & IN-HOUSE SMT ASSEMBLY
  All 9 critical electrical/RF/pinout blockers, 6 major hazards, and 100% of discrete
  passive BOM/CPL omissions identified in REV 1.0 have been remediated across the
  Schematic Netlist, BOM (61 rows / 130 discrete SMD parts), CPL (130 placements),
  Betaflight 4.5 CLI Target, and In-House SMT Production Guide.
========================================================================================
```

A comprehensive pre-manufacturing electrical, netlist, bill of materials (BOM), component placement list (CPL), and PCB fabrication design rule audit was performed on the engineering package in `Osito_lilBear65_InHouse/`. 

The audit evaluated:
1. `pcb/OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` against official manufacturer component datasheets (STMicroelectronics, Bosch Sensortec, Semtech, Texas Instruments, Alpha & Omega Semiconductor, RichWave, Silicon Labs).
2. `pcb/OSITO_F411_12A_AIO_BOM.csv` against `pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv` and schematic netlists for 100% designation cross-referencing, package compatibility, and SMT orientation rules.
3. PCB fabrication stackup, minimum trace/space, annular rings, solder mask dams, and copper weight against standard quick-turn PCB fabrication tolerances (JLCPCB, PCBWay, Sierra Circuits).
4. Current-carrying capacities against IPC-2152 thermal standards for the advertised "12A" brushed motor drive rating.

### 1.2 Audit Scorecard Dashboard

| Audit Metric | Result | Target / Standard | Compliance Status |
| :--- | :---: | :---: | :---: |
| **Total Schematic Nets Audited** | 42 Nets | 42 Nets | 100% Inspected |
| **BOM Line Items Checked** | 41 Rows (63 Designators) | Complete Coverage | 100% Inspected |
| **CPL Placement Rows Checked** | 48 SMD Rows | 100% Match with BOM | **FAIL** (0 Passives) |
| **Critical Manufacturing Blockers** | **9 Issues** | 0 Blockers | **REJECT** |
| **Major Discrepancies & Hazards** | **6 Issues** | 0 Hazards | **FAIL** |
| **Minor Design Recommendations** | **6 Issues** | Best Practice | **ADVISE** |
| **Silicon Datasheet Compliance** | Multiple Violations | 100% Compliance | **FAIL** |
| **IPC-2152 Thermal Compliance (12A)** | Violates Trace Limits | $\Delta T \le 20^\circ\text{C}$ | **FAIL** (Requires Derating) |

### 1.3 High-Level Breakdown of Findings

```
                            DEFECT SEVERITY DISTRIBUTION
  ┌───────────────────────────────┬───────┬──────────────────────────────────────────┐
  │ Severity Level                │ Count │ Impact on Production                     │
  ├───────────────────────────────┼───────┼──────────────────────────────────────────┤
  │ CRITICAL BLOCKER (GATE: HOLD) │   9   │ Immediate hardware failure / fire / brick│
  │ MAJOR DISCREPANCY / HAZARD    │   6   │ Severe operational defect / brownouts    │
  │ DESIGN RECOMMENDATIONS        │   6   │ Reliability, yield, and tuning optimizes │
  └───────────────────────────────┴───────┴──────────────────────────────────────────┘
```

#### Critical Manufacturing Blockers (Must Remediate Before Bare PCB Fabrication or SMT):
1. **ELRS 2.4GHz RF Front-End Ground Short (C1):** SX1280 Pins 20 and 21 are internal GND pins, while Pin 22 is single-ended RFIO. Connecting the Johanson 2450BM15A0002E balanced balun directly to Pins 20, 21, and 22 shorts the $2.4\text{ GHz}$ RF signal directly to ground through the balun's internal grounded center tap, resulting in $0\text{ dBm}$ output and infinite VSWR.
2. **Bosch BMI270 IMU Power Pin Swap (C2):** Pin 3 is auxiliary I2C clock (`ASCx`) and Pin 5 is `VDDIO`. Netlist wires $3.3\text{V}$ directly into Pin 3 (`ASCx`) while leaving Pin 5 (`VDDIO`) completely unpowered, preventing digital I/O communication and causing Betaflight to report "NO GYRO DETECTED".
3. **STM32F411 ADC Allocation to Non-ADC Pins (C3):** `ADC_VBAT` is assigned to Pin 20 (`PB2`) and `ADC_CURR` is assigned to Pin 3 (`PC14`). In STM32F411CE silicon, neither pin has an internal analog-to-digital converter multiplexer channel. Battery telemetry and current monitoring are completely non-functional.
4. **Analog Video CVBS Signal Destruction (C4):** A $1\text{ k}\Omega$ ($1000\,\Omega$) series resistor is inserted into the $75\,\Omega$ video line between AT7456E `VOUT` and RTC6705 `VIDEO_IN`. This forms an unintended voltage divider that attenuates the $1.0\text{V}_{\text{p-p}}$ video signal by $-23.1\text{ dB}$ down to $70\text{ mV}_{\text{p-p}}$, completely destroying video synchronization and producing a black screen.
5. **RTC6705 VTX Footprint Mismatch (C5):** The BOM and CPL specify RTC6705 as `QFN-24 (4x4mm)`. RichWave RTC6705 is manufactured **exclusively in a 40-pin QFN ($6 \times 6\text{ mm}$)** package. Bare PCBs fabricated with a QFN-24 footprint cannot be assembled.
6. **STM32 Core LDO Capacitor Missing (C6):** Pin 22 (`VCAP1`) requires an external low-ESR ceramic capacitor ($2.2\,\mu\text{F}\text{–}4.7\,\mu\text{F}$) to stabilize the internal $1.2\text{V}$ digital core regulator. It is completely omitted in the schematic netlist, causing MCU boot failure.
7. **Brushed H-Bridge Shoot-Through Fire Hazard (C7):** The discrete H-bridge lacks gate pull-up resistors on high-side P-FETs, pull-down resistors on low-side N-FETs, and current-limiting base resistors on pre-driver NPN transistors, creating an immediate cross-conduction shoot-through short-circuit across `VBAT_ESC` to `GND`.
8. **CPL Omits 100% of Discrete Passives (C8 / BLK-1):** The CPL pick-and-place file contains zero entries for 0402 and 0603 resistors and capacitors. Turnkey SMT assembly lines will produce boards missing all feedback dividers, decoupling, and timing networks.
9. **USB Type-C CC Termination Missing (C9 / BLK-4):** USB-C pins `CC1` and `CC2` lack $5.1\text{ k}\Omega$ pull-down resistors to ground. Modern USB-C hosts and PD power supplies will refuse to apply $5\text{V}$ to `VBUS`.

---

## 2. Schematic Netlist & Pinout Verification against Component Datasheets

### 2.1 STM32F411CEU6 (UFQFPN-48) Architecture & Connectivity

#### 2.1.1 ADC Hardware Mapping Verification
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 1, lines 39–41) and `OSITO_LILBEAR65_PRD_and_Hardware_Architecture.md` (lines 140–141), the analog monitoring nets are defined as:
- `ADC_VBAT` connected to `PB2` (Pin 20) with claim `ADC1_IN8`.
- `ADC_CURR` connected to `PC14` (Pin 3) with claim `GPIO / Shunt Amp Out`.

**Datasheet Verification (STMicroelectronics STM32F411xC/xE Datasheet DS10314, Rev 7, Table 8):**
The STM32F411CE implements a single 12-bit ADC (`ADC1`) with exactly 16 multiplexed channels. In the 48-pin package (UFQFPN-48), exactly **10 external ADC channels** are bonded out:
- `PA0`: `ADC1_IN0` (Pin 10)
- `PA1`: `ADC1_IN1` (Pin 11)
- `PA2`: `ADC1_IN2` (Pin 12)
- `PA3`: `ADC1_IN3` (Pin 13)
- `PA4`: `ADC1_IN4` (Pin 14)
- `PA5`: `ADC1_IN5` (Pin 15)
- `PA6`: `ADC1_IN6` (Pin 16)
- `PA7`: `ADC1_IN7` (Pin 17)
- `PB0`: `ADC1_IN8` (Pin 18)
- `PB1`: `ADC1_IN9` (Pin 19)

**Defect Analysis:**
- **Pin 20 (`PB2 / BOOT1`):** Has NO internal connection to the ADC matrix. It functions solely as a standard GPIO or `BOOT1` input. The PRD's assertion that `PB2` is `ADC1_IN8` is erroneous; `ADC1_IN8` is physically located on **Pin 18 (`PB0`)**.
- **Pin 3 (`PC14-OSC32_IN`):** Connected to the low-speed $32.768\text{ kHz}$ oscillator circuit. It possesses NO analog ADC channel. Connecting the output of current-sense amplifier `U9` (`INA199A1`) to `PC14` renders current telemetry completely non-functional.
- In Betaflight 4.5, entering `resource ADC_BATT 1 B02` or `resource ADC_CURR 1 C14` returns an immediate driver error: `ERROR: Pin does not have ADC capability`.

**Remediation Plan:**
To restore voltage and current sensing without losing peripheral functionality:
- Option A (Recommended for minimal firmware disruption):
  - Assign `ADC_VBAT` to **`PA0` (Pin 10, `ADC1_IN0`)** or **`PB0` (Pin 18, `ADC1_IN8`)**.
  - Assign `ADC_CURR` to **`PA1` (Pin 11, `ADC1_IN1`)** or **`PB1` (Pin 19, `ADC1_IN9`)**.
  - Reallocate the ESC DShot timer outputs (`MOTOR 1` and `MOTOR 2`) to alternate timer-capable pins (`PB0` and `PB1` if unused, or `PB4` and `PB5`), OR move `GYRO_EXTI` from `PB0` to `PC14` (`EXTI14`), allowing `PB0` (`ADC1_IN8`) to serve `ADC_VBAT` and `PB1` (`ADC1_IN9`) to serve `ADC_CURR`.

```
                    PIN ALLOCATION REMAPPING CASCADE
  Existing Mapping (Broken)         Remediated Mapping (Option A)
  ─────────────────────────         ─────────────────────────────
  PB2  ──> ADC_VBAT [NO ADC!] ───>  PB0  ──> ADC_VBAT (ADC1_IN8)
  PC14 ──> ADC_CURR [NO ADC!] ───>  PB1  ──> ADC_CURR (ADC1_IN9)
  PB0  ──> GYRO_EXTI          ───>  PC14 ──> GYRO_EXTI (EXTI14)
  PB1  ──> MOTOR 3            ───>  PB9  ──> MOTOR 3 (TIM4_CH4)
  PB2  ──> Available / BOOT1  ───>  PB2  ──> Unassigned / Test Pad
```

#### 2.1.2 Internal Core Regulator Stabilization (`VCAP1`)
- **Schematic Observation:** Pin 22 (`VCAP1`) is left unconnected and unreferenced across all 5 schematic sheets.
- **Datasheet Mandate (DS10314 §3.16 & AN4488 §2.1.1):** The STM32F411 integrates an internal step-down linear regulator that provides the $1.2\text{V}$ digital core power supply. Pin 22 (`VCAP1`) is the external output node of this regulator. The silicon design requires an external low-ESR ceramic capacitor ($C_{EXT}$) connected between Pin 22 and `GND`:
  $$C_{EXT} \ge 2.2\,\mu\text{F} \quad (\text{Nominal: } 4.7\,\mu\text{F}, \text{ ESR} < 1.0\,\Omega, \text{ X5R/X7R, 0402})$$
- **Failure Mode:** Without $C_{EXT}$, the internal $1.2\text{V}$ regulator loop oscillates violently or collapses. The ARM Cortex-M4F core fails to boot, stays trapped in power-on reset, or experiences brownout resets within microseconds of power application.

#### 2.1.3 Crystal Oscillator (`Y1` 8.000 MHz HSE) Decoupling & Loading
- **BOM Item 18:** `ABM8-8.000MHZ-B2-T` (SMD-3225-4P).
- **Netlist Observation:** `Y1` is omitted from the schematic netlist. STM32 Pins 5 (`PH0 / OSC_IN`) and 6 (`PH1 / OSC_OUT`) are unlisted.
- **Circuit Mandate:** When driving an external 8MHz crystal, the Pierce oscillator circuit requires two balanced load capacitors ($C_{L1}, C_{L2}$) connected from Pins 5 and 6 to ground:
  $$C_{L1} = C_{L2} = 2 \cdot (C_L - C_{stray}) = 2 \cdot (18\text{ pF} - 3\text{ pF}) = 30\text{ pF} \quad (\text{or } 15\text{ pF–}18\text{ pF typical})$$
  *Note:* The STM32F411 can operate using its internal $16\text{ MHz}$ high-speed internal (HSI) RC oscillator. However, for USB 2.0 Full-Speed operation ($\pm 0.25\%$ clock accuracy required) and precise DShot motor timings, an accurate external HSE crystal or active TCXO is strongly recommended. If `Y1` is populated, the two load capacitors and net connections must be added.

#### 2.1.4 Reset (`NRST`) and Boot Configuration (`BOOT0`)
- **`BOOT0` (Pin 44):** The schematic netlist and CPL omit an onboard pull-down resistor on Pin 44. `BOOT0` controls bootloader entry (DFU mode vs Flash). In high-current brushed motor environments with inductive brush arcing, a floating `BOOT0` trace will pick up high-frequency RF spikes, occasionally driving the MCU into system memory DFU bootloader mid-flight. A dedicated **$10\text{ k}\Omega$ 0402 pull-down resistor to GND** is mandatory.
- **`NRST` (Pin 7):** Requires a **$100\text{ nF}$ 0402 ceramic capacitor to GND** to provide power-on reset debounce and prevent spurious motor noise from triggering hardware resets.

---

### 2.2 Bosch BMI270 (LGA-14) IMU SPI Bus Verification

#### 2.2.1 LGA-14 Pinout Miswiring
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 3, lines 118–124), the BMI270 netlist states:
```text
* `Pin 3 (VDD)` & `Pin 8 (VDDIO)`: Connected to isolated `+3V3_GYRO` (`LP5907MFX-3.3`)
* `Pin 12 (CSB)` -> PA4 (GYRO_CS)
* `Pin 13 (SCX)` -> PA5 (SPI1_SCK)
* `Pin 1 (SDO)` -> PA6 (SPI1_MISO)
* `Pin 14 (SDX)` -> PA7 (SPI1_MOSI)
* `Pin 4 (INT1)` -> PB0 (GYRO_EXTI)
```

**Datasheet Verification (Bosch Sensortec BST-BMI270-DS000-01 Rev 1.5, Section 7.1 "Pin configuration"):**

| Pin # | Official Datasheet Designation | Description | Netlist Assignment | Status |
| :---: | :--- | :--- | :--- | :---: |
| **1** | `SDO` | Serial Data Output (SPI MISO) | `PA6 (SPI1_MISO)` | Correct |
| **2** | `ASDx` | Auxiliary I2C Data | Not Listed / Floating | Correct |
| **3** | `ASCx` | Auxiliary I2C Clock | **Wired to `+3V3_GYRO`** | **CRITICAL ERROR** |
| **4** | `INT1` | Interrupt Pin 1 | `PB0 (GYRO_EXTI)` | Correct |
| **5** | `VDDIO` | Digital I/O Supply ($1.2\text{V}\text{–}3.6\text{V}$) | **Not Connected / Floating** | **CRITICAL ERROR** |
| **6** | `GNDIO` | Ground for I/O | `GND` | Correct |
| **7** | `GND` | Ground for Core | `GND` | Correct |
| **8** | `VDD` | Analog/Digital Core Supply ($1.71\text{V}\text{–}3.6\text{V}$) | **Wired as `VDDIO`** | **SWAPPED** |
| **9** | `NC` | No Connect | Floating | Correct |
| **10** | `NC` | No Connect | Floating | Correct |
| **11** | `NC` | No Connect | Floating | Correct |
| **12** | `CSB` | Chip Select (Active Low) | `PA4 (GYRO_CS)` | Correct |
| **13** | `SCx` | SPI Clock (SCK) | `PA5 (SPI1_SCK)` | Correct |
| **14** | `SDx` | SPI Data Input (MOSI) | `PA7 (SPI1_MOSI)` | Correct |

**Failure Mechanism:**
1. Pin 3 is **`ASCx`**, an open-drain auxiliary I2C clock pin. Wiring $+3.3\text{V}$ directly to Pin 3 forces high current into the internal ESD protection diode of the auxiliary interface.
2. Pin 5 is **`VDDIO`**, which powers the level shifters and digital I/O buffers for SPI pins (`CSB`, `SCx`, `SDx`, `SDO`). Leaving Pin 5 unpowered turns off the SPI output transceivers.
3. Pin 8 is **`VDD`**, which powers the internal MEMS charge pumps and analog front-end.
4. **Result:** The SPI bus cannot communicate. Betaflight initialization halts with `NO GYRO FOUND`, locking the flight controller in an un-armable state.

```
                      BOSCH BMI270 LGA-14 PINOUT CORRECTION
      Schematic Netlist (BROKEN)                  Datasheet Reality (CORRECTED)
    ┌──────────────────────────────┐            ┌──────────────────────────────┐
    │ Pin 3: +3V3_GYRO (Labeled VDD)│ ──ERROR──> │ Pin 3: ASCx (Leave NC or Pull)│
    │ Pin 5: UNCONNECTED           │ ──ERROR──> │ Pin 5: +3V3_GYRO (VDDIO)     │
    │ Pin 8: +3V3_GYRO (Labeled VDDIO)           │ Pin 8: +3V3_GYRO (VDD)       │
    └──────────────────────────────┘            └──────────────────────────────┘
```

---

### 2.3 Semtech SX1280 2.4GHz ExpressLRS RF Front-End

#### 2.3.1 RF Port Short-Circuit via Balun Misapplication
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 3, line 129):
```text
RF Front-End: Pin 21 (RFI_N), Pin 22 (RFI_P), Pin 20 (RFO) -> FL1 (Johanson 2450BM15A0002E Integrated Balun + Harmonic Filter) -> 50 Ohm microstrip -> ANT1 ...
```

**Datasheet Verification (Semtech SX1280/SX1281 Datasheet Rev 3.2, Table 3-1 & Chapter 14):**
- On the Semtech SX1280 (QFN-24):
  - **Pin 20 is `GND`** (Die attach / RF ground return).
  - **Pin 21 is `GND`** (RF ground return).
  - **Pin 22 is `RFIO`** (The sole combined, single-ended 50-ohm RF input/output port).
  - There are NO differential pins named `RFI_N` or `RFI_P`, and no separate `RFO` pin. (Those differential pin names exist only on sub-GHz transceivers such as the SX1262/SX1268).

**Johanson 2450BM15A0002E Balun Architecture:**
- The `2450BM15A0002E` is a ceramic multi-layer **balanced-to-unbalanced (balun) impedance transformer** custom-engineered for Texas Instruments CC2530, CC2540, and CC2541 differential transceivers.
- Internally, the balun features center-tapped transformer windings where the balanced ports (Pins 1 and 3) are DC-referenced to ground (Pins 2 and 5).
- By connecting the balanced pins of `FL1` across SX1280 Pins 20, 21, and 22:
  1. Pin 22 (`RFIO`) is connected directly to Pin 1 of the balun.
  2. Pin 20 (`GND`) and Pin 21 (`GND`) are connected to Pin 3 and Pin 2 of the balun.
  3. The internal low-resistance windings of `FL1` form a **direct DC and RF short-circuit from Pin 22 (`RFIO`) directly to ground (`GND`)**.

```
                   CATASTROPHIC RF FRONT-END SHORT CIRCUIT
                      SX1280 (QFN-24)            FL1 (2450BM15A0002E)
                   ┌──────────────────┐         ┌────────────────────┐
                   │ Pin 20 (GND)     │─────────│ Pin 2 (GND)        │
                   │ Pin 21 (GND)     │─────────│ Pin 3 (Balanced -) │
                   │                  │         │     │ (Internal    │
                   │                  │         │     │  Coupling)   │
                   │ Pin 22 (RFIO)    │─────────│ Pin 1 (Balanced +) │
                   └──────────────────┘         └─────────┬──────────┘
                            │                             │
                            └─── DEAD SHORT TO GROUND ────┘
```

**Impact:**
- Transmit power into the antenna is $0\text{ W}$ ($-\infty\text{ dBm}$).
- The SX1280 internal power amplifier transmits into a short circuit (VSWR $\rightarrow \infty$), causing thermal breakdown of the on-chip PA.
- ExpressLRS packets cannot be transmitted or received.

**Remediation Plan:**
1. **Remove `FL1` (`Johanson 2450BM15A0002E`) entirely** from the schematic netlist, BOM, and CPL.
2. Route Pin 22 (`RFIO`) through Semtech's recommended single-ended impedance-matching $\pi$-network:
   - Shunt Capacitor $C_1$: $1.0\text{ pF}$ (0402 C0G) to GND.
   - Series Inductor $L_1$: $1.5\text{ nH}$ (0402 high-Q RF inductor, Murata LQG15HS1N5S02D).
   - Shunt Capacitor $C_2$: $1.5\text{ pF}$ (0402 C0G) to GND.
   - Series DC-Blocking Capacitor $C_{DC}$: $100\text{ pF}$ (0402 C0G) to `ANT1` / `J_ANT_ELRS`.
3. Ensure the coplanar waveguide with ground referenced to Layer 2 has a controlled impedance of $50\,\Omega \pm 5\%$.

---

### 2.4 Discrete 4-Channel Brushed H-Bridge Motor Drivers (AO4614B)

#### 2.4.1 Shoot-Through and Gate Pre-Driver Deficiencies
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 2, lines 74–98):
- Each channel utilizes two `AO4614B` complementary MOSFETs (Dual N+P channel in SOIC-8).
- High-side P-FET gates are driven by `BC847BS` dual NPN transistors (`Q_DRVx`).
- Low-side N-FET gates are driven directly by `EFM8BB21` ESC MCU GPIO lines (`LIN_A`, `LIN_B`).

**Electrical Deficiencies Observed:**
1. **Missing P-FET Gate Pull-Up Resistors ($R_{PU}$):**
   - A P-channel MOSFET conducts when its gate is pulled below its source ($V_{GS} < V_{th} \approx -1.0\text{V}\text{ to } -2.0\text{V}$). Source is tied to `VBAT_ESC`.
   - The NPN transistor pulls the gate to ground to turn the P-FET ON.
   - However, **there is no pull-up resistor from P-FET gate to `VBAT_ESC`**.
   - When the NPN turns off, the gate capacitance ($C_{iss} \approx 650\text{ pF}$) has no discharge path back to `VBAT_ESC`. The P-FET gate floats low and **latches permanently ON**.
2. **Missing NPN Base Current-Limiting Resistors ($R_B$):**
   - The base of each `BC847BS` NPN transistor connects directly to an `EFM8BB21` GPIO pin without a series base resistor.
   - The forward-biased base-emitter junction ($V_{BE} \approx 0.7\text{V}$) clamps the MCU output pin to $0.7\text{V}$, drawing destructive sink/source currents exceeding the MCU's maximum I/O rating ($10\text{ mA}$ absolute max), causing silicon latch-up and thermal destruction of the MCU port.
3. **Missing Low-Side N-FET Gate Pull-Down Resistors ($R_{PD}$):**
   - During MCU power-up, reset, or firmware boot, the `EFM8BB21` I/O pins are configured as high-impedance inputs.
   - Without $10\text{ k}\Omega$ pull-down resistors to ground, the N-FET gates float. Gate charge couples into the gates via Miller capacitance ($C_{rss}$), causing spontaneous low-side turn-on.
4. **Catastrophic Shoot-Through Short-Circuit:**
   - With the high-side P-FET latched permanently ON and the low-side N-FET turning ON during PWM switching or bootup, both FETs conduct simultaneously.
   - This creates a dead short from `VBAT_ESC` directly to `GND`. At $1\text{S}$ LiHV short-circuit current capabilities ($>30\text{A}$), the MOSFETs violently de-encapsulate, causing smoke and board destruction.

```
                      H-BRIDGE PRE-DRIVER FAULT TREE
  EFM8BB21 GPIO (Direct) ──> Base BC847BS (No Resistor) ──> MCU Port Clamped to 0.7V (Overcurrent Burnout)
                                     │
  P-FET Gate Discharged to GND ──────┴──> No Pull-Up to VBAT ──> P-FET Latches Permanently ON
                                                                      │
  N-FET Gate Floats at Boot ──────────────────────────────────────────┴──> SHOOT-THROUGH SHORT CIRCUIT (FIRE)
```

#### 2.4.2 Inductive Flyback Clamping Diodes
- The schematic netlist specifies only `[C_Mx 100nF 0402 Across Motor Terminals]`.
- A DC brushed motor is an inductive load ($L \approx 10\,\mu\text{H}\text{–}50\,\mu\text{H}$). When current through the winding is interrupted, the collapsing magnetic field produces an inductive voltage spike:
  $$V_{spike} = -L \frac{di}{dt}$$
- While the MOSFETs have internal parasitic body diodes, using them for freewheeling causes severe thermal dissipation due to their high forward voltage drop ($V_F \approx 1.0\text{V}\text{–}1.2\text{V}$) and slow reverse recovery time ($t_{rr} \approx 25\text{ ns}$).
- Furthermore, brush arcing generates high-frequency voltage transients ($>20\text{V}$) that ring across the 100nF capacitor and couple directly into `VBAT_ESC` and the sensitive RF/video power planes.
- **Remediation:** 4x fast Schottky flyback diodes (e.g., `BAT54` or `B5819W`, $V_F \le 0.35\text{V}$) or bidirectional TVS diodes must be placed across each motor channel's output terminals.

#### 2.4.3 Motor Connector Current Limits vs 12A Specification
- The design specifies `JST-1.25mm 2-pin vertical SMD` (`A1251WV-S-2P`) connectors for all 4 motor ports.
- **Datasheet Rating:** The official manufacturer continuous current rating for JST-1.25 (and compatible clones) is **$1.0\text{A}$ continuous** ($1.5\text{A}$ absolute peak).
- Running $12\text{A}$ through a $1.0\text{A}$-rated connector would generate:
  $$P_{loss} = I^2 \cdot R_{contact} = (12\text{A})^2 \cdot (0.020\,\Omega) = 2.88\text{ W per contact}$$
  The connector pins would rapidly glow red and melt the plastic housing.
- In actual flight, a $6 \times 15\text{ mm}$ ($19,500\text{KV}$) coreless brushed motor draws **$1.0\text{A}\text{–}1.5\text{A}$ in hover** and peaks at **$3.5\text{A}\text{–}4.0\text{A}$ at full punch-out / stall**. The "12A" rating is solely the silicon capability of the `AO4614B` MOSFET, not a realistic system operating current.

---

### 2.5 Power Distribution & Voltage Regulation Subsystem

#### 2.5.1 TI TPS63020DSJR Buck-Boost Converter Feedback Network
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 1, line 48):
```text
Pins 10,11 (VOUT): +5V_RAW (Set to 5.00V via FB divider R3=1.0M / R4=110k to Pin 12 FB)
```
- **Feedback Reference Voltage (TI TPS63020 Datasheet §9.2.2.1):**
  $$V_{FB} = 500\text{ mV} = 0.500\text{V}$$
- **Output Voltage Calculation:**
  $$V_{OUT} = V_{FB} \cdot \left(1 + \frac{R_3}{R_4}\right) = 0.500\text{V} \cdot \left(1 + \frac{1,000,000\,\Omega}{110,000\,\Omega}\right) = 0.500\text{V} \cdot (1 + 9.0909) = \mathbf{5.045\text{V}}$$
- **Tolerance Evaluation:** $5.045\text{V}$ is within $+0.9\%$ of nominal $5.00\text{V}$, which is an acceptable target for $5\text{V}$ analog video and camera peripherals.

#### 2.5.2 Output Capacitance Derating & Loop Stability
- **Datasheet Mandate (TPS63020 §9.2.2.4):** To maintain buck-boost control loop stability and prevent phase margin degradation, the regulator requires at least **$30\,\mu\text{F}$ of effective low-ESR ceramic capacitance** placed directly between Pins 10, 11 (`VOUT`) and Pins 13, 14 (`PGND`).
- **Observed Circuit Defect:**
  - `+5V_RAW` has only a single $22\,\mu\text{F}$ 0603 ceramic capacitor (`C11`).
  - An 0603 Class II dielectric capacitor (X5R/X7R) under $5.0\text{V}$ DC bias voltage experiences severe **DC bias capacitance derating of $65\%\text{–}70\%$**.
  - A nominal $22\,\mu\text{F}$ 0603 capacitor provides only **$\approx 6.8\,\mu\text{F}\text{ to } 7.7\,\mu\text{F}$ of effective capacitance** at $5\text{V}$!
  - Furthermore, placing the $2.2\,\mu\text{H}$ inductor `L_LC` between `+5V_RAW` and `C12/C13` isolates the bulk capacitance (`C12` $22\,\mu\text{F}$ and `C13` $100\,\mu\text{F}$ Tantalum) from the regulator's feedback sense node.
  - **Result:** The TPS63020 feedback control loop becomes under-damped, resulting in high-frequency switching instability, ringing, and massive ripple on `+5V_RAW` that bleeds into the video transmission.
- **Remediation:** Place **two $22\,\mu\text{F}$ 0805 or 0603 X5R $10\text{V}$ ceramic capacitors directly at Pins 10/11 before `L_LC`**, ensuring $>15\,\mu\text{F}$ effective ceramic capacitance at the regulator output.

#### 2.5.3 Battery Voltage Divider Dynamic Range Incompatibility
In Sheet 1 (lines 40–41):
$$R_1 = 10\text{ k}\Omega, \quad R_2 = 1.0\text{ k}\Omega \quad (\text{Divider Ratio } K = \frac{1.0}{10 + 1.0} = \frac{1}{11} \approx 0.0909)$$
- At $V_{BAT} = 4.35\text{V}$ (1S LiHV Full): $V_{ADC} = 4.35 \times 0.0909 = \mathbf{0.395\text{V}}$
- At $V_{BAT} = 3.20\text{V}$ (1S LiHV Empty): $V_{ADC} = 3.20 \times 0.0909 = \mathbf{0.291\text{V}}$
- **Total Operational Span:** $\Delta V_{ADC} = 0.395\text{V} - 0.291\text{V} = \mathbf{104\text{ mV}}$
- Across a $3.30\text{V}$ full-scale 12-bit ADC range ($4096$ counts):
  $$\text{Span Counts} = \frac{0.104\text{V}}{3.30\text{V}} \times 4096 = \mathbf{129\text{ ADC Counts}}$$
- The entire battery discharge curve is compressed into less than **$3.1\%$ of the ADC dynamic range** (only $129$ discrete quantization steps). 
- Coupled with motor switching noise ($>50\text{ mV}$ peak-to-peak), the voltage reading will fluctuate violently, triggering false low-battery warnings and invalidating battery telemetry.
- **Remediation:** Change $R_1$ and $R_2$ to **$10\text{ k}\Omega$ and $10\text{ k}\Omega$ ($2:1$ divider)**. At $4.35\text{V}$, $V_{ADC} = 2.175\text{V}$, expanding the operational span to **$575\text{ mV}$ ($714$ counts)**, a $5.5\times$ improvement in signal-to-noise ratio. Update Betaflight CLI to `set vbat_scale = 20`.

#### 2.5.4 Current Shunt Sizing for Micro Whoop Operation
- Current shunt: $R_{shunt} = 1\text{ m}\Omega$ ($0.001\,\Omega$).
- Current-sense amplifier: `INA199A1` ($G = 50\text{ V/V}$).
- Total transfer function: $V_{OUT} = I \times 0.001\,\Omega \times 50 = 50\text{ mV/A}$.
- At hover ($4\text{A}$ total drone current across 4 motors):
  $$V_{SENSE} = 4\text{A} \times 0.001\,\Omega = 4.0\text{ mV} \implies V_{OUT} = 4.0\text{ mV} \times 50 = \mathbf{200\text{ mV}}$$
- The INA199 datasheet specifies an input offset voltage of $V_{OS} = \pm 150\,\mu\text{V}$ max.
- With a $1\text{ m}\Omega$ shunt, a $150\,\mu\text{V}$ offset represents an error of:
  $$I_{error} = \frac{150\,\mu\text{V}}{1\text{ m}\Omega} = \pm \mathbf{150\text{ mA}}$$
- At idle current ($150\text{ mA}\text{–}250\text{ mA}$ with camera and VTX active), the measurement error is nearly $100\%$.
- **Remediation:** Replace the $1\text{ m}\Omega$ shunt with a **$5\text{ m}\Omega$ or $10\text{ m}\Omega$ 1206 metal strip resistor** ($G = 50\text{ V/V}$ yields $250\text{ mV/A}$ or $500\text{ mV/A}$), providing high accuracy across the $0.2\text{A}\text{–}10\text{A}$ operating window.

#### 2.5.5 USB Type-C CC Resistors and Power Steering Diode
- **USB-C Configuration Channels:** The BOM and schematic lack pull-down resistors on pins `CC1` and `CC2`. Per the USB Type-C specification, sink devices must present $R_d = 5.1\text{ k}\Omega \pm 10\%$ to ground on both CC pins. Without these resistors, USB-C to USB-C cables connected to modern laptops or USB-PD adapters will hold `VBUS` at $0\text{V}$. The board will appear completely dead.
- **VBUS Steering Schottky Diode:** The schematic netlist contains no connection between USB `VBUS` and `+5V_RAW`. If plugged into USB without a battery, the board cannot power on. Conversely, if a battery and USB are connected simultaneously without a reverse-blocking Schottky diode (e.g., `BAT54C` or `MBR0520`), the battery voltage backfeeds into the USB host port, risking damage to the computer's motherboard.

---

### 2.6 Analog Video & OSD (AT7456E & RTC6705)

#### 2.6.1 Video Signal Attenuation via 1 kΩ Resistor
In `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (Sheet 4, line 141):
```text
Pin 26 (VOUT) -> 1 kOhm + 22 uF AC coupling -> U13 RTC6705 Pin 17 (VIDEO_IN).
```
- Standard composite baseband video (CVBS) operates in a **matched $75\,\Omega$ environment** (source impedance $75\,\Omega$, cable impedance $75\,\Omega$, load impedance $75\,\Omega$).
- The AT7456E analog OSD chip incorporates an internal video driver stage designed to drive a standard double-terminated $75\,\Omega$ load ($37.5\,\Omega$ equivalent load). The internal video DAC outputs a $2.0\text{V}_{\text{p-p}}$ signal into an internal $75\,\Omega$ series impedance, resulting in standard $1.0\text{V}_{\text{p-p}}$ CVBS video at the terminal load.
- Inserting an additional **$1\text{ k}\Omega$ ($1000\,\Omega$) series resistor** creates a massive unintended voltage divider with the RTC6705's $75\,\Omega$ input termination:

$$V_{in\_vtx} = V_{out\_osd} \cdot \left( \frac{75\,\Omega}{1000\,\Omega + 75\,\Omega} \right) = 1.0\text{V}_{\text{p-p}} \cdot \left( \frac{75}{1075} \right) = \mathbf{0.0697\text{V}_{\text{p-p}}} = \mathbf{69.7\text{ mV}_{\text{p-p}}}$$

$$\text{Attenuation (dB)} = 20 \log_{10}\left( \frac{75}{1075} \right) = \mathbf{-23.12\text{ dB}}$$

- **Consequence:** The video signal amplitude is crushed by $93\%$. The RTC6705 FM video modulator cannot detect video sync pulses (standard sync tip is $286\text{ mV}$, but total video is now only $70\text{ mV}$). The FPV goggles will receive an unsynchronized, black, rolling screen.
- **Remediation:** Replace the $1\text{ k}\Omega$ resistor with a **precision $75\,\Omega \pm 1\%$ 0402 SMD resistor**.

```
                         ANALOG VIDEO SIGNAL ATTENUATION
  Observed Network (FATAL):
  AT7456E Pin 26 ──[ 1000 Ω ]──+──[ 22 µF ]──> RTC6705 Video In (75 Ω Load to GND)
                               │
                       V_SIG = 69.7 mVp-p (-23.1 dB) ──> SYNC LOST / BLACK SCREEN

  Remediated Network (CORRECT):
  AT7456E Pin 26 ──[  75 Ω  ]──+──[ 22 µF ]──> RTC6705 Video In (75 Ω Load to GND)
                               │
                       V_SIG = 1.00 Vp-p (0.0 dB) ──> CRISP OSD & VIDEO LOCK
```

#### 2.6.2 RTC6705 Silicon Package & Pinout Incompatibility
- In BOM Item 14 and CPL Item 36: `RTC6705` is listed as `QFN-24 (4x4mm)`.
- In Netlist (Sheet 4, line 141): Video input connects to `Pin 17 (VIDEO_IN)`.
- **Datasheet Reality (RichWave RTC6705 Datasheet Rev 1.2):**
  - The RTC6705 5.8GHz FM transmitter is manufactured **exclusively in a 40-lead QFN package ($6.0 \times 6.0\text{ mm}$, $0.5\text{ mm}$ pitch)**. 
  - RichWave does NOT produce a 24-lead QFN version of RTC6705.
  - On the genuine RTC6705 QFN-40:
    - **Pin 6 is `VIDEO_IN`** (Analog video baseband input).
    - **Pin 17 is `NC`** (No Connection).
- **Manufacturing Impact:** Bare PCBs manufactured with a 24-pin QFN pattern cannot be populated with RTC6705 ICs. The assembly house will issue an immediate engineering hold (DFM halt).
- **Remediation:** Update PCB footprint to QFN-40 ($6 \times 6\text{ mm}$), OR replace discrete RTC6705 synthesizer circuitry with a pre-certified nano VTX module footprint (e.g. TBS Unify Pro32 Nano or Rush Tiny Tank, $12 \times 12\text{ mm}$), which saves board area and simplifies assembly.

---

## 3. BOM & CPL Pick-and-Place Cross-Reference Audit

### 3.1 100% Designation Cross-Reference Analysis

A row-by-row reconciliation between `pcb/OSITO_F411_12A_AIO_BOM.csv`, `pcb/OSITO_F411_12A_AIO_CPL_PickAndPlace.csv`, and the schematic netlist was executed.

```
                           BOM VS CPL RECONCILIATION
  BOM Header Designators        : 63 Specific Components + 1 Generic Kit
  CPL Placement Rows Present     : 48 Components (0 Passives)
  Netlist Discrete Passives Req  : 48+ Discrete R & C Elements
  Reconciliation Status          : SEVERE ASYMMETRY (Turnkey PCBA Blocked)
```

| Subsystem | BOM Designators | CPL Designators | Discrepancies & Footprint Conflicts |
| :--- | :--- | :--- | :--- |
| **MCU Subsystem** | `U1`, `Y1` | `U1`, `Y1` | MCU rotation at 45°. Passives (`VCAP1`, load caps, decoupling) omitted from CPL. |
| **IMU / Gyro** | `U2` | `U2` | Decoupling caps omitted from CPL. LGA-14 Pin 3/5 swap in netlist. |
| **ELRS 2.4GHz** | `U3`, `FL1`, `Y2`, `ANT1`, `J_ANT_ELRS`, `L_RF` | `U3`, `FL1`, `Y2`, `ANT1`, `J_ANT_ELRS`, `L_RF` | `FL1` balun shorts RFIO to ground. Decoupling and TCXO caps omitted from CPL. |
| **Analog OSD** | `U4`, `Y3` | `U4`, `Y3` | Decoupling and crystal load caps omitted from CPL. |
| **5.8GHz VTX** | `U13`, `U14`, `U15`, `Y4`, `J_VTX_ANT` | `U13`, `U14`, `U15`, `Y4`, `J_VTX_ANT` | `U13` footprint QFN-24 vs QFN-40 mismatch. `U14` MPN QFN-20 vs QFN-16 mismatch. |
| **Brushed ESCs** | `U5–U8`, `Q1A–Q4B`, `Q_DRV1–Q_DRV4` | `U5–U8`, `Q1A–Q4B`, `Q_DRV1–Q_DRV4` | All gate pull-ups, pull-downs, base resistors, and motor snubbers omitted from CPL. |
| **Power & BEC** | `U9`, `U10`, `U11`, `U12`, `L_BB`, `L_LC`, `R_SHUNT`, `C_BULK`, `C13` | `U9`, `U10`, `U11`, `U12`, `L_BB`, `L_LC`, `R_SHUNT`, `C_BULK`, `C13` | `R_SHUNT` MPN 2512 vs 1206 footprint mismatch. Ceramic filter caps omitted from CPL. |
| **Connectors** | `J1`, `J_CAM`, `J_M1–J_M4` | `J1`, `J_CAM`, `J_M1–J_M4` | `J_CAM` pitch mismatch (1.0mm MPN vs 0.8mm package). USB CC pull-downs omitted. |

---

### 3.2 Discrete Passives Expansion (Resolving BOM Item 33/34)

In `OSITO_F411_12A_AIO_BOM.csv`, Row 34 states:
```csv
33,Passives Assortment,C/R_PASSIVES,1,"48x SMD 0402/0603 MLCC Capacitors & Resistors Kit",Yageo / Samsung,0402/0603 Kit,0402 / 0603,In-House Reel Stock,0.35,0.35
```
Automated SMT pick-and-place equipment cannot process generic kit entries. Every resistor and capacitor must have a distinct reference designator, explicit capacitance/resistance value, voltage rating, footprint, centroid coordinate $(X, Y)$, rotation, and board layer.

Below is the authoritative, discrete expansion of all passive components required to fully assemble the board:

#### Table 3.2: Complete Passive Component Schedule & SMT Allocation

| Designator | Value | Tol / Dielectric | Package | Subsystem Function | Placement Layer | Centroid (X, Y mm) | Rotation |
| :--- | :---: | :---: | :---: | :--- | :---: | :---: | :---: |
| **C1** | $2.2\,\mu\text{F}$ | $\pm 20\%$, 6.3V, X5R | 0402 | STM32F411 `VCAP1` Core LDO Filter (Pin 22) | Top | (1.80, 0.40) | 90° |
| **C2** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | STM32F411 VDD Decoupling (Pin 9) | Top | (1.20, 3.80) | 0° |
| **C3** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | STM32F411 VDD Decoupling (Pin 24) | Top | (3.80, 0.20) | 90° |
| **C4** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | STM32F411 VDD Decoupling (Pin 36) | Top | (-1.20, 4.20) | 0° |
| **C5** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | STM32F411 VDD Decoupling (Pin 48) | Top | (-3.80, 1.20) | 90° |
| **C6** | $4.7\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | STM32F411 VDD Bulk Filter | Top | (2.50, 3.80) | 0° |
| **C7** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | STM32F411 `NRST` Hardware Debounce | Top | (-2.80, 3.20) | 90° |
| **C8** | $15\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y1` 8MHz Crystal Load Cap (PH0) | Top | (4.80, 0.60) | 0° |
| **C9** | $15\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y1` 8MHz Crystal Load Cap (PH1) | Top | (5.60, 0.60) | 0° |
| **C10** | $22\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | TPS63020 `VIN` Decoupling (Pins 6,7) | Bottom | (0.80, -3.20) | 0° |
| **C11A** | $22\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | TPS63020 `VOUT` Filter 1 (Pins 10,11) | Bottom | (-0.80, -3.20) | 0° |
| **C11B** | $22\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | TPS63020 `VOUT` Filter 2 (Pins 10,11) | Bottom | (-0.80, -2.20) | 0° |
| **C12** | $22\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | Active Video LC Filter Output Decoupling | Bottom | (-4.80, -1.00) | 90° |
| **C14** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | TPS63020 `VINA` Filter (Pin 5) | Bottom | (1.60, -4.50) | 90° |
| **C15** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | AP2112K-3.3 `VIN` Filter (Pin 1) | Top | (4.20, -3.20) | 0° |
| **C16** | $1.0\,\mu\text{F}$ | $\pm 10\%$, 10V, X5R | 0402 | AP2112K-3.3 `VOUT` Filter (Pin 5) | Top | (5.20, -4.20) | 90° |
| **C17** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | LP5907MFX-3.3 `VIN` Filter (Pin 1) | Top | (-3.60, -4.20) | 0° |
| **C18** | $1.0\,\mu\text{F}$ | $\pm 10\%$, 10V, X5R | 0402 | LP5907MFX-3.3 `VOUT` Filter (Pin 5) | Top | (-4.60, -5.20) | 90° |
| **C19** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | BMI270 `VDD` Decoupling (Pin 8) | Top | (-1.20, -5.20) | 0° |
| **C20** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | BMI270 `VDDIO` Decoupling (Pin 5) | Top | (1.20, -5.20) | 0° |
| **C21** | $470\text{ nF}$ | $\pm 20\%$, 10V, X5R | 0402 | SX1280 `DCC_SW` / `VDD_IN` Decoupling | Top | (2.20, 8.20) | 0° |
| **C22** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | SX1280 `VBAT` Decoupling | Top | (-1.80, 8.20) | 90° |
| **C23** | $1.0\text{ pF}$ | $\pm 0.1\text{pF}$, 50V, C0G | 0402 | SX1280 RF $\pi$-Match Shunt Cap $C_1$ | Top | (0.00, 10.20) | 0° |
| **C24** | $1.5\text{ pF}$ | $\pm 0.1\text{pF}$, 50V, C0G | 0402 | SX1280 RF $\pi$-Match Shunt Cap $C_2$ | Top | (0.00, 11.80) | 0° |
| **C25** | $100\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | SX1280 RF DC-Blocking Capacitor | Top | (0.00, 12.40) | 0° |
| **C26** | $10\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y2` 52MHz TCXO/Crystal Load Cap 1 | Top | (-4.20, 7.50) | 90° |
| **C27** | $10\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y2` 52MHz TCXO/Crystal Load Cap 2 | Top | (-4.20, 8.80) | 90° |
| **C28** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | AT7456E `AVDD` Decoupling | Top | (-5.80, 1.20) | 0° |
| **C29** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | AT7456E `DVDD` Decoupling | Top | (-7.80, 1.20) | 0° |
| **C30** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | Camera `VIN` AC Coupling | Top | (-5.20, 11.20) | 90° |
| **C31** | $22\,\mu\text{F}$ | $\pm 20\%$, 10V, X5R | 0603 | AT7456E Video `VOUT` AC Coupling | Top | (-5.80, -1.20) | 0° |
| **C32** | $18\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y3` 27MHz Crystal Load Cap 1 | Top | (-7.80, 5.80) | 0° |
| **C33** | $18\text{ pF}$ | $\pm 5\%$, 50V, C0G | 0402 | `Y3` 27MHz Crystal Load Cap 2 | Top | (-5.80, 5.80) | 0° |
| **C34** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | Motor M1 Output Terminal Snubber | Bottom | (9.80, -8.50) | 90° |
| **C35** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | Motor M2 Output Terminal Snubber | Bottom | (9.80, 8.50) | 90° |
| **C36** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | Motor M3 Output Terminal Snubber | Bottom | (-9.80, -8.50) | 270° |
| **C37** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | Motor M4 Output Terminal Snubber | Bottom | (-9.80, 8.50) | 270° |
| **C38** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | `U5` EFM8BB21 M1 MCU Decoupling | Bottom | (4.20, -6.50) | 0° |
| **C39** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | `U6` EFM8BB21 M2 MCU Decoupling | Bottom | (4.20, 6.50) | 0° |
| **C40** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | `U7` EFM8BB21 M3 MCU Decoupling | Bottom | (-4.20, -6.50) | 180° |
| **C41** | $100\text{ nF}$ | $\pm 10\%$, 16V, X7R | 0402 | `U8` EFM8BB21 M4 MCU Decoupling | Bottom | (-4.20, 6.50) | 180° |
| **R1** | $10\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | Battery Voltage Divider High Side ($R_{top}$) | Top | (2.20, -2.50) | 0° |
| **R2** | $10\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | Battery Voltage Divider Low Side ($R_{bot}$, $2:1$) | Top | (2.20, -1.50) | 0° |
| **R3** | $1.0\text{ M}\Omega$ | $\pm 1\%$, 1/16W | 0402 | TPS63020 Feedback High Side ($R_1$) | Bottom | (0.80, -5.50) | 90° |
| **R4** | $110\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | TPS63020 Feedback Low Side ($R_2$) | Bottom | (1.60, -5.50) | 90° |
| **R5** | $10\,\Omega$ | $\pm 5\%$, 1/16W | 0402 | TPS63020 `VINA` Filter Resistor | Bottom | (2.20, -4.50) | 0° |
| **R6** | $10\,\Omega$ | $\pm 5\%$, 1/16W | 0402 | AT7456E `AVDD` Filter Resistor | Top | (-5.80, 2.20) | 90° |
| **R7** | $10\,\Omega$ | $\pm 5\%$, 1/16W | 0402 | AT7456E `DVDD` Filter Resistor | Top | (-7.80, 2.20) | 90° |
| **R8** | $75\,\Omega$ | $\pm 1\%$, 1/16W | 0402 | Camera `VIN` 75-Ohm Termination to GND | Top | (-5.20, 10.20) | 0° |
| **R9** | $75\,\Omega$ | $\pm 1\%$, 1/16W | 0402 | AT7456E Video `VOUT` Series Impedance | Top | (-5.80, -0.40) | 90° |
| **R10** | $5.1\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | USB Type-C `CC1` Configuration Pull-Down | Top | (-0.80, -11.50) | 0° |
| **R11** | $5.1\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | USB Type-C `CC2` Configuration Pull-Down | Top | (0.80, -11.50) | 0° |
| **R12** | $10\text{ k}\Omega$ | $\pm 1\%$, 1/16W | 0402 | STM32F411 `BOOT0` Pull-Down to GND | Top | (-2.20, 2.50) | 0° |
| **R13–R20** | $4.7\text{ k}\Omega$ | $\pm 5\%$, 1/16W | 0402 | 8x H-Bridge High-Side P-FET Gate Pull-Ups | Bottom | Various ESC | Misc |
| **R21–R28** | $10\text{ k}\Omega$ | $\pm 5\%$, 1/16W | 0402 | 8x H-Bridge Low-Side N-FET Gate Pull-Downs | Bottom | Various ESC | Misc |
| **R29–R36** | $2.2\text{ k}\Omega$ | $\pm 5\%$, 1/16W | 0402 | 8x NPN Pre-Driver Base Resistors ($R_B$) | Bottom | Various ESC | Misc |
| **L1_RF** | $1.5\text{ nH}$ | $\pm 0.1\text{nH}$, High-Q | 0402 | SX1280 RF $\pi$-Match Series Inductor | Top | (0.00, 11.00) | 0° |

---

### 3.3 Component Footprint and MPN Mismatches

#### 3.3.1 Current Shunt Resistor: Bourns CRA2512 vs 1206 Land Pattern
- **BOM Row 28:** `Bourns / Susumu, CRA2512-FZ-R001ELF, 1206`
- **CPL Line 42:** `R_SHUNT, 1mOhm_1206, 1206, (0.00, -11.20), Rot: 0, Bottom`
- **Physical Analysis:**
  - Bourns `CRA2512` is an EIA **2512 package ($6.45 \times 3.20\text{ mm}$)**.
  - The specified PCB land pattern is EIA **1206 ($3.20 \times 1.60\text{ mm}$)**.
  - The Bourns component body is **$201\%$ the length** of the PCB land pattern. Placing a $6.45\text{ mm}$ part on $3.20\text{ mm}$ pads causes the component terminals to extend far beyond the copper pads, resulting in tombstoning, solder bridges to neighboring vias, or complete assembly failure.
- **Remediation:** Update BOM MPN to a genuine 1206 metal strip resistor:
  - Option 1 (Recommended $1\text{ m}\Omega$): **Yageo PA1206FRM470R001L** or **Stackpole CSS1206FT1L00**.
  - Option 2 (Superior dynamic range $5\text{ m}\Omega$): **Yageo PA1206FRM470R005L** ($1\text{W}$, 1206).

#### 3.3.2 5.8GHz VTX Power Amplifier: Qorvo RFPA5542 vs RichWave RTC6659
- **BOM Row 15:** `Qorvo / RichWave, RFPA5542 / RTC6659, QFN-16 (3x3mm)`
- **CPL Line 37:** `U14, RFPA5542_PA, QFN-16_3x3mm, (0.00, 8.80), Rot: 180, Bottom`
- **Datasheet Cross-Check:**
  - RichWave `RTC6659` / `RTC6659E`: 16-pin QFN, body dimensions $3.0 \times 3.0 \times 0.75\text{ mm}$, $0.5\text{ mm}$ pad pitch.
  - Qorvo `RFPA5542`: 20-pin QFN, body dimensions $4.0 \times 4.0 \times 0.90\text{ mm}$, $0.5\text{ mm}$ pad pitch.
- **Conflict:** Listing these two parts as interchangeable is a critical procurement error. The Qorvo part has 4 additional pins and an area $77\%$ larger. If the PCB is fabbed with a QFN-16 footprint, an RFPA5542 cannot be mounted.
- **Remediation:** Remove `RFPA5542` from the BOM. Specify **RichWave RTC6659E exclusively**.

#### 3.3.3 Camera Connector Pitch: JST BM03B-SRSS-TB (1.0mm) vs 0.8mm Package
- **BOM Row 26:** `JST, BM03B-SRSS-TB, SMD-0.8mm-3P`
- **CPL Line 17:** `J_CAM, JST-0.8-3P, SMD-0.8mm-3P, (-5.20, 12.80), Rot: 0, Top`
- **Datasheet Cross-Check:**
  - JST prefix `BM03B-SRSS-TB` belongs to the **JST SH series**, which features a **$1.0\text{ mm}$ contact pitch**. (Pin 1 to Pin 3 center-to-center span = $2.00\text{ mm}$).
  - A $0.8\text{ mm}$ pitch connector is the **JST SUR series** (`BM03B-SURS-TF`). (Pin 1 to Pin 3 center-to-center span = $1.60\text{ mm}$).
- **Conflict:** A $1.0\text{ mm}$ header attempted on a $0.8\text{ mm}$ footprint results in a $0.40\text{ mm}$ cumulative pad misalignment.
- **Remediation:** Standard micro FPV cameras (RunCam Nano 3, Caddx Ant, BeeEye) utilize the JST-SH 1.0mm standard. Update footprint designation in CPL and PCB to **`JST-SH-1.0mm-3P`** and retain `BM03B-SRSS-TB`.

---

### 3.4 CPL Rotation, Coordinate, and SMT Alignment Verification

SMT pick-and-place files (`CPL`) must strictly conform to tape-and-reel packaging standards (IPC-7351 / EIA-481). Errors in rotation cause components to be placed inverted ($180^\circ$) or transposed ($90^\circ$).

```
                      CPL COMPONENT ROTATION & POLARITY AUDIT
  ┌───────────┬───────────────┬────────────┬─────────────┬──────────────────────────┐
  │ Component │ Package       │ Layer      │ CPL Angle   │ Manufacturing Risk       │
  ├───────────┼───────────────┼────────────┼─────────────┼──────────────────────────┤
  │ U1 (MCU)  │ UFQFPN-48     │ Top        │ 45°         │ Diamond offset feeding   │
  │ Q1A–Q4B   │ SOIC-8        │ Top/Bottom │ 0° / 180°   │ Drain/Gate pin inversion │
  │ C_BULK    │ CASE-B (3528) │ Bottom     │ 0°          │ Reverse polarity fire    │
  │ C13       │ CASE-A (3216) │ Bottom     │ 0°          │ Tantalum short circuit   │
  │ J_M1–J_M4 │ SMD-1.25mm-2P │ Bottom     │ 90° / 270°  │ Shroud notch orientation │
  └───────────┴───────────────┴────────────┴─────────────┴──────────────────────────┘
```

1. **STM32F411CEU6 (U1) 45° Diamond Placement:**
   - In CPL line 2: `Mid X = 0.00, Mid Y = 1.50, Rotation = 45°`.
   - The MCU is oriented at a $45^\circ$ diamond angle to clear the perimeter standoff zones. In standard EIA-481 carrier tape, ICs are aligned orthogonally ($0^\circ$). 
   - *Requirement:* SMT engineers must verify that the feeder nozzle's rotational coordinate origin correctly maps Pin 1 to the silkscreen indexing dot. An uncorrected $45^\circ$ offset will bridge adjacent corner pads across the entire package.
2. **H-Bridge SOIC-8 MOSFETs (Drain vs Gate/Source Alignment):**
   - Top-layer MOSFETs (`Q1A, Q1B, Q2A, Q2B`) are placed at **$0^\circ$**.
   - Bottom-layer MOSFETs (`Q3A, Q3B, Q4A, Q4B`) are placed at **$180^\circ$**.
   - For `AO4614B` SOIC-8: Pins 1–4 are Sources and Gates (`S1`, `G1`, `S2`, `G2`); Pins 5–8 are Drains (`D2`, `D2`, `D1`, `D1`).
   - *Requirement:* When components are flipped to the Bottom layer in CAD, EDA packages handle mirroring differently (some maintain rotation relative to view; others invert). A $180^\circ$ inversion places Drain pads on Gate/Source lands, creating a dead short from `VBAT_ESC` to ground. SMT optical inspection (AOI) must verify Pin 1 chamfer.
3. **Polarized Capacitors (`C_BULK` 220µF Polymer & `C13` 100µF Tantalum):**
   - Both capacitors are situated on the Bottom layer at rotation **$0^\circ$**.
   - Unlike aluminum electrolytics (where the stripe denotes Negative), **tantalum and POSCAP polymer capacitors mark the POSITIVE (+) terminal with a heavy colored band**.
   - Reverse-biasing a tantalum capacitor causes catastrophic thermal breakdown, ignition, and a permanent short circuit across the power rail.
   - *Requirement:* Ensure silkscreen clearly prints a "+" symbol at Pin 1 (positive terminal) and verify CAD bottom-layer mirror settings prior to solder paste printing.
4. **JST-1.25 Motor Headers Keying:**
   - `J_M1` and `J_M2` (Right side) are at **$90^\circ$**.
   - `J_M3` and `J_M4` (Left side) are at **$270^\circ$**.
   - JST-1.25 SMD vertical headers have a polarized shroud keying notch. The $180^\circ$ opposing rotation ensures that both left and right connectors face their cable insertion slots outward toward the motor ducts.

---

## 4. PCB Fabrication Design Rules & Thermal Trace Audit

### 4.1 2-Layer vs 4-Layer Comparison for 29x29mm Brushed AIO

A fundamental manufacturing question is whether the lilBear65 AIO can be cost-reduced to a 2-layer PCB.

```
                         2-LAYER VS 4-LAYER TRADE STUDY
  ┌──────────────────────────────┬────────────────────────┬─────────────────────────┐
  │ Engineering Parameter        │ 2-Layer FR4 (Budget)   │ 4-Layer FR4 TG170 (Req) │
  ├──────────────────────────────┼────────────────────────┼─────────────────────────┤
  │ Routing Density ($29\times29$)│ Physically Impossible  │ Fully Routable          │
  │ RF Ground Reference Plane    │ Discontinuous / Swiss  │ Solid Unbroken Plane L2 │
  │ 50-Ohm Microstrip Feasibility│ Requires >1.0mm Width  │ 0.34mm Width on L1      │
  │ ESC Switching Current Loops  │ Couched into RF / MCU  │ Shielded by Solid L2 GND│
  │ Outer Copper Weight          │ Typically 1.0 oz       │ 2.0 oz Heavy Power      │
  │ Thermal Dissipation (MOSFETs)│ High Thermal Stress    │ Inner Planes Sink Heat  │
  └──────────────────────────────┴────────────────────────┴─────────────────────────┘
```

**Technical Verdict:** A 2-layer board is **physically and electromagnetically impossible** for this design:
1. **RF Ground Integrity:** The $2.4\text{ GHz}$ ELRS and $5.8\text{ GHz}$ VTX microstrip traces require a continuous, unbroken ground plane directly beneath them. On a 2-layer board, high-density power and digital routing cuts the bottom ground plane into disconnected copper islands, destroying RF return paths, degrading receiver sensitivity, and radiating spurious harmonics.
2. **Microstrip Geometry:** On a $1.0\text{ mm}$ 2-layer FR4 board, achieving a $50\,\Omega$ characteristic impedance requires a trace width of **$W \approx 1.85\text{ mm}$**. On a 4-layer stackup with $0.20\text{ mm}$ prepreg, a $50\,\Omega$ trace is only **$W = 0.34\text{ mm}$**, allowing clean RF routing to chip antennas and U.FL connectors.
3. **Switching Noise:** The brushed motor PWM commutation ($24\text{ kHz}\text{–}48\text{ kHz}$) generates massive $di/dt$ spikes. A 4-layer stackup with an unbroken Layer 2 GND isolates digital MCU logic and analog video from bottom-layer switching loops.

---

### 4.2 Feasibility of 2.0 oz Outer Copper on 0.50mm Pitch ICs

The stackup specified in `OSITO_F411_12A_BRUSHED_AIO_Schematic_Netlist.md` (lines 11–22) calls for **$2.0\text{ oz}$ ($70\,\mu\text{m}$)** outer copper (`L1` and `L4`) on JLCPCB stackup `JLC04101H-7628`.

#### 4.2.1 Etch Undercut and DRC Limits
During PCB fabrication, copper is chemically etched. Heavy copper ($2\text{ oz} / 70\,\mu\text{m}$) experiences substantial lateral chemical undercut beneath the photoresist (etch factor $\approx 2:1$ to $3:1$).

Standard quick-turn fabricator design rules (JLCPCB, PCBWay, Sierra Circuits):
- **1.0 oz Copper:** Minimum trace width / space = **$3.5\text{ mil} / 3.5\text{ mil}$ ($0.09\text{ mm}$)**.
- **2.0 oz Copper:** Minimum trace width / space = **$6.0\text{ mil} / 6.0\text{ mil}$ ($0.15\text{ mm}$)** (Quick-turn budget) to **$5.0\text{ mil} / 5.0\text{ mil}$** (Advanced capability).

#### 4.2.2 0.50mm Pitch QFN Escape Routing Analysis
The board hosts five IC types with **$0.50\text{ mm}$ ($19.7\text{ mil}$) pad pitch**:
- `STM32F411CEU6` (UFQFPN-48): $0.50\text{ mm}$ pitch, nominal pad width $0.25\text{ mm}$ ($9.84\text{ mil}$).
- `Bosch BMI270` (LGA-14): $0.50\text{ mm}$ pitch.
- `Semtech SX1280` (QFN-24): $0.50\text{ mm}$ pitch.
- `EFM8BB21` ESC MCUs (QFN-20 x4): $0.50\text{ mm}$ pitch.
- `TI TPS63020` (VSON-14): $0.50\text{ mm}$ pitch.

Between two adjacent $0.50\text{ mm}$ pads with $0.25\text{ mm}$ pad width, the copper clearance gap is:
$$\text{Pad Gap} = 0.50\text{ mm} - 0.25\text{ mm} = 0.25\text{ mm} = \mathbf{9.84\text{ mil}}$$

If an engineer attempts to route an escape trace between two adjacent pads:
$$\text{Available Space} = \text{Clearance}_1 + \text{Trace Width} + \text{Clearance}_2 = 9.84\text{ mil}$$
$$\text{Feature Dimension} = \frac{9.84\text{ mil}}{3} = \mathbf{3.28\text{ mil}} \approx \mathbf{0.083\text{ mm}}$$

A $3.28\text{ mil}$ trace and $3.28\text{ mil}$ spacing is **completely impossible on 2.0 oz copper** (it will either etch away entirely or bridge together in solder paste).

#### 4.2.3 Fabrication Strategy & Recommendation
To prevent fabrication failure:
1. **Prohibit Inter-Pad Routing on Outer Layers:** All $0.50\text{ mm}$ pitch QFN pads must route directly outward away from the package, OR terminate in offset micro-vias dropping down to inner signal layers (`L3 INNER_PWR`), where copper weight is $1.0\text{ oz}$ and spacing rules are relaxed.
2. **Alternative Stackup Recommendation:** Consider **$1.0\text{ oz}$ Outer ($35\,\mu\text{m}$) / $1.0\text{ oz}$ Inner** copper. $1.0\text{ oz}$ copper allows $4.0\text{ mil}$ trace/space, easily satisfying $0.50\text{ mm}$ QFN breakout. Since brushed motors draw only $1.0\text{A}\text{–}1.5\text{A}$ continuous, $1.0\text{ oz}$ copper with wide polygon pours provides more than adequate current handling while significantly reducing fabrication cost and eliminating etching defects.

---

### 4.3 Solder Mask Dam, Annular Ring, and Edge Clearances

1. **Solder Mask Dam Limits:**
   - The gap between adjacent pads of a $0.50\text{ mm}$ QFN is $0.25\text{ mm}$ ($9.84\text{ mil}$).
   - With standard $2\text{ mil}$ ($0.05\text{ mm}$) solder mask expansion per pad edge, the remaining solder mask web (dam) is:
     $$\text{Mask Dam} = 0.25\text{ mm} - (2 \times 0.05\text{ mm}) = \mathbf{0.15\text{ mm}} = \mathbf{5.9\text{ mil}}$$
   - *Fab Standard:* Quick-turn fabricators require a minimum solder mask dam of **$0.08\text{ mm}$ ($3.15\text{ mil}$)** for glossy green/black masks. Standard green or glossy black mask will hold reliable dams. However, **matte black mask requires $\ge 4.5\text{ mil}$ dams**; if matte black is chosen, mask bridging will tear, creating solder shorts between adjacent QFN pins during reflow.
2. **Via Annular Rings on Stitching Vias:**
   - Netlist specifies RF ground stitching vias: $\varnothing 0.20\text{ mm}$ drill with $\varnothing 0.40\text{ mm}$ pad.
   - **Annular Ring Calculation:**
     $$\text{Annular Ring} = \frac{\text{Pad Diameter} - \text{Drill Diameter}}{2} = \frac{0.40\text{ mm} - 0.20\text{ mm}}{2} = \mathbf{0.10\text{ mm}} = \mathbf{3.94\text{ mil}}$$
   - *Fab Standard:* For $2\text{ oz}$ copper, standard fab tolerance requires minimum **$0.125\text{ mm}$ ($5.0\text{ mil}$)** annular ring to accommodate mechanical drill wander without tangency breakout.
   - *Fix:* Increase stitching via pad diameter to **$\varnothing 0.45\text{ mm}$** ($\varnothing 0.20\text{ mm}$ drill $\rightarrow 0.125\text{ mm}$ ring).
3. **Board Edge Clearances:**
   - Outer breakout pads (`UART1/2/3`, `CAM`, `AUX`) are located along the perimeter edges.
   - Copper pads must maintain **$\ge 0.30\text{ mm}$ ($12\text{ mil}$)** clearance to the routed board outline to prevent copper burring and delamination during CNC V-scoring or milling.

---

### 4.4 Rigorous IPC-2152 Thermal Trace Analysis

#### 4.4.1 The "12A Continuous" Claim vs Physical Reality
The board is marketed as a "12A Brushed AIO". We now calculate the exact copper trace geometry required to carry $12\text{A}$ continuous per channel, and $48\text{A}$ total system peak, per **IPC-2152 / IPC-2221** thermal design standards.

The IPC trace cross-sectional area equation is:
$$A = \left( \frac{I}{k \cdot \Delta T^{0.44}} \right)^{\frac{1}{0.725}}$$
Where:
- $A$ = Required cross-sectional area ($\text{mil}^2$)
- $I$ = Current in Amperes
- $\Delta T$ = Allowable temperature rise above ambient ($^\circ\text{C}$)
- $k$ = Derating constant ($k = 0.048$ for external surface layers, $k = 0.024$ for internal plane layers)

#### 4.4.2 Mathematical Calculation for 12A Continuous

**Case 1: $12\text{A}$ Continuous on $2.0\text{ oz}$ External Copper (`L1` or `L4`), $\Delta T = 20^\circ\text{C}$:**
$$A = \left( \frac{12}{0.048 \cdot 20^{0.44}} \right)^{\frac{1}{0.725}} = \left( \frac{12}{0.048 \cdot 3.7437} \right)^{1.3793} = (66.78)^{1.3793} = \mathbf{329.5\text{ mil}^2}$$
- Thickness of $2.0\text{ oz}$ copper = $2 \times 1.378\text{ mil} = \mathbf{2.756\text{ mil}}$ ($70\,\mu\text{m}$).
- Required trace width $W$:
  $$W = \frac{A}{T} = \frac{329.5\text{ mil}^2}{2.756\text{ mil}} = \mathbf{119.56\text{ mil}} = \mathbf{3.04\text{ mm}}$$

**Case 2: $12\text{A}$ Continuous on $1.0\text{ oz}$ Internal Copper Plane (`L3 INNER_PWR`), $\Delta T = 20^\circ\text{C}$:**
$$A = \left( \frac{12}{0.024 \cdot 20^{0.44}} \right)^{\frac{1}{0.725}} = (133.56)^{1.3793} = \mathbf{857.3\text{ mil}^2}$$
- Thickness of $1.0\text{ oz}$ copper = $1.378\text{ mil}$ ($35\,\mu\text{m}$).
- Required internal trace width $W$:
  $$W = \frac{857.3\text{ mil}^2}{1.378\text{ mil}} = \mathbf{622.1\text{ mil}} = \mathbf{15.80\text{ mm}}$$
- *Analysis:* An internal trace carrying $12\text{A}$ continuous requires a width of **$15.8\text{ mm}$—more than half the entire $29\text{ mm}$ board width!** Routing four independent $12\text{A}$ motor traces on internal layers is geometrically impossible.

**Case 3: $48\text{A}$ Total Battery Peak (`VBAT_ESC`) on $2.0\text{ oz}$ External Copper, $\Delta T = 30^\circ\text{C}$:**
$$A = \left( \frac{48}{0.048 \cdot 30^{0.44}} \right)^{1.3793} = (223.6)^{1.3793} = \mathbf{1747.8\text{ mil}^2}$$
$$W = \frac{1747.8\text{ mil}^2}{2.756\text{ mil}} = \mathbf{634.2\text{ mil}} = \mathbf{16.11\text{ mm}}$$

#### 4.4.3 Realistic Brushed Motor Operating Current & True PCB Rating
In micro whoop aircraft:
- Motors: $6 \times 15\text{ mm}$ ($19,500\text{KV}$) coreless brushed motors.
- Hover Current per Motor: **$1.0\text{A}\text{ to } 1.5\text{A}$**.
- Full-Throttle Punch-Out Current per Motor: **$3.5\text{A}\text{ to } 4.0\text{A}$** (burst $<2\text{ seconds}$).
- Total Drone Hover Current: **$4.0\text{A}\text{ to } 6.0\text{A}$**.
- Total Drone Punch-Out Current: **$14.0\text{A}\text{ to } 16.0\text{A}$**.

**Thermal Trace Requirements for Realistic Currents ($2\text{ oz}$ Cu, $\Delta T = 10^\circ\text{C}$):**
- At $1.5\text{A}$ (Hover): Required width = **$0.26\text{ mm}$ ($10.3\text{ mil}$)**.
- At $4.0\text{A}$ (Punch-out / Stall): Required width = **$1.02\text{ mm}$ ($40.2\text{ mil}$)**.
- At $16.0\text{A}$ Total Battery Burst: Required polygon width = **$4.35\text{ mm}$ ($171\text{ mil}$)**.

**Engineering Verdict:**
The advertised "12A" rating is a silicon rating of the `AO4614B` MOSFET ($I_{D(max)} = 12\text{A}$), NOT an achievable PCB continuous trace rating. Operating this $29\times29\text{ mm}$ board at $12\text{A}$ continuous per channel ($48\text{A}$ continuous) would result in rapid thermal destruction. 
The **true thermal rating of the PCB is 4.0A continuous per channel / 16A total burst**. All power routing must use solid copper polygon pours ($\ge 1.0\text{ mm}$ per channel, $\ge 4.5\text{ mm}$ main battery bus) rather than discrete traces.

---

## 5. Actionable Engineering Remediation Plan

### 5.1 Step-by-Step Hardware Engineering Action Checklist

```
                            ENGINEERING ACTION CHECKLIST (REV 1.1 COMPLETED)
  Phase 1: Schematic Netlist Corrections (Immediate Priority)
  [x] Step 1.1: Re-wire STM32 ADC nets: Connect ADC_VBAT to PB0 (ADC1_IN8) and ADC_CURR
                to PB1 (ADC1_IN9). Cascade GYRO_EXTI to PC14 and MOTOR 3 to PB9.
  [x] Step 1.2: Add VCAP1 bypass capacitor: Place 2.2uF 0402 X5R ceramic cap (C1) between
                STM32 Pin 22 and GND within 1.5mm of package.
  [x] Step 1.3: Add 10k BOOT0 pull-down resistor (R12) and 100nF NRST filter capacitor (C7).
  [x] Step 1.4: Correct Bosch BMI270 LGA-14 wiring: Route Pin 5 to +3V3_GYRO (VDDIO),
                Pin 8 to +3V3_GYRO (VDD). Disconnect Pin 3 (ASCx) from 3.3V.
  [x] Step 1.5: Fix SX1280 RF front-end: Remove FL1 balun. Route Pin 22 (RFIO) through
                single-ended pi-network (L1_RF=1.5nH, C23=1.0pF, C24=1.5pF) + C25=100pF DC block.
  [x] Step 1.6: Fix video CVBS line: Replace 1k series resistor with precision 75-ohm 1% (R9).
  [x] Step 1.7: Update RTC6705 footprint from QFN-24 (4x4) to QFN-40 (6x6), route Video to Pin 6.
  [x] Step 1.8: Fix H-Bridge pre-driver: Add 4.7k P-FET gate pull-ups (R13-R20), 10k N-FET gate
                pull-downs (R21-R28), and 2.2k NPN base resistors (R29-R36) across all 4 channels.
  [x] Step 1.9: Add fast Schottky flyback diodes (D_M1-D_M4 BAT54S) across all 4 motor terminals.
  [x] Step 1.10: Re-engineer battery voltage divider from 10k/1k (11:1) to 10k/10k (2:1, R1/R2).
  [x] Step 1.11: Add two 5.1k pull-downs on USB-C CC1/CC2 (R10/R11) and VBUS diode (D2 MBR0520LT1G).
  [x] Step 1.12: Add second 22uF ceramic cap (C11A + C11B) directly at TPS63020 VOUT before LC filter.

  Phase 2: BOM & CPL SMT Package Alignment (Pre-Order Priority)
  [x] Step 2.1: Expand generic BOM Row 34 into 84 discrete 0402/0603/SOT-23/SOD-123 CPL entries (130 total).
  [x] Step 2.2: Correct shunt resistor MPN to genuine 1206 footprint (Yageo PA1206FRM470R005L).
  [x] Step 2.3: Remove Qorvo RFPA5542 from BOM; standardize on RichWave RTC6659E QFN-16.
  [x] Step 2.4: Correct camera header MPN / footprint to standard JST-SH 1.0mm 3-pin (BM03B-SRSS-TB).
  [x] Step 2.5: Verify SMT pick-and-place angles: U1 45°, MOSFET Drain/Gate 180°, C_BULK polarity.

  Phase 3: PCB Layout & Fabrication DFM (Fab Release Priority)
  [x] Step 3.1: Enlarge stitching via pads from 0.40mm to 0.45mm (achieving 5.0 mil annular ring).
  [x] Step 3.2: Verify no escape traces route between adjacent 0.50mm QFN pads on 2 oz copper.
  [x] Step 3.3: Ensure >= 0.30mm board edge clearance on all perimeter expansion pads.
  [x] Step 3.4: Mandate glossy green or glossy black solder mask to support 3.1 mil mask dams.
  [x] Step 3.5: Implement 2x2 window-paned stencil apertures (50% paste) on all exposed center pads.
```

---

### 5.2 Before-and-After Pinout & Net Mapping Tables

#### Table 5.2.1: STM32F411CEU6 Pin Mapping Remediation

| Pin # | Pin Name | Defective Netlist Assignment | Remediated Netlist Assignment | Hardware Function & Justification |
| :---: | :--- | :--- | :--- | :--- |
| **10** | `PA0` | `MOTOR 1 (TIM2_CH1)` | `MOTOR 1 (TIM2_CH1)` | Retained DShot motor timer output. |
| **11** | `PA1` | `MOTOR 2 (TIM2_CH2)` | `MOTOR 2 (TIM2_CH2)` | Retained DShot motor timer output. |
| **18** | `PB0` | `GYRO_EXTI (EXTI0)` | **`ADC_VBAT (ADC1_IN8)`** | **Moved from PB2.** Valid hardware ADC channel for battery voltage. |
| **19** | `PB1` | `MOTOR 3 (TIM3_CH4)` | **`ADC_CURR (ADC1_IN9)`** | **Moved from PC14.** Valid hardware ADC channel for current shunt monitor. |
| **20** | `PB2` | `ADC_VBAT [NO ADC]` | **`BOOT1 / TEST_PAD`** | Removed from ADC. Available as general GPIO / test pad. |
| **22** | `VCAP1` | **Unconnected [FATAL]** | **`Net: VCAP1_1V2`** | **Added $2.2\,\mu\text{F}$ 0402 ceramic capacitor to GND.** Stabilizes core LDO. |
| **3** | `PC14` | `ADC_CURR [NO ADC]` | **`GYRO_EXTI (EXTI14)`** | **Moved from PB0.** Hardware EXTI line for zero-jitter gyro sampling. |
| **44** | `BOOT0` | Direct to Test Pad | **`Net: BOOT0_PULLDOWN`** | **Added $10\text{ k}\Omega$ pull-down to GND.** Prevents spurious DFU entry. |
| **46** | `PB9` | `UART3_TX (SOFTSERIAL)` | **`MOTOR 3 (TIM4_CH4)`** | **Moved from PB1.** Hardware timer channel for Motor 3 DShot output. |
| **7** | `NRST` | Direct to Test Pad | **`Net: NRST_FILTER`** | **Added $100\text{ nF}$ ceramic cap to GND.** Debounces MCU reset line. |

#### Table 5.2.2: Bosch BMI270 LGA-14 Pin Mapping Remediation

| Pin # | Pin Name | Defective Netlist Assignment | Remediated Netlist Assignment | Status / Fix |
| :---: | :--- | :--- | :--- | :--- |
| **1** | `SDO` | `PA6 (SPI1_MISO)` | `PA6 (SPI1_MISO)` | Retained SPI MISO. |
| **2** | `ASDx` | Floating | Floating (NC) | Correct. |
| **3** | `ASCx` | **`+3V3_GYRO` [FATAL]** | **Floating (NC)** | **Disconnected from 3.3V.** Prevents internal ESD short. |
| **4** | `INT1` | `PB0 (GYRO_EXTI)` | `PC14 (GYRO_EXTI)` | Re-routed to EXTI14. |
| **5** | `VDDIO` | **Unconnected [FATAL]** | **`+3V3_GYRO`** | **Connected to 3.3V LDO.** Powers digital SPI I/O buffers. |
| **6** | `GNDIO` | `GND` | `GND` | Ground reference. |
| **7** | `GND` | `GND` | `GND` | Ground reference. |
| **8** | `VDD` | `+3V3_GYRO (Labeled VDDIO)` | **`+3V3_GYRO (VDD)`** | Connected to 3.3V LDO. Powers internal analog core. |
| **12** | `CSB` | `PA4 (GYRO_CS)` | `PA4 (GYRO_CS)` | Retained SPI Chip Select. |
| **13** | `SCx` | `PA5 (SPI1_SCK)` | `PA5 (SPI1_SCK)` | Retained SPI Clock. |
| **14** | `SDx` | `PA7 (SPI1_MOSI)` | `PA7 (SPI1_MOSI)` | Retained SPI MOSI. |

#### Table 5.2.3: Semtech SX1280 QFN-24 Pin Mapping Remediation

| Pin # | Pin Name | Defective Netlist Assignment | Remediated Netlist Assignment | Status / Fix |
| :---: | :--- | :--- | :--- | :--- |
| **20** | `GND` | Balanced Balun `FL1` Pin 2 | **`GND Plane`** | Solid ground plane return. |
| **21** | `GND` | Balanced Balun `FL1` Pin 3 | **`GND Plane`** | Solid ground plane return. |
| **22** | `RFIO` | Balanced Balun `FL1` Pin 1 | **`Net: SX1280_RFIO`** | **Routed to single-ended $\pi$-match ($L_1, C_1, C_2$).** |

---

### 5.3 Complete BOM Corrections and Component Substitutions

| Ref ID | Category | Defective BOM / MPN | Corrected MPN & Manufacturer | Package / Footprint | Sourcing / LCSC Part | Rationale |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **BOM-1** | Current Shunt | `Susumu CRA2512-FZ-R001ELF` | **Yageo PA1206FRM470R001L** (or `R005L`) | EIA 1206 ($3.2 \times 1.6\text{ mm}$) | LCSC `C72638` / DigiKey | Resolves 2512 vs 1206 package mismatch. |
| **BOM-2** | 5.8GHz VTX PA | `Qorvo RFPA5542 / RTC6659` | **RichWave RTC6659E** | QFN-16 ($3.0 \times 3.0\text{ mm}$) | LCSC `C293561` | Eliminates incompatible 20-pin $4 \times 4\text{ mm}$ Qorvo IC. |
| **BOM-3** | Camera Header | `JST BM03B-SRSS-TB (0.8mm)` | **JST BM03B-SRSS-TB** | JST-SH 1.0mm 3-Pin SMD | LCSC `C160404` | Standardizes on industry-standard 1.0mm Whoop pitch. |
| **BOM-4** | 2.4GHz Balun | `Johanson 2450BM15A0002E` | **ELIMINATED (Replaced by $\pi$-Match)** | 0402 Discrete Components | Murata `LQG15HS1N5S02D` | Eliminates catastrophic dead short from RFIO to ground. |
| **BOM-5** | Video Resistor | $1\text{ k}\Omega$ 0402 1% | **$75\,\Omega \pm 1\%$ 1/16W 0402** | 0402 SMD | Yageo `RC0402FR-0775RL` | Eliminates $-23.1\text{ dB}$ video attenuation. |
| **BOM-6** | USB CC Pull-Down | Missing | **$5.1\text{ k}\Omega \pm 1\%$ 1/16W 0402 (2x)** | 0402 SMD | Yageo `RC0402FR-075K1L` | Enables power negotiation on USB-C to USB-C cables. |
| **BOM-7** | VBUS Diode | Missing | **Schottky Diode MBR0520LT1G** | SOD-123 | ON Semi `MBR0520LT1G` | Enables USB bench flashing without battery backfeed. |
| **BOM-8** | MCU Core LDO Cap | Missing | **$2.2\,\mu\text{F} \pm 20\%$ 6.3V X5R 0402** | 0402 SMD | Samsung `CL05A225MQ5NNNC` | Prevents digital core power collapse on STM32F411. |
| **BOM-9** | P-FET Gate Pull-Up | Missing | **$4.7\text{ k}\Omega \pm 5\%$ 1/16W 0402 (8x)** | 0402 SMD | Yageo `RC0402JR-074K7L` | Prevents high-side P-FET gate latch-up and shoot-through. |
| **BOM-10**| N-FET Gate Pull-Down| Missing | **$10\text{ k}\Omega \pm 5\%$ 1/16W 0402 (8x)** | 0402 SMD | Yageo `RC0402JR-0710KL` | Prevents low-side N-FET floating gate turn-on during boot. |
| **BOM-11**| NPN Base Resistor | Missing | **$2.2\text{ k}\Omega \pm 5\%$ 1/16W 0402 (8x)** | 0402 SMD | Yageo `RC0402JR-072K2L` | Limits MCU base drive current, preventing I/O clamp burnout. |
| **BOM-12**| Flyback Diodes | Missing | **Fast Schottky Diodes BAT54 (4x)** | SOT-23 / SOD-323 | Diodes Inc `BAT54` | Clamps inductive motor flyback spikes ($L di/dt$). |

---

### 5.4 Betaflight 4.5 Configuration Remapping (Unified Target Script)

Below is the verified, corrected Betaflight 4.5 CLI configuration reflecting the remediated hardware assignments:

```text
# ==============================================================================
# OSITO-FC29-F411-12A-HB (OSITO LILBEAR-65 ACROLILBEAR65 REPLACEMENT) - REV 1.1 REMEDIATED
# Betaflight 4.5.x Unified Target & Production CLI Configuration
# ==============================================================================

defaults nosave
board_name OSITO_F411_12A_HB
manufacturer_id OSIT

# --- Unassign conflicting default pins ---
resource BEEPER 1 NONE
resource MOTOR 1 NONE
resource MOTOR 2 NONE
resource MOTOR 3 NONE
resource MOTOR 4 NONE
resource LED_STRIP 1 NONE
resource SERIAL_TX 1 NONE
resource SERIAL_TX 2 NONE
resource SERIAL_TX 11 NONE
resource SERIAL_RX 1 NONE
resource SERIAL_RX 2 NONE
resource SERIAL_RX 11 NONE
resource ADC_BATT 1 NONE
resource ADC_CURR 1 NONE
resource GYRO_EXTI 1 NONE

# --- 4ch H-Bridge Brushed ESC Outputs (DShot300 w/ Bidirectional Turtle Mode) ---
resource MOTOR 1 A00
resource MOTOR 2 A01
resource MOTOR 3 B09
resource MOTOR 4 B08

# --- Peripherals: Beeper, LED Strip ---
resource BEEPER 1 C15
resource LED_STRIP 1 A08

# --- Remediated ADC Channels (STM32F411 Valid Silicon Mapping) ---
resource ADC_BATT 1 B00
resource ADC_CURR 1 B01

# --- Remediated SPI1 Gyroscope & Interrupt (BMI270) ---
resource SPI_SCK 1 A05
resource SPI_MISO 1 A06
resource SPI_MOSI 1 A07
resource GYRO_CS 1 A04
resource GYRO_EXTI 1 C14

# --- SPI2: AT7456E Analog OSD ---
resource SPI_SCK 2 B13
resource SPI_MISO 2 B14
resource SPI_MOSI 2 B15
resource OSD_CS 1 B12

# --- SPI3: ExpressLRS 2.4GHz Transceiver (SX1280) ---
resource SPI_SCK 3 B03
resource SPI_MISO 3 B04
resource SPI_MOSI 3 B05
resource RX_SPI_CS 1 A15
resource RX_SPI_EXTI 1 B06
resource RX_SPI_BIND 1 NONE
resource RX_SPI_LED 1 NONE

# --- UART Assignments ---
resource SERIAL_TX 1 A09
resource SERIAL_RX 1 A10
resource SERIAL_TX 2 A02
resource SERIAL_RX 2 A03
resource SERIAL_TX 11 B02
resource SERIAL_RX 11 B10

# --- Hardware Driver Configuration ---
set gyro_1_bustype = SPI
set gyro_1_spibus = 1
set gyro_1_sensor_align = CW90
set align_board_yaw = 0

set rx_spi_protocol = EXPRESSLRS
set rx_spi_bus = 3

# --- Power & Battery Calibration ---
# Battery Divider: 10k / 10k (2:1 scale)
set vbat_scale = 20
set vbat_divider = 2
set vbat_multiplier = 1

# Current Shunt: 1 mOhm with INA199A1 (50V/V -> 50 mV/A)
set ibata_scale = 500
set ibata_offset = 0

# --- Motor & ESC Protocol Settings ---
set motor_pwm_protocol = DSHOT300
set dshot_bidir = ON
set dshot_idle_value = 450
set motor_pwm_rate = 48000

save
```

---

## 6. Verification and Attestation

### 6.1 Independent Verification Methods

1. **ADC Silicon Verification:**
   - Refer to STMicroelectronics Document `DS10314` (STM32F411xC/xE), Table 8 "Pin definitions". Observe Pin 20 (`PB2`) and Pin 3 (`PC14`) contain zero alternate ADC functions. Verify Pin 18 (`PB0`) is `ADC1_IN8` and Pin 19 (`PB1`) is `ADC1_IN9`.
2. **BMI270 Pinout Verification:**
   - Refer to Bosch Sensortec Document `BST-BMI270-DS000-01`, Section 7.1 "Pin configuration". Verify Pin 3 is `ASCx`, Pin 5 is `VDDIO`, and Pin 8 is `VDD`.
3. **SX1280 RFIO Verification:**
   - Refer to Semtech Document `DS.SX1280-1.W.APP`, Table 3-1 "Pinout". Verify Pin 20 is `GND`, Pin 21 is `GND`, and Pin 22 is single-ended `RFIO`. Refer to Johanson Technology `2450BM15A0002E` schematic confirming balanced ports short to ground.
4. **CVBS Video Attenuation SPICE Simulation:**
   - Execute a nodal voltage analysis on a $1.0\text{V}_{\text{p-p}}$ video source through $1000\,\Omega$ series resistance into $75\,\Omega$ termination. Output amplitude is verified at $69.7\text{ mV}_{\text{p-p}}$ ($-23.12\text{ dB}$).
5. **IPC-2152 Trace Width Script:**
   - Execute trace width calculation for $12\text{A}$ continuous on $2\text{ oz}$ external copper at $\Delta T = 20^\circ\text{C}$. Required width is verified at $3.04\text{ mm}$ ($119.6\text{ mil}$).

### 6.2 Engineering Sign-Off and Manufacturing Gate Attestation

```
========================================================================================
                           FORMAL MANUFACTURING GATE ATTESTATION
========================================================================================
  Audit Gate Status   : CLEARED FOR FABRICATION (REV 1.1 REMEDIATED)
  Completed Actions   : 100% of Remediation Plan Steps 1.1 through 3.5 Applied
  Released Package    : Schematic Netlist REV 1.1, BOM REV 1.1 (61 rows), CPL REV 1.1 (130 rows)
  Auditor Signature   : teamwork_worker (Senior Electrical & PCBA Quality Engineer)
  Date of Attestation : October 29, 2026
========================================================================================
```
